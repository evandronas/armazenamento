import logging
import os

import hashlib
from redis.cluster import RedisCluster as Redis

from log_utils import conf_logger


class RedisUtilities:
    redis_url = os.getenv("REDIS_CLUSTER_ENDPOINT", "fe-rebatedor-redis.qqysli.clustercfg.sae1.cache.amazonaws.com")
    _redis_client = None
    __logger = conf_logger(name=__name__, level=logging.DEBUG)

    def __init__(self):
        self.__logger.debug("INICIADO")

    def conect_to_redis(self, host=redis_url, port=6379, **kwargs):
        self._redis_client = Redis(host=host, port=port, socket_connect_timeout=1, socket_timeout=1, **kwargs)

    def is_redis_connected(self):
        if self._redis_client:
            return self._redis_client.ping()
        else:
            return False

    def nodes(self):
        if not self._redis_client:
            return []
        return self._redis_client.get_nodes()

    def insert(self, key: str, value, ttl, **kwargs):
        if not self._redis_client:
            self.__logger.info("REDIS OFF")
            return False
        return self._redis_client.set(name=key, value=value, keepttl=ttl, **kwargs)

    def search(self, key: str):
        if not self._redis_client:
            return False
        return self._redis_client.get(name=key)

    def remove(self, key: str):
        if not self._redis_client:
            return False
        return self._redis_client.delete(key)

    @staticmethod
    def generate_hash_key(key: str) -> str:
        return hashlib.md5(key.encode()).hexdigest()


if __name__ == '__main__':
    r = RedisUtilities()
    print(
        r.generate_hash_key(
            "TESTES"
        )
    )

    r.conect_to_redis()
    if r.is_redis_connected():
        print(
            "REDIS: READY"
        )
        print(
            r._redis_client.get_nodes()
        )

        if r.insert(key="TESTE", value="VALUE", ttl=0):
            print("INSERT DONE")

        print(
            r.search(
                key="TESTE"
            )
        )




