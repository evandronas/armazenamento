import datetime
import json
import logging
import time
import traceback
from json import loads
import log_utils

from fastapi import FastAPI, Request, Response, status
from redis.exceptions import RedisClusterException, TimeoutError
from starlette.responses import JSONResponse

import redisUtilities
from redisUtilities import RedisUtilities

TTL_REGISTROS_REDIS = (24 * 60 * 60 * 30)
log_utils.ConfGlobalLogger()

logger = log_utils.conf_logger(
    name=__name__,
    level=logging.DEBUG
)


def parse_api_gateway_response_to_fastapi(response: dict) -> JSONResponse:
    _response = JSONResponse(
        content=loads(response.get("body")),
        status_code=response.get("statusCode")
    )
    _response.headers.update(
        response.get("headers")
    )
    return _response


_redis_client = RedisUtilities()
try:
    _redis_client.conect_to_redis()
except RedisClusterException as e:
    logger.exception(f"REDIS ZUADO: {traceback.format_exc()}")

__start_time = time.time()

app = FastAPI()


async def get_request_body_data(request: Request, key: str):
    return (await request.json()).get(key)


@app.get("/actuator/health/redis")
def read_root():
    elapsed_time = time.time() - __start_time
    result = {
        "APP": f"UP: {time.strftime('%H:%M:%S', time.gmtime(elapsed_time))}",
        "REDIS": {
            "STATUS": f"CONNECTED: {_redis_client.is_redis_connected()}",
            "NODES": str(_redis_client.nodes())
        }
    }

    return result


@app.get("/actuator/redis/kill")
def kill_instance():
    raise Exception("DESTRUINDO INSTANCIA")


@app.get("/actuator/redis/reconnect")
def connect_instance():
    _redis_client.conect_to_redis()


@app.get("/")
def check_get():
    logger.info("CHECK - GET")
    return {
        "status": "ok"
    }


@app.post("/")
def check_post():
    logger.info("CHECK - POST")
    return {"status": "ok"}


@app.post("/cards")
async def compromised_card(request: Request, response: Response):
    __card = redisUtilities.RedisUtilities.generate_hash_key(
        key=(await get_request_body_data(request=request, key="card")))
    logger.info(f"[DADOS DE CARTAO] {__card}")
    if not _redis_client.is_redis_connected():
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return {"status": f"REDIS INDISPONIVEL"}
    elif _redis_client.search(__card):
        return {"status": f"CARTAO COMPROMETIDO"}
    else:
        return {"status": f"CARTAO OK"}


@app.post("/cards/append")
async def compromised_card_insert(request: Request, response: Response):
    __card = redisUtilities.RedisUtilities.generate_hash_key(
        key=(await get_request_body_data(request=request, key="card")))
    __motivo = (await get_request_body_data(request=request, key="motivation"))
    __bandeira = (await get_request_body_data(request=request, key="card-brand"))

    data = {
        "bandeira": __bandeira,
        "motivo": __motivo,
        "cartao": __card,
        "timestamp": datetime.datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
    }

    logger.info(f"[DADOS DE CARTAO]: {data}")
    if _redis_client.insert(__card, json.dumps(data), TTL_REGISTROS_REDIS):
        return {"status": "CARTAO INSERIDO"}
    else:
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return {"status": "CARTAO NAO INSERIDO - PROBLEMAS NO REDIS"}


@app.post("/cards/remove")
async def compromised_card_remove(request: Request, response: Response):
    __card = redisUtilities.RedisUtilities.generate_hash_key(
        key=(await get_request_body_data(request=request, key="card")))
    logger.info(f"[DADOS DE CARTAO] {__card}")
    if _redis_client.remove(__card):
        return {"status": "CARTAO REMOVIDO"}
    else:
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return {"status": "CARTAO NAO REMOVIDO - PROBLEMAS NO REDIS"}


if __name__ == '__main__':
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8002)
