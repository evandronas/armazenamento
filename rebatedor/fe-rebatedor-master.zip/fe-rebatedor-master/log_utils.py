import sys

from logging import StreamHandler, getLogger, Formatter, INFO, Logger


def conf_logger(name, level=INFO) -> Logger:
    logger = getLogger(name)
    logger.setLevel(level)
    return logger


class ConfGlobalLogger():
    def __init__(
        self,
        handler_level=INFO,
        formatter=Formatter(
            "[%(asctime)s] [%(levelname)s] --- %(message)s (%(filename)s:%(lineno)s)",
            datefmt="%Y-%m-%d %H:%M:%S",
        ),
        xray_trace=False,
    ):
        self.handler_level = handler_level
        self.formatter = formatter
        self.xray = xray_trace

        self.__reset_root_handlers()

    def __reset_root_handlers(self):
        root = getLogger()

        if root.handlers:
            for handler in root.handlers:
                root.removeHandler(handler)
        root.addHandler(self.__get_out_handler())

    def __get_out_handler(self):
        out_hdlr = StreamHandler(sys.stdout)
        out_hdlr.setFormatter(self.formatter)
        out_hdlr.setLevel(self.handler_level)

        return out_hdlr
