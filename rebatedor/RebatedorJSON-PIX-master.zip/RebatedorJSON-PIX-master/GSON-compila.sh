#!/bin/ksh
 /usr/java8_64/bin/javac -cp $CLASSPATH:/home/cr313510/lib/gson-2.6.2.jar JSONServerGSON.java
 /usr/java8_64/bin/java -cp .:/home/cr313510/lib/gson-2.6.2.jar JSONServerGSON

