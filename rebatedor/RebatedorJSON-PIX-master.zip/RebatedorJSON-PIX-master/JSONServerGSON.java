import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket; 
import java.util.Scanner;
import com.google.gson.*;
import java.util.ArrayList;


public class JSONServerGSON {
		
        public static ArrayList<String> boxNSU = new ArrayList();		
        public static boolean flag;
        
        public static void main(String[] args){
                
            int port = 8000;
 
            try (ServerSocket serverSocket = new ServerSocket(port)) {
     
                System.out.println("Server is listening on port " + port);
     
                while (true) {
                    Socket socket = serverSocket.accept();
                    System.out.println("New client connected");
     
                    new ServerThread(socket).start();
                }
     
            } catch (IOException ex) {
                System.out.println("Server exception: " + ex.getMessage());
                ex.printStackTrace();
            }
            
        }            

        public static boolean consultaBox(String nsu){
            int n = boxNSU.size();
            int i;
            System.out.println("USOU boxNSU para o NSU: " + nsu);
            for (i=0; i<n; i++) {
                System.out.println("Pegou do array: " + boxNSU.get(i));
                if (boxNSU.get(i).equals(nsu))
                {
                    System.out.println("TRUE Pegou do array: " + boxNSU.get(i));
                    return true;
                }
            }
            return false;
            
        }        
}

class JSON
{

        private JsonObject json;

        public JSON(){
        }

        public String toString(){
                return json.toString();
        }

        public String getAttr(String attr){

        try {
            String[] nodes = attr.split("\\.");

            String child = nodes[nodes.length-1];

            JsonObject parent = json;

            for (int i=0; i<nodes.length-1; i++){
                parent = parent.getAsJsonObject(nodes[i]);
            }
            return parent.get(child).getAsString();

        } catch (Exception  ex) {
            System.out.println("\n\nNão foi possível encontrar o valor: " + attr);
            ex.printStackTrace();
            return "";
        }
        }

        public void updateAttr(String attr, String value){

        try{
            String[] nodes = attr.split("\\.");

            String child = nodes[nodes.length-1];

            JsonObject parent = json;

            for (int i=0; i<nodes.length-1; i++){
                parent = parent.getAsJsonObject(nodes[i]);
            }
            parent.addProperty(child,value);

        } catch (Exception  ex) {
            System.out.println("\n\nNão foi possível encontrar o valor: " + attr);
            ex.printStackTrace();
        }
        }

        public void setByString(String jsonString){
        json = new Gson().fromJson(jsonString, JsonObject.class);
        }

        public void readFromFile(String path){

        try {
            File myObj = new File(path);
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();

                json = new Gson().fromJson(data, JsonObject.class);

            }

            myReader.close();

        } catch (FileNotFoundException e) {
          System.out.println("An error occurred.");
          e.printStackTrace();
        }
    }


}

class JSONUtil{
        public void copyAttr(String attr, JSON json1, JSON json2){

        try{
            json2.updateAttr(attr, json1.getAttr(attr));
        } catch (Exception  ex) {
            System.out.println("\n\nNão foi possível encontrar o valor: " + attr);
            ex.printStackTrace();
        }

        }
}

class BuildResponse {

        JSON jsonOrigem;
        JSON json;
        
        public BuildResponse(String jsonMessage){

        try {
            jsonOrigem = new JSON();
            jsonOrigem.setByString(jsonMessage);

            //METODOS
            /*
                getAttr --> consulta valor do atributo
                copyAttr --> consulta no jsonOrigem e transporta o valor e campo para o json destino
                updateAttr ---> atualiza/cria um novo valor ou campo no json destino
            */
            //HELP CENTER
            /*
                bit63 --> COMPROVANTE LITERAL DE IMPRESSAO - TEXTO 
                alpha_response_code --> código de retorno  
                sequencialPooling
            */
            
            
            //modelo previo
            json = new JSON();

            JSONServerGSON.flag = true;
    
            if ( jsonOrigem.getAttr("shc_msg.msgtype").equals("900") ) 
            {
                JSONServerGSON.flag = false;
                json.readFromFile("null.model");
            }
             
             System.out.println("\n\n\nFLAG: " + JSONServerGSON.flag);
             if (JSONServerGSON.flag)
             {
            
                 switch (jsonOrigem.getAttr("shc_msg.origmsg")){
                    case "100" : json.readFromFile("0100-response-pix.model"); break;
                    case "600" : json.readFromFile("0600-response.model"); break;
                    case "400" : json.readFromFile("0400-response.model"); break;
                    default: json.readFromFile("0800-response.model");
                }
            

                        String[] valor = jsonOrigem.getAttr("shc_msg.amount").split("\\.");
 
                        if (valor[0].equals("70") && jsonOrigem.getAttr("shc_msg.origmsg").equals("600"))
                        {
                                json.readFromFile("0600-response-sw7.model");

                                new JSONUtil().copyAttr("segments.common.origrefnum", jsonOrigem, json);
                                        new JSONUtil().copyAttr("shc_msg.refnum", jsonOrigem, json); //NSU
                                        new JSONUtil().copyAttr("shc_msg.amount", jsonOrigem, json);
                                        new JSONUtil().copyAttr("shc_msg.termid", jsonOrigem, json);
                                        new JSONUtil().copyAttr("shc_msg.trace", jsonOrigem, json);
                                        new JSONUtil().copyAttr("shc_msg.acceptorname", jsonOrigem, json);
                                    new JSONUtil().copyAttr("shc_msg.acquirer", jsonOrigem, json);
                                    new JSONUtil().copyAttr("shc_msg.issuer", jsonOrigem, json);
                                        new JSONUtil().copyAttr("shc_msg.origtrace", jsonOrigem, json);
                        }

                        if (valor[1].equals("97") && jsonOrigem.getAttr("shc_msg.origmsg").equals("100"))
                        {
                            json.readFromFile("0100-response.model");
                        }
                    
                        
                        //sempre
                        new JSONUtil().copyAttr("shc_msg.refnum", jsonOrigem, json); //NSU
                        new JSONUtil().copyAttr("shc_msg.amount", jsonOrigem, json);
                        new JSONUtil().copyAttr("shc_msg.termid", jsonOrigem, json);
                        new JSONUtil().copyAttr("shc_msg.trace", jsonOrigem, json);
                        new JSONUtil().copyAttr("shc_msg.acceptorname", jsonOrigem, json);
                        //new JSONUtil().copyAttr("segments.pix.identificadorLojista", jsonOrigem, json);
                        //new JSONUtil().copyAttr("segments.pix.nomeFantasiaLojista", jsonOrigem, json);
                        //new JSONUtil().copyAttr("segments.pix.cidadeLojista", jsonOrigem, json);
                        new JSONUtil().copyAttr("shc_msg.acquirer", jsonOrigem, json);
                        new JSONUtil().copyAttr("shc_msg.issuer", jsonOrigem, json);
                        new JSONUtil().copyAttr("shc_msg.origtrace", jsonOrigem, json);
                        //new JSONUtil().copyAttr("segments.common.transactionId", jsonOrigem, json);

                        
                        if (jsonOrigem.getAttr("shc_msg.origmsg").equals("600"))
                        {
                        
                            new JSONUtil().copyAttr("segments.common.origrefnum", jsonOrigem, json);

                            if(jsonOrigem.getAttr("segments.pix.indicadorCancelaPix").equals("1"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.common.bit63", "");
                            }
                            else if (valor[1].equals("09"))
                            {
                                    if(valor[0].equals("12") && jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("02"))
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "00");
                                    }
                                    else if (valor[0].equals("13") && jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("03"))
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "00");
                                    }

                                    else
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "09");
                                        //json.updateAttr("segments.pix.dataPagamento", "");
                                        //json.updateAttr("segments.pix.horaPagamento", "");
                                        //json.updateAttr("segments.pix.transactionId", "");
                                        json.updateAttr("segments.common.bit63", "");
                                    }
                            }
                            else{
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.common.bit63", "");
                            }

                            if (valor[1].equals("93"))
                            {
                                if(jsonOrigem.getAttr("segments.pix.indicadorCancelaPix").equals("1"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "40");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                                else{
                                    json.updateAttr("shc_msg.alpha_response_code", "09");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }
                            if (valor[1].equals("92"))
                            {
                                if(jsonOrigem.getAttr("segments.pix.indicadorCancelaPix").equals("1"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "74");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                                else{
                                    json.updateAttr("shc_msg.alpha_response_code", "09");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }
                            if (valor[1].equals("91"))
                            {
                                if(jsonOrigem.getAttr("segments.pix.indicadorCancelaPix").equals("1"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "59");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                                else{
                                    json.updateAttr("shc_msg.alpha_response_code", "09");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }
                            if (valor[1].equals("90"))
                            {
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("06"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "00");
                                    json.updateAttr("segments.common.bit63", "PAGAMENTO APROVADO");
                                }
                                else{
                                    json.updateAttr("shc_msg.alpha_response_code", "09");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }
                            if (valor[1].equals("89"))
                            {
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("06"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "40");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                                else{
                                    json.updateAttr("shc_msg.alpha_response_code", "09");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }
                            if (valor[1].equals("88"))
                            {
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("01"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "74");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "74"); 
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            } 
                            if (valor[1].equals("87"))
                            {
                                if ( !JSONServerGSON.consultaBox( jsonOrigem.getAttr("segments.common.origrefnum") ) )
                                {
                                    if (jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                        JSONServerGSON.boxNSU.add(jsonOrigem.getAttr("segments.common.origrefnum"));
                                    if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("01"))
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "74");
                                        json.updateAttr("segments.common.bit63", "");
                                    }
                                    if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "74");
                                        json.updateAttr("segments.common.bit63", "");
                                    }
                                }
                                else {
                                    if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "59");
                                        json.updateAttr("segments.common.bit63", "");
                                    }   
                                }
                            }
                            if (valor[1].equals("86"))
                            {
                                if ( !JSONServerGSON.consultaBox( jsonOrigem.getAttr("segments.common.origrefnum") ) )
                                {
                                    if (jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                        JSONServerGSON.boxNSU.add(jsonOrigem.getAttr("segments.common.origrefnum"));
                                    if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("01"))
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "74");
                                        json.updateAttr("segments.common.bit63", "");
                                    }
                                    if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "74");
                                        json.updateAttr("segments.common.bit63", "");
                                    }
                                }
                                else {
                                    if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                    {
                                        json.updateAttr("shc_msg.alpha_response_code", "00");
                                        json.updateAttr("segments.common.bit63", "");
                                    }   
                                }
                            }
                            if (valor[1].equals("84"))
                            {
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("01"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "74");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "00");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }
                    if (valor[1].equals("11"))
                    {
                        json.updateAttr("shc_msg.alpha_response_code", "00");
                        json.updateAttr("segments.pix.cardHolderName", "Thamiris Silvestre Ferreira");
                        json.updateAttr("segments.pix.cnpjPagador", "123456789012345678");
                    }
                    if (valor[1].equals("12"))
                    {
                        json.updateAttr("shc_msg.alpha_response_code", "00");
                        json.updateAttr("segments.pix.cardHolderName", "ThamirisSilvestreFerreiraR");
                        json.updateAttr("segments.pix.cnpjPagador", "123456789012345678");
                    }
                    if (valor[1].equals("13"))
                    {
                        json.updateAttr("shc_msg.alpha_response_code", "00");
                        json.updateAttr("segments.pix.cardHolderName", "ThamirisSilvestreFerreiraR");
                        json.updateAttr("segments.pix.cnpjPagador", "");
                    }
                    if (valor[1].equals("14"))
                    {
                        json.updateAttr("shc_msg.alpha_response_code", "00");
                        json.updateAttr("segments.pix.cardHolderName", "");
                        json.updateAttr("segments.pix.cnpjPagador", "123456789012345678");
                    }


                            
                            
                            /* Cenarios por centavo - INICIO */
                            if (valor[1].equals("99"))
                            {
                                json.updateAttr("segments.common.bit63", "Instituicao sem comunicacao");
                                json.updateAttr("shc_msg.alpha_response_code", "74");
                            }
                            if (valor[1].equals("98"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");

                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "74");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }
                            /* Cenarios por centavo - FIM */

                        }

                        if (jsonOrigem.getAttr("shc_msg.origmsg").equals("400"))
                        {
                        
                            new JSONUtil().copyAttr("segments.common.origrefnum", jsonOrigem, json);
                        
                            /* Cenarios por centavo - INICIO */
                            if (valor[1].equals("41"))
                            {
                                json.updateAttr("segments.common.bit63", "Chave Pix Inexistente");
                                json.updateAttr("shc_msg.alpha_response_code", "41");
                            }
                            if (valor[1].equals("42"))
                            {
                                json.updateAttr("segments.common.bit63", "Chave Pix Nao cadastrada");
                                json.updateAttr("shc_msg.alpha_response_code", "42");
                            }
                            if (valor[1].equals("59"))
                            {
                                json.updateAttr("segments.common.bit63", "Negada, ausencia pgto");
                                json.updateAttr("shc_msg.alpha_response_code", "59");
                            }
                            if (valor[1].equals("74"))
                            {
                                json.updateAttr("segments.common.bit63", "Instituicao sem comunicacao");
                                json.updateAttr("shc_msg.alpha_response_code", "74");
                            }
                            if (valor[1].equals("72"))
                            {
                                json.updateAttr("segments.common.bit63", "Instituicao sem comunicacao");
                                json.updateAttr("shc_msg.alpha_response_code", "72");
                            }
                            if (valor[1].equals("76"))
                            {
                                json.updateAttr("segments.common.bit63", "Servico indisponivel no momento");
                                json.updateAttr("shc_msg.alpha_response_code", "76");
                            }
                            /* Cenarios por centavo - FIM */
                            if (valor[1].equals("95"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "74");
                                json.updateAttr("segments.common.bit63", "Instituicao sem comunicacao");
                                
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "43");
                                    json.updateAttr("segments.common.bit63", "LIGUE DOMICILIO PIX");
                                }
                            }
                            if (valor[1].equals("96"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "74");
                                json.updateAttr("segments.common.bit63", "A DEFINIR");
                                
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "00");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }
                            if (valor[1].equals("98"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "74");
                                json.updateAttr("segments.common.bit63", "A DEFINIR");
                                
                                if(jsonOrigem.getAttr("segments.pix.sequencialPooling").equals("00"))
                                {
                                    json.updateAttr("shc_msg.alpha_response_code", "74");
                                    json.updateAttr("segments.common.bit63", "");
                                }
                            }

                        }

                        if (jsonOrigem.getAttr("shc_msg.origmsg").equals("100"))
                        {
                    json.updateAttr("shc_msg.alpha_response_code", "00");
                            /* Cenarios por real - INICIO */
                            if (valor[0].equals("33"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", "3");
                            }
                    if (valor[0].equals("34"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", " 3");
                            }
                    if (valor[0].equals("35"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", "                         ");
                            }
                    if (valor[0].equals("36"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", " 338745837459238493059221");
                            }
                    if (valor[0].equals("37"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", "33387 5837459238493059221");
                            }


                    /* Cenarios por real - FIM */
                            
                            if (valor[1].equals("20"))
                            {
                                json.updateAttr("segments.common.bit63", "00020102021226720014br.gov.bcb.pix2550bx.com.br/pix/8b3da2f3-9a41-40d1-a91a-bd93113bd4415204000053039865406123.455802BR5913Fulano de Tal6008BRASILIA62190515RP12345678-2019630445C8");
                            }
                            if (valor[1].equals("21"))
                            {
                                json.updateAttr("segments.common.bit63", "00020101021226990014br.gov.bcb.pix2585bx.com.br/pix/8b3da2f3-9a41-40d1-a91a-bd93113bd441bx.com.br/pix/8b3dda2f3-9a45204000053039865406123.455802BR5925Fulano de Tal da REDE S/A6015BRASILIAREDESAT62290525RP12345678-20195678-20209630445C8");
                            }
                            if (valor[1].equals("22"))
                            {
                                json.updateAttr("segments.common.bit63", "00020101021226720014br.gov.bcb.pix2550bx.com.br/pix/8b3da2f3-9a41-40d1-a91a-bd93113bd4415204000053039865406123.455802BR5913Fulano de Tal6008BRASILIA630445C8");
                            }
                            if (valor[1].equals("23"))
                            {
                                json.updateAttr("segments.common.bit63", "00020101021226720014br.gov.bcb.pix2550bx.com.br/pix/8b3da2f3-9a41-40d1-a91a-bd93113bd44153039865406123.455802BR5913Fulano de Tal6008BRASILIA62190515RP12345678-2019630445C8");
                            }
                            if (valor[1].equals("24"))
                            {
                                json.updateAttr("segments.common.bit63", "00020101021226720014br.gov.bcb.pix2550bx.com.br/pix/8b3da2f3-9a41-40d1-a91a-bd93113bd441520400005406123.455802BR5913Fulano de Tal6008BRASILIA62190515RP12345678-2019630445C8");
                            }
                            if (valor[1].equals("25"))
                            {
                                json.updateAttr("segments.common.bit63", "00020101021226720014br.gov.bcb.pix2550bx.com.br/pix/8b3da2f3-9a41-40d1-a91a-bd93113bd4415204000053039865406123.455913Fulano de Tal6008BRASILIA62190515RP12345678-2019630445C8");
                            }
                            if (valor[1].equals("26"))
                            {
                                json.updateAttr("segments.common.bit63", "00020101021226720014br.gov.bcb.pix2550bx.com.br/pix/8b3da2f3-9a41-40d1-a91a-bd93113bd4415204000053039865406123.455802BR6008BRASILIA62190515RP12345678-2019630445C8");
                            }
                            if (valor[1].equals("27"))
                            {
                                json.updateAttr("segments.common.bit63", "00020101021226720014br.gov.bcb.pix2550bx.com.br/pix/8b3da2f3-9a41-40d1-a91a-bd93113bd4415204000053039865406123.455802BR5913Fulano de Tal62190515RP12345678-2019630445C8");
                            }
                            if (valor[1].equals("28"))
                            {
                                json.updateAttr("segments.common.bit63", "00020101021226230014br.gov.bcb.pix2550b5204000053039865406123.455802BR5901F6001B62050501R630445C8");
                            }
                            
                            if (valor[1].equals("85"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "42");
                                json.updateAttr("segments.common.bit63", "PV SEM CHAVE PIX CADASTRADA");
                            }
                            if (valor[1].equals("01"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", "asdfjg42odfn3rk3asASDNfkdasdfjg42odf");
                            }
                            if (valor[1].equals("77"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "77");
                                json.updateAttr("segments.common.bit63", "");
                            } 
                    if (valor[1].equals("98"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", " ");
                            }
                    if (valor[1].equals("96"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", "912345678912345");
                            }
                            if (valor[1].equals("97"))
                            {
                                json.updateAttr("shc_msg.alpha_response_code", "00");
                                json.updateAttr("segments.pix.requestIdPix", "");
                            }




                         }   
                         
            }
        


        } catch (Exception  ex) {
            System.out.println("\n\nNão foi possível encontrar um dos valores: " + ex.getMessage());
            ex.printStackTrace();
        }

        }

        public String getResponse(){
                if (JSONServerGSON.flag)
                    return json.toString();
                else
                    return "";
        }
}

class SocketServer {

    public void startSocket(int port){

        try (ServerSocket serverSocket = new ServerSocket(port)) {

            System.out.println("Server is listening on port " + port);

            while (true) {

            }

        } catch (IOException ex) {
            System.out.println("Server exception: " + ex.getMessage());
            ex.printStackTrace();
        }

    }


}

class SocketServerHandle {

    public void startSocket(int port){
     
        try (ServerSocket serverSocket = new ServerSocket(port)) {

            System.out.println("Server is listening on port " + port);

            while (true) {
            
                Socket socket = serverSocket.accept();
                System.out.println("New client connected");

                socket.setKeepAlive(true);
                socket.setTcpNoDelay(true);
                socket.setPerformancePreferences(10,11,11);
                socket.setReceiveBufferSize(50000);
                socket.setSendBufferSize(50000);
                socket.setTrafficClass(255);

                PrintWriter writer = new PrintWriter(socket.getOutputStream());

                int dataBuffer;
                int count125 = 0;

                String json = "";
                
                while ((dataBuffer = socket.getInputStream().read()) != -1)
                {
                    System.out.print((char) dataBuffer);

                    json += (char) dataBuffer;

                    // }}} 125 125 125
                    if (dataBuffer==125) count125++;
                    else count125 = 0;

                    if (count125==3)
                    {
                        count125 = 0;
                        System.out.print(json);

                        //pega a mensagem do tunel
                        String pixMessage = removeTPDU(json);

                        //envia para o construtor de respostas
                        BuildResponse response = new BuildResponse(pixMessage);

                        //imprime a saída do construtor de respostas
                        System.out.println( "\n\n\nSaida para o Tunel (sem TPDU):\n" + ( response.getResponse() ) );
                        System.out.println( "\n\n\nSaida para o Tunel:\n" + includeTPDU( response.getResponse() ) );
                        writer.write(
                                        includeTPDU
                                (
                                                        response.getResponse()
                                                )
                                );
                        writer.flush();
                        System.out.println("Lenght: " + response.getResponse().length() );

                        json = "";
                    }

                }

                socket.close();
                
            }
             
        } catch (IOException ex) {
            System.out.println("Server exception: " + ex.getMessage());
            ex.printStackTrace();
        }
     
    }
    
    public String removeTPDU(String message){
        return message.substring(2,message.length());
    }

    public String includeTPDU(String message){
        String tpdu = ""; // tamanho 13000 / Binary 00110010 11001000
 
        if (JSONServerGSON.flag)
            tpdu = decoupleBinary16ToChar( message.length() );

        return tpdu + message;
    }

    public String decoupleBinary16ToChar(int number){

        // packt size 3000
        // 00000001 011001111 --> Integer.toHexString(1343) --> 7ec --> 0c 23

        String chainChar = "";

        String origString = Integer.toBinaryString(number);

        int mod = origString.length()%8;
        if (mod >= 1){
                for (int i = 0; i <= 8 - mod; i++)
                        origString = "0" + origString; //padding with left zeroes
        }
        System.out.println("\n\n\n\nPacket Size em binário: " + origString + "\n\n\n");

        String result = "";
        for (int j=origString.length(); j>1; j=j-8){
                result = origString.substring(j-8,j);
                char c = (char) Integer.parseInt(result, 2);
                chainChar = c + chainChar;
        }

        return chainChar;
    }

}


class ServerThread extends Thread {
    private Socket socket;
 
    public ServerThread(Socket socket) {
        this.socket = socket;
    }
 
    public void run() {
        try {
            
            PrintWriter writer = new PrintWriter(socket.getOutputStream());

            int dataBuffer;
            int count125 = 0;

            String json = "";
            
            while ((dataBuffer = socket.getInputStream().read()) != -1)
            {
                System.out.print((char) dataBuffer);

                json += (char) dataBuffer;

                // }}} 125 125 125
                if (dataBuffer==125) count125++;
                else count125 = 0;

                if (count125==3)
                {
                    count125 = 0;
                    System.out.print(json);

                    //pega a mensagem do tunel
                    String pixMessage = removeTPDU(json);

                    //envia para o construtor de respostas
                    BuildResponse response = new BuildResponse(pixMessage);

                    //imprime a saída do construtor de respostas
                    System.out.println( "\n\n\nSaida para o Tunel (sem TPDU):\n" + ( response.getResponse() ) );
                    System.out.println( "\n\n\nSaida para o Tunel:\n" + includeTPDU( response.getResponse() ) );
                    writer.write(
                                    includeTPDU
                            (
                                                    response.getResponse()
                                            )
                            );
                    writer.flush();
                    System.out.println("Lenght: " + response.getResponse().length() );

                    json = "";
                }

            }
        
            socket.close();
            
        } catch (IOException ex) {
            System.out.println("Server exception: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    public String removeTPDU(String message){
        return message.substring(2,message.length());
    }

    public String includeTPDU(String message){
        String tpdu = ""; // tamanho 13000 / Binary 00110010 11001000
 
        if (JSONServerGSON.flag)
            tpdu = decoupleBinary16ToChar( message.length() );

        return tpdu + message;
    }

    public String decoupleBinary16ToChar(int number){

        // packt size 3000
        // 00000001 011001111 --> Integer.toHexString(1343) --> 7ec --> 0c 23

        String chainChar = "";

        String origString = Integer.toBinaryString(number);

        int mod = origString.length()%8;
        if (mod >= 1){
                for (int i = 0; i <= 8 - mod; i++)
                        origString = "0" + origString; //padding with left zeroes
        }
        System.out.println("\n\n\n\nPacket Size em binário: " + origString + "\n\n\n");

        String result = "";
        for (int j=origString.length(); j>1; j=j-8){
                result = origString.substring(j-8,j);
                char c = (char) Integer.parseInt(result, 2);
                chainChar = c + chainChar;
        }

        return chainChar;
    }
}