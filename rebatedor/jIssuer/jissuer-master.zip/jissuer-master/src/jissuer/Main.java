/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jissuer;

import java.net.*;  // for Socket, ServerSocket, and InetAddress
import java.io.*;   // for IOException and Input/OutputStream
import isofw.*;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

/**
 *
 * @author Renato
 */
public class Main {

    private static String driver_log = "";
    private static String Port = "";
    private static String script_dir = "";
    private static String response_script = "";
    private static String mCFGfile = "";
    private static String jIssuer = "jIssuer v3.1.1 - 26/06/2018 - @%d - Copyright rcamargo\n";
    private static ISO8583 iso8583 = ISO8583.getInstance();
    private static String mDirectory = ".";
    private static final int BUFSIZE = 4096;   // Size of receive buffer
    private static ServerSocket servSock;
    private static Socket clntSock;
    public static LogFile mlog;
    private static boolean _debug = false;
    private static boolean mExecutePosScriptCommand = false;
    private static boolean mAbortNonZeroScriptRespCode = false;    
    private static final String jISSUERCMD = "JISSUERCMD";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, IOException, NoSuchFieldException, IllegalArgumentException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        long PID = Util.getPID();
        System.out.printf(jIssuer,PID);        
        if (args.length > 0) {
            for (int i = 0; i < args.length; i++) {
                switch (args[i].charAt(0)) {
                    case '-': {
                        String parameter = args[i].substring(2, args[i].length());
                        switch (Character.toUpperCase(args[i].charAt(1))) {
                            case 'P': {
                                Port = args[i].substring(2, args[i].length());
                                break;
                            }
                            case 'L': {  // Issuer Log
                                driver_log = args[i].substring(2, args[i].length());
                                break;
                            }
                            case 'D': {  // Script Dir
                                script_dir = args[i].substring(2, args[i].length());
                                break;
                            }
                            case 'S': {  // Response Script
                                response_script = args[i].substring(2, args[i].length());
                                break;
                            }
                            case 'C': {  // Config File
                                RunCFGFile(args[i].substring(2, args[i].length()));
                                break;
                            }
                            case 'F': {
                               if ( args[i].charAt(1) == 'F' ) {
                                    SetDirectory(args[i].substring(2, args[i].length()));
                                    break;
                               }
                               else {
                                    for ( int c = 0; c < parameter.length(); c++) {
                                        if( parameter.toUpperCase().charAt(c) == 'A') {
                                             mAbortNonZeroScriptRespCode = true;
                                             if( _debug )
                                                 System.out.println( "AbortifNonZeroPosCommandScript = ON");
                                        }
                                        if( parameter.toUpperCase().charAt(c) == 'S') {
                                             mExecutePosScriptCommand = true;
                                             if( _debug )
                                                 System.out.println( "ExecuteGeneralPosCommandScript = ON");                                        
                                        }
                                    }
                               }
                               break;
                            }                            
                            case 'V': {
                                _debug = true;
                                break;
                            }
                            default: {
                                System.err.print("Unknown Parameter !!!\n");
                                Sintaxe();
                                System.exit(1);
                                break;
                            }
                        }
                    }
                }
            }
        } else {
            Sintaxe();
            System.exit(1);
        }
        if (Port.length() == 0 || response_script.length() == 0 && mCFGfile.length() == 0) {
            Sintaxe();
            System.exit(0);
        }

        Run();

        System.err.println("\nbye");
        System.exit(0);
    }
    
    public static void RunCFGFile(String larq) throws FileNotFoundException, IOException {
        if (_debug) {
            System.out.println("Config File = " + larq);
        }
        mCFGfile = larq;
        iso8583.LoadISO8583Profile(larq, mDirectory, _debug);
    }

    public static void SetDirectory(String dir) {
        if (_debug) {
            System.out.println("Directory = " + dir);
        }
        iso8583.setDataDirectory(dir);
        mDirectory = dir;
    }    

    public static void Sintaxe() {
        System.err.println("Sintaxe : jIssuer -P<Port> -L<LOG File> -C<Config File> -D<Script Dir> -F<Datafile Dir> -S<Script> -V");
        System.err.println("      -P<Port>           - Issuer Port");
        System.err.println("      -C<Config File>    - Config File");
        System.err.println("      -L<LogFile>        - LOG File");
        System.err.println("      -D<Script Dir>     - Script Directory");
        System.err.println("      -F<Datafile Dir>   - DataFile Directory");
        System.err.println("      -S<Script>         - Script");
        System.err.println("      -f<flags>          - Flags to modify workflow of execution");
        System.err.println("                           -fa => abort if a PosScript Command return a Non Zero Status");
        System.err.println("                           -fs => execute a generic PosScript Command setted by environment Variable <" + jISSUERCMD + ")" );
        System.err.println("      -V                 - Verbose (debug info)");
    }

    @SuppressWarnings("static-access")
    public static void Run() throws InterruptedException, IOException {
        mlog = new LogFile(driver_log);

        IssuerProcessor mIssuerProcessor = new IssuerProcessor(mCFGfile, mDirectory, _debug);

        mIssuerProcessor.SetScritDir(script_dir);
        mIssuerProcessor.SetResponseScript(response_script);
        mIssuerProcessor.AddRawVariable("_SCRIPTDIR", script_dir);
        mIssuerProcessor.AddRawVariable("_RESPONSESCRIPT", response_script);
        mIssuerProcessor.AddRawVariable("_CONFIGFILE", mCFGfile);
        mIssuerProcessor.AddRawVariable("_DATADIR", mDirectory);        

        int recvMsgSize, sentMsgSize;   // Size of received e sent message
        byte[] rcvdBuffer = new byte[BUFSIZE];  // Receive buffer
        byte[] sentBuffer = new byte[BUFSIZE];  // Sent buffer

        // Get name and IP address of the local host
        try {
            InetAddress address = InetAddress.getLocalHost();
            mlog.println("Localhost: " + address.getHostName() + " : " + address.getHostAddress());
            mIssuerProcessor.AddVariable("_IP", address.getHostAddress() );
        } catch (UnknownHostException e) {
            mlog.println("Unable to determine this host's address");
        } catch (IOException exc) {
            mlog.println(exc.getMessage());
        }
        mIssuerProcessor.AddVariable("_PORT", Port );
        mlog.log("Listening port [" + Port + "]");
        mIssuerProcessor.AddVariable("_STARTTIME", Util.getTimeStamp().trim() );

        try {
            // Create a server socket to accept client connection requests
            servSock = new ServerSocket(Integer.parseInt(Port));
        } catch(IOException exc) {
            mlog.println(exc.getMessage());
            return;
        }
        int ix = 0;
        int connix = 0;
        for (;;) { // Run forever, accepting and servicing connections
            try {
               clntSock = servSock.accept();     // Get client connection
             } catch(IOException exc) {
                mlog.println(exc.getMessage());
                return;
             }
            mlog.println("New Connection at " + clntSock.getInetAddress().getHostAddress() + " on port " + clntSock.getPort() + " at " + Util.getTimeStamp());
            mIssuerProcessor.AddVariable("_CONNECTIONSEQ", ++connix);
            InputStream in = clntSock.getInputStream();
            OutputStream out = clntSock.getOutputStream();

            try {
                // Receive until client closes connection, indicated by -1 return
                while ((recvMsgSize = in.read(rcvdBuffer)) != -1) {
                    String receiveTime = Util.getTimeStamp();
                    long receiveTimeL = System.currentTimeMillis();
                    mIssuerProcessor.AddVariable("_RECEIVETIME", receiveTime.trim() );
                    mIssuerProcessor.AddVariable("_RCVDBUFFER", Util.Bytes2HEX(rcvdBuffer, recvMsgSize) );
                    mIssuerProcessor.AddVariable("_SENTBUFFER", "NULL");
                    mIssuerProcessor.AddVariable("_SENDTIME", "NULL");
                    mIssuerProcessor.AddVariable("_MSGETIME", "NULL" );  
                    mlog.println("Received [" + recvMsgSize + "] bytes");
                    mlog.println(receiveTime + Util.creplicate("-",56));
                    
                    mIssuerProcessor.AddVariable("_MSGSEQ", ++ix);

                    if( iso8583.getFormat().equals("EBCDIC") || iso8583.getFormat().equals("BCD-V"))
                        Util.Dump_EBCDIC(rcvdBuffer, recvMsgSize);
                    else
                        Util.Dump2(rcvdBuffer, recvMsgSize);

                    sentBuffer = mIssuerProcessor.Process(rcvdBuffer, recvMsgSize);
                    sentMsgSize = mIssuerProcessor.GetBufferSize();

                    if ( sentMsgSize > 0 ) {
                        out.write(sentBuffer, 0, sentMsgSize );
                        String sendTime = Util.getTimeStamp();
                        long sendTimeL = System.currentTimeMillis();
                        
                        mIssuerProcessor.AddVariable("_SENTBUFFER", Util.Bytes2HEX(sentBuffer, sentBuffer.length) );
                        mIssuerProcessor.AddVariable("_SENDTIME", sendTime.trim() );
                        mIssuerProcessor.AddVariable("_MSGETIME", sendTimeL - receiveTimeL );                    
                        
                        mlog.println("Sent [" + sentMsgSize + "] bytes");
                        mlog.println(sendTime + Util.creplicate("-",56));
                        if( iso8583.getFormat().equals("EBCDIC") || iso8583.getFormat().equals("BCD-V"))
                            Util.Dump_EBCDIC(sentBuffer, sentMsgSize);
                        else
                            Util.Dump2(sentBuffer, sentMsgSize);                                
                        iso8583.decode(sentBuffer, sentMsgSize,true);
                    } else {
                        mlog.println("*** NO DATA TO SEND ***" );
                    }
                    
                    if( mExecutePosScriptCommand ) {
                        String cmdline = jposFunc.GetEnv_func( jISSUERCMD );
                        if( cmdline != null &&  cmdline.length() > 0 && !cmdline.isEmpty() && !cmdline.equals(""))
                            mIssuerProcessor.addPosCommand( "!" + cmdline);
                        else
                            System.out.println( "WARNING: General PosScript Command not executed because " + jISSUERCMD + " not setted" );
                    }

                    ArrayList<String> Commands = mIssuerProcessor.getPosCommand();
                    for (int iCommands = 0; iCommands < Commands.size(); iCommands++) {
                        if( _debug )
                            System.out.printf ( "...\nPosScript Command[%s]\n", Commands.get(iCommands) );
                        if ( Commands.get(iCommands).charAt(0) == '!' )
                        {
                            String CommandLine = jposFunc.IssuerResponseField_func(Commands.get(iCommands).substring(1));

                            System.out.printf ( "-----------------------------------------------------------------------------------------------------\n");
                            mIssuerProcessor.AddVariable("_LASTCMDSTART", Util.getTimeStamp());
                            long startTime = System.currentTimeMillis();
                            int respCode = jposFunc.RunCommand(CommandLine);
                            mIssuerProcessor.AddVariable("_LASTCMDEND", Util.getTimeStamp());
                            long estimatedTime = System.currentTimeMillis() - startTime;
                            mIssuerProcessor.AddVariable("_LASTCMDETIME", estimatedTime );
                            System.out.printf ( "-----------------------------------------------------------------------------------------------------\n");
                            mIssuerProcessor.AddVariable("_LASTCMDSTATUS", respCode );
                            mIssuerProcessor.AddRawVariable("_LASTCMD", CommandLine);
                            if ( mAbortNonZeroScriptRespCode && respCode != 0 )
                            {
                                System.out.printf("Execution aborted !!!  PosCommad Script [%s], returned [%d]\n",CommandLine,respCode);
                                System.exit(1);
                            }
                        }
                    }
                    mIssuerProcessor.ClearCommands();
                    if( _debug )
                        mIssuerProcessor.PrintAllVariables();
                }
                mlog.println( "Disconnect at " + Util.getTimeStamp());
            } catch (IOException e) {
                mlog.println(e.getMessage());
                mlog.println(Util.creplicate("-",80));
            }
            clntSock.close();  // Close the socket.  We are done with this client!
            
        }
    }
}
