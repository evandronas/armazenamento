cd "/c/Users/renat/Dropbox/Fontes/test"

DATADIR="/c/Users/renat/Dropbox/Fontes/test/issuer_script/"
DATADIR="C:\\Users\Renat\\Dropbox\\Fontes\\test\\issuer_script\\"
FILEDIR="C:\\Users\Renat\\Dropbox\\Fontes\\test\\datafile\\"
PORTA=6666

if [[ "${1}" == "MCI" ]]; then
	CFGFILE="cfg/jMCI.cfg"
	INITSCRIPT="mci.jIssuer"
fi

if [[ "${1}" == "POS" ]]; then
	CFGFILE="cfg/jPOS.cfg"
	INITSCRIPT="pos.jIssuer"
fi

if [[ "${1}" == "POO" ]]; then
	CFGFILE="cfg/jPOO.cfg"
	INITSCRIPT="pos.jIssuer"
fi

if [[ "${1}" == "POSIP" ]]; then
	CFGFILE="cfg/jPOSIP.cfg"
	INITSCRIPT="pos.jIssuer"
fi

if [[ "${1}" == "PDV" ]]; then
	CFGFILE="cfg/jPDVinac.cfg"
	INITSCRIPT="pdv.jIssuer"
fi

if [[ "${1}" == "TKCH" ]]; then
	CFGFILE="cfg/jTKCHIP.cfg"
	INITSCRIPT="tkchip.jIssuer"
fi

if [[ "${1}" == "VISA" ]]; then
	CFGFILE="cfg/jVISA.cfg"
	INITSCRIPT="visa.jIssuer"
fi

if [[ "${1}" == "AMEX" ]]; then
	CFGFILE="cfg/jAMEX.cfg"
	INITSCRIPT="amex.jIssuer"
fi

if [[ "${1}" == "ELO" ]]; then
	CFGFILE="cfg/jELO.cfg"
	INITSCRIPT="elo.jIssuer"
fi

if [[ "${1}" == "ALELO" ]]; then
	CFGFILE="cfg/jAlelo.cfg"
	INITSCRIPT="alelo.jIssuer"
fi

if [[ "${1}" == "DINERS" ]]; then
	CFGFILE="cfg/jDiners.cfg"
	INITSCRIPT="dv.jIssuer"
fi

if [[ "${1}" == "GREENCARD" ]]; then
	CFGFILE="cfg/jDV.cfg"
	INITSCRIPT="dv.jIssuer"
fi

if [[ "${1}" == "VOUCHER" ]]; then
	CFGFILE="cfg/jVoucher.cfg"
	INITSCRIPT="voucher.jIssuer"
fi

if [[ "${1}" == "SERASA" ]]; then
	CFGFILE="cfg/jHOST.cfg"
	INITSCRIPT="host.jIssuer"
fi

if [[ "${1}" == "RAV" ]]; then
	CFGFILE="cfg/jHOST.cfg"
	INITSCRIPT="host.jIssuer"
fi

if [[ "${1}" == "QRCODE" ]]; then
	CFGFILE="cfg/jWQ3.cfg"
	INITSCRIPT="wq3.jIssuer"
fi

if [[ "${1}" == "ITI" ]]; then
	CFGFILE="cfg/jWQ3.cfg"
	INITSCRIPT="wq3.jIssuer"
fi

java -jar "C:\Users\renat\Documents\NetBeansProjects\jIssuer\dist\jIssuer.jar" -C${CFGFILE} -P${PORTA} -F${FILEDIR} -D${DATADIR} -S${INITSCRIPT} -fs ${2} 