﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Newtonsoft.Json;
namespace proxy_commons
{
    /// <summary>
    /// Classe util que implementa o dialeto REST/HTTP 
    /// </summary>
    public class Requests
    {
        /// <summary>
        /// Executa GET na API REST
        /// </summary>
        /// <typeparam name="T">Objeto que será deserializado</typeparam>
        /// <param name="host">Endereço do host API</param>
        /// <param name="port">Número da porta do host da API</param>
        /// <param name="path">Nome do recurso a ser consumido</param>
        /// <param name="parameters">Parametros de pesquisa</param>
        /// <param name="timeoutMinutes">Tempo limite de execução do request na API REST</param>
        /// <returns>Retorna tipo T deserializado</returns>
        public static T ExecuteGet<T>(string host, int port, string path, List<KeyValuePair<string, string>> parameters = null, int timeoutMinutes = 5)
        {
            using (HttpClient client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(timeoutMinutes);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                UriBuilder uriBuilder = new UriBuilder() { Host = host, Port = port, Path = path };
                var uri = GetQueryParams(uriBuilder, parameters);
                Task<HttpResponseMessage> response = client.GetAsync(uri, HttpCompletionOption.ResponseContentRead);

                if (response.Result.IsSuccessStatusCode)
                {
                    var result = response.Result.Content.ReadAsStringAsync().Result;
                    T obj = DeserializeObject<T>(result);
                    return obj;
                }
                throw new Exception(string.Format("Response Status: {0}; Content: {1}", response.Result.StatusCode, response.Result.Content));
            }
        }

        /// <summary>
        /// Executa PUT na Api REST
        /// </summary>
        /// <typeparam name="T">Objeto que será deserializado</typeparam>
        /// <param name="host">Endereço do host API</param>
        /// <param name="port">Número da porta do host da API</param>
        /// <param name="path">Nome do recurso a ser consumido</param>
        /// <param name="body">objeto que será enviado para API</param>
        /// <param name="timeoutMinutes">Tempo limite de execução do request na API REST</param>
        /// <returns>Retorna tipo T deserializado</returns>
        public static T ExecutePut<T>(string host, int port, string path, object body, int timeoutMinutes = 5)
        {
            using (HttpClient client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(timeoutMinutes);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                UriBuilder uriBuilder = new UriBuilder() { Host = host, Port = port, Path = path };
                string json = SerializeObject(body);
                HttpContent httpContent = new StringContent(json, Encoding.Unicode, "application/json");
                Task<HttpResponseMessage> response = client.PutAsync(uriBuilder.Uri, httpContent);
                
                if (response.Result.IsSuccessStatusCode)
                {
                    var result = response.Result.Content.ReadAsStringAsync().Result;
                    T obj = DeserializeObject<T>(result);
                    return obj;
                }
                throw new Exception(string.Format("Response Status: {0}; Content: {1}", response.Result.StatusCode, response.Result.Content));
            }
        }

        /// <summary>
        /// Deserializa JSON String para objeto dto especificado em T
        /// </summary>
        /// <typeparam name="T">Tipo do objeto a ser deserializado</typeparam>
        /// <param name="json">JSON string de retorno</param>
        /// <returns>Retorna Objeto deserializado</returns>
        private static T DeserializeObject<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json, GetJsonDeserializeSettings());
        }

        /// <summary>
        /// Serializa objeto dto para JSON String
        /// </summary>
        /// <param name="body">Objeto Dto</param>
        /// <returns>JSON String</returns>
        private static string SerializeObject(object body)
        {
            var jsonString = string.Empty;
            try
            {
                jsonString = JsonConvert.SerializeObject(body, Formatting.Indented, GetJsonSerializerSettings());
            }
            catch (JsonSerializationException ex)
            {
                //Logger error
            }
            return jsonString;
        }

        /// <summary>
        /// Configuração de serialização do objeto para JSON string
        /// </summary>
        /// <returns>Retorna as configurações de serialização do JSON</returns>
        private static JsonSerializerSettings GetJsonSerializerSettings()
        {
            var jsonSerializerSettings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore,
                DateTimeZoneHandling = DateTimeZoneHandling.Utc
            };

            return jsonSerializerSettings;
        }

        /// <summary>
        /// Configuração de deserialize do objeto para object T
        /// </summary>
        /// <returns>Retorna as configurações de deserialização do JSON</returns>
        private static JsonSerializerSettings GetJsonDeserializeSettings()
        {
            var jsonDeserializeSettings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                DateFormatString = "yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'"
            };

            return jsonDeserializeSettings;
        }

        /// <summary>
        /// Gera parametros+valores da url
        /// </summary>
        /// <param name="uriBuilder">Objeto que contém o valor da url</param>
        /// <param name="parameters">Objeto chave valor que contém os dados para pesquisa</param>
        /// <returns>Uri com os parametros de pesquisa compilados</returns>
        private static Uri GetQueryParams(UriBuilder uriBuilder, List<KeyValuePair<string, string>> parameters)
        {
            if (parameters != null && parameters.Count > 0)
            {
                var query = HttpUtility.ParseQueryString(uriBuilder.Query, Encoding.Unicode);
                foreach (KeyValuePair<string, string> param in parameters)
                {
                    query[param.Key] = param.Value;
                }
                uriBuilder.Query = query.ToString();
            }
            return uriBuilder.Uri;
        }
    }
}