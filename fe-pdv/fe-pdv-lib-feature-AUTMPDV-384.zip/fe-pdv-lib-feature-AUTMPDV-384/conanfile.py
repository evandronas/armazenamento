from conans import ConanFile, tools

class ResolveDependency(ConanFile):
    settings = "os", "compiler", "build_type", "arch"
    description = "Generic library for usage in online repos"
    url = "http://gitlab.prd.useredecloud/SW7/autorizador/aplicacao/online/libs/fe-pdv-lib"
    license = "None"
    author = "RT Autorizador"
    topics = ("sw7", "online", "lib")

    def package(self):
        self.copy("*", src="dist/lib", dst="lib")
        self.copy("*", src="dist/include", dst="include")

    def package_info(self):
        self.cpp_info.libs = tools.collect_libs(self)
