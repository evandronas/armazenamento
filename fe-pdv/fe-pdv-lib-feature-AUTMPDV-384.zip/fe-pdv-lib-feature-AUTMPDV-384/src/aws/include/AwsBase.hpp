/*
* Copyright 2020 REDE
*
* Commom base of Internal AWS library
*/

#include <aws/core/Aws.h>


namespace internalAws {

    /**
     Class which provides common base of AWS library
    */
    class Base {
    public:
        /**
         * Get singleton's instance.
         * @return The intance.
         */
        static Base * GetInstance();

        /**
         * Read the region where EC2 instance is running.
         * @return The AWS region.
         */
        Aws::String GetRegion();

        /**
         * Read the AZ where EC2 instance is running.
         * @return The AWS AZ.
         */
        Aws::String GetAZ();

    private:
        static Base * instance;
        Base();
        ~Base();
    };
}
