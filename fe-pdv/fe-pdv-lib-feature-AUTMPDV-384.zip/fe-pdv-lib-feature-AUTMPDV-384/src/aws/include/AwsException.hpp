#pragma once
#include <exception>
#include <iostream>
#include <string>

namespace internalAws {
namespace exception {
	class AwsException : public std::exception
	{
        std::string exceptionmsg;
        public:
            AwsException(const std::string& msg) : exceptionmsg(msg) {}

            virtual const char* what() const noexcept override
            {
                return exceptionmsg.c_str();
            }
	};
} // namespace exception
} // namespace internalAws
