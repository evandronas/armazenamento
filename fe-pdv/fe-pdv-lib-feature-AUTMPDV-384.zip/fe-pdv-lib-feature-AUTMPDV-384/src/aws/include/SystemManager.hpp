/**
* Copyright 2020 REDE
*
* Internal AWS library which allow access to AWS System Manager
*/

#include <string>
#include "logger/Logger.hpp"


namespace internalAws {
namespace ssm {

    /**
     Class which provides access to AWS System Manager
    */
    class SystemManager {
    public:
        SystemManager();
        ~SystemManager();

        /**
         * Read parameter content stores on Parameter Store from System Manager.
         * @param name The parameter's name.
         * @return A string if parameter exists otherwise empty string.
         */
        std::string GetParameterStore(const char * name);

    private:
        logger::Logger * logger;
    };

} // namespace ssm
} // namespace internalAws
