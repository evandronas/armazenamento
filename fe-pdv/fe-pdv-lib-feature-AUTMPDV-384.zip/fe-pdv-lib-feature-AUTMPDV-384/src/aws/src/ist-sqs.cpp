/*----------------------------------------------------------------------------
FNome : sqsaws.cpp
Objetivo : Driver SQS
----------------------------------------------------------------------------*/
static char ver[]="    ";

#include <aws/core/Aws.h>
#include <aws/sqs/SQSClient.h>
#include <aws/sqs/model/SendMessageRequest.h>
#include <aws/sqs/model/SendMessageResult.h>
#include <aws/sqs/model/GetQueueUrlRequest.h>
#include <aws/sqs/model/GetQueueUrlResult.h>
#include <aws/sqs/model/ReceiveMessageRequest.h>
#include <aws/sqs/model/ReceiveMessageResult.h>
#include <aws/sqs/model/DeleteMessageRequest.h>

#include <stdio.h>
#include <signal.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <string>
#include <sys/timeb.h>
#include <sys/time.h>
#include <mb.h>
#include <ist4.h>
#include <ist_types.h>
#include <ist_gps.h>
#include <debug.h>
#include <ist_otrace.h>
#include <ist_argv0.h>
#include <string>
#include <iostream>

#define debugon	1
#define	MAX_MSG_LEN				    50000
#define TIME_SLEEP_PROCESS          5*60 // 5 MINUTOS

#define MB_INPUT_REQ   1
#define MB_INPUT_RESP  2

int			  PortId = -1;
pid_t         pid_read_sqs = 0;
char		  ServerName[MB_MAX_NAME+1]={ 0 };
int     	  MyMbId = 0;
int     	  OrigMbId = 0;
struct mbport *MbPortP = NULL;
int           destionationType = 0;

char		  SQSName[MB_MAX_NAME+1] = {0};       /* local queue manager              */
char 		  QInputName[MB_MAX_NAME+1] = {0};
char 		  QOutputName[MB_MAX_NAME+1] = {0};
FILE*         logTcp = NULL;

std::string timeval2TimeStamp( struct timeval *tv ) {
    char buf[30] = {0};
    size_t sz = sizeof(buf);
    ssize_t written = -1;
    std::string result = "";

    struct tm *gm = gmtime(&tv->tv_sec);

    if (gm)
    {
        written = (ssize_t)strftime(buf, sz, "%Y-%m-%d %H:%M:%S", gm);
        if ((written > 0) && ((size_t)written < sz))
        {
            int w = snprintf(buf+written, sz-(size_t)written, ".%06dZ", tv->tv_usec);
            written = (w > 0) ? written + w : -1;
        }
        result = buf;
    }
    return result;
}

long timediffmicro(struct timeval start) {
    struct timeval now;

    gettimeofday( &now, 0 );
    float diff = (float) ((now.tv_sec - start.tv_sec) * 1000000 + ((int)now.tv_usec - (int)start.tv_usec));
    long etime = diff;
        
    return etime;
}

std::string getFullTimeStamp() {
    static char buffer[256];
    struct tm date;
    struct timeval tv;
    std::string timestamp;

    gettimeofday(&tv, 0);
    localtime_r(&tv.tv_sec, &date);
    snprintf(buffer, sizeof(buffer), "%.4d-%.2d-%.2d %.2d:%.2d:%.2d.%06d",
            date.tm_year + 1900,
            date.tm_mon + 1,
            date.tm_mday,
            date.tm_hour,
            date.tm_min,
            date.tm_sec,
            int(tv.tv_usec));
    timestamp = buffer;
    return timestamp;
}

void LogTcpMsg( char *inOut, char *tcpBuffer, int bufferLen ) {
    struct tm date;
    struct timeval tv;

    gettimeofday(&tv, 0);
    localtime_r(&tv.tv_sec, &date);    
    fprintf(logTcp,"%04d/%02d/%02d %02d:%02d:%02d.%03d %1s %s %-*s\n",
        date.tm_year + 1900,
        date.tm_mon + 1,
        date.tm_mday,
        date.tm_hour,
        date.tm_min,
        date.tm_sec,
        int(tv.tv_usec/1000),
        SQSName,
        inOut, 
        bufferLen, 
        tcpBuffer);
    fflush(logTcp);
}

void SQSExit( int n ) {
	static char 	FnDesc[]="SQSExit";
	int				pid=-1;
	
	syslg("%s: signal %d received\n",FnDesc, n);
	ODebug("%s: signal %d received\n",FnDesc, n);
	if ( pid_read_sqs > 0 )	{
		syslg("Secund[%d]: signal %d received\n",pid_read_sqs, n);
	    kill(pid_read_sqs,n);
	} else {
        if ( pid_read_sqs == 0 ) {
            syslg("Sending Signal to Parent too [%d=>%d]\n", getpid(), getppid());
            kill(getppid(),SIGTERM);	/* If Child is killed, kill parent too */
        }
	}
	if(n == SIGALRM){
		signal(n, SQSExit);
		return;
	}

    if ( MbPortP ) {
        MbPortP->flags &= ~MB_PORT_CONNECTED;
    }
	if (logTcp) {
        fclose(logTcp);
    }
    OTraceOff();
    exit(n);                
}

int SQSInitiliaze ( char *portname ) {       
    static char FnDesc[]="SQSInitiliaze";
    char		lbuf[1024] = {0};
    char        destination[100] = {0};

    memset( lbuf, 0, sizeof lbuf ); 
    memset( SQSName, 0, sizeof SQSName );
    memset( QInputName, 0, sizeof QInputName );
    memset( QOutputName, 0, sizeof QOutputName );
    PortId = mb_locateport(portname);
    if ( PortId == -1 ) {
        syslg("fail to locate port: %s\n",portname);
        ODebug("fail to locate port: %s\n",portname);
        return IST_RET_ERR;
    }

    printf("PortID [%d]\n",PortId);
    MbPortP = mb_getportentry(PortId);

    strcpy( ServerName, mbMailBoxName(MbPortP->serverid) );

    strcpy( lbuf, MbPortP->address.a.address   );
    strtok( lbuf,":" );
    strcpy( SQSName, "SQS-AWS" );

    strcpy( QInputName, lbuf );
    if ( !strcmp( QInputName, "Null" ) )
        memset( QInputName, 0, sizeof QInputName );

    strcpy( QOutputName,strtok( NULL,":" )     );
    if ( !strcmp( QOutputName, "Null" ) )
        memset( QOutputName, 0, sizeof QOutputName );

    strcpy( destination,strtok( NULL,":" )     );
    if ( !strcmp( destination, "request" ) ) {
        destionationType = MB_INPUT_REQ;
    } else {
        destionationType = MB_INPUT_RESP;
    }

    MyMbId = mb_locatemailbox( portname );
    if ( MyMbId < 0 ) {
        sleep(2);
        return IST_RET_ERR;
    }

	if((mb_locateoutbound(ServerName)) < 0) { 
		// Outbound mailbox not found:
		//      1. Create it;
		//      2. Duplicate it;
		//      3. Find outbound.
		if(mb_duplicatemailbox( mb_locatemailbox(ServerName)) < 0 ) {
            syslg("Failed to Duplicate Mailbox");
            sleep(2);
            return IST_RET_ERR;
        }

		if((mb_locateoutbound(ServerName)) < 0) {
            syslg("Failed to Duplicate Mailbox");
            sleep(2);            
		    return IST_RET_ERR;
        }
        syslg("Creating mailbox for %s -> (%d:%d)\n", ServerName, mb_locatemailbox( ServerName ),mb_locateoutbound(ServerName));
	}
    char ConfigurationPath[128] = {0};
    sprintf(ConfigurationPath,"%s/log/sys/log%s.log", getenv("OSITE_ROOT"), portname );

    if(( logTcp = fopen( ConfigurationPath, "a" )) == NULL ) {
        syslg("Cannot open SQS LOG [%s] for port [%s]. Working without LOG\n", portname );
        sleep(2);
        return IST_RET_OK;
    }

    OTraceDebug("QManager: %s\n"       , SQSName                            );
    OTraceDebug("InputQueue: %s\n"     , QInputName                         );
    OTraceDebug("OutputQueue: %s\n"    , QOutputName                        );
    OTraceDebug("ServerName: %s\n"     , mbMailBoxName( MbPortP->serverid ) );
    OTraceDebug("ClientName: %s\n"     , mbMailBoxName( MyMbId )            );
    OTraceDebug("LogName: %s\n"        , ConfigurationPath                  );
    OTraceDebug("Mailbox Port : %d\n", mb_locatemailbox(portname)           );
    OTraceDebug("Mailbox In  : %d\n", mb_locatemailbox(ServerName)        );
    OTraceDebug("Mailbox Out  : %d\n", mb_locateoutbound(ServerName)        );
    OTraceDebug("Destination MB : %s\n", destination );
    OTraceDebug("Compiled on %s %s\n", __DATE__, __TIME__);
    syslg("QManager: %s\n"       , SQSName                            );
    syslg("InputQueue: %s\n"     , QInputName                         );
    syslg("OutputQueue: %s\n"    , QOutputName                        );
    syslg("ServerName: %s\n"     , mbMailBoxName( MbPortP->serverid ) );
    syslg("ClientName: %s\n"     , mbMailBoxName( MyMbId )            );
    syslg("LogName: %s\n"        , ConfigurationPath                  );
    syslg("Mailbox Port : %d\n", mb_locatemailbox(portname)           );
    syslg("Mailbox Out  : %d\n", mb_locateoutbound(ServerName)        );
    syslg("Mailbox In  : %d\n", mb_locatemailbox(ServerName)        );
    syslg("Destination MB : %s\n", destination );
    syslg("Compiled on %s %s\n", __DATE__, __TIME__);

    return IST_RET_OK;
}

void fromMBtoSQS() {
    static char FnDesc[] = "fromMBtoSQS";
    unsigned char buffer[MAX_MSG_LEN] = {0};
    int buflen = 0;

    syslg( "SQSName = <%s:%s>\n", SQSName, QOutputName );

    Aws::SDKOptions options;
    Aws::InitAPI(options);

    Aws::SQS::SQSClient sqs;
    Aws::SQS::Model::SendMessageRequest sm_req;
    Aws::SQS::Model::GetQueueUrlRequest gqu_req;
    Aws::String QueueURL;

    for(;;) {
        // No OutputName - Just Sleep - Nothing to do
        if( !strlen( QOutputName )) {
            sleep(TIME_SLEEP_PROCESS);
            continue;
        }
        // Get URL for OutputQueue
        gqu_req.SetQueueName( QOutputName );
        auto gqu_out = sqs.GetQueueUrl( gqu_req );
        if ( ! gqu_out.IsSuccess() ) {
            syslg("Error to GETURL for [%s] : %s\n", QOutputName, gqu_out.GetError().GetMessage().c_str() );
            sleep( TIME_SLEEP_PROCESS );
            continue;
        }

        // Get URL and prepare to ajust Client
        QueueURL = gqu_out.GetResult().GetQueueUrl().c_str();

        for( ;; ) {
            sm_req.SetQueueUrl(QueueURL);
            memset(buffer,0,sizeof(buffer));
            buflen = mb_read( MyMbId, buffer, sizeof(buffer) );
            if( buflen <= 0 )
                break;
            Aws::String SQSMessage( (char *)&buffer, buflen );
            OTraceDebug("Received from mb[%d - %d bytes) to Queue [%s:%s]\n",mbLastSenderId(), buflen, SQSName, QOutputName);
            syslg("Received from mb[%d - %d bytes) to Queue [%s:%s]\n",mbLastSenderId(), buflen, SQSName, QOutputName);
            OTraceHexDump( (unsigned char *)buffer, buflen );
            LogTcpMsg( (char *)"O", (char *)buffer, buflen );
            sm_req.SetMessageBody(SQSMessage);
            auto sm_out = sqs.SendMessage(sm_req);
            if ( !sm_out.IsSuccess() ) {
                syslg( "Error sending message to SQS [%s] : %s\n", QOutputName, sm_out.GetError().GetMessage().c_str());
            }
        } /* End forever loop */
    } /* End forever loop */

    Aws::ShutdownAPI(options);    
	SQSExit(0);
}

void fromSQStoMB() {
	static char FnDesc[]="fromSQStoMB";
    unsigned char buffer[MAX_MSG_LEN] = {0};
    int buflen = 0;    
	ist_Return_t Result = IST_RET_OK;
    int destinationMB = 0;

	syslg("SQSName = <%s:%s>\n", SQSName,QInputName);

    Aws::SDKOptions options;
    Aws::InitAPI(options);

    Aws::Client::ClientConfiguration client_cfg;
    Aws::SQS::Model::ReceiveMessageRequest rm_req;
    Aws::SQS::Model::DeleteMessageRequest dm_req;
    Aws::SQS::Model::GetQueueUrlRequest gqu_req;
    Aws::String QueueURL;

    client_cfg.requestTimeoutMs = 30000;
    Aws::SQS::SQSClient sqs(client_cfg);

    if ( destionationType == MB_INPUT_REQ ) {
        destinationMB = mb_locatemailbox( ServerName );
    } else {
        destinationMB = mb_locateoutbound( ServerName );
    }

    for(;;) {
        // No InputName - Just Sleep - Nothing to do
        if( !strlen(QInputName)) {
            sleep(TIME_SLEEP_PROCESS);            
            continue;
        }
        gqu_req.SetQueueName( QInputName );
        auto gqu_out = sqs.GetQueueUrl( gqu_req );
        if ( ! gqu_out.IsSuccess() ) {
            syslg("Error to GETURL for [%s] : %s\n", QInputName, gqu_out.GetError().GetMessage().c_str() );
            OTraceDebug("Error to GETURL for [%s] : %s\n", QInputName, gqu_out.GetError().GetMessage().c_str() );
            sleep( TIME_SLEEP_PROCESS );
            continue;
        }
        QueueURL = gqu_out.GetResult().GetQueueUrl().c_str();

        for(;;) {
            rm_req.SetQueueUrl(QueueURL);
            rm_req.SetMaxNumberOfMessages(1);
            rm_req.SetWaitTimeSeconds(20);
            auto rm_out = sqs.ReceiveMessage(rm_req);
            if (!rm_out.IsSuccess()) {
                syslg( "Error receiving message from queue [%s] : %s\n",  QInputName, rm_out.GetError().GetMessage().c_str());
                OTraceDebug( "Error receiving message from queue [%s] : %s\n",  QInputName, rm_out.GetError().GetMessage().c_str());
                continue;
            }

            const auto& messages = rm_out.GetResult().GetMessages();
            if (messages.size() == 0) {
                syslg( "No messages received from queue [%s]\n", QInputName );
                OTraceDebug( "No messages received from queue [%s]\n", QInputName );
                continue;
            }
            const auto& message = messages[0];
            dm_req.SetQueueUrl( QueueURL );
            dm_req.SetReceiptHandle(message.GetReceiptHandle());
            auto dm_out = sqs.DeleteMessage(dm_req);
            if (!dm_out.IsSuccess()) {
                syslg("Error deleting message from queue [%s] ID[%s] : %s\n", QInputName, message.GetMessageId().c_str(), dm_out.GetError().GetMessage().c_str() );
                OTraceDebug("Error deleting message from queue [%s] ID[%s] : %s\n", QInputName, message.GetMessageId().c_str(), dm_out.GetError().GetMessage().c_str() );
                continue;
            }
            OTraceDebug( "MessageId : [%s]\n" , message.GetMessageId().c_str() );
            OTraceDebug( "ReceiptHandle: [%s]\n", message.GetReceiptHandle().c_str() );
            buflen = strlen( message.GetBody().c_str());
            OTraceDebug("Received from SQS[%s] (%d bytes) to MB [%d]\n", QInputName, buflen, destinationMB);
            // Full Message only in HexDump
            OTraceHexDump( (unsigned char *)message.GetBody().c_str(), buflen );
            syslg("Received from SQS[%s] (%d bytes) to MB [%d]\n", QInputName, buflen, destinationMB);
            LogTcpMsg( (char *)"I", (char *)message.GetBody().c_str(), buflen );
            if  ( mb_write( destinationMB, MyMbId, (void *)message.GetBody().c_str(), buflen ) < 0 ) {
                syslg( "Fail to send to mbox: %s\n", ServerName );
                OTraceDebug( "Fail to send to mbox: %s\n", ServerName );
            }
        } /* end of for loop */
    } /* end of for loop */
    Aws::ShutdownAPI(options);    
	SQSExit(0);
}

int main( int argc, char *argv[] ) {
	static char	FnDesc[] = "main";
	char	filename[MB_MAX_NAME+1]={0};
	argv0 = argv[0];
        
	if ( argc != 2 ) {
		syslg("Invalid arguments for calling %s, usage: %s <port_name>\n", argv[0], argv[0], argv[1]);
		return -1;
	}

	sprintf( filename, "%s.debug", argv[1] );
	OTraceOn( argv[1] );

	syslg( "%s %s started up\n", argv[0], argv[1] );
	OTraceDebug ( "%s %s started up\n", argv[0], argv[1] );
	catch_all_signals( SQSExit );

    // MB Initialization
	mb_init();

    // SQS Initialization
	if ( SQSInitiliaze( argv[1] ) != IST_RET_OK ) {
		syslg("Failed to init SQS interface\n");
		SQSExit(1);
	}
	    
	MbPortP->flags |= MB_PORT_CONNECTED;
	
	if (strlen(QInputName)) {
    	pid_read_sqs = fork();
    
    	if( pid_read_sqs == 0 ) {
        	OTraceDebug ( "%s Monitoring MB to write in SQS\n" , argv[0] );
        	fromMBtoSQS();
    	}
    	OTraceDebug ( "%s Monitoring SQS to write in MB\n" , argv[0] );
    	fromSQStoMB();
    } else {
        OTraceDebug ( "%s Monitoring MB to write in SQS\n" , argv[0] );
        fromMBtoSQS();
    }

    SQSExit(0);

    return 0;
}
