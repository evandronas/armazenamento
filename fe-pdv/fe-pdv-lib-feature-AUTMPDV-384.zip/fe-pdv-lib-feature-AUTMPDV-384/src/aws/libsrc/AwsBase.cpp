/*
* Copyright 2020 REDE
*
* Commom base of Internal AWS library
*/

#include <string>
#include <aws/core/internal/AWSHttpResourceClient.h>
#include "AwsBase.hpp"


namespace internalAws {

    Base * Base::instance = NULL;

    Base::Base() {;}

    Base::~Base() {;}

     Base * Base::GetInstance() {
        if (!instance) {
            instance = new Base;
        }
        return instance;
    }

     Aws::String Base::GetRegion() {
         Aws::String region;
         const char * envvar = std::getenv("DB_REGION");
         if ((envvar == nullptr) || (*envvar == '\0'))
         {
             Aws::Internal::EC2MetadataClient regionData;
             return regionData.GetCurrentRegion();
         }
         else
         {
             region.assign(envvar);
         }

         return region;
     }

     Aws::String Base::GetAZ() {
         Aws::SDKOptions options;
         Aws::InitAPI(options);

         std::string az = std::getenv("AZ");
         Aws::String region = GetInstance()->GetRegion();

         if (!region.empty() && !az.empty()) {
             region.push_back(az[az.length() - 1]);
         }

         Aws::ShutdownAPI(options);
         return region;
     }
}
