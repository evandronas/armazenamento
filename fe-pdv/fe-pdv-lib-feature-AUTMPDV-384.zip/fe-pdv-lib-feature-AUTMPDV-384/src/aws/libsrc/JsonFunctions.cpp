/*
* Copyright 2021 REDE
*
* Internal AWS library which allow access to AWS DynamoDB
*/
#include <sstream>

#include <aws/core/Aws.h>
#include <aws/core/internal/AWSHttpResourceClient.h>
#include <aws/secretsmanager/SecretsManagerClient.h>
#include <aws/secretsmanager/model/GetSecretValueRequest.h>

#include <iostream>
#include <string>
#include <map>

#include "logger/LoggerGen.hpp"
#include "JsonFunctions.hpp"
#include "AwsException.hpp"

namespace internalAws {
namespace json {
    JsonFunctions::JsonFunctions() {
        this->logger = logger::LoggerGen::getInstance();
        this->logger->init();
    }

    JsonFunctions::~JsonFunctions() {;}

    std::string JsonFunctions::GetAsString(std::string jsonstr, std::string key) {
        std::string result = std::string("");

        if ( jsonstr.empty() || key.empty()) {
            this->logger->print(logger::LEVEL_FATAL, "JsonFunctions: Empty data");
            throw internalAws::exception::AwsException( "JsonFunctions: Empty Data" ); 
        }

        Aws::SDKOptions options;
        Aws::InitAPI(options);
        {        
            Aws::String awsjsonstr(jsonstr.c_str(),jsonstr.size());
            Aws::Utils::Json::JsonValue awsJsonStr(awsjsonstr);
            Aws::Utils::Json::JsonView awsJsonReader(awsJsonStr);
            Aws::String awsJsonKey(key.c_str(),key.size());
            std::stringstream logMsg;

            if( ! awsJsonReader.KeyExists( awsJsonKey )) {
                logMsg << "JsonReader: Key not found -> " << key << std::endl;
                this->logger->print(logger::LEVEL_FATAL, logMsg.str().c_str());
                throw internalAws::exception::AwsException( logMsg.str() );
            }
            if( awsJsonReader.GetObject(awsJsonKey).IsIntegerType()) {
                logMsg << "JsonReader: Invalid Get. Use GetAsInteger -> " << key << std::endl;
                this->logger->print(logger::LEVEL_FATAL, logMsg.str().c_str());
                throw internalAws::exception::AwsException( logMsg.str() );
            }            
            result = std::string( awsJsonReader.GetString( awsJsonKey ).c_str() );
        }
        Aws::ShutdownAPI(options);        
        return result;
    }

    int JsonFunctions::GetAsInteger(std::string jsonstr, std::string key) {
        int result = -1;

        if ( jsonstr.empty() || key.empty()) {
            this->logger->print(logger::LEVEL_FATAL, "JsonFunctions: Empty data");
            throw internalAws::exception::AwsException( "JsonFunctions: Empty Data" );
        }

        Aws::SDKOptions options;
        Aws::InitAPI(options);
        {        
            Aws::String awsjsonstr(jsonstr.c_str(),jsonstr.size());
            Aws::Utils::Json::JsonValue awsJsonValue(awsjsonstr);
            Aws::Utils::Json::JsonView awsJsonReader(awsJsonValue);
            Aws::String awsJsonKey(key.c_str(),key.size());
            std::stringstream logMsg;

            if( ! awsJsonReader.KeyExists( awsJsonKey )) {
                logMsg << "JsonReader: Key not found -> " << key << std::endl;
                this->logger->print(logger::LEVEL_FATAL, logMsg.str().c_str());
                throw internalAws::exception::AwsException( logMsg.str() );
            }
            if( awsJsonReader.GetObject(awsJsonKey).IsString()) {
                logMsg << "JsonReader: Invalid Get. Use GetAsString -> " << key << std::endl;
                this->logger->print(logger::LEVEL_FATAL, logMsg.str().c_str());
                throw internalAws::exception::AwsException( logMsg.str() );
            }
            result = awsJsonReader.GetInteger( awsJsonKey );
        }
        Aws::ShutdownAPI(options);
        return result; 
    }
}
}