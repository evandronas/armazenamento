/*
* Copyright 2020 REDE
*
* Internal AWS library which allow access to AWS System Manager
*/

#include <cstdlib>
#include <sstream>

#include <aws/core/internal/AWSHttpResourceClient.h>
#include <aws/ssm/model/GetParameterRequest.h>
#include <aws/ssm/SSMClient.h>

#include "logger/LoggerGen.hpp"
#include "AwsBase.hpp"
#include "SystemManager.hpp"


namespace internalAws {
namespace ssm {
    SystemManager::SystemManager() {
        this->logger = logger::LoggerGen::getInstance();
        this->logger->init();
    }

    SystemManager::~SystemManager() {;}

    std::string SystemManager::GetParameterStore(const char * name) {
        std::string ret;

        if ((name == nullptr) || (*name == '\0')) {
            this->logger->print(logger::LEVEL_FATAL, "Empty data");
            return ret;
        }

        Aws::String _name(name);
        Aws::SDKOptions options;
        Aws::InitAPI(options);
        {
            Aws::Client::ClientConfiguration clientConfig;
            clientConfig.region = internalAws::Base::GetInstance()->GetRegion();
            Aws::SSM::SSMClient ssmClient(clientConfig);

            Aws::SSM::Model::GetParameterRequest request;
            request.SetName(_name);
            request.SetWithDecryption(true);
            auto response = ssmClient.GetParameter(request);

            if (response.IsSuccess()) {
                const auto &parameterValue = response.GetResult().GetParameter().GetValue();
                this->logger->print(logger::LEVEL_DEBUG, "The secret has been read");

                ret.assign(parameterValue.c_str());
            } else {
                std::stringstream logMsg;
                logMsg << "Failed to get secret:\n" << response.GetError();
                this->logger->print(logger::LEVEL_FATAL, logMsg.str().c_str());
            }
        }
        Aws::ShutdownAPI(options);

        return ret;
    }
} // ssm
} // internalAws