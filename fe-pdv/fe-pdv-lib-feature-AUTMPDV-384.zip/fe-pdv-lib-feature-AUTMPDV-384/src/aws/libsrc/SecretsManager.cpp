/*
* Copyright 2020 REDE
*
* Internal AWS library which allow access to AWS Secrets Manager
*/

#include <sstream>

#include <aws/core/internal/AWSHttpResourceClient.h>
#include <aws/secretsmanager/SecretsManagerClient.h>
#include <aws/secretsmanager/model/GetSecretValueRequest.h>

#include "logger/LoggerGen.hpp"
#include "SecretsManager.hpp"
#include "AwsBase.hpp"


namespace internalAws {
namespace sm {

    SecretsManager::SecretsManager() {
        this->logger = logger::LoggerGen::getInstance();
        this->logger->init();
    }

    SecretsManager::~SecretsManager() {;}

    std::string SecretsManager::RetrieveSecretName(std::string secret, const char * key) {
        std::string ret;

        if (secret.empty() || (key == nullptr) || (*key == '\0')) {
            this->logger->print(logger::LEVEL_FATAL, "Empty data");
            return ret;
        }

        Aws::String _secret(secret.c_str(), secret.size());
        Aws::SDKOptions options;
        Aws::InitAPI(options);
        {
            Aws::Client::ClientConfiguration clientConfig;
            clientConfig.region = internalAws::Base::GetInstance()->GetRegion();
            Aws::SecretsManager::SecretsManagerClient secretManagerClient(clientConfig);

            Aws::SecretsManager::Model::GetSecretValueRequest request;
            request.SetSecretId(_secret);
            auto response = secretManagerClient.GetSecretValue(request);

            if (response.IsSuccess()) {
                Aws::String secret = response.GetResult().GetSecretString();
                Aws::Utils::Json::JsonValue secretJson(secret);
                Aws::Utils::Json::JsonView secretJsonView(secretJson);

                this->logger->print(logger::LEVEL_DEBUG, "The secret has been retrieved");

                if( !secretJsonView.KeyExists(key)) {
                    std::stringstream logMsg;
                    logMsg << " Key '" << key << "' doesnt exist in secret";
                    this->logger->print(logger::LEVEL_FATAL, logMsg.str().c_str());
                    return ret;
                }

                if (secretJsonView.GetObject(key).IsString()){
                    ret.assign(secretJsonView.GetString(key).c_str());
                } else {
                    ret.assign(std::to_string(secretJsonView.GetInteger(key)));
                }
            } else {
                std::stringstream logMsg;
                logMsg << "Failed to retrieve secret:\n" << response.GetError();
                this->logger->print(logger::LEVEL_FATAL, logMsg.str().c_str());
            }
        }

        Aws::ShutdownAPI(options);

        return ret;
    }
}
}