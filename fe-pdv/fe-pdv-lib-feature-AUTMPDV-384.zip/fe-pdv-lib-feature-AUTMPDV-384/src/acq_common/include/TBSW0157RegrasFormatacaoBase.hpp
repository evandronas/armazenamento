#pragma once

#include <string>
#include <DBM3.h> //oasis_dec_t
#include "TBSW0157.hpp"
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <AcqUtils.hpp>

class TBSW0157RegrasFormatacaoBase
{
	private:    
		logger::DebugWriter *m_log;

    public:
        TBSW0157RegrasFormatacaoBase( );
        ~TBSW0157RegrasFormatacaoBase( );

		virtual void DAT_MOV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao );
		virtual void NUM_SEQ_UNC( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao );
		virtual void COD_SERV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao );
		virtual void NUM_PDV_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao );
		virtual void COD_TERM_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao );
		virtual void NUM_DDD_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao );
		virtual void NUM_TEL_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao );
		virtual void NUM_SEQ_UNC_OPER( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao );

		virtual void gen_DAT_MOV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void gen_NUM_SEQ_UNC( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void gen_COD_SERV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void gen_NUM_PDV_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void gen_COD_TERM_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void gen_NUM_DDD_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void gen_NUM_TEL_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void gen_NUM_SEQ_UNC_OPER( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );

		virtual void insert_DAT_MOV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void insert_NUM_SEQ_UNC( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void insert_COD_SERV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void insert_NUM_PDV_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void insert_COD_TERM_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void insert_NUM_DDD_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void insert_NUM_TEL_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void insert_NUM_SEQ_UNC_OPER( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );

		virtual void update_DAT_MOV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void update_NUM_SEQ_UNC( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void update_COD_SERV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void update_NUM_PDV_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void update_COD_TERM_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void update_NUM_DDD_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void update_NUM_TEL_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
		virtual void update_NUM_SEQ_UNC_OPER( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params );
};