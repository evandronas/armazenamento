#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_common
{
    class TBSW0152 : public dbaccess::table
    {
        public:
            
            TBSW0152( );
            TBSW0152( const std::string& whereClause );
            ~TBSW0152( );
            
            void initialize( );
            void bind_columns( );
            void let_as_is( );
			
            void set_QTD_CICL_CRNC_PRMR_PRCL( unsigned long a_QTD_CICL_CRNC_PRMR_PRCL );
            void set_QTD_PRCL( unsigned long a_QTD_PRCL );
            void set_DAT_VCTO_PRMR_PRCL( dbm_datetime_t a_DAT_VCTO_PRMR_PRCL );
            void set_VAL_PRCL_ENTR( oasis_dec_t a_VAL_PRCL_ENTR );
            void set_VAL_PRCL( oasis_dec_t a_VAL_PRCL );
            void set_PRCN_TX_JURO( oasis_dec_t a_PRCN_TX_JURO );
            void set_PRCN_TX_JURO_MES( oasis_dec_t a_PRCN_TX_JURO_MES );
            void set_PRCN_TX_JURO_ANO( oasis_dec_t a_PRCN_TX_JURO_ANO );
            void set_PRCN_TX_JURO_MORA( oasis_dec_t a_PRCN_TX_JURO_MORA );
            void set_VAL_PRES_BRTO( oasis_dec_t a_VAL_PRES_BRTO );
            void set_VAL_TX_EFTV( oasis_dec_t a_VAL_TX_EFTV );
            void set_VAL_TX_MNSL( oasis_dec_t a_VAL_TX_MNSL );
            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            
            unsigned long get_QTD_CICL_CRNC_PRMR_PRCL( ) const;
            unsigned long get_QTD_PRCL( ) const;
            dbm_datetime_t get_DAT_VCTO_PRMR_PRCL( ) const;
            oasis_dec_t get_VAL_PRCL_ENTR( ) const;
            oasis_dec_t get_VAL_PRCL( ) const;
            oasis_dec_t get_PRCN_TX_JURO( ) const;
            oasis_dec_t get_PRCN_TX_JURO_MES( ) const;
            oasis_dec_t get_PRCN_TX_JURO_ANO( ) const;
            oasis_dec_t get_PRCN_TX_JURO_MORA( ) const;
            oasis_dec_t get_VAL_PRES_BRTO( ) const;
            oasis_dec_t get_VAL_TX_EFTV( ) const;
            oasis_dec_t get_VAL_TX_MNSL( ) const;
            unsigned long get_DAT_MOV_TRAN( ) const;
            oasis_dec_t get_NUM_SEQ_UNC( ) const;

            void showxxx( const char *name, unsigned long campo );
            void showxxx( const char *name, dbm_datetime_t campo );
            void showxxx( const char *name, const std::string& campo );
            void showxxx( const char *name, oasis_dec_t campo );
            void show(int nvl);
            
        private:
            
            unsigned long    m_QTD_CICL_CRNC_PRMR_PRCL;
            unsigned long    m_QTD_PRCL;
            dbm_datetime_t   m_DAT_VCTO_PRMR_PRCL;
            oasis_dec_t      m_VAL_PRCL_ENTR;
            oasis_dec_t      m_VAL_PRCL;
            oasis_dec_t      m_PRCN_TX_JURO;
            oasis_dec_t      m_PRCN_TX_JURO_MES;
            oasis_dec_t      m_PRCN_TX_JURO_ANO;
            oasis_dec_t      m_PRCN_TX_JURO_MORA;
            oasis_dec_t      m_VAL_PRES_BRTO;
            oasis_dec_t      m_VAL_TX_EFTV;
            oasis_dec_t      m_VAL_TX_MNSL;
            unsigned long    m_DAT_MOV_TRAN;
            oasis_dec_t      m_NUM_SEQ_UNC;
            
            int m_QTD_CICL_CRNC_PRMR_PRCL_pos;
            int m_QTD_PRCL_pos;
            int m_DAT_VCTO_PRMR_PRCL_pos;
            int m_VAL_PRCL_ENTR_pos;
            int m_VAL_PRCL_pos;
            int m_PRCN_TX_JURO_pos;
            int m_PRCN_TX_JURO_MES_pos;
            int m_PRCN_TX_JURO_ANO_pos;
            int m_PRCN_TX_JURO_MORA_pos;
            int m_VAL_PRES_BRTO_pos;
            int m_VAL_TX_EFTV_pos;
            int m_VAL_TX_MNSL_pos;
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            
            int m_DAT_VCTO_PRMR_PRCL_ind_null;

            logger::DebugWriter *m_log;
    };
} //namespace dbaccess_common


