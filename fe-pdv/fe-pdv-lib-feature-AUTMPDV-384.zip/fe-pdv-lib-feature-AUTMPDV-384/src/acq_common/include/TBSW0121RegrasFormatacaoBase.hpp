#pragma once

#include "TBSW0121.hpp"
#include<string>
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <AcqUtils.hpp>

class TBSW0121RegrasFormatacaoBase
{
    public:
        TBSW0121RegrasFormatacaoBase( );
        ~TBSW0121RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SRE_PNPD       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_CHCK_PDV       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_MODL_PNPD      ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_BBLT_PNPD ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_CHCK_PDV  ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_SRVD_PDV  ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_SIS       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_SFTW      ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao );

        // Metodos utilizados por campos que tem input generico (INSERT/UPDATE)
        virtual void gen_DAT_MOV_TRAN       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_NUM_SEQ_UNC        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_NUM_SRE_PNPD       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_COD_CHCK_PDV       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_COD_MODL_PNPD      ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_COD_VERS_BBLT_PNPD ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_COD_VERS_CHCK_PDV  ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_COD_VERS_SRVD_PDV  ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_COD_VERS_SIS       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void gen_COD_VERS_SFTW      ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );

        // Metodos especificos para INSERT
        virtual void insert_DAT_MOV_TRAN        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_NUM_SEQ_UNC         ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_NUM_SRE_PNPD        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_COD_CHCK_PDV        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_COD_MODL_PNPD       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_COD_VERS_BBLT_PNPD  ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_COD_VERS_CHCK_PDV   ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_COD_VERS_SRVD_PDV   ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_COD_VERS_SIS        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void insert_COD_VERS_SFTW       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );

        // Metodos especificos para UPDATE
        virtual void update_DAT_MOV_TRAN        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_NUM_SEQ_UNC         ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_NUM_SRE_PNPD        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_COD_CHCK_PDV        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_COD_MODL_PNPD       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_COD_VERS_BBLT_PNPD  ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_COD_VERS_CHCK_PDV   ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_COD_VERS_SRVD_PDV   ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_COD_VERS_SIS        ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
        virtual void update_COD_VERS_SFTW       ( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );

        logger::DebugWriter *m_log;

}; // class TBSW0121RegrasFormatacaoBase
