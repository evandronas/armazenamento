#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0102 : public dbaccess::table
    {
        public:
            TBSW0102( );
            TBSW0102( const std::string& whereClause );
            ~TBSW0102( );

            void initialize( );
            void bind_columns( );

            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC );
            void set_COD_NVL_SGRA_TKN( const std::string& a_COD_NVL_SGRA_TKN );
            void set_COD_REF_CTA_PGMN( const std::string& a_COD_REF_CTA_PGMN );

            unsigned long get_DAT_MOV_TRAN( ) const;
            unsigned long get_NUM_SEQ_UNC( ) const;
            const std::string& get_COD_NVL_SGRA_TKN( ) const;
            const std::string& get_COD_REF_CTA_PGMN( ) const;

        private:
            unsigned long   m_DAT_MOV_TRAN;
            unsigned long   m_NUM_SEQ_UNC;
            std::string     m_COD_NVL_SGRA_TKN;
            std::string     m_COD_REF_CTA_PGMN;

            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_COD_NVL_SGRA_TKN_pos;
            int m_COD_REF_CTA_PGMN_pos;

    }; // class TBSW0102

} // namespace dbaccess_common


