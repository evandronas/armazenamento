#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
	class TBSW0128 : public dbaccess::table
	{
	public:
		TBSW0128();
		TBSW0128( const std::string& whereClause );
		~TBSW0128();

		void bind_columns();

		void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
		void set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC );
		void set_NUM_ESTB( unsigned long a_NUM_ESTB );
		void set_VAL_TRAN( unsigned long a_VAL_TRAN );
		void set_COD_TERM( const std::string& a_COD_TERM );
		void set_NUM_CAR( const std::string& a_NUM_CAR );
		void set_COD_MOT_RSPS_DEST( const std::string& a_COD_MOT_RSPS_DEST );
		void set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN );
		
		unsigned long get_DAT_MOV_TRAN() const;
		unsigned long get_NUM_SEQ_UNC() const;
		unsigned long get_NUM_ESTB() const;
		unsigned long get_VAL_TRAN() const;
		const std::string& get_COD_TERM() const;
		const std::string& get_NUM_CAR() const;
		const std::string& get_COD_MOT_RSPS_DEST() const;
		const dbm_datetime_t get_DTH_INI_TRAN() const;

	private:
		unsigned long m_DAT_MOV_TRAN;
		unsigned long m_NUM_SEQ_UNC;
		unsigned long m_NUM_ESTB;
		unsigned long m_VAL_TRAN;
		std::string m_COD_TERM;
		std::string m_NUM_CAR;
		std::string m_COD_MOT_RSPS_DEST;
		dbm_datetime_t m_DTH_INI_TRAN;

		int m_DAT_MOV_TRAN_pos;
		int m_NUM_SEQ_UNC_pos;
		int m_NUM_ESTB_pos;
		int m_VAL_TRAN_pos;
		int m_COD_TERM_pos;
		int m_NUM_CAR_pos;
		int m_COD_MOT_RSPS_DEST_pos;
		int m_DTH_INI_TRAN_pos;
	};
} //namespace dbaccess_common

