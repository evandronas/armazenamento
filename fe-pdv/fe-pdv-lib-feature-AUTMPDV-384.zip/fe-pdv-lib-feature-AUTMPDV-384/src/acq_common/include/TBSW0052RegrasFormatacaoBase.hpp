#pragma once

class TBSW0052RegrasFormatacaoBase
{
public:
	TBSW0052RegrasFormatacaoBase( );
	~TBSW0052RegrasFormatacaoBase( );
};