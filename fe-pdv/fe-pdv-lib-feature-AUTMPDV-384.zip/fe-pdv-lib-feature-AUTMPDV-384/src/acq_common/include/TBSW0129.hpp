#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0129 : public dbaccess::table
    {
        public:
            TBSW0129( );
            TBSW0129( const std::string& whereClause );
            ~TBSW0129( );

            void initialize( );
            void bind_columns( );

            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            void set_NUM_ESTB( unsigned long a_NUM_ESTB );
            void set_COD_TERM( const std::string& a_COD_TERM );
            void set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN );
            void set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL );
            void set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL );
            void set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL );

            unsigned long get_DAT_MOV_TRAN( ) const;
            oasis_dec_t get_NUM_SEQ_UNC( ) const;
            unsigned long get_NUM_ESTB( ) const;
            const std::string& get_COD_TERM( ) const;
            const dbm_datetime_t get_DTH_INI_TRAN( ) const;
            const std::string& get_NOM_SITE_ACQR_ORGL( ) const;
            const std::string& get_NOM_HOST_ACQR_ORGL( ) const;
            const std::string& get_NOM_FE_ACQR_ORGL( ) const;

        private:
            unsigned long   m_DAT_MOV_TRAN;
            oasis_dec_t     m_NUM_SEQ_UNC;
            unsigned long   m_NUM_ESTB;
            std::string     m_COD_TERM;
            dbm_datetime_t  m_DTH_INI_TRAN;
            std::string     m_NOM_SITE_ACQR_ORGL;
            std::string     m_NOM_HOST_ACQR_ORGL;
            std::string     m_NOM_FE_ACQR_ORGL;

            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_NUM_ESTB_pos;
            int m_COD_TERM_pos;
            int m_DTH_INI_TRAN_pos;
            int m_NOM_SITE_ACQR_ORGL_pos;
            int m_NOM_HOST_ACQR_ORGL_pos;
            int m_NOM_FE_ACQR_ORGL_pos;

    }; // class TBSW0129

} // namespace dbaccess_common


