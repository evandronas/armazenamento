/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#ifndef __TBSW0268_H__
#define __TBSW0268_H__

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0268 : public dbaccess::table
    {
        public:
            // Declaracao dos Contrutores
            TBSW0268();
            TBSW0268(const std::string& where);

            // Declaracao dos Destrutores
            virtual ~TBSW0268();

            // Getters
            const std::string& GetCodigoBinInferior() const;
            const std::string& GetCodigoBinSuperior() const;
            const std::string& GetCodigoEntryMode() const;
            const std::string& GetCodigoProduto() const;
            const dbm_datetime_t& GetDataInclusaoRegistro() const;
            const std::string& GetCodigoSituacaoRegistro() const;
			
            // Setters
            void SetCodigoBinInferior(const std::string& value);
            void SetCodigoBinSuperior(const std::string& value);
            void SetCodigoEntryMode(const std::string& value);
            void SetCodigoProduto(const std::string& value);
            void SetDataInclusaoRegistro(const dbm_datetime_t& value);
            void SetCodigoSituacaoRegistro(const std::string& value);

        protected:
            // Metodo herdado da classe base(db_object)
            void bind_columns();

        private:
            // Indices dos campos na tabela
            int codigoBinInferiorPosicao;
            int codigoBinSuperiorPosicao;
            int codigoEntryModePosicao;
            int codigoProdutoPosicao;
            int dataInclusaoRegistroPosicao;
            int codigoSituacaoRegistroPosicao;

            // Atributos confrome campos da tabela TBSW0268
            std::string codigoBinInferior;
            std::string codigoBinSuperior;
            std::string codigoEntryMode;
            std::string codigoProduto;
            dbm_datetime_t dataInclusaoRegistro;
            std::string codigoSituacaoRegistro;
    };
}
#endif  // __TBSW0268_H__
