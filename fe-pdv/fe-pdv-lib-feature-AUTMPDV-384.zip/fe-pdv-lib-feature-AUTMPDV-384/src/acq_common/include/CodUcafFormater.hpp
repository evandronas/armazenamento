#pragma once
#include <sstream>

class CodUcafFormater
{
    public:
        CodUcafFormater( const std::string &cavv );
        virtual ~CodUcafFormater();
        virtual std::string format() = 0;

    protected:
        std::string m_cavv;

        void BinaryToChar( char* outputData, char* inputData, int lenghtData );
};