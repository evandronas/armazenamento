#pragma once

#include <string>
#include "defines.hpp"
#include "TBSW0083.hpp"

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
class TBSW0083RegrasFormatacaoBase
{
public:
    TBSW0083RegrasFormatacaoBase( );
    ~TBSW0083RegrasFormatacaoBase( );

    //INTERFACE
    virtual void COD_CEP_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao );
    virtual void COD_CEP_CMPM_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao );
    virtual void TXT_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao );
    virtual void NUM_CPF_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao );
    virtual void DAT_MOV_TRAN( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao );
    virtual void NUM_SEQ_UNC( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao );
    virtual void COD_RSPS_AVS( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao );
    virtual void TXT_CMPM_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao );
    
    //GERAL
    virtual void gen_COD_CEP_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void gen_COD_CEP_CMPM_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void gen_TXT_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void gen_NUM_CPF_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void gen_DAT_MOV_TRAN( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void gen_NUM_SEQ_UNC( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void gen_COD_RSPS_AVS( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void gen_TXT_CMPM_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );

    //INSERT
    virtual void insert_COD_CEP_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void insert_COD_CEP_CMPM_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void insert_TXT_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void insert_NUM_CPF_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void insert_DAT_MOV_TRAN( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void insert_NUM_SEQ_UNC( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void insert_COD_RSPS_AVS( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void insert_TXT_CMPM_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );

    //UPDATE
    virtual void update_COD_CEP_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void update_COD_CEP_CMPM_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void update_TXT_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void update_NUM_CPF_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void update_DAT_MOV_TRAN( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void update_NUM_SEQ_UNC( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void update_COD_RSPS_AVS( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    virtual void update_TXT_CMPM_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params );
    
private:    
    logger::DebugWriter *m_log;
};