/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ 2020, 07 de Outubro, Andre, J10_2020 - Release Bandeiras
/ -------------------------------------------------------------------------------------------------
/ 2021-02-01 Breder - AUT1-2821 - PIX CNPJ Owner +Refactory
/ 2021-05-21 Eduardo Sert�rio - AUT1-1830 - ELO endereco EC no CV
*/
#pragma once
#include <dbm.h>
#include "dbaccess/table.hpp"
namespace dbaccess_common
{
    class TBSW0040 : public dbaccess::table
    {
    public:
        TBSW0040( );
        TBSW0040( const std::string &str );
        virtual ~TBSW0040( );
        void bind_columns( );
        void setProperties( const std::string &str );

        long                getNUM_PDV( )               const;
        long                getCOD_TIP_ESTB_PDV( )      const;
        const std::string&  getCOD_CTGR( )              const;
        const std::string&  getNOM_RZAO_SCLA_ESTB( )    const;
        const std::string&  getNOM_FAT_PDV( )           const;
        const std::string&  getCOD_CEP_PDV( )           const;
        const std::string&  getCOD_CEP_CPL_PDV( )       const;
        const std::string&  getNOM_CID_PDV( )           const;
        const std::string&  getNOM_ESTB_PDV( )          const;
        const std::string&  getCOD_PAIS( )              const;
        long                getCOD_RAM_ATVD( )          const;
        long                getCOD_RAM_ATVD_MTC( )      const;
        const std::string&  getCOD_CTGR_TRAN_MTC( )     const;
        long                getCOD_RAM_ATVD_MTC_DNRS( ) const;
        long                getCOD_MTZ_ESTB( )          const;
        long                getCOD_GRU_ESTB( )          const;
        oasis_dec_t         getNUM_CNPJ( )              const;
        const std::string&  getCOD_STTU_REG( )          const;
        dbm_datetime_t      getDAT_ATLZ_REG( )          const;
        long                getCOD_ID_DSTR( )           const;
        const std::string&  getIND_PDV_CART_DGTL( )     const;
        const std::string&  getCOD_TIP_PES( )           const;
        long                getCOD_GRU_CLAS_RAM( )      const;
        long                getCOD_TIP_FACR( )          const;
        const std::string&  getCOD_MVV( )               const; // J10_2020 - Release Outubro
        long                getCOD_PRCR_PSP( )          const; // AUT1-2121 - Codigo do Parceiro PSP - PIX
        long                getCOD_TIP_CHAV_PIX( )      const; // AUT1-2121 - Codigo da Chave PIX
        const std::string&  getCOD_CHAV_PIX( )          const; // AUT1-2320 - Codigo do tipo da Chave PIX
        oasis_dec_t         getNUM_CNPJ_PIX_OWN_CHAV( ) const; // AUT1-2821 - PIX CNPJ Owner
        const std::string&  getNOM_LOGR_PDV( )          const; // AUT1-1830 - ELO endereco EC no CV
        const std::string&  getNUM_LOGR_PDV( )          const; // AUT1-1830 - ELO endereco EC no CV
        const std::string&  getNOM_BRR_PDV( )           const; // AUT1-1830 - ELO endereco EC no CV
        const std::string&  getDES_CPL_ENDR_PDV( )      const; // AUT1-1830 - ELO endereco EC no CV
        int                 GetCanal( )                 const;
        int                 GetCelula( )                const;

        void setNUM_PDV               ( long                 a_NUM_PDV               );
        void setCOD_TIP_ESTB_PDV      ( long                 a_COD_TIP_ESTB_PDV      );
        void setCOD_CTGR              ( const std::string&   a_COD_CTGR              );
        void setNOM_RZAO_SCLA_ESTB    ( const std::string&   a_NOM_RZAO_SCLA_ESTB    );
        void setNOM_FAT_PDV           ( const std::string&   a_NOM_FAT_PDV           );
        void setCOD_CEP_PDV           ( const std::string&   a_COD_CEP_PDV           );
        void setCOD_CEP_CPL_PDV       ( const std::string&   a_COD_CEP_CPL_PDV       );
        void setNOM_CID_PDV           ( const std::string&   a_NOM_CID_PDV           );
        void setNOM_ESTB_PDV          ( const std::string&   a_NOM_ESTB_PDV          );
        void setCOD_PAIS              ( const std::string&   a_COD_PAIS              );
        void setCOD_RAM_ATVD          ( long                 a_COD_RAM_ATVD          );
        void setCOD_RAM_ATVD_MTC      ( long                 a_COD_RAM_ATVD_MTC      );
        void setCOD_CTGR_TRAN_MTC     ( const std::string&   a_COD_CTGR_TRAN_MTC     );
        void setCOD_RAM_ATVD_MTC_DNRS ( long                 a_COD_RAM_ATVD_MTC_DNRS );
        void setCOD_MTZ_ESTB          ( long                 a_COD_MTZ_ESTB          );
        void setCOD_GRU_ESTB          ( long                 a_COD_GRU_ESTB          );
        void setNUM_CNPJ              ( oasis_dec_t          a_NUM_CNPJ              );
        void setCOD_STTU_REG          ( const std::string&   a_COD_STTU_REG          );
        void setDAT_ATLZ_REG          ( dbm_datetime_t       a_DAT_ATLZ_REG          );
        void setCOD_ID_DSTR           ( long                 a_COD_ID_DSTR           );
        void setIND_PDV_CART_DGTL     ( const std::string&   a_IND_PDV_CART_DGTL     );
        void setCOD_TIP_PES           ( const std::string&   a_COD_TIP_PES           );
        void setCOD_GRU_CLAS_RAM      ( long                 a_COD_GRU_CLAS_RAM      );
        void setCOD_TIP_FACR          ( long                 a_COD_TIP_FACR          );
        void setCOD_MVV               ( const std::string&   a_COD_MVV               ); // J10_2020 - Release Outubro
        void setCOD_PRCR_PSP          ( long                 a_COD_PRCR_PSP          ); // AUT1-2121 - Codigo do Parceiro PSP - PIX
        void setCOD_TIP_CHAV_PIX      ( long                 a_COD_TIP_CHAV_PIX      ); // AUT1-2121 - Codigo da Chave PIX
        void setCOD_CHAV_PIX          ( const std::string&   a_COD_CHAV_PIX          ); // AUT1-2320 - Codigo do tipo da Chave PIX
        void setNUM_CNPJ_PIX_OWN_CHAV ( oasis_dec_t          a_NUM_CNPJ_PIX_OWN_CHAV ); // AUT1-2821 - PIX CNPJ Owner
        void setNOM_LOGR_PDV          ( const std::string&   a_NOM_LOGR_PDV          ); // AUT1-1830 - ELO endereco EC no CV
        void setNUM_LOGR_PDV          ( const std::string&   a_NUM_LOGR_PDV          ); // AUT1-1830 - ELO endereco EC no CV
        void setNOM_BRR_PDV           ( const std::string&   a_NOM_BRR_PDV           ); // AUT1-1830 - ELO endereco EC no CV
        void setDES_CPL_ENDR_PDV      ( const std::string&   a_DES_CPL_ENDR_PDV      ); // AUT1-1830 - ELO endereco EC no CV
        void setCanal                 ( int                  canal                   );
        void setCelula                ( int                  celula                  );

    private:
        int m_NUM_PDV_pos;                     long             m_NUM_PDV;
        int m_COD_TIP_ESTB_PDV_pos;            long             m_COD_TIP_ESTB_PDV;
        int m_COD_CTGR_pos;                    std::string      m_COD_CTGR;
        int m_NOM_RZAO_SCLA_ESTB_pos;          std::string      m_NOM_RZAO_SCLA_ESTB;
        int m_NOM_FAT_PDV_pos;                 std::string      m_NOM_FAT_PDV;
        int m_COD_CEP_PDV_pos;                 std::string      m_COD_CEP_PDV;
        int m_COD_CEP_CPL_PDV_pos;             std::string      m_COD_CEP_CPL_PDV;
        int m_NOM_CID_PDV_pos;                 std::string      m_NOM_CID_PDV;
        int m_NOM_ESTB_PDV_pos;                std::string      m_NOM_ESTB_PDV;
        int m_COD_PAIS_pos;                    std::string      m_COD_PAIS;
        int m_COD_RAM_ATVD_pos;                long             m_COD_RAM_ATVD;
        int m_COD_RAM_ATVD_MTC_pos;            long             m_COD_RAM_ATVD_MTC;
        int m_COD_CTGR_TRAN_MTC_pos;           std::string      m_COD_CTGR_TRAN_MTC;
        int m_COD_RAM_ATVD_MTC_DNRS_pos;       long             m_COD_RAM_ATVD_MTC_DNRS;
        int m_COD_MTZ_ESTB_pos;                long             m_COD_MTZ_ESTB;
        int m_COD_GRU_ESTB_pos;                long             m_COD_GRU_ESTB;
        int m_NUM_CNPJ_pos;                    oasis_dec_t      m_NUM_CNPJ;
        int m_COD_STTU_REG_pos;                std::string      m_COD_STTU_REG;
        int m_DAT_ATLZ_REG_pos;                dbm_datetime_t   m_DAT_ATLZ_REG;
        int m_COD_ID_DSTR_pos;                 long             m_COD_ID_DSTR;
        int m_IND_PDV_CART_DGTL_pos;           std::string      m_IND_PDV_CART_DGTL;
        int m_COD_TIP_PES_pos;                 std::string      m_COD_TIP_PES;
        int m_COD_GRU_CLAS_RAM_pos;            long             m_COD_GRU_CLAS_RAM;
        int m_COD_TIP_FACR_pos;                long             m_COD_TIP_FACR;
        int m_COD_MVV_pos;                     std::string      m_COD_MVV;               // J10_2020 - Release Outubro
        int m_COD_PRCR_PSP_pos;                long             m_COD_PRCR_PSP;          // AUT1-2121 - Codigo do Parceiro PSP - PIX
        int m_COD_TIP_CHAV_PIX_pos;            long             m_COD_TIP_CHAV_PIX;      // AUT1-2121 - Codigo da Chave PIX
        int m_COD_CHAV_PIX_pos;                std::string      m_COD_CHAV_PIX;          // AUT1-2320 - Codigo do tipo da Chave PIX
        int m_NUM_CNPJ_PIX_OWN_CHAV_pos;       oasis_dec_t      m_NUM_CNPJ_PIX_OWN_CHAV; // AUT1-2821 - PIX CNPJ Owner
        int m_NOM_LOGR_PDV_pos;                std::string      m_NOM_LOGR_PDV;          // AUT1-1830 - ELO endereco EC
        int m_NUM_LOGR_PDV_pos;                std::string      m_NUM_LOGR_PDV;          // AUT1-1830 - ELO endereco EC
        int m_NOM_BRR_PDV_pos;                 std::string      m_NOM_BRR_PDV;           // AUT1-1830 - ELO endereco EC
        int m_DES_CPL_ENDR_PDV_pos;            std::string      m_DES_CPL_ENDR_PDV;      // AUT1-1830 - ELO endereco EC
        int codigoCanalPos;                    int              codigoCanal;
        int codigoCelulaPos;                   int              codigoCelula;
    };
}
