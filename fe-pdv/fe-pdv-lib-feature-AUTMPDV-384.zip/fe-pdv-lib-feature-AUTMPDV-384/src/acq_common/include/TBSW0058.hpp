#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_common
{
    class TBSW0058 : public dbaccess::table
    {
        public:

            TBSW0058( );
            TBSW0058( const std::string& whereClause );
            ~TBSW0058( );

            void bind_columns( );

            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC );
            void set_TIP_TRAN( unsigned long a_TIP_TRAN );
            void set_NUM_MOT_RSPS( unsigned long a_NUM_MOT_RSPS );
            void set_NUM_ESTB( unsigned long a_NUM_ESTB );
            void set_COD_TERM( const std::string& a_COD_TERM );
            void set_NUM_RD_ORG( unsigned long a_NUM_RD_ORG );
            void set_COD_POS_ENTR_MODO( const std::string& a_COD_POS_ENTR_MODO );
            void set_COD_EMSR( unsigned long a_COD_EMSR );
            void set_VAL_TRAN( oasis_dec_t a_VAL_TRAN );
            void set_COD_RAM_ATVD( unsigned long a_COD_RAM_ATVD );
            void set_NUM_CAR( const std::string& a_NUM_CAR );
            void set_NUM_AUT( const std::string& a_NUM_AUT );
            void set_VAL_COT_DLR( oasis_dec_t a_VAL_COT_DLR );
            void set_DAT_VLD_CAR( sw_date_t a_DAT_VLD_CAR );
            void set_COD_TRK_CAR( const std::string& a_COD_TRK_CAR );
            void set_COD_MOED( const std::string& a_COD_MOED );
            void set_COD_PAIS_CAR( const std::string& a_COD_PAIS_CAR );
            void set_COD_SERV_SNHA( const std::string& a_COD_SERV_SNHA );
            void set_IND_RD_ORG( const std::string& a_IND_RD_ORG );
            void set_COD_MOT_AUT( const std::string& a_COD_MOT_AUT );
            void set_DAT_PAUZ( dbm_datetime_t a_DAT_PAUZ );
            void set_COD_GRU_ESTB( unsigned long a_COD_GRU_ESTB );
            void set_COD_MTZ_ESTB( unsigned long a_COD_MTZ_ESTB );
            void set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN );
            void set_DTH_STTU_TRAN( dbm_datetime_t a_DTH_STTU_TRAN );
            void set_DTH_GMT( dbm_datetime_t a_DTH_GMT );
            void set_NUM_STAN( unsigned long a_NUM_STAN );
            void set_VAL_EFTV_CPTR( oasis_dec_t a_VAL_EFTV_CPTR );
            void set_QTD_PRCL_CNFR( unsigned long a_QTD_PRCL_CNFR );
            void set_IND_RD_CPTR( const std::string& a_IND_RD_CPTR );
            void set_COD_CNDC_CPTR( const std::string& a_COD_CNDC_CPTR );
            void set_DAT_CNFR_PAUZ( dbm_datetime_t a_DAT_CNFR_PAUZ );
            void set_VAL_TRAN_DLR( oasis_dec_t a_VAL_TRAN_DLR );
            void set_DAT_CAN_PAUZ( dbm_datetime_t a_DAT_CAN_PAUZ );
            void set_DAT_VLD_PAUZ( dbm_datetime_t a_DAT_VLD_PAUZ );
            void set_NOM_PORT_CAR( const std::string& a_NOM_PORT_CAR );
            void set_COD_MSG_ISO( unsigned long a_COD_MSG_ISO );
            void set_COD_PCM_ISO( unsigned long a_COD_PCM_ISO );
            void set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL );
            void set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL );
            void set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL );
            void set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR );
            void set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR );
            void set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR );
            void set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ );
            void set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ );
            void set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ );
            void set_COD_MOT_ISO_EMSR( const std::string& a_COD_MOT_ISO_EMSR );
            void set_COD_TERM_CNFR( const std::string& a_COD_TERM_CNFR );
            void set_DAT_MOV_TRAN_CNFR( unsigned long a_DAT_MOV_TRAN_CNFR );
            void set_DTH_CNFR( dbm_datetime_t a_DTH_CNFR );
            void set_IND_RD_ORG_ESTR( const std::string& a_IND_RD_ORG_ESTR );
            void set_IND_STTU_TRAN( const std::string& a_IND_STTU_TRAN );
            void set_NUM_EMSR( unsigned long a_NUM_EMSR );
            void set_NUM_ESTB_CNFR( unsigned long a_NUM_ESTB_CNFR );
            void set_NUM_ESTB_ESTR( unsigned long a_NUM_ESTB_ESTR );
            void set_NUM_ID_CAR( oasis_dec_t a_NUM_ID_CAR );
            void set_NUM_SEQ_UNC_CNFR( unsigned long a_NUM_SEQ_UNC_CNFR );
            void set_NUM_STAN_ORGL( unsigned long a_NUM_STAN_ORGL );
            void set_COD_BNDR( unsigned long a_COD_BNDR );
            void set_IND_EMSR_MTC( const std::string& a_IND_EMSR_MTC );

            void set_NUM_AVSO_AUT( const std::string& a_NUM_AVSO_AUT );
            void set_TXT_DA_ADIC_EMSR( const std::string& a_TXT_DA_ADIC_EMSR );
            void set_NOM_FNTS_PDV( const std::string& a_NOM_FNTS_PDV );
            void set_COD_PGM_AUT( const std::string& a_COD_PGM_AUT );
            void set_IND_NVL_SGRA_KMRC( const std::string& a_IND_NVL_SGRA_KMRC );
            void set_COD_UCAF( const std::string& a_COD_UCAF );
            void set_COD_AUT_EMSR_CNVT( const std::string& a_COD_AUT_EMSR_CNVT );
            void set_COD_AUT_EMSR( const std::string& a_COD_AUT_EMSR_CNVT );
            void set_NTWK_ID_ACQR_ATLZ(const std::string& a_NTWK_ID_ACQR_ATLZ);
            void set_NTWK_ID_ACQR_ORGL(const std::string& a_NTWK_ID_ACQR_ORGL);
            void set_NTWK_ID_ROUTE_ATLZ(const std::string& a_NTWK_ID_ROUTE_ATLZ);
            void set_NTWK_ID_ROUTE_ORGL(const std::string& a_NTWK_ID_ROUTE_ORGL);
            void set_NTWK_ID_ISSR_ATLZ(const std::string& a_NTWK_ID_ISSR_ATLZ);
            void set_NTWK_ID_ISSR_ORGL(const std::string& a_NTWK_ID_ISSR_ORGL);
            //void set_IND_CPTRDO( const std::string& a_IND_CPTRDO );   // 12.11.2013 - Removido no GAP3
            //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
            void set_COD_CTAH_VOCH( const std::string& a_COD_CTAH_VOCH );
            //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//
            void set_COD_TIP_PROD_CAR( const std::string& a_COD_TIP_PROD_CAR );   // GAP13.1
            void set_NUM_PDV_EXT( const std::string& a_NUM_PDV_EXT );
            void set_NUM_PDV_VAN( const std::string& a_NUM_PDV_VAN );
            void set_COD_GRU_CLAS_RAM( long a_COD_GRU_CLAS_RAM );
            void set_COD_CPCD_TERM( const std::string& a_COD_CPCD_TERM );
            void set_NUM_REF_TRAN( const std::string& a_NUM_REF_TRAN );
            void set_IND_TRAN_TKN( const std::string& a_IND_TRAN_TKN );
            /// Grava o Codigo de origem da transacao do Emissor
            /// DRS ID29728 - DP-2017-0043734 Release  Elo Abril 2018 SW75
            /// Historico: 03-05-2018 Valor respondido autorizador Elo Full conforme descricao do MER.
            void SetCodOrgAprv( const std::string& codigoOrigemAprovacaoParametro );
            void SetCodigoProdutoMastercard( const std::string& codigoProdutoMastercard ); /// COD_PROD_MTC
            void SetCodigoRegiaoMastercard( const std::string& codigoRegiaoMastercard ); /// COD_RGAO_MTC
            // R10_2018 - Release Outubro - INICIO 
            void SetPrintedCardSecurityCode(const std::string& value);
            // R10_2018 - Release Outubro - FIM
            void SetCodigoServicoCorporativo( unsigned long codServ );
            void SetCodigoSituacaoOferta( unsigned long situacao );

            unsigned long get_DAT_MOV_TRAN( ) const;
            unsigned long get_NUM_SEQ_UNC( ) const;
            unsigned long get_TIP_TRAN( ) const;
            unsigned long get_NUM_MOT_RSPS( ) const;
            unsigned long get_NUM_ESTB( ) const;
            const std::string& get_COD_TERM( ) const;
            unsigned long get_NUM_RD_ORG( ) const;
            const std::string& get_COD_POS_ENTR_MODO( ) const;
            unsigned long get_COD_EMSR( ) const;
            oasis_dec_t get_VAL_TRAN( ) const;
            unsigned long get_COD_RAM_ATVD( ) const;
            const std::string& get_NUM_CAR( ) const;
            const std::string& get_NUM_AUT( ) const;
            oasis_dec_t get_VAL_COT_DLR( ) const;
            sw_date_t get_DAT_VLD_CAR( ) const;
            const std::string& get_COD_TRK_CAR( ) const;
            const std::string& get_COD_MOED( ) const;
            const std::string& get_COD_PAIS_CAR( ) const;
            const std::string& get_COD_SERV_SNHA( ) const;
            const std::string& get_IND_RD_ORG( ) const;
            const std::string& get_COD_MOT_AUT( ) const;
            dbm_datetime_t get_DAT_PAUZ( ) const;
            unsigned long get_COD_GRU_ESTB( ) const;
            unsigned long get_COD_MTZ_ESTB( ) const;
            dbm_datetime_t get_DTH_INI_TRAN( ) const;
            dbm_datetime_t get_DTH_STTU_TRAN( ) const;
            dbm_datetime_t get_DTH_GMT( ) const;
            unsigned long get_NUM_STAN( ) const;
            oasis_dec_t get_VAL_EFTV_CPTR( ) const;
            unsigned long get_QTD_PRCL_CNFR( ) const;
            const std::string& get_IND_RD_CPTR( ) const;
            const std::string& get_COD_CNDC_CPTR( ) const;
            dbm_datetime_t get_DAT_CNFR_PAUZ( ) const;
            oasis_dec_t get_VAL_TRAN_DLR( ) const;
            dbm_datetime_t get_DAT_CAN_PAUZ( ) const;
            dbm_datetime_t get_DAT_VLD_PAUZ( ) const;
            const std::string& get_NOM_PORT_CAR( ) const;
            unsigned long get_COD_MSG_ISO( ) const;
            unsigned long get_COD_PCM_ISO( ) const;
            const std::string& get_NOM_SITE_ACQR_ORGL( ) const;
            const std::string& get_NOM_HOST_ACQR_ORGL( ) const;
            const std::string& get_NOM_FE_ACQR_ORGL( ) const;
            const std::string& get_NOM_SITE_ISSR( ) const;
            const std::string& get_NOM_HOST_ISSR( ) const;
            const std::string& get_NOM_FE_ISSR( ) const;
            const std::string& get_NOM_SITE_ACQR_ATLZ( ) const;
            const std::string& get_NOM_HOST_ACQR_ATLZ( ) const;
            const std::string& get_NOM_FE_ACQR_ATLZ( ) const;
            const std::string& get_COD_MOT_ISO_EMSR( ) const;
            const std::string& get_COD_TERM_CNFR( ) const;
            unsigned long get_DAT_MOV_TRAN_CNFR( ) const;
            dbm_datetime_t get_DTH_CNFR( ) const;
            const std::string& get_IND_RD_ORG_ESTR( ) const;
            const std::string& get_IND_STTU_TRAN( ) const;
            unsigned long get_NUM_EMSR( ) const;
            unsigned long get_NUM_ESTB_CNFR( ) const;
            unsigned long get_NUM_ESTB_ESTR( ) const;
            oasis_dec_t get_NUM_ID_CAR() const;
            unsigned long get_NUM_SEQ_UNC_CNFR( ) const;
            unsigned long get_NUM_STAN_ORGL( ) const;
            unsigned long get_COD_BNDR( ) const;
            const std::string& get_IND_EMSR_MTC( ) const;

            const std::string&  get_NUM_AVSO_AUT() const;
            const std::string&  get_TXT_DA_ADIC_EMSR() const;
            const std::string&  get_NOM_FNTS_PDV() const;
            const std::string&  get_COD_PGM_AUT() const;
            const std::string&  get_IND_NVL_SGRA_KMRC() const;
            const std::string&  get_COD_UCAF() const;
            const std::string&  get_COD_AUT_EMSR_CNVT() const;
            const std::string&  get_COD_AUT_EMSR() const;
            const std::string&  get_NTWK_ID_ACQR_ATLZ() const;
            const std::string&  get_NTWK_ID_ACQR_ORGL() const;
            const std::string&  get_NTWK_ID_ROUTE_ATLZ() const;
            const std::string&  get_NTWK_ID_ROUTE_ORGL() const;
            const std::string&  get_NTWK_ID_ISSR_ATLZ() const;
            const std::string&  get_NTWK_ID_ISSR_ORGL() const;
            //const std::string& get_IND_CPTRDO( ) const;   // 12.11.2013 - Removido no GAP3
            //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
            const std::string& get_COD_CTAH_VOCH( ) const;
            //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//
            const std::string& get_COD_TIP_PROD_CAR( ) const;   // GAP13.1
            const std::string& get_NUM_PDV_EXT( ) const;
            const std::string& get_NUM_PDV_VAN( ) const;
			long get_COD_GRU_CLAS_RAM( ) const;
            const std::string& get_COD_CPCD_TERM( ) const;
            const std::string& get_NUM_REF_TRAN( ) const;
            const std::string& get_IND_TRAN_TKN( ) const;
            /// GetCodOrgAprv
            /// Recupera o Codigo de origem da transacao do Emissor
            /// DRS ID29728 - DP-2017-0043734 Release  Elo Abril 2018 SW75
            /// Historico: 03-05-2018 Valor recuperado do banco de dados.
            const std::string& GetCodOrgAprv( ) const;
            const std::string& GetCodigoProdutoMastercard( ) const; /// COD_PROD_MTC
            const std::string& GetCodigoRegiaoMastercard( ) const; /// COD_RGAO_MTC
            // R10_2018 - Release Outubro - INICIO 
            const std::string& GetPrintedCardSecurityCode() const;
            // R10_2018 - Release Outubro - FIM

            unsigned long GetCodigoServicoCorporativo( );
            unsigned long GetCodigoSituacaoOferta( );

            // J4_2019 - Release Bandeiras Abril 2019 - INICIO
            void SetIndicadorPresencaPortador( const std::string& indicadorPresencaPortadorParametro );
            void SetIndicadorTecnologiaTerminal( const std::string& indicadorTecnologiaTerminalParametro );
            const std::string& GetIndicadorPresencaPortador( ) const;
            const std::string& GetIndicadorTecnologiaTerminal( ) const;
            // J4_2019 - Release Bandeiras Abril 2019 - FIM

            // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
            void SetCodigoProcessoEmissor( int codigoProcessoEmissor );
            int GetCodigoProcessoEmissor( ) const;
            // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM

            //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - INICIO
            void SetIdentificadorReferenciaBandeira( const std::string& idRefBandeira );
            const std::string& GetIdentificadorReferenciaBandeira( ) const;
            //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - FIM

			//cr689721@FIS - Data: 04/03/2015 - Ref. Mostrar o conteudo
			void showxxx( const char *name, unsigned long campo );
			void showxxx( const char *name, int campo );
			void showxxx( const char *name, dbm_datetime_t campo );
			void showxxx( const char *name, const std::string& campo );
			void showxxx( const char *name, oasis_dec_t campo );
			void show(int nvl);

			void let_as_is( );
        private:
            // NUM_SEQ_UNC                    NOT NULL NUMBER(12)     
            // VAL_TRAN                       NOT NULL NUMBER(13,2)         
            // VAL_COT_DLR                             NUMBER(13,4)          
            // COD_GRU_ESTB                   NOT NULL NUMBER(12)    
            // COD_MTZ_ESTB                   NOT NULL NUMBER(12)           
            // NUM_STAN                       NOT NULL NUMBER(12)    
            // VAL_EFTV_CPTR                           NUMBER(13,2)          
            // VAL_TRAN_DLR                            NUMBER(13,2)     
            // NUM_ID_CAR                              NUMBER(11)    
            // NUM_SEQ_UNC_CNFR                        NUMBER(12)    
            // NUM_STAN_ORGL                           NUMBER(12) 

            unsigned long    m_DAT_MOV_TRAN;
            unsigned long    m_NUM_SEQ_UNC;
            unsigned long    m_TIP_TRAN;
            unsigned long    m_NUM_MOT_RSPS;
            unsigned long    m_NUM_ESTB;
            std::string      m_COD_TERM;
            unsigned long    m_NUM_RD_ORG;
            std::string      m_COD_POS_ENTR_MODO;
            unsigned long    m_COD_EMSR;
            oasis_dec_t      m_VAL_TRAN;
            unsigned long    m_COD_RAM_ATVD;
            std::string      m_NUM_CAR;
            std::string      m_NUM_AUT;
            oasis_dec_t      m_VAL_COT_DLR;
            sw_date_t        m_DAT_VLD_CAR;
            std::string      m_COD_TRK_CAR;
            std::string      m_COD_MOED;
            std::string      m_COD_PAIS_CAR;
            std::string      m_COD_SERV_SNHA;
            std::string      m_IND_RD_ORG;
            std::string      m_COD_MOT_AUT;
            dbm_datetime_t   m_DAT_PAUZ;
            unsigned long      m_COD_GRU_ESTB;
            unsigned long      m_COD_MTZ_ESTB;
            dbm_datetime_t   m_DTH_INI_TRAN;
            dbm_datetime_t   m_DTH_STTU_TRAN;
            dbm_datetime_t   m_DTH_GMT;
            unsigned long   m_NUM_STAN;
            oasis_dec_t      m_VAL_EFTV_CPTR;
            unsigned long    m_QTD_PRCL_CNFR;
            std::string      m_IND_RD_CPTR;
            std::string      m_COD_CNDC_CPTR;
            dbm_datetime_t   m_DAT_CNFR_PAUZ;
            oasis_dec_t      m_VAL_TRAN_DLR;
            dbm_datetime_t   m_DAT_CAN_PAUZ;
            dbm_datetime_t   m_DAT_VLD_PAUZ;
            std::string      m_NOM_PORT_CAR;
            unsigned long    m_COD_MSG_ISO;
            unsigned long    m_COD_PCM_ISO;
            std::string      m_NOM_SITE_ACQR_ORGL;
            std::string      m_NOM_HOST_ACQR_ORGL;
            std::string      m_NOM_FE_ACQR_ORGL;
            std::string      m_NOM_SITE_ISSR;
            std::string      m_NOM_HOST_ISSR;
            std::string      m_NOM_FE_ISSR;
            std::string      m_NOM_SITE_ACQR_ATLZ;
            std::string      m_NOM_HOST_ACQR_ATLZ;
            std::string      m_NOM_FE_ACQR_ATLZ;
            std::string      m_COD_MOT_ISO_EMSR;
            std::string      m_COD_TERM_CNFR;
            unsigned long    m_DAT_MOV_TRAN_CNFR;
            dbm_datetime_t   m_DTH_CNFR;
            std::string      m_IND_RD_ORG_ESTR;
            std::string      m_IND_STTU_TRAN;
            unsigned long    m_NUM_EMSR;
            unsigned long    m_NUM_ESTB_CNFR;
            unsigned long    m_NUM_ESTB_ESTR;
            oasis_dec_t      m_NUM_ID_CAR;
            unsigned long    m_NUM_SEQ_UNC_CNFR;
            unsigned long    m_NUM_STAN_ORGL;
            unsigned long    m_COD_BNDR;
            std::string      m_IND_EMSR_MTC;

            std::string      m_NUM_AVSO_AUT;
            std::string      m_TXT_DA_ADIC_EMSR;
            std::string      m_NOM_FNTS_PDV;
            std::string      m_COD_PGM_AUT;
            std::string      m_IND_NVL_SGRA_KMRC;
            std::string      m_COD_UCAF;
            std::string      m_COD_AUT_EMSR_CNVT;
            std::string      m_COD_AUT_EMSR;
            std::string      m_NTWK_ID_ACQR_ATLZ;
            std::string      m_NTWK_ID_ACQR_ORGL;
            std::string      m_NTWK_ID_ROUTE_ATLZ;
            std::string      m_NTWK_ID_ROUTE_ORGL;
            std::string      m_NTWK_ID_ISSR_ATLZ;
            std::string      m_NTWK_ID_ISSR_ORGL;
            //std::string      m_IND_CPTRDO;    // 12.11.2013 - Removido no GAP3
            //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
            std::string      m_COD_CTAH_VOCH;
            //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//
            std::string      m_COD_TIP_PROD_CAR;   // GAP13.1
            std::string      m_NUM_PDV_EXT;
            std::string      m_NUM_PDV_VAN;
            long             m_COD_GRU_CLAS_RAM;
            std::string      m_COD_CPCD_TERM;
            std::string      m_NUM_REF_TRAN;
            std::string      m_IND_TRAN_TKN;
            std::string      codigoOrigemAprovacao;
            std::string      codigoProdutoMastercard; /// COD_PROD_MTC
            std::string      codigoRegiaoMastercard; /// COD_RGAO_MTC
            // R10_2018 - Release Outubro - INICIO 
            std::string     printedCardSecurityCode;
            // R10_2018 - Release Outubro - FIM
            unsigned long    codigoServicoCorporativo;
            unsigned long    codigoSituacaoOferta;
            
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_TIP_TRAN_pos;
            int m_NUM_MOT_RSPS_pos;
            int m_NUM_ESTB_pos;
            int m_COD_TERM_pos;
            int m_NUM_RD_ORG_pos;
            int m_COD_POS_ENTR_MODO_pos;
            int m_COD_EMSR_pos;
            int m_VAL_TRAN_pos;
            int m_COD_RAM_ATVD_pos;
            int m_NUM_CAR_pos;
            int m_NUM_AUT_pos;
            int m_VAL_COT_DLR_pos;
            int m_DAT_VLD_CAR_pos;
            int m_COD_TRK_CAR_pos;
            int m_COD_MOED_pos;
            int m_COD_PAIS_CAR_pos;
            int m_COD_SERV_SNHA_pos;
            int m_IND_RD_ORG_pos;
            int m_COD_MOT_AUT_pos;
            int m_DAT_PAUZ_pos;
            int m_COD_GRU_ESTB_pos;
            int m_COD_MTZ_ESTB_pos;
            int m_DTH_INI_TRAN_pos;
            int m_DTH_STTU_TRAN_pos;
            int m_DTH_GMT_pos;
            int m_NUM_STAN_pos;
            int m_VAL_EFTV_CPTR_pos;
            int m_QTD_PRCL_CNFR_pos;
            int m_IND_RD_CPTR_pos;
            int m_COD_CNDC_CPTR_pos;
            int m_DAT_CNFR_PAUZ_pos;
            int m_VAL_TRAN_DLR_pos;
            int m_DAT_CAN_PAUZ_pos;
            int m_DAT_VLD_PAUZ_pos;
            int m_NOM_PORT_CAR_pos;
            int m_COD_MSG_ISO_pos;
            int m_COD_PCM_ISO_pos;
            int m_NOM_SITE_ACQR_ORGL_pos;
            int m_NOM_HOST_ACQR_ORGL_pos;
            int m_NOM_FE_ACQR_ORGL_pos;
            int m_NOM_SITE_ISSR_pos;
            int m_NOM_HOST_ISSR_pos;
            int m_NOM_FE_ISSR_pos;
            int m_NOM_SITE_ACQR_ATLZ_pos;
            int m_NOM_HOST_ACQR_ATLZ_pos;
            int m_NOM_FE_ACQR_ATLZ_pos;
            int m_COD_MOT_ISO_EMSR_pos;
            int m_COD_TERM_CNFR_pos;
            int m_DAT_MOV_TRAN_CNFR_pos;
            int m_DTH_CNFR_pos;
            int m_IND_RD_ORG_ESTR_pos;
            int m_IND_STTU_TRAN_pos;
            int m_NUM_EMSR_pos;
            int m_NUM_ESTB_CNFR_pos;
            int m_NUM_ESTB_ESTR_pos;
            int m_NUM_ID_CAR_pos;
            int m_NUM_SEQ_UNC_CNFR_pos;
            int m_NUM_STAN_ORGL_pos;
            int m_COD_BNDR_pos;
            int m_IND_EMSR_MTC_pos;
            int m_IND_TRAN_TKN_pos;
            int codigoOrigemAprovacaoPos;
            int codigoProdutoMastercardPos; /// COD_PROD_MTC
            int codigoRegiaoMastercardPos;  /// COD_RGAO_MTC

            int m_NUM_AVSO_AUT_pos;
            int m_TXT_DA_ADIC_EMSR_pos;
            int m_NOM_FNTS_PDV_pos;
            int m_COD_PGM_AUT_pos;
            int m_IND_NVL_SGRA_KMRC_pos;
            int m_COD_UCAF_pos;
            int m_COD_AUT_EMSR_CNVT_pos;
            int m_COD_AUT_EMSR_pos;
            int m_NTWK_ID_ACQR_ATLZ_pos;
            int m_NTWK_ID_ACQR_ORGL_pos;
            int m_NTWK_ID_ROUTE_ATLZ_pos;
            int m_NTWK_ID_ROUTE_ORGL_pos;
            int m_NTWK_ID_ISSR_ATLZ_pos;
            int m_NTWK_ID_ISSR_ORGL_pos;
            //int m_IND_CPTRDO_pos; // 12.11.2013 - Removido no GAP3
            //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
            int m_COD_CTAH_VOCH_pos;
            //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//
            int m_COD_TIP_PROD_CAR_pos;   // GAP13.1
            int m_NUM_PDV_EXT_pos;
            int m_NUM_PDV_VAN_pos;
            int m_COD_GRU_CLAS_RAM_pos;
            int m_COD_CPCD_TERM_pos;
            int m_NUM_REF_TRAN_pos;
            // R10_2018 - Release Outubro - INICIO 
            int printedCardSecurityCodePosicao;
            // R10_2018 - Release Outubro - FIM

            int codigoServicoCorporativoPos;
            int codigoSituacaoOfertaPos;
            
            int m_DAT_CNFR_PAUZ_ind_null;
            int m_DAT_CAN_PAUZ_ind_null;
            int m_DTH_CNFR_ind_null;
            int m_NUM_ESTB_CNFR_ind_null;
            int m_QTD_PRCL_CNFR_ind_null;
            int m_VAL_EFTV_CPTR_ind_null;
            int m_NUM_SEQ_UNC_CNFR_ind_null;
            int m_DAT_MOV_TRAN_CNFR_ind_null;
            int m_NUM_ID_CAR_ind_null;
            int m_IND_RD_CPTR_ind_null;
            int m_VAL_TRAN_DLR_ind_null;

            // t689049@FIS - Data: 26/06/2014 - Ref BT 63.966
            int m_NUM_ESTB_ESTR_ind_null;

            // t689049@FIS - Data: 23/09/2014 - Ref. Iniciar com NULL.
            int m_NUM_STAN_ORGL_ind_null;
			
			//cr689721@FIS - Data: 05/03/2015
			logger::DebugWriter *m_log;
            
            void initialize();

            // J4_2019 - Release Bandeiras Abril 2019 - INICIO
            std::string         indicadorPresencaPortador;     // COD_PORT_PRES_VLDC_BNDR
            int posicaoIndicadorPresencaPortador;
            std::string         indicadorTecnologiaTerminal;   // COD_CPCD_TERM_VLDC_BNDR
            int posicaoIndicadorTecnologiaTerminal;
            // J4_2019 - Release Bandeiras Abril 2019 - FIM

            // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
            int codigoProcessoEmissor;
            int codigoProcessoEmissorPos;
            int codigoProcessoEmissorIndNull;
            // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM

            //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - INICIO
            std::string identificadorReferenciaBandeira;
            int identificadorReferenciaBandeiraPos;
            //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - FIM
    };
} //namespace dbaccess_common


