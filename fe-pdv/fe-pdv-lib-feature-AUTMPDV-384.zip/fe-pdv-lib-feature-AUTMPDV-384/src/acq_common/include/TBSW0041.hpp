/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_common
{
	class TBSW0041 : public dbaccess::table
	{
	public:
		TBSW0041( );
		TBSW0041( const std::string &str );
		virtual ~TBSW0041( );
		void bind_columns( );
		long getNUM_PDV( ) const;
		long getCOD_BNDR( ) const;
		long getQTD_MXO_PRCL( ) const;
		const std::string getCOD_STTU_REG( ) const;
		const dbm_datetime_t getDAT_ATLZ_REG( ) const;
		long getCOD_BCO_CMPS( ) const;
		long getCOD_AGE( ) const;
		const std::string getNUM_CTA_BNCR( ) const;
		const dbm_datetime_t getDAT_INI_COB_ANT( ) const;
		const dbm_datetime_t getDAT_INI_COB_ATU( ) const;
		const std::string getTIP_COB_TRAN_ANT( ) const;
		const std::string getTIP_COB_TRAN_ATU( ) const;
		const oasis_dec_t getVAL_COB_TRAN_ANT( ) const;
		const oasis_dec_t getVAL_COB_TRAN_ATU( ) const;
		long getCOD_TRAN( ) const;
		const std::string getIND_PERM_TRAN_DGTD_EMSR( ) const;
		const std::string getIND_MODL_CPTR( ) const;
		const std::string getIND_PART_PROD_FLEX( ) const;
		void setNUM_PDV( long a_NUM_PDV );
		void setCOD_BNDR( long a_COD_BNDR );
		void setQTD_MXO_PRCL( long a_QTD_MXO_PRCL );
		void setCOD_STTU_REG( const std::string& a_COD_STTU_REG );
		void setDAT_ATLZ_REG( const dbm_datetime_t a_DAT_ATLZ_REG );
		void setCOD_BCO_CMPS( long a_COD_BCO_CMPS );
		void setCOD_AGE( long a_COD_AGE );
		void setNUM_CTA_BNCR( const std::string& a_NUM_CTA_BNCR );
		void setDAT_INI_COB_ANT( const dbm_datetime_t a_DAT_INI_COB_ANT );
		void setDAT_INI_COB_ATU( const dbm_datetime_t a_DAT_INI_COB_ATU );
		void setTIP_COB_TRAN_ANT( const std::string& a_TIP_COB_TRAN_ANT );
		void setTIP_COB_TRAN_ATU( const std::string& a_TIP_COB_TRAN_ATU );
		void setVAL_COB_TRAN_ANT( oasis_dec_t a_VAL_COB_TRAN_ANT );
		void setVAL_COB_TRAN_ATU( oasis_dec_t a_VAL_COB_TRAN_ATU );
		void setCOD_TRAN( long a_COD_TRAN );
		void setIND_PERM_TRAN_DGTD_EMSR( const std::string& a_IND_PERM_TRAN_DGTD_EMSR );
		void setIND_MODL_CPTR( const std::string& a_IND_MODL_CPTR );
		void setIND_PART_PROD_FLEX( const std::string& a_IND_PART_PROD_FLEX );
	private:
		int m_NUM_PDV_pos;
		int m_COD_BNDR_pos;
		int m_QTD_MXO_PRCL_pos;
		int m_COD_STTU_REG_pos;
		int m_DAT_ATLZ_REG_pos;
		int m_COD_BCO_CMPS_pos;
		int m_COD_AGE_pos;
		int m_NUM_CTA_BNCR_pos;
		int m_DAT_INI_COB_ANT_pos;
		int m_DAT_INI_COB_ATU_pos;
		int m_TIP_COB_TRAN_ANT_pos;
		int m_TIP_COB_TRAN_ATU_pos;
		int m_VAL_COB_TRAN_ANT_pos;
		int m_VAL_COB_TRAN_ATU_pos;
		int m_COD_TRAN_pos;
		int m_IND_PERM_TRAN_DGTD_EMSR_pos;
		int m_IND_MODL_CPTR_pos;
		int m_IND_PART_PROD_FLEX_pos;
		long  m_NUM_PDV;
		long  m_COD_BNDR;
		long  m_QTD_MXO_PRCL;
		std::string    m_COD_STTU_REG;
		dbm_datetime_t m_DAT_ATLZ_REG;
		long  m_COD_BCO_CMPS;
		long  m_COD_AGE;
		std::string    m_NUM_CTA_BNCR;
		dbm_datetime_t m_DAT_INI_COB_ANT;
		dbm_datetime_t m_DAT_INI_COB_ATU;
		std::string    m_TIP_COB_TRAN_ANT;
		std::string    m_TIP_COB_TRAN_ATU;
		oasis_dec_t    m_VAL_COB_TRAN_ANT;
		oasis_dec_t    m_VAL_COB_TRAN_ATU;
		long  m_COD_TRAN;
		std::string    m_IND_PERM_TRAN_DGTD_EMSR;
		std::string    m_IND_MODL_CPTR;
		std::string    m_IND_PART_PROD_FLEX;
	};
}

