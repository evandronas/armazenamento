#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0042 : public dbaccess::table
    {
        public:
            TBSW0042();
            TBSW0042( const std::string& whereClause );
            ~TBSW0042();

            void bind_columns();

            void set_COD_TERM( const std::string& a_COD_TERM );
            void set_NUM_PDV( unsigned long a_NUM_PDV );
            void set_COD_STTU_REG( const std::string& a_COD_STTU_REG );
            void set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG );
            void set_COD_PSSE_TERM( unsigned long a_COD_PSSE_TERM );
            void set_COD_SIT_TERM( const std::string& a_COD_SIT_TERM );
            void set_COD_PRDC_TERM( unsigned long a_COD_PRDC_TERM );
            void set_IND_ATIN( const std::string& a_IND_ATIN );
            void set_IND_ATCG( const std::string& a_IND_ATCG );
            void set_IND_UTLZ_PNPD( const std::string& a_IND_UTLZ_PNPD );
            void set_IND_TRAN_DGTD( const std::string& a_IND_TRAN_DGTD );
            void set_COD_VERS_SFTW( unsigned long a_COD_VERS_SFTW );
            void set_COD_VERS_DLL( unsigned long a_COD_VERS_DLL );
            void set_COD_TCNL( unsigned long a_COD_TCNL );
            void set_SGL_TCNL( const std::string& a_SGL_TCNL );
            void set_TIP_LGCO( unsigned long a_TIP_LGCO );
            void set_IND_TERM_BLQD( const std::string& a_IND_TERM_BLQD );
            void set_TIP_TERM( const std::string& a_TIP_TERM );
            void set_TIP_EQPM( const std::string& a_TIP_EQPM );
            void set_IND_TRAN_CHIP( const std::string& a_IND_TRAN_CHIP );
            void set_IND_TERM_LTRO_CHIP( const std::string& a_IND_TERM_LTRO_CHIP );
            void set_DAT_ATCG( dbm_datetime_t a_DAT_ATCG );
            void set_IND_TERM_FATR_EXPS( const std::string& a_IND_TERM_FATR_EXPS );
            void set_QTD_HOR_INTV( unsigned long a_QTD_HOR_INTV );
			void set_NUM_SRE_TERM( const std::string& a_NUM_SRE_TERM );
			void set_COD_VERS_SFTW_POS( const std::string& a_COD_VERS_SFTW_POS );

            const std::string& get_COD_TERM() const;
            unsigned long get_NUM_PDV() const;
            const std::string& get_COD_STTU_REG() const;
            dbm_datetime_t get_DAT_ATLZ_REG() const;
            unsigned long get_COD_PSSE_TERM() const;
            const std::string& get_COD_SIT_TERM() const;
            unsigned long get_COD_PRDC_TERM() const;
            const std::string& get_IND_ATIN() const;
            const std::string& get_IND_ATCG() const;
            const std::string& get_IND_UTLZ_PNPD() const;
            const std::string& get_IND_TRAN_DGTD() const;
            unsigned long get_COD_VERS_SFTW() const;
            unsigned long get_COD_VERS_DLL() const;
            unsigned long get_COD_TCNL() const;
            const std::string& get_SGL_TCNL() const;
            unsigned long get_TIP_LGCO() const;
            const std::string& get_IND_TERM_BLQD() const;
            const std::string& get_TIP_TERM() const;
            const std::string& get_TIP_EQPM() const;
            const std::string& get_IND_TRAN_CHIP() const;
            const std::string& get_IND_TERM_LTRO_CHIP() const;
            dbm_datetime_t get_DAT_ATCG() const;
            const std::string& get_IND_TERM_FATR_EXPS() const;
            unsigned long get_QTD_HOR_INTV() const;
			const std::string& get_NUM_SRE_TERM() const;
			const std::string& get_COD_VERS_SFTW_POS() const;
            
        private:
            std::string				m_COD_TERM;
            unsigned long           m_NUM_PDV;
            std::string				m_COD_STTU_REG;
            dbm_datetime_t          m_DAT_ATLZ_REG;
            unsigned long           m_COD_PSSE_TERM;
            std::string				m_COD_SIT_TERM;
            unsigned long           m_COD_PRDC_TERM;
            std::string				m_IND_ATIN;
            std::string				m_IND_ATCG;
            std::string				m_IND_UTLZ_PNPD;
            std::string				m_IND_TRAN_DGTD;
            unsigned long           m_COD_VERS_SFTW;
            unsigned long           m_COD_VERS_DLL;
            unsigned long           m_COD_TCNL;
            std::string				m_SGL_TCNL;
            unsigned long           m_TIP_LGCO;
            std::string				m_IND_TERM_BLQD;
            std::string				m_TIP_TERM;
            std::string				m_TIP_EQPM;
            std::string				m_IND_TRAN_CHIP;
            std::string				m_IND_TERM_LTRO_CHIP;
            dbm_datetime_t          m_DAT_ATCG;
            std::string				m_IND_TERM_FATR_EXPS;
            unsigned long           m_QTD_HOR_INTV;
			std::string				m_NUM_SRE_TERM;
			std::string				m_COD_VERS_SFTW_POS;
            
            int m_COD_TERM_pos;
            int m_NUM_PDV_pos;
            int m_COD_STTU_REG_pos;
            int m_DAT_ATLZ_REG_pos;
            int m_COD_PSSE_TERM_pos;
            int m_COD_SIT_TERM_pos;
            int m_COD_PRDC_TERM_pos;
            int m_IND_ATIN_pos;
            int m_IND_ATCG_pos;
            int m_IND_UTLZ_PNPD_pos;
            int m_IND_TRAN_DGTD_pos;
            int m_COD_VERS_SFTW_pos;
            int m_COD_VERS_DLL_pos;
            int m_COD_TCNL_pos;
            int m_SGL_TCNL_pos;
            int m_TIP_LGCO_pos;
            int m_IND_TERM_BLQD_pos;
            int m_TIP_TERM_pos;
            int m_TIP_EQPM_pos;
            int m_IND_TRAN_CHIP_pos;
            int m_IND_TERM_LTRO_CHIP_pos;
            int m_DAT_ATCG_pos;
            int m_IND_TERM_FATR_EXPS_pos;
            int m_QTD_HOR_INTV_pos;
			int m_NUM_SRE_TERM_pos;		
			int m_COD_VERS_SFTW_POS_pos;		
    };
} //namespace dbaccess_common

