#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_common
{
    class TBSW0030 : public dbaccess::table
    {

    public:

        TBSW0030();
        TBSW0030( const std::string& whereClause );
        ~TBSW0030();

        void initialize();
        void bind_columns();

        void setWhereClause( const std::string& a_whereClause );
        void setDualSelect( );
        void unsetDualSelect( );

        void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
        void set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC );
        void set_DTH_GMT( dbm_datetime_t a_DTH_GMT );
        void set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN );
        void set_DAT_CTB_TRAN( dbm_datetime_t a_DAT_CTB_TRAN );
        void set_COD_MSG_ISO( unsigned long a_COD_MSG_ISO );
        void set_COD_PCM_ISO( unsigned long a_COD_PCM_ISO );
        void set_TIP_TRAN( unsigned long a_TIP_TRAN );
        void set_TIP_DTLH_TRAN( const std::string& a_TIP_DTLH_TRAN );
        void set_TIP_VD( const std::string& a_TIP_VD );
        void set_TIP_PLN_PGMN( unsigned long a_TIP_PLN_PGMN );
        void set_COD_CTGR_TRAN( const std::string& a_COD_CTGR_TRAN );
        void set_COD_CMPM_TRAN( unsigned long a_COD_CMPM_TRAN );
        void set_NUM_RD_ORG( unsigned long a_NUM_RD_ORG );
        void set_NUM_ESTB( unsigned long a_NUM_ESTB );
        void set_COD_TERM( const std::string& a_COD_TERM );
        void set_NUM_STAN( unsigned long a_NUM_STAN );
        void set_TIP_TCNL( const std::string& a_TIP_TCNL );
        void set_TIP_TERM( const std::string& a_TIP_TERM );
        void set_COD_RAM_ATVD( unsigned long a_COD_RAM_ATVD );
        void set_COD_POS_ENTR_MODO( const std::string& a_COD_POS_ENTR_MODO );
        void set_COD_BNDR( unsigned long a_COD_BNDR );
        void set_COD_EMSR( unsigned long a_COD_EMSR );
        void set_NUM_EMSR( unsigned long a_NUM_EMSR );
        void set_NUM_ID_CAR( oasis_dec_t a_NUM_ID_CAR );
        void set_COD_PAIS_CAR( const std::string& a_COD_PAIS_CAR );
        void set_NUM_CAR( const std::string& a_NUM_CAR );
        void set_DAT_VLD_CAR( sw_date_t a_DAT_VLD_CAR );
        void set_IND_TRK( const std::string& a_IND_TRK );
        void set_IND_CPTR_CVC_2( const std::string& a_IND_CPTR_CVC_2 );
        void set_NUM_CVC_2( unsigned long a_NUM_CVC_2 );
        void set_COD_TRK_CAR( const std::string& a_COD_TRK_CAR );
        void set_COD_SERV( const std::string& a_COD_SERV );
        void set_COD_SERV_SNHA( const std::string& a_COD_SERV_SNHA );
        void set_IND_ID_PREV( unsigned long a_IND_ID_PREV );
        void set_VAL_TRAN( oasis_dec_t a_VAL_TRAN );
        void set_VAL_TOTL_TRAN( oasis_dec_t a_VAL_TOTL_TRAN );
        void set_COD_MOED( const std::string& a_COD_MOED );
        void set_NUM_CV( unsigned long a_NUM_CV );
        void set_NUM_AUT( const std::string& a_NUM_AUT );
        void set_COD_MOT_AUT( const std::string& a_COD_MOT_AUT );
        void set_NUM_MOT_RSPS( unsigned long a_NUM_MOT_RSPS );
        void set_COD_MOT_RSPS_EXT( const std::string& a_COD_MOT_RSPS_EXT );
        void set_COD_MOT_SW( const std::string& a_COD_MOT_SW );
        void set_IND_STTU_TRAN( const std::string& a_IND_STTU_TRAN );
        void set_DTH_STTU_TRAN( dbm_datetime_t a_DTH_STTU_TRAN );
        void set_COD_PROD( const std::string& a_COD_PROD );
        void set_NUM_RSMO_VD( unsigned long a_NUM_RSMO_VD );
        void set_DAT_RSMO_VD( dbm_datetime_t a_DAT_RSMO_VD );
        void set_NOM_LOC_ESTB( const std::string& a_NOM_LOC_ESTB );
        void set_IND_TERM_RLCD_CHIP( const std::string& a_IND_TERM_RLCD_CHIP );
        void set_IND_DFZM( const std::string& a_IND_DFZM );
        void set_IND_ESTR( const std::string& a_IND_ESTR );
        void set_IND_CPTRDO( const std::string& a_IND_CPTRDO );
        void set_IND_AGND_TRAN( const std::string& a_IND_AGND_TRAN );
        void set_IND_IMPR_CPOM( const std::string& a_IND_IMPR_CPOM );
        void set_IND_EMSR_MTC( const std::string& a_IND_EMSR_MTC );
        void set_IND_DA_RLCD_CHIP( const std::string& a_IND_DA_RLCD_CHIP );
        void set_IND_DA_RLCD_IATA( const std::string& a_IND_DA_RLCD_IATA );
        void set_IND_TRAN_REFD( const std::string& a_IND_TRAN_REFD );
        void set_TIP_TRAN_ORGL( unsigned long a_TIP_TRAN_ORGL );
        void set_DAT_EXPC_TRAN( dbm_datetime_t a_DAT_EXPC_TRAN );
        void set_VAL_TRAN_DLR( oasis_dec_t a_VAL_TRAN_DLR );
        void set_VAL_COT_DLR( oasis_dec_t a_VAL_COT_DLR );
        void set_COD_CTR( const std::string& a_COD_CTR );
        void set_VAL_TX( oasis_dec_t a_VAL_TX );
        void set_COD_REF_RESTANTE( const std::string& a_COD_REF_RESTANTE );
        void set_COD_CNDC_CPTR_PAUZ( const std::string& a_COD_CNDC_CPTR_PAUZ );
        void set_TIP_ENT_PAUZ( const std::string& a_TIP_ENT_PAUZ );
        void set_COD_OPER_CNFR( const std::string& a_COD_OPER_CNFR );
        void set_PRCN_TX_RISC( oasis_dec_t a_PRCN_TX_RISC );
        void set_VAL_TX_RISC( oasis_dec_t a_VAL_TX_RISC );
        void set_COD_CNDC_CPTR( const std::string& a_COD_CNDC_CPTR );
        void set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL );
        void set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL );
        void set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL );
        void set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR );
        void set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR );
        void set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR );
        void set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ );
        void set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ );
        void set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ );
        void set_TXT_DA_ADIC_EMSR( const std::string& a_TXT_DA_ADIC_EMSR );
        void set_TIP_MODL_CPTR( const std::string& a_TIP_MODL_CPTR );
        void set_DTH_TRAN_EMSR( dbm_datetime_t a_DTH_TRAN_EMSR );
        void set_DAT_LQDC_EMSR( dbm_datetime_t a_DAT_LQDC_EMSR );
        void set_COD_ISTT_ACQR( unsigned long a_COD_ISTT_ACQR );
        void set_COD_ISTT_FRWD( unsigned long a_COD_ISTT_FRWD );
        void set_COD_RSPS_DTLH_EMSR( unsigned long a_COD_RSPS_DTLH_EMSR );
        void set_COD_RSTD_NUM_CVC_2( const std::string& a_COD_RSTD_NUM_CVC_2 );
        void set_COD_SERV_TRK_CAR( unsigned long a_COD_SERV_TRK_CAR );
        void set_COD_VLDC_EMSR( const std::string& a_COD_VLDC_EMSR );
        void set_IND_AUT( const std::string& a_IND_AUT );
        void set_IND_DA_RLCD_KMRC( const std::string& a_IND_DA_RLCD_KMRC );
        void set_IND_TRAN_SEM_ORGL( const std::string& a_IND_TRAN_SEM_ORGL );
        void set_DAT_PAUZ( dbm_datetime_t a_DAT_PAUZ );
        void set_NUM_SEQ_UNC_PAUZ( unsigned long a_NUM_SEQ_UNC_PAUZ );
        void set_COD_TRAN_CAD( unsigned long a_COD_TRAN_CAD );
        void set_COD_AUT_EMSR( const std::string& a_COD_AUT_EMSR );
        void set_COD_NTWK_ID_ACQR_ATLZ( const std::string& a_COD_NTWK_ID_ACQR_ATLZ );
        void set_COD_NTWK_ID_ACQR_ORGL( const std::string& a_NTWK_ID_ACQR_ORGL );
        void set_COD_NTWK_ID_ROUT_ATLZ( const std::string& a_COD_NTWK_ID_ROUT_ATLZ );
        void set_COD_NTWK_ID_ROUT_ORGL( const std::string& a_NTWK_ID_ROUT_ORGL );
        void set_COD_NTWK_ID_ISSR_ATLZ( const std::string& a_COD_NTWK_ID_ISSR_ATLZ );
        void set_COD_NTWK_ID_ISSR_ORGL( const std::string& a_NTWK_ID_ISSR_ORGL );
        void set_COD_RAM_MCC( const std::string& a_COD_RAM_MCC );
        void set_COD_CNDC_CPTR_EMSR( const std::string& a_COD_CNDC_CPTR_EMSR );
        void set_COD_PROD_CDST( unsigned long a_COD_PROD_CDST );
        void set_COD_SERV_CORP( unsigned long a_COD_SERV_CORP );
        void set_COD_EMP_ADQT( unsigned long a_COD_EMP_ADQT );
        void set_NUM_PDV_EXT( const std::string& a_NUM_PDV_EXT );
        void set_NUM_PDV_VAN( const std::string& a_NUM_PDV_VAN );
        void set_COD_DSPO_NFC( const std::string& a_COD_DSPO_NFC );
        void set_COD_PROD_PRCR(unsigned long a_COD_PROD_PRCR );
        void set_COD_GRU_CLAS_RAM( long a_COD_GRU_CLAS_RAM );
        void set_IND_TRAN_TKN( const std::string& a_IND_TRAN_TKN );
        /// SetCodOrgAprv
        /// Grava o Codigo de origem da transacao do Emissor
        /// DRS ID29728 - DP-2017-0043734 Release  Elo Abril 2018 SW75
        /// Historico: 03-05-2018 Valor respondido autorizador Elo Full conforme descricao do MER.
        void SetCodOrgAprv( const std::string& codigoOrigemAprovacaoParametro );
        void SetSituacaoOferta( unsigned long sitOferta );

        unsigned long get_DAT_MOV_TRAN() const;
        unsigned long get_NUM_SEQ_UNC() const;
        dbm_datetime_t get_DTH_GMT() const;
        dbm_datetime_t get_DTH_INI_TRAN() const;
        dbm_datetime_t get_DAT_CTB_TRAN() const;
        unsigned long get_COD_MSG_ISO() const;
        unsigned long get_COD_PCM_ISO() const;
        unsigned long get_TIP_TRAN() const;
        const std::string& get_TIP_DTLH_TRAN() const;
        const std::string& get_TIP_VD() const;
        unsigned long get_TIP_PLN_PGMN() const;
        const std::string& get_COD_CTGR_TRAN() const;
        unsigned long get_COD_CMPM_TRAN() const;
        unsigned long get_NUM_RD_ORG() const;
        unsigned long get_NUM_ESTB() const;
        const std::string& get_COD_TERM() const;
        unsigned long get_NUM_STAN() const;
        const std::string& get_TIP_TCNL() const;
        const std::string& get_TIP_TERM() const;
        unsigned long get_COD_RAM_ATVD() const;
        const std::string& get_COD_POS_ENTR_MODO() const;
        unsigned long get_COD_BNDR() const;
        unsigned long get_COD_EMSR() const;
        unsigned long get_NUM_EMSR() const;
        oasis_dec_t get_NUM_ID_CAR() const;
        const std::string& get_COD_PAIS_CAR() const;
        const std::string& get_NUM_CAR() const;
        sw_date_t get_DAT_VLD_CAR() const;
        const std::string& get_IND_TRK() const;
        const std::string& get_IND_CPTR_CVC_2() const;
        unsigned long get_NUM_CVC_2() const;
        const std::string& get_COD_TRK_CAR() const;
        const std::string& get_COD_SERV() const;
        const std::string& get_COD_SERV_SNHA() const;
        unsigned long get_IND_ID_PREV() const;
        oasis_dec_t get_VAL_TRAN() const;
        oasis_dec_t get_VAL_TOTL_TRAN() const;
        const std::string& get_COD_MOED() const;
        unsigned long get_NUM_CV() const;
        const std::string& get_NUM_AUT() const;
        const std::string& get_COD_MOT_AUT() const;
        unsigned long get_NUM_MOT_RSPS() const;
        const std::string& get_COD_MOT_RSPS_EXT() const;
        const std::string& get_COD_MOT_SW() const;
        const std::string& get_IND_STTU_TRAN() const;
        dbm_datetime_t get_DTH_STTU_TRAN() const;
        const std::string& get_COD_PROD() const;
        unsigned long get_NUM_RSMO_VD() const;
        dbm_datetime_t get_DAT_RSMO_VD() const;
        const std::string& get_NOM_LOC_ESTB() const;
        const std::string& get_IND_TERM_RLCD_CHIP() const;
        const std::string& get_IND_DFZM() const;
        const std::string& get_IND_ESTR() const;
        const std::string& get_IND_CPTRDO() const;
        const std::string& get_IND_AGND_TRAN() const;
        const std::string& get_IND_IMPR_CPOM() const;
        const std::string& get_IND_EMSR_MTC() const;
        const std::string& get_IND_DA_RLCD_CHIP() const;
        const std::string& get_IND_DA_RLCD_IATA() const;
        const std::string& get_IND_TRAN_REFD() const;
        unsigned long get_TIP_TRAN_ORGL() const;
        dbm_datetime_t get_DAT_EXPC_TRAN() const;
        oasis_dec_t get_VAL_TRAN_DLR() const;
        oasis_dec_t get_VAL_COT_DLR() const;
        const std::string& get_COD_CTR() const;
        oasis_dec_t get_VAL_TX() const;
        const std::string& get_COD_REF_RESTANTE() const;
        const std::string& get_COD_CNDC_CPTR_PAUZ() const;
        const std::string& get_TIP_ENT_PAUZ() const;
        const std::string& get_COD_OPER_CNFR() const;
        oasis_dec_t get_PRCN_TX_RISC() const;
        oasis_dec_t get_VAL_TX_RISC() const;
        const std::string& get_COD_CNDC_CPTR() const;
        const std::string& get_NOM_SITE_ACQR_ORGL() const;
        const std::string& get_NOM_HOST_ACQR_ORGL() const;
        const std::string& get_NOM_FE_ACQR_ORGL() const;
        const std::string& get_NOM_SITE_ISSR() const;
        const std::string& get_NOM_HOST_ISSR() const;
        const std::string& get_NOM_FE_ISSR() const;
        const std::string& get_NOM_SITE_ACQR_ATLZ() const;
        const std::string& get_NOM_HOST_ACQR_ATLZ() const;
        const std::string& get_NOM_FE_ACQR_ATLZ() const;
        const std::string& get_TXT_DA_ADIC_EMSR() const;
        const std::string& get_TIP_MODL_CPTR() const;
        dbm_datetime_t get_DTH_TRAN_EMSR() const;
        dbm_datetime_t get_DAT_LQDC_EMSR() const;
        unsigned long get_COD_ISTT_ACQR() const;
        unsigned long get_COD_ISTT_FRWD() const;
        unsigned long get_COD_RSPS_DTLH_EMSR() const;
        const std::string& get_COD_RSTD_NUM_CVC_2() const;
        unsigned long get_COD_SERV_TRK_CAR() const;
        const std::string& get_COD_VLDC_EMSR() const;
        const std::string& get_IND_AUT() const;
        const std::string& get_IND_DA_RLCD_KMRC() const;
        const std::string& get_IND_TRAN_SEM_ORGL() const;
        dbm_datetime_t get_DAT_PAUZ() const;
        unsigned long get_NUM_SEQ_UNC_PAUZ() const;
        unsigned long get_COD_TRAN_CAD() const;
        const std::string& get_COD_AUT_EMSR() const;
        const std::string& get_COD_NTWK_ID_ACQR_ATLZ() const;
        const std::string& get_NTWK_ID_ACQR_ORGL() const;
        const std::string& get_COD_NTWK_ID_ROUT_ATLZ() const;
        const std::string& get_NTWK_ID_ROUT_ORGL() const;
        const std::string& get_COD_NTWK_ID_ISSR_ATLZ() const;
        const std::string& get_NTWK_ID_ISSR_ORGL() const;
        const std::string& get_COD_RAM_MCC() const;
        const std::string& get_COD_CNDC_CPTR_EMSR( ) const;
        unsigned long get_COD_PROD_CDST() const;
        unsigned long get_COD_SERV_CORP() const;
        unsigned long get_COD_EMP_ADQT( ) const;
        const std::string& get_NUM_PDV_EXT() const;
        const std::string& get_NUM_PDV_VAN() const;
        const std::string& get_COD_DSPO_NFC() const;
        unsigned long get_COD_PROD_PRCR() const;
        long get_COD_GRU_CLAS_RAM() const;
        const std::string& get_IND_TRAN_TKN( ) const;
        /// GetCodOrgAprv
        /// Recupera o Codigo de origem da transacao do Emissor
        /// DRS ID29728 - DP-2017-0043734 Release  Elo Abril 2018 SW75
        /// Historico: 03-05-2018 Valor recuperado do banco de dados.
        const std::string& GetCodOrgAprv( ) const;
        unsigned long GetSituacaoOferta() const;

        /* PR-2018-0002340 - Rocket - Nome do Portador - INICIO */
        void setNomePortadorDoCartao( const std::string& umNome);
        const std::string& getNomePortadorDoCartao( ) const;
        const std::string& getCodigoBinCartao( ) const;
        const std::string& getNumeroFinalCartao( ) const;
        /* PR-2018-0002340 - Rocket - Nome do Portador - FIM */

        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        void SetIndicadorPresencaPortador( const std::string& indicadorPresencaPortadorParametro );
        void SetIndicadorTecnologiaTerminal( const std::string& indicadorTecnologiaTerminalParametro );
        const std::string& GetIndicadorPresencaPortador( ) const;
        const std::string& GetIndicadorTecnologiaTerminal( ) const;
        // J4_2019 - Release Bandeiras Abril 2019 - FIM

        // J2_2020 - WQ3 QRCODE - INICIO
        void SetTipoFormatadorHeader( const std::string& tipoFormatadorHeaderParametro );
        void SetIndicacaoQrcode( const std::string& indicacaoQrcodeParametro );
        void SetCodigoParceiro( long codigoParceiroParametro );
        const std::string& GetTipoFormatadorHeader( ) const;
        const std::string& GetIndicacaoQrcode( ) const;
        long GetCodigoParceiro( ) const;
        // J2_2020 - WQ3 QRCODE - FIM

        void SetCodigoRoteamentoTransacao( const std::string& codigoRoteamentoTransacaoParametro );
        const std::string& GetCodigoRoteamentoTransacao( ) const;

        // AUT1-2168 - PIX - INICIO
        void SetRequestIdPix( const std::string& requestIdPix );
        const std::string& GetRequestIdPix( ) const;
        // AUT1-2168 - PIX - INICIO

        // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
        void SetCodigoProcessoEmissor( int codigoProcessoEmissor );
        int GetCodigoProcessoEmissor( ) const;
        // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM

        //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - INICIO
        void SetIdentificadorReferenciaBandeira( const std::string& idRefBandeira );
        const std::string& GetIdentificadorReferenciaBandeira( ) const;
        //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - FIM

        void SetCodigoParceiroAdquirente( long value );
        long GetCodigoParceiroAdquirente( ) const;

        // ..
        void showxxx( const char *name, unsigned long campo, bool isNull );
        void showxxx( const char *name, int campo, bool isNull );
        void showxxx( const char *name, dbm_datetime_t campo, bool isNull );
        void showxxx( const char *name, const std::string& campo, bool isNull );
        void showxxx( const char *name, oasis_dec_t campo, bool isNull );
        void showxxx( const char *name, sw_date_t campo, bool isNull );
        void show( int nvl );
        // ..

        void let_as_is( );
    private:

        unsigned long       m_DAT_MOV_TRAN;
        unsigned long       m_NUM_SEQ_UNC;
        dbm_datetime_t      m_DTH_GMT;
        dbm_datetime_t      m_DTH_INI_TRAN;
        dbm_datetime_t      m_DAT_CTB_TRAN;
        unsigned long       m_COD_MSG_ISO;
        unsigned long       m_COD_PCM_ISO;
        unsigned long       m_TIP_TRAN;
        std::string         m_TIP_DTLH_TRAN;
        std::string         m_TIP_VD;
        unsigned long       m_TIP_PLN_PGMN;
        std::string         m_COD_CTGR_TRAN;
        unsigned long       m_COD_CMPM_TRAN;
        unsigned long       m_NUM_RD_ORG;
        unsigned long       m_NUM_ESTB;
        std::string         m_COD_TERM;
        unsigned long       m_NUM_STAN;
        std::string         m_TIP_TCNL;
        std::string         m_TIP_TERM;
        unsigned long       m_COD_RAM_ATVD;
        std::string         m_COD_POS_ENTR_MODO;
        unsigned long       m_COD_BNDR;
        unsigned long       m_COD_EMSR;
        unsigned long       m_NUM_EMSR;
        oasis_dec_t         m_NUM_ID_CAR;
        std::string         m_COD_PAIS_CAR;
        std::string         m_NUM_CAR;
        sw_date_t           m_DAT_VLD_CAR;
        std::string         m_IND_TRK;
        std::string         m_IND_CPTR_CVC_2;
        unsigned long       m_NUM_CVC_2;
        std::string         m_COD_TRK_CAR;
        std::string         m_COD_SERV;
        std::string         m_COD_SERV_SNHA;
        unsigned long       m_IND_ID_PREV;
        oasis_dec_t         m_VAL_TRAN;
        oasis_dec_t         m_VAL_TOTL_TRAN;
        std::string         m_COD_MOED;
        unsigned long       m_NUM_CV;
        std::string         m_NUM_AUT;
        std::string         m_COD_MOT_AUT;
        unsigned long       m_NUM_MOT_RSPS;
        std::string         m_COD_MOT_RSPS_EXT;
        std::string         m_COD_MOT_SW;
        std::string         m_IND_STTU_TRAN;
        dbm_datetime_t      m_DTH_STTU_TRAN;
        std::string         m_COD_PROD;
        unsigned long       m_NUM_RSMO_VD;
        dbm_datetime_t      m_DAT_RSMO_VD;
        std::string         m_NOM_LOC_ESTB;
        std::string         m_IND_TERM_RLCD_CHIP;
        std::string         m_IND_DFZM;
        std::string         m_IND_ESTR;
        std::string         m_IND_CPTRDO;
        std::string         m_IND_AGND_TRAN;
        std::string         m_IND_IMPR_CPOM;
        std::string         m_IND_EMSR_MTC;
        std::string         m_IND_DA_RLCD_CHIP;
        std::string         m_IND_DA_RLCD_IATA;
        std::string         m_IND_TRAN_REFD;
        unsigned long       m_TIP_TRAN_ORGL;
        dbm_datetime_t      m_DAT_EXPC_TRAN;
        oasis_dec_t         m_VAL_TRAN_DLR;
        oasis_dec_t         m_VAL_COT_DLR;
        std::string         m_COD_CTR;
        oasis_dec_t         m_VAL_TX;
        std::string         m_COD_REF_RESTANTE;
        std::string         m_COD_CNDC_CPTR_PAUZ;
        std::string         m_TIP_ENT_PAUZ;
        std::string         m_COD_OPER_CNFR;
        oasis_dec_t         m_PRCN_TX_RISC;
        oasis_dec_t         m_VAL_TX_RISC;
        std::string         m_COD_CNDC_CPTR;
        std::string         m_NOM_SITE_ACQR_ORGL;
        std::string         m_NOM_HOST_ACQR_ORGL;
        std::string         m_NOM_FE_ACQR_ORGL;
        std::string         m_NOM_SITE_ISSR;
        std::string         m_NOM_HOST_ISSR;
        std::string         m_NOM_FE_ISSR;
        std::string         m_NOM_SITE_ACQR_ATLZ;
        std::string         m_NOM_HOST_ACQR_ATLZ;
        std::string         m_NOM_FE_ACQR_ATLZ;
        std::string         m_TXT_DA_ADIC_EMSR;
        std::string         m_TIP_MODL_CPTR;
        dbm_datetime_t      m_DTH_TRAN_EMSR;
        dbm_datetime_t      m_DAT_LQDC_EMSR;
        unsigned long       m_COD_ISTT_ACQR;
        unsigned long       m_COD_ISTT_FRWD;
        unsigned long       m_COD_RSPS_DTLH_EMSR;
        std::string         m_COD_RSTD_NUM_CVC_2;
        unsigned long       m_COD_SERV_TRK_CAR;
        std::string         m_COD_VLDC_EMSR;
        std::string         m_IND_AUT;
        std::string         m_IND_DA_RLCD_KMRC;
        std::string         m_IND_TRAN_SEM_ORGL;
        dbm_datetime_t      m_DAT_PAUZ;
        unsigned long       m_NUM_SEQ_UNC_PAUZ;
        unsigned long       m_COD_TRAN_CAD;
        std::string         m_COD_AUT_EMSR;
        std::string         m_COD_NTWK_ID_ACQR_ATLZ;
        std::string         m_COD_NTWK_ID_ACQR_ORGL;
        std::string         m_COD_NTWK_ID_ROUT_ATLZ;
        std::string         m_COD_NTWK_ID_ROUT_ORGL;
        std::string         m_COD_NTWK_ID_ISSR_ATLZ;
        std::string         m_COD_NTWK_ID_ISSR_ORGL;
        std::string         m_COD_RAM_MCC;
        std::string         m_COD_CNDC_CPTR_EMSR;
        unsigned long       m_COD_PROD_CDST;
        unsigned long       m_COD_SERV_CORP;
        unsigned long       m_COD_EMP_ADQT;
        std::string         m_NUM_PDV_EXT;
        std::string         m_NUM_PDV_VAN;
        std::string         m_COD_DSPO_NFC;
        unsigned long       m_COD_PROD_PRCR;
        long                m_COD_GRU_CLAS_RAM;
        std::string         m_IND_TRAN_TKN;
        std::string         codigoOrigemAprovacao;
        unsigned long       situacaoOferta;
        
        int m_DAT_MOV_TRAN_pos;
        int m_NUM_SEQ_UNC_pos;
        int m_DTH_GMT_pos;
        int m_DTH_INI_TRAN_pos;
        int m_DAT_CTB_TRAN_pos;
        int m_COD_MSG_ISO_pos;
        int m_COD_PCM_ISO_pos;
        int m_TIP_TRAN_pos;
        int m_TIP_DTLH_TRAN_pos;
        int m_TIP_VD_pos;
        int m_TIP_PLN_PGMN_pos;
        int m_COD_CTGR_TRAN_pos;
        int m_COD_CMPM_TRAN_pos;
        int m_NUM_RD_ORG_pos;
        int m_NUM_ESTB_pos;
        int m_COD_TERM_pos;
        int m_NUM_STAN_pos;
        int m_TIP_TCNL_pos;
        int m_TIP_TERM_pos;
        int m_COD_RAM_ATVD_pos;
        int m_COD_POS_ENTR_MODO_pos;
        int m_COD_BNDR_pos;
        int m_COD_EMSR_pos;
        int m_NUM_EMSR_pos;
        int m_NUM_ID_CAR_pos;
        int m_COD_PAIS_CAR_pos;
        int m_NUM_CAR_pos;
        int m_DAT_VLD_CAR_pos;
        int m_IND_TRK_pos;
        int m_IND_CPTR_CVC_2_pos;
        int m_NUM_CVC_2_pos;
        int m_COD_TRK_CAR_pos;
        int m_COD_SERV_pos;
        int m_COD_SERV_SNHA_pos;
        int m_IND_ID_PREV_pos;
        int m_VAL_TRAN_pos;
        int m_VAL_TOTL_TRAN_pos;
        int m_COD_MOED_pos;
        int m_NUM_CV_pos;
        int m_NUM_AUT_pos;
        int m_COD_MOT_AUT_pos;
        int m_NUM_MOT_RSPS_pos;
        int m_COD_MOT_RSPS_EXT_pos;
        int m_COD_MOT_SW_pos;
        int m_IND_STTU_TRAN_pos;
        int m_DTH_STTU_TRAN_pos;
        int m_COD_PROD_pos;
        int m_NUM_RSMO_VD_pos;
        int m_DAT_RSMO_VD_pos;
        int m_NOM_LOC_ESTB_pos;
        int m_IND_TERM_RLCD_CHIP_pos;
        int m_IND_DFZM_pos;
        int m_IND_ESTR_pos;
        int m_IND_CPTRDO_pos;
        int m_IND_AGND_TRAN_pos;
        int m_IND_IMPR_CPOM_pos;
        int m_IND_EMSR_MTC_pos;
        int m_IND_DA_RLCD_CHIP_pos;
        int m_IND_DA_RLCD_IATA_pos;
        int m_IND_TRAN_REFD_pos;
        int m_TIP_TRAN_ORGL_pos;
        int m_DAT_EXPC_TRAN_pos;
        int m_VAL_TRAN_DLR_pos;
        int m_VAL_COT_DLR_pos;
        int m_COD_CTR_pos;
        int m_VAL_TX_pos;
        int m_COD_REF_RESTANTE_pos;
        int m_COD_CNDC_CPTR_PAUZ_pos;
        int m_TIP_ENT_PAUZ_pos;
        int m_COD_OPER_CNFR_pos;
        int m_PRCN_TX_RISC_pos;
        int m_VAL_TX_RISC_pos;
        int m_COD_CNDC_CPTR_pos;
        int m_NOM_SITE_ACQR_ORGL_pos;
        int m_NOM_HOST_ACQR_ORGL_pos;
        int m_NOM_FE_ACQR_ORGL_pos;
        int m_NOM_SITE_ISSR_pos;
        int m_NOM_HOST_ISSR_pos;
        int m_NOM_FE_ISSR_pos;
        int m_NOM_SITE_ACQR_ATLZ_pos;
        int m_NOM_HOST_ACQR_ATLZ_pos;
        int m_NOM_FE_ACQR_ATLZ_pos;
        int m_TXT_DA_ADIC_EMSR_pos;
        int m_TIP_MODL_CPTR_pos;
        int m_DTH_TRAN_EMSR_pos;
        int m_DAT_LQDC_EMSR_pos;
        int m_COD_ISTT_ACQR_pos;
        int m_COD_ISTT_FRWD_pos;
        int m_COD_RSPS_DTLH_EMSR_pos;
        int m_COD_RSTD_NUM_CVC_2_pos;
        int m_COD_SERV_TRK_CAR_pos;
        int m_COD_VLDC_EMSR_pos;
        int m_IND_AUT_pos;
        int m_IND_DA_RLCD_KMRC_pos;
        int m_IND_TRAN_SEM_ORGL_pos;
        int m_DAT_PAUZ_pos;
        int m_NUM_SEQ_UNC_PAUZ_pos;
        int m_COD_TRAN_CAD_pos;
        int m_COD_AUT_EMSR_pos;
        int m_COD_NTWK_ID_ACQR_ATLZ_pos;
        int m_COD_NTWK_ID_ACQR_ORGL_pos;
        int m_COD_NTWK_ID_ROUT_ATLZ_pos;
        int m_COD_NTWK_ID_ROUT_ORGL_pos;
        int m_COD_NTWK_ID_ISSR_ATLZ_pos;
        int m_COD_NTWK_ID_ISSR_ORGL_pos;
        int m_COD_RAM_MCC_pos;
        int m_COD_CNDC_CPTR_EMSR_pos;
        int m_COD_PROD_CDST_pos;
        int m_COD_SERV_CORP_pos;
        int m_COD_EMP_ADQT_pos;
        int m_NUM_PDV_EXT_pos;
        int m_NUM_PDV_VAN_pos;
        int m_COD_DSPO_NFC_pos;
        int m_COD_PROD_PRCR_pos;
        int m_COD_GRU_CLAS_RAM_pos;
        int m_IND_TRAN_TKN_pos;
        int codigoOrigemAprovacaoPos;
        int situacaoOfertaPos;

        int m_DAT_RSMO_VD_ind_null;
        int m_DAT_LQDC_EMSR_ind_null;
        int m_DTH_TRAN_EMSR_ind_null;
        int m_COD_SERV_TRK_CAR_ind_null;
        int m_DAT_EXPC_TRAN_ind_null;
        int m_DAT_VLD_CAR_ind_null;
        int m_DTH_GMT_ind_null;
        int m_VAL_COT_DLR_ind_null;
        int m_NUM_CV_ind_null;
        int m_VAL_TRAN_ind_null;
        int m_VAL_TX_ind_null;
        int m_VAL_TRAN_DLR_ind_null;
        int m_NUM_ID_CAR_ind_null;
        int m_TIP_PLN_PGMN_ind_null;
        int m_NUM_EMSR_ind_null;
        int m_COD_BNDR_ind_null;
        int m_VAL_TX_RISC_ind_null;
        int m_TIP_TRAN_ORGL_ind_null;
        int m_COD_CMPM_TRAN_ind_null;
        int m_PRCN_TX_RISC_ind_null;
        int m_NUM_CVC_2_ind_null;
        int m_VAL_TOTL_TRAN_ind_null;
        int m_NUM_RSMO_VD_ind_null;
        int m_COD_EMSR_ind_null;
        int m_NUM_RD_ORG_ind_null;
        int m_DAT_PAUZ_ind_null;
        int m_NUM_SEQ_UNC_PAUZ_ind_null;
        int m_COD_TRAN_CAD_ind_null;
        int m_COD_RSPS_DTLH_EMSR_ind_null;
        int m_COD_ISTT_ACQR_ind_null;
        int m_COD_ISTT_FRWD_ind_null;
        int m_IND_CPTRDO_ind_null;
        int m_IND_ID_PREV_ind_null;
        int m_COD_PROD_CDST_ind_null;
        int m_COD_SERV_CORP_ind_null;
        int m_COD_PROD_PRCR_ind_null;
        
        logger::DebugWriter *m_log;
        bool is_dual;

        /* PR-2018-0002340 - Rocket - Nome do Portador - INICIO */
        std::string nomePortadorDoCartao; //NOM_PORT_CAR
        int posicaoDoNomePortadorDoCartao;
        std::string codigoBinCartao;//COD_BIN_CAR
        int posicaoDoCodigoBinCartao;
        void setCodigoBinCartao( const std::string& numeroDoCartao);
        std::string numeroFinalCartao;//NUM_FINL_CAR
        int posicaoDoNumeroFinalCartao;
        void setNumeroFinalCartao( const std::string& numeroDoCartao);
        /* PR-2018-0002340 - Rocket - Nome do Portador - FIM */

        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        std::string         indicadorPresencaPortador;     // COD_PORT_PRES_VLDC_BNDR
        int posicaoIndicadorPresencaPortador;
        std::string         indicadorTecnologiaTerminal;   // COD_CPCD_TERM_VLDC_BNDR
        int posicaoIndicadorTecnologiaTerminal;
        // J4_2019 - Release Bandeiras Abril 2019 - FIM

        // J2_2020 - WQ3 QRCODE - INICIO
        std::string     tipoFormatadorHeader;   // COD_FMTR_HEDR
        int             posicaoTipoFormatadorHeader;
        std::string     indicacaoQrcode;        // IND_QRCODE
        int             posicaoIndicacaoQrcode;
        long            codigoParceiro;         // COD_PRCR
        int             posicaoCodigoParceiro;
        // J2_2020 - WQ3 QRCODE - FIM

        std::string     codigoRoteamentoTransacao;        // COD_ROTM_TRAN
        int             posicaoCodigoRoteamentoTransacao;

        // AUT1-2168 - PIX - INICIO
        std::string     requestIdPix;   // COD_FMTR_HEDR
        int             posicaoRequestIdPix;
        // AUT1-2168 - PIX - INICIO

        // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
        int codigoProcessoEmissor;
        int codigoProcessoEmissorPos;
        // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM

        //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - INICIO
        std::string identificadorReferenciaBandeira;
        int identificadorReferenciaBandeiraPos;
        //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - FIM

        long codigoParceiroAdquirente;
        int codigoParceiroAdquirentePos;
    };
} //namespace dbaccess_common

