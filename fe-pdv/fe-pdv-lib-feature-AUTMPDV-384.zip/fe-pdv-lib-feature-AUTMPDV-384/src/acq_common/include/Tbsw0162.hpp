/* Copyright 2018 Rede S.A.
Autor : Danilo Oliveira
Empresa : FIS
*/

#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_common
{
    /// Tbsw0162
    /// Representa um registro da tabela TBSW0162 no BD
    /// EF/ET: 000
    /// Historico: 04/05/2018 - Danilo Oliveira - 000 - Implementacao inicial
    class Tbsw0162 : public dbaccess::table
    {
    public:

        // Declaracao de construtores/destrutores
        Tbsw0162( );
        Tbsw0162( const std::string& whereClause );
        ~Tbsw0162( );

        // Assinatura de metodos
        void SetWhereClause( const std::string& whereClause );
        void bind_columns( );

        // Assinatura dos metodos para atribuir valor aos respectivos atributos
        void SetDataMovimentoTransacao( unsigned long paramDataMovimentoTransacao );
        void SetNumeroSequencialUnico( unsigned long paramNumeroSequencialUnico );
        void SetCodigoTerminal( const std::string& paramCodigoTerminal );
        void SetNumeroEstabelecimento( unsigned long paramNumeroEstabelecimento );
        void SetNumeroSerieTerminal( const std::string& paramNumeroSerieTerminal );

        // Assinatura dos metodos para obter valor dos respectivos atributos
        unsigned long GetDataMovimentoTransacao( ) const;
        unsigned long GetNumeroSequencialUnico( ) const;
        const std::string& GetCodigoTerminal( ) const;
        unsigned long GetNumeroEstabelecimento( ) const;
        const std::string& GetNumeroSerieTerminal( ) const;

    private:
        // Declaracao dos atributos que representam cada um dos campos da tabela
        unsigned long dataMovimentoTransacao;
        unsigned long numeroSequencialUnico;
        std::string   codigoTerminal;
        unsigned long numeroEstabelecimento;
        std::string   numeroSerieTerminal;

        // Declaracao dos atributos que representam a posicao em que cada campo fica no select
        int posDataMovimentoTransacao;
        int posNumeroSequencialUnico;
        int posCodigoTerminal;
        int posNumeroEstabelecimento;
        int posNumeroSerieTerminal;

        // Declaracao de atributos
        logger::DebugWriter *debugWriter;

        // Assinatura de metodos
        void Initialize();
    };
} //namespace dbaccess_pdv
