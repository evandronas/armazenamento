#pragma once
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_common
{
	class TBSW2020 : public dbaccess::table
	{
	private:
		oasis_dec_t m_nsu;
		int m_range;
		oasis_dec_t m_rangeLimite;
		dbm_datetime_t m_resetDate;
		dbm_datetime_t m_now;
	protected:
		oasis_dec_t VAL_RESET_NUM_SEQ_UNC;
		oasis_dec_t VAL_ATU_NUM_SEQ_UNC;
		int VAL_RNG_NUM_SEQ_UNC;
		std::string SGL_SITE;
		dbm_datetime_t DAT_RESET;
		
		// Novos Campos 
		std::string     nomHost;
		int             processoId;
		dbm_datetime_t  dataUltimaAtualizacao;
		
		int VAL_RESET_NUM_SEQ_UNC_pos;
		int VAL_ATU_NUM_SEQ_UNC_pos;
		int VAL_RNG_NUM_SEQ_UNC_pos;
		int SGL_SITE_pos;
		int DAT_RESET_pos;

		// Position Novos Campos 
		int  posNomHost;
		int  posProcessoId;
		int  posDataUltimaAtualizacao;		
	public:
		TBSW2020( );
		TBSW2020( std::string a_table );
		virtual ~TBSW2020( );
		void set_VAL_RESET_NUM_SEQ_UNC( oasis_dec_t a_value );
		void set_VAL_ATU_NUM_SEQ_UNC( oasis_dec_t a_value );
		void set_VAL_RNG_NUM_SEQ_UNC( int a_value );
		void set_SGL_SITE( const std::string& a_value );
		void set_DAT_RESET( const dbm_datetime_t& a_value );
		
		// Setters Novos Campos 
		void SetNomeHost( const std::string value );
		void SetProcessoId( int pid );
		void SetDataUltimaAtualizacao( const dbm_datetime_t& value );
		
		oasis_dec_t get_VAL_RESET_NUM_SEQ_UNC( );
		oasis_dec_t get_VAL_ATU_NUM_SEQ_UNC( );
		int get_VAL_RNG_NUM_SEQ_UNC( );
		const std::string& get_SGL_SITE( );
		const dbm_datetime_t& get_DAT_RESET( );

		// Getters Novos Campos 
		int  GetProcessoId();
		const std::string& GetNomeHost();
		const dbm_datetime_t& GetDataUltimaAtualizacao();
		
		bool VAL_RESET_NUM_SEQ_UNC_is_null( );
		bool VAL_ATU_NUM_SEQ_UNC_is_null( );
		bool VAL_RNG_NUM_SEQ_UNC_is_null( );
		bool SGL_SITE_is_null( );
		bool DAT_RESET_is_null( );
		
		// Novos Campos IsNull
		bool ProcessoIdIsNull();
		bool NomeHostIsNull();
		bool DataUltimaAtualizacaoIsNull();	
		
		void bind_columns( );
		void set_table_name( const std::string& a_table );
		void set_where_condition( const std::string& a_where );
		void set_query_fields( const std::string& a_fields );
		oasis_dec_t currentNsu( );
	};
}//namespace dbaccess_pdv

