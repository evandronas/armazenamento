#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_common
{
    class EmptyQuery : public dbaccess::table
    {
        private:
            std::string         m_RESULT;
            logger::DebugWriter *m_log;

            EmptyQuery( ){};

        public:
            EmptyQuery( const std::string&, const std::string&, const std::string& );
            ~EmptyQuery( );
            void bind_columns( );
            const std::string& get_RESULT( ) const;
    };
} //namespace dbaccess_common
