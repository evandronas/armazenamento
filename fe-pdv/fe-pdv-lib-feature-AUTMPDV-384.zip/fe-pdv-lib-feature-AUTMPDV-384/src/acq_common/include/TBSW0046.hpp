#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0046 : public dbaccess::table
    {
    public:
        TBSW0046();
        TBSW0046( const std::string& whereClause );
        ~TBSW0046();

        void bind_columns();

        void set_NUM_RV( oasis_dec_t a_NUM_RV );
        void set_IND_NUM_QBRA( unsigned long a_IND_NUM_QBRA );
        void set_IND_NUM_PRCL( unsigned long a_IND_NUM_PRCL );
        void set_VAL_PRCL( oasis_dec_t a_VAL_PRCL );
        void set_DAT_PRCL( dbm_datetime_t a_DAT_PRCL );
        void set_NUM_PDV( unsigned long a_NUM_PDV );

        oasis_dec_t get_NUM_RV() const;
        unsigned long get_IND_NUM_QBRA() const;
        unsigned long get_IND_NUM_PRCL() const;
        oasis_dec_t get_VAL_PRCL() const;
        dbm_datetime_t get_DAT_PRCL() const;
        unsigned long get_NUM_PDV() const;

        void let_VAL_PRCL_as_is();

    private:
        oasis_dec_t        m_NUM_RV;
        unsigned long    m_IND_NUM_QBRA;
        unsigned long    m_IND_NUM_PRCL;
        oasis_dec_t        m_VAL_PRCL;
        dbm_datetime_t    m_DAT_PRCL;
        unsigned long    m_NUM_PDV;

        int m_NUM_RV_pos;
        int m_IND_NUM_QBRA_pos;
        int m_IND_NUM_PRCL_pos;
        int m_VAL_PRCL_pos;
        int m_DAT_PRCL_pos;
        int m_NUM_PDV_pos;
        
        int m_VAL_PRCL_ind_null;
    };
} //namespace dbaccess_common

