#pragma once
#include "CodUcafFormater.hpp"

class CodUcafFormaterVisa : public CodUcafFormater
{
    public:
        CodUcafFormaterVisa( const std::string &cavv );
        virtual ~CodUcafFormaterVisa();
        std::string format();
};