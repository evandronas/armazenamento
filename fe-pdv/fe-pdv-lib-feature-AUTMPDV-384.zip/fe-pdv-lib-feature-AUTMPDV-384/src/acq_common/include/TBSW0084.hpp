#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0084 : public dbaccess::table
    {
        public:
            TBSW0084( );
            TBSW0084( const std::string & str );
            virtual ~TBSW0084( );

            void initialize( );
            void bind_columns( );

            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_COD_TERM( const std::string& a_COD_TERM );
            void set_NUM_STAN( const oasis_dec_t& a_NUM_STAN );
            void set_DTH_INI_TRAN( const dbm_datetime_t& a_DTH_INI_TRAN );
            void set_NUM_ESTB( unsigned long a_NUM_ESTB );
            void set_COD_PNPD_PDV( const std::string& a_COD_PNPD_PDV );
            void set_NOM_FBRC_PNPD( const std::string& a_NOM_FBRC_PNPD );
            void set_NUM_SRE_PNPD( const std::string& a_NUM_SRE_PNPD );
            void set_COD_VERS_HDW_PNPD( const std::string& a_COD_VERS_HDW_PNPD );
            void set_COD_VERS_FRWR_PNPD( const std::string& a_COD_VERS_FRWR_PNPD );
            void set_NOM_FBRC_TEF( const std::string& a_NOM_FBRC_TEF );
            void set_COD_VERS_SFTW_TEF( const std::string& a_COD_VERS_SFTW_TEF );
            void set_NOM_FBRC_ATMC( const std::string& a_NOM_FBRC_ATMC );
            void set_COD_VERS_SFTW_ATMC( const std::string& a_COD_VERS_SFTW_ATMC );
            void set_QTD_LEIT_MAGN( unsigned long a_QTD_LEIT_MAGN );
            void set_QTD_ERR_LEIT_MAGN( unsigned long a_QTD_ERR_LEIT_MAGN );
            void set_QTD_SNHA_MAGN( unsigned long a_QTD_SNHA_MAGN );
            void set_QTD_ERR_SNHA_MAGN( unsigned long a_QTD_ERR_SNHA_MAGN );
            void set_QTD_SNHA_CHIP_ONLN( unsigned long a_QTD_SNHA_CHIP_ONLN );
            void set_QTD_ERR_SNHA_CHIP_ONLN( unsigned long a_QTD_ERR_SNHA_CHIP_ONLN );
            void set_QTD_SNHA_CHIP_OFLN( unsigned long a_QTD_SNHA_CHIP_OFLN );
            void set_QTD_ERR_SNHA_CHIP_OFLN( unsigned long a_QTD_ERR_SNHA_CHIP_OFLN );
            void set_QTD_BLQD_CHIP( unsigned long a_QTD_BLQD_CHIP );
            void set_QTD_LEIT_CHIP( unsigned long a_QTD_LEIT_CHIP );
            void set_QTD_FALLBACK_CRE( unsigned long a_QTD_FALLBACK_CRE );
            void set_QTD_FALLBACK_DEB( unsigned long a_QTD_FALLBACK_DEB );
            void set_COD_VERS_SFTW_PNPD( const std::string& a_COD_VERS_SFTW_PNPD );
            void set_NUM_SEQ_UNC( const oasis_dec_t& a_NUM_SEQ_UNC );

            unsigned long get_DAT_MOV_TRAN() const;
            const std::string& get_COD_TERM() const;
            const oasis_dec_t& get_NUM_STAN() const;
            const dbm_datetime_t& get_DTH_INI_TRAN() const;
            unsigned long get_NUM_ESTB() const;
            const std::string& get_COD_PNPD_PDV() const;
            const std::string& get_NOM_FBRC_PNPD() const;
            const std::string& get_NUM_SRE_PNPD() const;
            const std::string& get_COD_VERS_HDW_PNPD() const;
            const std::string& get_COD_VERS_FRWR_PNPD() const;
            const std::string& get_NOM_FBRC_TEF() const;
            const std::string& get_COD_VERS_SFTW_TEF() const;
            const std::string& get_NOM_FBRC_ATMC() const;
            const std::string& get_COD_VERS_SFTW_ATMC() const;
            unsigned long get_QTD_LEIT_MAGN() const;
            unsigned long get_QTD_ERR_LEIT_MAGN() const;
            unsigned long get_QTD_SNHA_MAGN() const;
            unsigned long get_QTD_ERR_SNHA_MAGN() const;
            unsigned long get_QTD_SNHA_CHIP_ONLN() const;
            unsigned long get_QTD_ERR_SNHA_CHIP_ONLN() const;
            unsigned long get_QTD_SNHA_CHIP_OFLN() const;
            unsigned long get_QTD_ERR_SNHA_CHIP_OFLN() const;
            unsigned long get_QTD_BLQD_CHIP() const;
            unsigned long get_QTD_LEIT_CHIP() const;
            unsigned long get_QTD_FALLBACK_CRE() const;
            unsigned long get_QTD_FALLBACK_DEB() const;
            const std::string& get_COD_VERS_SFTW_PNPD() const;
            const oasis_dec_t& get_NUM_SEQ_UNC() const;

        private:
            unsigned long   m_DAT_MOV_TRAN;
            std::string     m_COD_TERM;
            oasis_dec_t     m_NUM_STAN;
            dbm_datetime_t  m_DTH_INI_TRAN;
            unsigned long   m_NUM_ESTB;
            std::string     m_COD_PNPD_PDV;
            std::string     m_NOM_FBRC_PNPD;
            std::string     m_NUM_SRE_PNPD;
            std::string     m_COD_VERS_HDW_PNPD;
            std::string     m_COD_VERS_FRWR_PNPD;
            std::string     m_NOM_FBRC_TEF;
            std::string     m_COD_VERS_SFTW_TEF;
            std::string     m_NOM_FBRC_ATMC;
            std::string     m_COD_VERS_SFTW_ATMC;
            unsigned long   m_QTD_LEIT_MAGN;
            unsigned long   m_QTD_ERR_LEIT_MAGN;
            unsigned long   m_QTD_SNHA_MAGN;
            unsigned long   m_QTD_ERR_SNHA_MAGN;
            unsigned long   m_QTD_SNHA_CHIP_ONLN;
            unsigned long   m_QTD_ERR_SNHA_CHIP_ONLN;
            unsigned long   m_QTD_SNHA_CHIP_OFLN;
            unsigned long   m_QTD_ERR_SNHA_CHIP_OFLN;
            unsigned long   m_QTD_BLQD_CHIP;
            unsigned long   m_QTD_LEIT_CHIP;
            unsigned long   m_QTD_FALLBACK_CRE;
            unsigned long   m_QTD_FALLBACK_DEB;
            std::string     m_COD_VERS_SFTW_PNPD;
            oasis_dec_t     m_NUM_SEQ_UNC;

            int m_DAT_MOV_TRAN_pos;
            int m_COD_TERM_pos;
            int m_NUM_STAN_pos;
            int m_DTH_INI_TRAN_pos;
            int m_NUM_ESTB_pos;
            int m_COD_PNPD_PDV_pos;
            int m_NOM_FBRC_PNPD_pos;
            int m_NUM_SRE_PNPD_pos;
            int m_COD_VERS_HDW_PNPD_pos;
            int m_COD_VERS_FRWR_PNPD_pos;
            int m_NOM_FBRC_TEF_pos;
            int m_COD_VERS_SFTW_TEF_pos;
            int m_NOM_FBRC_ATMC_pos;
            int m_COD_VERS_SFTW_ATMC_pos;
            int m_QTD_LEIT_MAGN_pos;
            int m_QTD_ERR_LEIT_MAGN_pos;
            int m_QTD_SNHA_MAGN_pos;
            int m_QTD_ERR_SNHA_MAGN_pos;
            int m_QTD_SNHA_CHIP_ONLN_pos;
            int m_QTD_ERR_SNHA_CHIP_ONLN_pos;
            int m_QTD_SNHA_CHIP_OFLN_pos;
            int m_QTD_ERR_SNHA_CHIP_OFLN_pos;
            int m_QTD_BLQD_CHIP_pos;
            int m_QTD_LEIT_CHIP_pos;
            int m_QTD_FALLBACK_CRE_pos;
            int m_QTD_FALLBACK_DEB_pos;
            int m_COD_VERS_SFTW_PNPD_pos;
            int m_NUM_SEQ_UNC_pos;

    }; // class TBSW0084

} // namespace dbaccess_common



