/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#ifndef __TBSW2017_H__
#define __TBSW2017_H__

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW2017 : public dbaccess::table
    {
        public:
            // Declaracao dos Contrutores
            TBSW2017();
            TBSW2017(const std::string& where);

            // Declaracao dos Destrutores
            virtual ~TBSW2017();

            // Getters
            const std::string& GetCodigoSituacaoRegistro() const;
            const std::string& GetDescricaoBloqueio() const;
            const std::string& GetCodigoUsuarioUltimaAlteracao() const;
            const dbm_datetime_t& GetDataUltimaAlteracaoRegistro() const;
            
			
            // Setters
            void SetCodigoSituacaoRegistro(const std::string& value);
            void SetDescricaoBloqueio(const std::string& value);
            void SetCodigoUsuarioUltimaAlteracao(const std::string& value);
            void SetDataUltimaAlteracaoRegistro(const dbm_datetime_t& value);
            
        protected:
            // Metodo herdado da classe base(db_object)
            void bind_columns();

        private:
            // Indices dos campos na tabela
            int codigoSituacaoRegistroPosicao;
            int descricaoBloqueioPosicao;
            int codigoUsuarioUltimaAlteracaoPosicao;
            int dataUltimaAlteracaoRegistroPosicao;

            // Atributos confrome campos da tabela TBSW2017
            std::string codigoSituacaoRegistro;
            std::string descricaoBloqueio;
            std::string codigoUsuarioUltimaAlteracao;
            dbm_datetime_t dataAlteracaoRegistro;
            
    };
}
#endif  // __TBSW2017_H__
