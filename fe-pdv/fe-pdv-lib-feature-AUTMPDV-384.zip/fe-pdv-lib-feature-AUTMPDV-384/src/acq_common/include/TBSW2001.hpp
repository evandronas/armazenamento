/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW2001 : public dbaccess::table
    {
    public:
        TBSW2001();
        TBSW2001( const std::string & str );
        virtual ~TBSW2001();

        void bind_columns();

		// Setters
		void SetCodChavSupr( const std::string& a_COD_CHAV_SUPR );
		void SetTipBin( const std::string& a_TIP_BIN );
		void SetCodChavInfr( const std::string& a_COD_CHAV_INFR );
		void SetTipIssr( const std::string& a_TIP_ISSR );
		void SetCodBinIssr( const std::string& a_COD_BIN_ISSR );
		void SetTipChckDigVrfc( const std::string& a_TIP_CHCK_DIG_VRFC );
		void SetTamRngCta( const std::string& a_TAM_RNG_CTA );
		void SetTipCar( const std::string& a_TIP_CAR );
		void SetTipUso( const std::string& a_TIP_USO );
		void SetCodBinPrcs( const std::string& a_COD_BIN_PRCS );
		void SetCodDomCar( const std::string& a_COD_DOM_CAR );
		void SetCodRgaoEmsr( const std::string& a_COD_RGAO_EMSR );
		void SetCodPaisEmsr( const std::string& a_COD_PAIS_EMSR );
		void SetIndServCarCmc( const std::string& a_IND_SERV_CAR_CMC );
		void SetIndTcnl( const std::string& a_IND_TCNL );
		void SetCodRgaoCar( const std::string& a_COD_RGAO_CAR );
		void SetCodPaisCar( const std::string& a_COD_PAIS_CAR );
		void SetIndDaNvl2( const std::string& a_IND_DA_NVL_2 );
		void SetIndDaNvl3( const std::string& a_IND_DA_NVL_3 );
		void SetIndMsgCarCmc( const std::string& a_IND_MSG_CAR_CMC );
		void SetIndTxValAgrd( const std::string& a_IND_TX_VAL_AGRD );
		void SetIndValOrgl( const std::string& a_IND_VAL_ORGL );
		void SetIndExtnTipProd( const std::string& a_IND_EXTN_TIP_PROD );
		void SetIndTrsfMntr( const std::string& a_IND_TRSF_MNTR );
		void SetIndJogOnln( const std::string& a_IND_JOG_ONLN );
		void SetCodProd( const std::string& a_COD_PROD );
		void SetTipUsoInt1( const std::string& a_TIP_USO_INT_1 );
		void SetIndAmb( const std::string& a_IND_AMB );
		void SetTipUsoInt2( const std::string& a_TIP_USO_INT_2 );
		void SetCodIdMmbrVisa( unsigned long a_COD_ID_MMBR_VISA );
		void SetDatInclRegVisa( unsigned long a_DAT_INCL_REG_VISA );
		void SetTipCarMltp( const std::string& a_TIP_CAR_MLTP );
		
		// Getters
		const std::string& GetCodChavSupr() const;
		const std::string& GetTipBin() const;
		const std::string& GetCodChavInfr() const;
		const std::string& GetTipIssr() const;
		const std::string& GetCodBinIssr() const;
		const std::string& GetTipChckDigVrfc() const;
		const std::string& GetTamRngCta() const;
		const std::string& GetTipCar() const;
		const std::string& GetTipUso() const;
		const std::string& GetCodBinPrcs() const;
		const std::string& GetCodDomCar() const;
		const std::string& GetCodRgaoEmsr() const;
		const std::string& GetCodPaisEmsr() const;
		const std::string& GetIndServCarCmc() const;
		const std::string& GetIndTcnl() const;
		const std::string& GetCodRgaoCar() const;
		const std::string& GetCodPaisCar() const;
		const std::string& GetIndDaNvl2() const;
		const std::string& GetIndDaNvl3() const;
		const std::string& GetIndMsgCarCmc() const;
		const std::string& GetIndTxValAgrd() const;
		const std::string& GetIndValOrgl() const;
		const std::string& GetIndExtnTipProd() const;
		const std::string& GetIndTrsfMntr() const;
		const std::string& GetIndJogOnln() const;
		const std::string& GetCodProd() const;
		const std::string& GetTipUsoInt1() const;
		const std::string& GetIndAmb() const;
		const std::string& GetTipUsoInt2() const;
		unsigned long      GetCodIdMmbrVisa() const;
		unsigned long      GetDatInclRegVisa() const;
		const std::string& GetTipCarMltp() const;

    private:
	    //variables
		std::string codChavSupr;
		std::string tipBin;      
		std::string codChavInfr;
		std::string tipIssr;
		std::string codBinIssr;
		std::string tipChckDigVrfc;
		std::string tamRngCta;
		std::string tipCar;
		std::string tipUso;
		std::string codBinPrcs;
		std::string codDomCar;
		std::string codRgaoEmsr;
		std::string codPaisEmsr;
		std::string indServCarCMC;
		std::string indTcnl;
		std::string codRgaoCar;
		std::string codPaisCar;
		std::string indDaNvl2;
		std::string indDaNvl3;
		std::string indMsgCarCmc;
		std::string indTxValAgrd;
		std::string indValOrgl;
		std::string indExtnTipProd;
		std::string indTrsfMntr;
		std::string indJogOnln;
		std::string codProd;
		std::string tipUsoInt1;
		std::string indAmb;
		std::string tipUsoInt2;
		unsigned long codIdMmbrVisa;
		unsigned long datInclRegVisa;
		std::string tipCarMltp;

        //indexes
		int codChavSuprPos;
		int tipBinPos;
		int codChavInfrPos;
		int tipIssrPos;
		int codBinIssrPos;
		int tipChckDigVrfcPos;
		int tamRngCtaPos;
		int tipCarPos;
		int tipUsoPos;
		int codBinPrcsPos;
		int codDomCarPos;
		int codRgaoEmsrPos;
		int codPaisEmsrPos;
		int indServCarCmcPos;
		int indTcnlPos;
		int codRgaoCarPos;
		int codPaisCarPos;
		int indDaNvl2Pos;
		int indDaNvl3Pos;
		int indMsgCarCmcPos;
		int indTxValAgrdPos;
		int indValOrglPos;
		int indExtnTipProdPos;
		int indTrsfMntrPos;
		int indJogOnlnPos;
		int codProdPos;
		int tipUsoInt1Tos;
		int indAmbPos;
		int tipUsoInt2Tos;
		int codIdMmbrVisaPos;
		int datInclRegVisaPos;
		int tipCarMltpPos;
    };
}//namespace dbaccess_common



