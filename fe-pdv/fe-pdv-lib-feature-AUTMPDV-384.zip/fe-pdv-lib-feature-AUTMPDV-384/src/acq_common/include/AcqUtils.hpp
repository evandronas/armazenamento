#pragma once

#include <cstdio>
#include <ctime>
#include <dbm.h>
#include <string>
#include <fieldSet/fsextr.hpp>
#include <fieldSet/fscopy.hpp>
#include <base/shc_structs.hpp>
#include <defines.hpp>

#define WARNING_INVALID_FUNCTION    std::string str;\
                                    str.clear();\
                                    str.append("ATENCAO: metodo ").append( __FUNCTION__).append(" invalido");\
                                    m_log->write( logger::LEVEL_INFO, str.c_str() );

#define WARNING_EMPTY_STRING        std::string str;\
                                    str.clear();\
                                    str.append("ATENCAO: esta funcao nao pode gravar valor nulo (campo 'not null' no BD), e a informacao estah vazia. Portanto sera gravado espaco.[").append( __FUNCTION__).append("] invalido");\
                                    m_log->write( logger::LEVEL_INFO, str.c_str() );

#define WARNING_FLOW_ERROR1         std::ostringstream str;\
                                    str << "ATENCAO: Condicoes nao atendidas ao tentar gravar campo na tabela[";\
                                    str << __FUNCTION__;\
                                    str << ".";\
                                    str << __LINE__;\
                                    str << "]";\
                                    m_log->write( logger::LEVEL_INFO, str.str( ).c_str( ) );

#define WARNING_FLOW_ERROR          {std::ostringstream str;\
                                    str << " ATENCAO: Condicoes nao atendidas ao tentar gravar campo na tabela[";\
                                    str << __FUNCTION__;\
                                    str << ".";\
                                    str << __LINE__;\
                                    str << "]";\
                                    m_log->write( logger::LEVEL_INFO, str.str( ).c_str( ) );}
                             
class AcqUtils
{
public:
    AcqUtils( );
    ~AcqUtils( );

    static dbm_datetime_t dateTime( long a_data, long a_time );
    static dbm_datetime_t dateTimeGMT( long a_data, long a_time );
    static std::string getServiceCode( std::string track2, std::string track3 );
    static std::string format_cd_cnd_cpt( const std::string & de061, const unsigned long & modo_entrada, const std::string & iss_name, const std::string & msg_name, const std::string & modelo_terminal, const std::string & tipo_tecnologia );
    static void cfsextr( base::date_t &target, fieldSet::ConstFieldAccess &field );
    static void cfsextr( char *target, fieldSet::ConstFieldAccess &field );
    static void cfsextr( oasis_dec_t &target, fieldSet::ConstFieldAccess &field );
    static void cfscopy( fieldSet::FieldAccess &field, oasis_dec_t &source );
    static void cfscopy( fieldSet::FieldAccess &field, base::date_t &source );
    static std::string converteAuthnum( const std::string& value );
    static std::string trim( const std::string& source, const std::string& trimmingChar, const bool& leftTrimming, const bool& rightTrimming );
    static bool findChip( std::string buffer_de55,std::string nome_tag, std::string &conteudo_tag );
    static std::string findChipTag( std::string l_de55, int &l_pos );
    static std::string findChipConteudo( std::string l_de55, int &l_pos, int l_len );
    static int findChipLen( std::string l_de55, int &l_pos );
};