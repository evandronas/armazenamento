#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
	class TBSW0083 : public dbaccess::table
	{
	public:
		TBSW0083();
		TBSW0083( const std::string& whereClause );
		~TBSW0083();

		void bind_columns();

		void set_COD_CEP_PORT( const std::string& a_COD_CEP_PORT );
		void set_COD_CEP_CMPM_PORT( const std::string& a_COD_CEP_CMPM_PORT );
		void set_TXT_ENDR_PORT( const std::string& a_TXT_ENDR_PORT );
		void set_NUM_CPF_PORT( const std::string& a_NUM_CPF_PORT );
		void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
		void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
		void set_COD_RSPS_AVS( const std::string& a_COD_RSPS_AVS );
		void set_TXT_CMPM_ENDR_PORT( const std::string& a_TXT_CMPM_ENDR_PORT );

		const std::string& get_COD_CEP_PORT() const;
		const std::string& get_COD_CEP_CMPM_PORT() const;
		const std::string& get_TXT_ENDR_PORT() const;
		const std::string& get_NUM_CPF_PORT() const;
		unsigned long get_DAT_MOV_TRAN() const;
		oasis_dec_t get_NUM_SEQ_UNC() const;
		const std::string& get_COD_RSPS_AVS() const;
		const std::string& get_TXT_CMPM_ENDR_PORT() const;



	private:
		std::string				m_COD_CEP_PORT;
		std::string				m_COD_CEP_CMPM_PORT;
		std::string				m_TXT_ENDR_PORT;
		std::string				m_NUM_CPF_PORT;
		unsigned long			m_DAT_MOV_TRAN;
		oasis_dec_t			m_NUM_SEQ_UNC;
		std::string				m_COD_RSPS_AVS;
		std::string				m_TXT_CMPM_ENDR_PORT;

		int m_COD_CEP_PORT_pos;
		int m_COD_CEP_CMPM_PORT_pos;
		int m_TXT_ENDR_PORT_pos;
		int m_NUM_CPF_PORT_pos;
		int m_DAT_MOV_TRAN_pos;
		int m_NUM_SEQ_UNC_pos;
		int m_COD_RSPS_AVS_pos;
		int m_TXT_CMPM_ENDR_PORT_pos;
        
        void initialize();
	};
} //namespace dbaccess_common

