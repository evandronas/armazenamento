#pragma once
#include "CodUcafFormater.hpp"

class CodUcafFormaterElo : public CodUcafFormater
{
    public:
        CodUcafFormaterElo( const std::string &cavv, const std::string &programProtocol, unsigned long codigoTransacao );
        CodUcafFormaterElo( const std::string &cavv );
        virtual ~CodUcafFormaterElo();

        CodUcafFormaterElo setCodigoTransacao( unsigned long codigoTransacao );
        std::string format();

    private:
        std::string m_programProtocol;
        unsigned long m_codigoTransacao;
};