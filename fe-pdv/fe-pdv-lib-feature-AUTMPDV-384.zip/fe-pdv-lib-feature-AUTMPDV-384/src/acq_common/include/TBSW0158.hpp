#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_pdv
{
class TBSW0158 : public dbaccess::table
{
public:
	TBSW0158();
	TBSW0158( const std::string& whereClause );
	~TBSW0158();

	void bind_columns();
	void initialize();

        void set_COD_EMP_ADQT( unsigned long a_COD_EMP_ADQT );
        void set_NUM_PDV( unsigned long a_NUM_PDV );
        void set_NUM_PDV_EXT( const std::string& a_NUM_PDV_EXT );
        void set_NUM_PDV_VAN( const std::string& a_NUM_PDV_VAN );
        void set_COD_SIT_PDV_EXT( const std::string& a_COD_SIT_PDV_EXT );
        void set_DAT_ATLZ_REG( dbm_datetime_t  a_DAT_ATLZ_REG );

        unsigned long		get_COD_EMP_ADQT() const;
        unsigned long		get_NUM_PDV() const;
        const std::string	get_NUM_PDV_EXT() const;
        const std::string	get_NUM_PDV_VAN() const;
        const std::string	get_COD_SIT_PDV_EXT() const;
        dbm_datetime_t		get_DAT_ATLZ_REG() const;

		void let_COD_EMP_ADQT_as_is();
		void let_NUM_PDV_as_is();

private:

	int m_COD_EMP_ADQT_pos;
	int m_NUM_PDV_pos;
	int m_NUM_PDV_EXT_pos;
	int m_NUM_PDV_VAN_pos;
	int m_COD_SIT_PDV_EXT_pos;
	int m_DAT_ATLZ_REG_pos;
 
        unsigned long	m_COD_EMP_ADQT;
        unsigned long	m_NUM_PDV;
        std::string	m_NUM_PDV_EXT;
        std::string	m_NUM_PDV_VAN;
        std::string	m_COD_SIT_PDV_EXT;
        dbm_datetime_t	m_DAT_ATLZ_REG;
 
        // Teste de conteudo do registro
        logger::DebugWriter *m_log;

};
} //namespace dbaccess_pdv

