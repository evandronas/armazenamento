#pragma once

#include "TBSW0139.hpp"
#include<string>
#include <AcqUtils.hpp>
#include <defines.hpp>
#include<DBM3.h> //oasis_dec_t
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

class TBSW0139RegrasFormatacaoBase
{
    public:
        TBSW0139RegrasFormatacaoBase( );
        ~TBSW0139RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_TERM               ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_PNPD_PDV           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void TIP_CIP                ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_PDV                ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_VERS_SRVD_PDV      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_VERS_CLIT          ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_VERS_APLV_RCD      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_VERS_SFTW_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_VERS_ESPF_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_FBRC_PDV           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_SITE_ACQR_ORGL     ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_HOST_ACQR_ORGL     ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_FE_ACQR_ORGL       ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_SITE_ISSR          ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_HOST_ISSR          ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_FE_ISSR            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_SITE_ACQR_ATLZ     ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_HOST_ACQR_ATLZ     ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_FE_ACQR_ATLZ       ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );
        virtual void TIP_GRU_TERM           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao );

        // Metodos utilizados por campos que tem input generico (INSERT/UPDATE)
        virtual void gen_DAT_MOV_TRAN           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_COD_TERM               ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_COD_PNPD_PDV           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_TIP_CIP                ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NUM_PDV                ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NUM_VERS_SRVD_PDV      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NUM_VERS_CLIT          ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NUM_VERS_APLV_RCD      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NUM_VERS_SFTW_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NUM_VERS_ESPF_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_COD_FBRC_PDV           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_SITE_ACQR_ORGL     ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_HOST_ACQR_ORGL     ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_FE_ACQR_ORGL       ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_SITE_ISSR          ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_HOST_ISSR          ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_FE_ISSR            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_SITE_ACQR_ATLZ     ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_HOST_ACQR_ATLZ     ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_NOM_FE_ACQR_ATLZ       ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void gen_TIP_GRU_TERM           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );

        // Metodos especificos para INSERT
        virtual void insert_DAT_MOV_TRAN            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_COD_TERM                ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_COD_PNPD_PDV            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_TIP_CIP                 ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NUM_PDV                 ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NUM_VERS_SRVD_PDV       ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NUM_VERS_CLIT           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NUM_VERS_APLV_RCD       ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NUM_VERS_SFTW_BBLT_PNPD ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NUM_VERS_ESPF_BBLT_PNPD ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_COD_FBRC_PDV            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_SITE_ACQR_ORGL      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_HOST_ACQR_ORGL      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_FE_ACQR_ORGL        ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_SITE_ISSR           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_HOST_ISSR           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_FE_ISSR             ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_SITE_ACQR_ATLZ      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_HOST_ACQR_ATLZ      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_NOM_FE_ACQR_ATLZ        ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void insert_TIP_GRU_TERM            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );

        // Metodos especificos para UPDATE
        virtual void update_DAT_MOV_TRAN            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_COD_TERM                ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_COD_PNPD_PDV            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_TIP_CIP                 ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NUM_PDV                 ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NUM_VERS_SRVD_PDV       ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NUM_VERS_CLIT           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NUM_VERS_APLV_RCD       ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NUM_VERS_SFTW_BBLT_PNPD ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NUM_VERS_ESPF_BBLT_PNPD ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_COD_FBRC_PDV            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_SITE_ACQR_ORGL      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_HOST_ACQR_ORGL      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_FE_ACQR_ORGL        ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_SITE_ISSR           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_HOST_ISSR           ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_FE_ISSR             ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_SITE_ACQR_ATLZ      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_HOST_ACQR_ATLZ      ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_NOM_FE_ACQR_ATLZ        ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
        virtual void update_TIP_GRU_TERM            ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );

        logger::DebugWriter *m_log;

}; // class TBSW0139RegrasFormatacaoBase
