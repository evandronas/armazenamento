#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_common
{
    class TBSW0034 : public dbaccess::table
    {
        public:
            
            TBSW0034( );
            TBSW0034( const std::string& whereClause );            
            ~TBSW0034( );
            void setWhereClause( const std::string& whereClause );    
            void bind_columns( );
            
            void showxxx( const char *name, unsigned long campo, bool isNull );
            void showxxx( const char *name, dbm_datetime_t campo, bool isNull );
            void showxxx( const char *name, const std::string& campo, bool isNull );
            void showxxx( const char *name, oasis_dec_t campo, bool isNull );
            void showxxx( const char *name, sw_date_t campo, bool isNull );            
            void show( int nvl );
            
			void let_as_is( );
            
            void set_TXT_RLCD_CHIP( const std::string& a_TXT_RLCD_CHIP );
            void set_TXT_INFO_CMPM_CHIP( const std::string& a_TXT_INFO_CMPM_CHIP );
            void set_TXT_RSTD_ATLZ_CHIP( const std::string& a_TXT_RSTD_ATLZ_CHIP );
            void set_IND_NVL_SGRA_KMRC( const std::string& a_IND_NVL_SGRA_KMRC );
            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC );
            void set_DAT_VD_CHIP( dbm_datetime_t a_DAT_VD_CHIP );
            void set_COD_PGM_AUT( const std::string& a_COD_PGM_AUT );
            void set_IND_MTDO_VRFC_PORT( const std::string& a_IND_MTDO_VRFC_PORT );
            void set_IND_PRSC_SNHA( const std::string& a_IND_PRSC_SNHA );
            void set_NUM_SEQ_CAR_VLDC_CHIP( unsigned long a_NUM_SEQ_CAR_VLDC_CHIP );
            void set_NOM_PORT_CAR( const std::string& a_NOM_PORT_CAR );
            const std::string& get_TXT_RLCD_CHIP( ) const;
            const std::string& get_TXT_INFO_CMPM_CHIP( ) const;
            const std::string& get_TXT_RSTD_ATLZ_CHIP( ) const;
            const std::string& get_IND_NVL_SGRA_KMRC( ) const;
            unsigned long get_DAT_MOV_TRAN( ) const;
            unsigned long get_NUM_SEQ_UNC( ) const;
            dbm_datetime_t get_DAT_VD_CHIP( ) const;
            const std::string& get_COD_PGM_AUT( ) const;
            const std::string& get_IND_MTDO_VRFC_PORT( ) const;
            const std::string& get_IND_PRSC_SNHA( ) const;
            unsigned long get_NUM_SEQ_CAR_VLDC_CHIP( ) const;
            const std::string& get_NOM_PORT_CAR() const;
            

        private:
            std::string      m_TXT_RLCD_CHIP;
            std::string      m_TXT_INFO_CMPM_CHIP;
            std::string      m_TXT_RSTD_ATLZ_CHIP;
            std::string      m_IND_NVL_SGRA_KMRC;
            unsigned long    m_DAT_MOV_TRAN;
            unsigned long    m_NUM_SEQ_UNC;
            dbm_datetime_t   m_DAT_VD_CHIP;
            std::string      m_COD_PGM_AUT;
            std::string      m_IND_MTDO_VRFC_PORT;
            std::string      m_IND_PRSC_SNHA;
            unsigned long    m_NUM_SEQ_CAR_VLDC_CHIP;
            std::string      m_NOM_PORT_CAR;            
            int m_TXT_RLCD_CHIP_pos;
            int m_TXT_INFO_CMPM_CHIP_pos;
            int m_TXT_RSTD_ATLZ_CHIP_pos;
            int m_IND_NVL_SGRA_KMRC_pos;
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_DAT_VD_CHIP_pos;
            int m_COD_PGM_AUT_pos;
            int m_IND_MTDO_VRFC_PORT_pos;
            int m_IND_PRSC_SNHA_pos;
            int m_NUM_SEQ_CAR_VLDC_CHIP_pos;
            int m_NOM_PORT_CAR_pos;
            
            int m_NUM_SEQ_CAR_VLDC_CHIP_ind_null;
            void initialize();
            
            logger::DebugWriter *m_log;
    };
} //namespace dbaccess_pdv


