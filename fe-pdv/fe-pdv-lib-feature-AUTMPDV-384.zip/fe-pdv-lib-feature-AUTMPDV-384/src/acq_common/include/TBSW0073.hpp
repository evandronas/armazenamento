/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_common
{
	class TBSW0073 : public dbaccess::table
	{
	public:
		TBSW0073( );
		TBSW0073( const std::string & str );
		virtual ~TBSW0073( );
		void bind_columns( );
		long getCOD_RAM_ATVD( ) const;
		const std::string& getCOD_STTU_REG( ) const;
		long getQTD_DIA_PRZO_PRE_AUT( ) const;
	private:
		int m_COD_RAM_ATVD_pos;
		int m_COD_STTU_REG_pos;
		int m_QTD_DIA_PRZO_PRE_AUT_pos;
		long m_COD_RAM_ATVD;
		std::string m_COD_STTU_REG;
		long m_QTD_DIA_PRZO_PRE_AUT;
	};
}//namespace dbaccess_common

