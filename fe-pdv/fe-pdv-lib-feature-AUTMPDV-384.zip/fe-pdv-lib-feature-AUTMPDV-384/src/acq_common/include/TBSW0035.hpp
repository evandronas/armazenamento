#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0035 : public dbaccess::table
    {
        public:
            TBSW0035();
            TBSW0035( const std::string& whereClause );
            ~TBSW0035();

            void bind_columns();

            void set_NUM_ESTB( unsigned long a_NUM_ESTB );
            void set_COD_TERM( const std::string& a_COD_TERM );
            void set_NUM_BXA_TEC( oasis_dec_t a_NUM_BXA_TEC );
            void set_COD_VERS_SFTW( const std::string& a_COD_VERS_SFTW );
            void set_COD_APLV_PNPD( const std::string& a_COD_APLV_PNPD );
            void set_NOM_FNTS_PT_DE_VD( const std::string& a_NOM_FNTS_PT_DE_VD );
            void set_COD_STTU_RPLC( const std::string& a_COD_STTU_RPLC );
            void set_COD_VERS_KRN( const std::string& a_COD_VERS_KRN );
            void set_NUM_SRE_SMCRD( const std::string& a_NUM_SRE_SMCRD );
            void set_NOM_OPER( const std::string& a_NOM_OPER );
            void set_COD_IP_PRMI( const std::string& a_COD_IP_PRMI );
            void set_NUM_PRTA_PRMI( unsigned long a_NUM_PRTA_PRMI );
            void set_COD_IP_SECD( const std::string& a_COD_IP_SECD );
            void set_NUM_PRTA_SECD( unsigned long a_NUM_PRTA_SECD );
            void set_NOM_URL_CNFR( const std::string& a_NOM_URL_CNFR );
            void set_NOM_MODL_CHIP( const std::string& a_NOM_MODL_CHIP );
            void set_QTD_TRAN_GPRS_PRMI( unsigned long a_QTD_TRAN_GPRS_PRMI );
            void set_QTD_TRAN_GSM_PRMI( unsigned long a_QTD_TRAN_GSM_PRMI );
            void set_QTD_TRAN_GPRS_SECD( unsigned long a_QTD_TRAN_GPRS_SECD );
            void set_QTD_TRAN_GSM_SECD( unsigned long a_QTD_TRAN_GSM_SECD );
            void set_NUM_SRE_TERM( const std::string& a_NUM_SRE_TERM );
            void set_NUM_SRE_PNPD_EXT( const std::string& a_NUM_SRE_PNPD_EXT );
            void set_COD_ID_PNPD( const std::string& a_COD_ID_PNPD );
            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            void set_DTH_BXA_TEC( dbm_datetime_t a_DTH_BXA_TEC );
            void set_COD_ORDM_SERV( const std::string& a_COD_ORDM_SERV );
            void set_COD_ID_TEC( const std::string& a_COD_ID_TEC );
            void set_COD_OCOR( const std::string& a_COD_OCOR );
            void set_COD_EPS( const std::string& a_COD_EPS );
            void set_NUM_TEL_ESTB( oasis_dec_t a_NUM_TEL_ESTB );
            void set_TXT_ENDR_ESTB( const std::string& a_TXT_ENDR_ESTB );
            void set_TIP_TCNL( const std::string& a_TIP_TCNL );
            void set_QTD_TNTA_PRMI( unsigned long a_QTD_TNTA_PRMI );
            void set_QTD_TNTA_SECD( unsigned long a_QTD_TNTA_SECD );
			void set_NUM_TEL_ADIC_ESTB( const std::string& a_NUM_TEL_ADIC_ESTB );

            unsigned long get_NUM_ESTB() const;
            const std::string& get_COD_TERM() const;
            oasis_dec_t get_NUM_BXA_TEC() const;
            const std::string& get_COD_VERS_SFTW() const;
            const std::string& get_COD_APLV_PNPD() const;
            const std::string& get_NOM_FNTS_PT_DE_VD() const;
            const std::string& get_COD_STTU_RPLC() const;
            const std::string& get_COD_VERS_KRN() const;
            const std::string& get_NUM_SRE_SMCRD() const;
            const std::string& get_NOM_OPER() const;
            const std::string& get_COD_IP_PRMI() const;
            unsigned long get_NUM_PRTA_PRMI() const;
            const std::string& get_COD_IP_SECD() const;
            unsigned long get_NUM_PRTA_SECD() const;
            const std::string& get_NOM_URL_CNFR() const;
            const std::string& get_NOM_MODL_CHIP() const;
            unsigned long get_QTD_TRAN_GPRS_PRMI() const;
            unsigned long get_QTD_TRAN_GSM_PRMI() const;
            unsigned long get_QTD_TRAN_GPRS_SECD() const;
            unsigned long get_QTD_TRAN_GSM_SECD() const;
            const std::string& get_NUM_SRE_TERM() const;
            const std::string& get_NUM_SRE_PNPD_EXT() const;
            const std::string& get_COD_ID_PNPD() const;
            unsigned long get_DAT_MOV_TRAN() const;
            oasis_dec_t get_NUM_SEQ_UNC() const;
            dbm_datetime_t get_DTH_BXA_TEC() const;
            const std::string& get_COD_ORDM_SERV() const;
            const std::string& get_COD_ID_TEC() const;
            const std::string& get_COD_OCOR() const;
            const std::string& get_COD_EPS() const;
            oasis_dec_t get_NUM_TEL_ESTB() const;
            const std::string& get_TXT_ENDR_ESTB() const;
            const std::string& get_TIP_TCNL() const;
            unsigned long get_QTD_TNTA_PRMI() const;
            unsigned long get_QTD_TNTA_SECD() const;
			const std::string& get_NUM_TEL_ADIC_ESTB() const;

            void let_NUM_TEL_ESTB_as_is();
            void let_DTH_BXA_TEC_as_is();
            void let_NUM_PRTA_PRMI_as_is();
            void let_NUM_PRTA_SECD_as_is();
            void let_QTD_TRAN_GPRS_PRMI_as_is();
            void let_QTD_TRAN_GSM_PRMI_as_is();
            void let_QTD_TRAN_GPRS_SECD_as_is();
            void let_QTD_TRAN_GSM_SECD_as_is();
            void let_QTD_TNTA_PRMI_as_is();
            void let_QTD_TNTA_SECD_as_is();

            void inicializar();

        private:
            unsigned long   m_NUM_ESTB;
            std::string     m_COD_TERM;
            oasis_dec_t     m_NUM_BXA_TEC;
            std::string     m_COD_VERS_SFTW;
            std::string     m_COD_APLV_PNPD;
            std::string     m_NOM_FNTS_PT_DE_VD;
            std::string     m_COD_STTU_RPLC;
            std::string     m_COD_VERS_KRN;
            std::string     m_NUM_SRE_SMCRD;
            std::string     m_NOM_OPER;
            std::string     m_COD_IP_PRMI;
            unsigned long   m_NUM_PRTA_PRMI;
            std::string     m_COD_IP_SECD;
            unsigned long   m_NUM_PRTA_SECD;
            std::string     m_NOM_URL_CNFR;
            std::string     m_NOM_MODL_CHIP;
            unsigned long   m_QTD_TRAN_GPRS_PRMI;
            unsigned long   m_QTD_TRAN_GSM_PRMI;
            unsigned long   m_QTD_TRAN_GPRS_SECD;
            unsigned long   m_QTD_TRAN_GSM_SECD;
            std::string     m_NUM_SRE_TERM;
            std::string     m_NUM_SRE_PNPD_EXT;
            std::string     m_COD_ID_PNPD;
            unsigned long   m_DAT_MOV_TRAN;
            oasis_dec_t     m_NUM_SEQ_UNC;
            dbm_datetime_t  m_DTH_BXA_TEC;
            std::string     m_COD_ORDM_SERV;
            std::string     m_COD_ID_TEC;
            std::string     m_COD_OCOR;
            std::string     m_COD_EPS;
            oasis_dec_t     m_NUM_TEL_ESTB;
            std::string     m_TXT_ENDR_ESTB;
            std::string     m_TIP_TCNL;
            unsigned long   m_QTD_TNTA_PRMI;
            unsigned long   m_QTD_TNTA_SECD;
			std::string		m_NUM_TEL_ADIC_ESTB;

            int m_NUM_ESTB_pos;
            int m_COD_TERM_pos;
            int m_NUM_BXA_TEC_pos;
            int m_COD_VERS_SFTW_pos;
            int m_COD_APLV_PNPD_pos;
            int m_NOM_FNTS_PT_DE_VD_pos;
            int m_COD_STTU_RPLC_pos;
            int m_COD_VERS_KRN_pos;
            int m_NUM_SRE_SMCRD_pos;
            int m_NOM_OPER_pos;
            int m_COD_IP_PRMI_pos;
            int m_NUM_PRTA_PRMI_pos;
            int m_COD_IP_SECD_pos;
            int m_NUM_PRTA_SECD_pos;
            int m_NOM_URL_CNFR_pos;
            int m_NOM_MODL_CHIP_pos;
            int m_QTD_TRAN_GPRS_PRMI_pos;
            int m_QTD_TRAN_GSM_PRMI_pos;
            int m_QTD_TRAN_GPRS_SECD_pos;
            int m_QTD_TRAN_GSM_SECD_pos;
            int m_NUM_SRE_TERM_pos;
            int m_NUM_SRE_PNPD_EXT_pos;
            int m_COD_ID_PNPD_pos;
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_DTH_BXA_TEC_pos;
            int m_COD_ORDM_SERV_pos;
            int m_COD_ID_TEC_pos;
            int m_COD_OCOR_pos;
            int m_COD_EPS_pos;
            int m_NUM_TEL_ESTB_pos;
            int m_TXT_ENDR_ESTB_pos;
            int m_TIP_TCNL_pos;
            int m_QTD_TNTA_PRMI_pos;
            int m_QTD_TNTA_SECD_pos;
			int m_NUM_TEL_ADIC_ESTB_pos;

            int m_NUM_TEL_ESTB_ind_null;
            int m_DTH_BXA_TEC_ind_null;
            int m_NUM_PRTA_PRMI_ind_null;
            int m_NUM_PRTA_SECD_ind_null;
            int m_QTD_TRAN_GPRS_PRMI_ind_null;
            int m_QTD_TRAN_GSM_PRMI_ind_null;
            int m_QTD_TRAN_GPRS_SECD_ind_null;
            int m_QTD_TRAN_GSM_SECD_ind_null;
            int m_QTD_TNTA_PRMI_ind_null;
            int m_QTD_TNTA_SECD_ind_null;

    }; // class TBSW0035

} // namespace dbaccess_common