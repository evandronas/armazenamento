#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0031 : public dbaccess::table
    {
        public:
            TBSW0031( );
            TBSW0031( const std::string& whereClause );
            ~TBSW0031( );

            void initialize( );
            void bind_columns( );
			void let_as_is( );
			
            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            void set_NUM_ADM( unsigned long a_NUM_ADM );
            void set_VAL_MN_CAR( oasis_dec_t a_VAL_MN_CAR );
            void set_COD_CRT_ECM( const std::string& a_COD_CRT_ECM );
            void set_COD_CTR( const std::string& a_COD_CTR );
            void set_QTD_DIA_CRNC( unsigned long a_QTD_DIA_CRNC );
            void set_NUM_SEQ_UNC_RD_AUT( oasis_dec_t a_NUM_SEQ_UNC_RD_AUT );
            void set_IND_TERM_FATR_EXPS( const std::string& a_IND_TERM_FATR_EXPS );
            void set_COD_CTAH_VOCH( const std::string& a_COD_CTAH_VOCH );
            void set_COD_PROD_MTC( const std::string& a_COD_PROD_MTC );
            void set_COD_RGAO_MTC( const std::string& a_COD_RGAO_MTC );
            void set_COD_CPCD_TERM( const std::string& a_COD_PROD_MTC );
            void set_NUM_REF_TRAN( const std::string& a_COD_RGAO_MTC );
            // R10_2018 - Release Outubro - INICIO 
            void SetPrintedCardSecurityCode(const std::string& value);
            // R10_2018 - Release Outubro - FIM
            void SetNumeroEstabelecimentoPreAutorizacao(unsigned long value);
            void SetCodigoTerminalPreAutorizacao(const std::string& value);
            
            unsigned long get_DAT_MOV_TRAN( ) const;
            oasis_dec_t get_NUM_SEQ_UNC( ) const;
            unsigned long get_NUM_ADM( ) const;
            oasis_dec_t get_VAL_MN_CAR( ) const;
            const std::string& get_COD_CRT_ECM( ) const;
            const std::string& get_COD_CTR( ) const;
            unsigned long get_QTD_DIA_CRNC( ) const;
            oasis_dec_t get_NUM_SEQ_UNC_RD_AUT( ) const;
            const std::string& get_IND_TERM_FATR_EXPS( ) const;
            const std::string& get_COD_CTAH_VOCH( ) const;
            const std::string& get_COD_PROD_MTC( ) const;
            const std::string& get_COD_RGAO_MTC( ) const;
            const std::string& get_COD_CPCD_TERM( ) const;
            const std::string& get_NUM_REF_TRAN( ) const;
            // R10_2018 - Release Outubro - INICIO 
            const std::string& GetPrintedCardSecurityCode() const;
            // R10_2018 - Release Outubro - FIM
            unsigned long GetNumeroEstabelecimentoPreAutorizacao() const;
            const std::string& GetCodigoTerminalPreAutorizacao() const;
            
        private:
            unsigned long   m_DAT_MOV_TRAN;
            oasis_dec_t     m_NUM_SEQ_UNC;
            unsigned long   m_NUM_ADM;
            oasis_dec_t     m_VAL_MN_CAR;
            std::string     m_COD_CRT_ECM;
            std::string     m_COD_CTR;
            unsigned long   m_QTD_DIA_CRNC;
            oasis_dec_t     m_NUM_SEQ_UNC_RD_AUT;
            std::string     m_IND_TERM_FATR_EXPS;
            std::string     m_COD_CTAH_VOCH;
            std::string     m_COD_PROD_MTC;
            std::string     m_COD_RGAO_MTC;
            std::string     m_COD_CPCD_TERM;
            std::string     m_NUM_REF_TRAN;
            // R10_2018 - Release Outubro - INICIO 
            std::string					printedCardSecurityCode;
            // R10_2018 - Release Outubro - FIM
            unsigned long   numeroEstabelecimentoPreAutorizacao;
            std::string     codigoTerminalPreAutorizacao;

            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_NUM_ADM_pos;
            int m_VAL_MN_CAR_pos;
            int m_COD_CRT_ECM_pos;
            int m_COD_CTR_pos;
            int m_QTD_DIA_CRNC_pos;
            int m_NUM_SEQ_UNC_RD_AUT_pos;
            int m_IND_TERM_FATR_EXPS_pos;
            int m_COD_CTAH_VOCH_pos;
            int m_COD_PROD_MTC_pos;
            int m_COD_RGAO_MTC_pos;
            int m_COD_CPCD_TERM_pos;
            int m_NUM_REF_TRAN_pos;
            // R10_2018 - Release Outubro - INICIO 
            int printedCardSecurityCodePosicao;
            // R10_2018 - Release Outubro - FIM
            
            int m_NUM_SEQ_UNC_RD_AUT_ind_null;
            int m_QTD_DIA_CRNC_ind_null;
            int numeroEstabelecimentoPreAutorizacaoPosicao;
            int codigoTerminalPreAutorizacaoPosicao;

    }; // class TBSW0031

} // namespace dbaccess_common

