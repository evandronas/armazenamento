/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_web::TBSW0042>
/ Descri��o: <Arquivo de implementa��o da classe plugins_web::TBSW0042Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, CKen>
/ Data de Cria��o: <Thu Oct 25 13:26:42 2012
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#include "TBSW0042.hpp"

namespace dbaccess_common
{
    TBSW0042::TBSW0042()
    {

        query_fields = "A.COD_TERM, A.NUM_PDV, A.COD_STTU_REG, A.DAT_ATLZ_REG, A.COD_PSSE_TERM, A.COD_SIT_TERM, A.COD_PRDC_TERM, A.IND_ATIN, A.IND_ATCG, A.IND_UTLZ_PNPD, A.IND_TRAN_DGTD, A.COD_VERS_SFTW, A.COD_VERS_DLL, A.COD_TCNL, A.SGL_TCNL, A.TIP_LGCO, A.IND_TERM_BLQD, A.TIP_TERM, A.TIP_EQPM, A.IND_TRAN_CHIP, A.IND_TERM_LTRO_CHIP, A.DAT_ATCG, A.IND_TERM_FATR_EXPS, A.QTD_HOR_INTV";
		query_fields += ", A.NUM_SRE_TERM, A.COD_VERS_SFTW_POS";
		
        table_name = "TBSW0042 A";

        m_COD_TERM_pos = 1;
        m_NUM_PDV_pos = 2;
        m_COD_STTU_REG_pos = 3;
        m_DAT_ATLZ_REG_pos = 4;
        m_COD_PSSE_TERM_pos = 5;
        m_COD_SIT_TERM_pos = 6;
        m_COD_PRDC_TERM_pos = 7;
        m_IND_ATIN_pos = 8;
        m_IND_ATCG_pos = 9;
        m_IND_UTLZ_PNPD_pos = 10;
        m_IND_TRAN_DGTD_pos = 11;
        m_COD_VERS_SFTW_pos = 12;
        m_COD_VERS_DLL_pos = 13;
        m_COD_TCNL_pos = 14;
        m_SGL_TCNL_pos = 15;
        m_TIP_LGCO_pos = 16;
        m_IND_TERM_BLQD_pos = 17;
        m_TIP_TERM_pos = 18;
        m_TIP_EQPM_pos = 19;
        m_IND_TRAN_CHIP_pos = 20;
        m_IND_TERM_LTRO_CHIP_pos = 21;
        m_DAT_ATCG_pos = 22;
        m_IND_TERM_FATR_EXPS_pos = 23;
        m_QTD_HOR_INTV_pos = 24;
		m_NUM_SRE_TERM_pos = 25;		
        m_COD_VERS_SFTW_POS_pos = 26;

        m_COD_TERM = " ";
        m_NUM_PDV = 0;
        m_COD_STTU_REG = " ";
        m_DAT_ATLZ_REG = 0;
        m_COD_PSSE_TERM = 0;
        m_COD_PRDC_TERM = 0;
        m_COD_VERS_SFTW = 0;
        m_COD_VERS_DLL = 0;
        m_COD_TCNL = 0;
        m_TIP_TERM = " ";
        m_TIP_EQPM = " ";
        m_IND_TRAN_CHIP = " ";
        m_IND_TERM_LTRO_CHIP = " ";
        m_DAT_ATCG = 0;
        m_IND_TERM_FATR_EXPS = " ";
        m_QTD_HOR_INTV = 0;
        m_NUM_SRE_TERM = " ";		
        m_COD_VERS_SFTW_POS = " ";
        
        where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0042::TBSW0042( const std::string& whereClause )
    {

        query_fields = "A.COD_TERM, A.NUM_PDV, A.COD_STTU_REG, A.DAT_ATLZ_REG, A.COD_PSSE_TERM, A.COD_SIT_TERM, A.COD_PRDC_TERM, A.IND_ATIN, A.IND_ATCG, A.IND_UTLZ_PNPD, A.IND_TRAN_DGTD, A.COD_VERS_SFTW, A.COD_VERS_DLL, A.COD_TCNL, A.SGL_TCNL, A.TIP_LGCO, A.IND_TERM_BLQD, A.TIP_TERM, A.TIP_EQPM, A.IND_TRAN_CHIP, A.IND_TERM_LTRO_CHIP, A.DAT_ATCG, A.IND_TERM_FATR_EXPS, A.QTD_HOR_INTV";
		query_fields += ", A.NUM_SRE_TERM, A.COD_VERS_SFTW_POS";

        table_name = "TBSW0042 A";

        m_COD_TERM_pos = 1;
        m_NUM_PDV_pos = 2;
        m_COD_STTU_REG_pos = 3;
        m_DAT_ATLZ_REG_pos = 4;
        m_COD_PSSE_TERM_pos = 5;
        m_COD_SIT_TERM_pos = 6;
        m_COD_PRDC_TERM_pos = 7;
        m_IND_ATIN_pos = 8;
        m_IND_ATCG_pos = 9;
        m_IND_UTLZ_PNPD_pos = 10;
        m_IND_TRAN_DGTD_pos = 11;
        m_COD_VERS_SFTW_pos = 12;
        m_COD_VERS_DLL_pos = 13;
        m_COD_TCNL_pos = 14;
        m_SGL_TCNL_pos = 15;
        m_TIP_LGCO_pos = 16;
        m_IND_TERM_BLQD_pos = 17;
        m_TIP_TERM_pos = 18;
        m_TIP_EQPM_pos = 19;
        m_IND_TRAN_CHIP_pos = 20;
        m_IND_TERM_LTRO_CHIP_pos = 21;
        m_DAT_ATCG_pos = 22;
        m_IND_TERM_FATR_EXPS_pos = 23;
        m_QTD_HOR_INTV_pos = 24;
		m_NUM_SRE_TERM_pos = 25;		
        m_COD_VERS_SFTW_POS_pos = 26;
        m_COD_TERM = " ";
        m_NUM_PDV = 0;
        m_COD_STTU_REG = " ";
        m_DAT_ATLZ_REG = 0;
        m_COD_PSSE_TERM = 0;
        m_COD_PRDC_TERM = 0;
        m_COD_VERS_SFTW = 0;
        m_COD_VERS_DLL = 0;
        m_COD_TCNL = 0;
        m_TIP_TERM = " ";
        m_TIP_EQPM = " ";
        m_IND_TRAN_CHIP = " ";
        m_IND_TERM_LTRO_CHIP = " ";
        m_DAT_ATCG = 0;
        m_IND_TERM_FATR_EXPS = " ";
        m_QTD_HOR_INTV = 0;
        m_NUM_SRE_TERM = " ";		
        m_COD_VERS_SFTW_POS = " ";
        
        where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0042::~TBSW0042()
    {
    }

    void TBSW0042::bind_columns()
    {
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_NUM_PDV_pos, m_NUM_PDV );
        bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
        bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
        bind( m_COD_PSSE_TERM_pos, m_COD_PSSE_TERM );
        bind( m_COD_SIT_TERM_pos, m_COD_SIT_TERM );
        bind( m_COD_PRDC_TERM_pos, m_COD_PRDC_TERM );
        bind( m_IND_ATIN_pos, m_IND_ATIN );
        bind( m_IND_ATCG_pos, m_IND_ATCG );
        bind( m_IND_UTLZ_PNPD_pos, m_IND_UTLZ_PNPD );
        bind( m_IND_TRAN_DGTD_pos, m_IND_TRAN_DGTD );
        bind( m_COD_VERS_SFTW_pos, m_COD_VERS_SFTW );
        bind( m_COD_VERS_DLL_pos, m_COD_VERS_DLL );
        bind( m_COD_TCNL_pos, m_COD_TCNL );
        bind( m_SGL_TCNL_pos, m_SGL_TCNL );
        bind( m_TIP_LGCO_pos, m_TIP_LGCO );
        bind( m_IND_TERM_BLQD_pos, m_IND_TERM_BLQD );
        bind( m_TIP_TERM_pos, m_TIP_TERM );
        bind( m_TIP_EQPM_pos, m_TIP_EQPM );
        bind( m_IND_TRAN_CHIP_pos, m_IND_TRAN_CHIP );
        bind( m_IND_TERM_LTRO_CHIP_pos, m_IND_TERM_LTRO_CHIP );
        bind( m_DAT_ATCG_pos, &m_DAT_ATCG );
        bind( m_IND_TERM_FATR_EXPS_pos, m_IND_TERM_FATR_EXPS );
        bind( m_QTD_HOR_INTV_pos, m_QTD_HOR_INTV );
        bind( m_NUM_SRE_TERM_pos, m_NUM_SRE_TERM );		
        bind( m_COD_VERS_SFTW_POS_pos, m_COD_VERS_SFTW_POS );		
		
    }
    void TBSW0042::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void TBSW0042::set_NUM_PDV( unsigned long a_NUM_PDV )
    {
        m_NUM_PDV = a_NUM_PDV;
    }
    void TBSW0042::set_COD_STTU_REG( const std::string& a_COD_STTU_REG )
    {
        m_COD_STTU_REG = a_COD_STTU_REG;
    }
    void TBSW0042::set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
    {
        m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    void TBSW0042::set_COD_PSSE_TERM( unsigned long a_COD_PSSE_TERM )
    {
        m_COD_PSSE_TERM = a_COD_PSSE_TERM;
    }
    void TBSW0042::set_COD_SIT_TERM( const std::string& a_COD_SIT_TERM )
    {
        m_COD_SIT_TERM = a_COD_SIT_TERM;
    }
    void TBSW0042::set_COD_PRDC_TERM( unsigned long a_COD_PRDC_TERM )
    {
        m_COD_PRDC_TERM = a_COD_PRDC_TERM;
    }
    void TBSW0042::set_IND_ATIN( const std::string& a_IND_ATIN )
    {
        m_IND_ATIN = a_IND_ATIN;
    }
    void TBSW0042::set_IND_ATCG( const std::string& a_IND_ATCG )
    {
        m_IND_ATCG = a_IND_ATCG;
    }
    void TBSW0042::set_IND_UTLZ_PNPD( const std::string& a_IND_UTLZ_PNPD )
    {
        m_IND_UTLZ_PNPD = a_IND_UTLZ_PNPD;
    }
    void TBSW0042::set_IND_TRAN_DGTD( const std::string& a_IND_TRAN_DGTD )
    {
        m_IND_TRAN_DGTD = a_IND_TRAN_DGTD;
    }
    void TBSW0042::set_COD_VERS_SFTW( unsigned long a_COD_VERS_SFTW )
    {
        m_COD_VERS_SFTW = a_COD_VERS_SFTW;
    }
    void TBSW0042::set_COD_VERS_DLL( unsigned long a_COD_VERS_DLL )
    {
        m_COD_VERS_DLL = a_COD_VERS_DLL;
    }
    void TBSW0042::set_COD_TCNL( unsigned long a_COD_TCNL )
    {
        m_COD_TCNL = a_COD_TCNL;
    }
    void TBSW0042::set_SGL_TCNL( const std::string& a_SGL_TCNL )
    {
        m_SGL_TCNL = a_SGL_TCNL;
    }
    void TBSW0042::set_TIP_LGCO( unsigned long a_TIP_LGCO )
    {
        m_TIP_LGCO = a_TIP_LGCO;
    }
    void TBSW0042::set_IND_TERM_BLQD( const std::string& a_IND_TERM_BLQD )
    {
        m_IND_TERM_BLQD = a_IND_TERM_BLQD;
    }
    void TBSW0042::set_TIP_TERM( const std::string& a_TIP_TERM )
    {
        m_TIP_TERM = a_TIP_TERM;
    }
    void TBSW0042::set_TIP_EQPM( const std::string& a_TIP_EQPM )
    {
        m_TIP_EQPM = a_TIP_EQPM;
    }
    void TBSW0042::set_IND_TRAN_CHIP( const std::string& a_IND_TRAN_CHIP )
    {
        m_IND_TRAN_CHIP = a_IND_TRAN_CHIP;
    }
    void TBSW0042::set_IND_TERM_LTRO_CHIP( const std::string& a_IND_TERM_LTRO_CHIP )
    {
        m_IND_TERM_LTRO_CHIP = a_IND_TERM_LTRO_CHIP;
    }
    void TBSW0042::set_DAT_ATCG( dbm_datetime_t a_DAT_ATCG )
    {
        m_DAT_ATCG = a_DAT_ATCG;
    }
    void TBSW0042::set_IND_TERM_FATR_EXPS( const std::string& a_IND_TERM_FATR_EXPS )
    {
        m_IND_TERM_FATR_EXPS = a_IND_TERM_FATR_EXPS;
    }    
    void TBSW0042::set_QTD_HOR_INTV( unsigned long a_QTD_HOR_INTV )
    {
        m_QTD_HOR_INTV = a_QTD_HOR_INTV;
    }
    
    void TBSW0042::set_NUM_SRE_TERM( const std::string& a_NUM_SRE_TERM )
	{
		m_NUM_SRE_TERM = a_NUM_SRE_TERM;
	}    
	
	void TBSW0042::set_COD_VERS_SFTW_POS( const std::string& a_COD_VERS_SFTW_POS )
	{
		m_COD_VERS_SFTW_POS = a_COD_VERS_SFTW_POS;
	}

    const std::string& TBSW0042::get_COD_TERM() const
    {
        return m_COD_TERM;
    }
    unsigned long TBSW0042::get_NUM_PDV() const
    {
        return m_NUM_PDV;
    }
    const std::string& TBSW0042::get_COD_STTU_REG() const
    {
        return m_COD_STTU_REG;
    }
    dbm_datetime_t TBSW0042::get_DAT_ATLZ_REG() const
    {
        return m_DAT_ATLZ_REG;
    }
    unsigned long TBSW0042::get_COD_PSSE_TERM() const
    {
        return m_COD_PSSE_TERM;
    }
    const std::string& TBSW0042::get_COD_SIT_TERM() const
    {
        return m_COD_SIT_TERM;
    }
    unsigned long TBSW0042::get_COD_PRDC_TERM() const
    {
        return m_COD_PRDC_TERM;
    }
    const std::string& TBSW0042::get_IND_ATIN() const
    {
        return m_IND_ATIN;
    }
    const std::string& TBSW0042::get_IND_ATCG() const
    {
        return m_IND_ATCG;
    }
    const std::string& TBSW0042::get_IND_UTLZ_PNPD() const
    {
        return m_IND_UTLZ_PNPD;
    }
    const std::string& TBSW0042::get_IND_TRAN_DGTD() const
    {
        return m_IND_TRAN_DGTD;
    }
    unsigned long TBSW0042::get_COD_VERS_SFTW() const
    {
        return m_COD_VERS_SFTW;
    }
    unsigned long TBSW0042::get_COD_VERS_DLL() const
    {
        return m_COD_VERS_DLL;
    }
    unsigned long TBSW0042::get_COD_TCNL() const
    {
        return m_COD_TCNL;
    }
    const std::string& TBSW0042::get_SGL_TCNL() const
    {
        return m_SGL_TCNL;
    }
    unsigned long TBSW0042::get_TIP_LGCO() const
    {
        return m_TIP_LGCO;
    }
    const std::string& TBSW0042::get_IND_TERM_BLQD() const
    {
        return m_IND_TERM_BLQD;
    }
    const std::string& TBSW0042::get_TIP_TERM() const
    {
        return m_TIP_TERM;
    }
    const std::string& TBSW0042::get_TIP_EQPM() const
    {
        return m_TIP_EQPM;
    }
    const std::string& TBSW0042::get_IND_TRAN_CHIP() const
    {
        return m_IND_TRAN_CHIP;
    }
    const std::string& TBSW0042::get_IND_TERM_LTRO_CHIP() const
    {
        return m_IND_TERM_LTRO_CHIP;
    }    

    dbm_datetime_t TBSW0042::get_DAT_ATCG() const
    {
        return m_DAT_ATCG;
    }
    const std::string& TBSW0042::get_IND_TERM_FATR_EXPS() const
    {
        return m_IND_TERM_FATR_EXPS;
    }            
    unsigned long TBSW0042::get_QTD_HOR_INTV() const
    {
        return m_QTD_HOR_INTV;
    }
	
	const std::string& TBSW0042::get_NUM_SRE_TERM() const
	{
		return m_NUM_SRE_TERM;
	}
	const std::string& TBSW0042::get_COD_VERS_SFTW_POS() const
	{
		return m_COD_VERS_SFTW_POS;
	}

} //namespace dbaccess_common

