#include "EmptyQuery.hpp"

namespace dbaccess_common
{
    EmptyQuery::EmptyQuery( const std::string& field, const std::string& table, const std::string& where )
    {
        query_fields = field;
        table_name = table;
        where_condition = where;

        m_RESULT = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    EmptyQuery::~EmptyQuery( )
    {
    }

    void EmptyQuery::bind_columns( )
    {
        bind( 1, m_RESULT );
    }

    const std::string& EmptyQuery::get_RESULT( ) const
    {
        return( m_RESULT );
    }

} //namespace dbaccess_common
