#include "TBSW0084.hpp"

namespace dbaccess_common
{
    TBSW0084::TBSW0084()
    {
        initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

     TBSW0084::TBSW0084( const std::string& str )
    {
        initialize();
        where_condition = str;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0084::~ TBSW0084()
    {
    }

    void TBSW0084::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, COD_TERM, NUM_STAN, DTH_INI_TRAN, NUM_ESTB, COD_PNPD_PDV, NOM_FBRC_PNPD, NUM_SRE_PNPD, COD_VERS_HDW_PNPD, COD_VERS_FRWR_PNPD, NOM_FBRC_TEF, COD_VERS_SFTW_TEF, NOM_FBRC_ATMC, COD_VERS_SFTW_ATMC, QTD_LEIT_MAGN, QTD_ERR_LEIT_MAGN, QTD_SNHA_MAGN, QTD_ERR_SNHA_MAGN, QTD_SNHA_CHIP_ONLN, QTD_ERR_SNHA_CHIP_ONLN, QTD_SNHA_CHIP_OFLN, QTD_ERR_SNHA_CHIP_OFLN, QTD_BLQD_CHIP, QTD_LEIT_CHIP, QTD_FALLBACK_CRE, QTD_FALLBACK_DEB, COD_VERS_SFTW_PNPD, NUM_SEQ_UNC";

        table_name = "TBSW0084";

        m_DAT_MOV_TRAN_pos = 1;
        m_COD_TERM_pos = 2;
        m_NUM_STAN_pos = 3;
        m_DTH_INI_TRAN_pos = 4;
        m_NUM_ESTB_pos = 5;
        m_COD_PNPD_PDV_pos = 6;
        m_NOM_FBRC_PNPD_pos = 7;
        m_NUM_SRE_PNPD_pos = 8;
        m_COD_VERS_HDW_PNPD_pos = 9;
        m_COD_VERS_FRWR_PNPD_pos = 10;
        m_NOM_FBRC_TEF_pos = 11;
        m_COD_VERS_SFTW_TEF_pos = 12;
        m_NOM_FBRC_ATMC_pos = 13;
        m_COD_VERS_SFTW_ATMC_pos = 14;
        m_QTD_LEIT_MAGN_pos = 15;
        m_QTD_ERR_LEIT_MAGN_pos = 16;
        m_QTD_SNHA_MAGN_pos = 17;
        m_QTD_ERR_SNHA_MAGN_pos = 18;
        m_QTD_SNHA_CHIP_ONLN_pos = 19;
        m_QTD_ERR_SNHA_CHIP_ONLN_pos = 20;
        m_QTD_SNHA_CHIP_OFLN_pos = 21;
        m_QTD_ERR_SNHA_CHIP_OFLN_pos = 22;
        m_QTD_BLQD_CHIP_pos = 23;
        m_QTD_LEIT_CHIP_pos = 24;
        m_QTD_FALLBACK_CRE_pos = 25;
        m_QTD_FALLBACK_DEB_pos = 26;
        m_COD_VERS_SFTW_PNPD_pos = 27;
        m_NUM_SEQ_UNC_pos = 28;

        m_DAT_MOV_TRAN = 0;
        m_COD_TERM = " ";
        dbm_longtodec( &m_NUM_STAN, 0 );
        m_DTH_INI_TRAN = 0;
        m_NUM_ESTB = 0;
        m_COD_PNPD_PDV = "";
        m_NOM_FBRC_PNPD = "";
        m_NUM_SRE_PNPD = " ";
        m_COD_VERS_HDW_PNPD = "";
        m_COD_VERS_FRWR_PNPD = "";
        m_NOM_FBRC_TEF = "";
        m_COD_VERS_SFTW_TEF = "";
        m_NOM_FBRC_ATMC = "";
        m_COD_VERS_SFTW_ATMC = "";
        m_QTD_LEIT_MAGN = 0;
        m_QTD_ERR_LEIT_MAGN = 0;
        m_QTD_SNHA_MAGN = 0;
        m_QTD_ERR_SNHA_MAGN = 0;
        m_QTD_SNHA_CHIP_ONLN = 0;
        m_QTD_ERR_SNHA_CHIP_ONLN = 0;
        m_QTD_SNHA_CHIP_OFLN = 0;
        m_QTD_ERR_SNHA_CHIP_OFLN = 0;
        m_QTD_BLQD_CHIP = 0;
        m_QTD_LEIT_CHIP = 0;
        m_QTD_FALLBACK_CRE = 0;
        m_QTD_FALLBACK_DEB = 0;
        m_COD_VERS_SFTW_PNPD = "";
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
    }

    void  TBSW0084::bind_columns()
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_NUM_STAN_pos, m_NUM_STAN );
        bind( m_DTH_INI_TRAN_pos, &m_DTH_INI_TRAN );
        bind( m_NUM_ESTB_pos, m_NUM_ESTB );
        bind( m_COD_PNPD_PDV_pos, m_COD_PNPD_PDV );
        bind( m_NOM_FBRC_PNPD_pos, m_NOM_FBRC_PNPD );
        bind( m_NUM_SRE_PNPD_pos, m_NUM_SRE_PNPD );
        bind( m_COD_VERS_HDW_PNPD_pos, m_COD_VERS_HDW_PNPD );
        bind( m_COD_VERS_FRWR_PNPD_pos, m_COD_VERS_FRWR_PNPD );
        bind( m_NOM_FBRC_TEF_pos, m_NOM_FBRC_TEF );
        bind( m_COD_VERS_SFTW_TEF_pos, m_COD_VERS_SFTW_TEF );
        bind( m_NOM_FBRC_ATMC_pos, m_NOM_FBRC_ATMC );
        bind( m_COD_VERS_SFTW_ATMC_pos, m_COD_VERS_SFTW_ATMC );
        bind( m_QTD_LEIT_MAGN_pos, m_QTD_LEIT_MAGN );
        bind( m_QTD_ERR_LEIT_MAGN_pos, m_QTD_ERR_LEIT_MAGN );
        bind( m_QTD_SNHA_MAGN_pos, m_QTD_SNHA_MAGN );
        bind( m_QTD_ERR_SNHA_MAGN_pos, m_QTD_ERR_SNHA_MAGN );
        bind( m_QTD_SNHA_CHIP_ONLN_pos, m_QTD_SNHA_CHIP_ONLN );
        bind( m_QTD_ERR_SNHA_CHIP_ONLN_pos, m_QTD_ERR_SNHA_CHIP_ONLN );
        bind( m_QTD_SNHA_CHIP_OFLN_pos, m_QTD_SNHA_CHIP_OFLN );
        bind( m_QTD_ERR_SNHA_CHIP_OFLN_pos, m_QTD_ERR_SNHA_CHIP_OFLN );
        bind( m_QTD_BLQD_CHIP_pos, m_QTD_BLQD_CHIP );
        bind( m_QTD_LEIT_CHIP_pos, m_QTD_LEIT_CHIP );
        bind( m_QTD_FALLBACK_CRE_pos, m_QTD_FALLBACK_CRE );
        bind( m_QTD_FALLBACK_DEB_pos, m_QTD_FALLBACK_DEB );
        bind( m_COD_VERS_SFTW_PNPD_pos, m_COD_VERS_SFTW_PNPD );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
    }

    void TBSW0084::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0084::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void TBSW0084::set_NUM_STAN( const oasis_dec_t& a_NUM_STAN )
    {
        m_NUM_STAN = a_NUM_STAN;
    }
    void TBSW0084::set_DTH_INI_TRAN( const dbm_datetime_t& a_DTH_INI_TRAN )
    {
        m_DTH_INI_TRAN = a_DTH_INI_TRAN;
    }
    void TBSW0084::set_NUM_ESTB( unsigned long a_NUM_ESTB )
    {
        m_NUM_ESTB = a_NUM_ESTB;
    }
    void TBSW0084::set_COD_PNPD_PDV( const std::string& a_COD_PNPD_PDV )
    {
        m_COD_PNPD_PDV = a_COD_PNPD_PDV;
    }
    void TBSW0084::set_NOM_FBRC_PNPD( const std::string& a_NOM_FBRC_PNPD )
    {
        m_NOM_FBRC_PNPD = a_NOM_FBRC_PNPD;
    }
    void TBSW0084::set_NUM_SRE_PNPD( const std::string& a_NUM_SRE_PNPD )
    {
        m_NUM_SRE_PNPD = a_NUM_SRE_PNPD;
    }
    void TBSW0084::set_COD_VERS_HDW_PNPD( const std::string& a_COD_VERS_HDW_PNPD )
    {
        m_COD_VERS_HDW_PNPD = a_COD_VERS_HDW_PNPD;
    }
    void TBSW0084::set_COD_VERS_FRWR_PNPD( const std::string& a_COD_VERS_FRWR_PNPD )
    {
        m_COD_VERS_FRWR_PNPD = a_COD_VERS_FRWR_PNPD;
    }
    void TBSW0084::set_NOM_FBRC_TEF( const std::string& a_NOM_FBRC_TEF )
    {
        m_NOM_FBRC_TEF = a_NOM_FBRC_TEF;
    }
    void TBSW0084::set_COD_VERS_SFTW_TEF( const std::string& a_COD_VERS_SFTW_TEF )
    {
        m_COD_VERS_SFTW_TEF = a_COD_VERS_SFTW_TEF;
    }
    void TBSW0084::set_NOM_FBRC_ATMC( const std::string& a_NOM_FBRC_ATMC )
    {
        m_NOM_FBRC_ATMC = a_NOM_FBRC_ATMC;
    }
    void TBSW0084::set_COD_VERS_SFTW_ATMC( const std::string& a_COD_VERS_SFTW_ATMC )
    {
        m_COD_VERS_SFTW_ATMC = a_COD_VERS_SFTW_ATMC;
    }
    void TBSW0084::set_QTD_LEIT_MAGN( unsigned long a_QTD_LEIT_MAGN )
    {
        m_QTD_LEIT_MAGN = a_QTD_LEIT_MAGN;
    }
    void TBSW0084::set_QTD_ERR_LEIT_MAGN( unsigned long a_QTD_ERR_LEIT_MAGN )
    {
        m_QTD_ERR_LEIT_MAGN = a_QTD_ERR_LEIT_MAGN;
    }
    void TBSW0084::set_QTD_SNHA_MAGN( unsigned long a_QTD_SNHA_MAGN )
    {
        m_QTD_SNHA_MAGN = a_QTD_SNHA_MAGN;
    }
    void TBSW0084::set_QTD_ERR_SNHA_MAGN( unsigned long a_QTD_ERR_SNHA_MAGN )
    {
        m_QTD_ERR_SNHA_MAGN = a_QTD_ERR_SNHA_MAGN;
    }
    void TBSW0084::set_QTD_SNHA_CHIP_ONLN( unsigned long a_QTD_SNHA_CHIP_ONLN )
    {
        m_QTD_SNHA_CHIP_ONLN = a_QTD_SNHA_CHIP_ONLN;
    }
    void TBSW0084::set_QTD_ERR_SNHA_CHIP_ONLN( unsigned long a_QTD_ERR_SNHA_CHIP_ONLN )
    {
        m_QTD_ERR_SNHA_CHIP_ONLN = a_QTD_ERR_SNHA_CHIP_ONLN;
    }
    void TBSW0084::set_QTD_SNHA_CHIP_OFLN( unsigned long a_QTD_SNHA_CHIP_OFLN )
    {
        m_QTD_SNHA_CHIP_OFLN = a_QTD_SNHA_CHIP_OFLN;
    }
    void TBSW0084::set_QTD_ERR_SNHA_CHIP_OFLN( unsigned long a_QTD_ERR_SNHA_CHIP_OFLN )
    {
        m_QTD_ERR_SNHA_CHIP_OFLN = a_QTD_ERR_SNHA_CHIP_OFLN;
    }
    void TBSW0084::set_QTD_BLQD_CHIP( unsigned long a_QTD_BLQD_CHIP )
    {
        m_QTD_BLQD_CHIP = a_QTD_BLQD_CHIP;
    }
    void TBSW0084::set_QTD_LEIT_CHIP( unsigned long a_QTD_LEIT_CHIP )
    {
        m_QTD_LEIT_CHIP = a_QTD_LEIT_CHIP;
    }
    void TBSW0084::set_QTD_FALLBACK_CRE( unsigned long a_QTD_FALLBACK_CRE )
    {
        m_QTD_FALLBACK_CRE = a_QTD_FALLBACK_CRE;
    }
    void TBSW0084::set_QTD_FALLBACK_DEB( unsigned long a_QTD_FALLBACK_DEB )
    {
        m_QTD_FALLBACK_DEB = a_QTD_FALLBACK_DEB;
    }
    void TBSW0084::set_COD_VERS_SFTW_PNPD( const std::string& a_COD_VERS_SFTW_PNPD )
    {
        m_COD_VERS_SFTW_PNPD = a_COD_VERS_SFTW_PNPD;
    }
    void TBSW0084::set_NUM_SEQ_UNC( const oasis_dec_t& a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }

    unsigned long TBSW0084::get_DAT_MOV_TRAN() const
    {
        return m_DAT_MOV_TRAN;
    }
    const std::string& TBSW0084::get_COD_TERM() const
    {
        return m_COD_TERM;
    }
    const oasis_dec_t& TBSW0084::get_NUM_STAN() const
    {
        return m_NUM_STAN;
    }
    const dbm_datetime_t& TBSW0084::get_DTH_INI_TRAN() const
    {
        return m_DTH_INI_TRAN;
    }
    unsigned long TBSW0084::get_NUM_ESTB() const
    {
        return m_NUM_ESTB;
    }
    const std::string& TBSW0084::get_COD_PNPD_PDV() const
    {
        return m_COD_PNPD_PDV;
    }
    const std::string& TBSW0084::get_NOM_FBRC_PNPD() const
    {
        return m_NOM_FBRC_PNPD;
    }
    const std::string& TBSW0084::get_NUM_SRE_PNPD() const
    {
        return m_NUM_SRE_PNPD;
    }
    const std::string& TBSW0084::get_COD_VERS_HDW_PNPD() const
    {
        return m_COD_VERS_HDW_PNPD;
    }
    const std::string& TBSW0084::get_COD_VERS_FRWR_PNPD() const
    {
        return m_COD_VERS_FRWR_PNPD;
    }
    const std::string& TBSW0084::get_NOM_FBRC_TEF() const
    {
        return m_NOM_FBRC_TEF;
    }
    const std::string& TBSW0084::get_COD_VERS_SFTW_TEF() const
    {
        return m_COD_VERS_SFTW_TEF;
    }
    const std::string& TBSW0084::get_NOM_FBRC_ATMC() const
    {
        return m_NOM_FBRC_ATMC;
    }
    const std::string& TBSW0084::get_COD_VERS_SFTW_ATMC() const
    {
        return m_COD_VERS_SFTW_ATMC;
    }
    unsigned long TBSW0084::get_QTD_LEIT_MAGN() const
    {
        return m_QTD_LEIT_MAGN;
    }
    unsigned long TBSW0084::get_QTD_ERR_LEIT_MAGN() const
    {
        return m_QTD_ERR_LEIT_MAGN;
    }
    unsigned long TBSW0084::get_QTD_SNHA_MAGN() const
    {
        return m_QTD_SNHA_MAGN;
    }
    unsigned long TBSW0084::get_QTD_ERR_SNHA_MAGN() const
    {
        return m_QTD_ERR_SNHA_MAGN;
    }
    unsigned long TBSW0084::get_QTD_SNHA_CHIP_ONLN() const
    {
        return m_QTD_SNHA_CHIP_ONLN;
    }
    unsigned long TBSW0084::get_QTD_ERR_SNHA_CHIP_ONLN() const
    {
        return m_QTD_ERR_SNHA_CHIP_ONLN;
    }
    unsigned long TBSW0084::get_QTD_SNHA_CHIP_OFLN() const
    {
        return m_QTD_SNHA_CHIP_OFLN;
    }
    unsigned long TBSW0084::get_QTD_ERR_SNHA_CHIP_OFLN() const
    {
        return m_QTD_ERR_SNHA_CHIP_OFLN;
    }
    unsigned long TBSW0084::get_QTD_BLQD_CHIP() const
    {
        return m_QTD_BLQD_CHIP;
    }
    unsigned long TBSW0084::get_QTD_LEIT_CHIP() const
    {
        return m_QTD_LEIT_CHIP;
    }
    unsigned long TBSW0084::get_QTD_FALLBACK_CRE() const
    {
        return m_QTD_FALLBACK_CRE;
    }
    unsigned long TBSW0084::get_QTD_FALLBACK_DEB() const
    {
        return m_QTD_FALLBACK_DEB;
    }
    const std::string& TBSW0084::get_COD_VERS_SFTW_PNPD() const
    {
        return m_COD_VERS_SFTW_PNPD;
    }
    const oasis_dec_t& TBSW0084::get_NUM_SEQ_UNC() const
    {
        return m_NUM_SEQ_UNC;
    }

} // namespace dbaccess_common

