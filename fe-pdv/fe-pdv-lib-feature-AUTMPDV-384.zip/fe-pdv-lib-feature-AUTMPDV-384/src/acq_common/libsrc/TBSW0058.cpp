#include "TBSW0058.hpp"

namespace dbaccess_common
{
    TBSW0058::TBSW0058( )
    {
        initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_BASEUNICA);
    }
    TBSW0058::TBSW0058( const std::string& whereClause )
    {
        initialize();
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_BASEUNICA);
    }

    TBSW0058::~TBSW0058( )
    {
    }
    
    void TBSW0058::initialize()
    {
	    m_log = logger::DebugWriter::getInstance();
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, TIP_TRAN, NUM_MOT_RSPS, NUM_ESTB, COD_TERM, NUM_RD_ORG, COD_POS_ENTR_MODO, COD_EMSR, VAL_TRAN, COD_RAM_ATVD, NUM_CAR, NUM_AUT, VAL_COT_DLR, DAT_VLD_CAR, COD_TRK_CAR, COD_MOED, COD_PAIS_CAR, COD_SERV_SNHA, IND_RD_ORG, COD_MOT_AUT, DAT_PAUZ, COD_GRU_ESTB, COD_MTZ_ESTB, DTH_INI_TRAN, DTH_STTU_TRAN, DTH_GMT, NUM_STAN, VAL_EFTV_CPTR, QTD_PRCL_CNFR, IND_RD_CPTR, COD_CNDC_CPTR, DAT_CNFR_PAUZ, VAL_TRAN_DLR, DAT_CAN_PAUZ, DAT_VLD_PAUZ, NOM_PORT_CAR, COD_MSG_ISO, COD_PCM_ISO, NOM_SITE_ACQR_ORGL, NOM_HOST_ACQR_ORGL, NOM_FE_ACQR_ORGL, NOM_SITE_ISSR, NOM_HOST_ISSR, NOM_FE_ISSR, NOM_SITE_ACQR_ATLZ, NOM_HOST_ACQR_ATLZ, NOM_FE_ACQR_ATLZ, COD_MOT_ISO_EMSR, COD_TERM_CNFR, DAT_MOV_TRAN_CNFR, DTH_CNFR, IND_RD_ORG_ESTR, IND_STTU_TRAN, NUM_EMSR, NUM_ESTB_CNFR, NUM_ESTB_ESTR, NUM_ID_CAR, NUM_SEQ_UNC_CNFR, NUM_STAN_ORGL, COD_BNDR, IND_EMSR_MTC, NUM_AVSO_AUT, TXT_DA_ADIC_EMSR, NOM_FNTS_PDV, COD_PGM_AUT, IND_NVL_SGRA_KMRC, COD_UCAF, COD_AUT_EMSR_CNVT, COD_AUT_EMSR, COD_NTWK_ID_ACQR_ATLZ, COD_NTWK_ID_ACQR_ORGL, COD_NTWK_ID_ROUT_ATLZ, COD_NTWK_ID_ROUT_ORGL, COD_NTWK_ID_ISSR_ATLZ, COD_NTWK_ID_ISSR_ORGL, COD_CTAH_VOCH, COD_TIP_PROD_CAR, NUM_PDV_EXT, NUM_PDV_VAN, COD_GRU_CLAS_RAM, COD_CPCD_TERM, NUM_REF_TRAN, IND_TRAN_TKN, COD_ORG_APRV, COD_PROD_MTC, COD_RGAO_MTC, COD_RET_VLDC_SGRA";
        query_fields.append(", COD_PORT_PRES_VLDC_BNDR, COD_CPCD_TERM_VLDC_BNDR, COD_PCM_EMS, ID_REF_BNDR, COD_SERV_CORP, COD_SIT_OFRT");

        table_name = "TBSW0058";

        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_TIP_TRAN_pos = 3;
        m_NUM_MOT_RSPS_pos = 4;
        m_NUM_ESTB_pos = 5;
        m_COD_TERM_pos = 6;
        m_NUM_RD_ORG_pos = 7;
        m_COD_POS_ENTR_MODO_pos = 8;
        m_COD_EMSR_pos = 9;
        m_VAL_TRAN_pos = 10;
        m_COD_RAM_ATVD_pos = 11;
        m_NUM_CAR_pos = 12;
        m_NUM_AUT_pos = 13;
        m_VAL_COT_DLR_pos = 14;
        m_DAT_VLD_CAR_pos = 15;
        m_COD_TRK_CAR_pos = 16;
        m_COD_MOED_pos = 17;
        m_COD_PAIS_CAR_pos = 18;
        m_COD_SERV_SNHA_pos = 19;
        m_IND_RD_ORG_pos = 20;
        m_COD_MOT_AUT_pos = 21;
        m_DAT_PAUZ_pos = 22;
        m_COD_GRU_ESTB_pos = 23;
        m_COD_MTZ_ESTB_pos = 24;
        m_DTH_INI_TRAN_pos = 25;
        m_DTH_STTU_TRAN_pos = 26;
        m_DTH_GMT_pos = 27;
        m_NUM_STAN_pos = 28;
        m_VAL_EFTV_CPTR_pos = 29;
        m_QTD_PRCL_CNFR_pos = 30;
        m_IND_RD_CPTR_pos = 31;
        m_COD_CNDC_CPTR_pos = 32;
        m_DAT_CNFR_PAUZ_pos = 33;
        m_VAL_TRAN_DLR_pos = 34;
        m_DAT_CAN_PAUZ_pos = 35;
        m_DAT_VLD_PAUZ_pos = 36;
        m_NOM_PORT_CAR_pos = 37;
        m_COD_MSG_ISO_pos = 38;
        m_COD_PCM_ISO_pos = 39;
        m_NOM_SITE_ACQR_ORGL_pos = 40;
        m_NOM_HOST_ACQR_ORGL_pos = 41;
        m_NOM_FE_ACQR_ORGL_pos = 42;
        m_NOM_SITE_ISSR_pos = 43;
        m_NOM_HOST_ISSR_pos = 44;
        m_NOM_FE_ISSR_pos = 45;
        m_NOM_SITE_ACQR_ATLZ_pos = 46;
        m_NOM_HOST_ACQR_ATLZ_pos = 47;
        m_NOM_FE_ACQR_ATLZ_pos = 48;
        m_COD_MOT_ISO_EMSR_pos = 49;
        m_COD_TERM_CNFR_pos = 50;
        m_DAT_MOV_TRAN_CNFR_pos = 51;
        m_DTH_CNFR_pos = 52;
        m_IND_RD_ORG_ESTR_pos = 53;
        m_IND_STTU_TRAN_pos = 54;
        m_NUM_EMSR_pos = 55;
        m_NUM_ESTB_CNFR_pos = 56;
        m_NUM_ESTB_ESTR_pos = 57;
        m_NUM_ID_CAR_pos = 58;
        m_NUM_SEQ_UNC_CNFR_pos = 59;
        m_NUM_STAN_ORGL_pos = 60;
        m_COD_BNDR_pos = 61;
        m_IND_EMSR_MTC_pos = 62;
        m_NUM_AVSO_AUT_pos = 63;
        m_TXT_DA_ADIC_EMSR_pos = 64;
        m_NOM_FNTS_PDV_pos = 65;
        m_COD_PGM_AUT_pos = 66;
        m_IND_NVL_SGRA_KMRC_pos = 67;
        m_COD_UCAF_pos = 68;
        m_COD_AUT_EMSR_CNVT_pos = 69;
        m_COD_AUT_EMSR_pos = 70;
        m_NTWK_ID_ACQR_ATLZ_pos = 71;
        m_NTWK_ID_ACQR_ORGL_pos = 72;
        m_NTWK_ID_ROUTE_ATLZ_pos = 73;
        m_NTWK_ID_ROUTE_ORGL_pos = 74;
        m_NTWK_ID_ISSR_ATLZ_pos = 75;
        m_NTWK_ID_ISSR_ORGL_pos = 76;
        m_COD_CTAH_VOCH_pos = 77;
        m_COD_TIP_PROD_CAR_pos = 78;
        m_NUM_PDV_EXT_pos = 79;
        m_NUM_PDV_VAN_pos = 80;
        m_COD_GRU_CLAS_RAM_pos = 81;
        m_COD_CPCD_TERM_pos = 82;
        m_NUM_REF_TRAN_pos = 83;
        m_IND_TRAN_TKN_pos = 84;
        codigoOrigemAprovacaoPos = 85;
        codigoProdutoMastercardPos = 86; /// COD_PROD_MTC
        codigoRegiaoMastercardPos = 87; /// COD_RGAO_MTC
        // R10_2018 - Release Outubro - INICIO 
        printedCardSecurityCodePosicao = 88;
        // R10_2018 - Release Outubro - FIM
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        posicaoIndicadorPresencaPortador    = 89;
        posicaoIndicadorTecnologiaTerminal  = 90;
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        codigoProcessoEmissorPos = 91;
        identificadorReferenciaBandeiraPos = 92;
        codigoServicoCorporativoPos = 93;
        codigoSituacaoOfertaPos = 94;
        
            // NUM_SEQ_UNC                    NOT NULL NUMBER(12)     
            // VAL_TRAN                       NOT NULL NUMBER(13,2)         
            // VAL_COT_DLR                             NUMBER(13,4)          
            // COD_GRU_ESTB                   NOT NULL NUMBER(12)    
            // COD_MTZ_ESTB                   NOT NULL NUMBER(12)           
            // NUM_STAN                       NOT NULL NUMBER(12)    
            // VAL_EFTV_CPTR                           NUMBER(13,2)          
            // VAL_TRAN_DLR                            NUMBER(13,2)     
            // NUM_ID_CAR                              NUMBER(11)    
            // NUM_SEQ_UNC_CNFR                        NUMBER(12)    
            // NUM_STAN_ORGL                           NUMBER(12)

        m_DAT_MOV_TRAN = 0;
        m_NUM_SEQ_UNC = 0;
        m_TIP_TRAN = 0;
        m_NUM_MOT_RSPS = 0;
        m_NUM_ESTB = 0;
        m_COD_TERM = " ";
        m_NUM_RD_ORG = 0;
        m_COD_POS_ENTR_MODO = " ";
        m_COD_EMSR = 0;
        dbm_chartodec( &m_VAL_TRAN, "0.00", 2 );
        m_COD_RAM_ATVD = 0;
        m_NUM_CAR = " ";
        m_NUM_AUT = " ";
        dbm_chartodec( &m_VAL_COT_DLR, "0.0000", 4 );
        m_DAT_VLD_CAR.date = 0;
        m_COD_TRK_CAR = " ";
        m_COD_MOED = " ";
        m_COD_PAIS_CAR = " ";
        m_COD_SERV_SNHA = " ";
        m_IND_RD_ORG = " ";
        m_COD_MOT_AUT = " ";
        m_DAT_PAUZ = 0;
        m_COD_GRU_ESTB = 0 ;
        m_COD_MTZ_ESTB = 0 ;
        m_DTH_INI_TRAN = 0;
        m_DTH_STTU_TRAN = 0;
        m_DTH_GMT = 0;
        m_NUM_STAN = 0 ;
        dbm_chartodec( &m_VAL_EFTV_CPTR, "0.00", 2 );
        m_QTD_PRCL_CNFR = 0;
        m_IND_RD_CPTR = "";
        m_COD_CNDC_CPTR = "";
        m_DAT_CNFR_PAUZ = 0;
        dbm_chartodec( &m_VAL_TRAN_DLR, "0.00", 2 );
        m_DAT_CAN_PAUZ = 0;
        m_DAT_VLD_PAUZ = 0;
        m_NOM_PORT_CAR = "";
        m_COD_MSG_ISO = 0;
        m_COD_PCM_ISO = 0;
        m_NOM_SITE_ACQR_ORGL = " ";
        m_NOM_HOST_ACQR_ORGL = " ";
        m_NOM_FE_ACQR_ORGL = " ";
        m_NOM_SITE_ISSR = "";
        m_NOM_HOST_ISSR = "";
        m_NOM_FE_ISSR = "";
        m_NOM_SITE_ACQR_ATLZ = "";
        m_NOM_HOST_ACQR_ATLZ = "";
        m_NOM_FE_ACQR_ATLZ = "";
        m_COD_MOT_ISO_EMSR = "";
        m_COD_TERM_CNFR = "";
        m_DAT_MOV_TRAN_CNFR = 0;
        m_DTH_CNFR = 0;
        m_IND_RD_ORG_ESTR = "";
        m_IND_STTU_TRAN = " ";
        m_NUM_EMSR = 0;
        m_NUM_ESTB_CNFR = 0;
        m_NUM_ESTB_ESTR = 0;    
        m_NUM_SEQ_UNC_CNFR = 0 ;
        m_NUM_STAN_ORGL = 0 ;
        dbm_chartodec( &m_NUM_ID_CAR, "0", 0 );
        m_COD_BNDR = 0;
        m_IND_EMSR_MTC = " ";
        m_NUM_AVSO_AUT = "";
        m_TXT_DA_ADIC_EMSR = "";
        m_NOM_FNTS_PDV = "";
        m_COD_PGM_AUT = "";
        m_IND_NVL_SGRA_KMRC = "";
        m_COD_UCAF = "";
        m_COD_AUT_EMSR_CNVT = "";
        m_COD_AUT_EMSR = "";
        m_NTWK_ID_ACQR_ATLZ = "";
        m_NTWK_ID_ACQR_ORGL = "";
        m_NTWK_ID_ROUTE_ATLZ = "";
        m_NTWK_ID_ROUTE_ORGL = "";
        m_NTWK_ID_ISSR_ATLZ = "";
        m_NTWK_ID_ISSR_ORGL = "";
        m_COD_CTAH_VOCH = "";
        m_COD_TIP_PROD_CAR = "";
        m_NUM_PDV_EXT = "";
        m_NUM_PDV_VAN = "";
        m_COD_GRU_CLAS_RAM = 0;
        m_COD_CPCD_TERM = "";
        m_NUM_REF_TRAN = "";
        m_IND_TRAN_TKN = " ";
        codigoOrigemAprovacao = " ";
        codigoProdutoMastercard = " "; /// COD_PROD_MTC
        codigoRegiaoMastercard = " "; /// COD_RGAO_MTC
        // R10_2018 - Release Outubro - INICIO 
        printedCardSecurityCode = "";
        // R10_2018 - Release Outubro - FIM
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        indicadorPresencaPortador = " ";
        indicadorTecnologiaTerminal = " ";
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        codigoProcessoEmissor = 0;
        identificadorReferenciaBandeira = "";
        codigoServicoCorporativo = 0;
        codigoSituacaoOferta = 0;
        
        m_VAL_EFTV_CPTR_ind_null = DBM_NULL_DATA;
        m_QTD_PRCL_CNFR_ind_null = DBM_NULL_DATA;
        m_DAT_CNFR_PAUZ_ind_null = DBM_NULL_DATA;
        m_DAT_CAN_PAUZ_ind_null = DBM_NULL_DATA;
        m_DAT_MOV_TRAN_CNFR_ind_null = DBM_NULL_DATA;
        m_DTH_CNFR_ind_null = DBM_NULL_DATA;
        m_NUM_ESTB_CNFR_ind_null = DBM_NULL_DATA;
        m_NUM_ESTB_ESTR_ind_null = DBM_NULL_DATA;
        m_NUM_ID_CAR_ind_null = DBM_NULL_DATA;
        m_NUM_SEQ_UNC_CNFR_ind_null = DBM_NULL_DATA;
        m_NUM_STAN_ORGL_ind_null = DBM_NULL_DATA;
        m_VAL_TRAN_DLR_ind_null = DBM_NULL_DATA;
    }
    
	void TBSW0058::let_as_is( )
	{
        m_DAT_CNFR_PAUZ_ind_null = is_null( &m_DAT_CNFR_PAUZ ) ? DBM_NULL_DATA : 0;
        m_DAT_CAN_PAUZ_ind_null = is_null( &m_DAT_CAN_PAUZ ) ? DBM_NULL_DATA : 0;
        m_DTH_CNFR_ind_null = is_null( &m_DTH_CNFR ) ? DBM_NULL_DATA : 0;
        m_NUM_ESTB_CNFR_ind_null = is_null( m_NUM_ESTB_CNFR ) ? DBM_NULL_DATA : 0;
        m_NUM_ESTB_ESTR_ind_null = is_null( m_NUM_ESTB_ESTR ) ? DBM_NULL_DATA : 0;
        m_QTD_PRCL_CNFR_ind_null = is_null( m_QTD_PRCL_CNFR ) ? DBM_NULL_DATA : 0;
        m_VAL_EFTV_CPTR_ind_null = is_null( m_VAL_EFTV_CPTR ) ? DBM_NULL_DATA : 0;
        m_NUM_SEQ_UNC_CNFR_ind_null = is_null( m_NUM_SEQ_UNC_CNFR ) ? DBM_NULL_DATA : 0;
        m_DAT_MOV_TRAN_CNFR_ind_null = is_null( &m_DAT_MOV_TRAN_CNFR ) ? DBM_NULL_DATA : 0;
        m_NUM_ID_CAR_ind_null = is_null( &m_NUM_ID_CAR ) ? DBM_NULL_DATA : 0;
        m_IND_RD_CPTR_ind_null = is_null( &m_IND_RD_CPTR ) ? DBM_NULL_DATA : 0;
        m_NUM_STAN_ORGL_ind_null = is_null(m_NUM_STAN_ORGL) ? DBM_NULL_DATA : 0;
        m_VAL_TRAN_DLR_ind_null = is_null( &m_VAL_TRAN_DLR ) ? DBM_NULL_DATA : 0;
	}

    void TBSW0058::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_TIP_TRAN_pos, m_TIP_TRAN );
        bind( m_NUM_MOT_RSPS_pos, m_NUM_MOT_RSPS );
        bind( m_NUM_ESTB_pos, m_NUM_ESTB );
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_NUM_RD_ORG_pos, m_NUM_RD_ORG );
        bind( m_COD_POS_ENTR_MODO_pos, m_COD_POS_ENTR_MODO );
        bind( m_COD_EMSR_pos, m_COD_EMSR );
        bind( m_VAL_TRAN_pos, m_VAL_TRAN );
        bind( m_COD_RAM_ATVD_pos, m_COD_RAM_ATVD );
        bind( m_NUM_CAR_pos, m_NUM_CAR );
        bind( m_NUM_AUT_pos, m_NUM_AUT );
        bind( m_VAL_COT_DLR_pos, m_VAL_COT_DLR );
        bind( m_DAT_VLD_CAR_pos, m_DAT_VLD_CAR );
        bind( m_COD_TRK_CAR_pos, m_COD_TRK_CAR );
        bind( m_COD_MOED_pos, m_COD_MOED );
        bind( m_COD_PAIS_CAR_pos, m_COD_PAIS_CAR );
        bind( m_COD_SERV_SNHA_pos, m_COD_SERV_SNHA );
        bind( m_IND_RD_ORG_pos, m_IND_RD_ORG );
        bind( m_COD_MOT_AUT_pos, m_COD_MOT_AUT );
        bind( m_DAT_PAUZ_pos, &m_DAT_PAUZ );
        bind( m_COD_GRU_ESTB_pos, m_COD_GRU_ESTB );
        bind( m_COD_MTZ_ESTB_pos, m_COD_MTZ_ESTB );
        bind( m_DTH_INI_TRAN_pos, &m_DTH_INI_TRAN );
        bind( m_DTH_STTU_TRAN_pos, &m_DTH_STTU_TRAN );
        bind( m_DTH_GMT_pos, &m_DTH_GMT );
        bind( m_NUM_STAN_pos, m_NUM_STAN );
        bind( m_VAL_EFTV_CPTR_pos, m_VAL_EFTV_CPTR, &m_VAL_EFTV_CPTR_ind_null );
        bind( m_QTD_PRCL_CNFR_pos, m_QTD_PRCL_CNFR, &m_QTD_PRCL_CNFR_ind_null );
        bind( m_IND_RD_CPTR_pos, m_IND_RD_CPTR );
        bind( m_COD_CNDC_CPTR_pos, m_COD_CNDC_CPTR );
        bind( m_DAT_CNFR_PAUZ_pos, &m_DAT_CNFR_PAUZ, &m_DAT_CNFR_PAUZ_ind_null );
        bind( m_VAL_TRAN_DLR_pos, m_VAL_TRAN_DLR, &m_VAL_TRAN_DLR_ind_null );
        bind( m_DAT_CAN_PAUZ_pos, &m_DAT_CAN_PAUZ, &m_DAT_CAN_PAUZ_ind_null );
        bind( m_DAT_VLD_PAUZ_pos, &m_DAT_VLD_PAUZ );
        bind( m_NOM_PORT_CAR_pos, m_NOM_PORT_CAR );
        bind( m_COD_MSG_ISO_pos, m_COD_MSG_ISO );
        bind( m_COD_PCM_ISO_pos, m_COD_PCM_ISO );
        bind( m_NOM_SITE_ACQR_ORGL_pos, m_NOM_SITE_ACQR_ORGL );
        bind( m_NOM_HOST_ACQR_ORGL_pos, m_NOM_HOST_ACQR_ORGL );
        bind( m_NOM_FE_ACQR_ORGL_pos, m_NOM_FE_ACQR_ORGL );
        bind( m_NOM_SITE_ISSR_pos, m_NOM_SITE_ISSR );
        bind( m_NOM_HOST_ISSR_pos, m_NOM_HOST_ISSR );
        bind( m_NOM_FE_ISSR_pos, m_NOM_FE_ISSR );
        bind( m_NOM_SITE_ACQR_ATLZ_pos, m_NOM_SITE_ACQR_ATLZ );
        bind( m_NOM_HOST_ACQR_ATLZ_pos, m_NOM_HOST_ACQR_ATLZ );
        bind( m_NOM_FE_ACQR_ATLZ_pos, m_NOM_FE_ACQR_ATLZ );
        bind( m_COD_MOT_ISO_EMSR_pos, m_COD_MOT_ISO_EMSR );
        bind( m_COD_TERM_CNFR_pos, m_COD_TERM_CNFR );
        bind( m_DAT_MOV_TRAN_CNFR_pos, m_DAT_MOV_TRAN_CNFR, &m_DAT_MOV_TRAN_CNFR_ind_null );
        bind( m_DTH_CNFR_pos, &m_DTH_CNFR, &m_DTH_CNFR_ind_null );
        bind( m_IND_RD_ORG_ESTR_pos, m_IND_RD_ORG_ESTR );
        bind( m_IND_STTU_TRAN_pos, m_IND_STTU_TRAN );
        bind( m_NUM_EMSR_pos, m_NUM_EMSR );
        bind( m_NUM_ESTB_CNFR_pos, m_NUM_ESTB_CNFR, &m_NUM_ESTB_CNFR_ind_null );
        bind( m_COD_GRU_CLAS_RAM_pos, m_COD_GRU_CLAS_RAM );

        // t689049@FIS - Data: 26/06/2014 - Ref BT 63.966
        bind( m_NUM_ESTB_ESTR_pos, m_NUM_ESTB_ESTR, &m_NUM_ESTB_ESTR_ind_null );

        bind( m_NUM_ID_CAR_pos, m_NUM_ID_CAR, &m_NUM_ID_CAR_ind_null );
        bind( m_NUM_SEQ_UNC_CNFR_pos, m_NUM_SEQ_UNC_CNFR, &m_NUM_SEQ_UNC_CNFR_ind_null );
        bind( m_NUM_STAN_ORGL_pos, m_NUM_STAN_ORGL );
        bind( m_COD_BNDR_pos, m_COD_BNDR );
        bind( m_IND_EMSR_MTC_pos, m_IND_EMSR_MTC );
        bind( m_NUM_AVSO_AUT_pos, m_NUM_AVSO_AUT );
        bind( m_TXT_DA_ADIC_EMSR_pos, m_TXT_DA_ADIC_EMSR );
        bind( m_NOM_FNTS_PDV_pos, m_NOM_FNTS_PDV );
        bind( m_COD_PGM_AUT_pos, m_COD_PGM_AUT );
        bind( m_IND_NVL_SGRA_KMRC_pos, m_IND_NVL_SGRA_KMRC );
        bind( m_COD_UCAF_pos, m_COD_UCAF );
        bind( m_COD_AUT_EMSR_CNVT_pos, m_COD_AUT_EMSR_CNVT );
        bind( m_COD_AUT_EMSR_pos, m_COD_AUT_EMSR );
        bind( m_NTWK_ID_ACQR_ATLZ_pos, m_NTWK_ID_ACQR_ATLZ );
        bind( m_NTWK_ID_ACQR_ORGL_pos, m_NTWK_ID_ACQR_ORGL );
        bind( m_NTWK_ID_ROUTE_ATLZ_pos, m_NTWK_ID_ROUTE_ATLZ );
        bind( m_NTWK_ID_ROUTE_ORGL_pos, m_NTWK_ID_ROUTE_ORGL );
        bind( m_NTWK_ID_ISSR_ATLZ_pos, m_NTWK_ID_ISSR_ATLZ );
        bind( m_NTWK_ID_ISSR_ORGL_pos, m_NTWK_ID_ISSR_ORGL );
        //bind( m_IND_CPTRDO_pos, m_IND_CPTRDO );    // 12.11.2013 - Removido no GAP3
        //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
        bind( m_COD_CTAH_VOCH_pos, m_COD_CTAH_VOCH );
        //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//
        bind( m_COD_TIP_PROD_CAR_pos, m_COD_TIP_PROD_CAR );   // GAP 13.1
        bind( m_NUM_PDV_EXT_pos, m_NUM_PDV_EXT );
        bind( m_NUM_PDV_VAN_pos, m_NUM_PDV_VAN );

        //t689049@FIS - Data: 23/09/2014 - Ref. Iniciar com NULL.
        bind( m_NUM_STAN_ORGL_pos, m_NUM_STAN_ORGL, &m_NUM_STAN_ORGL_ind_null );        
        bind( m_COD_CPCD_TERM_pos, m_COD_CPCD_TERM );
        bind( m_NUM_REF_TRAN_pos, m_NUM_REF_TRAN );
        bind( m_IND_TRAN_TKN_pos, m_IND_TRAN_TKN );
        bind( codigoOrigemAprovacaoPos, codigoOrigemAprovacao );
        bind( codigoProdutoMastercardPos, codigoProdutoMastercard ); /// COD_PROD_MTC
        bind( codigoRegiaoMastercardPos, codigoRegiaoMastercard ); /// COD_RGAO_MTC

        // R10_2018 - Release Outubro - INICIO 
        bind( printedCardSecurityCodePosicao, printedCardSecurityCode );
        // R10_2018 - Release Outubro - FIM
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        bind( posicaoIndicadorPresencaPortador, indicadorPresencaPortador );
        bind( posicaoIndicadorTecnologiaTerminal, indicadorTecnologiaTerminal );
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        bind( codigoProcessoEmissorPos, codigoProcessoEmissor );
        bind( identificadorReferenciaBandeiraPos, identificadorReferenciaBandeira );
        bind( codigoServicoCorporativoPos, codigoServicoCorporativo );
        bind( codigoSituacaoOfertaPos, codigoSituacaoOferta );
    }

    void TBSW0058::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0058::set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC ;
    }
    void TBSW0058::set_TIP_TRAN( unsigned long a_TIP_TRAN )
    {
        m_TIP_TRAN = a_TIP_TRAN;
    }
    void TBSW0058::set_NUM_MOT_RSPS( unsigned long a_NUM_MOT_RSPS )
    {
        m_NUM_MOT_RSPS = a_NUM_MOT_RSPS;
    }
    void TBSW0058::set_NUM_ESTB( unsigned long a_NUM_ESTB )
    {
        m_NUM_ESTB = a_NUM_ESTB;
    }
    void TBSW0058::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void TBSW0058::set_NUM_RD_ORG( unsigned long a_NUM_RD_ORG )
    {
        m_NUM_RD_ORG = a_NUM_RD_ORG;
    }
    void TBSW0058::set_COD_POS_ENTR_MODO( const std::string& a_COD_POS_ENTR_MODO )
    {
        m_COD_POS_ENTR_MODO = a_COD_POS_ENTR_MODO;
    }
    void TBSW0058::set_COD_EMSR( unsigned long a_COD_EMSR )
    {
        m_COD_EMSR = a_COD_EMSR;
    }
    void TBSW0058::set_VAL_TRAN( oasis_dec_t a_VAL_TRAN )
    {
        dbm_deccopy( &m_VAL_TRAN, &a_VAL_TRAN );
    }
    void TBSW0058::set_COD_RAM_ATVD( unsigned long a_COD_RAM_ATVD )
    {
        m_COD_RAM_ATVD = a_COD_RAM_ATVD;
    }
    void TBSW0058::set_NUM_CAR( const std::string& a_NUM_CAR )
    {
        m_NUM_CAR = a_NUM_CAR;
    }
    void TBSW0058::set_NUM_AUT( const std::string& a_NUM_AUT )
    {
        m_NUM_AUT = a_NUM_AUT;
    }
    void TBSW0058::set_VAL_COT_DLR( oasis_dec_t a_VAL_COT_DLR )
    {
        dbm_deccopy( &m_VAL_COT_DLR, &a_VAL_COT_DLR );
    }
    void TBSW0058::set_DAT_VLD_CAR( sw_date_t a_DAT_VLD_CAR )
    {
        m_DAT_VLD_CAR = a_DAT_VLD_CAR;
    }
    void TBSW0058::set_COD_TRK_CAR( const std::string& a_COD_TRK_CAR )
    {
        m_COD_TRK_CAR = a_COD_TRK_CAR;
    }
    void TBSW0058::set_COD_MOED( const std::string& a_COD_MOED )
    {
        m_COD_MOED = a_COD_MOED;
    }
    void TBSW0058::set_COD_PAIS_CAR( const std::string& a_COD_PAIS_CAR )
    {
        m_COD_PAIS_CAR = a_COD_PAIS_CAR;
    }
    void TBSW0058::set_COD_SERV_SNHA( const std::string& a_COD_SERV_SNHA )
    {
        m_COD_SERV_SNHA = a_COD_SERV_SNHA;
    }
    void TBSW0058::set_IND_RD_ORG( const std::string& a_IND_RD_ORG )
    {
        m_IND_RD_ORG = a_IND_RD_ORG;
    }
    void TBSW0058::set_COD_MOT_AUT( const std::string& a_COD_MOT_AUT )
    {
        m_COD_MOT_AUT = a_COD_MOT_AUT;
    }
    void TBSW0058::set_DAT_PAUZ( dbm_datetime_t a_DAT_PAUZ )
    {
        m_DAT_PAUZ = a_DAT_PAUZ;
    }
    void TBSW0058::set_COD_GRU_ESTB( unsigned long a_COD_GRU_ESTB )
    {
        m_COD_GRU_ESTB = a_COD_GRU_ESTB ;
    }
    void TBSW0058::set_COD_MTZ_ESTB( unsigned long a_COD_MTZ_ESTB )
    {
        m_COD_MTZ_ESTB = a_COD_MTZ_ESTB ;
    }
    void TBSW0058::set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN )
    {
        m_DTH_INI_TRAN = a_DTH_INI_TRAN;
    }
    void TBSW0058::set_DTH_STTU_TRAN( dbm_datetime_t a_DTH_STTU_TRAN )
    {
        m_DTH_STTU_TRAN = a_DTH_STTU_TRAN;
    }
    void TBSW0058::set_DTH_GMT( dbm_datetime_t a_DTH_GMT )
    {
        m_DTH_GMT = a_DTH_GMT;
    }
    void TBSW0058::set_NUM_STAN( unsigned long a_NUM_STAN )
    {
        m_NUM_STAN = a_NUM_STAN;
    }
    void TBSW0058::set_VAL_EFTV_CPTR( oasis_dec_t a_VAL_EFTV_CPTR )
    {
        dbm_deccopy( &m_VAL_EFTV_CPTR, &a_VAL_EFTV_CPTR );
        m_VAL_EFTV_CPTR_ind_null = 0;
    }
    void TBSW0058::set_QTD_PRCL_CNFR( unsigned long a_QTD_PRCL_CNFR )
    {
        m_QTD_PRCL_CNFR = a_QTD_PRCL_CNFR;
        m_QTD_PRCL_CNFR_ind_null = 0;
    }
    void TBSW0058::set_IND_RD_CPTR( const std::string& a_IND_RD_CPTR )
    {
        m_IND_RD_CPTR = a_IND_RD_CPTR;
        m_IND_RD_CPTR_ind_null = 0;
    }
    void TBSW0058::set_COD_CNDC_CPTR( const std::string& a_COD_CNDC_CPTR )
    {
        m_COD_CNDC_CPTR = a_COD_CNDC_CPTR;
    }
    void TBSW0058::set_DAT_CNFR_PAUZ( dbm_datetime_t a_DAT_CNFR_PAUZ )
    {
        m_DAT_CNFR_PAUZ = a_DAT_CNFR_PAUZ;
        m_DAT_CNFR_PAUZ_ind_null = 0;
    }
    void TBSW0058::set_VAL_TRAN_DLR( oasis_dec_t a_VAL_TRAN_DLR )
    {
        dbm_deccopy( &m_VAL_TRAN_DLR, &a_VAL_TRAN_DLR );
        m_VAL_TRAN_DLR_ind_null = 0;
    }
    void TBSW0058::set_DAT_CAN_PAUZ( dbm_datetime_t a_DAT_CAN_PAUZ )
    {
        m_DAT_CAN_PAUZ = a_DAT_CAN_PAUZ;
        m_DAT_CAN_PAUZ_ind_null = 0;
    }
    void TBSW0058::set_DAT_VLD_PAUZ( dbm_datetime_t a_DAT_VLD_PAUZ )
    {
        m_DAT_VLD_PAUZ = a_DAT_VLD_PAUZ;
    }
    void TBSW0058::set_NOM_PORT_CAR( const std::string& a_NOM_PORT_CAR )
    {
        m_NOM_PORT_CAR = a_NOM_PORT_CAR;
    }
    void TBSW0058::set_COD_MSG_ISO( unsigned long a_COD_MSG_ISO )
    {
        m_COD_MSG_ISO = a_COD_MSG_ISO;
    }
    void TBSW0058::set_COD_PCM_ISO( unsigned long a_COD_PCM_ISO )
    {
        m_COD_PCM_ISO = a_COD_PCM_ISO;
    }
    void TBSW0058::set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL )
    {
        m_NOM_SITE_ACQR_ORGL = a_NOM_SITE_ACQR_ORGL;
    }
    void TBSW0058::set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL )
    {
        m_NOM_HOST_ACQR_ORGL = a_NOM_HOST_ACQR_ORGL;
    }
    void TBSW0058::set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL )
    {
        m_NOM_FE_ACQR_ORGL = a_NOM_FE_ACQR_ORGL;
    }
    void TBSW0058::set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR )
    {
        m_NOM_SITE_ISSR = a_NOM_SITE_ISSR;
    }
    void TBSW0058::set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR )
    {
        m_NOM_HOST_ISSR = a_NOM_HOST_ISSR;
    }
    void TBSW0058::set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR )
    {
        m_NOM_FE_ISSR = a_NOM_FE_ISSR;
    }
    void TBSW0058::set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ )
    {
        m_NOM_SITE_ACQR_ATLZ = a_NOM_SITE_ACQR_ATLZ;
    }
    void TBSW0058::set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ )
    {
        m_NOM_HOST_ACQR_ATLZ = a_NOM_HOST_ACQR_ATLZ;
    }
    void TBSW0058::set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ )
    {
        m_NOM_FE_ACQR_ATLZ = a_NOM_FE_ACQR_ATLZ;
    }
    void TBSW0058::set_COD_MOT_ISO_EMSR( const std::string& a_COD_MOT_ISO_EMSR )
    {
        m_COD_MOT_ISO_EMSR = a_COD_MOT_ISO_EMSR;
    }
    void TBSW0058::set_COD_TERM_CNFR( const std::string& a_COD_TERM_CNFR )
    {
        m_COD_TERM_CNFR = a_COD_TERM_CNFR;
    }
    void TBSW0058::set_DAT_MOV_TRAN_CNFR( unsigned long a_DAT_MOV_TRAN_CNFR )
    {
        m_DAT_MOV_TRAN_CNFR = a_DAT_MOV_TRAN_CNFR;
        m_DAT_MOV_TRAN_CNFR_ind_null = 0;
    }
    void TBSW0058::set_DTH_CNFR( dbm_datetime_t a_DTH_CNFR )
    {
        m_DTH_CNFR = a_DTH_CNFR;
        m_DTH_CNFR_ind_null = 0;
    }
    void TBSW0058::set_IND_RD_ORG_ESTR( const std::string& a_IND_RD_ORG_ESTR )
    {
        m_IND_RD_ORG_ESTR = a_IND_RD_ORG_ESTR;
    }
    void TBSW0058::set_IND_STTU_TRAN( const std::string& a_IND_STTU_TRAN )
    {
        m_IND_STTU_TRAN = a_IND_STTU_TRAN;
    }
    void TBSW0058::set_NUM_EMSR( unsigned long a_NUM_EMSR )
    {
        m_NUM_EMSR = a_NUM_EMSR;
    }
    void TBSW0058::set_NUM_ESTB_CNFR( unsigned long a_NUM_ESTB_CNFR )
    {
        m_NUM_ESTB_CNFR = a_NUM_ESTB_CNFR;
        m_NUM_ESTB_CNFR_ind_null = 0;
    }
    void TBSW0058::set_NUM_ESTB_ESTR( unsigned long a_NUM_ESTB_ESTR )
    {
        m_NUM_ESTB_ESTR = a_NUM_ESTB_ESTR;
        // t689049@FIS - Data: 26/06/2014 - Ref BT 63.966
        m_NUM_ESTB_ESTR_ind_null = 0;
    }
    void TBSW0058::set_NUM_ID_CAR( oasis_dec_t a_NUM_ID_CAR )
    {
        dbm_deccopy( &m_NUM_ID_CAR, &a_NUM_ID_CAR );
        m_NUM_ID_CAR_ind_null = 0;
    }
    void TBSW0058::set_NUM_SEQ_UNC_CNFR( unsigned long a_NUM_SEQ_UNC_CNFR )
    {
        m_NUM_SEQ_UNC_CNFR = a_NUM_SEQ_UNC_CNFR ;
        m_NUM_SEQ_UNC_CNFR_ind_null = 0;
    }
    void TBSW0058::set_NUM_STAN_ORGL( unsigned long a_NUM_STAN_ORGL )
    {
        m_NUM_STAN_ORGL = a_NUM_STAN_ORGL ;
        m_NUM_STAN_ORGL_ind_null = 0;
    }
    void TBSW0058::set_COD_BNDR( unsigned long a_COD_BNDR )
    {
        m_COD_BNDR = a_COD_BNDR;
    }
    void TBSW0058::set_IND_EMSR_MTC( const std::string& a_IND_EMSR_MTC )
    {
        m_IND_EMSR_MTC = a_IND_EMSR_MTC;
    }

    void TBSW0058::set_NUM_AVSO_AUT( const std::string& a_NUM_AVSO_AUT)
    {
        m_NUM_AVSO_AUT = a_NUM_AVSO_AUT;
    }
    void TBSW0058::set_TXT_DA_ADIC_EMSR( const std::string& a_TXT_DA_ADIC_EMSR)
    {
        m_TXT_DA_ADIC_EMSR = a_TXT_DA_ADIC_EMSR;
    }
    void TBSW0058::set_NOM_FNTS_PDV( const std::string& a_NOM_FNTS_PDV)
    {
        m_NOM_FNTS_PDV = a_NOM_FNTS_PDV;
    }
    void TBSW0058::set_COD_PGM_AUT( const std::string& a_COD_PGM_AUT)
    {
        m_COD_PGM_AUT = a_COD_PGM_AUT;
    }
    void TBSW0058::set_IND_NVL_SGRA_KMRC( const std::string& a_IND_NVL_SGRA_KMRC)
    {
        m_IND_NVL_SGRA_KMRC = a_IND_NVL_SGRA_KMRC;
    }
    void TBSW0058::set_COD_UCAF( const std::string& a_COD_UCAF)
    {
        m_COD_UCAF = a_COD_UCAF;
    }
    void TBSW0058::set_COD_AUT_EMSR_CNVT( const std::string& a_COD_AUT_EMSR_CNVT)
    {
        m_COD_AUT_EMSR_CNVT = a_COD_AUT_EMSR_CNVT;
    }
    void TBSW0058::set_COD_AUT_EMSR( const std::string& a_COD_AUT_EMSR)
    {
        m_COD_AUT_EMSR = a_COD_AUT_EMSR;
    }
    void TBSW0058::set_NTWK_ID_ACQR_ATLZ( const std::string& a_NTWK_ID_ACQR_ATLZ)
    {
        m_NTWK_ID_ACQR_ATLZ = a_NTWK_ID_ACQR_ATLZ;
    }
    void TBSW0058::set_NTWK_ID_ACQR_ORGL( const std::string& a_NTWK_ID_ACQR_ORGL)
    {
        m_NTWK_ID_ACQR_ORGL = a_NTWK_ID_ACQR_ORGL;
    }
    void TBSW0058::set_NTWK_ID_ROUTE_ATLZ( const std::string& a_NTWK_ID_ROUTE_ATLZ)
    {
        m_NTWK_ID_ROUTE_ATLZ = a_NTWK_ID_ROUTE_ATLZ;
    }
    void TBSW0058::set_NTWK_ID_ROUTE_ORGL( const std::string& a_NTWK_ID_ROUTE_ORGL)
    {
        m_NTWK_ID_ROUTE_ORGL = a_NTWK_ID_ROUTE_ORGL;
    }
    void TBSW0058::set_NTWK_ID_ISSR_ATLZ( const std::string& a_NTWK_ID_ISSR_ATLZ)
    {
        m_NTWK_ID_ISSR_ATLZ = a_NTWK_ID_ISSR_ATLZ;
    }
    void TBSW0058::set_NTWK_ID_ISSR_ORGL( const std::string& a_NTWK_ID_ISSR_ORGL)
    {
        m_NTWK_ID_ISSR_ORGL = a_NTWK_ID_ISSR_ORGL;
    }
    // 12.11.2013 - Removido no GAP3
    //void TBSW0058::set_IND_CPTRDO( const std::string& a_IND_CPTRDO)
    //{
    //    m_IND_CPTRDO = a_IND_CPTRDO;
    //}
    //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
    void TBSW0058::set_COD_CTAH_VOCH( const std::string& a_COD_CTAH_VOCH )
    {
        m_COD_CTAH_VOCH = a_COD_CTAH_VOCH;
    }
    //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//

    //GAP13.1
    void TBSW0058::set_COD_TIP_PROD_CAR( const std::string& a_COD_TIP_PROD_CAR )
    {
        m_COD_TIP_PROD_CAR = a_COD_TIP_PROD_CAR;
    }
    void TBSW0058::set_NUM_PDV_EXT( const std::string& a_NUM_PDV_EXT )
    {
        m_NUM_PDV_EXT = a_NUM_PDV_EXT;
    }
    void TBSW0058::set_NUM_PDV_VAN( const std::string& a_NUM_PDV_VAN )
    {
        m_NUM_PDV_VAN = a_NUM_PDV_VAN;
    }
    void TBSW0058::set_COD_GRU_CLAS_RAM( long a_COD_GRU_CLAS_RAM )
    {
        m_COD_GRU_CLAS_RAM = a_COD_GRU_CLAS_RAM;
    }
    void TBSW0058::set_COD_CPCD_TERM( const std::string& a_COD_CPCD_TERM )
    {
        m_COD_CPCD_TERM = a_COD_CPCD_TERM;
    }
    void TBSW0058::set_NUM_REF_TRAN( const std::string& a_NUM_REF_TRAN )
    {
        m_NUM_REF_TRAN = a_NUM_REF_TRAN;
    }
    void TBSW0058::set_IND_TRAN_TKN( const std::string& a_IND_TRAN_TKN )
    {
        m_IND_TRAN_TKN = a_IND_TRAN_TKN;
    }
    void TBSW0058::SetCodOrgAprv( const std::string& codigoOrigemAprovacaoParametro )
    {
        codigoOrigemAprovacao = codigoOrigemAprovacaoParametro;
    }
    /// COD_PROD_MTC
    void TBSW0058::SetCodigoProdutoMastercard( const std::string& codigoProdutoMastercardParametro )
    {
        codigoProdutoMastercard = codigoProdutoMastercardParametro;
    }
    
    /// COD_RGAO_MTC
    void TBSW0058::SetCodigoRegiaoMastercard( const std::string& codigoRegiaoMastercardParametro )
    {
        codigoRegiaoMastercard = codigoRegiaoMastercardParametro;
    }



    // R10_2018 - Release Outubro - INICIO 
	/// SetPrintedCardSecurityCode
	/// Atribui novo valor ao campo COD_RET_VLDC_SGRA
	/// EF/ET : ET1
	/// Historico: [Data] - ET - Descricao
	/// 22/08/2018 - ET1 - Release Outubro 2018
	/// value: Valor a ser atribuido ao campo COD_RET_VLDC_SGRA
	void TBSW0058::SetPrintedCardSecurityCode(const std::string& value)
	{
		printedCardSecurityCode = value;
	}
    // R10_2018 - Release Outubro - FIM

    void TBSW0058::SetCodigoServicoCorporativo( unsigned long codServ )
    {
        codigoServicoCorporativo = codServ;
    }

    void TBSW0058::SetCodigoSituacaoOferta( unsigned long situacao )
    {
        codigoSituacaoOferta = situacao;
    }

    unsigned long TBSW0058::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    unsigned long TBSW0058::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }
    unsigned long TBSW0058::get_TIP_TRAN( ) const
    {
        return( m_TIP_TRAN );
    }
    unsigned long TBSW0058::get_NUM_MOT_RSPS( ) const
    {
        return( m_NUM_MOT_RSPS );
    }
    unsigned long TBSW0058::get_NUM_ESTB( ) const
    {
        return( m_NUM_ESTB );
    }
    const std::string& TBSW0058::get_COD_TERM( ) const
    {
        return( m_COD_TERM );
    }
    unsigned long TBSW0058::get_NUM_RD_ORG( ) const
    {
        return( m_NUM_RD_ORG );
    }
    const std::string& TBSW0058::get_COD_POS_ENTR_MODO( ) const
    {
        return( m_COD_POS_ENTR_MODO );
    }
    unsigned long TBSW0058::get_COD_EMSR( ) const
    {
        return( m_COD_EMSR );
    }
    oasis_dec_t TBSW0058::get_VAL_TRAN( ) const
    {
        return( m_VAL_TRAN );
    }
    unsigned long TBSW0058::get_COD_RAM_ATVD( ) const
    {
        return( m_COD_RAM_ATVD );
    }
    const std::string& TBSW0058::get_NUM_CAR( ) const
    {
        return( m_NUM_CAR );
    }
    const std::string& TBSW0058::get_NUM_AUT( ) const
    {
        return( m_NUM_AUT );
    }
    oasis_dec_t TBSW0058::get_VAL_COT_DLR( ) const
    {
        return( m_VAL_COT_DLR );
    }
    sw_date_t TBSW0058::get_DAT_VLD_CAR( ) const
    {
        return( m_DAT_VLD_CAR );
    }
    const std::string& TBSW0058::get_COD_TRK_CAR( ) const
    {
        return( m_COD_TRK_CAR );
    }
    const std::string& TBSW0058::get_COD_MOED( ) const
    {
        return( m_COD_MOED );
    }
    const std::string& TBSW0058::get_COD_PAIS_CAR( ) const
    {
        return( m_COD_PAIS_CAR );
    }
    const std::string& TBSW0058::get_COD_SERV_SNHA( ) const
    {
        return( m_COD_SERV_SNHA );
    }
    const std::string& TBSW0058::get_IND_RD_ORG( ) const
    {
        return( m_IND_RD_ORG );
    }
    const std::string& TBSW0058::get_COD_MOT_AUT( ) const
    {
        return( m_COD_MOT_AUT );
    }
    dbm_datetime_t TBSW0058::get_DAT_PAUZ( ) const
    {
        return( m_DAT_PAUZ );
    }
    unsigned long TBSW0058::get_COD_GRU_ESTB( ) const
    {
        return( m_COD_GRU_ESTB );
    }
    unsigned long TBSW0058::get_COD_MTZ_ESTB( ) const
    {
        return( m_COD_MTZ_ESTB );
    }
    dbm_datetime_t TBSW0058::get_DTH_INI_TRAN( ) const
    {
        return( m_DTH_INI_TRAN );
    }
    dbm_datetime_t TBSW0058::get_DTH_STTU_TRAN( ) const
    {
        return( m_DTH_STTU_TRAN );
    }
    dbm_datetime_t TBSW0058::get_DTH_GMT( ) const
    {
        return( m_DTH_GMT );
    }
    unsigned long TBSW0058::get_NUM_STAN( ) const
    {
        return( m_NUM_STAN );
    }
    oasis_dec_t TBSW0058::get_VAL_EFTV_CPTR( ) const
    {
        return( m_VAL_EFTV_CPTR );
    }
    unsigned long TBSW0058::get_QTD_PRCL_CNFR( ) const
    {
        return( m_QTD_PRCL_CNFR );
    }
    const std::string& TBSW0058::get_IND_RD_CPTR( ) const
    {
        return( m_IND_RD_CPTR );
    }
    const std::string& TBSW0058::get_COD_CNDC_CPTR( ) const
    {
        return( m_COD_CNDC_CPTR );
    }
    dbm_datetime_t TBSW0058::get_DAT_CNFR_PAUZ( ) const
    {
        return( m_DAT_CNFR_PAUZ );
    }
    oasis_dec_t TBSW0058::get_VAL_TRAN_DLR( ) const
    {
        return( m_VAL_TRAN_DLR );
    }
    dbm_datetime_t TBSW0058::get_DAT_CAN_PAUZ( ) const
    {
        return( m_DAT_CAN_PAUZ );
    }
    dbm_datetime_t TBSW0058::get_DAT_VLD_PAUZ( ) const
    {
        return( m_DAT_VLD_PAUZ );
    }
    const std::string& TBSW0058::get_NOM_PORT_CAR( ) const
    {
        return( m_NOM_PORT_CAR );
    }
    unsigned long TBSW0058::get_COD_MSG_ISO( ) const
    {
        return( m_COD_MSG_ISO );
    }
    unsigned long TBSW0058::get_COD_PCM_ISO( ) const
    {
        return( m_COD_PCM_ISO );
    }
    const std::string& TBSW0058::get_NOM_SITE_ACQR_ORGL( ) const
    {
        return( m_NOM_SITE_ACQR_ORGL );
    }
    const std::string& TBSW0058::get_NOM_HOST_ACQR_ORGL( ) const
    {
        return( m_NOM_HOST_ACQR_ORGL );
    }
    const std::string& TBSW0058::get_NOM_FE_ACQR_ORGL( ) const
    {
        return( m_NOM_FE_ACQR_ORGL );
    }
    const std::string& TBSW0058::get_NOM_SITE_ISSR( ) const
    {
        return( m_NOM_SITE_ISSR );
    }
    const std::string& TBSW0058::get_NOM_HOST_ISSR( ) const
    {
        return( m_NOM_HOST_ISSR );
    }
    const std::string& TBSW0058::get_NOM_FE_ISSR( ) const
    {
        return( m_NOM_FE_ISSR );
    }
    const std::string& TBSW0058::get_NOM_SITE_ACQR_ATLZ( ) const
    {
        return( m_NOM_SITE_ACQR_ATLZ );
    }
    const std::string& TBSW0058::get_NOM_HOST_ACQR_ATLZ( ) const
    {
        return( m_NOM_HOST_ACQR_ATLZ );
    }
    const std::string& TBSW0058::get_NOM_FE_ACQR_ATLZ( ) const
    {
        return( m_NOM_FE_ACQR_ATLZ );
    }
    const std::string& TBSW0058::get_COD_MOT_ISO_EMSR( ) const
    {
        return( m_COD_MOT_ISO_EMSR );
    }
    const std::string& TBSW0058::get_COD_TERM_CNFR( ) const
    {
        return( m_COD_TERM_CNFR );
    }
    unsigned long TBSW0058::get_DAT_MOV_TRAN_CNFR( ) const
    {
        return( m_DAT_MOV_TRAN_CNFR );
    }
    dbm_datetime_t TBSW0058::get_DTH_CNFR( ) const
    {
        return( m_DTH_CNFR );
    }
    const std::string& TBSW0058::get_IND_RD_ORG_ESTR( ) const
    {
        return( m_IND_RD_ORG_ESTR );
    }
    const std::string& TBSW0058::get_IND_STTU_TRAN( ) const
    {
        return( m_IND_STTU_TRAN );
    }
    unsigned long TBSW0058::get_NUM_EMSR( ) const
    {
        return( m_NUM_EMSR );
    }
    unsigned long TBSW0058::get_NUM_ESTB_CNFR( ) const
    {
        return( m_NUM_ESTB_CNFR );
    }
    unsigned long TBSW0058::get_NUM_ESTB_ESTR( ) const
    {
        return( m_NUM_ESTB_ESTR );
    }
    oasis_dec_t TBSW0058::get_NUM_ID_CAR() const
    {
        return ( m_NUM_ID_CAR );
    }
    unsigned long TBSW0058::get_NUM_SEQ_UNC_CNFR( ) const
    {
        return( m_NUM_SEQ_UNC_CNFR );
    }
    unsigned long TBSW0058::get_NUM_STAN_ORGL( ) const
    {
        return( m_NUM_STAN_ORGL );
    }
    unsigned long TBSW0058::get_COD_BNDR( ) const
    {
        return( m_COD_BNDR );
    }
    const std::string& TBSW0058::get_IND_EMSR_MTC( ) const
    {
        return( m_IND_EMSR_MTC );
    }

    const std::string& TBSW0058::get_NUM_AVSO_AUT( ) const
    {
        return( m_NUM_AVSO_AUT );
    }
    const std::string& TBSW0058::get_TXT_DA_ADIC_EMSR( ) const
    {
        return( m_TXT_DA_ADIC_EMSR );
    }
    const std::string& TBSW0058::get_NOM_FNTS_PDV( ) const
    {
        return( m_NOM_FNTS_PDV );
    }
    const std::string& TBSW0058::get_COD_PGM_AUT( ) const
    {
        return( m_COD_PGM_AUT );
    }
    const std::string& TBSW0058::get_IND_NVL_SGRA_KMRC( ) const
    {
        return( m_IND_NVL_SGRA_KMRC );
    }
    const std::string& TBSW0058::get_COD_UCAF( ) const
    {
        return( m_COD_UCAF );
    }
    const std::string& TBSW0058::get_COD_AUT_EMSR_CNVT( ) const
    {
        return( m_COD_AUT_EMSR_CNVT );
    }
    const std::string& TBSW0058::get_COD_AUT_EMSR( ) const
    {
        return( m_COD_AUT_EMSR );
    }
    const std::string& TBSW0058::get_NTWK_ID_ACQR_ATLZ( ) const
    {
        return( m_NTWK_ID_ACQR_ATLZ );
    }
    const std::string& TBSW0058::get_NTWK_ID_ACQR_ORGL( ) const
    {
        return( m_NTWK_ID_ACQR_ORGL );
    }
    const std::string& TBSW0058::get_NTWK_ID_ROUTE_ATLZ( ) const
    {
        return( m_NTWK_ID_ROUTE_ATLZ );
    }
    const std::string& TBSW0058::get_NTWK_ID_ROUTE_ORGL( ) const
    {
        return( m_NTWK_ID_ROUTE_ORGL );
    }
    const std::string& TBSW0058::get_NTWK_ID_ISSR_ATLZ( ) const
    {
        return( m_NTWK_ID_ISSR_ATLZ );
    }
    const std::string& TBSW0058::get_NTWK_ID_ISSR_ORGL( ) const
    {
        return( m_NTWK_ID_ISSR_ORGL );
    }
    // 12.11.2013 - Removido no GAP3
    //const std::string& TBSW0058::get_IND_CPTRDO( ) const
    //{
    //    return( m_IND_CPTRDO );
    //}
    //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
    const std::string& TBSW0058::get_COD_CTAH_VOCH( ) const
    {
        return( m_COD_CTAH_VOCH );
    }
    //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//

    // GAP 13.1
    const std::string& TBSW0058::get_COD_TIP_PROD_CAR( ) const
    {
        return( m_COD_TIP_PROD_CAR );
    }
    const std::string& TBSW0058::get_NUM_PDV_EXT( ) const
    {
        return( m_NUM_PDV_EXT );
    }
    const std::string& TBSW0058::get_NUM_PDV_VAN( ) const
    {
        return( m_NUM_PDV_VAN );
    }
	long TBSW0058::get_COD_GRU_CLAS_RAM( ) const
	{
		return m_COD_GRU_CLAS_RAM;
	}
    const std::string& TBSW0058::get_COD_CPCD_TERM() const
    {
        return m_COD_CPCD_TERM;
    }
    const std::string& TBSW0058::get_NUM_REF_TRAN() const
    {
        return m_NUM_REF_TRAN;
    }
    const std::string& TBSW0058::get_IND_TRAN_TKN() const
    {
        return m_IND_TRAN_TKN;
    }
    const std::string& TBSW0058::GetCodOrgAprv() const
    {
        return codigoOrigemAprovacao;
    }

    /// COD_PROD_MTC
    const std::string& TBSW0058::GetCodigoProdutoMastercard() const
    {
        return codigoProdutoMastercard;
    }

    /// COD_RGAO_MTC
    const std::string& TBSW0058::GetCodigoRegiaoMastercard() const
    {
        return codigoRegiaoMastercard;
    }


    // R10_2018 - Release Outubro - INICIO 
    /// GetPrintedCardSecurityCode
	/// Obtem valor do campo COD_RET_VLDC_SGRA
	/// EF/ET : ET1
	/// Historico: [Data] - ET - Descricao
	/// 22/08/2018 - ET1 - Release Outubro 2018
	const std::string& TBSW0058::GetPrintedCardSecurityCode() const
	{
		return printedCardSecurityCode;
	}
    // R10_2018 - Release Outubro - FIM

    // J4_2019 - Release Bandeiras Abril 2019 - INICIO
    /// SetIndicadorPresencaPortador
    /// Grava o indicador de presenca do portador
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 12/03/2019 - ET1 - Criacao da versao inicial
    /// indicadorPresencaPortadorParametro: valor a ser gravado
    void TBSW0058::SetIndicadorPresencaPortador( const std::string& indicadorPresencaPortadorParametro )
    {
        indicadorPresencaPortador = indicadorPresencaPortadorParametro;
    }

    /// SetIndicadorTecnologiaTerminal
    /// Grava o indicador de tecnologia do terminal
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 12/03/2019 - ET1 - Criacao da versao inicial
    /// indicadorTecnologiaTerminalParametro: valor a ser gravado
    void TBSW0058::SetIndicadorTecnologiaTerminal( const std::string& indicadorTecnologiaTerminalParametro )
    {
        indicadorTecnologiaTerminal = indicadorTecnologiaTerminalParametro;
    }

    /// GetIndicadorPresencaPortador
    /// Obtem o indicador de tecnologia do terminal
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 12/03/2019 - ET1 - Criacao da versao inicial
    const std::string& TBSW0058::GetIndicadorPresencaPortador( ) const
    {
        return indicadorPresencaPortador;
    }

    /// GetIndicadorTecnologiaTerminal
    /// Obtem o indicador de tecnologia do terminal
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 12/03/2019 - ET1 - Criacao da versao inicial
    const std::string& TBSW0058::GetIndicadorTecnologiaTerminal( ) const
    {
        return indicadorTecnologiaTerminal;
    }
    // J4_2019 - Release Bandeiras Abril 2019 - FIM

    // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
    void TBSW0058::SetCodigoProcessoEmissor( int codigoProcessoEmissorParam )
    {
        codigoProcessoEmissor = codigoProcessoEmissorParam;
    }
    int TBSW0058::GetCodigoProcessoEmissor( ) const
    {
        return codigoProcessoEmissor;
    }
    // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM

    //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - INICIO
    void TBSW0058::SetIdentificadorReferenciaBandeira( const std::string& idRefBandeira )
    {
        identificadorReferenciaBandeira = idRefBandeira;
    }
    const std::string& TBSW0058::GetIdentificadorReferenciaBandeira( ) const
    {
        return identificadorReferenciaBandeira;
    }
    //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - FIM

    unsigned long TBSW0058::GetCodigoServicoCorporativo( )
    {
        return codigoServicoCorporativo;
    }

    unsigned long TBSW0058::GetCodigoSituacaoOferta( )
    {
        return codigoSituacaoOferta;
    }

    //cr689721@FIS - Data: 04/03/2015 - Ref. Mostrar o conteudo
    void TBSW0058::showxxx( const char *name, unsigned long campo )
    {
        char buf[1000] = {0};
        sprintf(buf, " - %s : [%ld]", name, campo );
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0058::showxxx( const char *name, int campo )
    {
        char buf[1000] = {0};
        sprintf(buf, " - %s : [%d]", name, campo );
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0058::showxxx( const char *name, dbm_datetime_t campo )
    {
        char buf[1000] = {0};
        sprintf(buf, " - %s : [%ld]", name, campo );
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0058::showxxx( const char *name, const std::string& campo )
    {
        char buf[1000] = {0};
		if( campo.size() > 0 )
		{
			sprintf(buf, " - %s : [%s]", name, campo.c_str() );
			m_log->write( logger::LEVEL_DEBUG, buf );
		}
    }
    void TBSW0058::showxxx( const char *name, oasis_dec_t campo )
    {
        char buf[1000] = {0};
        char buf_aux[1000] = {0};
        dbm_dectochar( &campo, buf_aux);
        sprintf(buf, " - %s : [%s]", name, buf_aux );
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0058::show(int nvl)
    {
        char buf[1000];
        sprintf( buf, " <##[%s]##>", table_name.c_str() );
        m_log->write( logger::LEVEL_DEBUG, buf );
        showxxx( "m_DAT_MOV_TRAN", 			m_DAT_MOV_TRAN ); 
        showxxx( "m_NUM_SEQ_UNC",  			m_NUM_SEQ_UNC ); 
        showxxx( "m_TIP_TRAN", 				m_TIP_TRAN );
        showxxx( "m_NUM_MOT_RSPS", 			m_NUM_MOT_RSPS );
        showxxx( "m_NUM_ESTB", 				m_NUM_ESTB );
        showxxx( "m_COD_TERM", 				m_COD_TERM );
        showxxx( "m_NUM_RD_ORG", 			m_NUM_RD_ORG );
        showxxx( "m_COD_POS_ENTR_MODO", 	m_COD_POS_ENTR_MODO );
        showxxx( "m_COD_EMSR", 				m_COD_EMSR );
        showxxx( "m_VAL_TRAN", 				m_VAL_TRAN );
        showxxx( "m_COD_RAM_ATVD", 			m_COD_RAM_ATVD );
        showxxx( "m_NUM_CAR", 				m_NUM_CAR );
        showxxx( "m_NUM_AUT", 				m_NUM_AUT );
        showxxx( "m_VAL_COT_DLR", 			m_VAL_COT_DLR );
        //showxxx( "m_DAT_VLD_CAR", 			m_DAT_VLD_CAR ); //*
        showxxx( "m_COD_TRK_CAR", 			m_COD_TRK_CAR );
        showxxx( "m_COD_MOED", 				m_COD_MOED );
        showxxx( "m_COD_PAIS_CAR", 			m_COD_PAIS_CAR );
        showxxx( "m_COD_SERV_SNHA", 		m_COD_SERV_SNHA );
        showxxx( "m_IND_RD_ORG", 			m_IND_RD_ORG );
        showxxx( "m_COD_MOT_AUT", 			m_COD_MOT_AUT );
        showxxx( "m_DAT_PAUZ", 				m_DAT_PAUZ );
        showxxx( "m_COD_GRU_ESTB", 			m_COD_GRU_ESTB );
        showxxx( "m_COD_MTZ_ESTB", 			m_COD_MTZ_ESTB );
        showxxx( "m_DTH_INI_TRAN",			m_DTH_INI_TRAN );
        showxxx( "m_DTH_STTU_TRAN", 		m_DTH_STTU_TRAN );
        showxxx( "m_DTH_GMT", 				m_DTH_GMT );
        showxxx( "m_NUM_STAN", 				m_NUM_STAN );
        showxxx( "m_VAL_EFTV_CPTR", 		m_VAL_EFTV_CPTR );
        showxxx( "m_QTD_PRCL_CNFR", 		m_QTD_PRCL_CNFR );
        showxxx( "m_IND_RD_CPTR", 			m_IND_RD_CPTR );
        showxxx( "m_COD_CNDC_CPTR", 		m_COD_CNDC_CPTR );
        showxxx( "m_DAT_CNFR_PAUZ", 		m_DAT_CNFR_PAUZ );
        showxxx( "m_VAL_TRAN_DLR", 			m_VAL_TRAN_DLR );
        showxxx( "m_DAT_CAN_PAUZ", 			m_DAT_CAN_PAUZ );
        showxxx( "m_DAT_VLD_PAUZ", 			m_DAT_VLD_PAUZ );
        showxxx( "m_NOM_PORT_CAR", 			m_NOM_PORT_CAR );
        showxxx( "m_COD_MSG_ISO", 			m_COD_MSG_ISO );
        showxxx( "m_COD_PCM_ISO", 			m_COD_PCM_ISO );
        showxxx( "m_NOM_SITE_ACQR_ORGL", 	m_NOM_SITE_ACQR_ORGL );
        showxxx( "m_NOM_HOST_ACQR_ORGL", 	m_NOM_HOST_ACQR_ORGL );
        showxxx( "m_NOM_FE_ACQR_ORGL", 		m_NOM_FE_ACQR_ORGL );
        showxxx( "m_NOM_SITE_ISSR", 		m_NOM_SITE_ISSR );
        showxxx( "m_NOM_HOST_ISSR", 		m_NOM_HOST_ISSR );
        showxxx( "m_NOM_FE_ISSR", 			m_NOM_FE_ISSR );
        showxxx( "m_NOM_SITE_ACQR_ATLZ", 	m_NOM_SITE_ACQR_ATLZ );
        showxxx( "m_NOM_HOST_ACQR_ATLZ", 	m_NOM_HOST_ACQR_ATLZ );
        showxxx( "m_NOM_FE_ACQR_ATLZ", 		m_NOM_FE_ACQR_ATLZ );
        showxxx( "m_COD_MOT_ISO_EMSR", 		m_COD_MOT_ISO_EMSR );
        showxxx( "m_COD_TERM_CNFR", 		m_COD_TERM_CNFR );
        showxxx( "m_DAT_MOV_TRAN_CNFR", 	m_DAT_MOV_TRAN_CNFR );
        showxxx( "m_DTH_CNFR", 				m_DTH_CNFR );
        showxxx( "m_IND_RD_ORG_ESTR", 		m_IND_RD_ORG_ESTR );
        showxxx( "m_IND_STTU_TRAN", 		m_IND_STTU_TRAN );
        showxxx( "m_NUM_EMSR", 				m_NUM_EMSR );
        showxxx( "m_NUM_ESTB_CNFR", 		m_NUM_ESTB_CNFR );
        showxxx( "m_NUM_ESTB_ESTR", 		m_NUM_ESTB_ESTR );
        showxxx( "m_NUM_ID_CAR", 			m_NUM_ID_CAR );
        showxxx( "m_NUM_SEQ_UNC_CNFR", 		m_NUM_SEQ_UNC_CNFR );
        showxxx( "m_NUM_STAN_ORGL", 		m_NUM_STAN_ORGL );
        showxxx( "m_COD_BNDR", 				m_COD_BNDR );
        showxxx( "m_IND_EMSR_MTC", 			m_IND_EMSR_MTC );
        showxxx( "m_NUM_AVSO_AUT", 			m_NUM_AVSO_AUT );
        showxxx( "m_TXT_DA_ADIC_EMSR", 		m_TXT_DA_ADIC_EMSR );
        showxxx( "m_NOM_FNTS_PDV", 			m_NOM_FNTS_PDV );
        showxxx( "m_COD_PGM_AUT", 			m_COD_PGM_AUT );
        showxxx( "m_IND_NVL_SGRA_KMRC", 	m_IND_NVL_SGRA_KMRC );
        showxxx( "m_COD_UCAF", 				m_COD_UCAF );
        showxxx( "m_COD_AUT_EMSR_CNVT", 	m_COD_AUT_EMSR_CNVT );
        showxxx( "m_COD_AUT_EMSR", 			m_COD_AUT_EMSR );
        showxxx( "m_NTWK_ID_ACQR_ATLZ", 	m_NTWK_ID_ACQR_ATLZ );
        showxxx( "m_NTWK_ID_ACQR_ORGL", 	m_NTWK_ID_ACQR_ORGL );
        showxxx( "m_NTWK_ID_ROUTE_ATLZ", 	m_NTWK_ID_ROUTE_ATLZ );
        showxxx( "m_NTWK_ID_ROUTE_ORGL", 	m_NTWK_ID_ROUTE_ORGL );
        showxxx( "m_NTWK_ID_ISSR_ATLZ", 	m_NTWK_ID_ISSR_ATLZ );
        showxxx( "m_NTWK_ID_ISSR_ORGL", 	m_NTWK_ID_ISSR_ORGL );
        showxxx( "m_COD_CTAH_VOCH", 		m_COD_CTAH_VOCH );
        showxxx( "m_COD_TIP_PROD_CAR", 		m_COD_TIP_PROD_CAR );
        showxxx( "m_NUM_PDV_EXT", 		    m_NUM_PDV_EXT );
        showxxx( "m_NUM_PDV_VAN", 		    m_NUM_PDV_VAN );
        showxxx( "m_COD_CPCD_TERM", 		m_COD_CPCD_TERM );
        showxxx( "m_NUM_REF_TRAN", 		    m_NUM_REF_TRAN );
        showxxx( "m_IND_TRAN_TKN", 		    m_IND_TRAN_TKN );
        showxxx( "m_COD_ORG_APRV", 		    codigoOrigemAprovacao );
        showxxx( "m_COD_PROD_MTC",          codigoProdutoMastercard ); /// COD_PROD_MTC
        showxxx( "m_COD_RGAO_MTC",          codigoRegiaoMastercard );  /// COD_RGAO_MTC
        // R10_2018 - Release Outubro - INICIO 
        showxxx( "COD_RET_VLDC_SGRA", 	    printedCardSecurityCode );
        // R10_2018 - Release Outubro - FIM
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        showxxx( "COD_PORT_PRES_VLDC_BNDR",  indicadorPresencaPortador );
        showxxx( "COD_CPCD_TERM_VLDC_BNDR",  indicadorTecnologiaTerminal );
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
        showxxx( "COD_PCM_EMS", codigoProcessoEmissor );
        // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM
        showxxx( "ID_REF_BNDR", identificadorReferenciaBandeira );

        showxxx( "COD_SERV_CORP", codigoServicoCorporativo );
        showxxx( "COD_SIT_OFRT", codigoSituacaoOferta );

        sprintf( buf, " </##[%s]##>", table_name.c_str() );
        
        m_log->write( logger::LEVEL_DEBUG, buf );

    }

} //namespace dbaccess_common


