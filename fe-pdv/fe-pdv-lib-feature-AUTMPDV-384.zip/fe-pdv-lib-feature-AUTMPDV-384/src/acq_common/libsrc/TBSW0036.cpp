/* Copyright 2021 Rede S.A.
Autor  : Igor
Empresa: Rede
*/

#include "TBSW0036.hpp"

namespace dbaccess_common
{

    TBSW0036::TBSW0036()
    {
        initialize();

        where_condition = "";

        // Teste de conteudo do registro
        log = logger::DebugWriter::getInstance();
	update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0036::TBSW0036(const std::string& where)
    {
        initialize();

        where_condition = where;

        // Teste de conteudo do registro
        log = logger::DebugWriter::getInstance();
	update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0036::~TBSW0036() {
    }

    void TBSW0036::initialize()
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, VLR_MOED_ESTN, COD_MOED_ESTN, PCT_TX_MKP, VAL_TX_CONV_MOED, DAT_MOV_TRAN_CLTA, NUM_SEQ_UNC_CLTA";

        table_name = "TBSW0036";

        dataMovimentoTransacaoPosicao = 1;
        numeroSequencialUnicoPosicao = 2;
        valorMoedaEstrangeiraPosicao = 3;
        codigoMoedaEstrangeiraPosicao = 4;
        percentualTaxaMarkupPosicao = 5;
        valorTaxaConversaoMoedaPosicao = 6;
        dataMovimentoTransacaoConsultaPosicao = 7;
        numeroSequencialUnicoConsultaPosicao = 8;

        dataMovimentoTransacao = 0;
        numeroSequencialUnico = 0;
        dbm_chartodec( &valorMoedaEstrangeira, "0.00", 2 );
        codigoMoedaEstrangeira = "";
        percentualTaxaMarkup = 0;
        valorTaxaConversaoMoeda = 0;
        dataMovimentoTransacaoConsulta = 0;
        numeroSequencialUnicoConsulta = 0;
        
        valorMoedaEstrangeiraIndNull = DBM_NULL_DATA;
        codigoMoedaEstrangeiraIndNull = DBM_NULL_DATA;
        percentualTaxaMarkupIndNull = DBM_NULL_DATA;
        valorTaxaConversaoMoedaIndNull = DBM_NULL_DATA;
        dataMovimentoTransacaoConsultaIndNull = DBM_NULL_DATA;
        numeroSequencialUnicoConsultaIndNull = DBM_NULL_DATA;
    }

    void TBSW0036::bind_columns( )
    {
        bind( dataMovimentoTransacaoPosicao, dataMovimentoTransacao );
        bind( numeroSequencialUnicoPosicao, numeroSequencialUnico );
        bind( valorMoedaEstrangeiraPosicao, valorMoedaEstrangeira, &valorMoedaEstrangeiraIndNull );
        bind( codigoMoedaEstrangeiraPosicao, codigoMoedaEstrangeira );
        bind( percentualTaxaMarkupPosicao, percentualTaxaMarkup, &percentualTaxaMarkupIndNull );
        bind( valorTaxaConversaoMoedaPosicao, valorTaxaConversaoMoeda ,&valorTaxaConversaoMoedaIndNull );
        bind( dataMovimentoTransacaoConsultaPosicao, dataMovimentoTransacaoConsulta, &dataMovimentoTransacaoConsultaIndNull );
        bind( numeroSequencialUnicoConsultaPosicao, numeroSequencialUnicoConsulta, &numeroSequencialUnicoConsultaIndNull );
    }
    
    void TBSW0036::let_as_is( )
    {
        valorMoedaEstrangeiraIndNull = is_null(valorMoedaEstrangeira) ? DBM_NULL_DATA : 0;
        codigoMoedaEstrangeiraIndNull = is_null(codigoMoedaEstrangeira) ? DBM_NULL_DATA : 0;
        percentualTaxaMarkupIndNull = is_null(&percentualTaxaMarkup) ? DBM_NULL_DATA : 0;
        valorTaxaConversaoMoedaIndNull = is_null(valorTaxaConversaoMoeda) ? DBM_NULL_DATA : 0;
        dataMovimentoTransacaoConsultaIndNull = is_null(dataMovimentoTransacaoConsulta) ? DBM_NULL_DATA : 0;
        numeroSequencialUnicoConsultaIndNull = is_null(numeroSequencialUnicoConsulta) ? DBM_NULL_DATA : 0;
    }
    
    void TBSW0036::setWhereClause( const std::string& whereClause )
    {
        where_condition = whereClause;
    }
    
    void TBSW0036::SetDataMovimentoTransacao( unsigned long value )
    {
        dataMovimentoTransacao = value;
    }
    void TBSW0036::SetNumeroSequencialUnico( unsigned long value )
    {
        numeroSequencialUnico = value;
    }
    void TBSW0036::SetValorMoedaEstrangeira( oasis_dec_t value )
    {
        dbm_deccopy( &valorMoedaEstrangeira, &value );
        valorMoedaEstrangeiraIndNull = 0;
    }
    void TBSW0036::SetCodigoMoedaEstrangeira( const std::string& value )
    {
        codigoMoedaEstrangeira = value;
        codigoMoedaEstrangeiraIndNull = 0;
    }
    void TBSW0036::SetPercentualTaxaMarkup( long value )
    {
        percentualTaxaMarkup = value;
        percentualTaxaMarkupIndNull = 0;
    }
    void TBSW0036::SetValorTaxaConversaoMoeda( unsigned long value )
    {
        valorTaxaConversaoMoeda = value;
        valorTaxaConversaoMoedaIndNull = 0;
    }
    void TBSW0036::SetDataMovimentoTransacaoConsulta( unsigned long value )
    {
        dataMovimentoTransacaoConsulta = value;
        dataMovimentoTransacaoConsultaIndNull = 0;
    }
    void TBSW0036::SetNumeroSequencialUnicoConsulta( unsigned long value )
    {
        numeroSequencialUnicoConsulta = value;
        numeroSequencialUnicoConsultaIndNull = 0;
    }

    unsigned long TBSW0036::GetDataMovimentoTransacao() const
    {
        return dataMovimentoTransacao;
    }
    unsigned long TBSW0036::GetNumeroSequencialUnico( ) const
    {
        return numeroSequencialUnico;
    }
    oasis_dec_t TBSW0036::GetValorMoedaEstrangeira() const
    {
        return valorMoedaEstrangeira;
    }
    const std::string& TBSW0036::GetCodigoMoedaEstrangeira() const
    {
        return codigoMoedaEstrangeira;
    }
    long TBSW0036::GetPercentualTaxaMarkup() const
    {
        return percentualTaxaMarkup;
    }
    unsigned long TBSW0036::GetValorTaxaConversaoMoeda() const
    {
        return valorTaxaConversaoMoeda;
    }
    unsigned long TBSW0036::GetDataMovimentoTransacaoConsulta() const
    {
        return dataMovimentoTransacaoConsulta;
    }
    unsigned long TBSW0036::GetNumeroSequencialUnicoConsulta() const
    {
        return numeroSequencialUnicoConsulta;
    }

    // Teste de conteudo do registro
    void TBSW0036::showxxx( const char *name, unsigned long campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%lu]", name, campo );
        }
        log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0036::showxxx( const char *name, long campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%ld]", name, campo );
        }
        log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0036::showxxx( const char *name, const std::string& campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%s]", name, campo.c_str( ) );
        }
        log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0036::showxxx( const char *name, oasis_dec_t campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            char buf_aux[1000] = {0};
            dbm_dectochar( &campo, buf_aux);
            sprintf(buf, " - %s : [%s]", name, buf_aux );
        }
        log->write( logger::LEVEL_DEBUG, buf );
    }
   
    void TBSW0036::show(int nvl)
    {
        char buf[1000];
        sprintf( buf, " --[%s]----------------------------", table_name.c_str() );
        log->write( logger::LEVEL_DEBUG, buf );

        //NOT NULL CAMPOS
        showxxx( "DAT_MOV_TRAN",  dataMovimentoTransacao, false);
        showxxx( "NUM_SEQ_UNC",  numeroSequencialUnico, false);
        showxxx( "VLR_MOED_ESTN",  valorMoedaEstrangeira, valorMoedaEstrangeiraIndNull == DBM_NULL_DATA );
        showxxx( "COD_MOED_ESTN",  codigoMoedaEstrangeira, codigoMoedaEstrangeira.empty() );
        showxxx( "PCT_TX_MKP",  percentualTaxaMarkup, percentualTaxaMarkupIndNull == DBM_NULL_DATA );
        showxxx( "VAL_TX_CONV_MOED",  valorTaxaConversaoMoeda, valorTaxaConversaoMoedaIndNull == DBM_NULL_DATA );
        showxxx( "DAT_MOV_TRAN_CLTA",  dataMovimentoTransacaoConsulta, dataMovimentoTransacaoConsultaIndNull == DBM_NULL_DATA );
        showxxx( "NUM_SEQ_UNC_CLTA",  numeroSequencialUnicoConsulta, numeroSequencialUnicoConsultaIndNull == DBM_NULL_DATA );
        sprintf( buf, " ------------------------------------------", table_name.c_str() );
        log->write( logger::LEVEL_DEBUG, buf );

    }

} //namespace dbaccess_common
