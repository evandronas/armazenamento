#include "TBSW0052.hpp"

namespace dbaccess_common
{
    TBSW0052::TBSW0052( )
    {
		// t694446@FIS_BEGIN - Data: 30/09/2013 - Renomeando os campos NTWK_ID
        //query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, DTH_GMT, DTH_INI_TRAN, COD_MSG_ISO, COD_PCM_ISO, TIP_TRAN, IND_RD_ORG, NUM_ESTB, COD_DDD_ESTB, NUM_TEL_ESTB, COD_TERM, NUM_TRAN_RD, COD_RAM_ATVD, COD_POS_ENTR_MODO, COD_BNDR, COD_EMSR, NUM_ID_CAR, NUM_CAR, COD_PAIS_CAR, IND_VLDC_CVC, COD_OPER_TRAN, COD_MOED, VAL_TRAN, VAL_TRAN_DLR, VAL_COT_DLR, QTD_PRCL, VAL_PRCL, NUM_AUT, COD_MOT_AUT, NUM_MOT_RSPS, COD_MOT_SW, COD_MOT_ISO_EMSR, TXT_MSG_RSPS, IND_STTU_TRAN, DTH_STTU_TRAN, COD_CNDC_CNFR, DTH_CPTR, COD_OPER_ESTR, COD_TERM_ESTR, TIP_PES, VAL_TX, DTH_DFZM_TRAN, DTH_ESTR_TRAN, NOM_SITE_ACQR_ORGL, NOM_HOST_ACQR_ORGL, NOM_FE_ACQR_ORGL, NOM_SITE_ISSR, NOM_HOST_ISSR, NOM_FE_ISSR, NOM_SITE_ACQR_ATLZ, NOM_HOST_ACQR_ATLZ, NOM_FE_ACQR_ATLZ, NUM_AVSO_AUT, COD_AUT_ICH, DTH_TRAN_OFLN, DTH_TRAN_EMSR, NTWK_ID_ACQR_ATLZ , NTWK_ID_ACQR_ORGL, NTWK_ID_ROUTE_ATLZ, NTWK_ID_ROUTE_ORGL, NTWK_ID_ISSR_ATLZ, NTWK_ID_ISSR_ORGL";
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, DTH_GMT, DTH_INI_TRAN, COD_MSG_ISO, COD_PCM_ISO, TIP_TRAN, IND_RD_ORG, NUM_ESTB, COD_DDD_ESTB, NUM_TEL_ESTB, COD_TERM, NUM_TRAN_RD, COD_RAM_ATVD, COD_POS_ENTR_MODO, COD_BNDR, COD_EMSR, NUM_ID_CAR, NUM_CAR, COD_PAIS_CAR, IND_VLDC_CVC, COD_OPER_TRAN, COD_MOED, VAL_TRAN, VAL_TRAN_DLR, VAL_COT_DLR, QTD_PRCL, VAL_PRCL, NUM_AUT, COD_MOT_AUT, NUM_MOT_RSPS, COD_MOT_SW, COD_MOT_ISO_EMSR, TXT_MSG_RSPS, IND_STTU_TRAN, DTH_STTU_TRAN, COD_CNDC_CNFR, DTH_CPTR, COD_OPER_ESTR, COD_TERM_ESTR, TIP_PES, VAL_TX, DTH_DFZM_TRAN, DTH_ESTR_TRAN, NOM_SITE_ACQR_ORGL, NOM_HOST_ACQR_ORGL, NOM_FE_ACQR_ORGL, NOM_SITE_ISSR, NOM_HOST_ISSR, NOM_FE_ISSR, NOM_SITE_ACQR_ATLZ, NOM_HOST_ACQR_ATLZ, NOM_FE_ACQR_ATLZ, NUM_AVSO_AUT, COD_AUT_ICH, DTH_TRAN_OFLN, DTH_TRAN_EMSR, COD_NTWK_ID_ACQR_ATLZ , COD_NTWK_ID_ACQR_ORGL, COD_NTWK_ID_ROUT_ATLZ, COD_NTWK_ID_ROUT_ORGL, COD_NTWK_ID_ISSR_ATLZ, COD_NTWK_ID_ISSR_ORGL";
		// t694446@FIS_END - Data: 30/09/2013
        
        table_name = "TBSW0052";
        
        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_DTH_GMT_pos = 3;
        m_DTH_INI_TRAN_pos = 4;
        m_COD_MSG_ISO_pos = 5;
        m_COD_PCM_ISO_pos = 6;
        m_TIP_TRAN_pos = 7;
        m_IND_RD_ORG_pos = 8;
        m_NUM_ESTB_pos = 9;
        m_COD_DDD_ESTB_pos = 10;
        m_NUM_TEL_ESTB_pos = 11;
        m_COD_TERM_pos = 12;
        m_NUM_TRAN_RD_pos = 13;
        m_COD_RAM_ATVD_pos = 14;
        m_COD_POS_ENTR_MODO_pos = 15;
        m_COD_BNDR_pos = 16;
        m_COD_EMSR_pos = 17;
        m_NUM_ID_CAR_pos = 18;
        m_NUM_CAR_pos = 19;
        m_COD_PAIS_CAR_pos = 20;
        m_IND_VLDC_CVC_pos = 21;
        m_COD_OPER_TRAN_pos = 22;
        m_COD_MOED_pos = 23;
        m_VAL_TRAN_pos = 24;
        m_VAL_TRAN_DLR_pos = 25;
        m_VAL_COT_DLR_pos = 26;
        m_QTD_PRCL_pos = 27;
        m_VAL_PRCL_pos = 28;
        m_NUM_AUT_pos = 29;
        m_COD_MOT_AUT_pos = 30;
        m_NUM_MOT_RSPS_pos = 31;
        m_COD_MOT_SW_pos = 32;
        m_COD_MOT_ISO_EMSR_pos = 33;
        m_TXT_MSG_RSPS_pos = 34;
        m_IND_STTU_TRAN_pos = 35;
        m_DTH_STTU_TRAN_pos = 36;
        m_COD_CNDC_CNFR_pos = 37;
        m_DTH_CPTR_pos = 38;
        m_COD_OPER_ESTR_pos = 39;
        m_COD_TERM_ESTR_pos = 40;
        m_TIP_PES_pos = 41;
        m_VAL_TX_pos = 42;
        m_DTH_DFZM_TRAN_pos = 43;
        m_DTH_ESTR_TRAN_pos = 44;
        m_NOM_SITE_ACQR_ORGL_pos = 45;
        m_NOM_HOST_ACQR_ORGL_pos = 46;
        m_NOM_FE_ACQR_ORGL_pos = 47;
        m_NOM_SITE_ISSR_pos = 48;
        m_NOM_HOST_ISSR_pos = 49;
        m_NOM_FE_ISSR_pos = 50;
        m_NOM_SITE_ACQR_ATLZ_pos = 51;
        m_NOM_HOST_ACQR_ATLZ_pos = 52;
        m_NOM_FE_ACQR_ATLZ_pos = 53;
        m_NUM_AVSO_AUT_pos = 54;
        m_COD_AUT_ICH_pos = 55;
        m_DTH_TRAN_OFLN_pos = 56;
        m_DTH_TRAN_EMSR_pos = 57;
        
        m_NTWK_ID_ACQR_ATLZ_pos=58;
        m_NTWK_ID_ACQR_ORGL_pos=59;
        m_NTWK_ID_ROUTE_ATLZ_pos=60;
        m_NTWK_ID_ROUTE_ORGL_pos=61;
        m_NTWK_ID_ISSR_ATLZ_pos=62;
        m_NTWK_ID_ISSR_ORGL_pos=63;        
        
        
        m_DAT_MOV_TRAN = 0;
        m_NUM_SEQ_UNC = 0;
        m_DTH_GMT = 0;
        m_DTH_INI_TRAN = 0;
        m_COD_MSG_ISO = 0;
        m_COD_PCM_ISO = 0;
        m_TIP_TRAN = 0;
        m_IND_RD_ORG = "";
        m_NUM_ESTB = 0;
        m_COD_DDD_ESTB = " ";
        dbm_longtodec( &m_NUM_TEL_ESTB, 0 );
        m_COD_TERM = " ";
        dbm_longtodec( &m_NUM_TRAN_RD, 0 );
        m_COD_RAM_ATVD = 0;
        m_COD_POS_ENTR_MODO = " ";
        m_COD_BNDR = 0;
        m_COD_EMSR = 0;
        m_NUM_ID_CAR = 0;
        m_NUM_CAR = " ";
        m_COD_PAIS_CAR = " ";
        m_IND_VLDC_CVC = " ";
        m_COD_OPER_TRAN = "";
        m_COD_MOED = " ";
        dbm_chartodec( &m_VAL_TRAN, "0.00", 2 );
        dbm_chartodec( &m_VAL_TRAN_DLR, "0.00", 2 );
        dbm_chartodec( &m_VAL_COT_DLR, "0.0000", 4 );
        m_QTD_PRCL = 0;
        dbm_chartodec( &m_VAL_PRCL, "0.00", 2 );
        m_NUM_AUT = "";
        m_COD_MOT_AUT = "";
        m_NUM_MOT_RSPS = 0;
        m_COD_MOT_SW = "";
        m_COD_MOT_ISO_EMSR = "";
        m_TXT_MSG_RSPS = "";
        m_IND_STTU_TRAN = " ";
        m_DTH_STTU_TRAN = 0;
        m_COD_CNDC_CNFR = "";
        m_DTH_CPTR = 0;
        m_COD_OPER_ESTR = "";
        m_COD_TERM_ESTR = " ";
        m_TIP_PES = " ";
        dbm_chartodec( &m_VAL_TX, "0.00", 2 );
        m_DTH_DFZM_TRAN = 0;
        m_DTH_ESTR_TRAN = 0;
        m_NOM_SITE_ACQR_ORGL = " ";
        m_NOM_HOST_ACQR_ORGL = " ";
        m_NOM_FE_ACQR_ORGL = " ";
        m_NOM_SITE_ISSR = "";
        m_NOM_HOST_ISSR = "";
        m_NOM_FE_ISSR = "";
        m_NOM_SITE_ACQR_ATLZ = "";
        m_NOM_HOST_ACQR_ATLZ = "";
        m_NOM_FE_ACQR_ATLZ = "";
        m_NUM_AVSO_AUT = "";
        m_COD_AUT_ICH = "";
        m_DTH_TRAN_OFLN = 0;
        m_DTH_TRAN_EMSR = 0;
        
        m_NTWK_ID_ACQR_ATLZ = "";
        m_NTWK_ID_ACQR_ORGL = "";
        m_NTWK_ID_ROUTE_ATLZ = "";
        m_NTWK_ID_ROUTE_ORGL = "";
        m_NTWK_ID_ISSR_ATLZ = "";
        m_NTWK_ID_ISSR_ORGL = "";            
        
        
        
        m_DTH_DFZM_TRAN_ind_null = DBM_NULL_DATA;
        m_DTH_ESTR_TRAN_ind_null = DBM_NULL_DATA;
        m_DTH_TRAN_EMSR_ind_null = DBM_NULL_DATA;
        m_DTH_CPTR_ind_null = DBM_NULL_DATA;
        m_DTH_TRAN_OFLN_ind_null = DBM_NULL_DATA;
        m_NUM_ID_CAR_ind_null = DBM_NULL_DATA;
        m_NUM_MOT_RSPS_ind_null = DBM_NULL_DATA;
        m_VAL_TRAN_ind_null = DBM_NULL_DATA;
        m_VAL_TRAN_DLR_ind_null = DBM_NULL_DATA;
        m_VAL_TX_ind_null = DBM_NULL_DATA;
        m_VAL_PRCL_ind_null = DBM_NULL_DATA;
        m_VAL_COT_DLR_ind_null = DBM_NULL_DATA;
        m_NUM_TEL_ESTB_ind_null = DBM_NULL_DATA;
        
        
        m_DAT_CNFR_PAUZ_ind_null = DBM_NULL_DATA;
        m_DAT_CAN_PAUZ_ind_null = DBM_NULL_DATA;
        m_DTH_CNFR_ind_null = DBM_NULL_DATA;
        m_NUM_ESTB_CNFR_ind_null = DBM_NULL_DATA;
        m_QTD_PRCL_CNFR_ind_null = DBM_NULL_DATA;
        m_VAL_EFTV_CPTR_ind_null = DBM_NULL_DATA;
        m_NUM_SEQ_UNC_CNFR_ind_null = DBM_NULL_DATA;
        m_DAT_MOV_TRAN_CNFR_ind_null = DBM_NULL_DATA;         
        
        where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0052::TBSW0052( const std::string& whereClause )
    {
    
		// t694446@FIS_BEGIN - Data: 30/09/2013 - Renomeando os campos NTWK_ID
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, DTH_GMT, DTH_INI_TRAN, COD_MSG_ISO, COD_PCM_ISO, TIP_TRAN, IND_RD_ORG, NUM_ESTB, COD_DDD_ESTB, NUM_TEL_ESTB, COD_TERM, NUM_TRAN_RD, COD_RAM_ATVD, COD_POS_ENTR_MODO, COD_BNDR, COD_EMSR, NUM_ID_CAR, NUM_CAR, COD_PAIS_CAR, IND_VLDC_CVC, COD_OPER_TRAN, COD_MOED, VAL_TRAN, VAL_TRAN_DLR, VAL_COT_DLR, QTD_PRCL, VAL_PRCL, NUM_AUT, COD_MOT_AUT, NUM_MOT_RSPS, COD_MOT_SW, COD_MOT_ISO_EMSR, TXT_MSG_RSPS, IND_STTU_TRAN, DTH_STTU_TRAN, COD_CNDC_CNFR, DTH_CPTR, COD_OPER_ESTR, COD_TERM_ESTR, TIP_PES, VAL_TX, DTH_DFZM_TRAN, DTH_ESTR_TRAN, NOM_SITE_ACQR_ORGL, NOM_HOST_ACQR_ORGL, NOM_FE_ACQR_ORGL, NOM_SITE_ISSR, NOM_HOST_ISSR, NOM_FE_ISSR, NOM_SITE_ACQR_ATLZ, NOM_HOST_ACQR_ATLZ, NOM_FE_ACQR_ATLZ, NUM_AVSO_AUT, COD_AUT_ICH, DTH_TRAN_OFLN, DTH_TRAN_EMSR, COD_NTWK_ID_ACQR_ATLZ, COD_NTWK_ID_ACQR_ORGL, COD_NTWK_ID_ROUT_ATLZ, COD_NTWK_ID_ROUT_ORGL, COD_NTWK_ID_ISSR_ATLZ, COD_NTWK_ID_ISSR_ORGL";
		// t694446@FIS_END - Data: 30/09/2013 - Renomeando os campos NTWK_ID
        
        table_name = "TBSW0052";
        
        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_DTH_GMT_pos = 3;
        m_DTH_INI_TRAN_pos = 4;
        m_COD_MSG_ISO_pos = 5;
        m_COD_PCM_ISO_pos = 6;
        m_TIP_TRAN_pos = 7;
        m_IND_RD_ORG_pos = 8;
        m_NUM_ESTB_pos = 9;
        m_COD_DDD_ESTB_pos = 10;
        m_NUM_TEL_ESTB_pos = 11;
        m_COD_TERM_pos = 12;
        m_NUM_TRAN_RD_pos = 13;
        m_COD_RAM_ATVD_pos = 14;
        m_COD_POS_ENTR_MODO_pos = 15;
        m_COD_BNDR_pos = 16;
        m_COD_EMSR_pos = 17;
        m_NUM_ID_CAR_pos = 18;
        m_NUM_CAR_pos = 19;
        m_COD_PAIS_CAR_pos = 20;
        m_IND_VLDC_CVC_pos = 21;
        m_COD_OPER_TRAN_pos = 22;
        m_COD_MOED_pos = 23;
        m_VAL_TRAN_pos = 24;
        m_VAL_TRAN_DLR_pos = 25;
        m_VAL_COT_DLR_pos = 26;
        m_QTD_PRCL_pos = 27;
        m_VAL_PRCL_pos = 28;
        m_NUM_AUT_pos = 29;
        m_COD_MOT_AUT_pos = 30;
        m_NUM_MOT_RSPS_pos = 31;
        m_COD_MOT_SW_pos = 32;
        m_COD_MOT_ISO_EMSR_pos = 33;
        m_TXT_MSG_RSPS_pos = 34;
        m_IND_STTU_TRAN_pos = 35;
        m_DTH_STTU_TRAN_pos = 36;
        m_COD_CNDC_CNFR_pos = 37;
        m_DTH_CPTR_pos = 38;
        m_COD_OPER_ESTR_pos = 39;
        m_COD_TERM_ESTR_pos = 40;
        m_TIP_PES_pos = 41;
        m_VAL_TX_pos = 42;
        m_DTH_DFZM_TRAN_pos = 43;
        m_DTH_ESTR_TRAN_pos = 44;
        m_NOM_SITE_ACQR_ORGL_pos = 45;
        m_NOM_HOST_ACQR_ORGL_pos = 46;
        m_NOM_FE_ACQR_ORGL_pos = 47;
        m_NOM_SITE_ISSR_pos = 48;
        m_NOM_HOST_ISSR_pos = 49;
        m_NOM_FE_ISSR_pos = 50;
        m_NOM_SITE_ACQR_ATLZ_pos = 51;
        m_NOM_HOST_ACQR_ATLZ_pos = 52;
        m_NOM_FE_ACQR_ATLZ_pos = 53;
        m_NUM_AVSO_AUT_pos = 54;
        m_COD_AUT_ICH_pos = 55;
        m_DTH_TRAN_OFLN_pos = 56;
        m_DTH_TRAN_EMSR_pos = 57;
       
        m_NTWK_ID_ACQR_ATLZ_pos=58;
        m_NTWK_ID_ACQR_ORGL_pos=59;
        m_NTWK_ID_ROUTE_ATLZ_pos=60;
        m_NTWK_ID_ROUTE_ORGL_pos=61;
        m_NTWK_ID_ISSR_ATLZ_pos=62;
        m_NTWK_ID_ISSR_ORGL_pos=63;

       
        m_DAT_MOV_TRAN = 0;
        m_NUM_SEQ_UNC = 0;
        m_DTH_GMT = 0;
        m_DTH_INI_TRAN = 0;
        m_COD_MSG_ISO = 0;
        m_COD_PCM_ISO = 0;
        m_TIP_TRAN = 0;
        m_IND_RD_ORG = "";
        m_NUM_ESTB = 0;
        m_COD_DDD_ESTB = " ";
        dbm_longtodec( &m_NUM_TEL_ESTB, 0 );
        m_COD_TERM = " ";
        dbm_longtodec( &m_NUM_TRAN_RD, 0 );
        m_COD_RAM_ATVD = 0;
        m_COD_POS_ENTR_MODO = " ";
        m_COD_BNDR = 0;
        m_COD_EMSR = 0;
        m_NUM_ID_CAR = 0;
        m_NUM_CAR = " ";
        m_COD_PAIS_CAR = " ";
        m_IND_VLDC_CVC = " ";
        m_COD_OPER_TRAN = "";
        m_COD_MOED = " ";
        dbm_chartodec( &m_VAL_TRAN, "0.00", 2 );
        dbm_chartodec( &m_VAL_TRAN_DLR, "0.00", 2 );
        dbm_chartodec( &m_VAL_COT_DLR, "0.0000", 4 );
        m_QTD_PRCL = 0;
        dbm_chartodec( &m_VAL_PRCL, "0.00", 2 );
        m_NUM_AUT = "";
        m_COD_MOT_AUT = "";
        m_NUM_MOT_RSPS = 0;
        m_COD_MOT_SW = "";
        m_COD_MOT_ISO_EMSR = "";
        m_TXT_MSG_RSPS = "";
        m_IND_STTU_TRAN = " ";
        m_DTH_STTU_TRAN = 0;
        m_COD_CNDC_CNFR = "";
        m_DTH_CPTR = 0;
        m_COD_OPER_ESTR = "";
        m_COD_TERM_ESTR = " ";
        m_TIP_PES = " ";
        dbm_chartodec( &m_VAL_TX, "0.00", 2 );
        m_DTH_DFZM_TRAN = 0;
        m_DTH_ESTR_TRAN = 0;
        m_NOM_SITE_ACQR_ORGL = " ";
        m_NOM_HOST_ACQR_ORGL = " ";
        m_NOM_FE_ACQR_ORGL = " ";
        m_NOM_SITE_ISSR = "";
        m_NOM_HOST_ISSR = "";
        m_NOM_FE_ISSR = "";
        m_NOM_SITE_ACQR_ATLZ = "";
        m_NOM_HOST_ACQR_ATLZ = "";
        m_NOM_FE_ACQR_ATLZ = "";
        m_NUM_AVSO_AUT = "";
        m_COD_AUT_ICH = "";
        m_DTH_TRAN_OFLN = 0;
        m_DTH_TRAN_EMSR = 0;
        
        m_NTWK_ID_ACQR_ATLZ = "";
        m_NTWK_ID_ACQR_ORGL = "";
        m_NTWK_ID_ROUTE_ATLZ = "";
        m_NTWK_ID_ROUTE_ORGL = "";
        m_NTWK_ID_ISSR_ATLZ = "";
        m_NTWK_ID_ISSR_ORGL = "";        
        
        
        m_DTH_DFZM_TRAN_ind_null = DBM_NULL_DATA;
        m_DTH_ESTR_TRAN_ind_null = DBM_NULL_DATA;
        m_DTH_TRAN_EMSR_ind_null = DBM_NULL_DATA;
        m_DTH_CPTR_ind_null = DBM_NULL_DATA;
        m_DTH_TRAN_OFLN_ind_null = DBM_NULL_DATA;
        m_NUM_ID_CAR_ind_null = DBM_NULL_DATA;
        m_NUM_MOT_RSPS_ind_null = DBM_NULL_DATA;
        m_VAL_TRAN_ind_null = DBM_NULL_DATA;
        m_VAL_TRAN_DLR_ind_null = DBM_NULL_DATA;
        m_VAL_TX_ind_null = DBM_NULL_DATA;
        m_VAL_PRCL_ind_null = DBM_NULL_DATA;
        m_VAL_COT_DLR_ind_null = DBM_NULL_DATA;
        m_NUM_TEL_ESTB_ind_null = DBM_NULL_DATA;
        
        
        m_DAT_CNFR_PAUZ_ind_null = DBM_NULL_DATA;
        m_DAT_CAN_PAUZ_ind_null = DBM_NULL_DATA;
        m_DTH_CNFR_ind_null = DBM_NULL_DATA;
        m_NUM_ESTB_CNFR_ind_null = DBM_NULL_DATA;
        m_QTD_PRCL_CNFR_ind_null = DBM_NULL_DATA;
        m_VAL_EFTV_CPTR_ind_null = DBM_NULL_DATA;
        m_NUM_SEQ_UNC_CNFR_ind_null = DBM_NULL_DATA;
        m_DAT_MOV_TRAN_CNFR_ind_null = DBM_NULL_DATA;
        
        where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0052::~TBSW0052( )
    {
    }
    
    void TBSW0052::bind_columns( )
    {        
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_DTH_GMT_pos, &m_DTH_GMT );
        bind( m_DTH_INI_TRAN_pos, &m_DTH_INI_TRAN );
        bind( m_COD_MSG_ISO_pos, m_COD_MSG_ISO );
        bind( m_COD_PCM_ISO_pos, m_COD_PCM_ISO );
        bind( m_TIP_TRAN_pos, m_TIP_TRAN );
        bind( m_IND_RD_ORG_pos, m_IND_RD_ORG );
        bind( m_NUM_ESTB_pos, m_NUM_ESTB );
        bind( m_COD_DDD_ESTB_pos, m_COD_DDD_ESTB );
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_NUM_TRAN_RD_pos, m_NUM_TRAN_RD );
        bind( m_COD_RAM_ATVD_pos, m_COD_RAM_ATVD );
        bind( m_COD_POS_ENTR_MODO_pos, m_COD_POS_ENTR_MODO );
        bind( m_COD_BNDR_pos, m_COD_BNDR );
        bind( m_COD_EMSR_pos, m_COD_EMSR );
        bind( m_NUM_CAR_pos, m_NUM_CAR );
        bind( m_COD_PAIS_CAR_pos, m_COD_PAIS_CAR );
        bind( m_IND_VLDC_CVC_pos, m_IND_VLDC_CVC );
        bind( m_COD_OPER_TRAN_pos, m_COD_OPER_TRAN );
        bind( m_COD_MOED_pos, m_COD_MOED );
        bind( m_QTD_PRCL_pos, m_QTD_PRCL );
        bind( m_NUM_AUT_pos, m_NUM_AUT );
        bind( m_COD_MOT_AUT_pos, m_COD_MOT_AUT );
        bind( m_COD_MOT_SW_pos, m_COD_MOT_SW );
        bind( m_COD_MOT_ISO_EMSR_pos, m_COD_MOT_ISO_EMSR );
        bind( m_TXT_MSG_RSPS_pos, m_TXT_MSG_RSPS );
        bind( m_IND_STTU_TRAN_pos, m_IND_STTU_TRAN );
        bind( m_DTH_STTU_TRAN_pos, &m_DTH_STTU_TRAN );
        bind( m_COD_CNDC_CNFR_pos, m_COD_CNDC_CNFR );
        bind( m_DTH_CPTR_pos, &m_DTH_CPTR, &m_DTH_CPTR_ind_null );
        bind( m_COD_OPER_ESTR_pos, m_COD_OPER_ESTR );
        bind( m_COD_TERM_ESTR_pos, m_COD_TERM_ESTR );
        bind( m_TIP_PES_pos, m_TIP_PES );
        bind( m_DTH_DFZM_TRAN_pos, &m_DTH_DFZM_TRAN, &m_DTH_DFZM_TRAN_ind_null );
        bind( m_DTH_ESTR_TRAN_pos, &m_DTH_ESTR_TRAN, &m_DTH_ESTR_TRAN_ind_null );
        bind( m_NOM_SITE_ACQR_ORGL_pos, m_NOM_SITE_ACQR_ORGL );
        bind( m_NOM_HOST_ACQR_ORGL_pos, m_NOM_HOST_ACQR_ORGL );
        bind( m_NOM_FE_ACQR_ORGL_pos, m_NOM_FE_ACQR_ORGL );
        bind( m_NOM_SITE_ISSR_pos, m_NOM_SITE_ISSR );
        bind( m_NOM_HOST_ISSR_pos, m_NOM_HOST_ISSR );
        bind( m_NOM_FE_ISSR_pos, m_NOM_FE_ISSR );
        bind( m_NOM_SITE_ACQR_ATLZ_pos, m_NOM_SITE_ACQR_ATLZ );
        bind( m_NOM_HOST_ACQR_ATLZ_pos, m_NOM_HOST_ACQR_ATLZ );
        bind( m_NOM_FE_ACQR_ATLZ_pos, m_NOM_FE_ACQR_ATLZ );
        bind( m_NUM_AVSO_AUT_pos, m_NUM_AVSO_AUT );
        bind( m_COD_AUT_ICH_pos, m_COD_AUT_ICH );
        bind( m_DTH_TRAN_OFLN_pos, &m_DTH_TRAN_OFLN, &m_DTH_TRAN_OFLN_ind_null );
        bind( m_DTH_TRAN_EMSR_pos, &m_DTH_TRAN_EMSR, &m_DTH_TRAN_EMSR_ind_null );
        bind( m_NUM_ID_CAR_pos, m_NUM_ID_CAR, &m_NUM_ID_CAR_ind_null );
        bind( m_NUM_MOT_RSPS_pos, m_NUM_MOT_RSPS, &m_NUM_MOT_RSPS_ind_null );
        bind( m_VAL_TRAN_pos, m_VAL_TRAN, &m_VAL_TRAN_ind_null );
        bind( m_VAL_TRAN_DLR_pos, m_VAL_TRAN_DLR, &m_VAL_TRAN_DLR_ind_null );
        bind( m_VAL_TX_pos, m_VAL_TX, &m_VAL_TX_ind_null );
        bind( m_VAL_PRCL_pos, m_VAL_PRCL, &m_VAL_PRCL_ind_null );
        bind( m_VAL_COT_DLR_pos, m_VAL_COT_DLR, &m_VAL_COT_DLR_ind_null );
        bind( m_NUM_TEL_ESTB_pos, m_NUM_TEL_ESTB, &m_NUM_TEL_ESTB_ind_null );
        
        
        bind( m_NTWK_ID_ACQR_ATLZ_pos, m_NTWK_ID_ACQR_ATLZ );        
        bind( m_NTWK_ID_ACQR_ORGL_pos, m_NTWK_ID_ACQR_ORGL );
        bind( m_NTWK_ID_ROUTE_ATLZ_pos, m_NTWK_ID_ROUTE_ATLZ );
        bind( m_NTWK_ID_ROUTE_ORGL_pos, m_NTWK_ID_ROUTE_ORGL );
        bind( m_NTWK_ID_ISSR_ATLZ_pos, m_NTWK_ID_ISSR_ATLZ );
        bind( m_NTWK_ID_ACQR_ATLZ_pos, m_NTWK_ID_ACQR_ATLZ );
                
    }
    
    void TBSW0052::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0052::set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }
    void TBSW0052::set_DTH_GMT( dbm_datetime_t a_DTH_GMT )
    {
        m_DTH_GMT = a_DTH_GMT;
    }
    void TBSW0052::set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN )
    {
        m_DTH_INI_TRAN = a_DTH_INI_TRAN;
    }
    void TBSW0052::set_COD_MSG_ISO( unsigned long a_COD_MSG_ISO )
    {
        m_COD_MSG_ISO = a_COD_MSG_ISO;
    }
    void TBSW0052::set_COD_PCM_ISO( unsigned long a_COD_PCM_ISO )
    {
        m_COD_PCM_ISO = a_COD_PCM_ISO;
    }
    void TBSW0052::set_TIP_TRAN( unsigned long a_TIP_TRAN )
    {
        m_TIP_TRAN = a_TIP_TRAN;
    }
    void TBSW0052::set_IND_RD_ORG( const std::string& a_IND_RD_ORG )
    {
        m_IND_RD_ORG = a_IND_RD_ORG;
    }
    void TBSW0052::set_NUM_ESTB( unsigned long a_NUM_ESTB )
    {
        m_NUM_ESTB = a_NUM_ESTB;
    }
    void TBSW0052::set_COD_DDD_ESTB( const std::string& a_COD_DDD_ESTB )
    {
        m_COD_DDD_ESTB = a_COD_DDD_ESTB;
    }
    void TBSW0052::set_NUM_TEL_ESTB( oasis_dec_t a_NUM_TEL_ESTB )
    {
        dbm_deccopy( &m_NUM_TEL_ESTB, &a_NUM_TEL_ESTB );
        m_NUM_TEL_ESTB_ind_null = 0;
    }
    void TBSW0052::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void TBSW0052::set_NUM_TRAN_RD( oasis_dec_t a_NUM_TRAN_RD )
    {
        dbm_deccopy( &m_NUM_TRAN_RD, &a_NUM_TRAN_RD );
    }
    void TBSW0052::set_COD_RAM_ATVD( unsigned long a_COD_RAM_ATVD )
    {
        m_COD_RAM_ATVD = a_COD_RAM_ATVD;
    }
    void TBSW0052::set_COD_POS_ENTR_MODO( const std::string& a_COD_POS_ENTR_MODO )
    {
        m_COD_POS_ENTR_MODO = a_COD_POS_ENTR_MODO;
    }
    void TBSW0052::set_COD_BNDR( unsigned long a_COD_BNDR )
    {
        m_COD_BNDR = a_COD_BNDR;
    }
    void TBSW0052::set_COD_EMSR( unsigned long a_COD_EMSR )
    {
        m_COD_EMSR = a_COD_EMSR;
    }
    void TBSW0052::set_NUM_ID_CAR( unsigned long a_NUM_ID_CAR )
    {
        m_NUM_ID_CAR = a_NUM_ID_CAR;
        m_NUM_ID_CAR_ind_null = 0;
    }
    void TBSW0052::set_NUM_CAR( const std::string& a_NUM_CAR )
    {
        m_NUM_CAR = a_NUM_CAR;
    }
    void TBSW0052::set_COD_PAIS_CAR( const std::string& a_COD_PAIS_CAR )
    {
        m_COD_PAIS_CAR = a_COD_PAIS_CAR;
    }
    void TBSW0052::set_IND_VLDC_CVC( const std::string& a_IND_VLDC_CVC )
    {
        m_IND_VLDC_CVC = a_IND_VLDC_CVC;
    }
    void TBSW0052::set_COD_OPER_TRAN( const std::string& a_COD_OPER_TRAN )
    {
        m_COD_OPER_TRAN = a_COD_OPER_TRAN;
    }
    void TBSW0052::set_COD_MOED( const std::string& a_COD_MOED )
    {
        m_COD_MOED = a_COD_MOED;
    }
    void TBSW0052::set_VAL_TRAN( oasis_dec_t a_VAL_TRAN )
    {
        dbm_deccopy( &m_VAL_TRAN, &a_VAL_TRAN );
        m_VAL_TRAN_ind_null = 0;
    }
    void TBSW0052::set_VAL_TRAN_DLR( oasis_dec_t a_VAL_TRAN_DLR )
    {
        dbm_deccopy( &m_VAL_TRAN_DLR, &a_VAL_TRAN_DLR );
        m_VAL_TRAN_ind_null_DLR = 0;
    }
    void TBSW0052::set_VAL_COT_DLR( oasis_dec_t a_VAL_COT_DLR )
    {
        dbm_deccopy( &m_VAL_COT_DLR, &a_VAL_COT_DLR );
        m_VAL_COT_DLR_ind_null = 0;
    }
    void TBSW0052::set_QTD_PRCL( unsigned long a_QTD_PRCL )
    {
        m_QTD_PRCL = a_QTD_PRCL;
    }
    void TBSW0052::set_VAL_PRCL( oasis_dec_t a_VAL_PRCL )
    {
        dbm_deccopy( &m_VAL_PRCL, &a_VAL_PRCL );
        m_VAL_PRCL_ind_null = 0;
    }
    void TBSW0052::set_NUM_AUT( const std::string& a_NUM_AUT )
    {
        m_NUM_AUT = a_NUM_AUT;
    }
    void TBSW0052::set_COD_MOT_AUT( const std::string& a_COD_MOT_AUT )
    {
        m_COD_MOT_AUT = a_COD_MOT_AUT;
    }
    void TBSW0052::set_NUM_MOT_RSPS( unsigned long a_NUM_MOT_RSPS )
    {
        m_NUM_MOT_RSPS = a_NUM_MOT_RSPS;
        m_NUM_MOT_RSPS_ind_null = 0;
    }
    void TBSW0052::set_COD_MOT_SW( const std::string& a_COD_MOT_SW )
    {
        m_COD_MOT_SW = a_COD_MOT_SW;
    }
    void TBSW0052::set_COD_MOT_ISO_EMSR( const std::string& a_COD_MOT_ISO_EMSR )
    {
        m_COD_MOT_ISO_EMSR = a_COD_MOT_ISO_EMSR;
    }
    void TBSW0052::set_TXT_MSG_RSPS( const std::string& a_TXT_MSG_RSPS )
    {
        m_TXT_MSG_RSPS = a_TXT_MSG_RSPS;
    }
    void TBSW0052::set_IND_STTU_TRAN( const std::string& a_IND_STTU_TRAN )
    {
        m_IND_STTU_TRAN = a_IND_STTU_TRAN;
    }
    void TBSW0052::set_DTH_STTU_TRAN( dbm_datetime_t a_DTH_STTU_TRAN )
    {
        m_DTH_STTU_TRAN = a_DTH_STTU_TRAN;
    }
    void TBSW0052::set_COD_CNDC_CNFR( const std::string& a_COD_CNDC_CNFR )
    {
        m_COD_CNDC_CNFR = a_COD_CNDC_CNFR;
    }
    void TBSW0052::set_DTH_CPTR( dbm_datetime_t a_DTH_CPTR )
    {
        m_DTH_CPTR = a_DTH_CPTR;
        m_DTH_CPTR_ind_null = 0;
    }
    void TBSW0052::set_COD_OPER_ESTR( const std::string& a_COD_OPER_ESTR )
    {
        m_COD_OPER_ESTR = a_COD_OPER_ESTR;
    }
    void TBSW0052::set_COD_TERM_ESTR( const std::string& a_COD_TERM_ESTR )
    {
        m_COD_TERM_ESTR = a_COD_TERM_ESTR;
    }
    void TBSW0052::set_TIP_PES( const std::string& a_TIP_PES )
    {
        m_TIP_PES = a_TIP_PES;
    }
    void TBSW0052::set_VAL_TX( oasis_dec_t a_VAL_TX )
    {
        dbm_deccopy( &m_VAL_TX, &a_VAL_TX );
        m_VAL_TX_ind_null = 0;
    }
    void TBSW0052::set_DTH_DFZM_TRAN( dbm_datetime_t a_DTH_DFZM_TRAN )
    {
        m_DTH_DFZM_TRAN = a_DTH_DFZM_TRAN;
        m_DTH_DFZM_TRAN_ind_null = 0;
    }
    void TBSW0052::set_DTH_ESTR_TRAN( dbm_datetime_t a_DTH_ESTR_TRAN )
    {
        m_DTH_ESTR_TRAN = a_DTH_ESTR_TRAN;
        m_DTH_ESTR_TRAN_ind_null = 0;
    }
    void TBSW0052::set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL )
    {
        m_NOM_SITE_ACQR_ORGL = a_NOM_SITE_ACQR_ORGL;
    }
    void TBSW0052::set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL )
    {
        m_NOM_HOST_ACQR_ORGL = a_NOM_HOST_ACQR_ORGL;
    }
    void TBSW0052::set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL )
    {
        m_NOM_FE_ACQR_ORGL = a_NOM_FE_ACQR_ORGL;
    }
    void TBSW0052::set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR )
    {
        m_NOM_SITE_ISSR = a_NOM_SITE_ISSR;
    }
    void TBSW0052::set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR )
    {
        m_NOM_HOST_ISSR = a_NOM_HOST_ISSR;
    }
    void TBSW0052::set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR )
    {
        m_NOM_FE_ISSR = a_NOM_FE_ISSR;
    }
    void TBSW0052::set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ )
    {
        m_NOM_SITE_ACQR_ATLZ = a_NOM_SITE_ACQR_ATLZ;
    }
    void TBSW0052::set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ )
    {
        m_NOM_HOST_ACQR_ATLZ = a_NOM_HOST_ACQR_ATLZ;
    }
    void TBSW0052::set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ )
    {
        m_NOM_FE_ACQR_ATLZ = a_NOM_FE_ACQR_ATLZ;
    }
    void TBSW0052::set_NUM_AVSO_AUT( const std::string& a_NUM_AVSO_AUT )
    {
        m_NUM_AVSO_AUT = a_NUM_AVSO_AUT;
    }
    void TBSW0052::set_COD_AUT_ICH( const std::string& a_COD_AUT_ICH )
    {
        m_COD_AUT_ICH = a_COD_AUT_ICH;
    }
    void TBSW0052::set_DTH_TRAN_OFLN( dbm_datetime_t a_DTH_TRAN_OFLN )
    {
        m_DTH_TRAN_OFLN = a_DTH_TRAN_OFLN;
        m_DTH_TRAN_OFLN_ind_null = 0;
    }
    void TBSW0052::set_DTH_TRAN_EMSR( dbm_datetime_t a_DTH_TRAN_EMSR )
    {
        m_DTH_TRAN_EMSR = a_DTH_TRAN_EMSR;
        m_DTH_TRAN_EMSR_ind_null = 0;
    }
    
    
        
    void TBSW0052::set_NTWK_ID_ACQR_ATLZ( const std::string& a_NTWK_ID_ACQR_ATLZ )
    {
        m_NTWK_ID_ACQR_ATLZ = a_NTWK_ID_ACQR_ATLZ;
        m_NTWK_ID_ACQR_ATLZ_ind_null = 0;
    }
    void TBSW0052::set_NTWK_ID_ACQR_ORGL( const std::string& a_NTWK_ID_ACQR_ORGL )
    {
        m_NTWK_ID_ACQR_ORGL = a_NTWK_ID_ACQR_ORGL;
        m_NTWK_ID_ACQR_ORGL_ind_null = 0;
    }
    void TBSW0052::set_NTWK_ID_ROUTE_ATLZ( const std::string& a_NTWK_ID_ROUTE_ATLZ )
    {
        m_NTWK_ID_ROUTE_ATLZ = a_NTWK_ID_ROUTE_ATLZ;
        m_NTWK_ID_ROUTE_ATLZ_ind_null = 0;
    }
    
    void TBSW0052::set_NTWK_ID_ROUTE_ORGL( const std::string& a_NTWK_ID_ROUTE_ORGL )
    {
        m_NTWK_ID_ROUTE_ORGL = a_NTWK_ID_ROUTE_ORGL;
        m_NTWK_ID_ROUTE_ORGL_ind_null = 0;
    }
    void TBSW0052::set_NTWK_ID_ISSR_ATLZ( const std::string& a_NTWK_ID_ISSR_ATLZ )
    {
        m_NTWK_ID_ISSR_ATLZ = a_NTWK_ID_ISSR_ATLZ;
        m_NTWK_ID_ISSR_ATLZ_ind_null = 0;
    }
    void TBSW0052::set_m_NTWK_ID_ISSR_ORGL( const std::string& a_NTWK_ID_ISSR_ORGL )
    {
        m_NTWK_ID_ISSR_ORGL = a_NTWK_ID_ISSR_ORGL;
        m_NTWK_ID_ISSR_ORGL_ind_null = 0;
    }  
    
    
    
    
    
    
    unsigned long TBSW0052::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    unsigned long TBSW0052::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }
    dbm_datetime_t TBSW0052::get_DTH_GMT( ) const
    {
        return( m_DTH_GMT );
    }
    dbm_datetime_t TBSW0052::get_DTH_INI_TRAN( ) const
    {
        return( m_DTH_INI_TRAN );
    }
    unsigned long TBSW0052::get_COD_MSG_ISO( ) const
    {
        return( m_COD_MSG_ISO );
    }
    unsigned long TBSW0052::get_COD_PCM_ISO( ) const
    {
        return( m_COD_PCM_ISO );
    }
    unsigned long TBSW0052::get_TIP_TRAN( ) const
    {
        return( m_TIP_TRAN );
    }
    const std::string& TBSW0052::get_IND_RD_ORG( ) const
    {
        return( m_IND_RD_ORG );
    }
    unsigned long TBSW0052::get_NUM_ESTB( ) const
    {
        return( m_NUM_ESTB );
    }
    const std::string& TBSW0052::get_COD_DDD_ESTB( ) const
    {
        return( m_COD_DDD_ESTB );
    }
    oasis_dec_t TBSW0052::get_NUM_TEL_ESTB( ) const
    {
        return( m_NUM_TEL_ESTB );
    }
    const std::string& TBSW0052::get_COD_TERM( ) const
    {
        return( m_COD_TERM );
    }
    oasis_dec_t TBSW0052::get_NUM_TRAN_RD( ) const
    {
        return( m_NUM_TRAN_RD );
    }
    unsigned long TBSW0052::get_COD_RAM_ATVD( ) const
    {
        return( m_COD_RAM_ATVD );
    }
    const std::string& TBSW0052::get_COD_POS_ENTR_MODO( ) const
    {
        return( m_COD_POS_ENTR_MODO );
    }
    unsigned long TBSW0052::get_COD_BNDR( ) const
    {
        return( m_COD_BNDR );
    }
    unsigned long TBSW0052::get_COD_EMSR( ) const
    {
        return( m_COD_EMSR );
    }
    unsigned long TBSW0052::get_NUM_ID_CAR( ) const
    {
        return( m_NUM_ID_CAR );
    }
    const std::string& TBSW0052::get_NUM_CAR( ) const
    {
        return( m_NUM_CAR );
    }
    const std::string& TBSW0052::get_COD_PAIS_CAR( ) const
    {
        return( m_COD_PAIS_CAR );
    }
    const std::string& TBSW0052::get_IND_VLDC_CVC( ) const
    {
        return( m_IND_VLDC_CVC );
    }
    const std::string& TBSW0052::get_COD_OPER_TRAN( ) const
    {
        return( m_COD_OPER_TRAN );
    }
    const std::string& TBSW0052::get_COD_MOED( ) const
    {
        return( m_COD_MOED );
    }
    oasis_dec_t TBSW0052::get_VAL_TRAN( ) const
    {
        return( m_VAL_TRAN );
    }
    oasis_dec_t TBSW0052::get_VAL_TRAN_DLR( ) const
    {
        return( m_VAL_TRAN_DLR );
    }
    oasis_dec_t TBSW0052::get_VAL_COT_DLR( ) const
    {
        return( m_VAL_COT_DLR );
    }
    unsigned long TBSW0052::get_QTD_PRCL( ) const
    {
        return( m_QTD_PRCL );
    }
    oasis_dec_t TBSW0052::get_VAL_PRCL( ) const
    {
        return( m_VAL_PRCL );
    }
    const std::string& TBSW0052::get_NUM_AUT( ) const
    {
        return( m_NUM_AUT );
    }
    const std::string& TBSW0052::get_COD_MOT_AUT( ) const
    {
        return( m_COD_MOT_AUT );
    }
    unsigned long TBSW0052::get_NUM_MOT_RSPS( ) const
    {
        return( m_NUM_MOT_RSPS );
    }
    const std::string& TBSW0052::get_COD_MOT_SW( ) const
    {
        return( m_COD_MOT_SW );
    }
    const std::string& TBSW0052::get_COD_MOT_ISO_EMSR( ) const
    {
        return( m_COD_MOT_ISO_EMSR );
    }
    const std::string& TBSW0052::get_TXT_MSG_RSPS( ) const
    {
        return( m_TXT_MSG_RSPS );
    }
    const std::string& TBSW0052::get_IND_STTU_TRAN( ) const
    {
        return( m_IND_STTU_TRAN );
    }
    dbm_datetime_t TBSW0052::get_DTH_STTU_TRAN( ) const
    {
        return( m_DTH_STTU_TRAN );
    }
    const std::string& TBSW0052::get_COD_CNDC_CNFR( ) const
    {
        return( m_COD_CNDC_CNFR );
    }
    dbm_datetime_t TBSW0052::get_DTH_CPTR( ) const
    {
        return( m_DTH_CPTR );
    }
    const std::string& TBSW0052::get_COD_OPER_ESTR( ) const
    {
        return( m_COD_OPER_ESTR );
    }
    const std::string& TBSW0052::get_COD_TERM_ESTR( ) const
    {
        return( m_COD_TERM_ESTR );
    }
    const std::string& TBSW0052::get_TIP_PES( ) const
    {
        return( m_TIP_PES );
    }
    oasis_dec_t TBSW0052::get_VAL_TX( ) const
    {
        return( m_VAL_TX );
    }
    dbm_datetime_t TBSW0052::get_DTH_DFZM_TRAN( ) const
    {
        return( m_DTH_DFZM_TRAN );
    }
    dbm_datetime_t TBSW0052::get_DTH_ESTR_TRAN( ) const
    {
        return( m_DTH_ESTR_TRAN );
    }
    const std::string& TBSW0052::get_NOM_SITE_ACQR_ORGL( ) const
    {
        return( m_NOM_SITE_ACQR_ORGL );
    }
    const std::string& TBSW0052::get_NOM_HOST_ACQR_ORGL( ) const
    {
        return( m_NOM_HOST_ACQR_ORGL );
    }
    const std::string& TBSW0052::get_NOM_FE_ACQR_ORGL( ) const
    {
        return( m_NOM_FE_ACQR_ORGL );
    }
    const std::string& TBSW0052::get_NOM_SITE_ISSR( ) const
    {
        return( m_NOM_SITE_ISSR );
    }
    const std::string& TBSW0052::get_NOM_HOST_ISSR( ) const
    {
        return( m_NOM_HOST_ISSR );
    }
    const std::string& TBSW0052::get_NOM_FE_ISSR( ) const
    {
        return( m_NOM_FE_ISSR );
    }
    const std::string& TBSW0052::get_NOM_SITE_ACQR_ATLZ( ) const
    {
        return( m_NOM_SITE_ACQR_ATLZ );
    }
    const std::string& TBSW0052::get_NOM_HOST_ACQR_ATLZ( ) const
    {
        return( m_NOM_HOST_ACQR_ATLZ );
    }
    const std::string& TBSW0052::get_NOM_FE_ACQR_ATLZ( ) const
    {
        return( m_NOM_FE_ACQR_ATLZ );
    }
    const std::string& TBSW0052::get_NUM_AVSO_AUT( ) const
    {
        return( m_NUM_AVSO_AUT );
    }
    const std::string& TBSW0052::get_COD_AUT_ICH( ) const
    {
        return( m_COD_AUT_ICH );
    }
    dbm_datetime_t TBSW0052::get_DTH_TRAN_OFLN( ) const
    {
        return( m_DTH_TRAN_OFLN );
    }
    dbm_datetime_t TBSW0052::get_DTH_TRAN_EMSR( ) const
    {
        return( m_DTH_TRAN_EMSR );
    }
    
    
    const std::string& TBSW0052::get_NTWK_ID_ACQR_ATLZ( ) const
    {
        return(m_NTWK_ID_ACQR_ATLZ);
    }
    const std::string& TBSW0052::get_NTWK_ID_ACQR_ORGL(  ) const
    {
        return(m_NTWK_ID_ACQR_ORGL);
    }
    const std::string& TBSW0052::get_NTWK_ID_ROUTE_ATLZ(  ) const
    {
        return(m_NTWK_ID_ROUTE_ATLZ);
    }
    
    const std::string& TBSW0052::get_NTWK_ID_ROUTE_ORGL(  ) const
    {
        return(m_NTWK_ID_ROUTE_ORGL);
    }
    const std::string& TBSW0052::get_NTWK_ID_ISSR_ATLZ( ) const
    {
        return(m_NTWK_ID_ISSR_ATLZ);
    }
    const std::string& TBSW0052::get_m_NTWK_ID_ISSR_ORGL(  ) const
    {
        return(m_NTWK_ID_ISSR_ORGL);
    }    
    
    
    
    
    
    
    //FUNCAO FLAG PARA NULO
    void TBSW0052::let_DTH_DFZM_TRAN_as_is( )
    {
        m_DTH_DFZM_TRAN_ind_null = is_null( &m_DTH_DFZM_TRAN ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_DTH_ESTR_TRAN_as_is( )
    {
        m_DTH_ESTR_TRAN_ind_null = is_null( &m_DTH_ESTR_TRAN ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_DTH_TRAN_EMSR_as_is( )
    {
        m_DTH_TRAN_EMSR_ind_null = is_null( &m_DTH_TRAN_EMSR ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_DTH_CPTR_as_is( )
    {
        m_DTH_CPTR_ind_null = is_null( &m_DTH_CPTR ) ? DBM_NULL_DATA : 0;
    }    
    void TBSW0052::let_DTH_TRAN_OFLN_as_is( )
    {
        m_DTH_TRAN_OFLN_ind_null = is_null( &m_DTH_TRAN_OFLN ) ? DBM_NULL_DATA : 0;
    }    
    void TBSW0052::let_NUM_ID_CAR_as_is( )
    {
        m_NUM_ID_CAR_ind_null = is_null( &m_NUM_ID_CAR ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_NUM_MOT_RSPS_as_is( )
    {
        m_NUM_MOT_RSPS_ind_null = is_null( &m_NUM_MOT_RSPS ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_VAL_TRAN_as_is( )
    {
        m_VAL_TRAN_ind_null = is_null( &m_VAL_TRAN ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_VAL_TRAN_DLR_as_is( )
    {
        m_VAL_TRAN_DLR_ind_null = is_null( &m_VAL_TRAN_DLR ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_VAL_TX_as_is( )
    {
        m_VAL_TX_ind_null = is_null( &m_VAL_TX ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_VAL_PRCL_as_is( )
    {
        m_VAL_PRCL_ind_null = is_null( &m_VAL_PRCL ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_VAL_COT_DLR_as_is( )
    {
        m_VAL_COT_DLR_ind_null = is_null( &m_VAL_COT_DLR ) ? DBM_NULL_DATA : 0;
    }
    void TBSW0052::let_NUM_TEL_ESTB_as_is( )
    {
        m_NUM_TEL_ESTB_ind_null = is_null( &m_NUM_TEL_ESTB ) ? DBM_NULL_DATA : 0;
    } 
    
} //namespace dbaccess_common

