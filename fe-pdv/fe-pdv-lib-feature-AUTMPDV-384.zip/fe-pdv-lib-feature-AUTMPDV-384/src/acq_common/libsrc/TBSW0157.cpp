#include "TBSW0157.hpp"

namespace dbaccess_common
{
	TBSW0157::TBSW0157()
	{
		initialize();
		where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0157::TBSW0157( const std::string& whereClause )
	{
		initialize();
		where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

    void TBSW0157::initialize()
    {
		query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, COD_SERV_TRAN, NUM_PDV_ORG_TRAN, COD_TERM_ORG_TRAN, NUM_DDD_RCRG, NUM_TEL_RCRG, NUM_SEQ_UNC_OPER";

		table_name = "TBSW0157";

        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_COD_SERV_TRAN_pos = 3;
        m_NUM_PDV_ORG_TRAN_pos = 4;
        m_COD_TERM_ORG_TRAN_pos = 5;
        m_NUM_DDD_RCRG_pos = 6;
        m_NUM_TEL_RCRG_pos = 7;
        m_NUM_SEQ_UNC_OPER_pos = 8;
        m_DAT_MOV_TRAN = 0;
        dbm_chartodec( &m_NUM_SEQ_UNC, "0", 0 );
		m_COD_SERV_TRAN = 0;
        m_NUM_PDV_ORG_TRAN = 0;
        m_COD_TERM_ORG_TRAN = " ";
        m_NUM_DDD_RCRG = 0;
        dbm_chartodec( &m_NUM_TEL_RCRG, "0", 0 );        
        m_NUM_SEQ_UNC_OPER = 0;

	}	
	
	TBSW0157::~TBSW0157()
	{
	}

	void TBSW0157::bind_columns()
	{
        bind( m_DAT_MOV_TRAN_pos,      m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos,       m_NUM_SEQ_UNC );
        bind( m_COD_SERV_TRAN_pos,     m_COD_SERV_TRAN );
        bind( m_NUM_PDV_ORG_TRAN_pos,  m_NUM_PDV_ORG_TRAN );
        bind( m_COD_TERM_ORG_TRAN_pos, m_COD_TERM_ORG_TRAN );
        bind( m_NUM_DDD_RCRG_pos,      m_NUM_DDD_RCRG );
        bind( m_NUM_TEL_RCRG_pos,      m_NUM_TEL_RCRG );
        bind( m_NUM_SEQ_UNC_OPER_pos,  m_NUM_SEQ_UNC_OPER );
	}

    void TBSW0157::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN  = a_DAT_MOV_TRAN;
    }
    void TBSW0157::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }
    void TBSW0157::set_COD_SERV_TRAN( unsigned long a_COD_SERV_TRAN )
    {
        m_COD_SERV_TRAN = a_COD_SERV_TRAN;
    }
    void TBSW0157::set_NUM_PDV_ORG_TRAN( unsigned long a_NUM_PDV_ORG_TRAN )
    {
        m_NUM_PDV_ORG_TRAN = a_NUM_PDV_ORG_TRAN;
    }
    void TBSW0157::set_COD_TERM_ORG_TRAN( const std::string& a_COD_TERM_ORG_TRAN )
    {
        m_COD_TERM_ORG_TRAN = a_COD_TERM_ORG_TRAN;
    }
    void TBSW0157::set_NUM_DDD_RCRG( unsigned long a_NUM_DDD_RCRG )
    {
        m_NUM_DDD_RCRG = a_NUM_DDD_RCRG;
    }
    void TBSW0157::set_NUM_TEL_RCRG( oasis_dec_t a_NUM_TEL_RCRG )
    {
        m_NUM_TEL_RCRG = a_NUM_TEL_RCRG;
    }
    void TBSW0157::set_NUM_SEQ_UNC_OPER( unsigned long a_NUM_SEQ_UNC_OPER )
    {
        m_NUM_SEQ_UNC_OPER = a_NUM_SEQ_UNC_OPER;
    }


    unsigned long TBSW0157::get_DAT_MOV_TRAN() const
    {
        return m_DAT_MOV_TRAN;
    }
    oasis_dec_t TBSW0157::get_NUM_SEQ_UNC() const
    {
        return m_NUM_SEQ_UNC;
    }
    unsigned long TBSW0157::get_COD_SERV_TRAN() const
    {
        return m_COD_SERV_TRAN;
    }
    unsigned long TBSW0157::get_NUM_PDV_ORG_TRAN() const
    {
        return m_NUM_PDV_ORG_TRAN;
    }
    const std::string& TBSW0157::get_COD_TERM_ORG_TRAN() const
    {
        return m_COD_TERM_ORG_TRAN;
    }
    unsigned long TBSW0157::get_NUM_DDD_RCRG() const
    {
        return m_NUM_DDD_RCRG;
    }
	oasis_dec_t TBSW0157::get_NUM_TEL_RCRG() const
    {
        return m_NUM_TEL_RCRG;
    }
    unsigned long TBSW0157::get_NUM_SEQ_UNC_OPER() const
    {
        return m_NUM_SEQ_UNC_OPER;
    }

} //namespace dbaccess_common

