#include "TBSW0030.hpp"

namespace dbaccess_common
{
    TBSW0030::TBSW0030()
    {
        initialize();

        where_condition = "";

        // Teste de conteudo do registro
        m_log = logger::DebugWriter::getInstance();
	update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0030::TBSW0030( const std::string& whereClause )
    {
        initialize();

        where_condition = whereClause;

        // Teste de conteudo do registro
        m_log = logger::DebugWriter::getInstance();
	update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0030::~TBSW0030()
    {
    }

    void TBSW0030::initialize()
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, DTH_GMT, DTH_INI_TRAN, DAT_CTB_TRAN, COD_MSG_ISO, COD_PCM_ISO, TIP_TRAN, TIP_DTLH_TRAN, TIP_VD, TIP_PLN_PGMN, COD_CTGR_TRAN, COD_CMPM_TRAN, NUM_RD_ORG, NUM_ESTB, COD_TERM, NUM_STAN, TIP_TCNL, TIP_TERM, COD_RAM_ATVD, COD_POS_ENTR_MODO, COD_BNDR, COD_EMSR, NUM_EMSR, NUM_ID_CAR, COD_PAIS_CAR, NUM_CAR, DAT_VLD_CAR, IND_TRK, IND_CPTR_CVC_2, NUM_CVC_2, COD_TRK_CAR, COD_SERV, COD_SERV_SNHA, IND_ID_PREV, VAL_TRAN, VAL_TOTL_TRAN, COD_MOED, NUM_CV, NUM_AUT, COD_MOT_AUT, NUM_MOT_RSPS, COD_MOT_RSPS_EXT, COD_MOT_SW, IND_STTU_TRAN, DTH_STTU_TRAN, COD_PROD, NUM_RSMO_VD, DAT_RSMO_VD, NOM_LOC_ESTB, IND_TERM_RLCD_CHIP, IND_DFZM, IND_ESTR, IND_CPTRDO, ";
        query_fields += "IND_AGND_TRAN, IND_IMPR_CPOM, IND_EMSR_MTC, IND_DA_RLCD_CHIP, IND_DA_RLCD_IATA, IND_TRAN_REFD, TIP_TRAN_ORGL, DAT_EXPC_TRAN, VAL_TRAN_DLR, VAL_COT_DLR, COD_CTR, VAL_TX, COD_REF_RESTANTE, COD_CNDC_CPTR_PAUZ, TIP_ENT_PAUZ, COD_OPER_CNFR, PRCN_TX_RISC, VAL_TX_RISC, COD_CNDC_CPTR, NOM_SITE_ACQR_ORGL, NOM_HOST_ACQR_ORGL, NOM_FE_ACQR_ORGL, NOM_SITE_ISSR, NOM_HOST_ISSR, NOM_FE_ISSR, NOM_SITE_ACQR_ATLZ, NOM_HOST_ACQR_ATLZ, NOM_FE_ACQR_ATLZ, TXT_DA_ADIC_EMSR, TIP_MODL_CPTR, DTH_TRAN_EMSR, DAT_LQDC_EMSR, COD_ISTT_ACQR, COD_ISTT_FRWD, COD_RSPS_DTLH_EMSR, COD_RSTD_NUM_CVC_2, COD_SERV_TRK_CAR, COD_VLDC_EMSR, IND_AUT, IND_DA_RLCD_KMRC, IND_TRAN_SEM_ORGL, DAT_PAUZ, ";
        query_fields += "NUM_SEQ_UNC_PAUZ, COD_TRAN_CAD, COD_AUT_EMSR, COD_NTWK_ID_ACQR_ATLZ,  COD_NTWK_ID_ACQR_ORGL, COD_NTWK_ID_ROUT_ATLZ, COD_NTWK_ID_ROUT_ORGL, COD_NTWK_ID_ISSR_ATLZ, COD_NTWK_ID_ISSR_ORGL,COD_RAM_MCC, COD_CNDC_CPTR_EMSR, COD_PROD_CDST, COD_SERV_CORP, COD_EMP_ADQT, NUM_PDV_EXT, NUM_PDV_VAN, COD_DSPO_NFC, COD_PROD_PRCR, COD_GRU_CLAS_RAM, IND_TRAN_TKN, COD_ORG_APRV";
        query_fields += ",NOM_PORT_CAR, COD_BIN_CAR, NUM_FINL_CAR, COD_PORT_PRES_VLDC_BNDR, COD_CPCD_TERM_VLDC_BNDR, COD_FMTR_HEDR, IND_QRCODE, COD_PRCR, COD_ROTM_TRAN, ID_RQSC_PIX, COD_PCM_EMS, ID_REF_BNDR, COD_PRCR_ADQT, COD_SIT_OFRT";


        table_name = "TBSW0030";

        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_DTH_GMT_pos = 3;
        m_DTH_INI_TRAN_pos = 4;
        m_DAT_CTB_TRAN_pos = 5;
        m_COD_MSG_ISO_pos = 6;
        m_COD_PCM_ISO_pos = 7;
        m_TIP_TRAN_pos = 8;
        m_TIP_DTLH_TRAN_pos = 9;
        m_TIP_VD_pos = 10;
        m_TIP_PLN_PGMN_pos = 11;
        m_COD_CTGR_TRAN_pos = 12;
        m_COD_CMPM_TRAN_pos = 13;
        m_NUM_RD_ORG_pos = 14;
        m_NUM_ESTB_pos = 15;
        m_COD_TERM_pos = 16;
        m_NUM_STAN_pos = 17;
        m_TIP_TCNL_pos = 18;
        m_TIP_TERM_pos = 19;
        m_COD_RAM_ATVD_pos = 20;
        m_COD_POS_ENTR_MODO_pos = 21;
        m_COD_BNDR_pos = 22;
        m_COD_EMSR_pos = 23;
        m_NUM_EMSR_pos = 24;
        m_NUM_ID_CAR_pos = 25;
        m_COD_PAIS_CAR_pos = 26;
        m_NUM_CAR_pos = 27;
        m_DAT_VLD_CAR_pos = 28;
        m_IND_TRK_pos = 29;
        m_IND_CPTR_CVC_2_pos = 30;
        m_NUM_CVC_2_pos = 31;
        m_COD_TRK_CAR_pos = 32;
        m_COD_SERV_pos = 33;
        m_COD_SERV_SNHA_pos = 34;
        m_IND_ID_PREV_pos = 35;
        m_VAL_TRAN_pos = 36;
        m_VAL_TOTL_TRAN_pos = 37;
        m_COD_MOED_pos = 38;
        m_NUM_CV_pos = 39;
        m_NUM_AUT_pos = 40;
        m_COD_MOT_AUT_pos = 41;
        m_NUM_MOT_RSPS_pos = 42;
        m_COD_MOT_RSPS_EXT_pos = 43;
        m_COD_MOT_SW_pos = 44;
        m_IND_STTU_TRAN_pos = 45;
        m_DTH_STTU_TRAN_pos = 46;
        m_COD_PROD_pos = 47;
        m_NUM_RSMO_VD_pos = 48;
        m_DAT_RSMO_VD_pos = 49;
        m_NOM_LOC_ESTB_pos = 50;
        m_IND_TERM_RLCD_CHIP_pos = 51;
        m_IND_DFZM_pos = 52;
        m_IND_ESTR_pos = 53;
        m_IND_CPTRDO_pos = 54;
        m_IND_AGND_TRAN_pos = 55;
        m_IND_IMPR_CPOM_pos = 56;
        m_IND_EMSR_MTC_pos = 57;
        m_IND_DA_RLCD_CHIP_pos = 58;
        m_IND_DA_RLCD_IATA_pos = 59;
        m_IND_TRAN_REFD_pos = 60;
        m_TIP_TRAN_ORGL_pos = 61;
        m_DAT_EXPC_TRAN_pos = 62;
        m_VAL_TRAN_DLR_pos = 63;
        m_VAL_COT_DLR_pos = 64;
        m_COD_CTR_pos = 65;
        m_VAL_TX_pos = 66;
        m_COD_REF_RESTANTE_pos = 67;
        m_COD_CNDC_CPTR_PAUZ_pos = 68;
        m_TIP_ENT_PAUZ_pos = 69;
        m_COD_OPER_CNFR_pos = 70;
        m_PRCN_TX_RISC_pos = 71;
        m_VAL_TX_RISC_pos = 72;
        m_COD_CNDC_CPTR_pos = 73;
        m_NOM_SITE_ACQR_ORGL_pos = 74;
        m_NOM_HOST_ACQR_ORGL_pos = 75;
        m_NOM_FE_ACQR_ORGL_pos = 76;
        m_NOM_SITE_ISSR_pos = 77;
        m_NOM_HOST_ISSR_pos = 78;
        m_NOM_FE_ISSR_pos = 79;
        m_NOM_SITE_ACQR_ATLZ_pos = 80;
        m_NOM_HOST_ACQR_ATLZ_pos = 81;
        m_NOM_FE_ACQR_ATLZ_pos = 82;
        m_TXT_DA_ADIC_EMSR_pos = 83;
        m_TIP_MODL_CPTR_pos = 84;
        m_DTH_TRAN_EMSR_pos = 85;
        m_DAT_LQDC_EMSR_pos = 86;
        m_COD_ISTT_ACQR_pos = 87;
        m_COD_ISTT_FRWD_pos = 88;
        m_COD_RSPS_DTLH_EMSR_pos = 89;
        m_COD_RSTD_NUM_CVC_2_pos = 90;
        m_COD_SERV_TRK_CAR_pos = 91;
        m_COD_VLDC_EMSR_pos = 92;
        m_IND_AUT_pos = 93;
        m_IND_DA_RLCD_KMRC_pos = 94;
        m_IND_TRAN_SEM_ORGL_pos = 95;
        m_DAT_PAUZ_pos = 96;
        m_NUM_SEQ_UNC_PAUZ_pos = 97;
        m_COD_TRAN_CAD_pos = 98;
        m_COD_AUT_EMSR_pos = 99;
        m_COD_NTWK_ID_ACQR_ATLZ_pos = 100;
        m_COD_NTWK_ID_ACQR_ORGL_pos = 101;
        m_COD_NTWK_ID_ROUT_ATLZ_pos = 102;
        m_COD_NTWK_ID_ROUT_ORGL_pos = 103;
        m_COD_NTWK_ID_ISSR_ATLZ_pos = 104;
        m_COD_NTWK_ID_ISSR_ORGL_pos = 105;
        m_COD_RAM_MCC_pos = 106;
        m_COD_CNDC_CPTR_EMSR_pos = 107;
        m_COD_PROD_CDST_pos = 108;
        m_COD_SERV_CORP_pos = 109;
        m_COD_EMP_ADQT_pos = 110;
        m_NUM_PDV_EXT_pos = 111;
        m_NUM_PDV_VAN_pos = 112;
        m_COD_DSPO_NFC_pos = 113;
        m_COD_PROD_PRCR_pos = 114;
        m_COD_GRU_CLAS_RAM_pos = 115;
        m_IND_TRAN_TKN_pos = 116;
        codigoOrigemAprovacaoPos = 117;
        posicaoDoNomePortadorDoCartao   = 118;
        posicaoDoCodigoBinCartao        = 119;
        posicaoDoNumeroFinalCartao      = 120;
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        posicaoIndicadorPresencaPortador    = 121;
        posicaoIndicadorTecnologiaTerminal  = 122;
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        // J2_2020 - WQ3 QRCODE - INICIO
        posicaoTipoFormatadorHeader = 123;
        posicaoIndicacaoQrcode = 124;
        posicaoCodigoParceiro = 125;
        // J2_2020 - WQ3 QRCODE - FIM
        posicaoCodigoRoteamentoTransacao = 126;
        posicaoRequestIdPix = 127; //AUT1-2168 - PIX
        codigoProcessoEmissorPos = 128;
        identificadorReferenciaBandeiraPos = 129;

        codigoParceiroAdquirentePos = 130;
        situacaoOfertaPos = 131;

        m_DAT_MOV_TRAN = 0;
        m_NUM_SEQ_UNC = 0;
        m_DTH_GMT = 0;
        m_DTH_INI_TRAN = 0;
        m_DAT_CTB_TRAN = 0;
        m_COD_MSG_ISO = 0;
        m_COD_PCM_ISO = 0;
        m_TIP_TRAN = 0;
        m_TIP_DTLH_TRAN = "";
        m_TIP_VD = "";
        m_COD_CTGR_TRAN = "";
        m_COD_CMPM_TRAN = 0;
        m_NUM_RD_ORG = 0;
        m_NUM_ESTB = 0;
        m_COD_TERM = "";
        m_NUM_STAN = 0;
        m_TIP_TCNL = "";
        m_TIP_TERM = "";
        m_COD_RAM_ATVD = 0;
        m_COD_POS_ENTR_MODO = "";
        m_COD_BNDR = 0;
        m_COD_EMSR = 0;
        m_NUM_EMSR = 0;
        dbm_chartodec( &m_NUM_ID_CAR, "0", 0 );
        m_NUM_CVC_2 = 0;
        m_COD_PAIS_CAR = "";
        m_NUM_CAR = "";
        m_DAT_VLD_CAR.date = 0;
        m_IND_TRK = "";
        m_IND_CPTR_CVC_2 = "";
        m_COD_TRK_CAR = "";
        m_COD_SERV = "";
        m_COD_SERV_SNHA = "";
        m_IND_ID_PREV = 0;
        dbm_chartodec( &m_VAL_TOTL_TRAN, "0.00", 2 );
        m_COD_MOED = "";
        m_NUM_CV = 0;
        m_NUM_RSMO_VD = 0;
        m_TIP_PLN_PGMN = 0;
        m_NUM_AUT = "";
        m_COD_MOT_AUT = "";
        m_NUM_MOT_RSPS = 0;
        m_COD_MOT_RSPS_EXT = "";
        m_COD_MOT_SW = "000"; 
        m_IND_STTU_TRAN = "";
        m_DTH_STTU_TRAN = 0;
        m_COD_PROD = "";
        m_DAT_RSMO_VD = 0;
        m_NOM_LOC_ESTB = "";
        m_IND_TERM_RLCD_CHIP = "";
        m_IND_DFZM = "";
        m_IND_ESTR = "";
        m_IND_CPTRDO = "";
        m_IND_AGND_TRAN = "";
        m_IND_IMPR_CPOM = "";
        m_IND_EMSR_MTC = "";
        m_IND_DA_RLCD_CHIP = "";
        m_IND_DA_RLCD_IATA = "";
        m_IND_TRAN_REFD = "";
        m_TIP_TRAN_ORGL = 0;
        m_DAT_EXPC_TRAN = 0;
        dbm_chartodec( &m_VAL_TRAN_DLR, "0.00", 2 );
        dbm_chartodec( &m_VAL_COT_DLR, "0.0000", 4 );
        m_COD_CTR = "";
        dbm_chartodec( &m_VAL_TX, "0.00", 2 );
        m_COD_REF_RESTANTE = "";
        m_COD_CNDC_CPTR_PAUZ = "";
        m_TIP_ENT_PAUZ = "";
        m_COD_OPER_CNFR = "";
        dbm_chartodec( &m_PRCN_TX_RISC, "0.00", 2 );
        dbm_chartodec( &m_VAL_TX_RISC, "0.00", 2 );
        m_COD_CNDC_CPTR = "";
        m_NOM_SITE_ACQR_ORGL = "";
        m_NOM_HOST_ACQR_ORGL = "";
        m_NOM_FE_ACQR_ORGL = "";
        m_NOM_SITE_ISSR = "";
        m_NOM_HOST_ISSR = "";
        m_NOM_FE_ISSR = "";
        m_NOM_SITE_ACQR_ATLZ = "";
        m_NOM_HOST_ACQR_ATLZ = "";
        m_NOM_FE_ACQR_ATLZ = "";
        m_TXT_DA_ADIC_EMSR = "";
        m_TIP_MODL_CPTR = "";
        m_DTH_TRAN_EMSR = 0;
        m_DAT_LQDC_EMSR = 0;
        m_COD_ISTT_ACQR = 0;
        m_COD_ISTT_FRWD = 0;
        m_COD_RSPS_DTLH_EMSR = 0;
        m_COD_RSTD_NUM_CVC_2 = "";
        m_COD_SERV_TRK_CAR = 0;
        m_COD_VLDC_EMSR = "";
        m_IND_AUT = "";
        m_IND_DA_RLCD_KMRC = "";
        m_IND_TRAN_SEM_ORGL = "";
        m_DAT_PAUZ = 0;
        m_NUM_SEQ_UNC_PAUZ = 0;
        m_COD_TRAN_CAD = 0;
        m_COD_AUT_EMSR = "";
        m_COD_NTWK_ID_ACQR_ATLZ = "";
        m_COD_NTWK_ID_ACQR_ORGL = "";
        m_COD_NTWK_ID_ROUT_ATLZ = "";
        m_COD_NTWK_ID_ROUT_ORGL = "";
        m_COD_NTWK_ID_ISSR_ATLZ = "";
        m_COD_NTWK_ID_ISSR_ORGL = "";
        m_COD_RAM_MCC = "";
        m_COD_CNDC_CPTR_EMSR = "";
        m_COD_PROD_CDST = 0;
        m_COD_SERV_CORP = 0;
        m_COD_EMP_ADQT = 0;
        m_NUM_PDV_EXT = "";
        m_NUM_PDV_VAN = "";
        m_COD_DSPO_NFC = "";
        m_COD_PROD_PRCR = 0;
        m_COD_GRU_CLAS_RAM = 0;
        m_IND_TRAN_TKN = " ";
        codigoOrigemAprovacao = " ";
        nomePortadorDoCartao    = std::string(40, ' ');
        codigoBinCartao         = std::string(8, ' ');
        numeroFinalCartao       = std::string(4, ' ');
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        indicadorPresencaPortador = " ";
        indicadorTecnologiaTerminal = " ";
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        // J2_2020 - WQ3 QRCODE - INICIO
        tipoFormatadorHeader = " ";
        indicacaoQrcode = "N";
        codigoParceiro = 0;
        // J2_2020 - WQ3 QRCODE - FIM
        codigoRoteamentoTransacao = "";
        //AUT1-2168 - PIX - INICIO
        requestIdPix = "";
        //AUT1-2168 - PIX - FIM
        codigoProcessoEmissor = 0;
        identificadorReferenciaBandeira = "";

        codigoParceiroAdquirente = 0;
        situacaoOferta = 0;
        
        m_DAT_RSMO_VD_ind_null = DBM_NULL_DATA;
        m_DAT_LQDC_EMSR_ind_null = DBM_NULL_DATA;
        m_DTH_TRAN_EMSR_ind_null = DBM_NULL_DATA;
        m_COD_SERV_TRK_CAR_ind_null = DBM_NULL_DATA;
        m_DAT_EXPC_TRAN_ind_null = DBM_NULL_DATA;
        m_DAT_VLD_CAR_ind_null = DBM_NULL_DATA;
        m_DTH_GMT_ind_null = DBM_NULL_DATA;
        m_VAL_COT_DLR_ind_null = DBM_NULL_DATA;
        m_NUM_CV_ind_null = DBM_NULL_DATA;
        m_VAL_TRAN_ind_null = DBM_NULL_DATA;
        m_VAL_TX_ind_null = DBM_NULL_DATA;
        m_VAL_TRAN_DLR_ind_null = DBM_NULL_DATA;
        m_NUM_ID_CAR_ind_null = DBM_NULL_DATA;
        m_TIP_PLN_PGMN_ind_null = DBM_NULL_DATA;  
        m_NUM_EMSR_ind_null = DBM_NULL_DATA;
        m_COD_BNDR_ind_null = DBM_NULL_DATA;
        m_VAL_TX_RISC_ind_null = DBM_NULL_DATA;
        m_TIP_TRAN_ORGL_ind_null = DBM_NULL_DATA;
        m_COD_CMPM_TRAN_ind_null = DBM_NULL_DATA;
        m_PRCN_TX_RISC_ind_null = DBM_NULL_DATA;
        m_NUM_CVC_2_ind_null = DBM_NULL_DATA;
        m_VAL_TOTL_TRAN_ind_null = DBM_NULL_DATA;
        m_NUM_RSMO_VD_ind_null = DBM_NULL_DATA;
        m_COD_SERV_TRK_CAR_ind_null = DBM_NULL_DATA;
        m_COD_EMSR_ind_null = DBM_NULL_DATA;
        m_NUM_RD_ORG_ind_null = DBM_NULL_DATA;
        m_DAT_PAUZ_ind_null = DBM_NULL_DATA;
        m_NUM_SEQ_UNC_PAUZ_ind_null = DBM_NULL_DATA;
        m_COD_TRAN_CAD_ind_null = DBM_NULL_DATA;
        m_COD_ISTT_ACQR_ind_null = DBM_NULL_DATA;
        m_COD_ISTT_FRWD_ind_null = DBM_NULL_DATA;
        m_IND_CPTRDO_ind_null = DBM_NULL_DATA;
        m_COD_RSPS_DTLH_EMSR_ind_null = DBM_NULL_DATA;
        m_IND_ID_PREV_ind_null = DBM_NULL_DATA;
        m_COD_PROD_CDST_ind_null = DBM_NULL_DATA;
        m_COD_SERV_CORP_ind_null = DBM_NULL_DATA;
        m_COD_PROD_PRCR_ind_null = DBM_NULL_DATA;
    }

    void TBSW0030::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_DTH_GMT_pos, &m_DTH_GMT, &m_DTH_GMT_ind_null );
        bind( m_DTH_INI_TRAN_pos, &m_DTH_INI_TRAN );
        bind( m_DAT_CTB_TRAN_pos, &m_DAT_CTB_TRAN );
        bind( m_COD_MSG_ISO_pos, m_COD_MSG_ISO );
        bind( m_COD_PCM_ISO_pos, m_COD_PCM_ISO );
        bind( m_TIP_TRAN_pos, m_TIP_TRAN );
        bind( m_TIP_DTLH_TRAN_pos, m_TIP_DTLH_TRAN );
        bind( m_TIP_VD_pos, m_TIP_VD );
        bind( m_TIP_PLN_PGMN_pos, m_TIP_PLN_PGMN, &m_TIP_PLN_PGMN_ind_null );
        bind( m_COD_CTGR_TRAN_pos, m_COD_CTGR_TRAN );
        bind( m_COD_CMPM_TRAN_pos, m_COD_CMPM_TRAN , &m_COD_CMPM_TRAN_ind_null);
        bind( m_NUM_RD_ORG_pos, m_NUM_RD_ORG );
        bind( m_NUM_ESTB_pos, m_NUM_ESTB );
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_NUM_STAN_pos, m_NUM_STAN );
        bind( m_TIP_TCNL_pos, m_TIP_TCNL );
        bind( m_TIP_TERM_pos, m_TIP_TERM );
        bind( m_COD_RAM_ATVD_pos, m_COD_RAM_ATVD );
        bind( m_COD_POS_ENTR_MODO_pos, m_COD_POS_ENTR_MODO );
        bind( m_COD_BNDR_pos, m_COD_BNDR , &m_COD_BNDR_ind_null );
        bind( m_COD_EMSR_pos, m_COD_EMSR);
        bind( m_NUM_EMSR_pos, m_NUM_EMSR , &m_NUM_EMSR_ind_null);
        bind( m_NUM_ID_CAR_pos, m_NUM_ID_CAR, &m_NUM_ID_CAR_ind_null);
        bind( m_COD_PAIS_CAR_pos, m_COD_PAIS_CAR );
        bind( m_NUM_CAR_pos, m_NUM_CAR );
        bind( m_DAT_VLD_CAR_pos, m_DAT_VLD_CAR , &m_DAT_VLD_CAR_ind_null);
        bind( m_IND_TRK_pos, m_IND_TRK );
        bind( m_IND_CPTR_CVC_2_pos, m_IND_CPTR_CVC_2 );
        bind( m_NUM_CVC_2_pos, m_NUM_CVC_2, &m_NUM_CVC_2_ind_null);
        bind( m_COD_TRK_CAR_pos, m_COD_TRK_CAR);
        bind( m_COD_SERV_pos, m_COD_SERV );
        bind( m_COD_SERV_SNHA_pos, m_COD_SERV_SNHA );
        bind( m_IND_ID_PREV_pos, m_IND_ID_PREV );
        bind( m_VAL_TRAN_pos, m_VAL_TRAN , &m_VAL_TRAN_ind_null);
        bind( m_VAL_TOTL_TRAN_pos, m_VAL_TOTL_TRAN , &m_VAL_TOTL_TRAN_ind_null);
        bind( m_COD_MOED_pos, m_COD_MOED);
        bind( m_NUM_CV_pos, m_NUM_CV, &m_NUM_CV_ind_null );
        bind( m_NUM_AUT_pos, m_NUM_AUT );
        bind( m_COD_MOT_AUT_pos, m_COD_MOT_AUT );
        bind( m_NUM_MOT_RSPS_pos, m_NUM_MOT_RSPS );
        bind( m_COD_MOT_RSPS_EXT_pos, m_COD_MOT_RSPS_EXT );
        bind( m_COD_MOT_SW_pos, m_COD_MOT_SW );
        bind( m_IND_STTU_TRAN_pos, m_IND_STTU_TRAN );
        bind( m_DTH_STTU_TRAN_pos, &m_DTH_STTU_TRAN );
        bind( m_COD_PROD_pos, m_COD_PROD );
        bind( m_NUM_RSMO_VD_pos, m_NUM_RSMO_VD ,&m_NUM_RSMO_VD_ind_null);
        bind( m_DAT_RSMO_VD_pos, &m_DAT_RSMO_VD, &m_DAT_RSMO_VD_ind_null );
        bind( m_NOM_LOC_ESTB_pos, m_NOM_LOC_ESTB );
        bind( m_IND_TERM_RLCD_CHIP_pos, m_IND_TERM_RLCD_CHIP );
        bind( m_IND_DFZM_pos, m_IND_DFZM );
        bind( m_IND_ESTR_pos, m_IND_ESTR );
        bind( m_IND_CPTRDO_pos, m_IND_CPTRDO );
        bind( m_IND_AGND_TRAN_pos, m_IND_AGND_TRAN );
        bind( m_IND_IMPR_CPOM_pos, m_IND_IMPR_CPOM );
        bind( m_IND_EMSR_MTC_pos, m_IND_EMSR_MTC );
        bind( m_IND_DA_RLCD_CHIP_pos, m_IND_DA_RLCD_CHIP );
        bind( m_IND_DA_RLCD_IATA_pos, m_IND_DA_RLCD_IATA );
        bind( m_IND_TRAN_REFD_pos, m_IND_TRAN_REFD );
        bind( m_TIP_TRAN_ORGL_pos, m_TIP_TRAN_ORGL, &m_TIP_TRAN_ORGL_ind_null );
        bind( m_DAT_EXPC_TRAN_pos, &m_DAT_EXPC_TRAN, &m_DAT_EXPC_TRAN_ind_null );
        bind( m_VAL_TRAN_DLR_pos, m_VAL_TRAN_DLR, &m_VAL_TRAN_DLR_ind_null );
        bind( m_VAL_COT_DLR_pos, m_VAL_COT_DLR, &m_VAL_COT_DLR_ind_null );
        bind( m_COD_CTR_pos, m_COD_CTR );
        bind( m_VAL_TX_pos, m_VAL_TX , &m_VAL_TX_ind_null);
        bind( m_COD_REF_RESTANTE_pos, m_COD_REF_RESTANTE );
        bind( m_COD_CNDC_CPTR_PAUZ_pos, m_COD_CNDC_CPTR_PAUZ );
        bind( m_TIP_ENT_PAUZ_pos, m_TIP_ENT_PAUZ );
        bind( m_COD_OPER_CNFR_pos, m_COD_OPER_CNFR );
        bind( m_PRCN_TX_RISC_pos, m_PRCN_TX_RISC , &m_PRCN_TX_RISC_ind_null);
        bind( m_VAL_TX_RISC_pos, m_VAL_TX_RISC , &m_VAL_TX_RISC_ind_null);
        bind( m_COD_CNDC_CPTR_pos, m_COD_CNDC_CPTR );
        bind( m_NOM_SITE_ACQR_ORGL_pos, m_NOM_SITE_ACQR_ORGL );
        bind( m_NOM_HOST_ACQR_ORGL_pos, m_NOM_HOST_ACQR_ORGL );
        bind( m_NOM_FE_ACQR_ORGL_pos, m_NOM_FE_ACQR_ORGL );
        bind( m_NOM_SITE_ISSR_pos, m_NOM_SITE_ISSR );
        bind( m_NOM_HOST_ISSR_pos, m_NOM_HOST_ISSR );
        bind( m_NOM_FE_ISSR_pos, m_NOM_FE_ISSR );
        bind( m_NOM_SITE_ACQR_ATLZ_pos, m_NOM_SITE_ACQR_ATLZ );
        bind( m_NOM_HOST_ACQR_ATLZ_pos, m_NOM_HOST_ACQR_ATLZ );
        bind( m_NOM_FE_ACQR_ATLZ_pos, m_NOM_FE_ACQR_ATLZ );
        bind( m_TXT_DA_ADIC_EMSR_pos, m_TXT_DA_ADIC_EMSR );
        bind( m_TIP_MODL_CPTR_pos, m_TIP_MODL_CPTR );
        bind( m_DTH_TRAN_EMSR_pos, &m_DTH_TRAN_EMSR, &m_DTH_TRAN_EMSR_ind_null );
        bind( m_DAT_LQDC_EMSR_pos, &m_DAT_LQDC_EMSR, &m_DAT_LQDC_EMSR_ind_null );
        bind( m_COD_ISTT_ACQR_pos, m_COD_ISTT_ACQR, &m_COD_ISTT_ACQR_ind_null );
        bind( m_COD_ISTT_FRWD_pos, m_COD_ISTT_FRWD, &m_COD_ISTT_FRWD_ind_null );
        bind( m_COD_RSPS_DTLH_EMSR_pos, m_COD_RSPS_DTLH_EMSR, &m_COD_RSPS_DTLH_EMSR_ind_null );
        bind( m_COD_RSTD_NUM_CVC_2_pos, m_COD_RSTD_NUM_CVC_2 );
        bind( m_COD_SERV_TRK_CAR_pos, m_COD_SERV_TRK_CAR, &m_COD_SERV_TRK_CAR_ind_null );
        bind( m_COD_VLDC_EMSR_pos, m_COD_VLDC_EMSR );
        bind( m_IND_AUT_pos, m_IND_AUT );
        bind( m_IND_DA_RLCD_KMRC_pos, m_IND_DA_RLCD_KMRC );
        bind( m_IND_TRAN_SEM_ORGL_pos, m_IND_TRAN_SEM_ORGL );
        bind( m_DAT_PAUZ_pos, &m_DAT_PAUZ, &m_DAT_PAUZ_ind_null);
        bind( m_NUM_SEQ_UNC_PAUZ_pos, m_NUM_SEQ_UNC_PAUZ, &m_NUM_SEQ_UNC_PAUZ_ind_null);
        bind( m_COD_TRAN_CAD_pos, m_COD_TRAN_CAD, &m_COD_TRAN_CAD_ind_null);
        bind( m_COD_AUT_EMSR_pos, m_COD_AUT_EMSR);
        bind( m_COD_NTWK_ID_ACQR_ATLZ_pos, m_COD_NTWK_ID_ACQR_ATLZ );
        bind( m_COD_NTWK_ID_ACQR_ORGL_pos, m_COD_NTWK_ID_ACQR_ORGL );
        bind( m_COD_NTWK_ID_ROUT_ATLZ_pos, m_COD_NTWK_ID_ROUT_ATLZ );
        bind( m_COD_NTWK_ID_ROUT_ORGL_pos, m_COD_NTWK_ID_ROUT_ORGL );
        bind( m_COD_NTWK_ID_ISSR_ATLZ_pos, m_COD_NTWK_ID_ISSR_ATLZ );
        bind( m_COD_NTWK_ID_ISSR_ORGL_pos, m_COD_NTWK_ID_ISSR_ORGL );
        bind( m_COD_RAM_MCC_pos, m_COD_RAM_MCC );
        bind( m_COD_CNDC_CPTR_EMSR_pos, m_COD_CNDC_CPTR_EMSR );
        bind( m_COD_CNDC_CPTR_PAUZ_pos, m_COD_CNDC_CPTR_PAUZ );
        bind( m_COD_PROD_CDST_pos, m_COD_PROD_CDST, &m_COD_PROD_CDST_ind_null );
        bind( m_COD_SERV_CORP_pos, m_COD_SERV_CORP, &m_COD_SERV_CORP_ind_null );
        bind( m_COD_EMP_ADQT_pos, m_COD_EMP_ADQT );
        bind( m_NUM_PDV_EXT_pos, m_NUM_PDV_EXT );
        bind( m_NUM_PDV_VAN_pos, m_NUM_PDV_VAN );
        bind( m_COD_DSPO_NFC_pos, m_COD_DSPO_NFC );
        bind( m_COD_PROD_PRCR_pos, m_COD_PROD_PRCR, &m_COD_PROD_PRCR_ind_null );
        bind( m_COD_GRU_CLAS_RAM_pos, m_COD_GRU_CLAS_RAM );
        bind( m_IND_TRAN_TKN_pos, m_IND_TRAN_TKN );
        bind( codigoOrigemAprovacaoPos, codigoOrigemAprovacao );
        bind(posicaoDoNomePortadorDoCartao, nomePortadorDoCartao);
        bind(posicaoDoCodigoBinCartao, codigoBinCartao);
        bind(posicaoDoNumeroFinalCartao, numeroFinalCartao);
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        bind( posicaoIndicadorPresencaPortador, indicadorPresencaPortador );
        bind( posicaoIndicadorTecnologiaTerminal, indicadorTecnologiaTerminal );
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        // J2_2020 - WQ3 QRCODE - INICIO
        bind( posicaoTipoFormatadorHeader, tipoFormatadorHeader );
        bind( posicaoIndicacaoQrcode, indicacaoQrcode );
        bind( posicaoCodigoParceiro, codigoParceiro );
        // J2_2020 - WQ3 QRCODE - FIM
        bind( posicaoCodigoRoteamentoTransacao, codigoRoteamentoTransacao );
        //AUT1-2168 - PIX - INICIO
        bind( posicaoRequestIdPix, requestIdPix);
        //AUT1-2168 - PIX - FIM
        bind( codigoProcessoEmissorPos, codigoProcessoEmissor );
        bind( identificadorReferenciaBandeiraPos, identificadorReferenciaBandeira );
        bind( codigoParceiroAdquirentePos, codigoParceiroAdquirente );
        bind( situacaoOfertaPos, situacaoOferta );
    }
    
    void TBSW0030::let_as_is( )
    {
        m_NUM_CV_ind_null = is_null(m_NUM_CV) ? DBM_NULL_DATA : 0;
        m_VAL_TX_ind_null = is_null(m_VAL_TX) ? DBM_NULL_DATA : 0;
        m_DTH_GMT_ind_null = is_null(&m_DTH_GMT) ? DBM_NULL_DATA : 0;
        m_COD_BNDR_ind_null = is_null(m_COD_BNDR) ? DBM_NULL_DATA : 0;
        m_TIP_PLN_PGMN_ind_null = is_null(m_TIP_PLN_PGMN) ? DBM_NULL_DATA : 0;
        m_COD_EMSR_ind_null = is_null(m_COD_EMSR) ? DBM_NULL_DATA : 0;
        m_NUM_EMSR_ind_null = is_null(m_NUM_EMSR) ? DBM_NULL_DATA : 0;
        m_VAL_TRAN_ind_null = is_null(m_VAL_TRAN) ? DBM_NULL_DATA : 0;
        m_NUM_CVC_2_ind_null = is_null(m_NUM_CVC_2) ? DBM_NULL_DATA : 0;
        m_NUM_ID_CAR_ind_null = is_null(m_NUM_ID_CAR) ? DBM_NULL_DATA : 0;
        m_NUM_RD_ORG_ind_null = is_null(m_NUM_RD_ORG) ? DBM_NULL_DATA : 0;
        m_DAT_RSMO_VD_ind_null = is_null(&m_DAT_RSMO_VD) ? DBM_NULL_DATA : 0;
        m_DAT_VLD_CAR_ind_null = is_null(&m_DAT_VLD_CAR) ? DBM_NULL_DATA : 0;
        m_NUM_RSMO_VD_ind_null = is_null(m_NUM_RSMO_VD) ? DBM_NULL_DATA : 0;
        m_VAL_COT_DLR_ind_null = is_null(m_VAL_COT_DLR) ? DBM_NULL_DATA : 0;
        m_VAL_TX_RISC_ind_null = is_null(m_VAL_TX_RISC) ? DBM_NULL_DATA : 0;
        m_PRCN_TX_RISC_ind_null = is_null(m_PRCN_TX_RISC) ? DBM_NULL_DATA : 0;
        m_VAL_TRAN_DLR_ind_null = is_null(m_VAL_TRAN_DLR) ? DBM_NULL_DATA : 0;
        m_COD_CMPM_TRAN_ind_null = is_null(m_COD_CMPM_TRAN) ? DBM_NULL_DATA : 0;
        m_DAT_EXPC_TRAN_ind_null = is_null(&m_DAT_EXPC_TRAN) ? DBM_NULL_DATA : 0;
        m_DAT_LQDC_EMSR_ind_null = is_null(&m_DAT_LQDC_EMSR) ? DBM_NULL_DATA : 0;
        m_DTH_TRAN_EMSR_ind_null = is_null(&m_DTH_TRAN_EMSR) ? DBM_NULL_DATA : 0;
        m_TIP_TRAN_ORGL_ind_null = is_null(m_TIP_TRAN_ORGL) ? DBM_NULL_DATA : 0;
        m_VAL_TOTL_TRAN_ind_null = is_null(m_VAL_TOTL_TRAN) ? DBM_NULL_DATA : 0;
        m_COD_SERV_TRK_CAR_ind_null = is_null(m_COD_SERV_TRK_CAR) ? DBM_NULL_DATA : 0;
        m_DAT_PAUZ_ind_null = is_null(&m_DAT_PAUZ) ? DBM_NULL_DATA : 0;
        m_NUM_SEQ_UNC_PAUZ_ind_null = is_null(m_NUM_SEQ_UNC_PAUZ) ? DBM_NULL_DATA : 0;
        m_COD_TRAN_CAD_ind_null = is_null(m_COD_TRAN_CAD) ? DBM_NULL_DATA : 0;
        m_COD_ISTT_ACQR_ind_null = is_null(m_COD_ISTT_ACQR) ? DBM_NULL_DATA : 0;
        m_COD_ISTT_FRWD_ind_null = is_null(m_COD_ISTT_FRWD) ? DBM_NULL_DATA : 0;
        m_IND_CPTRDO_ind_null = is_null(m_IND_CPTRDO) ? DBM_NULL_DATA : 0;
        m_COD_RSPS_DTLH_EMSR_ind_null = is_null(m_COD_RSPS_DTLH_EMSR) ? DBM_NULL_DATA : 0;
        m_IND_ID_PREV_ind_null = is_null( m_IND_ID_PREV ) ? DBM_NULL_DATA : 0;
        m_COD_PROD_CDST_ind_null = is_null( m_COD_PROD_CDST ) ? DBM_NULL_DATA : 0;
        m_COD_SERV_CORP_ind_null = is_null( m_COD_SERV_CORP ) ? DBM_NULL_DATA : 0;
        m_COD_PROD_PRCR_ind_null = is_null( m_COD_PROD_PRCR ) ? DBM_NULL_DATA : 0;
    }

    void TBSW0030::setWhereClause( const std::string& a_whereClause )
    {
        where_condition = a_whereClause;
    }

    void TBSW0030::setDualSelect( )
    {
        table_name = "(SELECT " + query_fields + " FROM TBSW0030 UNION SELECT " + query_fields + " FROM TBSW0030_DUAL)";
    }

    void TBSW0030::unsetDualSelect( )
    {
        table_name = "TBSW0030";
    }

    void TBSW0030::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0030::set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }
    void TBSW0030::set_DTH_GMT( dbm_datetime_t a_DTH_GMT )
    {
        m_DTH_GMT = a_DTH_GMT;
        m_DTH_GMT_ind_null = 0;
    }
    void TBSW0030::set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN )
    {
        m_DTH_INI_TRAN = a_DTH_INI_TRAN;
    }
    void TBSW0030::set_DAT_CTB_TRAN( dbm_datetime_t a_DAT_CTB_TRAN )
    {
        m_DAT_CTB_TRAN = a_DAT_CTB_TRAN;
    }
    void TBSW0030::set_COD_MSG_ISO( unsigned long a_COD_MSG_ISO )
    {
        m_COD_MSG_ISO = a_COD_MSG_ISO;
    }
    void TBSW0030::set_COD_PCM_ISO( unsigned long a_COD_PCM_ISO )
    {
        m_COD_PCM_ISO = a_COD_PCM_ISO;
    }
    void TBSW0030::set_TIP_TRAN( unsigned long a_TIP_TRAN )
    {
        m_TIP_TRAN = a_TIP_TRAN;
    }
    void TBSW0030::set_TIP_DTLH_TRAN( const std::string& a_TIP_DTLH_TRAN )
    {
        m_TIP_DTLH_TRAN = a_TIP_DTLH_TRAN;
    }
    void TBSW0030::set_TIP_VD( const std::string& a_TIP_VD )
    {
        m_TIP_VD = a_TIP_VD;
    }
    void TBSW0030::set_TIP_PLN_PGMN( unsigned long a_TIP_PLN_PGMN )
    {
        m_TIP_PLN_PGMN = a_TIP_PLN_PGMN;
        m_TIP_PLN_PGMN_ind_null = 0;
    }
    void TBSW0030::set_COD_CTGR_TRAN( const std::string& a_COD_CTGR_TRAN )
    {
        m_COD_CTGR_TRAN = a_COD_CTGR_TRAN;
    }
    void TBSW0030::set_COD_CMPM_TRAN( unsigned long a_COD_CMPM_TRAN )
    {
        m_COD_CMPM_TRAN = a_COD_CMPM_TRAN;
        m_COD_CMPM_TRAN_ind_null = 0;
    }
    void TBSW0030::set_NUM_RD_ORG( unsigned long a_NUM_RD_ORG )
    {
        m_NUM_RD_ORG = a_NUM_RD_ORG;
        m_NUM_RD_ORG_ind_null = 0;
    }
    void TBSW0030::set_NUM_ESTB( unsigned long a_NUM_ESTB )
    {
        m_NUM_ESTB = a_NUM_ESTB;
    }
    void TBSW0030::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void TBSW0030::set_NUM_STAN( unsigned long a_NUM_STAN )
    {
        m_NUM_STAN = a_NUM_STAN;
    }
    void TBSW0030::set_TIP_TCNL( const std::string& a_TIP_TCNL )
    {
        m_TIP_TCNL = a_TIP_TCNL;
    }
    void TBSW0030::set_TIP_TERM( const std::string& a_TIP_TERM )
    {
        m_TIP_TERM = a_TIP_TERM;
    }
    void TBSW0030::set_COD_RAM_ATVD( unsigned long a_COD_RAM_ATVD )
    {
        m_COD_RAM_ATVD = a_COD_RAM_ATVD;
    }
    void TBSW0030::set_COD_POS_ENTR_MODO( const std::string& a_COD_POS_ENTR_MODO )
    {
        m_COD_POS_ENTR_MODO = a_COD_POS_ENTR_MODO;
    }
    void TBSW0030::set_COD_BNDR( unsigned long a_COD_BNDR )
    {
        m_COD_BNDR = a_COD_BNDR;
        m_COD_BNDR_ind_null=0;
    }
    void TBSW0030::set_COD_EMSR( unsigned long a_COD_EMSR )
    {
        m_COD_EMSR = a_COD_EMSR;
        m_COD_EMSR_ind_null=0;
    }
    void TBSW0030::set_NUM_EMSR( unsigned long a_NUM_EMSR )
    {
        m_NUM_EMSR = a_NUM_EMSR;
        m_NUM_EMSR_ind_null=0;
    }
    void TBSW0030::set_NUM_ID_CAR( oasis_dec_t a_NUM_ID_CAR )
    {
        dbm_deccopy( &m_NUM_ID_CAR, &a_NUM_ID_CAR );
        m_NUM_ID_CAR_ind_null = 0;
    }
    void TBSW0030::set_COD_PAIS_CAR( const std::string& a_COD_PAIS_CAR )
    {
        m_COD_PAIS_CAR = a_COD_PAIS_CAR;
    }
    void TBSW0030::set_NUM_CAR( const std::string& a_NUM_CAR )
    {
        m_NUM_CAR = a_NUM_CAR;

        if(!m_NUM_CAR.empty() && m_NUM_CAR.size() >= 10)
        {
            this->setCodigoBinCartao(this->m_NUM_CAR);
            this->setNumeroFinalCartao(this->m_NUM_CAR);
        }

    }
    void TBSW0030::set_DAT_VLD_CAR( sw_date_t a_DAT_VLD_CAR )
    {
        m_DAT_VLD_CAR = a_DAT_VLD_CAR;
        m_DAT_VLD_CAR_ind_null = 0;
    }
    void TBSW0030::set_IND_TRK( const std::string& a_IND_TRK )
    {
        m_IND_TRK = a_IND_TRK;
    }
    void TBSW0030::set_IND_CPTR_CVC_2( const std::string& a_IND_CPTR_CVC_2 )
    {
        m_IND_CPTR_CVC_2 = a_IND_CPTR_CVC_2;
    }
    void TBSW0030::set_NUM_CVC_2( unsigned long a_NUM_CVC_2 )
    {
        m_NUM_CVC_2 = a_NUM_CVC_2;
        m_NUM_CVC_2_ind_null = 0;
    }
    void TBSW0030::set_COD_TRK_CAR( const std::string& a_COD_TRK_CAR )
    {
        m_COD_TRK_CAR = a_COD_TRK_CAR;
    }
    void TBSW0030::set_COD_SERV( const std::string& a_COD_SERV )
    {
        m_COD_SERV = a_COD_SERV;
    }
    void TBSW0030::set_COD_SERV_SNHA( const std::string& a_COD_SERV_SNHA )
    {
        m_COD_SERV_SNHA = a_COD_SERV_SNHA;
    }
    void TBSW0030::set_IND_ID_PREV( unsigned long a_IND_ID_PREV )
    {
        m_IND_ID_PREV = a_IND_ID_PREV;
    }
    void TBSW0030::set_VAL_TRAN( oasis_dec_t a_VAL_TRAN )
    {
        dbm_deccopy( &m_VAL_TRAN, &a_VAL_TRAN );
        m_VAL_TRAN_ind_null = 0;
    }
    void TBSW0030::set_VAL_TOTL_TRAN( oasis_dec_t a_VAL_TOTL_TRAN )
    {
        dbm_deccopy( &m_VAL_TOTL_TRAN, &a_VAL_TOTL_TRAN );
        m_VAL_TOTL_TRAN_ind_null = 0;
    }
    void TBSW0030::set_COD_MOED( const std::string& a_COD_MOED )
    {
        m_COD_MOED = a_COD_MOED;
    }
    void TBSW0030::set_NUM_CV( unsigned long a_NUM_CV )
    {
        m_NUM_CV = a_NUM_CV;
        m_NUM_CV_ind_null = 0;
    }
    void TBSW0030::set_NUM_AUT( const std::string& a_NUM_AUT )
    {
        m_NUM_AUT = a_NUM_AUT;
    }
    void TBSW0030::set_COD_MOT_AUT( const std::string& a_COD_MOT_AUT )
    {
        m_COD_MOT_AUT = a_COD_MOT_AUT;
    }
    void TBSW0030::set_NUM_MOT_RSPS( unsigned long a_NUM_MOT_RSPS )
    {
        m_NUM_MOT_RSPS = a_NUM_MOT_RSPS;
    }
    void TBSW0030::set_COD_MOT_RSPS_EXT( const std::string& a_COD_MOT_RSPS_EXT )
    {
        m_COD_MOT_RSPS_EXT = a_COD_MOT_RSPS_EXT;
    }
    void TBSW0030::set_COD_MOT_SW( const std::string& a_COD_MOT_SW )
    {
        m_COD_MOT_SW = a_COD_MOT_SW;
    }
    void TBSW0030::set_IND_STTU_TRAN( const std::string& a_IND_STTU_TRAN )
    {
        m_IND_STTU_TRAN = a_IND_STTU_TRAN;
    }
    void TBSW0030::set_DTH_STTU_TRAN( dbm_datetime_t a_DTH_STTU_TRAN )
    {
        m_DTH_STTU_TRAN = a_DTH_STTU_TRAN;
    }
    void TBSW0030::set_COD_PROD( const std::string& a_COD_PROD )
    {
        m_COD_PROD = a_COD_PROD;
    }
    void TBSW0030::set_NUM_RSMO_VD( unsigned long a_NUM_RSMO_VD )
    {
        m_NUM_RSMO_VD = a_NUM_RSMO_VD;
        m_NUM_RSMO_VD_ind_null=0;
    }
    void TBSW0030::set_DAT_RSMO_VD( dbm_datetime_t a_DAT_RSMO_VD )
    {
        m_DAT_RSMO_VD = a_DAT_RSMO_VD;
        m_DAT_RSMO_VD_ind_null = 0;
    }
    void TBSW0030::set_NOM_LOC_ESTB( const std::string& a_NOM_LOC_ESTB )
    {
        m_NOM_LOC_ESTB = a_NOM_LOC_ESTB;
    }
    void TBSW0030::set_IND_TERM_RLCD_CHIP( const std::string& a_IND_TERM_RLCD_CHIP )
    {
        m_IND_TERM_RLCD_CHIP = a_IND_TERM_RLCD_CHIP;
    }
    void TBSW0030::set_IND_DFZM( const std::string& a_IND_DFZM )
    {
        m_IND_DFZM = a_IND_DFZM;
    }
    void TBSW0030::set_IND_ESTR( const std::string& a_IND_ESTR )
    {
        m_IND_ESTR = a_IND_ESTR;
    }
    void TBSW0030::set_IND_CPTRDO( const std::string& a_IND_CPTRDO )
    {
        m_IND_CPTRDO = a_IND_CPTRDO;
        m_IND_CPTRDO_ind_null=0;
    }
    void TBSW0030::set_IND_AGND_TRAN( const std::string& a_IND_AGND_TRAN )
    {
        m_IND_AGND_TRAN = a_IND_AGND_TRAN;
    }
    void TBSW0030::set_IND_IMPR_CPOM( const std::string& a_IND_IMPR_CPOM )
    {
        m_IND_IMPR_CPOM = a_IND_IMPR_CPOM;
    }
    void TBSW0030::set_IND_EMSR_MTC( const std::string& a_IND_EMSR_MTC )
    {
        m_IND_EMSR_MTC = a_IND_EMSR_MTC;
    }
    void TBSW0030::set_IND_DA_RLCD_CHIP( const std::string& a_IND_DA_RLCD_CHIP )
    {
        m_IND_DA_RLCD_CHIP = a_IND_DA_RLCD_CHIP;
    }
    void TBSW0030::set_IND_DA_RLCD_IATA( const std::string& a_IND_DA_RLCD_IATA )
    {
        m_IND_DA_RLCD_IATA = a_IND_DA_RLCD_IATA;
    }
    void TBSW0030::set_IND_TRAN_REFD( const std::string& a_IND_TRAN_REFD )
    {
        m_IND_TRAN_REFD = a_IND_TRAN_REFD;
    }
    void TBSW0030::set_TIP_TRAN_ORGL( unsigned long a_TIP_TRAN_ORGL )
    {
        m_TIP_TRAN_ORGL = a_TIP_TRAN_ORGL;
        m_TIP_TRAN_ORGL_ind_null = 0;
    }
    void TBSW0030::set_DAT_EXPC_TRAN( dbm_datetime_t a_DAT_EXPC_TRAN )
    {
        m_DAT_EXPC_TRAN = a_DAT_EXPC_TRAN;
        m_DAT_EXPC_TRAN_ind_null = 0;
    }
    void TBSW0030::set_VAL_TRAN_DLR( oasis_dec_t a_VAL_TRAN_DLR )
    {
        dbm_deccopy( &m_VAL_TRAN_DLR, &a_VAL_TRAN_DLR );
        m_VAL_TRAN_DLR_ind_null = 0;
    }
    void TBSW0030::set_VAL_COT_DLR( oasis_dec_t a_VAL_COT_DLR )
    {
        dbm_deccopy( &m_VAL_COT_DLR, &a_VAL_COT_DLR );
        m_VAL_COT_DLR_ind_null = 0;
    }
    void TBSW0030::set_COD_CTR( const std::string& a_COD_CTR )
    {
        m_COD_CTR = a_COD_CTR;
    }
    void TBSW0030::set_VAL_TX( oasis_dec_t a_VAL_TX )
    {
        dbm_deccopy( &m_VAL_TX, &a_VAL_TX );
        m_VAL_TX_ind_null = 0;
    }
    void TBSW0030::set_COD_REF_RESTANTE( const std::string& a_COD_REF_RESTANTE )
    {
        m_COD_REF_RESTANTE = a_COD_REF_RESTANTE;
    }
    void TBSW0030::set_COD_CNDC_CPTR_PAUZ( const std::string& a_COD_CNDC_CPTR_PAUZ )
    {
        m_COD_CNDC_CPTR_PAUZ = a_COD_CNDC_CPTR_PAUZ;
    }
    void TBSW0030::set_TIP_ENT_PAUZ( const std::string& a_TIP_ENT_PAUZ )
    {
        m_TIP_ENT_PAUZ = a_TIP_ENT_PAUZ;
    }
    void TBSW0030::set_COD_OPER_CNFR( const std::string& a_COD_OPER_CNFR )
    {
        m_COD_OPER_CNFR = a_COD_OPER_CNFR;
    }
    void TBSW0030::set_PRCN_TX_RISC( oasis_dec_t a_PRCN_TX_RISC )
    {
        dbm_deccopy( &m_PRCN_TX_RISC, &a_PRCN_TX_RISC );
        m_PRCN_TX_RISC_ind_null=0;
    }
    void TBSW0030::set_VAL_TX_RISC( oasis_dec_t a_VAL_TX_RISC )
    {
        dbm_deccopy( &m_VAL_TX_RISC, &a_VAL_TX_RISC );
        m_VAL_TX_RISC_ind_null = 0;
    }
    void TBSW0030::set_COD_CNDC_CPTR( const std::string& a_COD_CNDC_CPTR )
    {
        m_COD_CNDC_CPTR = a_COD_CNDC_CPTR;
    }
    void TBSW0030::set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL )
    {
        m_NOM_SITE_ACQR_ORGL = a_NOM_SITE_ACQR_ORGL;
    }
    void TBSW0030::set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL )
    {
        m_NOM_HOST_ACQR_ORGL = a_NOM_HOST_ACQR_ORGL;
    }
    void TBSW0030::set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL )
    {
        m_NOM_FE_ACQR_ORGL = a_NOM_FE_ACQR_ORGL;
    }
    void TBSW0030::set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR )
    {
        m_NOM_SITE_ISSR = a_NOM_SITE_ISSR;
    }
    void TBSW0030::set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR )
    {
        m_NOM_HOST_ISSR = a_NOM_HOST_ISSR;
    }
    void TBSW0030::set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR )
    {
        m_NOM_FE_ISSR = a_NOM_FE_ISSR;
    }
    void TBSW0030::set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ )
    {
        m_NOM_SITE_ACQR_ATLZ = a_NOM_SITE_ACQR_ATLZ;
    }
    void TBSW0030::set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ )
    {
        m_NOM_HOST_ACQR_ATLZ = a_NOM_HOST_ACQR_ATLZ;
    }
    void TBSW0030::set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ )
    {
        m_NOM_FE_ACQR_ATLZ = a_NOM_FE_ACQR_ATLZ;
    }
    void TBSW0030::set_TXT_DA_ADIC_EMSR( const std::string& a_TXT_DA_ADIC_EMSR )
    {
        m_TXT_DA_ADIC_EMSR = a_TXT_DA_ADIC_EMSR;
    }
    void TBSW0030::set_TIP_MODL_CPTR( const std::string& a_TIP_MODL_CPTR )
    {
        m_TIP_MODL_CPTR = a_TIP_MODL_CPTR;
    }
    void TBSW0030::set_DTH_TRAN_EMSR( dbm_datetime_t a_DTH_TRAN_EMSR )
    {
        m_DTH_TRAN_EMSR = a_DTH_TRAN_EMSR;
        m_DTH_TRAN_EMSR_ind_null = 0;
    }
    void TBSW0030::set_DAT_LQDC_EMSR( dbm_datetime_t a_DAT_LQDC_EMSR )
    {
        m_DAT_LQDC_EMSR = a_DAT_LQDC_EMSR;
        m_DAT_LQDC_EMSR_ind_null = 0;
    }
    void TBSW0030::set_COD_ISTT_ACQR( unsigned long a_COD_ISTT_ACQR )
    {
        m_COD_ISTT_ACQR = a_COD_ISTT_ACQR;
        m_COD_ISTT_ACQR_ind_null = 0;
    }
    void TBSW0030::set_COD_ISTT_FRWD( unsigned long a_COD_ISTT_FRWD )
    {
        m_COD_ISTT_FRWD = a_COD_ISTT_FRWD;
        m_COD_ISTT_FRWD_ind_null = 0;
    }
    void TBSW0030::set_COD_RSPS_DTLH_EMSR( unsigned long a_COD_RSPS_DTLH_EMSR )
    {
        m_COD_RSPS_DTLH_EMSR = a_COD_RSPS_DTLH_EMSR;
        m_COD_RSPS_DTLH_EMSR_ind_null = 0;
    }
    void TBSW0030::set_COD_RSTD_NUM_CVC_2( const std::string& a_COD_RSTD_NUM_CVC_2 )
    {
        m_COD_RSTD_NUM_CVC_2 = a_COD_RSTD_NUM_CVC_2;
    }
    void TBSW0030::set_COD_SERV_TRK_CAR( unsigned long a_COD_SERV_TRK_CAR )
    {
        m_COD_SERV_TRK_CAR = a_COD_SERV_TRK_CAR;
        m_COD_SERV_TRK_CAR_ind_null = 0;
    }
    void TBSW0030::set_COD_VLDC_EMSR( const std::string& a_COD_VLDC_EMSR )
    {
        m_COD_VLDC_EMSR = a_COD_VLDC_EMSR;
    }
    void TBSW0030::set_IND_AUT( const std::string& a_IND_AUT )
    {
        m_IND_AUT = a_IND_AUT;
    }
    void TBSW0030::set_IND_DA_RLCD_KMRC( const std::string& a_IND_DA_RLCD_KMRC )
    {
        m_IND_DA_RLCD_KMRC = a_IND_DA_RLCD_KMRC;
    }
    void TBSW0030::set_IND_TRAN_SEM_ORGL( const std::string& a_IND_TRAN_SEM_ORGL )
    {
        m_IND_TRAN_SEM_ORGL = a_IND_TRAN_SEM_ORGL;
    }
    void TBSW0030::set_DAT_PAUZ( dbm_datetime_t a_DAT_PAUZ ) {
        m_DAT_PAUZ = a_DAT_PAUZ;
        m_DAT_PAUZ_ind_null = 0;
    }
    void TBSW0030::set_NUM_SEQ_UNC_PAUZ( unsigned long a_NUM_SEQ_UNC_PAUZ )
    {
        m_NUM_SEQ_UNC_PAUZ = a_NUM_SEQ_UNC_PAUZ;
        m_NUM_SEQ_UNC_PAUZ_ind_null = 0;
    }
    void TBSW0030::set_COD_TRAN_CAD( unsigned long a_COD_TRAN_CAD )
    {
        m_COD_TRAN_CAD = a_COD_TRAN_CAD;
        m_COD_TRAN_CAD_ind_null = 0;
    }
    void TBSW0030::set_COD_AUT_EMSR( const std::string& a_COD_AUT_EMSR )
    {
        m_COD_AUT_EMSR = a_COD_AUT_EMSR;
    }
    void TBSW0030::set_COD_NTWK_ID_ACQR_ATLZ( const std::string& a_COD_NTWK_ID_ACQR_ATLZ )
    {
        m_COD_NTWK_ID_ACQR_ATLZ = a_COD_NTWK_ID_ACQR_ATLZ;
    }
    void TBSW0030::set_COD_NTWK_ID_ACQR_ORGL( const std::string& a_NTWK_ID_ACQR_ORGL )
    {
        m_COD_NTWK_ID_ACQR_ORGL = a_NTWK_ID_ACQR_ORGL;
    }
    void TBSW0030::set_COD_NTWK_ID_ROUT_ATLZ( const std::string& a_COD_NTWK_ID_ROUT_ATLZ )
    {
        m_COD_NTWK_ID_ROUT_ATLZ = a_COD_NTWK_ID_ROUT_ATLZ;
    }
    void TBSW0030::set_COD_NTWK_ID_ROUT_ORGL( const std::string& a_NTWK_ID_ROUT_ORGL )
    {
        m_COD_NTWK_ID_ROUT_ORGL = a_NTWK_ID_ROUT_ORGL;
    }
    void TBSW0030::set_COD_NTWK_ID_ISSR_ATLZ( const std::string& a_COD_NTWK_ID_ISSR_ATLZ )
    {
        m_COD_NTWK_ID_ISSR_ATLZ = a_COD_NTWK_ID_ISSR_ATLZ;
    }
    void TBSW0030::set_COD_NTWK_ID_ISSR_ORGL( const std::string& a_NTWK_ID_ISSR_ORGL )
    {
        m_COD_NTWK_ID_ISSR_ORGL = a_NTWK_ID_ISSR_ORGL;
    }
    void TBSW0030::set_COD_RAM_MCC( const std::string& a_COD_RAM_MCC )
    {
        m_COD_RAM_MCC = a_COD_RAM_MCC;
    }
    void TBSW0030::set_COD_CNDC_CPTR_EMSR( const std::string& a_COD_CNDC_CPTR_EMSR )
    {
        m_COD_CNDC_CPTR_EMSR = a_COD_CNDC_CPTR_EMSR;
    }
    void TBSW0030::set_COD_PROD_CDST( unsigned long a_COD_PROD_CDST )
    {
        m_COD_PROD_CDST = a_COD_PROD_CDST;
        m_COD_PROD_CDST_ind_null = 0;
    }
    void TBSW0030::set_COD_SERV_CORP( unsigned long a_COD_SERV_CORP )
    {
        m_COD_SERV_CORP = a_COD_SERV_CORP;
        m_COD_SERV_CORP_ind_null = 0;
    }
    void TBSW0030::set_COD_EMP_ADQT( unsigned long a_COD_EMP_ADQT )
    {
        m_COD_EMP_ADQT = a_COD_EMP_ADQT;
    }
    void TBSW0030::set_NUM_PDV_EXT( const std::string& a_NUM_PDV_EXT )
    {
        m_NUM_PDV_EXT = a_NUM_PDV_EXT;
    }
    void TBSW0030::set_NUM_PDV_VAN( const std::string& a_NUM_PDV_VAN )
    {
        m_NUM_PDV_VAN = a_NUM_PDV_VAN;
    } 
    void TBSW0030::set_COD_DSPO_NFC( const std::string& a_COD_DSPO_NFC )
    {
        m_COD_DSPO_NFC = a_COD_DSPO_NFC;
    }
    void TBSW0030::set_COD_PROD_PRCR( unsigned long a_COD_PROD_PRCR )
    {
        m_COD_PROD_PRCR = a_COD_PROD_PRCR;
        m_COD_PROD_PRCR_ind_null = 0;
    }
    void TBSW0030::set_COD_GRU_CLAS_RAM( long a_COD_GRU_CLAS_RAM )
    {
        m_COD_GRU_CLAS_RAM = a_COD_GRU_CLAS_RAM;
    }

    void TBSW0030::set_IND_TRAN_TKN( const std::string& a_IND_TRAN_TKN )
    {
        m_IND_TRAN_TKN = a_IND_TRAN_TKN;
    }
    /// SetCodOrgAprv
    /// Grava o Codigo de origem da transacao do Emissor
    /// DRS ID29728 - DP-2017-0043734 Release  Elo Abril 2018 SW75
    /// Historico: 03-05-2018 Valor respondido autorizador Elo Full conforme descricao do MER.
    void TBSW0030::SetCodOrgAprv( const std::string& codigoOrigemAprovacaoParametro )
    {
        codigoOrigemAprovacao = codigoOrigemAprovacaoParametro;
    }


    unsigned long TBSW0030::get_DAT_MOV_TRAN() const
    {
        return m_DAT_MOV_TRAN;
    }
    unsigned long TBSW0030::get_NUM_SEQ_UNC( ) const
    {
        return m_NUM_SEQ_UNC;
    }
    dbm_datetime_t TBSW0030::get_DTH_GMT() const
    {
        return m_DTH_GMT;
    }
    dbm_datetime_t TBSW0030::get_DTH_INI_TRAN() const
    {
        return m_DTH_INI_TRAN;
    }
    dbm_datetime_t TBSW0030::get_DAT_CTB_TRAN() const
    {
        return m_DAT_CTB_TRAN;
    }
    unsigned long TBSW0030::get_COD_MSG_ISO() const
    {
        return m_COD_MSG_ISO;
    }
    unsigned long TBSW0030::get_COD_PCM_ISO() const
    {
        return m_COD_PCM_ISO;
    }
    unsigned long TBSW0030::get_TIP_TRAN() const
    {
        return m_TIP_TRAN;
    }
    const std::string& TBSW0030::get_TIP_DTLH_TRAN() const
    {
        return m_TIP_DTLH_TRAN;
    }
    const std::string& TBSW0030::get_TIP_VD() const
    {
        return m_TIP_VD;
    }
    unsigned long TBSW0030::get_TIP_PLN_PGMN() const
    {
        return m_TIP_PLN_PGMN;
    }
    const std::string& TBSW0030::get_COD_CTGR_TRAN() const
    {
        return m_COD_CTGR_TRAN;
    }
    unsigned long TBSW0030::get_COD_CMPM_TRAN() const
    {
        return m_COD_CMPM_TRAN;
    }
    unsigned long TBSW0030::get_NUM_RD_ORG() const
    {
        return m_NUM_RD_ORG;
    }
    unsigned long TBSW0030::get_NUM_ESTB() const
    {
        return m_NUM_ESTB;
    }
    const std::string& TBSW0030::get_COD_TERM() const
    {
        return m_COD_TERM;
    }
    unsigned long TBSW0030::get_NUM_STAN() const
    {
        return m_NUM_STAN;
    }
    const std::string& TBSW0030::get_TIP_TCNL() const
    {
        return m_TIP_TCNL;
    }
    const std::string& TBSW0030::get_TIP_TERM() const
    {
        return m_TIP_TERM;
    }
    unsigned long TBSW0030::get_COD_RAM_ATVD() const
    {
        return m_COD_RAM_ATVD;
    }
    const std::string& TBSW0030::get_COD_POS_ENTR_MODO() const
    {
        return m_COD_POS_ENTR_MODO;
    }
    unsigned long TBSW0030::get_COD_BNDR() const
    {
        return m_COD_BNDR;
    }
    unsigned long TBSW0030::get_COD_EMSR() const
    {
        return m_COD_EMSR;
    }
    unsigned long TBSW0030::get_NUM_EMSR() const
    {
        return m_NUM_EMSR;
    }
    oasis_dec_t TBSW0030::get_NUM_ID_CAR() const
    {
        return m_NUM_ID_CAR;
    }
    const std::string& TBSW0030::get_COD_PAIS_CAR() const
    {
        return m_COD_PAIS_CAR;
    }
    const std::string& TBSW0030::get_NUM_CAR() const
    {
        return m_NUM_CAR;
    }
    sw_date_t TBSW0030::get_DAT_VLD_CAR() const
    {
        return m_DAT_VLD_CAR;
    }
    const std::string& TBSW0030::get_IND_TRK() const
    {
        return m_IND_TRK;
    }
    const std::string& TBSW0030::get_IND_CPTR_CVC_2() const
    {
        return m_IND_CPTR_CVC_2;
    }
    unsigned long TBSW0030::get_NUM_CVC_2() const
    {
        return m_NUM_CVC_2;
    }
    const std::string& TBSW0030::get_COD_TRK_CAR() const
    {
        return m_COD_TRK_CAR;
    }
    const std::string& TBSW0030::get_COD_SERV() const
    {
        return m_COD_SERV;
    }
    const std::string& TBSW0030::get_COD_SERV_SNHA() const
    {
        return m_COD_SERV_SNHA;
    }
    unsigned long TBSW0030::get_IND_ID_PREV() const
    {
        return m_IND_ID_PREV;
    }
    oasis_dec_t TBSW0030::get_VAL_TRAN() const
    {
        return m_VAL_TRAN;
    }
    oasis_dec_t TBSW0030::get_VAL_TOTL_TRAN() const
    {
        return m_VAL_TOTL_TRAN;
    }
    const std::string& TBSW0030::get_COD_MOED() const
    {
        return m_COD_MOED;
    }
    unsigned long TBSW0030::get_NUM_CV() const
    {
        return m_NUM_CV;
    }
    const std::string& TBSW0030::get_NUM_AUT() const
    {
        return m_NUM_AUT;
    }
    const std::string& TBSW0030::get_COD_MOT_AUT() const
    {
        return m_COD_MOT_AUT;
    }
    unsigned long TBSW0030::get_NUM_MOT_RSPS() const
    {
        return m_NUM_MOT_RSPS;
    }
    const std::string& TBSW0030::get_COD_MOT_RSPS_EXT() const
    {
        return m_COD_MOT_RSPS_EXT;
    }
    const std::string& TBSW0030::get_COD_MOT_SW() const
    {
        return m_COD_MOT_SW;
    }
    const std::string& TBSW0030::get_IND_STTU_TRAN() const
    {
        return m_IND_STTU_TRAN;
    }
    dbm_datetime_t TBSW0030::get_DTH_STTU_TRAN() const
    {
        return m_DTH_STTU_TRAN;
    }
    const std::string& TBSW0030::get_COD_PROD() const
    {
        return m_COD_PROD;
    }
    unsigned long TBSW0030::get_NUM_RSMO_VD() const
    {
        return m_NUM_RSMO_VD;
    }
    dbm_datetime_t TBSW0030::get_DAT_RSMO_VD() const
    {
        return m_DAT_RSMO_VD;
    }
    const std::string& TBSW0030::get_NOM_LOC_ESTB() const
    {
        return m_NOM_LOC_ESTB;
    }
    const std::string& TBSW0030::get_IND_TERM_RLCD_CHIP() const
    {
        return m_IND_TERM_RLCD_CHIP;
    }
    const std::string& TBSW0030::get_IND_DFZM() const
    {
        return m_IND_DFZM;
    }
    const std::string& TBSW0030::get_IND_ESTR() const
    {
        return m_IND_ESTR;
    }
    const std::string& TBSW0030::get_IND_CPTRDO() const
    {
        return m_IND_CPTRDO;
    }
    const std::string& TBSW0030::get_IND_AGND_TRAN() const
    {
        return m_IND_AGND_TRAN;
    }
    const std::string& TBSW0030::get_IND_IMPR_CPOM() const
    {
        return m_IND_IMPR_CPOM;
    }
    const std::string& TBSW0030::get_IND_EMSR_MTC() const
    {
        return m_IND_EMSR_MTC;
    }
    const std::string& TBSW0030::get_IND_DA_RLCD_CHIP() const
    {
        return m_IND_DA_RLCD_CHIP;
    }
    const std::string& TBSW0030::get_IND_DA_RLCD_IATA() const
    {
        return m_IND_DA_RLCD_IATA;
    }
    const std::string& TBSW0030::get_IND_TRAN_REFD() const
    {
        return m_IND_TRAN_REFD;
    }
    unsigned long TBSW0030::get_TIP_TRAN_ORGL() const
    {
        return m_TIP_TRAN_ORGL;
    }
    dbm_datetime_t TBSW0030::get_DAT_EXPC_TRAN() const
    {
        return m_DAT_EXPC_TRAN;
    }
    oasis_dec_t TBSW0030::get_VAL_TRAN_DLR() const
    {
        return m_VAL_TRAN_DLR;
    }
    oasis_dec_t TBSW0030::get_VAL_COT_DLR() const
    {
        return m_VAL_COT_DLR;
    }
    const std::string& TBSW0030::get_COD_CTR() const
    {
        return m_COD_CTR;
    }
    oasis_dec_t TBSW0030::get_VAL_TX() const
    {
        return m_VAL_TX;
    }
    const std::string& TBSW0030::get_COD_REF_RESTANTE() const
    {
        return m_COD_REF_RESTANTE;
    }
    const std::string& TBSW0030::get_COD_CNDC_CPTR_PAUZ() const
    {
        return m_COD_CNDC_CPTR_PAUZ;
    }
    const std::string& TBSW0030::get_TIP_ENT_PAUZ() const
    {
        return m_TIP_ENT_PAUZ;
    }
    const std::string& TBSW0030::get_COD_OPER_CNFR() const
    {
        return m_COD_OPER_CNFR;
    }
    oasis_dec_t TBSW0030::get_PRCN_TX_RISC() const
    {
        return m_PRCN_TX_RISC;
    }
    oasis_dec_t TBSW0030::get_VAL_TX_RISC() const
    {
        return m_VAL_TX_RISC;
    }
    const std::string& TBSW0030::get_COD_CNDC_CPTR() const
    {
        return m_COD_CNDC_CPTR;
    }
    const std::string& TBSW0030::get_NOM_SITE_ACQR_ORGL() const
    {
        return m_NOM_SITE_ACQR_ORGL;
    }
    const std::string& TBSW0030::get_NOM_HOST_ACQR_ORGL() const
    {
        return m_NOM_HOST_ACQR_ORGL;
    }
    const std::string& TBSW0030::get_NOM_FE_ACQR_ORGL() const
    {
        return m_NOM_FE_ACQR_ORGL;
    }
    const std::string& TBSW0030::get_NOM_SITE_ISSR() const
    {
        return m_NOM_SITE_ISSR;
    }
    const std::string& TBSW0030::get_NOM_HOST_ISSR() const
    {
        return m_NOM_HOST_ISSR;
    }
    const std::string& TBSW0030::get_NOM_FE_ISSR() const
    {
        return m_NOM_FE_ISSR;
    }
    const std::string& TBSW0030::get_NOM_SITE_ACQR_ATLZ() const
    {
        return m_NOM_SITE_ACQR_ATLZ;
    }
    const std::string& TBSW0030::get_NOM_HOST_ACQR_ATLZ() const
    {
        return m_NOM_HOST_ACQR_ATLZ;
    }
    const std::string& TBSW0030::get_NOM_FE_ACQR_ATLZ() const
    {
        return m_NOM_FE_ACQR_ATLZ;
    }
    const std::string& TBSW0030::get_TXT_DA_ADIC_EMSR() const
    {
        return m_TXT_DA_ADIC_EMSR;
    }
    const std::string& TBSW0030::get_TIP_MODL_CPTR() const
    {
        return m_TIP_MODL_CPTR;
    }
    dbm_datetime_t TBSW0030::get_DTH_TRAN_EMSR() const
    {
        return m_DTH_TRAN_EMSR;
    }
    dbm_datetime_t TBSW0030::get_DAT_LQDC_EMSR() const
    {
        return m_DAT_LQDC_EMSR;
    }
    unsigned long TBSW0030::get_COD_ISTT_ACQR() const
    {
        return m_COD_ISTT_ACQR;
    }
    unsigned long TBSW0030::get_COD_ISTT_FRWD() const
    {
        return m_COD_ISTT_FRWD;
    }
    unsigned long TBSW0030::get_COD_RSPS_DTLH_EMSR() const
    {
        return m_COD_RSPS_DTLH_EMSR;
    }
    const std::string& TBSW0030::get_COD_RSTD_NUM_CVC_2() const
    {
        return m_COD_RSTD_NUM_CVC_2;
    }
    unsigned long TBSW0030::get_COD_SERV_TRK_CAR() const
    {
        return m_COD_SERV_TRK_CAR;
    }
    const std::string& TBSW0030::get_COD_VLDC_EMSR() const
    {
        return m_COD_VLDC_EMSR;
    }
    const std::string& TBSW0030::get_IND_AUT() const
    {
        return m_IND_AUT;
    }
    const std::string& TBSW0030::get_IND_DA_RLCD_KMRC() const
    {
        return m_IND_DA_RLCD_KMRC;
    }
    const std::string& TBSW0030::get_IND_TRAN_SEM_ORGL() const
    {
        return m_IND_TRAN_SEM_ORGL;
    }
    dbm_datetime_t TBSW0030::get_DAT_PAUZ() const
    {
        return m_DAT_PAUZ;
    }
    unsigned long TBSW0030::get_NUM_SEQ_UNC_PAUZ() const
    {
        return m_NUM_SEQ_UNC_PAUZ;
    }
    unsigned long TBSW0030::get_COD_TRAN_CAD() const
    {
        return m_COD_TRAN_CAD;
    }
    const std::string& TBSW0030::get_COD_AUT_EMSR() const
    {
        return m_COD_AUT_EMSR;
    }
    const std::string& TBSW0030::get_COD_NTWK_ID_ACQR_ATLZ() const
    {
        return m_COD_NTWK_ID_ACQR_ATLZ;
    }
    const std::string& TBSW0030::get_NTWK_ID_ACQR_ORGL() const
    {
        return m_COD_NTWK_ID_ACQR_ORGL;
    }
    const std::string& TBSW0030::get_COD_NTWK_ID_ROUT_ATLZ() const
    {
        return m_COD_NTWK_ID_ROUT_ATLZ;
    }
    const std::string& TBSW0030::get_NTWK_ID_ROUT_ORGL() const
    {
        return m_COD_NTWK_ID_ROUT_ORGL;
    }
    const std::string& TBSW0030::get_COD_NTWK_ID_ISSR_ATLZ() const
    {
        return m_COD_NTWK_ID_ISSR_ATLZ;
    }
    const std::string& TBSW0030::get_NTWK_ID_ISSR_ORGL() const
    {
        return m_COD_NTWK_ID_ISSR_ORGL;
    }
    const std::string& TBSW0030::get_COD_RAM_MCC() const
    {
        return m_COD_RAM_MCC;
    }
    const std::string& TBSW0030::get_COD_CNDC_CPTR_EMSR( ) const
    {
        return m_COD_CNDC_CPTR_EMSR;
    }
    unsigned long TBSW0030::get_COD_PROD_CDST( ) const
    {
        return m_COD_PROD_CDST;
    }
    unsigned long TBSW0030::get_COD_SERV_CORP( ) const
    {
        return m_COD_SERV_CORP;
    }
    unsigned long TBSW0030::get_COD_EMP_ADQT( ) const
    {
        return m_COD_EMP_ADQT;
    }
    const std::string& TBSW0030::get_NUM_PDV_EXT( ) const
    {
        return m_NUM_PDV_EXT;
    }
    const std::string& TBSW0030::get_NUM_PDV_VAN( ) const
    {
        return m_NUM_PDV_VAN;
    }
    const std::string& TBSW0030::get_COD_DSPO_NFC( ) const
    {
        return m_COD_DSPO_NFC;
    }
    unsigned long TBSW0030::get_COD_PROD_PRCR( ) const
    {
        return m_COD_PROD_PRCR;
    }
    long TBSW0030::get_COD_GRU_CLAS_RAM( ) const
    {
        return m_COD_GRU_CLAS_RAM;
    }
    const std::string& TBSW0030::get_IND_TRAN_TKN( ) const
    {
        return m_IND_TRAN_TKN;
    }

    const std::string& TBSW0030::GetCodOrgAprv( ) const
    {
        return codigoOrigemAprovacao;
    }

    /* PR-2018-0002340 - Rocket - Nome do Portador - INICIO */
    void TBSW0030::setNomePortadorDoCartao( const std::string& umNome)
    {
        this->nomePortadorDoCartao = umNome;
    }
    const std::string& TBSW0030::getNomePortadorDoCartao( ) const
    {
        return this->nomePortadorDoCartao;
    }
    void TBSW0030::setCodigoBinCartao( const std::string& numeroDoCartao)
    {
        this->codigoBinCartao = numeroDoCartao.substr(0,6);
    }
    const std::string& TBSW0030::getCodigoBinCartao( ) const
    {
        return this->codigoBinCartao;
    }
    void TBSW0030::setNumeroFinalCartao( const std::string& numeroDoCartao)
    {
        if(numeroDoCartao.size() <= 4)
        {
            this->numeroFinalCartao =  numeroDoCartao;
        }else
        {
            int fimNumeroCartao = numeroDoCartao.find_first_of(' ');
            if(fimNumeroCartao == std::string::npos)
                fimNumeroCartao = numeroDoCartao.size();

            fimNumeroCartao = fimNumeroCartao-4 < 0 ? 0 : fimNumeroCartao-4;
            this->numeroFinalCartao = numeroDoCartao.substr(fimNumeroCartao,4);
        }
    }
    const std::string& TBSW0030::getNumeroFinalCartao( ) const
    {
        return this->numeroFinalCartao;
    }
    /* PR-2018-0002340 - Rocket - Nome do Portador - FIM */

    // J4_2019 - Release Bandeiras Abril 2019 - INICIO
    /// SetIndicadorPresencaPortador
    /// Grava o indicador de presenca do portador
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 12/03/2019 - ET1 - Criacao da versao inicial
    /// indicadorPresencaPortadorParametro: valor a ser gravado
    void TBSW0030::SetIndicadorPresencaPortador( const std::string& indicadorPresencaPortadorParametro )
    {
        indicadorPresencaPortador = indicadorPresencaPortadorParametro;
    }

    /// SetIndicadorTecnologiaTerminal
    /// Grava o indicador de tecnologia do terminal
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 12/03/2019 - ET1 - Criacao da versao inicial
    /// indicadorTecnologiaTerminalParametro: valor a ser gravado
    void TBSW0030::SetIndicadorTecnologiaTerminal( const std::string& indicadorTecnologiaTerminalParametro )
    {
        indicadorTecnologiaTerminal = indicadorTecnologiaTerminalParametro;
    }

    /// GetIndicadorPresencaPortador
    /// Obtem o indicador de tecnologia do terminal
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 12/03/2019 - ET1 - Criacao da versao inicial
    const std::string& TBSW0030::GetIndicadorPresencaPortador( ) const
    {
        return indicadorPresencaPortador;
    }

    /// GetIndicadorTecnologiaTerminal
    /// Obtem o indicador de tecnologia do terminal
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 12/03/2019 - ET1 - Criacao da versao inicial
    const std::string& TBSW0030::GetIndicadorTecnologiaTerminal( ) const
    {
        return indicadorTecnologiaTerminal;
    }
    // J4_2019 - Release Bandeiras Abril 2019 - FIM

    // J2_2020 - WQ3 QRCODE - INICIO
    /// SetTipoFormatadorHeader
    /// Grava o tipo do formatador
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 08/02/2020 - ET1 - Criacao da versao inicial
    /// tipoFormatadorHeaderParametro: valor a ser gravado
    void TBSW0030::SetTipoFormatadorHeader( const std::string& tipoFormatadorHeaderParametro )
    {
        tipoFormatadorHeader = tipoFormatadorHeaderParametro;
    }

    /// SetIndicacaoQrcode
    /// Grava o indicador de QRCODE
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 08/02/2020 - ET1 - Criacao da versao inicial
    /// indicacaoQrcodeParametro: valor a ser gravado
    void TBSW0030::SetIndicacaoQrcode( const std::string& indicacaoQrcodeParametro )
    {
       indicacaoQrcode = indicacaoQrcodeParametro;
    }

    /// SetCodigoParceiro
    /// Grava o codigo parceiro da carteira digital
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 08/02/2020 - ET1 - Criacao da versao inicial
    /// codigoParceiroParametro: valor a ser gravado
    void TBSW0030::SetCodigoParceiro( long codigoParceiroParametro )
    {
       codigoParceiro = codigoParceiroParametro;
    }

    /// GetTipoFormatadorHeader
    /// Obtem o tipo do formatador
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 08/02/2020 - ET1 - Criacao da versao inicial
    const std::string& TBSW0030::GetTipoFormatadorHeader( ) const
    {
       return tipoFormatadorHeader;
    }

    /// GetIndicacaoQrcode
    /// Obtem o indicador de QRCODE
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 08/02/2020 - ET1 - Criacao da versao inicial
    const std::string& TBSW0030::GetIndicacaoQrcode( ) const
    {
       return indicacaoQrcode;
    }

    /// GetCodigoParceiro
    /// Obtem o codigo parceiro da carteira digital
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 08/02/2020 - ET1 - Criacao da versao inicial
    long TBSW0030::GetCodigoParceiro( ) const
    {
       return codigoParceiro;
    }
    // J2_2020 - WQ3 QRCODE - FIM

    /// SetCodigoRoteamentoTransacao
    /// Grava o codigo de roteamento da transacao
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 22/05/2020 - ET1 - Criacao da versao inicial
    /// codigoRoteamentoTransacaoParametro: valor a ser gravado
    void TBSW0030::SetCodigoRoteamentoTransacao( const std::string& codigoRoteamentoTransacaoParametro )
    {
       codigoRoteamentoTransacao = codigoRoteamentoTransacaoParametro;
    }

    /// GetCodigoRoteamentoTransacao
    /// Obtem o codigo de roteamento da transacao
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 22/05/2020 - ET1 - Criacao da versao inicial
    const std::string& TBSW0030::GetCodigoRoteamentoTransacao( ) const
    {
       return codigoRoteamentoTransacao;
    }

    // AUT1-2168 - PIX - INICIO
    /// SetRequestIdPix
    /// Grava o request id do PIX
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 13/10/2020 - ET1 - Criacao da versao inicial
    /// requestIdPixParametro: valor a ser gravado
    void TBSW0030::SetRequestIdPix( const std::string& requestIdPixParametro )
    {
        requestIdPix = requestIdPixParametro;
    }
    /// GetRequestIdPix
    /// Obtem o Request Id PIX
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 13/10/2020 - ET1 - Criacao da versao inicial
    const std::string& TBSW0030::GetRequestIdPix( ) const
    {
       return requestIdPix;
    }
    // AUT1-2168 - PIX - FIM

    // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
    void TBSW0030::SetCodigoProcessoEmissor( int codigoProcessoEmissorParam )
    {
        codigoProcessoEmissor = codigoProcessoEmissorParam;
    }
    int TBSW0030::GetCodigoProcessoEmissor( ) const
    {
        return codigoProcessoEmissor;
    }
    // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM

    //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - INICIO
    void TBSW0030::SetIdentificadorReferenciaBandeira( const std::string& idRefBandeira )
    {
        identificadorReferenciaBandeira = idRefBandeira;
    }
    const std::string& TBSW0030::GetIdentificadorReferenciaBandeira( ) const
    {
        return identificadorReferenciaBandeira;
    }
    //AUT1-3543 - Release Bandeira Abril/21 - ELO - ID da Transacao - FIM

    void TBSW0030::SetCodigoParceiroAdquirente( long value)
    {
        codigoParceiroAdquirente = value;
    }
    long TBSW0030::GetCodigoParceiroAdquirente() const
    {
        return codigoParceiroAdquirente;
    }

    void TBSW0030::SetSituacaoOferta( unsigned long sitOferta )
    {
        situacaoOferta = sitOferta;
    }

    unsigned long TBSW0030::GetSituacaoOferta() const
    {
        return situacaoOferta;
    }

    // Teste de conteudo do registro
    void TBSW0030::showxxx( const char *name, unsigned long campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%ld]", name, campo );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0030::showxxx( const char *name, int campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%d]", name, campo );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0030::showxxx( const char *name, dbm_datetime_t campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%ld]", name, campo );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0030::showxxx( const char *name, const std::string& campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%s]", name, campo.c_str( ) );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0030::showxxx( const char *name, oasis_dec_t campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            char buf_aux[1000] = {0};
            dbm_dectochar( &campo, buf_aux);
            sprintf(buf, " - %s : [%s]", name, buf_aux );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0030::showxxx( const char *name, sw_date_t campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%ld]", name, campo.date );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    
    void TBSW0030::show(int nvl)
    {
        char buf[1000];
        sprintf( buf, " --[%s]----------------------------", table_name.c_str() );
        m_log->write( logger::LEVEL_DEBUG, buf );

        //NOT NULL CAMPOS
        showxxx( "DAT_MOV_TRAN",  m_DAT_MOV_TRAN, false);
        showxxx( "NUM_SEQ_UNC",  m_NUM_SEQ_UNC, false);
        showxxx( "TIP_TRAN",  m_TIP_TRAN, false);
        showxxx( "NUM_MOT_RSPS",  m_NUM_MOT_RSPS, false);
        showxxx( "TIP_TCNL",  m_TIP_TCNL, false);
        showxxx( "NUM_ESTB",  m_NUM_ESTB, false);
        showxxx( "COD_TERM",  m_COD_TERM, false);
        showxxx( "TIP_TERM",  m_TIP_TERM, false);
        showxxx( "NUM_RD_ORG",  m_NUM_RD_ORG, false);
        showxxx( "COD_RAM_ATVD",  m_COD_RAM_ATVD, false);
        showxxx( "COD_CTGR_TRAN",  m_COD_CTGR_TRAN, false);
        showxxx( "COD_CNDC_CPTR",  m_COD_CNDC_CPTR, false);
        showxxx( "DAT_CTB_TRAN",  m_DAT_CTB_TRAN, false);
        showxxx( "IND_TRAN_REFD",  m_IND_TRAN_REFD, false);
        showxxx( "IND_TRK",  m_IND_TRK, false);
        showxxx( "COD_MOT_SW",  m_COD_MOT_SW, false);
        showxxx( "IND_CPTR_CVC_2",  m_IND_CPTR_CVC_2, false);
        showxxx( "IND_TERM_RLCD_CHIP",  m_IND_TERM_RLCD_CHIP, false);
        showxxx( "NOM_LOC_ESTB",  m_NOM_LOC_ESTB, false);
        showxxx( "COD_MSG_ISO",  m_COD_MSG_ISO, false);
        showxxx( "COD_PCM_ISO",  m_COD_PCM_ISO, false);
        showxxx( "IND_DFZM",  m_IND_DFZM, false);
        showxxx( "IND_ESTR",  m_IND_ESTR, false);
        showxxx( "IND_CPTRDO",  m_IND_CPTRDO, false);
        showxxx( "IND_AGND_TRAN",  m_IND_AGND_TRAN, false);
        showxxx( "IND_IMPR_CPOM",  m_IND_IMPR_CPOM, false);
        showxxx( "DTH_INI_TRAN",  m_DTH_INI_TRAN, false);
        showxxx( "DTH_STTU_TRAN",  m_DTH_STTU_TRAN, false);
        showxxx( "NUM_STAN",  m_NUM_STAN, false);
        showxxx( "IND_EMSR_MTC",  m_IND_EMSR_MTC, false);
        showxxx( "IND_DA_RLCD_CHIP",  m_IND_DA_RLCD_CHIP, false);
        showxxx( "TIP_DTLH_TRAN",  m_TIP_DTLH_TRAN, false);
        showxxx( "IND_DA_RLCD_IATA",  m_IND_DA_RLCD_IATA, false);
        showxxx( "IND_STTU_TRAN",  m_IND_STTU_TRAN, false);
        showxxx( "NOM_SITE_ACQR_ORGL",  m_NOM_SITE_ACQR_ORGL, false);
        showxxx( "NOM_HOST_ACQR_ORGL",  m_NOM_HOST_ACQR_ORGL, false);
        showxxx( "NOM_FE_ACQR_ORGL",  m_NOM_FE_ACQR_ORGL, false);
        showxxx( "COD_EMP_ADQT",  m_COD_EMP_ADQT, false);
        showxxx( "COD_GRU_CLAS_RAM",  m_COD_GRU_CLAS_RAM, false);
        showxxx( "NOM_PORT_CAR",  nomePortadorDoCartao, false);
        
        //NULL CAMPOS
        showxxx( "COD_POS_ENTR_MODO",  m_COD_POS_ENTR_MODO, m_COD_POS_ENTR_MODO.empty( ) );
        showxxx( "COD_EMSR",  m_COD_EMSR, m_COD_EMSR_ind_null == DBM_NULL_DATA );
        showxxx( "TIP_VD",  m_TIP_VD, m_TIP_VD.empty( ) );
        showxxx( "VAL_TRAN",  m_VAL_TRAN, m_VAL_TRAN_ind_null == DBM_NULL_DATA );
        showxxx( "NUM_CAR",  m_NUM_CAR, m_NUM_CAR.empty( ) );
        showxxx( "COD_MOT_RSPS_EXT",  m_COD_MOT_RSPS_EXT, m_COD_MOT_RSPS_EXT.empty( ) );
        showxxx( "NUM_AUT",  m_NUM_AUT, m_NUM_AUT.empty( ) );
        showxxx( "VAL_TX",  m_VAL_TX, m_VAL_TX_ind_null == DBM_NULL_DATA );
        showxxx( "VAL_COT_DLR",  m_VAL_COT_DLR, m_VAL_COT_DLR_ind_null == DBM_NULL_DATA );
        showxxx( "DAT_VLD_CAR",  m_DAT_VLD_CAR, m_DAT_VLD_CAR_ind_null == DBM_NULL_DATA );
        showxxx( "COD_TRK_CAR",  m_COD_TRK_CAR, m_COD_TRK_CAR.empty( ) );
        showxxx( "COD_MOED",  m_COD_MOED, m_COD_MOED.empty( ) );
        showxxx( "NUM_CV",  m_NUM_CV, m_NUM_CV_ind_null == DBM_NULL_DATA );
        showxxx( "VAL_TRAN_DLR",  m_VAL_TRAN_DLR, m_VAL_TRAN_DLR_ind_null == DBM_NULL_DATA );
        showxxx( "NUM_ID_CAR",  m_NUM_ID_CAR, m_NUM_ID_CAR_ind_null == DBM_NULL_DATA );
        showxxx( "COD_PAIS_CAR",  m_COD_PAIS_CAR, m_COD_PAIS_CAR.empty( ) );
        showxxx( "IND_ID_PREV",  m_IND_ID_PREV, m_IND_ID_PREV_ind_null == DBM_NULL_DATA );
        showxxx( "COD_PROD",  m_COD_PROD, m_COD_PROD.empty( ) );
        showxxx( "COD_CTR",  m_COD_CTR, m_COD_CTR.empty( ) );
        showxxx( "NUM_EMSR",  m_NUM_EMSR, m_NUM_EMSR_ind_null == DBM_NULL_DATA );
        showxxx( "COD_BNDR",  m_COD_BNDR, m_COD_BNDR_ind_null == DBM_NULL_DATA );
        showxxx( "DAT_RSMO_VD",  m_DAT_RSMO_VD, m_DAT_RSMO_VD_ind_null == DBM_NULL_DATA );
        showxxx( "COD_REF_RESTANTE",  m_COD_REF_RESTANTE, m_COD_REF_RESTANTE.empty( ) );
        showxxx( "COD_SERV",  m_COD_SERV, m_COD_SERV.empty( ) );
        showxxx( "COD_SERV_SNHA",  m_COD_SERV_SNHA, m_COD_SERV_SNHA.empty( ) );
        showxxx( "VAL_TX_RISC",  m_VAL_TX_RISC, m_VAL_TX_RISC_ind_null == DBM_NULL_DATA );
        showxxx( "TIP_TRAN_ORGL",  m_TIP_TRAN_ORGL, m_TIP_TRAN_ORGL_ind_null == DBM_NULL_DATA );
        showxxx( "TIP_PLN_PGMN",  m_TIP_PLN_PGMN, m_TIP_PLN_PGMN_ind_null == DBM_NULL_DATA );
        showxxx( "DAT_EXPC_TRAN",  m_DAT_EXPC_TRAN, m_DAT_EXPC_TRAN_ind_null == DBM_NULL_DATA );
        showxxx( "COD_CMPM_TRAN",  m_COD_CMPM_TRAN, m_COD_CMPM_TRAN_ind_null == DBM_NULL_DATA );
        showxxx( "PRCN_TX_RISC",  m_PRCN_TX_RISC, m_PRCN_TX_RISC_ind_null == DBM_NULL_DATA );
        showxxx( "COD_CNDC_CPTR_PAUZ",  m_COD_CNDC_CPTR_PAUZ, m_COD_CNDC_CPTR_PAUZ.empty( ) );
        showxxx( "TIP_ENT_PAUZ",  m_TIP_ENT_PAUZ, m_TIP_ENT_PAUZ.empty( ) );
        showxxx( "COD_OPER_CNFR",  m_COD_OPER_CNFR, m_COD_OPER_CNFR.empty( ) );
        showxxx( "DTH_GMT",  m_DTH_GMT, m_DTH_GMT_ind_null == DBM_NULL_DATA );
        showxxx( "COD_MOT_AUT",  m_COD_MOT_AUT, m_COD_MOT_AUT.empty( ) );
        showxxx( "NUM_CVC_2",  m_NUM_CVC_2, m_NUM_CVC_2_ind_null == DBM_NULL_DATA );
        showxxx( "VAL_TOTL_TRAN",  m_VAL_TOTL_TRAN, m_VAL_TOTL_TRAN_ind_null == DBM_NULL_DATA );
        showxxx( "NUM_RSMO_VD",  m_NUM_RSMO_VD, m_NUM_RSMO_VD_ind_null == DBM_NULL_DATA );
        showxxx( "NOM_SITE_ISSR",  m_NOM_SITE_ISSR, m_NOM_SITE_ISSR.empty( ) );
        showxxx( "NOM_HOST_ISSR",  m_NOM_HOST_ISSR, m_NOM_HOST_ISSR.empty( ) );
        showxxx( "NOM_FE_ISSR",  m_NOM_FE_ISSR, m_NOM_FE_ISSR.empty( ) );
        showxxx( "NOM_SITE_ACQR_ATLZ",  m_NOM_SITE_ACQR_ATLZ, m_NOM_SITE_ACQR_ATLZ.empty( ) );
        showxxx( "NOM_HOST_ACQR_ATLZ",  m_NOM_HOST_ACQR_ATLZ, m_NOM_HOST_ACQR_ATLZ.empty( ) );
        showxxx( "NOM_FE_ACQR_ATLZ",  m_NOM_FE_ACQR_ATLZ, m_NOM_FE_ACQR_ATLZ.empty( ) );
        showxxx( "COD_ISTT_ACQR",  m_COD_ISTT_ACQR, m_COD_ISTT_ACQR_ind_null == DBM_NULL_DATA );
        showxxx( "COD_ISTT_FRWD",  m_COD_ISTT_FRWD, m_COD_ISTT_FRWD_ind_null == DBM_NULL_DATA );
        showxxx( "COD_RSPS_DTLH_EMSR",  m_COD_RSPS_DTLH_EMSR, m_COD_RSPS_DTLH_EMSR_ind_null == DBM_NULL_DATA );
        showxxx( "COD_RSTD_NUM_CVC_2",  m_COD_RSTD_NUM_CVC_2, m_COD_RSTD_NUM_CVC_2.empty( ) );
        showxxx( "COD_SERV_TRK_CAR",  m_COD_SERV_TRK_CAR, m_COD_SERV_TRK_CAR_ind_null == DBM_NULL_DATA );
        showxxx( "COD_VLDC_EMSR",  m_COD_VLDC_EMSR, m_COD_VLDC_EMSR.empty( ) );
        showxxx( "IND_AUT",  m_IND_AUT, m_IND_AUT.empty( ) );
        showxxx( "IND_DA_RLCD_KMRC",  m_IND_DA_RLCD_KMRC, m_IND_DA_RLCD_KMRC.empty( ) );
        showxxx( "TXT_DA_ADIC_EMSR",  m_TXT_DA_ADIC_EMSR, m_TXT_DA_ADIC_EMSR.empty( ) );
        showxxx( "TIP_MODL_CPTR",  m_TIP_MODL_CPTR, m_TIP_MODL_CPTR.empty( ) );
        showxxx( "DTH_TRAN_EMSR",  m_DTH_TRAN_EMSR, m_DTH_TRAN_EMSR_ind_null == DBM_NULL_DATA );
        showxxx( "DAT_LQDC_EMSR",  m_DAT_LQDC_EMSR, m_DAT_LQDC_EMSR_ind_null == DBM_NULL_DATA );
        showxxx( "IND_TRAN_SEM_ORGL",  m_IND_TRAN_SEM_ORGL, m_IND_TRAN_SEM_ORGL.empty( ) );
        showxxx( "DAT_PAUZ",  m_DAT_PAUZ, m_DAT_PAUZ_ind_null == DBM_NULL_DATA );
        showxxx( "NUM_SEQ_UNC_PAUZ",  m_NUM_SEQ_UNC_PAUZ, m_NUM_SEQ_UNC_PAUZ_ind_null == DBM_NULL_DATA );
        showxxx( "COD_TRAN_CAD",  m_COD_TRAN_CAD, m_COD_TRAN_CAD_ind_null == DBM_NULL_DATA );
        showxxx( "COD_AUT_EMSR",  m_COD_AUT_EMSR, m_COD_AUT_EMSR.empty( ) );
        showxxx( "COD_NTWK_ID_ACQR_ATLZ",  m_COD_NTWK_ID_ACQR_ATLZ, m_COD_NTWK_ID_ACQR_ATLZ.empty( ) );
        showxxx( "COD_NTWK_ID_ACQR_ORGL",  m_COD_NTWK_ID_ACQR_ORGL, m_COD_NTWK_ID_ACQR_ORGL.empty( ) );
        showxxx( "COD_NTWK_ID_ROUT_ATLZ",  m_COD_NTWK_ID_ROUT_ATLZ, m_COD_NTWK_ID_ROUT_ATLZ.empty( ) );
        showxxx( "COD_NTWK_ID_ROUT_ORGL",  m_COD_NTWK_ID_ROUT_ORGL, m_COD_NTWK_ID_ROUT_ORGL.empty( ) );
        showxxx( "COD_NTWK_ID_ISSR_ATLZ",  m_COD_NTWK_ID_ISSR_ATLZ, m_COD_NTWK_ID_ISSR_ATLZ.empty( ) );
        showxxx( "COD_NTWK_ID_ISSR_ORGL",  m_COD_NTWK_ID_ISSR_ORGL, m_COD_NTWK_ID_ISSR_ORGL.empty( ) );
        showxxx( "COD_CNDC_CPTR_EMSR",  m_COD_CNDC_CPTR_EMSR, m_COD_CNDC_CPTR_EMSR.empty( ) );
        showxxx( "COD_RAM_MCC",  m_COD_RAM_MCC, m_COD_RAM_MCC.empty( )  );
        showxxx( "COD_PROD_CDST",  m_COD_PROD_CDST, m_COD_PROD_CDST_ind_null == DBM_NULL_DATA );
        showxxx( "COD_SERV_CORP",  m_COD_SERV_CORP, m_COD_SERV_CORP_ind_null == DBM_NULL_DATA );
        showxxx( "NUM_PDV_EXT",  m_NUM_PDV_EXT, m_NUM_PDV_EXT.empty( ) );
        showxxx( "NUM_PDV_VAN",  m_NUM_PDV_VAN, m_NUM_PDV_VAN.empty( ) );
        showxxx( "COD_DSPO_NFC",  m_COD_DSPO_NFC, m_COD_DSPO_NFC.empty( ) );
        showxxx( "COD_PROD_PRCR",  m_COD_PROD_PRCR, m_COD_PROD_PRCR_ind_null == DBM_NULL_DATA );
        showxxx( "IND_TRAN_TKN",  m_IND_TRAN_TKN, m_IND_TRAN_TKN.empty( ) );
        showxxx( "COD_ORG_APRV",  codigoOrigemAprovacao, codigoOrigemAprovacao.empty( ) );
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        showxxx( "COD_PORT_PRES_VLDC_BNDR",  indicadorPresencaPortador, indicadorPresencaPortador.empty( ) );
        showxxx( "COD_CPCD_TERM_VLDC_BNDR",  indicadorTecnologiaTerminal, indicadorTecnologiaTerminal.empty( ) );
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        // J2_2020 - WQ3 QRCODE - INICIO
        showxxx( "COD_FMTR_HEDR",  tipoFormatadorHeader, tipoFormatadorHeader.empty( ) );
        showxxx( "IND_QRCODE",  indicacaoQrcode, indicacaoQrcode.empty( ) );
        showxxx( "COD_PRCR",  codigoParceiro, false);
        // J2_2020 - WQ3 QRCODE - FIM
        showxxx( "COD_ROTM_TRAN",  codigoRoteamentoTransacao, codigoRoteamentoTransacao.empty( ));
        //AUT1-2168 - PIX - INICIO
        showxxx( "ID_RQSC_PIX", requestIdPix, requestIdPix.empty() );
        //AUT1-2168 - PIX - FIM
        // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
        showxxx( "COD_PCM_EMS", codigoProcessoEmissor, false );
        // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM
        showxxx( "ID_REF_BNDR", identificadorReferenciaBandeira, identificadorReferenciaBandeira.empty( ) );
        showxxx( "COD_PRCR_ADQT",  codigoParceiroAdquirente, false);
        showxxx( "COD_SIT_OFRT",  situacaoOferta, false);
        sprintf( buf, " ------------------------------------------", table_name.c_str() );
        m_log->write( logger::LEVEL_DEBUG, buf );

    }

} //namespace dbaccess_common

