#include "TBSW0156.hpp"

namespace dbaccess_common
{
	void TBSW0156::init()
	{
		query_fields = "COD_TERM, NUM_STAN, DTH_ESTT, COD_STTU_TERM, QTD_MSG_RCBD, QTD_MSG_ENVD, QTD_TRAN, QTD_NOVA_DSGM, QTD_ERR_COM, QTD_TMOT_TRAN, QTD_TMOT_RVRS, QTD_RTRM, QTD_ERR_RCBM_MSG, QTD_SNRM_RCBD, QTD_SNRM_ENVD, QTD_RNR_RCBD, QTD_RNR_ENVD, QTD_TST_RCBD, QTD_TST_ENVD, QTD_DM_RCBD, QTD_DM_ENVD, QTD_UAS_RCBD, QTD_UAS_ENVD, QTD_FRME_RCBD, QTD_FRME_ENVD, CONT_TMPO_RSPS, LIM_TMPO_RSPS_1, LIM_TMPO_RSPS_2, LIM_TMPO_RSPS_3, LIM_TMPO_RSPS_4, CONT_TMPO_RSPS_1, CONT_TMPO_RSPS_2, CONT_TMPO_RSPS_3, CONT_TMPO_RSPS_4, QTD_MIN_ATVD, QTD_MIN_INTD, QTD_REINCZ, QTD_ERR_ENT, MODL_OPE_TERM, IND_TIP_ALRM, QTD_TRAN_SCSO_NUM_PRMI, QTD_TRAN_SCSO_NUM_SECD, QTD_NOVA_DSGM_SCSO_NUM_PRMI, QTD_NOVA_DSGM_SCSO_NUM_SECD, QTD_ERR_LEIT_CAR, QTD_ERR_CNXO_HOST, QTD_TMPO_OFLN, QTD_LEIT_MSR, CPO_RSVA_1, VLCD_OPE_TERM, QTD_TNTA_SECD_OCPD, PSSW, QTD_TNTA_PRMI_NAO_ATDD, OPC_TERM, OPC_TERM_LOCL";
		query_fields += ", CPO_RSVA_2, IND_OPE_PNPD, VERS_SFTW_TERM, QTD_LIN_IMPR, CPCD_MMRA_TERM, MODL_OPE_CMPH, QTD_FALLBACK, TIP_DSGM, TIP_CNXO, IND_UTLZ_PABX, NUM_TEL_INCZ, NUM_TEL_PRMI_TERM, NUM_TEL_SECD_TERM, TMPO_MDOI_CNXO, TMPO_MDOI_OPE, TMPO_MDOI_TRAN, QTD_ENTR_ERR_PIN, QTD_TRAN_CNCL_PSSW, QTD_CAR_BLQD_PSSW, QTD_TRAN_OFLN, IND_STTU_RPLC, QTD_CV_IMPR_PRMR_SGND_VIA, QTD_CV_IMPR_PRMR_VIA, QTD_CV_IMPR_SGND_VIA, QTD_CV_NAO_IMPR, QTD_TRAN_DEB_MAGN_CHIP, QTD_CNXO_TLCG_SCSO, QTD_CNXO_INCZ_SCSO, TMPO_CNXO_TLCG_SCSO, TMPO_CNXO_INCZ_SCSO, QTD_CNXO_PRBL_COM_INCZ, QTD_CNXO_PRBL_COM_TLCG, QTD_ERR_TMOT_INCZ, QTD_ERR_TMOT_TLCG, QTD_ERR_MAP_BIT_INCZ, QTD_ERR_MAP_BIT_TLCG, QTD_ERR_DA_INCZ, QTD_ERR_DA_TLCG, QTD_ERR_CNXO_PRDD_INCZ, QTD_ERR_CNXO_PRDD_TLCG, QTD_ERR_COM_INCZ, QTD_ERR_COM_TLCG, QTD_ERR_LIN_USO_INCZ, QTD_ERR_LIN_USO_TLCG, QTD_ERR_SEM_TOM_DSGM_INCZ, QTD_ERR_SEM_TOM_DSGM_TLCG, QTD_ERR_LIN_OCPD_INCZ, QTD_ERR_LIN_OCPD_TLCG, QTD_ERR_NAO_ATND_INCZ, QTD_ERR_NAO_ATND_TLCG, QTD_ERR_FLHA_ANXO_INCZ, QTD_ERR_FLHA_ANXO_TLCG, QTD_ERR_FLHA_TCP_INCZ, QTD_ERR_FLHA_TCP_TLCG,";
		query_fields += "TMPO_CNCT_TLCG, TMPO_CNCT_INCZ, NUM_TEL_CRGA_RMT, NUM_IP_CNFG, NOM_SITE_ACQR_ORGL, NOM_HOST_ACQR_ORGL, NOM_FE_ACQR_ORGL, NOM_SITE_ISSR, NOM_HOST_ISSR, NOM_FE_ISSR, NOM_SITE_ACQR_ATLZ, NOM_HOST_ACQR_ATLZ, NOM_FE_ACQR_ATLZ";

		table_name = "TBSW0156";

		m_COD_TERM_pos = 1;
		m_NUM_STAN_pos = 2;
		m_DTH_ESTT_pos = 3;
		m_COD_STTU_TERM_pos = 4;
		m_QTD_MSG_RCBD_pos = 5;
		m_QTD_MSG_ENVD_pos = 6;
		m_QTD_TRAN_pos = 7;
		m_QTD_NOVA_DSGM_pos = 8;
		m_QTD_ERR_COM_pos = 9;
		m_QTD_TMOT_TRAN_pos = 10;
		m_QTD_TMOT_RVRS_pos = 11;
		m_QTD_RTRM_pos = 12;
		m_QTD_ERR_RCBM_MSG_pos = 13;
		m_QTD_SNRM_RCBD_pos = 14;
		m_QTD_SNRM_ENVD_pos = 15;
		m_QTD_RNR_RCBD_pos = 16;
		m_QTD_RNR_ENVD_pos = 17;
		m_QTD_TST_RCBD_pos = 18;
		m_QTD_TST_ENVD_pos = 19;
		m_QTD_DM_RCBD_pos = 20;
		m_QTD_DM_ENVD_pos = 21;
		m_QTD_UAS_RCBD_pos = 22;
		m_QTD_UAS_ENVD_pos = 23;
		m_QTD_FRME_RCBD_pos = 24;
		m_QTD_FRME_ENVD_pos = 25;
		m_CONT_TMPO_RSPS_pos = 26;
		m_LIM_TMPO_RSPS_1_pos = 27;
		m_LIM_TMPO_RSPS_2_pos = 28;
		m_LIM_TMPO_RSPS_3_pos = 29;
		m_LIM_TMPO_RSPS_4_pos = 30;
		m_CONT_TMPO_RSPS_1_pos = 31;
		m_CONT_TMPO_RSPS_2_pos = 32;
		m_CONT_TMPO_RSPS_3_pos = 33;
		m_CONT_TMPO_RSPS_4_pos = 34;
		m_QTD_MIN_ATVD_pos = 35;
		m_QTD_MIN_INTD_pos = 36;
		m_QTD_REINCZ_pos = 37;
		m_QTD_ERR_ENT_pos = 38;
		m_MODL_OPE_TERM_pos = 39;
		m_IND_TIP_ALRM_pos = 40;
		m_QTD_TRAN_SCSO_NUM_PRMI_pos = 41;
		m_QTD_TRAN_SCSO_NUM_SECD_pos = 42;
		m_QTD_NOVA_DSGM_SCSO_NUM_PRMI_pos = 43;
		m_QTD_NOVA_DSGM_SCSO_NUM_SECD_pos = 44;
		m_QTD_ERR_LEIT_CAR_pos = 45;
		m_QTD_ERR_CNXO_HOST_pos = 46;
		m_QTD_TMPO_OFLN_pos = 47;
		m_QTD_LEIT_MSR_pos = 48;
		m_CPO_RSVA_1_pos = 49;
		m_VLCD_OPE_TERM_pos = 50;
		m_QTD_TNTA_SECD_OCPD_pos = 51;
		m_PSSW_pos = 52;
		m_QTD_TNTA_PRMI_NAO_ATDD_pos = 53;
		m_OPC_TERM_pos = 54;
		m_OPC_TERM_LOCL_pos = 55;
		m_CPO_RSVA_2_pos = 56;
		m_IND_OPE_PNPD_pos = 57;
		m_VERS_SFTW_TERM_pos = 58;
		m_QTD_LIN_IMPR_pos = 59;
		m_CPCD_MMRA_TERM_pos = 60;
		m_MODL_OPE_CMPH_pos = 61;
		m_QTD_FALLBACK_pos = 62;
		m_TIP_DSGM_pos = 63;
		m_TIP_CNXO_pos = 64;
		m_IND_UTLZ_PABX_pos = 65;
		m_NUM_TEL_INCZ_pos = 66;
		m_NUM_TEL_PRMI_TERM_pos = 67;
		m_NUM_TEL_SECD_TERM_pos = 68;
		m_TMPO_MDOI_CNXO_pos = 69;
		m_TMPO_MDOI_OPE_pos = 70;
		m_TMPO_MDOI_TRAN_pos = 71;
		m_QTD_ENTR_ERR_PIN_pos = 72;
		m_QTD_TRAN_CNCL_PSSW_pos = 73;
		m_QTD_CAR_BLQD_PSSW_pos = 74;
		m_QTD_TRAN_OFLN_pos = 75;
		m_IND_STTU_RPLC_pos = 76;
		m_QTD_CV_IMPR_PRMR_SGND_VIA_pos = 77;
		m_QTD_CV_IMPR_PRMR_VIA_pos = 78;
		m_QTD_CV_IMPR_SGND_VIA_pos = 79;
		m_QTD_CV_NAO_IMPR_pos = 80;
		m_QTD_TRAN_DEB_MAGN_CHIP_pos = 81;
		m_QTD_CNXO_TLCG_SCSO_pos = 82;
		m_QTD_CNXO_INCZ_SCSO_pos = 83;
		m_TMPO_CNXO_TLCG_SCSO_pos = 84;
		m_TMPO_CNXO_INCZ_SCSO_pos = 85;
		m_QTD_CNXO_PRBL_COM_INCZ_pos = 86;
		m_QTD_CNXO_PRBL_COM_TLCG_pos = 87;
		m_QTD_ERR_TMOT_INCZ_pos = 88;
		m_QTD_ERR_TMOT_TLCG_pos = 89;
		m_QTD_ERR_MAP_BIT_INCZ_pos = 90;
		m_QTD_ERR_MAP_BIT_TLCG_pos = 91;
		m_QTD_ERR_DA_INCZ_pos = 92;
		m_QTD_ERR_DA_TLCG_pos = 93;
		m_QTD_ERR_CNXO_PRDD_INCZ_pos = 94;
		m_QTD_ERR_CNXO_PRDD_TLCG_pos = 95;
		m_QTD_ERR_COM_INCZ_pos = 96;
		m_QTD_ERR_COM_TLCG_pos = 97;
		m_QTD_ERR_LIN_USO_INCZ_pos = 98;
		m_QTD_ERR_LIN_USO_TLCG_pos = 99;
		m_QTD_ERR_SEM_TOM_DSGM_INCZ_pos = 100;
		m_QTD_ERR_SEM_TOM_DSGM_TLCG_pos = 101;
		m_QTD_ERR_LIN_OCPD_INCZ_pos = 102;
		m_QTD_ERR_LIN_OCPD_TLCG_pos = 103;
		m_QTD_ERR_NAO_ATND_INCZ_pos = 104;
		m_QTD_ERR_NAO_ATND_TLCG_pos = 105;
		m_QTD_ERR_FLHA_ANXO_INCZ_pos = 106;
		m_QTD_ERR_FLHA_ANXO_TLCG_pos = 107;
		m_QTD_ERR_FLHA_TCP_INCZ_pos = 108;
		m_QTD_ERR_FLHA_TCP_TLCG_pos = 109;
		m_TMPO_CNCT_TLCG_pos = 110;
		m_TMPO_CNCT_INCZ_pos = 111;
		m_NUM_TEL_CRGA_RMT_pos = 112;
		m_NUM_IP_CNFG_pos = 113;
		m_NOM_SITE_ACQR_ORGL_pos = 114;
		m_NOM_HOST_ACQR_ORGL_pos = 115;
		m_NOM_FE_ACQR_ORGL_pos = 116;
		m_NOM_SITE_ISSR_pos = 117;
		m_NOM_HOST_ISSR_pos = 118;
		m_NOM_FE_ISSR_pos = 119;
		m_NOM_SITE_ACQR_ATLZ_pos = 120;
		m_NOM_HOST_ACQR_ATLZ_pos = 121;
		m_NOM_FE_ACQR_ATLZ_pos = 122;

		m_COD_TERM = " ";
		dbm_longtodec( &m_NUM_STAN, 0 );
		m_DTH_ESTT = 0;
		m_COD_STTU_TERM = 0;
		m_QTD_MSG_RCBD = 0;
		m_QTD_MSG_ENVD = 0;
		m_QTD_TRAN = 0;
		m_QTD_NOVA_DSGM = 0;
		m_QTD_ERR_COM = 0;
		m_QTD_TMOT_TRAN = 0;
		m_QTD_TMOT_RVRS = 0;
		m_QTD_RTRM = 0;
		m_QTD_ERR_RCBM_MSG = 0;
		m_QTD_SNRM_RCBD = 0;
		m_QTD_SNRM_ENVD = 0;
		m_QTD_RNR_RCBD = 0;
		m_QTD_RNR_ENVD = 0;
		m_QTD_TST_RCBD = 0;
		m_QTD_TST_ENVD = 0;
		m_QTD_DM_RCBD = 0;
		m_QTD_DM_ENVD = 0;
		m_QTD_UAS_RCBD = 0;
		m_QTD_UAS_ENVD = 0;
		m_QTD_FRME_RCBD = 0;
		m_QTD_FRME_ENVD = 0;
		m_CONT_TMPO_RSPS = 0;
		m_LIM_TMPO_RSPS_1 = 0;
		m_LIM_TMPO_RSPS_2 = 0;
		m_LIM_TMPO_RSPS_3 = 0;
		m_LIM_TMPO_RSPS_4 = 0;
		m_CONT_TMPO_RSPS_1 = 0;
		m_CONT_TMPO_RSPS_2 = 0;
		m_CONT_TMPO_RSPS_3 = 0;
		m_CONT_TMPO_RSPS_4 = 0;
		m_QTD_MIN_ATVD = 0;
		m_QTD_MIN_INTD = 0;
		m_QTD_REINCZ = 0;
		m_QTD_ERR_ENT = 0;
		m_MODL_OPE_TERM = "";
		m_IND_TIP_ALRM = "";
		m_QTD_TRAN_SCSO_NUM_PRMI = 0;
		m_QTD_TRAN_SCSO_NUM_SECD = 0;
		m_QTD_NOVA_DSGM_SCSO_NUM_PRMI = 0;
		m_QTD_NOVA_DSGM_SCSO_NUM_SECD = 0;
		m_QTD_ERR_LEIT_CAR = 0;
		m_QTD_ERR_CNXO_HOST = 0;
		m_QTD_TMPO_OFLN = 0;
		m_QTD_LEIT_MSR = 0;
		m_CPO_RSVA_1 = "";
		m_VLCD_OPE_TERM = 0;
		m_QTD_TNTA_SECD_OCPD = "";
		m_PSSW = 0;
		m_QTD_TNTA_PRMI_NAO_ATDD = 0;
		m_OPC_TERM = "";
		m_OPC_TERM_LOCL = "";
		m_CPO_RSVA_2 = "";
		m_IND_OPE_PNPD = 0;
		m_VERS_SFTW_TERM = " ";
		m_QTD_LIN_IMPR = 0;
		m_CPCD_MMRA_TERM = 0;
		m_MODL_OPE_CMPH = 0;
		m_QTD_FALLBACK = 0;
		m_TIP_DSGM = "";
		m_TIP_CNXO = "";
		m_IND_UTLZ_PABX = "";
		m_NUM_TEL_INCZ = "";
		m_NUM_TEL_PRMI_TERM = "";
		m_NUM_TEL_SECD_TERM = "";
		m_TMPO_MDOI_CNXO = 0;
		m_TMPO_MDOI_OPE = 0;
		m_TMPO_MDOI_TRAN = 0;
		m_QTD_ENTR_ERR_PIN = 0;
		m_QTD_TRAN_CNCL_PSSW = 0;
		m_QTD_CAR_BLQD_PSSW = 0;
		m_QTD_TRAN_OFLN = 0;
		m_IND_STTU_RPLC = "";
		m_QTD_CV_IMPR_PRMR_SGND_VIA = 0;
		m_QTD_CV_IMPR_PRMR_VIA = 0;
		m_QTD_CV_IMPR_SGND_VIA = 0;
		m_QTD_CV_NAO_IMPR = 0;
		m_QTD_TRAN_DEB_MAGN_CHIP = 0;
		m_QTD_CNXO_TLCG_SCSO = 0;
		m_QTD_CNXO_INCZ_SCSO = 0;
		m_TMPO_CNXO_TLCG_SCSO = 0;
		m_TMPO_CNXO_INCZ_SCSO = 0;
		m_QTD_CNXO_PRBL_COM_INCZ = 0;
		m_QTD_CNXO_PRBL_COM_TLCG = 0;
		m_QTD_ERR_TMOT_INCZ = 0;
		m_QTD_ERR_TMOT_TLCG = 0;
		m_QTD_ERR_MAP_BIT_INCZ = 0;
		m_QTD_ERR_MAP_BIT_TLCG = 0;
		m_QTD_ERR_DA_INCZ = 0;
		m_QTD_ERR_DA_TLCG = 0;
		m_QTD_ERR_CNXO_PRDD_INCZ = 0;
		m_QTD_ERR_CNXO_PRDD_TLCG = 0;
		m_QTD_ERR_COM_INCZ = 0;
		m_QTD_ERR_COM_TLCG = 0;
		m_QTD_ERR_LIN_USO_INCZ = 0;
		m_QTD_ERR_LIN_USO_TLCG = 0;
		m_QTD_ERR_SEM_TOM_DSGM_INCZ = 0;
		m_QTD_ERR_SEM_TOM_DSGM_TLCG = 0;
		m_QTD_ERR_LIN_OCPD_INCZ = 0;
		m_QTD_ERR_LIN_OCPD_TLCG = 0;
		m_QTD_ERR_NAO_ATND_INCZ = 0;
		m_QTD_ERR_NAO_ATND_TLCG = 0;
		m_QTD_ERR_FLHA_ANXO_INCZ = 0;
		m_QTD_ERR_FLHA_ANXO_TLCG = 0;
		m_QTD_ERR_FLHA_TCP_INCZ = 0;
		m_QTD_ERR_FLHA_TCP_TLCG = 0;
		m_TMPO_CNCT_TLCG = 0;
		m_TMPO_CNCT_INCZ = 0;
		dbm_longtodec( &m_NUM_TEL_CRGA_RMT, 0 );
		dbm_longtodec( &m_NUM_IP_CNFG, 0 );
		m_NOM_SITE_ACQR_ORGL = "";
		m_NOM_HOST_ACQR_ORGL = "";
		m_NOM_FE_ACQR_ORGL = "";
		m_NOM_SITE_ISSR = "";
		m_NOM_HOST_ISSR = "";
		m_NOM_FE_ISSR = "";
		m_NOM_SITE_ACQR_ATLZ = "";
		m_NOM_HOST_ACQR_ATLZ = "";
		m_NOM_FE_ACQR_ATLZ = "";
	}
	
	TBSW0156::TBSW0156()
	{
		init();
		where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0156::TBSW0156( const std::string& whereClause )
	{
		init();
		where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0156::~TBSW0156()
	{
	}

	void TBSW0156::bind_columns()
	{
		bind( m_COD_TERM_pos, m_COD_TERM );
		bind( m_NUM_STAN_pos, m_NUM_STAN );
		bind( m_DTH_ESTT_pos, &m_DTH_ESTT );
		bind( m_COD_STTU_TERM_pos, m_COD_STTU_TERM );
		bind( m_QTD_MSG_RCBD_pos, m_QTD_MSG_RCBD );
		bind( m_QTD_MSG_ENVD_pos, m_QTD_MSG_ENVD );
		bind( m_QTD_TRAN_pos, m_QTD_TRAN );
		bind( m_QTD_NOVA_DSGM_pos, m_QTD_NOVA_DSGM );
		bind( m_QTD_ERR_COM_pos, m_QTD_ERR_COM );
		bind( m_QTD_TMOT_TRAN_pos, m_QTD_TMOT_TRAN );
		bind( m_QTD_TMOT_RVRS_pos, m_QTD_TMOT_RVRS );
		bind( m_QTD_RTRM_pos, m_QTD_RTRM );
		bind( m_QTD_ERR_RCBM_MSG_pos, m_QTD_ERR_RCBM_MSG );
		bind( m_QTD_SNRM_RCBD_pos, m_QTD_SNRM_RCBD );
		bind( m_QTD_SNRM_ENVD_pos, m_QTD_SNRM_ENVD );
		bind( m_QTD_RNR_RCBD_pos, m_QTD_RNR_RCBD );
		bind( m_QTD_RNR_ENVD_pos, m_QTD_RNR_ENVD );
		bind( m_QTD_TST_RCBD_pos, m_QTD_TST_RCBD );
		bind( m_QTD_TST_ENVD_pos, m_QTD_TST_ENVD );
		bind( m_QTD_DM_RCBD_pos, m_QTD_DM_RCBD );
		bind( m_QTD_DM_ENVD_pos, m_QTD_DM_ENVD );
		bind( m_QTD_UAS_RCBD_pos, m_QTD_UAS_RCBD );
		bind( m_QTD_UAS_ENVD_pos, m_QTD_UAS_ENVD );
		bind( m_QTD_FRME_RCBD_pos, m_QTD_FRME_RCBD );
		bind( m_QTD_FRME_ENVD_pos, m_QTD_FRME_ENVD );
		bind( m_CONT_TMPO_RSPS_pos, m_CONT_TMPO_RSPS );
		bind( m_LIM_TMPO_RSPS_1_pos, m_LIM_TMPO_RSPS_1 );
		bind( m_LIM_TMPO_RSPS_2_pos, m_LIM_TMPO_RSPS_2 );
		bind( m_LIM_TMPO_RSPS_3_pos, m_LIM_TMPO_RSPS_3 );
		bind( m_LIM_TMPO_RSPS_4_pos, m_LIM_TMPO_RSPS_4 );
		bind( m_CONT_TMPO_RSPS_1_pos, m_CONT_TMPO_RSPS_1 );
		bind( m_CONT_TMPO_RSPS_2_pos, m_CONT_TMPO_RSPS_2 );
		bind( m_CONT_TMPO_RSPS_3_pos, m_CONT_TMPO_RSPS_3 );
		bind( m_CONT_TMPO_RSPS_4_pos, m_CONT_TMPO_RSPS_4 );
		bind( m_QTD_MIN_ATVD_pos, m_QTD_MIN_ATVD );
		bind( m_QTD_MIN_INTD_pos, m_QTD_MIN_INTD );
		bind( m_QTD_REINCZ_pos, m_QTD_REINCZ );
		bind( m_QTD_ERR_ENT_pos, m_QTD_ERR_ENT );
		bind( m_MODL_OPE_TERM_pos, m_MODL_OPE_TERM );
		bind( m_IND_TIP_ALRM_pos, m_IND_TIP_ALRM );
		bind( m_QTD_TRAN_SCSO_NUM_PRMI_pos, m_QTD_TRAN_SCSO_NUM_PRMI );
		bind( m_QTD_TRAN_SCSO_NUM_SECD_pos, m_QTD_TRAN_SCSO_NUM_SECD );
		bind( m_QTD_NOVA_DSGM_SCSO_NUM_PRMI_pos, m_QTD_NOVA_DSGM_SCSO_NUM_PRMI );
		bind( m_QTD_NOVA_DSGM_SCSO_NUM_SECD_pos, m_QTD_NOVA_DSGM_SCSO_NUM_SECD );
		bind( m_QTD_ERR_LEIT_CAR_pos, m_QTD_ERR_LEIT_CAR );
		bind( m_QTD_ERR_CNXO_HOST_pos, m_QTD_ERR_CNXO_HOST );
		bind( m_QTD_TMPO_OFLN_pos, m_QTD_TMPO_OFLN );
		bind( m_QTD_LEIT_MSR_pos, m_QTD_LEIT_MSR );
		bind( m_CPO_RSVA_1_pos, m_CPO_RSVA_1 );
		bind( m_VLCD_OPE_TERM_pos, m_VLCD_OPE_TERM );
		bind( m_QTD_TNTA_SECD_OCPD_pos, m_QTD_TNTA_SECD_OCPD );
		bind( m_PSSW_pos, m_PSSW );
		bind( m_QTD_TNTA_PRMI_NAO_ATDD_pos, m_QTD_TNTA_PRMI_NAO_ATDD );
		bind( m_OPC_TERM_pos, m_OPC_TERM );
		bind( m_OPC_TERM_LOCL_pos, m_OPC_TERM_LOCL );
		bind( m_CPO_RSVA_2_pos, m_CPO_RSVA_2 );
		bind( m_IND_OPE_PNPD_pos, m_IND_OPE_PNPD );
		bind( m_VERS_SFTW_TERM_pos, m_VERS_SFTW_TERM );
		bind( m_QTD_LIN_IMPR_pos, m_QTD_LIN_IMPR );
		bind( m_CPCD_MMRA_TERM_pos, m_CPCD_MMRA_TERM );
		bind( m_MODL_OPE_CMPH_pos, m_MODL_OPE_CMPH );
		bind( m_QTD_FALLBACK_pos, m_QTD_FALLBACK );
		bind( m_TIP_DSGM_pos, m_TIP_DSGM );
		bind( m_TIP_CNXO_pos, m_TIP_CNXO );
		bind( m_IND_UTLZ_PABX_pos, m_IND_UTLZ_PABX );
		bind( m_NUM_TEL_INCZ_pos, m_NUM_TEL_INCZ );
		bind( m_NUM_TEL_PRMI_TERM_pos, m_NUM_TEL_PRMI_TERM );
		bind( m_NUM_TEL_SECD_TERM_pos, m_NUM_TEL_SECD_TERM );
		bind( m_TMPO_MDOI_CNXO_pos, m_TMPO_MDOI_CNXO );
		bind( m_TMPO_MDOI_OPE_pos, m_TMPO_MDOI_OPE );
		bind( m_TMPO_MDOI_TRAN_pos, m_TMPO_MDOI_TRAN );
		bind( m_QTD_ENTR_ERR_PIN_pos, m_QTD_ENTR_ERR_PIN );
		bind( m_QTD_TRAN_CNCL_PSSW_pos, m_QTD_TRAN_CNCL_PSSW );
		bind( m_QTD_CAR_BLQD_PSSW_pos, m_QTD_CAR_BLQD_PSSW );
		bind( m_QTD_TRAN_OFLN_pos, m_QTD_TRAN_OFLN );
		bind( m_IND_STTU_RPLC_pos, m_IND_STTU_RPLC );
		bind( m_QTD_CV_IMPR_PRMR_SGND_VIA_pos, m_QTD_CV_IMPR_PRMR_SGND_VIA );
		bind( m_QTD_CV_IMPR_PRMR_VIA_pos, m_QTD_CV_IMPR_PRMR_VIA );
		bind( m_QTD_CV_IMPR_SGND_VIA_pos, m_QTD_CV_IMPR_SGND_VIA );
		bind( m_QTD_CV_NAO_IMPR_pos, m_QTD_CV_NAO_IMPR );
		bind( m_QTD_TRAN_DEB_MAGN_CHIP_pos, m_QTD_TRAN_DEB_MAGN_CHIP );
		bind( m_QTD_CNXO_TLCG_SCSO_pos, m_QTD_CNXO_TLCG_SCSO );
		bind( m_QTD_CNXO_INCZ_SCSO_pos, m_QTD_CNXO_INCZ_SCSO );
		bind( m_TMPO_CNXO_TLCG_SCSO_pos, m_TMPO_CNXO_TLCG_SCSO );
		bind( m_TMPO_CNXO_INCZ_SCSO_pos, m_TMPO_CNXO_INCZ_SCSO );
		bind( m_QTD_CNXO_PRBL_COM_INCZ_pos, m_QTD_CNXO_PRBL_COM_INCZ );
		bind( m_QTD_CNXO_PRBL_COM_TLCG_pos, m_QTD_CNXO_PRBL_COM_TLCG );
		bind( m_QTD_ERR_TMOT_INCZ_pos, m_QTD_ERR_TMOT_INCZ );
		bind( m_QTD_ERR_TMOT_TLCG_pos, m_QTD_ERR_TMOT_TLCG );
		bind( m_QTD_ERR_MAP_BIT_INCZ_pos, m_QTD_ERR_MAP_BIT_INCZ );
		bind( m_QTD_ERR_MAP_BIT_TLCG_pos, m_QTD_ERR_MAP_BIT_TLCG );
		bind( m_QTD_ERR_DA_INCZ_pos, m_QTD_ERR_DA_INCZ );
		bind( m_QTD_ERR_DA_TLCG_pos, m_QTD_ERR_DA_TLCG );
		bind( m_QTD_ERR_CNXO_PRDD_INCZ_pos, m_QTD_ERR_CNXO_PRDD_INCZ );
		bind( m_QTD_ERR_CNXO_PRDD_TLCG_pos, m_QTD_ERR_CNXO_PRDD_TLCG );
		bind( m_QTD_ERR_COM_INCZ_pos, m_QTD_ERR_COM_INCZ );
		bind( m_QTD_ERR_COM_TLCG_pos, m_QTD_ERR_COM_TLCG );
		bind( m_QTD_ERR_LIN_USO_INCZ_pos, m_QTD_ERR_LIN_USO_INCZ );
		bind( m_QTD_ERR_LIN_USO_TLCG_pos, m_QTD_ERR_LIN_USO_TLCG );
		bind( m_QTD_ERR_SEM_TOM_DSGM_INCZ_pos, m_QTD_ERR_SEM_TOM_DSGM_INCZ );
		bind( m_QTD_ERR_SEM_TOM_DSGM_TLCG_pos, m_QTD_ERR_SEM_TOM_DSGM_TLCG );
		bind( m_QTD_ERR_LIN_OCPD_INCZ_pos, m_QTD_ERR_LIN_OCPD_INCZ );
		bind( m_QTD_ERR_LIN_OCPD_TLCG_pos, m_QTD_ERR_LIN_OCPD_TLCG );
		bind( m_QTD_ERR_NAO_ATND_INCZ_pos, m_QTD_ERR_NAO_ATND_INCZ );
		bind( m_QTD_ERR_NAO_ATND_TLCG_pos, m_QTD_ERR_NAO_ATND_TLCG );
		bind( m_QTD_ERR_FLHA_ANXO_INCZ_pos, m_QTD_ERR_FLHA_ANXO_INCZ );
		bind( m_QTD_ERR_FLHA_ANXO_TLCG_pos, m_QTD_ERR_FLHA_ANXO_TLCG );
		bind( m_QTD_ERR_FLHA_TCP_INCZ_pos, m_QTD_ERR_FLHA_TCP_INCZ );
		bind( m_QTD_ERR_FLHA_TCP_TLCG_pos, m_QTD_ERR_FLHA_TCP_TLCG );
		bind( m_TMPO_CNCT_TLCG_pos, m_TMPO_CNCT_TLCG );
		bind( m_TMPO_CNCT_INCZ_pos, m_TMPO_CNCT_INCZ );
		bind( m_NUM_TEL_CRGA_RMT_pos, m_NUM_TEL_CRGA_RMT );
		bind( m_NUM_IP_CNFG_pos, m_NUM_IP_CNFG );
		bind( m_NOM_SITE_ACQR_ORGL_pos, m_NOM_SITE_ACQR_ORGL );
		bind( m_NOM_HOST_ACQR_ORGL_pos, m_NOM_HOST_ACQR_ORGL );
		bind( m_NOM_FE_ACQR_ORGL_pos, m_NOM_FE_ACQR_ORGL );
		bind( m_NOM_SITE_ISSR_pos, m_NOM_SITE_ISSR );
		bind( m_NOM_HOST_ISSR_pos, m_NOM_HOST_ISSR );
		bind( m_NOM_FE_ISSR_pos, m_NOM_FE_ISSR );
		bind( m_NOM_SITE_ACQR_ATLZ_pos, m_NOM_SITE_ACQR_ATLZ );
		bind( m_NOM_HOST_ACQR_ATLZ_pos, m_NOM_HOST_ACQR_ATLZ );
		bind( m_NOM_FE_ACQR_ATLZ_pos, m_NOM_FE_ACQR_ATLZ );
	}
	void TBSW0156::set_COD_TERM( const std::string& a_COD_TERM )
	{
		m_COD_TERM = a_COD_TERM;
	}
	void TBSW0156::set_NUM_STAN( oasis_dec_t a_NUM_STAN )
	{
		dbm_deccopy( &m_NUM_STAN, &a_NUM_STAN );
	}
	void TBSW0156::set_DTH_ESTT( dbm_datetime_t a_DTH_ESTT )
	{
		m_DTH_ESTT = a_DTH_ESTT;
	}
	void TBSW0156::set_COD_STTU_TERM( unsigned long a_COD_STTU_TERM )
	{
		m_COD_STTU_TERM = a_COD_STTU_TERM;
	}
	void TBSW0156::set_QTD_MSG_RCBD( unsigned long a_QTD_MSG_RCBD )
	{
		m_QTD_MSG_RCBD = a_QTD_MSG_RCBD;
	}
	void TBSW0156::set_QTD_MSG_ENVD( unsigned long a_QTD_MSG_ENVD )
	{
		m_QTD_MSG_ENVD = a_QTD_MSG_ENVD;
	}
	void TBSW0156::set_QTD_TRAN( unsigned long a_QTD_TRAN )
	{
		m_QTD_TRAN = a_QTD_TRAN;
	}
	void TBSW0156::set_QTD_NOVA_DSGM( unsigned long a_QTD_NOVA_DSGM )
	{
		m_QTD_NOVA_DSGM = a_QTD_NOVA_DSGM;
	}
	void TBSW0156::set_QTD_ERR_COM( unsigned long a_QTD_ERR_COM )
	{
		m_QTD_ERR_COM = a_QTD_ERR_COM;
	}
	void TBSW0156::set_QTD_TMOT_TRAN( unsigned long a_QTD_TMOT_TRAN )
	{
		m_QTD_TMOT_TRAN = a_QTD_TMOT_TRAN;
	}
	void TBSW0156::set_QTD_TMOT_RVRS( unsigned long a_QTD_TMOT_RVRS )
	{
		m_QTD_TMOT_RVRS = a_QTD_TMOT_RVRS;
	}
	void TBSW0156::set_QTD_RTRM( unsigned long a_QTD_RTRM )
	{
		m_QTD_RTRM = a_QTD_RTRM;
	}
	void TBSW0156::set_QTD_ERR_RCBM_MSG( unsigned long a_QTD_ERR_RCBM_MSG )
	{
		m_QTD_ERR_RCBM_MSG = a_QTD_ERR_RCBM_MSG;
	}
	void TBSW0156::set_QTD_SNRM_RCBD( unsigned long a_QTD_SNRM_RCBD )
	{
		m_QTD_SNRM_RCBD = a_QTD_SNRM_RCBD;
	}
	void TBSW0156::set_QTD_SNRM_ENVD( unsigned long a_QTD_SNRM_ENVD )
	{
		m_QTD_SNRM_ENVD = a_QTD_SNRM_ENVD;
	}
	void TBSW0156::set_QTD_RNR_RCBD( unsigned long a_QTD_RNR_RCBD )
	{
		m_QTD_RNR_RCBD = a_QTD_RNR_RCBD;
	}
	void TBSW0156::set_QTD_RNR_ENVD( unsigned long a_QTD_RNR_ENVD )
	{
		m_QTD_RNR_ENVD = a_QTD_RNR_ENVD;
	}
	void TBSW0156::set_QTD_TST_RCBD( unsigned long a_QTD_TST_RCBD )
	{
		m_QTD_TST_RCBD = a_QTD_TST_RCBD;
	}
	void TBSW0156::set_QTD_TST_ENVD( unsigned long a_QTD_TST_ENVD )
	{
		m_QTD_TST_ENVD = a_QTD_TST_ENVD;
	}
	void TBSW0156::set_QTD_DM_RCBD( unsigned long a_QTD_DM_RCBD )
	{
		m_QTD_DM_RCBD = a_QTD_DM_RCBD;
	}
	void TBSW0156::set_QTD_DM_ENVD( unsigned long a_QTD_DM_ENVD )
	{
		m_QTD_DM_ENVD = a_QTD_DM_ENVD;
	}
	void TBSW0156::set_QTD_UAS_RCBD( unsigned long a_QTD_UAS_RCBD )
	{
		m_QTD_UAS_RCBD = a_QTD_UAS_RCBD;
	}
	void TBSW0156::set_QTD_UAS_ENVD( unsigned long a_QTD_UAS_ENVD )
	{
		m_QTD_UAS_ENVD = a_QTD_UAS_ENVD;
	}
	void TBSW0156::set_QTD_FRME_RCBD( unsigned long a_QTD_FRME_RCBD )
	{
		m_QTD_FRME_RCBD = a_QTD_FRME_RCBD;
	}
	void TBSW0156::set_QTD_FRME_ENVD( unsigned long a_QTD_FRME_ENVD )
	{
		m_QTD_FRME_ENVD = a_QTD_FRME_ENVD;
	}
	void TBSW0156::set_CONT_TMPO_RSPS( unsigned long a_CONT_TMPO_RSPS )
	{
		m_CONT_TMPO_RSPS = a_CONT_TMPO_RSPS;
	}
	void TBSW0156::set_LIM_TMPO_RSPS_1( unsigned long a_LIM_TMPO_RSPS_1 )
	{
		m_LIM_TMPO_RSPS_1 = a_LIM_TMPO_RSPS_1;
	}
	void TBSW0156::set_LIM_TMPO_RSPS_2( unsigned long a_LIM_TMPO_RSPS_2 )
	{
		m_LIM_TMPO_RSPS_2 = a_LIM_TMPO_RSPS_2;
	}
	void TBSW0156::set_LIM_TMPO_RSPS_3( unsigned long a_LIM_TMPO_RSPS_3 )
	{
		m_LIM_TMPO_RSPS_3 = a_LIM_TMPO_RSPS_3;
	}
	void TBSW0156::set_LIM_TMPO_RSPS_4( unsigned long a_LIM_TMPO_RSPS_4 )
	{
		m_LIM_TMPO_RSPS_4 = a_LIM_TMPO_RSPS_4;
	}
	void TBSW0156::set_CONT_TMPO_RSPS_1( unsigned long a_CONT_TMPO_RSPS_1 )
	{
		m_CONT_TMPO_RSPS_1 = a_CONT_TMPO_RSPS_1;
	}
	void TBSW0156::set_CONT_TMPO_RSPS_2( unsigned long a_CONT_TMPO_RSPS_2 )
	{
		m_CONT_TMPO_RSPS_2 = a_CONT_TMPO_RSPS_2;
	}
	void TBSW0156::set_CONT_TMPO_RSPS_3( unsigned long a_CONT_TMPO_RSPS_3 )
	{
		m_CONT_TMPO_RSPS_3 = a_CONT_TMPO_RSPS_3;
	}
	void TBSW0156::set_CONT_TMPO_RSPS_4( unsigned long a_CONT_TMPO_RSPS_4 )
	{
		m_CONT_TMPO_RSPS_4 = a_CONT_TMPO_RSPS_4;
	}
	void TBSW0156::set_QTD_MIN_ATVD( unsigned long a_QTD_MIN_ATVD )
	{
		m_QTD_MIN_ATVD = a_QTD_MIN_ATVD;
	}
	void TBSW0156::set_QTD_MIN_INTD( unsigned long a_QTD_MIN_INTD )
	{
		m_QTD_MIN_INTD = a_QTD_MIN_INTD;
	}
	void TBSW0156::set_QTD_REINCZ( unsigned long a_QTD_REINCZ )
	{
		m_QTD_REINCZ = a_QTD_REINCZ;
	}
	void TBSW0156::set_QTD_ERR_ENT( unsigned long a_QTD_ERR_ENT )
	{
		m_QTD_ERR_ENT = a_QTD_ERR_ENT;
	}
	void TBSW0156::set_MODL_OPE_TERM( const std::string& a_MODL_OPE_TERM )
	{
		m_MODL_OPE_TERM = a_MODL_OPE_TERM;
	}
	void TBSW0156::set_IND_TIP_ALRM( const std::string& a_IND_TIP_ALRM )
	{
		m_IND_TIP_ALRM = a_IND_TIP_ALRM;
	}
	void TBSW0156::set_QTD_TRAN_SCSO_NUM_PRMI( unsigned long a_QTD_TRAN_SCSO_NUM_PRMI )
	{
		m_QTD_TRAN_SCSO_NUM_PRMI = a_QTD_TRAN_SCSO_NUM_PRMI;
	}
	void TBSW0156::set_QTD_TRAN_SCSO_NUM_SECD( unsigned long a_QTD_TRAN_SCSO_NUM_SECD )
	{
		m_QTD_TRAN_SCSO_NUM_SECD = a_QTD_TRAN_SCSO_NUM_SECD;
	}
	void TBSW0156::set_QTD_NOVA_DSGM_SCSO_NUM_PRMI( unsigned long a_QTD_NOVA_DSGM_SCSO_NUM_PRMI )
	{
		m_QTD_NOVA_DSGM_SCSO_NUM_PRMI = a_QTD_NOVA_DSGM_SCSO_NUM_PRMI;
	}
	void TBSW0156::set_QTD_NOVA_DSGM_SCSO_NUM_SECD( unsigned long a_QTD_NOVA_DSGM_SCSO_NUM_SECD )
	{
		m_QTD_NOVA_DSGM_SCSO_NUM_SECD = a_QTD_NOVA_DSGM_SCSO_NUM_SECD;
	}
	void TBSW0156::set_QTD_ERR_LEIT_CAR( unsigned long a_QTD_ERR_LEIT_CAR )
	{
		m_QTD_ERR_LEIT_CAR = a_QTD_ERR_LEIT_CAR;
	}
	void TBSW0156::set_QTD_ERR_CNXO_HOST( unsigned long a_QTD_ERR_CNXO_HOST )
	{
		m_QTD_ERR_CNXO_HOST = a_QTD_ERR_CNXO_HOST;
	}
	void TBSW0156::set_QTD_TMPO_OFLN( unsigned long a_QTD_TMPO_OFLN )
	{
		m_QTD_TMPO_OFLN = a_QTD_TMPO_OFLN;
	}
	void TBSW0156::set_QTD_LEIT_MSR( unsigned long a_QTD_LEIT_MSR )
	{
		m_QTD_LEIT_MSR = a_QTD_LEIT_MSR;
	}
	void TBSW0156::set_CPO_RSVA_1( const std::string& a_CPO_RSVA_1 )
	{
		m_CPO_RSVA_1 = a_CPO_RSVA_1;
	}
	void TBSW0156::set_VLCD_OPE_TERM( unsigned long a_VLCD_OPE_TERM )
	{
		m_VLCD_OPE_TERM = a_VLCD_OPE_TERM;
	}
	void TBSW0156::set_QTD_TNTA_SECD_OCPD( const std::string& a_QTD_TNTA_SECD_OCPD )
	{
		m_QTD_TNTA_SECD_OCPD = a_QTD_TNTA_SECD_OCPD;
	}
	void TBSW0156::set_PSSW( unsigned long a_PSSW )
	{
		m_PSSW = a_PSSW;
	}
	void TBSW0156::set_QTD_TNTA_PRMI_NAO_ATDD( unsigned long a_QTD_TNTA_PRMI_NAO_ATDD )
	{
		m_QTD_TNTA_PRMI_NAO_ATDD = a_QTD_TNTA_PRMI_NAO_ATDD;
	}
	void TBSW0156::set_OPC_TERM( const std::string& a_OPC_TERM )
	{
		m_OPC_TERM = a_OPC_TERM;
	}
	void TBSW0156::set_OPC_TERM_LOCL( const std::string& a_OPC_TERM_LOCL )
	{
		m_OPC_TERM_LOCL = a_OPC_TERM_LOCL;
	}
	void TBSW0156::set_CPO_RSVA_2( const std::string& a_CPO_RSVA_2 )
	{
		m_CPO_RSVA_2 = a_CPO_RSVA_2;
	}
	void TBSW0156::set_IND_OPE_PNPD( unsigned long a_IND_OPE_PNPD )
	{
		m_IND_OPE_PNPD = a_IND_OPE_PNPD;
	}
	void TBSW0156::set_VERS_SFTW_TERM( const std::string& a_VERS_SFTW_TERM )
	{
		m_VERS_SFTW_TERM = a_VERS_SFTW_TERM;
	}
	void TBSW0156::set_QTD_LIN_IMPR( unsigned long a_QTD_LIN_IMPR )
	{
		m_QTD_LIN_IMPR = a_QTD_LIN_IMPR;
	}
	void TBSW0156::set_CPCD_MMRA_TERM( unsigned long a_CPCD_MMRA_TERM )
	{
		m_CPCD_MMRA_TERM = a_CPCD_MMRA_TERM;
	}
	void TBSW0156::set_MODL_OPE_CMPH( unsigned long a_MODL_OPE_CMPH )
	{
		m_MODL_OPE_CMPH = a_MODL_OPE_CMPH;
	}
	void TBSW0156::set_QTD_FALLBACK( unsigned long a_QTD_FALLBACK )
	{
		m_QTD_FALLBACK = a_QTD_FALLBACK;
	}
	void TBSW0156::set_TIP_DSGM( const std::string& a_TIP_DSGM )
	{
		m_TIP_DSGM = a_TIP_DSGM;
	}
	void TBSW0156::set_TIP_CNXO( const std::string& a_TIP_CNXO )
	{
		m_TIP_CNXO = a_TIP_CNXO;
	}
	void TBSW0156::set_IND_UTLZ_PABX( const std::string& a_IND_UTLZ_PABX )
	{
		m_IND_UTLZ_PABX = a_IND_UTLZ_PABX;
	}
	void TBSW0156::set_NUM_TEL_INCZ( const std::string& a_NUM_TEL_INCZ )
	{
		m_NUM_TEL_INCZ = a_NUM_TEL_INCZ;
	}
	void TBSW0156::set_NUM_TEL_PRMI_TERM( const std::string& a_NUM_TEL_PRMI_TERM )
	{
		m_NUM_TEL_PRMI_TERM = a_NUM_TEL_PRMI_TERM;
	}
	void TBSW0156::set_NUM_TEL_SECD_TERM( const std::string& a_NUM_TEL_SECD_TERM )
	{
		m_NUM_TEL_SECD_TERM = a_NUM_TEL_SECD_TERM;
	}
	void TBSW0156::set_TMPO_MDOI_CNXO( unsigned long a_TMPO_MDOI_CNXO )
	{
		m_TMPO_MDOI_CNXO = a_TMPO_MDOI_CNXO;
	}
	void TBSW0156::set_TMPO_MDOI_OPE( unsigned long a_TMPO_MDOI_OPE )
	{
		m_TMPO_MDOI_OPE = a_TMPO_MDOI_OPE;
	}
	void TBSW0156::set_TMPO_MDOI_TRAN( unsigned long a_TMPO_MDOI_TRAN )
	{
		m_TMPO_MDOI_TRAN = a_TMPO_MDOI_TRAN;
	}
	void TBSW0156::set_QTD_ENTR_ERR_PIN( unsigned long a_QTD_ENTR_ERR_PIN )
	{
		m_QTD_ENTR_ERR_PIN = a_QTD_ENTR_ERR_PIN;
	}
	void TBSW0156::set_QTD_TRAN_CNCL_PSSW( unsigned long a_QTD_TRAN_CNCL_PSSW )
	{
		m_QTD_TRAN_CNCL_PSSW = a_QTD_TRAN_CNCL_PSSW;
	}
	void TBSW0156::set_QTD_CAR_BLQD_PSSW( unsigned long a_QTD_CAR_BLQD_PSSW )
	{
		m_QTD_CAR_BLQD_PSSW = a_QTD_CAR_BLQD_PSSW;
	}
	void TBSW0156::set_QTD_TRAN_OFLN( unsigned long a_QTD_TRAN_OFLN )
	{
		m_QTD_TRAN_OFLN = a_QTD_TRAN_OFLN;
	}
	void TBSW0156::set_IND_STTU_RPLC( const std::string& a_IND_STTU_RPLC )
	{
		m_IND_STTU_RPLC = a_IND_STTU_RPLC;
	}
	void TBSW0156::set_QTD_CV_IMPR_PRMR_SGND_VIA( unsigned long a_QTD_CV_IMPR_PRMR_SGND_VIA )
	{
		m_QTD_CV_IMPR_PRMR_SGND_VIA = a_QTD_CV_IMPR_PRMR_SGND_VIA;
	}
	void TBSW0156::set_QTD_CV_IMPR_PRMR_VIA( unsigned long a_QTD_CV_IMPR_PRMR_VIA )
	{
		m_QTD_CV_IMPR_PRMR_VIA = a_QTD_CV_IMPR_PRMR_VIA;
	}
	void TBSW0156::set_QTD_CV_IMPR_SGND_VIA( unsigned long a_QTD_CV_IMPR_SGND_VIA )
	{
		m_QTD_CV_IMPR_SGND_VIA = a_QTD_CV_IMPR_SGND_VIA;
	}
	void TBSW0156::set_QTD_CV_NAO_IMPR( unsigned long a_QTD_CV_NAO_IMPR )
	{
		m_QTD_CV_NAO_IMPR = a_QTD_CV_NAO_IMPR;
	}
	void TBSW0156::set_QTD_TRAN_DEB_MAGN_CHIP( unsigned long a_QTD_TRAN_DEB_MAGN_CHIP )
	{
		m_QTD_TRAN_DEB_MAGN_CHIP = a_QTD_TRAN_DEB_MAGN_CHIP;
	}
	void TBSW0156::set_QTD_CNXO_TLCG_SCSO( unsigned long a_QTD_CNXO_TLCG_SCSO )
	{
		m_QTD_CNXO_TLCG_SCSO = a_QTD_CNXO_TLCG_SCSO;
	}
	void TBSW0156::set_QTD_CNXO_INCZ_SCSO( unsigned long a_QTD_CNXO_INCZ_SCSO )
	{
		m_QTD_CNXO_INCZ_SCSO = a_QTD_CNXO_INCZ_SCSO;
	}
	void TBSW0156::set_TMPO_CNXO_TLCG_SCSO( unsigned long a_TMPO_CNXO_TLCG_SCSO )
	{
		m_TMPO_CNXO_TLCG_SCSO = a_TMPO_CNXO_TLCG_SCSO;
	}
	void TBSW0156::set_TMPO_CNXO_INCZ_SCSO( unsigned long a_TMPO_CNXO_INCZ_SCSO )
	{
		m_TMPO_CNXO_INCZ_SCSO = a_TMPO_CNXO_INCZ_SCSO;
	}
	void TBSW0156::set_QTD_CNXO_PRBL_COM_INCZ( unsigned long a_QTD_CNXO_PRBL_COM_INCZ )
	{
		m_QTD_CNXO_PRBL_COM_INCZ = a_QTD_CNXO_PRBL_COM_INCZ;
	}
	void TBSW0156::set_QTD_CNXO_PRBL_COM_TLCG( unsigned long a_QTD_CNXO_PRBL_COM_TLCG )
	{
		m_QTD_CNXO_PRBL_COM_TLCG = a_QTD_CNXO_PRBL_COM_TLCG;
	}
	void TBSW0156::set_QTD_ERR_TMOT_INCZ( unsigned long a_QTD_ERR_TMOT_INCZ )
	{
		m_QTD_ERR_TMOT_INCZ = a_QTD_ERR_TMOT_INCZ;
	}
	void TBSW0156::set_QTD_ERR_TMOT_TLCG( unsigned long a_QTD_ERR_TMOT_TLCG )
	{
		m_QTD_ERR_TMOT_TLCG = a_QTD_ERR_TMOT_TLCG;
	}
	void TBSW0156::set_QTD_ERR_MAP_BIT_INCZ( unsigned long a_QTD_ERR_MAP_BIT_INCZ )
	{
		m_QTD_ERR_MAP_BIT_INCZ = a_QTD_ERR_MAP_BIT_INCZ;
	}
	void TBSW0156::set_QTD_ERR_MAP_BIT_TLCG( unsigned long a_QTD_ERR_MAP_BIT_TLCG )
	{
		m_QTD_ERR_MAP_BIT_TLCG = a_QTD_ERR_MAP_BIT_TLCG;
	}
	void TBSW0156::set_QTD_ERR_DA_INCZ( unsigned long a_QTD_ERR_DA_INCZ )
	{
		m_QTD_ERR_DA_INCZ = a_QTD_ERR_DA_INCZ;
	}
	void TBSW0156::set_QTD_ERR_DA_TLCG( unsigned long a_QTD_ERR_DA_TLCG )
	{
		m_QTD_ERR_DA_TLCG = a_QTD_ERR_DA_TLCG;
	}
	void TBSW0156::set_QTD_ERR_CNXO_PRDD_INCZ( unsigned long a_QTD_ERR_CNXO_PRDD_INCZ )
	{
		m_QTD_ERR_CNXO_PRDD_INCZ = a_QTD_ERR_CNXO_PRDD_INCZ;
	}
	void TBSW0156::set_QTD_ERR_CNXO_PRDD_TLCG( unsigned long a_QTD_ERR_CNXO_PRDD_TLCG )
	{
		m_QTD_ERR_CNXO_PRDD_TLCG = a_QTD_ERR_CNXO_PRDD_TLCG;
	}
	void TBSW0156::set_QTD_ERR_COM_INCZ( unsigned long a_QTD_ERR_COM_INCZ )
	{
		m_QTD_ERR_COM_INCZ = a_QTD_ERR_COM_INCZ;
	}
	void TBSW0156::set_QTD_ERR_COM_TLCG( unsigned long a_QTD_ERR_COM_TLCG )
	{
		m_QTD_ERR_COM_TLCG = a_QTD_ERR_COM_TLCG;
	}
	void TBSW0156::set_QTD_ERR_LIN_USO_INCZ( unsigned long a_QTD_ERR_LIN_USO_INCZ )
	{
		m_QTD_ERR_LIN_USO_INCZ = a_QTD_ERR_LIN_USO_INCZ;
	}
	void TBSW0156::set_QTD_ERR_LIN_USO_TLCG( unsigned long a_QTD_ERR_LIN_USO_TLCG )
	{
		m_QTD_ERR_LIN_USO_TLCG = a_QTD_ERR_LIN_USO_TLCG;
	}
	void TBSW0156::set_QTD_ERR_SEM_TOM_DSGM_INCZ( unsigned long a_QTD_ERR_SEM_TOM_DSGM_INCZ )
	{
		m_QTD_ERR_SEM_TOM_DSGM_INCZ = a_QTD_ERR_SEM_TOM_DSGM_INCZ;
	}
	void TBSW0156::set_QTD_ERR_SEM_TOM_DSGM_TLCG( unsigned long a_QTD_ERR_SEM_TOM_DSGM_TLCG )
	{
		m_QTD_ERR_SEM_TOM_DSGM_TLCG = a_QTD_ERR_SEM_TOM_DSGM_TLCG;
	}
	void TBSW0156::set_QTD_ERR_LIN_OCPD_INCZ( unsigned long a_QTD_ERR_LIN_OCPD_INCZ )
	{
		m_QTD_ERR_LIN_OCPD_INCZ = a_QTD_ERR_LIN_OCPD_INCZ;
	}
	void TBSW0156::set_QTD_ERR_LIN_OCPD_TLCG( unsigned long a_QTD_ERR_LIN_OCPD_TLCG )
	{
		m_QTD_ERR_LIN_OCPD_TLCG = a_QTD_ERR_LIN_OCPD_TLCG;
	}
	void TBSW0156::set_QTD_ERR_NAO_ATND_INCZ( unsigned long a_QTD_ERR_NAO_ATND_INCZ )
	{
		m_QTD_ERR_NAO_ATND_INCZ = a_QTD_ERR_NAO_ATND_INCZ;
	}
	void TBSW0156::set_QTD_ERR_NAO_ATND_TLCG( unsigned long a_QTD_ERR_NAO_ATND_TLCG )
	{
		m_QTD_ERR_NAO_ATND_TLCG = a_QTD_ERR_NAO_ATND_TLCG;
	}
	void TBSW0156::set_QTD_ERR_FLHA_ANXO_INCZ( unsigned long a_QTD_ERR_FLHA_ANXO_INCZ )
	{
		m_QTD_ERR_FLHA_ANXO_INCZ = a_QTD_ERR_FLHA_ANXO_INCZ;
	}
	void TBSW0156::set_QTD_ERR_FLHA_ANXO_TLCG( unsigned long a_QTD_ERR_FLHA_ANXO_TLCG )
	{
		m_QTD_ERR_FLHA_ANXO_TLCG = a_QTD_ERR_FLHA_ANXO_TLCG;
	}
	void TBSW0156::set_QTD_ERR_FLHA_TCP_INCZ( unsigned long a_QTD_ERR_FLHA_TCP_INCZ )
	{
		m_QTD_ERR_FLHA_TCP_INCZ = a_QTD_ERR_FLHA_TCP_INCZ;
	}
	void TBSW0156::set_QTD_ERR_FLHA_TCP_TLCG( unsigned long a_QTD_ERR_FLHA_TCP_TLCG )
	{
		m_QTD_ERR_FLHA_TCP_TLCG = a_QTD_ERR_FLHA_TCP_TLCG;
	}
	void TBSW0156::set_TMPO_CNCT_TLCG( unsigned long a_TMPO_CNCT_TLCG )
	{
		m_TMPO_CNCT_TLCG = a_TMPO_CNCT_TLCG;
	}
	void TBSW0156::set_TMPO_CNCT_INCZ( unsigned long a_TMPO_CNCT_INCZ )
	{
		m_TMPO_CNCT_INCZ = a_TMPO_CNCT_INCZ;
	}
	void TBSW0156::set_NUM_TEL_CRGA_RMT( oasis_dec_t a_NUM_TEL_CRGA_RMT )
	{
		dbm_deccopy( &m_NUM_TEL_CRGA_RMT, &a_NUM_TEL_CRGA_RMT );
	}
	void TBSW0156::set_NUM_IP_CNFG( oasis_dec_t a_NUM_IP_CNFG )
	{
		dbm_deccopy( &m_NUM_IP_CNFG, &a_NUM_IP_CNFG );
	}
	void TBSW0156::set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL )
    {
        m_NOM_SITE_ACQR_ORGL = a_NOM_SITE_ACQR_ORGL;
    }
    void TBSW0156::set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL )
    {
        m_NOM_HOST_ACQR_ORGL = a_NOM_HOST_ACQR_ORGL;
    }
    void TBSW0156::set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL )
    {
        m_NOM_FE_ACQR_ORGL = a_NOM_FE_ACQR_ORGL;
    }
    void TBSW0156::set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR )
    {
        m_NOM_SITE_ISSR = a_NOM_SITE_ISSR;
    }
    void TBSW0156::set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR )
    {
        m_NOM_HOST_ISSR = a_NOM_HOST_ISSR;
    }
    void TBSW0156::set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR )
    {
        m_NOM_FE_ISSR = a_NOM_FE_ISSR;
    }
    void TBSW0156::set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ )
    {
        m_NOM_SITE_ACQR_ATLZ = a_NOM_SITE_ACQR_ATLZ;
    }
    void TBSW0156::set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ )
    {
        m_NOM_HOST_ACQR_ATLZ = a_NOM_HOST_ACQR_ATLZ;
    }
    void TBSW0156::set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ )
    {
        m_NOM_FE_ACQR_ATLZ = a_NOM_FE_ACQR_ATLZ;
    }
	const std::string& TBSW0156::get_COD_TERM() const
	{
		return m_COD_TERM;
	}
	oasis_dec_t TBSW0156::get_NUM_STAN() const
	{
		return m_NUM_STAN;
	}
	dbm_datetime_t TBSW0156::get_DTH_ESTT() const
	{
		return m_DTH_ESTT;
	}
	unsigned long TBSW0156::get_COD_STTU_TERM() const
	{
		return m_COD_STTU_TERM;
	}
	unsigned long TBSW0156::get_QTD_MSG_RCBD() const
	{
		return m_QTD_MSG_RCBD;
	}
	unsigned long TBSW0156::get_QTD_MSG_ENVD() const
	{
		return m_QTD_MSG_ENVD;
	}
	unsigned long TBSW0156::get_QTD_TRAN() const
	{
		return m_QTD_TRAN;
	}
	unsigned long TBSW0156::get_QTD_NOVA_DSGM() const
	{
		return m_QTD_NOVA_DSGM;
	}
	unsigned long TBSW0156::get_QTD_ERR_COM() const
	{
		return m_QTD_ERR_COM;
	}
	unsigned long TBSW0156::get_QTD_TMOT_TRAN() const
	{
		return m_QTD_TMOT_TRAN;
	}
	unsigned long TBSW0156::get_QTD_TMOT_RVRS() const
	{
		return m_QTD_TMOT_RVRS;
	}
	unsigned long TBSW0156::get_QTD_RTRM() const
	{
		return m_QTD_RTRM;
	}
	unsigned long TBSW0156::get_QTD_ERR_RCBM_MSG() const
	{
		return m_QTD_ERR_RCBM_MSG;
	}
	unsigned long TBSW0156::get_QTD_SNRM_RCBD() const
	{
		return m_QTD_SNRM_RCBD;
	}
	unsigned long TBSW0156::get_QTD_SNRM_ENVD() const
	{
		return m_QTD_SNRM_ENVD;
	}
	unsigned long TBSW0156::get_QTD_RNR_RCBD() const
	{
		return m_QTD_RNR_RCBD;
	}
	unsigned long TBSW0156::get_QTD_RNR_ENVD() const
	{
		return m_QTD_RNR_ENVD;
	}
	unsigned long TBSW0156::get_QTD_TST_RCBD() const
	{
		return m_QTD_TST_RCBD;
	}
	unsigned long TBSW0156::get_QTD_TST_ENVD() const
	{
		return m_QTD_TST_ENVD;
	}
	unsigned long TBSW0156::get_QTD_DM_RCBD() const
	{
		return m_QTD_DM_RCBD;
	}
	unsigned long TBSW0156::get_QTD_DM_ENVD() const
	{
		return m_QTD_DM_ENVD;
	}
	unsigned long TBSW0156::get_QTD_UAS_RCBD() const
	{
		return m_QTD_UAS_RCBD;
	}
	unsigned long TBSW0156::get_QTD_UAS_ENVD() const
	{
		return m_QTD_UAS_ENVD;
	}
	unsigned long TBSW0156::get_QTD_FRME_RCBD() const
	{
		return m_QTD_FRME_RCBD;
	}
	unsigned long TBSW0156::get_QTD_FRME_ENVD() const
	{
		return m_QTD_FRME_ENVD;
	}
	unsigned long TBSW0156::get_CONT_TMPO_RSPS() const
	{
		return m_CONT_TMPO_RSPS;
	}
	unsigned long TBSW0156::get_LIM_TMPO_RSPS_1() const
	{
		return m_LIM_TMPO_RSPS_1;
	}
	unsigned long TBSW0156::get_LIM_TMPO_RSPS_2() const
	{
		return m_LIM_TMPO_RSPS_2;
	}
	unsigned long TBSW0156::get_LIM_TMPO_RSPS_3() const
	{
		return m_LIM_TMPO_RSPS_3;
	}
	unsigned long TBSW0156::get_LIM_TMPO_RSPS_4() const
	{
		return m_LIM_TMPO_RSPS_4;
	}
	unsigned long TBSW0156::get_CONT_TMPO_RSPS_1() const
	{
		return m_CONT_TMPO_RSPS_1;
	}
	unsigned long TBSW0156::get_CONT_TMPO_RSPS_2() const
	{
		return m_CONT_TMPO_RSPS_2;
	}
	unsigned long TBSW0156::get_CONT_TMPO_RSPS_3() const
	{
		return m_CONT_TMPO_RSPS_3;
	}
	unsigned long TBSW0156::get_CONT_TMPO_RSPS_4() const
	{
		return m_CONT_TMPO_RSPS_4;
	}
	unsigned long TBSW0156::get_QTD_MIN_ATVD() const
	{
		return m_QTD_MIN_ATVD;
	}
	unsigned long TBSW0156::get_QTD_MIN_INTD() const
	{
		return m_QTD_MIN_INTD;
	}
	unsigned long TBSW0156::get_QTD_REINCZ() const
	{
		return m_QTD_REINCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_ENT() const
	{
		return m_QTD_ERR_ENT;
	}
	const std::string& TBSW0156::get_MODL_OPE_TERM() const
	{
		return m_MODL_OPE_TERM;
	}
	const std::string& TBSW0156::get_IND_TIP_ALRM() const
	{
		return m_IND_TIP_ALRM;
	}
	unsigned long TBSW0156::get_QTD_TRAN_SCSO_NUM_PRMI() const
	{
		return m_QTD_TRAN_SCSO_NUM_PRMI;
	}
	unsigned long TBSW0156::get_QTD_TRAN_SCSO_NUM_SECD() const
	{
		return m_QTD_TRAN_SCSO_NUM_SECD;
	}
	unsigned long TBSW0156::get_QTD_NOVA_DSGM_SCSO_NUM_PRMI() const
	{
		return m_QTD_NOVA_DSGM_SCSO_NUM_PRMI;
	}
	unsigned long TBSW0156::get_QTD_NOVA_DSGM_SCSO_NUM_SECD() const
	{
		return m_QTD_NOVA_DSGM_SCSO_NUM_SECD;
	}
	unsigned long TBSW0156::get_QTD_ERR_LEIT_CAR() const
	{
		return m_QTD_ERR_LEIT_CAR;
	}
	unsigned long TBSW0156::get_QTD_ERR_CNXO_HOST() const
	{
		return m_QTD_ERR_CNXO_HOST;
	}
	unsigned long TBSW0156::get_QTD_TMPO_OFLN() const
	{
		return m_QTD_TMPO_OFLN;
	}
	unsigned long TBSW0156::get_QTD_LEIT_MSR() const
	{
		return m_QTD_LEIT_MSR;
	}
	const std::string& TBSW0156::get_CPO_RSVA_1() const
	{
		return m_CPO_RSVA_1;
	}
	unsigned long TBSW0156::get_VLCD_OPE_TERM() const
	{
		return m_VLCD_OPE_TERM;
	}
	const std::string& TBSW0156::get_QTD_TNTA_SECD_OCPD() const
	{
		return m_QTD_TNTA_SECD_OCPD;
	}
	unsigned long TBSW0156::get_PSSW() const
	{
		return m_PSSW;
	}
	unsigned long TBSW0156::get_QTD_TNTA_PRMI_NAO_ATDD() const
	{
		return m_QTD_TNTA_PRMI_NAO_ATDD;
	}
	const std::string& TBSW0156::get_OPC_TERM() const
	{
		return m_OPC_TERM;
	}
	const std::string& TBSW0156::get_OPC_TERM_LOCL() const
	{
		return m_OPC_TERM_LOCL;
	}
	const std::string& TBSW0156::get_CPO_RSVA_2() const
	{
		return m_CPO_RSVA_2;
	}
	unsigned long TBSW0156::get_IND_OPE_PNPD() const
	{
		return m_IND_OPE_PNPD;
	}
	const std::string& TBSW0156::get_VERS_SFTW_TERM() const
	{
		return m_VERS_SFTW_TERM;
	}
	unsigned long TBSW0156::get_QTD_LIN_IMPR() const
	{
		return m_QTD_LIN_IMPR;
	}
	unsigned long TBSW0156::get_CPCD_MMRA_TERM() const
	{
		return m_CPCD_MMRA_TERM;
	}
	unsigned long TBSW0156::get_MODL_OPE_CMPH() const
	{
		return m_MODL_OPE_CMPH;
	}
	unsigned long TBSW0156::get_QTD_FALLBACK() const
	{
		return m_QTD_FALLBACK;
	}
	const std::string& TBSW0156::get_TIP_DSGM() const
	{
		return m_TIP_DSGM;
	}
	const std::string& TBSW0156::get_TIP_CNXO() const
	{
		return m_TIP_CNXO;
	}
	const std::string& TBSW0156::get_IND_UTLZ_PABX() const
	{
		return m_IND_UTLZ_PABX;
	}
	const std::string& TBSW0156::get_NUM_TEL_INCZ() const
	{
		return m_NUM_TEL_INCZ;
	}
	const std::string& TBSW0156::get_NUM_TEL_PRMI_TERM() const
	{
		return m_NUM_TEL_PRMI_TERM;
	}
	const std::string& TBSW0156::get_NUM_TEL_SECD_TERM() const
	{
		return m_NUM_TEL_SECD_TERM;
	}
	unsigned long TBSW0156::get_TMPO_MDOI_CNXO() const
	{
		return m_TMPO_MDOI_CNXO;
	}
	unsigned long TBSW0156::get_TMPO_MDOI_OPE() const
	{
		return m_TMPO_MDOI_OPE;
	}
	unsigned long TBSW0156::get_TMPO_MDOI_TRAN() const
	{
		return m_TMPO_MDOI_TRAN;
	}
	unsigned long TBSW0156::get_QTD_ENTR_ERR_PIN() const
	{
		return m_QTD_ENTR_ERR_PIN;
	}
	unsigned long TBSW0156::get_QTD_TRAN_CNCL_PSSW() const
	{
		return m_QTD_TRAN_CNCL_PSSW;
	}
	unsigned long TBSW0156::get_QTD_CAR_BLQD_PSSW() const
	{
		return m_QTD_CAR_BLQD_PSSW;
	}
	unsigned long TBSW0156::get_QTD_TRAN_OFLN() const
	{
		return m_QTD_TRAN_OFLN;
	}
	const std::string& TBSW0156::get_IND_STTU_RPLC() const
	{
		return m_IND_STTU_RPLC;
	}
	unsigned long TBSW0156::get_QTD_CV_IMPR_PRMR_SGND_VIA() const
	{
		return m_QTD_CV_IMPR_PRMR_SGND_VIA;
	}
	unsigned long TBSW0156::get_QTD_CV_IMPR_PRMR_VIA() const
	{
		return m_QTD_CV_IMPR_PRMR_VIA;
	}
	unsigned long TBSW0156::get_QTD_CV_IMPR_SGND_VIA() const
	{
		return m_QTD_CV_IMPR_SGND_VIA;
	}
	unsigned long TBSW0156::get_QTD_CV_NAO_IMPR() const
	{
		return m_QTD_CV_NAO_IMPR;
	}
	unsigned long TBSW0156::get_QTD_TRAN_DEB_MAGN_CHIP() const
	{
		return m_QTD_TRAN_DEB_MAGN_CHIP;
	}
	unsigned long TBSW0156::get_QTD_CNXO_TLCG_SCSO() const
	{
		return m_QTD_CNXO_TLCG_SCSO;
	}
	unsigned long TBSW0156::get_QTD_CNXO_INCZ_SCSO() const
	{
		return m_QTD_CNXO_INCZ_SCSO;
	}
	unsigned long TBSW0156::get_TMPO_CNXO_TLCG_SCSO() const
	{
		return m_TMPO_CNXO_TLCG_SCSO;
	}
	unsigned long TBSW0156::get_TMPO_CNXO_INCZ_SCSO() const
	{
		return m_TMPO_CNXO_INCZ_SCSO;
	}
	unsigned long TBSW0156::get_QTD_CNXO_PRBL_COM_INCZ() const
	{
		return m_QTD_CNXO_PRBL_COM_INCZ;
	}
	unsigned long TBSW0156::get_QTD_CNXO_PRBL_COM_TLCG() const
	{
		return m_QTD_CNXO_PRBL_COM_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_TMOT_INCZ() const
	{
		return m_QTD_ERR_TMOT_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_TMOT_TLCG() const
	{
		return m_QTD_ERR_TMOT_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_MAP_BIT_INCZ() const
	{
		return m_QTD_ERR_MAP_BIT_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_MAP_BIT_TLCG() const
	{
		return m_QTD_ERR_MAP_BIT_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_DA_INCZ() const
	{
		return m_QTD_ERR_DA_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_DA_TLCG() const
	{
		return m_QTD_ERR_DA_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_CNXO_PRDD_INCZ() const
	{
		return m_QTD_ERR_CNXO_PRDD_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_CNXO_PRDD_TLCG() const
	{
		return m_QTD_ERR_CNXO_PRDD_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_COM_INCZ() const
	{
		return m_QTD_ERR_COM_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_COM_TLCG() const
	{
		return m_QTD_ERR_COM_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_LIN_USO_INCZ() const
	{
		return m_QTD_ERR_LIN_USO_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_LIN_USO_TLCG() const
	{
		return m_QTD_ERR_LIN_USO_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_SEM_TOM_DSGM_INCZ() const
	{
		return m_QTD_ERR_SEM_TOM_DSGM_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_SEM_TOM_DSGM_TLCG() const
	{
		return m_QTD_ERR_SEM_TOM_DSGM_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_LIN_OCPD_INCZ() const
	{
		return m_QTD_ERR_LIN_OCPD_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_LIN_OCPD_TLCG() const
	{
		return m_QTD_ERR_LIN_OCPD_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_NAO_ATND_INCZ() const
	{
		return m_QTD_ERR_NAO_ATND_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_NAO_ATND_TLCG() const
	{
		return m_QTD_ERR_NAO_ATND_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_FLHA_ANXO_INCZ() const
	{
		return m_QTD_ERR_FLHA_ANXO_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_FLHA_ANXO_TLCG() const
	{
		return m_QTD_ERR_FLHA_ANXO_TLCG;
	}
	unsigned long TBSW0156::get_QTD_ERR_FLHA_TCP_INCZ() const
	{
		return m_QTD_ERR_FLHA_TCP_INCZ;
	}
	unsigned long TBSW0156::get_QTD_ERR_FLHA_TCP_TLCG() const
	{
		return m_QTD_ERR_FLHA_TCP_TLCG;
	}
	unsigned long TBSW0156::get_TMPO_CNCT_TLCG() const
	{
		return m_TMPO_CNCT_TLCG;
	}
	unsigned long TBSW0156::get_TMPO_CNCT_INCZ() const
	{
		return m_TMPO_CNCT_INCZ;
	}
	oasis_dec_t TBSW0156::get_NUM_TEL_CRGA_RMT() const
	{
		return m_NUM_TEL_CRGA_RMT;
	}
	oasis_dec_t TBSW0156::get_NUM_IP_CNFG() const
	{
		return m_NUM_IP_CNFG;
	}
	const std::string& TBSW0156::get_NOM_SITE_ACQR_ORGL() const
    {
        return m_NOM_SITE_ACQR_ORGL;
    }
    const std::string& TBSW0156::get_NOM_HOST_ACQR_ORGL() const
    {
        return m_NOM_HOST_ACQR_ORGL;
    }
    const std::string& TBSW0156::get_NOM_FE_ACQR_ORGL() const
    {
        return m_NOM_FE_ACQR_ORGL;
    }
    const std::string& TBSW0156::get_NOM_SITE_ISSR() const
    {
        return m_NOM_SITE_ISSR;
    }
    const std::string& TBSW0156::get_NOM_HOST_ISSR() const
    {
        return m_NOM_HOST_ISSR;
    }
    const std::string& TBSW0156::get_NOM_FE_ISSR() const
    {
        return m_NOM_FE_ISSR;
    }
    const std::string& TBSW0156::get_NOM_SITE_ACQR_ATLZ() const
    {
        return m_NOM_SITE_ACQR_ATLZ;
    }
    const std::string& TBSW0156::get_NOM_HOST_ACQR_ATLZ() const
    {
        return m_NOM_HOST_ACQR_ATLZ;
    }
    const std::string& TBSW0156::get_NOM_FE_ACQR_ATLZ() const
    {
        return m_NOM_FE_ACQR_ATLZ;
    }

} //namespace dbaccess_common

