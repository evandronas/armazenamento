/* Copyright 2018 Rede S.A.
Autor : Danilo Oliveira
Empresa : FIS
*/

#include "Tbsw0162.hpp"

namespace dbaccess_common
{
    /// Tbsw0162
    /// Construtor padrao da classe
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    Tbsw0162::Tbsw0162( )
    {
        // Procedimentos iniciais
        Initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    /// Tbsw0162
    /// Construtor da classe onde eh possivel informar a clausula where a ser utilizada
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    /// whereClause: valor a ser atribuido
    Tbsw0162::Tbsw0162( const std::string& whereClause )
    {
        // Procedimentos iniciais
        Initialize();
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    /// ~Tbsw0162
    /// Destrutor padrao da classe
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    Tbsw0162::~Tbsw0162( )
    {
    }

    /// Initialize
    /// Inicia a montagem da query
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    void Tbsw0162::Initialize()
    {
        // Inicio da montagem da query
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, COD_TERM, NUM_ESTB, NUM_SRE_TERM";
        table_name = "TBSW0162";

        // Inicializacao dos atributos
        posDataMovimentoTransacao = 1;
        posNumeroSequencialUnico = 2;
        posCodigoTerminal = 3;
        posNumeroEstabelecimento = 4;
        posNumeroSerieTerminal = 5;		
        dataMovimentoTransacao = 0;
        numeroSequencialUnico = 0;
        codigoTerminal = "";
        numeroEstabelecimento = 0;
        numeroSerieTerminal = "";
    }

    /// SetWhereClause
    /// Atribui valor ao atributo que representa a clausula where
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    /// whereClause: valor a ser atribuido
    void Tbsw0162::SetWhereClause( const std::string& whereClause )
    {
        // Atribuindo valor
        where_condition = whereClause;
    }

    /// bind_columns
    /// Efetua bind das colunas (implementacao obrigatoria - metodo virtual na classe pai)
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    void Tbsw0162::bind_columns( )
    {
        // Efetua bind
        bind( posDataMovimentoTransacao, dataMovimentoTransacao );
        bind( posNumeroSequencialUnico, numeroSequencialUnico );
        bind( posCodigoTerminal, codigoTerminal );
        bind( posNumeroEstabelecimento, numeroEstabelecimento );
        bind( posNumeroSerieTerminal, numeroSerieTerminal );
    }

    /// SetDataMovimentoTransacao
    /// Atribui valor ao atributo dataMovimentoTransacao
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    /// paramDataMovimentoTransacao: valor a ser atribuido
    void Tbsw0162::SetDataMovimentoTransacao( unsigned long paramDataMovimentoTransacao )
    {
        // Atribuindo valor
        dataMovimentoTransacao = paramDataMovimentoTransacao;
    }

    /// SetNumeroSequencialUnico
    /// Atribui valor ao atributo numeroSequencialUnico
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    /// paramNumeroSequencialUnico: valor a ser atribuido
    void Tbsw0162::SetNumeroSequencialUnico( unsigned long paramNumeroSequencialUnico )
    {
        // Atribuindo valor
        numeroSequencialUnico = paramNumeroSequencialUnico;
    }

    /// SetCodigoTerminal
    /// Atribui valor ao atributo codigoTerminal
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    /// paramCodigoTerminal: valor a ser atribuido
    void Tbsw0162::SetCodigoTerminal( const std::string& paramCodigoTerminal )
    {
        // Atribuindo valor
        codigoTerminal = paramCodigoTerminal;
    }

    /// SetNumeroEstabelecimento
    /// Atribui valor ao atributo numeroEstabelecimento
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    /// paramNumeroEstabelecimento: valor a ser atribuido
    void Tbsw0162::SetNumeroEstabelecimento( unsigned long paramNumeroEstabelecimento )
    {
        // Atribuindo valor
        numeroEstabelecimento = paramNumeroEstabelecimento;
    }

    /// SetNumeroSerieTerminal
    /// Atribui valor ao atributo numeroSerieTerminal
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    /// paramNumeroSerieTerminal: valor a ser atribuido
    void Tbsw0162::SetNumeroSerieTerminal( const std::string& paramNumeroSerieTerminal )
    {
        // Atribuindo valor
        numeroSerieTerminal = paramNumeroSerieTerminal;
    }

    /// GetDataMovimentoTransacao
    /// Obtem o valor do atributo dataMovimentoTransacao
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    unsigned long Tbsw0162::GetDataMovimentoTransacao( ) const
    {
        // Retorna o valor
        return dataMovimentoTransacao;
    }

    /// GetNumeroSequencialUnico
    /// Obtem o valor do atributo numeroSequencialUnico
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    unsigned long Tbsw0162::GetNumeroSequencialUnico( ) const
    {
        // Retorna o valor
        return numeroSequencialUnico;
    }

    /// GetCodigoTerminal
    /// Obtem o valor do atributo codigoTerminal
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    const std::string& Tbsw0162::GetCodigoTerminal( ) const
    {
        // Retorna o valor
        return codigoTerminal;
    }

    /// GetNumeroEstabelecimento
    /// Obtem o valor do atributo numeroEstabelecimento
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    unsigned long Tbsw0162::GetNumeroEstabelecimento( ) const
    {
        // Retorna o valor
        return numeroEstabelecimento;
    }

    /// GetNumeroSerieTerminal
    /// Obtem o valor do atributo numeroSerieTerminal
    /// EF/ET: 000
    /// Historico: 04/05/2018 - 000 - Implementacao inicial
    const std::string& Tbsw0162::GetNumeroSerieTerminal( ) const
    {
        // Retorna o valor
        return numeroSerieTerminal;
    }

} //namespace dbaccess_common
