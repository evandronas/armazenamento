/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#include "TBSW2018.hpp"

namespace dbaccess_common
{

    TBSW2018::TBSW2018() {
        
        query_fields = "ID_ENDR_CTL_DSPO, COD_SIT_REG, DES_ORG_BLQO, COD_USR_ULT_ATLZ, DTH_ULT_ATLZ";
		table_name = "TBSW2018";

        enderecoControleDispositivoPosicao = 1;
        codigoSituacaoRegistroPosicao = 2;
        descricaoBloqueioPosicao = 3;
        codigoUsuarioUltimaAlteracaoPosicao = 4;
        dataUltimaAlteracaoRegistroPosicao = 5;

        enderecoControleDispositivo = "";
        codigoSituacaoRegistro = "";
        descricaoBloqueio = "" ; 
        codigoUsuarioUltimaAlteracao = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW2018::TBSW2018(const std::string& where) {
    
        query_fields = "ID_ENDR_CTL_DSPO, COD_SIT_REG, DES_ORG_BLQO, COD_USR_ULT_ATLZ, DTH_ULT_ATLZ";
        table_name = "TBSW2018";
        where_condition = where;

        enderecoControleDispositivoPosicao = 1;
        codigoSituacaoRegistroPosicao = 2;
        descricaoBloqueioPosicao = 3;
        codigoUsuarioUltimaAlteracaoPosicao = 4;
        dataUltimaAlteracaoRegistroPosicao = 5;

        enderecoControleDispositivo = "";
        codigoSituacaoRegistro = "";
        descricaoBloqueio = "" ; 
        codigoUsuarioUltimaAlteracao = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW2018::~TBSW2018() {
    }

    void TBSW2018::bind_columns() {
        bind(enderecoControleDispositivoPosicao, enderecoControleDispositivo);
        bind(codigoSituacaoRegistroPosicao, codigoSituacaoRegistro);
        bind(descricaoBloqueioPosicao, descricaoBloqueio);
        bind(codigoUsuarioUltimaAlteracaoPosicao, codigoUsuarioUltimaAlteracao);
        bind(dataUltimaAlteracaoRegistroPosicao, &dataAlteracaoRegistro);

    }

    // Getters
    const std::string& TBSW2018::GetEnderecoControleDispositivo() const {
        return enderecoControleDispositivo;
    }

    const std::string& TBSW2018::GetCodigoSituacaoRegistro() const {
        return codigoSituacaoRegistro;
    }

    const std::string& TBSW2018::GetDescricaoBloqueio() const {
        return descricaoBloqueio;
    }    

    const std::string& TBSW2018::GetCodigoUsuarioUltimaAlteracao() const {
        return codigoUsuarioUltimaAlteracao;
    }

    const dbm_datetime_t& TBSW2018::GetDataUltimaAlteracaoRegistro() const {
        return dataAlteracaoRegistro;
    }


    // Setters
    void TBSW2018::SetEnderecoControleDispositivo(const std::string& value) {
        enderecoControleDispositivo = value;
    }

    void TBSW2018::SetCodigoSituacaoRegistro(const std::string& value) {
        codigoSituacaoRegistro = value;
    }

    void TBSW2018::SetDescricaoBloqueio(const std::string& value) {
        descricaoBloqueio = value;
    }    
        
    void TBSW2018::SetCodigoUsuarioUltimaAlteracao(const std::string& value) {
        codigoUsuarioUltimaAlteracao = value;
    }

    void TBSW2018::SetDataUltimaAlteracaoRegistro(const dbm_datetime_t& value) {
        dataAlteracaoRegistro = value;
    }

}
