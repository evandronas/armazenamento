#include<TBSW0157RegrasFormatacaoBase.hpp>
#include<AcqUtils.hpp>

TBSW0157RegrasFormatacaoBase::TBSW0157RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0157RegrasFormatacaoBase::~TBSW0157RegrasFormatacaoBase( )
{
}

//insert
void TBSW0157RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	tbsw0157.set_DAT_MOV_TRAN(params.local_date);
}

void TBSW0157RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	tbsw0157.set_NUM_SEQ_UNC( params.refnum );
}

void TBSW0157RegrasFormatacaoBase::insert_COD_SERV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	tbsw0157.set_COD_SERV_TRAN( params.cod_service );
}

void TBSW0157RegrasFormatacaoBase::insert_NUM_PDV_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	tbsw0157.set_NUM_PDV_ORG_TRAN( params.pv_fisico);
}

void TBSW0157RegrasFormatacaoBase::insert_COD_TERM_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	if(params.term_fisico.empty())
	{
		WARNING_EMPTY_STRING;
		tbsw0157.set_COD_TERM_ORG_TRAN(" ");
	}
	else
		tbsw0157.set_COD_TERM_ORG_TRAN( params.term_fisico );
}

void TBSW0157RegrasFormatacaoBase::insert_NUM_DDD_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	tbsw0157.set_NUM_DDD_RCRG( params.ddd_celular );
}

void TBSW0157RegrasFormatacaoBase::insert_NUM_TEL_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	tbsw0157.set_NUM_TEL_RCRG( params.num_celular);
}

void TBSW0157RegrasFormatacaoBase::insert_NUM_SEQ_UNC_OPER( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	tbsw0157.set_NUM_SEQ_UNC_OPER( params.nsu_operadora  );
}

//chamada
void TBSW0157RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao )
{
	if( operacao == acq_common::INSERT )
	{
		insert_DAT_MOV_TRAN( tbsw0157, params );
	}
	else if( operacao == acq_common::UPDATE )
	{
		update_DAT_MOV_TRAN( tbsw0157, params );
	}
}

void TBSW0157RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao )
{
	if( operacao == acq_common::INSERT )
	{
		insert_NUM_SEQ_UNC( tbsw0157, params );
	}
	else if( operacao == acq_common::UPDATE )
	{
		update_NUM_SEQ_UNC( tbsw0157, params );
	}
}

void TBSW0157RegrasFormatacaoBase::COD_SERV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao )
{
	if( operacao == acq_common::INSERT )
	{
		insert_COD_SERV_TRAN( tbsw0157, params );
	}
	else if( operacao == acq_common::UPDATE )
	{
		update_COD_SERV_TRAN( tbsw0157, params );
	}
}

void TBSW0157RegrasFormatacaoBase::NUM_PDV_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao )
{
	if( operacao == acq_common::INSERT )
	{
		insert_NUM_PDV_ORG_TRAN( tbsw0157, params );
	}
	else if( operacao == acq_common::UPDATE )
	{
		update_NUM_PDV_ORG_TRAN( tbsw0157, params );
	}
}

void TBSW0157RegrasFormatacaoBase::COD_TERM_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao )
{
	if( operacao == acq_common::INSERT )
	{
		insert_COD_TERM_ORG_TRAN( tbsw0157, params );
	}
	else if( operacao == acq_common::UPDATE )
	{
		update_COD_TERM_ORG_TRAN( tbsw0157, params );
	}
}

void TBSW0157RegrasFormatacaoBase::NUM_DDD_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao )
{
	if( operacao == acq_common::INSERT )
	{
		insert_NUM_DDD_RCRG( tbsw0157, params );
	}
	else if( operacao == acq_common::UPDATE )
	{
		update_NUM_DDD_RCRG( tbsw0157, params );
	}
}

void TBSW0157RegrasFormatacaoBase::NUM_TEL_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao )
{
	if( operacao == acq_common::INSERT )
	{
		insert_NUM_TEL_RCRG( tbsw0157, params );
	}
	else if( operacao == acq_common::UPDATE )
	{
		update_NUM_TEL_RCRG( tbsw0157, params );
	}
}

void TBSW0157RegrasFormatacaoBase::NUM_SEQ_UNC_OPER( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params, const acq_common::OPERACAO &operacao )
{
	if( operacao == acq_common::INSERT )
	{
		insert_NUM_SEQ_UNC_OPER( tbsw0157, params );
	}
	else if( operacao == acq_common::UPDATE )
	{
		update_NUM_SEQ_UNC_OPER( tbsw0157, params );
	}
}

//gen
void TBSW0157RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::gen_COD_SERV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::gen_NUM_PDV_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::gen_COD_TERM_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::gen_NUM_DDD_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::gen_NUM_TEL_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::gen_NUM_SEQ_UNC_OPER( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

//update
void TBSW0157RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::update_COD_SERV_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::update_NUM_PDV_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::update_COD_TERM_ORG_TRAN( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::update_NUM_DDD_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::update_NUM_TEL_RCRG( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}

void TBSW0157RegrasFormatacaoBase::update_NUM_SEQ_UNC_OPER( dbaccess_common::TBSW0157 &tbsw0157, const struct acq_common::tbsw0157_params &params )
{
	WARNING_INVALID_FUNCTION;
}
