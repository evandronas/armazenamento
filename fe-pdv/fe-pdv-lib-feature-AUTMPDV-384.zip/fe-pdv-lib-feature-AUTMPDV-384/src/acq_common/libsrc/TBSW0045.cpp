/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <dbaccess_common::TBSW0045>
/ Descri��o: <Arquivo de implementa��o da classe dbaccess_common::TBSW0045>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <694449, Fernando Ramires>
/ Data de Cria��o: <2013, 22 de Mar�o>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#include "TBSW0045.hpp"

namespace dbaccess_common
{
	TBSW0045::TBSW0045()
	{

		query_fields = "NUM_RV, NUM_PDV, IND_NUM_QBRA, DAT_RV, COD_BNDR, NOM_BNDR, COD_PROD, NOM_PROD, QTD_CV, VAL_TOTL_LQDO, VAL_TOTL_DSCT, VAL_TOTL_GRJT, VAL_TOTL_PAGO, DAT_CRE_RV, VAL_SIT_RVS, DTH_INI, DTH_FIM, QTD_PRCL, VAL_ENTR, VAL_TX_SERV_RVS, VAL_FLAG_QBRA, COD_TCNL, COD_TERM, NUM_STAN, COD_CMPM_TRAN, VAL_SQUE, VAL_PRES_BRTO, VAL_RMNR_RCD, VAL_IOF, VAL_CPMF, VAL_TAC, TIP_IOF";

		table_name = "TBSW0045";

		m_NUM_RV_pos = 1;
		m_NUM_PDV_pos = 2;
		m_IND_NUM_QBRA_pos = 3;
		m_DAT_RV_pos = 4;
		m_COD_BNDR_pos = 5;
		m_NOM_BNDR_pos = 6;
		m_COD_PROD_pos = 7;
		m_NOM_PROD_pos = 8;
		m_QTD_CV_pos = 9;
		m_VAL_TOTL_LQDO_pos = 10;
		m_VAL_TOTL_DSCT_pos = 11;
		m_VAL_TOTL_GRJT_pos = 12;
		m_VAL_TOTL_PAGO_pos = 13;
		m_DAT_CRE_RV_pos = 14;
		m_VAL_SIT_RVS_pos = 15;
		m_DTH_INI_pos = 16;
		m_DTH_FIM_pos = 17;
		m_QTD_PRCL_pos = 18;
		m_VAL_ENTR_pos = 19;
		m_VAL_TX_SERV_RVS_pos = 20;
		m_VAL_FLAG_QBRA_pos = 21;
		m_COD_TCNL_pos = 22;
		m_COD_TERM_pos = 23;
		m_NUM_STAN_pos = 24;
		m_COD_CMPM_TRAN_pos = 25;
		m_VAL_SQUE_pos = 26;
		m_VAL_PRES_BRTO_pos = 27;
		m_VAL_RMNR_RCD_pos = 28;
		m_VAL_IOF_pos = 29;
		m_VAL_CPMF_pos = 30;
		m_VAL_TAC_pos = 31;
		m_TIP_IOF_pos = 32;

	dbm_longtodec( &m_NUM_RV, 0 );
	m_NUM_PDV = 0;
	m_IND_NUM_QBRA = 0;
	m_DAT_RV = 0;
	m_COD_BNDR = 0;
	m_NOM_BNDR = " ";
	m_COD_PROD = 0;
	m_NOM_PROD = " ";
	dbm_longtodec( &m_QTD_CV, 0 );
	dbm_chartodec( &m_VAL_TOTL_LQDO, "0.00", 2 );
	dbm_chartodec( &m_VAL_TOTL_DSCT, "0.00", 2 );
	dbm_chartodec( &m_VAL_TOTL_GRJT, "0.00", 2 );
	dbm_chartodec( &m_VAL_TOTL_PAGO, "0.00", 2 );
	m_DAT_CRE_RV = 0;
	m_VAL_SIT_RVS = 0;
	m_DTH_INI = 0;
	m_DTH_FIM = 0;
	m_QTD_PRCL = 0;
	dbm_chartodec( &m_VAL_ENTR, "0.00", 2 );
	dbm_chartodec( &m_VAL_TX_SERV_RVS, "0.00", 2 );
	m_VAL_FLAG_QBRA = "";
	m_COD_TCNL = "";
	m_COD_TERM = " ";
	m_NUM_STAN = 0;
	m_COD_CMPM_TRAN = 0;
	dbm_chartodec( &m_VAL_SQUE, "0.00", 2 );
	dbm_chartodec( &m_VAL_PRES_BRTO, "0.00", 2 );
	dbm_chartodec( &m_VAL_RMNR_RCD, "0.00", 2 );
	dbm_chartodec( &m_VAL_IOF, "0.00", 2 );
	dbm_chartodec( &m_VAL_CPMF, "0.00", 2 );
	dbm_chartodec( &m_VAL_TAC, "0.00", 2 );
	m_TIP_IOF = "";

    m_QTD_CV_ind_null = DBM_NULL_DATA;
    m_VAL_TOTL_LQDO_ind_null = DBM_NULL_DATA;
    m_VAL_TOTL_DSCT_ind_null = DBM_NULL_DATA;
    m_VAL_TOTL_GRJT_ind_null = DBM_NULL_DATA;
    m_VAL_ENTR_ind_null = DBM_NULL_DATA;
    m_VAL_TX_SERV_RVS_ind_null = DBM_NULL_DATA;
    m_NUM_STAN_ind_null = DBM_NULL_DATA;
    m_VAL_SQUE_ind_null = DBM_NULL_DATA;
    m_VAL_PRES_BRTO_ind_null = DBM_NULL_DATA;
    m_VAL_RMNR_RCD_ind_null = DBM_NULL_DATA;
    m_VAL_IOF_ind_null = DBM_NULL_DATA;
    m_VAL_CPMF_ind_null = DBM_NULL_DATA;
    m_VAL_TAC_ind_null = DBM_NULL_DATA;    
   
		where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0045::TBSW0045( const std::string& whereClause )
	{

		query_fields = "NUM_RV, NUM_PDV, IND_NUM_QBRA, DAT_RV, COD_BNDR, NOM_BNDR, COD_PROD, NOM_PROD, QTD_CV, VAL_TOTL_LQDO, VAL_TOTL_DSCT, VAL_TOTL_GRJT, VAL_TOTL_PAGO, DAT_CRE_RV, VAL_SIT_RVS, DTH_INI, DTH_FIM, QTD_PRCL, VAL_ENTR, VAL_TX_SERV_RVS, VAL_FLAG_QBRA, COD_TCNL, COD_TERM, NUM_STAN, COD_CMPM_TRAN, VAL_SQUE, VAL_PRES_BRTO, VAL_RMNR_RCD, VAL_IOF, VAL_CPMF, VAL_TAC, TIP_IOF";

		table_name = "TBSW0045";

		m_NUM_RV_pos = 1;
		m_NUM_PDV_pos = 2;
		m_IND_NUM_QBRA_pos = 3;
		m_DAT_RV_pos = 4;
		m_COD_BNDR_pos = 5;
		m_NOM_BNDR_pos = 6;
		m_COD_PROD_pos = 7;
		m_NOM_PROD_pos = 8;
		m_QTD_CV_pos = 9;
		m_VAL_TOTL_LQDO_pos = 10;
		m_VAL_TOTL_DSCT_pos = 11;
		m_VAL_TOTL_GRJT_pos = 12;
		m_VAL_TOTL_PAGO_pos = 13;
		m_DAT_CRE_RV_pos = 14;
		m_VAL_SIT_RVS_pos = 15;
		m_DTH_INI_pos = 16;
		m_DTH_FIM_pos = 17;
		m_QTD_PRCL_pos = 18;
		m_VAL_ENTR_pos = 19;
		m_VAL_TX_SERV_RVS_pos = 20;
		m_VAL_FLAG_QBRA_pos = 21;
		m_COD_TCNL_pos = 22;
		m_COD_TERM_pos = 23;
		m_NUM_STAN_pos = 24;
		m_COD_CMPM_TRAN_pos = 25;
		m_VAL_SQUE_pos = 26;
		m_VAL_PRES_BRTO_pos = 27;
		m_VAL_RMNR_RCD_pos = 28;
		m_VAL_IOF_pos = 29;
		m_VAL_CPMF_pos = 30;
		m_VAL_TAC_pos = 31;
		m_TIP_IOF_pos = 32;

	dbm_longtodec( &m_NUM_RV, 0 );
	m_NUM_PDV = 0;
	m_IND_NUM_QBRA = 0;
	m_DAT_RV = 0;
	m_COD_BNDR = 0;
	m_NOM_BNDR = " ";
	m_COD_PROD = 0;
	m_NOM_PROD = " ";
	dbm_longtodec( &m_QTD_CV, 0 );
	dbm_chartodec( &m_VAL_TOTL_LQDO, "0.00", 2 );
	dbm_chartodec( &m_VAL_TOTL_DSCT, "0.00", 2 );
	dbm_chartodec( &m_VAL_TOTL_GRJT, "0.00", 2 );
	dbm_chartodec( &m_VAL_TOTL_PAGO, "0.00", 2 );
	m_DAT_CRE_RV = 0;
	m_VAL_SIT_RVS = 0;
	m_DTH_INI = 0;
	m_DTH_FIM = 0;
	m_QTD_PRCL = 0;
	dbm_chartodec( &m_VAL_ENTR, "0.00", 2 );
	dbm_chartodec( &m_VAL_TX_SERV_RVS, "0.00", 2 );
	m_VAL_FLAG_QBRA = "";
	m_COD_TCNL = "";
	m_COD_TERM = " ";
	m_NUM_STAN = 0;
	m_COD_CMPM_TRAN = 0;
	dbm_chartodec( &m_VAL_SQUE, "0.00", 2 );
	dbm_chartodec( &m_VAL_PRES_BRTO, "0.00", 2 );
	dbm_chartodec( &m_VAL_RMNR_RCD, "0.00", 2 );
	dbm_chartodec( &m_VAL_IOF, "0.00", 2 );
	dbm_chartodec( &m_VAL_CPMF, "0.00", 2 );
	dbm_chartodec( &m_VAL_TAC, "0.00", 2 );
	m_TIP_IOF = "";

    m_QTD_CV_ind_null = DBM_NULL_DATA;
    m_VAL_TOTL_LQDO_ind_null = DBM_NULL_DATA;
    m_VAL_TOTL_DSCT_ind_null = DBM_NULL_DATA;
    m_VAL_TOTL_GRJT_ind_null = DBM_NULL_DATA;
    m_VAL_ENTR_ind_null = DBM_NULL_DATA;
    m_VAL_TX_SERV_RVS_ind_null = DBM_NULL_DATA;
    m_NUM_STAN_ind_null = DBM_NULL_DATA;
    m_VAL_SQUE_ind_null = DBM_NULL_DATA;
    m_VAL_PRES_BRTO_ind_null = DBM_NULL_DATA;
    m_VAL_RMNR_RCD_ind_null = DBM_NULL_DATA;
    m_VAL_IOF_ind_null = DBM_NULL_DATA;
    m_VAL_CPMF_ind_null = DBM_NULL_DATA;
    m_VAL_TAC_ind_null = DBM_NULL_DATA;
		where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0045::~TBSW0045()
	{
	}

	void TBSW0045::bind_columns()
	{
		bind( m_NUM_RV_pos, m_NUM_RV );
		bind( m_NUM_PDV_pos, m_NUM_PDV );
		bind( m_IND_NUM_QBRA_pos, m_IND_NUM_QBRA );
		bind( m_DAT_RV_pos, &m_DAT_RV );
		bind( m_COD_BNDR_pos, m_COD_BNDR );
		bind( m_NOM_BNDR_pos, m_NOM_BNDR );
		bind( m_COD_PROD_pos, m_COD_PROD );
		bind( m_NOM_PROD_pos, m_NOM_PROD );
		bind( m_QTD_CV_pos, m_QTD_CV , &m_QTD_CV_ind_null);
		bind( m_VAL_TOTL_LQDO_pos, m_VAL_TOTL_LQDO , &m_VAL_TOTL_LQDO_ind_null);
		bind( m_VAL_TOTL_DSCT_pos, m_VAL_TOTL_DSCT , &m_VAL_TOTL_DSCT_ind_null);
		bind( m_VAL_TOTL_GRJT_pos, m_VAL_TOTL_GRJT , &m_VAL_TOTL_GRJT_ind_null);
		bind( m_VAL_TOTL_PAGO_pos, m_VAL_TOTL_PAGO );
		bind( m_DAT_CRE_RV_pos, &m_DAT_CRE_RV );
		bind( m_VAL_SIT_RVS_pos, m_VAL_SIT_RVS );
		bind( m_DTH_INI_pos, &m_DTH_INI );
		bind( m_DTH_FIM_pos, &m_DTH_FIM );
		bind( m_QTD_PRCL_pos, m_QTD_PRCL );
		bind( m_VAL_ENTR_pos, m_VAL_ENTR, &m_VAL_ENTR_ind_null );
		bind( m_VAL_TX_SERV_RVS_pos, m_VAL_TX_SERV_RVS, &m_VAL_TX_SERV_RVS_ind_null );
		bind( m_VAL_FLAG_QBRA_pos, m_VAL_FLAG_QBRA );
		bind( m_COD_TCNL_pos, m_COD_TCNL );
		bind( m_COD_TERM_pos, m_COD_TERM );
		bind( m_NUM_STAN_pos, m_NUM_STAN, &m_NUM_STAN_ind_null );
		bind( m_COD_CMPM_TRAN_pos, m_COD_CMPM_TRAN );
		bind( m_VAL_SQUE_pos, m_VAL_SQUE , &m_VAL_SQUE_ind_null);
		bind( m_VAL_PRES_BRTO_pos, m_VAL_PRES_BRTO , &m_VAL_PRES_BRTO_ind_null);
		bind( m_VAL_RMNR_RCD_pos, m_VAL_RMNR_RCD, &m_VAL_RMNR_RCD_ind_null );
		bind( m_VAL_IOF_pos, m_VAL_IOF , &m_VAL_IOF_ind_null);
		bind( m_VAL_CPMF_pos, m_VAL_CPMF, &m_VAL_CPMF_ind_null );
		bind( m_VAL_TAC_pos, m_VAL_TAC, &m_VAL_TAC_ind_null );
		bind( m_TIP_IOF_pos, m_TIP_IOF );
	}
void TBSW0045::set_NUM_RV( oasis_dec_t a_NUM_RV )
	{
		dbm_deccopy( &m_NUM_RV, &a_NUM_RV );
	}
	void TBSW0045::set_NUM_PDV( unsigned long a_NUM_PDV )
	{
		m_NUM_PDV = a_NUM_PDV;
	}
	void TBSW0045::set_IND_NUM_QBRA( unsigned long a_IND_NUM_QBRA )
	{
		m_IND_NUM_QBRA = a_IND_NUM_QBRA;
	}
	void TBSW0045::set_DAT_RV( dbm_datetime_t a_DAT_RV )
	{
		m_DAT_RV = a_DAT_RV;
	}
	void TBSW0045::set_COD_BNDR( unsigned long a_COD_BNDR )
	{
		m_COD_BNDR = a_COD_BNDR;
	}
	void TBSW0045::set_NOM_BNDR( const std::string& a_NOM_BNDR )
	{
		m_NOM_BNDR = a_NOM_BNDR;
	}
	void TBSW0045::set_COD_PROD( unsigned long a_COD_PROD )
	{
		m_COD_PROD = a_COD_PROD;
	}
	void TBSW0045::set_NOM_PROD( const std::string& a_NOM_PROD )
	{
		m_NOM_PROD = a_NOM_PROD;
	}
	void TBSW0045::set_QTD_CV( oasis_dec_t a_QTD_CV )
	{
		dbm_deccopy( &m_QTD_CV, &a_QTD_CV );
        m_QTD_CV_ind_null = 0;
	}
	void TBSW0045::set_VAL_TOTL_LQDO( oasis_dec_t a_VAL_TOTL_LQDO )
	{
		dbm_deccopy( &m_VAL_TOTL_LQDO, &a_VAL_TOTL_LQDO );
        m_VAL_TOTL_LQDO_ind_null=0;
	}
	void TBSW0045::set_VAL_TOTL_DSCT( oasis_dec_t a_VAL_TOTL_DSCT )
	{
		dbm_deccopy( &m_VAL_TOTL_DSCT, &a_VAL_TOTL_DSCT );
        m_VAL_TOTL_DSCT_ind_null = 0;
	}
	void TBSW0045::set_VAL_TOTL_GRJT( oasis_dec_t a_VAL_TOTL_GRJT )
	{
		dbm_deccopy( &m_VAL_TOTL_GRJT, &a_VAL_TOTL_GRJT );
        m_VAL_TOTL_GRJT_ind_null = 0;
	}
	void TBSW0045::set_VAL_TOTL_PAGO( oasis_dec_t a_VAL_TOTL_PAGO )
	{
		dbm_deccopy( &m_VAL_TOTL_PAGO, &a_VAL_TOTL_PAGO );
	}
	void TBSW0045::set_DAT_CRE_RV( dbm_datetime_t a_DAT_CRE_RV )
	{
		m_DAT_CRE_RV = a_DAT_CRE_RV;
	}
	void TBSW0045::set_VAL_SIT_RVS( unsigned long a_VAL_SIT_RVS )
	{
		m_VAL_SIT_RVS = a_VAL_SIT_RVS;
	}
	void TBSW0045::set_DTH_INI( dbm_datetime_t a_DTH_INI )
	{
		m_DTH_INI = a_DTH_INI;
	}
	void TBSW0045::set_DTH_FIM( dbm_datetime_t a_DTH_FIM )
	{
		m_DTH_FIM = a_DTH_FIM;
	}
	void TBSW0045::set_QTD_PRCL( unsigned long a_QTD_PRCL )
	{
		m_QTD_PRCL = a_QTD_PRCL;
	}
	void TBSW0045::set_VAL_ENTR( oasis_dec_t a_VAL_ENTR )
	{
		dbm_deccopy( &m_VAL_ENTR, &a_VAL_ENTR );
        m_VAL_ENTR_ind_null = 0;
	}
	void TBSW0045::set_VAL_TX_SERV_RVS( oasis_dec_t a_VAL_TX_SERV_RVS )
	{
		dbm_deccopy( &m_VAL_TX_SERV_RVS, &a_VAL_TX_SERV_RVS );
        m_VAL_TX_SERV_RVS_ind_null = 0;
	}
	void TBSW0045::set_VAL_FLAG_QBRA( const std::string& a_VAL_FLAG_QBRA )
	{
		m_VAL_FLAG_QBRA = a_VAL_FLAG_QBRA;
	}
	void TBSW0045::set_COD_TCNL( const std::string& a_COD_TCNL )
	{
		m_COD_TCNL = a_COD_TCNL;
	}
	void TBSW0045::set_COD_TERM( const std::string& a_COD_TERM )
	{
		m_COD_TERM = a_COD_TERM;
	}
	void TBSW0045::set_NUM_STAN( unsigned long a_NUM_STAN )
	{
		m_NUM_STAN = a_NUM_STAN;
        m_NUM_STAN_ind_null = 0;
	}
	void TBSW0045::set_COD_CMPM_TRAN( unsigned long a_COD_CMPM_TRAN )
	{
		m_COD_CMPM_TRAN = a_COD_CMPM_TRAN;
	}
	void TBSW0045::set_VAL_SQUE( oasis_dec_t a_VAL_SQUE )
	{
		dbm_deccopy( &m_VAL_SQUE, &a_VAL_SQUE );
        m_VAL_SQUE_ind_null = 0;
	}
	void TBSW0045::set_VAL_PRES_BRTO( oasis_dec_t a_VAL_PRES_BRTO )
	{
		dbm_deccopy( &m_VAL_PRES_BRTO, &a_VAL_PRES_BRTO );
        m_VAL_PRES_BRTO_ind_null = 0;
	}
	void TBSW0045::set_VAL_RMNR_RCD( oasis_dec_t a_VAL_RMNR_RCD )
	{
		dbm_deccopy( &m_VAL_RMNR_RCD, &a_VAL_RMNR_RCD );
        m_VAL_RMNR_RCD_ind_null = 0;
	}
	void TBSW0045::set_VAL_IOF( oasis_dec_t a_VAL_IOF )
	{
		dbm_deccopy( &m_VAL_IOF, &a_VAL_IOF );
        m_VAL_IOF_ind_null=0;
	}
	void TBSW0045::set_VAL_CPMF( oasis_dec_t a_VAL_CPMF )
	{
		dbm_deccopy( &m_VAL_CPMF, &a_VAL_CPMF );
        m_VAL_CPMF_ind_null = 0;
	}
	void TBSW0045::set_VAL_TAC( oasis_dec_t a_VAL_TAC )
	{
		dbm_deccopy( &m_VAL_TAC, &a_VAL_TAC );
        m_VAL_TAC_ind_null =0;
	}
	void TBSW0045::set_TIP_IOF( const std::string& a_TIP_IOF )
	{
		m_TIP_IOF = a_TIP_IOF;
	}
	oasis_dec_t TBSW0045::get_NUM_RV() const
	{
		return m_NUM_RV;
	}
	unsigned long TBSW0045::get_NUM_PDV() const
	{
		return m_NUM_PDV;
	}
	unsigned long TBSW0045::get_IND_NUM_QBRA() const
	{
		return m_IND_NUM_QBRA;
	}
	dbm_datetime_t TBSW0045::get_DAT_RV() const
	{
		return m_DAT_RV;
	}
	unsigned long TBSW0045::get_COD_BNDR() const
	{
		return m_COD_BNDR;
	}
	const std::string& TBSW0045::get_NOM_BNDR() const
	{
		return m_NOM_BNDR;
	}
	unsigned long TBSW0045::get_COD_PROD() const
	{
		return m_COD_PROD;
	}
	const std::string& TBSW0045::get_NOM_PROD() const
	{
		return m_NOM_PROD;
	}
	oasis_dec_t TBSW0045::get_QTD_CV() const
	{
		return m_QTD_CV;
	}
	oasis_dec_t TBSW0045::get_VAL_TOTL_LQDO() const
	{
		return m_VAL_TOTL_LQDO;
	}
	oasis_dec_t TBSW0045::get_VAL_TOTL_DSCT() const
	{
		return m_VAL_TOTL_DSCT;
	}
	oasis_dec_t TBSW0045::get_VAL_TOTL_GRJT() const
	{
		return m_VAL_TOTL_GRJT;
	}
	oasis_dec_t TBSW0045::get_VAL_TOTL_PAGO() const
	{
		return m_VAL_TOTL_PAGO;
	}
	dbm_datetime_t TBSW0045::get_DAT_CRE_RV() const
	{
		return m_DAT_CRE_RV;
	}
	unsigned long TBSW0045::get_VAL_SIT_RVS() const
	{
		return m_VAL_SIT_RVS;
	}
	dbm_datetime_t TBSW0045::get_DTH_INI() const
	{
		return m_DTH_INI;
	}
	dbm_datetime_t TBSW0045::get_DTH_FIM() const
	{
		return m_DTH_FIM;
	}
	unsigned long TBSW0045::get_QTD_PRCL() const
	{
		return m_QTD_PRCL;
	}
	oasis_dec_t TBSW0045::get_VAL_ENTR() const
	{
		return m_VAL_ENTR;
	}
	oasis_dec_t TBSW0045::get_VAL_TX_SERV_RVS() const
	{
		return m_VAL_TX_SERV_RVS;
	}
	const std::string& TBSW0045::get_VAL_FLAG_QBRA() const
	{
		return m_VAL_FLAG_QBRA;
	}
	const std::string& TBSW0045::get_COD_TCNL() const
	{
		return m_COD_TCNL;
	}
	const std::string& TBSW0045::get_COD_TERM() const
	{
		return m_COD_TERM;
	}
	unsigned long TBSW0045::get_NUM_STAN() const
	{
		return m_NUM_STAN;
	}
	unsigned long TBSW0045::get_COD_CMPM_TRAN() const
	{
		return m_COD_CMPM_TRAN;
	}
	oasis_dec_t TBSW0045::get_VAL_SQUE() const
	{
		return m_VAL_SQUE;
	}
	oasis_dec_t TBSW0045::get_VAL_PRES_BRTO() const
	{
		return m_VAL_PRES_BRTO;
	}
	oasis_dec_t TBSW0045::get_VAL_RMNR_RCD() const
	{
		return m_VAL_RMNR_RCD;
	}
	oasis_dec_t TBSW0045::get_VAL_IOF() const
	{
		return m_VAL_IOF;
	}
	oasis_dec_t TBSW0045::get_VAL_CPMF() const
	{
		return m_VAL_CPMF;
	}
	oasis_dec_t TBSW0045::get_VAL_TAC() const
	{
		return m_VAL_TAC;
	}
	const std::string& TBSW0045::get_TIP_IOF() const
	{
		return m_TIP_IOF;
	}
    
    
/////////////////////////////////////////
//    void TBSW0045::let_EXEMPLO_as_is() const
//    {
//        m_EXEMPLO_ind_null = is_null(m_EXEMPLO) ? DBM_NULL_DATA : 0;
//    }

        void TBSW0045::let_QTD_CV_as_is()
        {
            m_QTD_CV_ind_null = is_null(m_QTD_CV) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_TOTL_LQDO_as_is()
        {
            m_VAL_TOTL_LQDO_ind_null = is_null(m_VAL_TOTL_LQDO) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_TOTL_DSCT_as_is()
        {
            m_VAL_TOTL_DSCT_ind_null = is_null(m_VAL_TOTL_DSCT) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_TOTL_GRJT_as_is()
        {
            m_VAL_TOTL_GRJT_ind_null = is_null(m_VAL_TOTL_GRJT) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_ENTR_as_is()
        {
            m_VAL_ENTR_ind_null = is_null(m_VAL_ENTR) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_TX_SERV_RVS_as_is()
        {
            m_VAL_TX_SERV_RVS_ind_null = is_null(m_VAL_TX_SERV_RVS) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_NUM_STAN_as_is()
        {
            m_NUM_STAN_ind_null = is_null(m_NUM_STAN) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_SQUE_as_is()
        {
            m_VAL_SQUE_ind_null = is_null(m_VAL_SQUE) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_PRES_BRTO_as_is()
        {
            m_VAL_PRES_BRTO_ind_null = is_null(m_VAL_PRES_BRTO) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_RMNR_RCD_as_is()
        {
            m_VAL_RMNR_RCD_ind_null = is_null(m_VAL_RMNR_RCD) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_IOF_as_is()
        {
            m_VAL_IOF_ind_null = is_null(m_VAL_IOF) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_CPMF_as_is()
        {
            m_VAL_CPMF_ind_null = is_null(m_VAL_CPMF) ? DBM_NULL_DATA : 0;
        }
        void TBSW0045::let_VAL_TAC_as_is()
        {
            m_VAL_TAC_ind_null = is_null(m_VAL_TAC) ? DBM_NULL_DATA : 0;
        }

} //namespace dbaccess_common

