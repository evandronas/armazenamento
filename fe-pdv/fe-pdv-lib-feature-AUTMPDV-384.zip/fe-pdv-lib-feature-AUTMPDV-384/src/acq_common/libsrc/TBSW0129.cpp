#include "TBSW0129.hpp"

namespace dbaccess_common
{
    TBSW0129::TBSW0129( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0129::TBSW0129( const std::string& whereClause )
    {
        initialize( );
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0129::~TBSW0129( )
    {
    }

    void TBSW0129::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, NUM_ESTB, COD_TERM, DTH_INI_TRAN, NOM_SITE_ACQR_ORGL, NOM_HOST_ACQR_ORGL, NOM_FE_ACQR_ORGL";
        table_name = "TBSW0129";
        
        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_NUM_ESTB_pos = 3;
        m_COD_TERM_pos = 4;
        m_DTH_INI_TRAN_pos = 5;
        m_NOM_SITE_ACQR_ORGL_pos = 6;
        m_NOM_HOST_ACQR_ORGL_pos = 7;
        m_NOM_FE_ACQR_ORGL_pos = 8;

        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_NUM_ESTB = 0;
        m_COD_TERM = " ";
        m_DTH_INI_TRAN = 0;
        m_NOM_SITE_ACQR_ORGL = " ";
        m_NOM_HOST_ACQR_ORGL = " ";
        m_NOM_FE_ACQR_ORGL = " ";
    }

    void TBSW0129::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_NUM_ESTB_pos, m_NUM_ESTB );
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_DTH_INI_TRAN_pos, &m_DTH_INI_TRAN );
        bind( m_NOM_SITE_ACQR_ORGL_pos, m_NOM_SITE_ACQR_ORGL );
        bind( m_NOM_HOST_ACQR_ORGL_pos, m_NOM_HOST_ACQR_ORGL );
        bind( m_NOM_FE_ACQR_ORGL_pos, m_NOM_FE_ACQR_ORGL );
    }
    
    void TBSW0129::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0129::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    void TBSW0129::set_NUM_ESTB( unsigned long a_NUM_ESTB )
    {
        m_NUM_ESTB = a_NUM_ESTB;
    }
    void TBSW0129::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void TBSW0129::set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN )
    {
        m_DTH_INI_TRAN = a_DTH_INI_TRAN;
    }
    void TBSW0129::set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL )
    {
        m_NOM_SITE_ACQR_ORGL = a_NOM_SITE_ACQR_ORGL;
    }
    void TBSW0129::set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL )
    {
        m_NOM_HOST_ACQR_ORGL = a_NOM_HOST_ACQR_ORGL;
    }
    void TBSW0129::set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL )
    {
        m_NOM_FE_ACQR_ORGL = a_NOM_FE_ACQR_ORGL;
    }

    unsigned long TBSW0129::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    oasis_dec_t TBSW0129::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }
    unsigned long TBSW0129::get_NUM_ESTB( ) const
    {
        return( m_NUM_ESTB );
    }
    const std::string& TBSW0129::get_COD_TERM( ) const
    {
        return( m_COD_TERM );
    }
    const dbm_datetime_t TBSW0129::get_DTH_INI_TRAN( ) const
    {
        return( m_DTH_INI_TRAN );
    }
    const std::string& TBSW0129::get_NOM_SITE_ACQR_ORGL( ) const
    {
        return( m_NOM_SITE_ACQR_ORGL );
    }
    const std::string& TBSW0129::get_NOM_HOST_ACQR_ORGL( ) const
    {
        return( m_NOM_HOST_ACQR_ORGL );
    }
    const std::string& TBSW0129::get_NOM_FE_ACQR_ORGL( ) const
    {
        return( m_NOM_FE_ACQR_ORGL );
    }

} // namespace dbaccess_common


