/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "TBSW0087.hpp"

namespace dbaccess_common
{
	TBSW0087::TBSW0087( )
	{
		query_fields = "NUM_PRFX_CAR, COD_SGL_PAI, COD_STTU_REG, DAT_ATLZ_REG";
		table_name = "TBSW0087";
		where_condition = "";
		m_NUM_PRFX_CAR_pos = 1;
		m_COD_SGL_PAI_pos = 2;
		m_COD_STTU_REG_pos = 3;
		m_DAT_ATLZ_REG_pos = 4;
		m_NUM_PRFX_CAR = "";
		m_COD_SGL_PAI = "";
		m_COD_STTU_REG = "";
		m_DAT_ATLZ_REG = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0087::TBSW0087( const std::string &str )
	{
		query_fields = "NUM_PRFX_CAR, COD_SGL_PAI, COD_STTU_REG, DAT_ATLZ_REG";
		table_name = "TBSW0087";
		where_condition = str;
		m_NUM_PRFX_CAR_pos = 1;
		m_COD_SGL_PAI_pos = 2;
		m_COD_STTU_REG_pos = 3;
		m_DAT_ATLZ_REG_pos = 4;
		m_NUM_PRFX_CAR = "";
		m_COD_SGL_PAI = "";
		m_COD_STTU_REG = "";
		m_DAT_ATLZ_REG = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0087::~TBSW0087( )
	{
	}
	const std::string& TBSW0087::getNUM_PRFX_CAR( ) const
	{
		return m_NUM_PRFX_CAR;
	}
	const std::string& TBSW0087::getCOD_SGL_PAI( ) const
	{
		return m_COD_SGL_PAI;
	}
	const std::string& TBSW0087::getCOD_STTU_REG( ) const
	{
		return m_COD_STTU_REG;
	}
	dbm_datetime_t TBSW0087::getDAT_ATLZ_REG( ) const
	{
		return m_DAT_ATLZ_REG;
	}
	void TBSW0087::setNUM_PRFX_CAR( const std::string& a_NUM_PRFX_CAR )
	{
		m_NUM_PRFX_CAR = a_NUM_PRFX_CAR;
	}
	void TBSW0087::setCOD_SGL_PAI( const std::string& a_COD_SGL_PAI )
	{
		m_COD_SGL_PAI = a_COD_SGL_PAI;
	}
	void TBSW0087::setCOD_STTU_REG( const std::string& a_COD_STTU_REG )
	{
		m_COD_STTU_REG = a_COD_STTU_REG;
	}
	void TBSW0087::setDAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
	{
		m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
	}
	void TBSW0087::bind_columns( )
	{
		bind( m_NUM_PRFX_CAR_pos, m_NUM_PRFX_CAR );
		bind( m_COD_SGL_PAI_pos, m_COD_SGL_PAI );
		bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
		bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
	}
}//namespace dbaccess_common

