#include "TBSW0035.hpp"

namespace dbaccess_common
{
    TBSW0035::TBSW0035()
    {
        query_fields = "NUM_ESTB, COD_TERM, NUM_BXA_TEC, COD_VERS_SFTW, COD_APLV_PNPD, NOM_FNTS_PT_DE_VD, COD_STTU_RPLC, COD_VERS_KRN, NUM_SRE_SMCRD, NOM_OPER, COD_IP_PRMI, NUM_PRTA_PRMI, COD_IP_SECD, NUM_PRTA_SECD, NOM_URL_CNFR, NOM_MODL_CHIP, QTD_TRAN_GPRS_PRMI, QTD_TRAN_GSM_PRMI, QTD_TRAN_GPRS_SECD, QTD_TRAN_GSM_SECD, NUM_SRE_TERM, NUM_SRE_PNPD_EXT, COD_ID_PNPD, DAT_MOV_TRAN, NUM_SEQ_UNC, DTH_BXA_TEC, COD_ORDM_SERV, COD_ID_TEC, COD_OCOR, COD_EPS, NUM_TEL_ESTB, TXT_ENDR_ESTB, TIP_TCNL, QTD_TNTA_PRMI, QTD_TNTA_SECD, NUM_TEL_ADIC_ESTB";
        table_name = "TBSW0035";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
        inicializar( );
    }

    TBSW0035::TBSW0035( const std::string& whereClause )
    {
        table_name = "TBSW0035";
        query_fields = "NUM_ESTB, COD_TERM, NUM_BXA_TEC, COD_VERS_SFTW, COD_APLV_PNPD, NOM_FNTS_PT_DE_VD, COD_STTU_RPLC, COD_VERS_KRN, NUM_SRE_SMCRD, NOM_OPER, COD_IP_PRMI, NUM_PRTA_PRMI, COD_IP_SECD, NUM_PRTA_SECD, NOM_URL_CNFR, NOM_MODL_CHIP, QTD_TRAN_GPRS_PRMI, QTD_TRAN_GSM_PRMI, QTD_TRAN_GPRS_SECD, QTD_TRAN_GSM_SECD, NUM_SRE_TERM, NUM_SRE_PNPD_EXT, COD_ID_PNPD, DAT_MOV_TRAN, NUM_SEQ_UNC, DTH_BXA_TEC, COD_ORDM_SERV, COD_ID_TEC, COD_OCOR, COD_EPS, NUM_TEL_ESTB, TXT_ENDR_ESTB, TIP_TCNL, QTD_TNTA_PRMI, QTD_TNTA_SECD, NUM_TEL_ADIC_ESTB";
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
        inicializar( );
    }

    TBSW0035::~TBSW0035()
    {
    }

    void TBSW0035::inicializar()
    {
        m_NUM_ESTB_pos = 1;
        m_COD_TERM_pos = 2;
        m_NUM_BXA_TEC_pos = 3;
        m_COD_VERS_SFTW_pos = 4;
        m_COD_APLV_PNPD_pos = 5;
        m_NOM_FNTS_PT_DE_VD_pos = 6;
        m_COD_STTU_RPLC_pos = 7;
        m_COD_VERS_KRN_pos = 8;
        m_NUM_SRE_SMCRD_pos = 9;
        m_NOM_OPER_pos = 10;
        m_COD_IP_PRMI_pos = 11;
        m_NUM_PRTA_PRMI_pos = 12;
        m_COD_IP_SECD_pos = 13;
        m_NUM_PRTA_SECD_pos = 14;
        m_NOM_URL_CNFR_pos = 15;
        m_NOM_MODL_CHIP_pos = 16;
        m_QTD_TRAN_GPRS_PRMI_pos = 17;
        m_QTD_TRAN_GSM_PRMI_pos = 18;
        m_QTD_TRAN_GPRS_SECD_pos = 19;
        m_QTD_TRAN_GSM_SECD_pos = 20;
        m_NUM_SRE_TERM_pos = 21;
        m_NUM_SRE_PNPD_EXT_pos = 22;
        m_COD_ID_PNPD_pos = 23;
        m_DAT_MOV_TRAN_pos = 24;
        m_NUM_SEQ_UNC_pos = 25;
        m_DTH_BXA_TEC_pos = 26;
        m_COD_ORDM_SERV_pos = 27;
        m_COD_ID_TEC_pos = 28;
        m_COD_OCOR_pos = 29;
        m_COD_EPS_pos = 30;
        m_NUM_TEL_ESTB_pos = 31;
        m_TXT_ENDR_ESTB_pos = 32;
        m_TIP_TCNL_pos = 33;
        m_QTD_TNTA_PRMI_pos = 34;
        m_QTD_TNTA_SECD_pos = 35;
		m_NUM_TEL_ADIC_ESTB_pos = 36;

        m_NUM_ESTB = 0;
        m_COD_TERM = " ";
        dbm_longtodec( &m_NUM_BXA_TEC, 0 );
        m_COD_VERS_SFTW = " ";
        m_COD_APLV_PNPD = " ";
        m_NOM_FNTS_PT_DE_VD = " ";
        m_COD_STTU_RPLC = " ";
        m_COD_VERS_KRN = " ";
        m_NUM_SRE_SMCRD = " ";
        m_NOM_OPER = " ";
        m_COD_IP_PRMI = " ";
        m_NUM_PRTA_PRMI = 0;
        m_COD_IP_SECD = " ";
        m_NUM_PRTA_SECD = 0;
        m_NOM_URL_CNFR = " ";
        m_NOM_MODL_CHIP = " ";
        m_QTD_TRAN_GPRS_PRMI = 0;
        m_QTD_TRAN_GSM_PRMI = 0;
        m_QTD_TRAN_GPRS_SECD = 0;
        m_QTD_TRAN_GSM_SECD = 0;
        m_NUM_SRE_TERM = " ";
        m_NUM_SRE_PNPD_EXT = " ";
        m_COD_ID_PNPD = " ";
        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_DTH_BXA_TEC = 0;
        m_COD_ORDM_SERV = "";
        m_COD_ID_TEC = "";
        m_COD_OCOR = "";
        m_COD_EPS = "";
        dbm_longtodec( &m_NUM_TEL_ESTB, 0 );
        m_TXT_ENDR_ESTB = "";
        m_TIP_TCNL = " ";
        m_QTD_TNTA_PRMI = 0;
        m_QTD_TNTA_SECD = 0;
		m_NUM_TEL_ADIC_ESTB = "";

        m_NUM_TEL_ESTB_ind_null = DBM_NULL_DATA;
        m_DTH_BXA_TEC_ind_null = DBM_NULL_DATA;
        m_NUM_PRTA_PRMI_ind_null = DBM_NULL_DATA;
        m_NUM_PRTA_SECD_ind_null = DBM_NULL_DATA;
        m_QTD_TRAN_GPRS_PRMI_ind_null = DBM_NULL_DATA;
        m_QTD_TRAN_GSM_PRMI_ind_null = DBM_NULL_DATA;
        m_QTD_TRAN_GPRS_SECD_ind_null = DBM_NULL_DATA;
        m_QTD_TRAN_GSM_SECD_ind_null = DBM_NULL_DATA;
        m_QTD_TNTA_PRMI_ind_null = DBM_NULL_DATA;
        m_QTD_TNTA_SECD_ind_null = DBM_NULL_DATA;
    }

    void TBSW0035::bind_columns()
    {
        bind( m_NUM_ESTB_pos, m_NUM_ESTB );
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_NUM_BXA_TEC_pos, m_NUM_BXA_TEC );
        bind( m_COD_VERS_SFTW_pos, m_COD_VERS_SFTW );
        bind( m_COD_APLV_PNPD_pos, m_COD_APLV_PNPD );
        bind( m_NOM_FNTS_PT_DE_VD_pos, m_NOM_FNTS_PT_DE_VD );
        bind( m_COD_STTU_RPLC_pos, m_COD_STTU_RPLC );
        bind( m_COD_VERS_KRN_pos, m_COD_VERS_KRN );
        bind( m_NUM_SRE_SMCRD_pos, m_NUM_SRE_SMCRD );
        bind( m_NOM_OPER_pos, m_NOM_OPER );
        bind( m_COD_IP_PRMI_pos, m_COD_IP_PRMI );
        bind( m_NUM_PRTA_PRMI_pos, m_NUM_PRTA_PRMI, &m_NUM_PRTA_PRMI_ind_null );
        bind( m_COD_IP_SECD_pos, m_COD_IP_SECD );
        bind( m_NUM_PRTA_SECD_pos, m_NUM_PRTA_SECD, &m_NUM_PRTA_SECD_ind_null );
        bind( m_NOM_URL_CNFR_pos, m_NOM_URL_CNFR );
        bind( m_NOM_MODL_CHIP_pos, m_NOM_MODL_CHIP );
        bind( m_QTD_TRAN_GPRS_PRMI_pos, m_QTD_TRAN_GPRS_PRMI, &m_QTD_TRAN_GPRS_PRMI_ind_null );
        bind( m_QTD_TRAN_GSM_PRMI_pos, m_QTD_TRAN_GSM_PRMI, &m_QTD_TRAN_GSM_PRMI_ind_null );
        bind( m_QTD_TRAN_GPRS_SECD_pos, m_QTD_TRAN_GPRS_SECD, &m_QTD_TRAN_GPRS_SECD_ind_null );
        bind( m_QTD_TRAN_GSM_SECD_pos, m_QTD_TRAN_GSM_SECD, &m_QTD_TRAN_GSM_SECD_ind_null );
        bind( m_NUM_SRE_TERM_pos, m_NUM_SRE_TERM );
        bind( m_NUM_SRE_PNPD_EXT_pos, m_NUM_SRE_PNPD_EXT );
        bind( m_COD_ID_PNPD_pos, m_COD_ID_PNPD );
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_DTH_BXA_TEC_pos, &m_DTH_BXA_TEC, &m_DTH_BXA_TEC_ind_null );
        bind( m_COD_ORDM_SERV_pos, m_COD_ORDM_SERV );
        bind( m_COD_ID_TEC_pos, m_COD_ID_TEC );
        bind( m_COD_OCOR_pos, m_COD_OCOR );
        bind( m_COD_EPS_pos, m_COD_EPS );
        bind( m_NUM_TEL_ESTB_pos, m_NUM_TEL_ESTB , &m_NUM_TEL_ESTB_ind_null); // NUM_TEL_ESTB nulo
        bind( m_TXT_ENDR_ESTB_pos, m_TXT_ENDR_ESTB );
        bind( m_TIP_TCNL_pos, m_TIP_TCNL );
        bind( m_QTD_TNTA_PRMI_pos, m_QTD_TNTA_PRMI, &m_QTD_TNTA_PRMI_ind_null );
        bind( m_QTD_TNTA_SECD_pos, m_QTD_TNTA_SECD, &m_QTD_TNTA_SECD_ind_null );
		bind( m_NUM_TEL_ADIC_ESTB_pos, m_NUM_TEL_ADIC_ESTB );
    }
    void TBSW0035::set_NUM_ESTB( unsigned long a_NUM_ESTB )
    {
        m_NUM_ESTB = a_NUM_ESTB;
    }
    void TBSW0035::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void TBSW0035::set_NUM_BXA_TEC( oasis_dec_t a_NUM_BXA_TEC )
    {
        dbm_deccopy( &m_NUM_BXA_TEC, &a_NUM_BXA_TEC );
    }
    void TBSW0035::set_COD_VERS_SFTW( const std::string& a_COD_VERS_SFTW )
    {
        m_COD_VERS_SFTW = a_COD_VERS_SFTW;
    }
    void TBSW0035::set_COD_APLV_PNPD( const std::string& a_COD_APLV_PNPD )
    {
        m_COD_APLV_PNPD = a_COD_APLV_PNPD;
    }
    void TBSW0035::set_NOM_FNTS_PT_DE_VD( const std::string& a_NOM_FNTS_PT_DE_VD )
    {
        m_NOM_FNTS_PT_DE_VD = a_NOM_FNTS_PT_DE_VD;
    }
    void TBSW0035::set_COD_STTU_RPLC( const std::string& a_COD_STTU_RPLC )
    {
        m_COD_STTU_RPLC = a_COD_STTU_RPLC;
    }
    void TBSW0035::set_COD_VERS_KRN( const std::string& a_COD_VERS_KRN )
    {
        m_COD_VERS_KRN = a_COD_VERS_KRN;
    }
    void TBSW0035::set_NUM_SRE_SMCRD( const std::string& a_NUM_SRE_SMCRD )
    {
        m_NUM_SRE_SMCRD = a_NUM_SRE_SMCRD;
    }
    void TBSW0035::set_NOM_OPER( const std::string& a_NOM_OPER )
    {
        m_NOM_OPER = a_NOM_OPER;
    }
    void TBSW0035::set_COD_IP_PRMI( const std::string& a_COD_IP_PRMI )
    {
        m_COD_IP_PRMI = a_COD_IP_PRMI;
    }
    void TBSW0035::set_NUM_PRTA_PRMI( unsigned long a_NUM_PRTA_PRMI )
    {
        m_NUM_PRTA_PRMI = a_NUM_PRTA_PRMI;
        m_NUM_PRTA_PRMI_ind_null = 0;
    }
    void TBSW0035::set_COD_IP_SECD( const std::string& a_COD_IP_SECD )
    {
        m_COD_IP_SECD = a_COD_IP_SECD;
    }
    void TBSW0035::set_NUM_PRTA_SECD( unsigned long a_NUM_PRTA_SECD )
    {
        m_NUM_PRTA_SECD = a_NUM_PRTA_SECD;
        m_NUM_PRTA_SECD_ind_null = 0;
    }
    void TBSW0035::set_NOM_URL_CNFR( const std::string& a_NOM_URL_CNFR )
    {
        m_NOM_URL_CNFR = a_NOM_URL_CNFR;
    }
    void TBSW0035::set_NOM_MODL_CHIP( const std::string& a_NOM_MODL_CHIP )
    {
        m_NOM_MODL_CHIP = a_NOM_MODL_CHIP;
    }
    void TBSW0035::set_QTD_TRAN_GPRS_PRMI( unsigned long a_QTD_TRAN_GPRS_PRMI )
    {
        m_QTD_TRAN_GPRS_PRMI = a_QTD_TRAN_GPRS_PRMI;
        m_QTD_TRAN_GPRS_PRMI_ind_null = 0;
    }
    void TBSW0035::set_QTD_TRAN_GSM_PRMI( unsigned long a_QTD_TRAN_GSM_PRMI )
    {
        m_QTD_TRAN_GSM_PRMI = a_QTD_TRAN_GSM_PRMI;
        m_QTD_TRAN_GSM_PRMI_ind_null = 0;
    }
    void TBSW0035::set_QTD_TRAN_GPRS_SECD( unsigned long a_QTD_TRAN_GPRS_SECD )
    {
        m_QTD_TRAN_GPRS_SECD = a_QTD_TRAN_GPRS_SECD;
        m_QTD_TRAN_GPRS_SECD_ind_null = 0;
    }
    void TBSW0035::set_QTD_TRAN_GSM_SECD( unsigned long a_QTD_TRAN_GSM_SECD )
    {
        m_QTD_TRAN_GSM_SECD = a_QTD_TRAN_GSM_SECD;
        m_QTD_TRAN_GSM_SECD_ind_null = 0;
    }
    void TBSW0035::set_NUM_SRE_TERM( const std::string& a_NUM_SRE_TERM )
    {
        m_NUM_SRE_TERM = a_NUM_SRE_TERM;
    }
    void TBSW0035::set_NUM_SRE_PNPD_EXT( const std::string& a_NUM_SRE_PNPD_EXT )
    {
        m_NUM_SRE_PNPD_EXT = a_NUM_SRE_PNPD_EXT;
    }
    void TBSW0035::set_COD_ID_PNPD( const std::string& a_COD_ID_PNPD )
    {
        m_COD_ID_PNPD = a_COD_ID_PNPD;
    }
    void TBSW0035::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0035::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    void TBSW0035::set_DTH_BXA_TEC( dbm_datetime_t a_DTH_BXA_TEC )
    {
        m_DTH_BXA_TEC = a_DTH_BXA_TEC;
        m_DTH_BXA_TEC_ind_null = 0;
    }
    void TBSW0035::set_COD_ORDM_SERV( const std::string& a_COD_ORDM_SERV )
    {
        m_COD_ORDM_SERV = a_COD_ORDM_SERV;
    }
    void TBSW0035::set_COD_ID_TEC( const std::string& a_COD_ID_TEC )
    {
        m_COD_ID_TEC = a_COD_ID_TEC;
    }
    void TBSW0035::set_COD_OCOR( const std::string& a_COD_OCOR )
    {
        m_COD_OCOR = a_COD_OCOR;
    }
    void TBSW0035::set_COD_EPS( const std::string& a_COD_EPS )
    {
        m_COD_EPS = a_COD_EPS;
    }
    void TBSW0035::set_NUM_TEL_ESTB( oasis_dec_t a_NUM_TEL_ESTB )
    {
        dbm_deccopy( &m_NUM_TEL_ESTB, &a_NUM_TEL_ESTB );
        m_NUM_TEL_ESTB_ind_null = 0; //DBM_NULL_DATA;
    }
    void TBSW0035::set_TXT_ENDR_ESTB( const std::string& a_TXT_ENDR_ESTB )
    {
        m_TXT_ENDR_ESTB = a_TXT_ENDR_ESTB;
    }
    void TBSW0035::set_TIP_TCNL( const std::string& a_TIP_TCNL )
    {
        m_TIP_TCNL = a_TIP_TCNL;
    }
    void TBSW0035::set_QTD_TNTA_PRMI( unsigned long a_QTD_TNTA_PRMI )
    {
        m_QTD_TNTA_PRMI = a_QTD_TNTA_PRMI;
        m_QTD_TNTA_PRMI_ind_null = 0;
    }
    void TBSW0035::set_QTD_TNTA_SECD( unsigned long a_QTD_TNTA_SECD )
    {
        m_QTD_TNTA_SECD = a_QTD_TNTA_SECD;
        m_QTD_TNTA_SECD_ind_null = 0;
    }
	void TBSW0035::set_NUM_TEL_ADIC_ESTB(const std::string& a_NUM_TEL_ADIC_ESTB )
	{
		m_NUM_TEL_ADIC_ESTB = a_NUM_TEL_ADIC_ESTB;
	}
	
    unsigned long TBSW0035::get_NUM_ESTB() const
    {
        return m_NUM_ESTB;
    }
    const std::string& TBSW0035::get_COD_TERM() const
    {
        return m_COD_TERM;
    }
    oasis_dec_t TBSW0035::get_NUM_BXA_TEC() const
    {
        return m_NUM_BXA_TEC;
    }
    const std::string& TBSW0035::get_COD_VERS_SFTW() const
    {
        return m_COD_VERS_SFTW;
    }
    const std::string& TBSW0035::get_COD_APLV_PNPD() const
    {
        return m_COD_APLV_PNPD;
    }
    const std::string& TBSW0035::get_NOM_FNTS_PT_DE_VD() const
    {
        return m_NOM_FNTS_PT_DE_VD;
    }
    const std::string& TBSW0035::get_COD_STTU_RPLC() const
    {
        return m_COD_STTU_RPLC;
    }
    const std::string& TBSW0035::get_COD_VERS_KRN() const
    {
        return m_COD_VERS_KRN;
    }
    const std::string& TBSW0035::get_NUM_SRE_SMCRD() const
    {
        return m_NUM_SRE_SMCRD;
    }
    const std::string& TBSW0035::get_NOM_OPER() const
    {
        return m_NOM_OPER;
    }
    const std::string& TBSW0035::get_COD_IP_PRMI() const
    {
        return m_COD_IP_PRMI;
    }
    unsigned long TBSW0035::get_NUM_PRTA_PRMI() const
    {
        return m_NUM_PRTA_PRMI;
    }
    const std::string& TBSW0035::get_COD_IP_SECD() const
    {
        return m_COD_IP_SECD;
    }
    unsigned long TBSW0035::get_NUM_PRTA_SECD() const
    {
        return m_NUM_PRTA_SECD;
    }
    const std::string& TBSW0035::get_NOM_URL_CNFR() const
    {
        return m_NOM_URL_CNFR;
    }
    const std::string& TBSW0035::get_NOM_MODL_CHIP() const
    {
        return m_NOM_MODL_CHIP;
    }
    unsigned long TBSW0035::get_QTD_TRAN_GPRS_PRMI() const
    {
        return m_QTD_TRAN_GPRS_PRMI;
    }
    unsigned long TBSW0035::get_QTD_TRAN_GSM_PRMI() const
    {
        return m_QTD_TRAN_GSM_PRMI;
    }
    unsigned long TBSW0035::get_QTD_TRAN_GPRS_SECD() const
    {
        return m_QTD_TRAN_GPRS_SECD;
    }
    unsigned long TBSW0035::get_QTD_TRAN_GSM_SECD() const
    {
        return m_QTD_TRAN_GSM_SECD;
    }
    const std::string& TBSW0035::get_NUM_SRE_TERM() const
    {
        return m_NUM_SRE_TERM;
    }
    const std::string& TBSW0035::get_NUM_SRE_PNPD_EXT() const
    {
        return m_NUM_SRE_PNPD_EXT;
    }
    const std::string& TBSW0035::get_COD_ID_PNPD() const
    {
        return m_COD_ID_PNPD;
    }
    unsigned long TBSW0035::get_DAT_MOV_TRAN() const
    {
        return m_DAT_MOV_TRAN;
    }
    oasis_dec_t TBSW0035::get_NUM_SEQ_UNC() const
    {
        return m_NUM_SEQ_UNC;
    }
    dbm_datetime_t TBSW0035::get_DTH_BXA_TEC() const
    {
        return m_DTH_BXA_TEC;
    }
    const std::string& TBSW0035::get_COD_ORDM_SERV() const
    {
        return m_COD_ORDM_SERV;
    }
    const std::string& TBSW0035::get_COD_ID_TEC() const
    {
        return m_COD_ID_TEC;
    }
    const std::string& TBSW0035::get_COD_OCOR() const
    {
        return m_COD_OCOR;
    }
    const std::string& TBSW0035::get_COD_EPS() const
    {
        return m_COD_EPS;
    }
    oasis_dec_t TBSW0035::get_NUM_TEL_ESTB() const
    {
        return m_NUM_TEL_ESTB;
    }
    const std::string& TBSW0035::get_TXT_ENDR_ESTB() const
    {
        return m_TXT_ENDR_ESTB;
    }
    const std::string& TBSW0035::get_TIP_TCNL() const
    {
        return m_TIP_TCNL;
    }
    unsigned long TBSW0035::get_QTD_TNTA_PRMI() const
    {
        return m_QTD_TNTA_PRMI;
    }
    unsigned long TBSW0035::get_QTD_TNTA_SECD() const
    {
        return m_QTD_TNTA_SECD;
    }
	const std::string& TBSW0035::get_NUM_TEL_ADIC_ESTB() const
	{
		return m_NUM_TEL_ADIC_ESTB;
	}
	
    void TBSW0035::let_NUM_TEL_ESTB_as_is()
    {
        m_NUM_TEL_ESTB_ind_null = is_null(&m_NUM_TEL_ESTB) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_DTH_BXA_TEC_as_is()
    {
        m_DTH_BXA_TEC_ind_null = is_null(&m_DTH_BXA_TEC) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_NUM_PRTA_PRMI_as_is()
    {
        m_NUM_PRTA_PRMI_ind_null = is_null(&m_NUM_PRTA_PRMI) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_NUM_PRTA_SECD_as_is()
    {
        m_NUM_PRTA_SECD_ind_null = is_null(&m_NUM_PRTA_SECD) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_QTD_TRAN_GPRS_PRMI_as_is()
    {
        m_QTD_TRAN_GPRS_PRMI_ind_null = is_null(&m_QTD_TRAN_GPRS_PRMI) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_QTD_TRAN_GSM_PRMI_as_is()
    {
        m_QTD_TRAN_GSM_PRMI_ind_null = is_null(&m_QTD_TRAN_GSM_PRMI) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_QTD_TRAN_GPRS_SECD_as_is()
    {
        m_QTD_TRAN_GPRS_SECD_ind_null = is_null(&m_QTD_TRAN_GPRS_SECD) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_QTD_TRAN_GSM_SECD_as_is()
    {
        m_QTD_TRAN_GSM_SECD_ind_null = is_null(&m_QTD_TRAN_GSM_SECD) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_QTD_TNTA_PRMI_as_is()
    {
        m_QTD_TNTA_PRMI_ind_null = is_null(&m_QTD_TNTA_PRMI) ? DBM_NULL_DATA : 0;
    }
    void TBSW0035::let_QTD_TNTA_SECD_as_is()
    {
        m_QTD_TNTA_SECD_ind_null = is_null(&m_QTD_TNTA_SECD) ? DBM_NULL_DATA : 0;
    }

} //namespace dbaccess_common