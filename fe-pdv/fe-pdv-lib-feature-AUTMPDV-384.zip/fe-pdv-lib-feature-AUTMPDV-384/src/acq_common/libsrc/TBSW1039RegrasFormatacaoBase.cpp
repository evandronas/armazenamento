
#include<AcqUtils.hpp>
#include<TBSW1039RegrasFormatacaoBase.hpp>

TBSW1039RegrasFormatacaoBase::TBSW1039RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW1039RegrasFormatacaoBase::~TBSW1039RegrasFormatacaoBase( )
{
}

void TBSW1039RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw1039, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw1039, params );
    }
}

void TBSW1039RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw1039, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw1039, params );
    }
}

void TBSW1039RegrasFormatacaoBase::COD_MSG_ISO_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MSG_ISO_ORGL( tbsw1039, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MSG_ISO_ORGL( tbsw1039, params );
    }
}

void TBSW1039RegrasFormatacaoBase::NUM_STAN_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_STAN_ORGL( tbsw1039, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_STAN_ORGL( tbsw1039, params );
    }
}

void TBSW1039RegrasFormatacaoBase::DTH_STTU_TRAN_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_STTU_TRAN_ORGL( tbsw1039, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_STTU_TRAN_ORGL( tbsw1039, params );
    }
}

void TBSW1039RegrasFormatacaoBase::COD_ISTT_ACQR_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_ISTT_ACQR_ORGL( tbsw1039, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_ISTT_ACQR_ORGL( tbsw1039, params );
    }
}


void TBSW1039RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW1039RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW1039RegrasFormatacaoBase::gen_COD_MSG_ISO_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    tbsw1039.set_COD_MSG_ISO_ORGL( params.origmsg );
}

void TBSW1039RegrasFormatacaoBase::gen_NUM_STAN_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, params.origtrace.c_str( ), 0 );
    tbsw1039.set_NUM_STAN_ORGL( l_dect );
}

void TBSW1039RegrasFormatacaoBase::gen_DTH_STTU_TRAN_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW1039RegrasFormatacaoBase::gen_COD_ISTT_ACQR_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    WARNING_INVALID_FUNCTION;
}


void TBSW1039RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    tbsw1039.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW1039RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw1039.set_NUM_SEQ_UNC( l_dect );
}

void TBSW1039RegrasFormatacaoBase::insert_COD_MSG_ISO_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    gen_COD_MSG_ISO_ORGL( tbsw1039, params );
}

void TBSW1039RegrasFormatacaoBase::insert_NUM_STAN_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    gen_NUM_STAN_ORGL( tbsw1039, params );
}

void TBSW1039RegrasFormatacaoBase::insert_DTH_STTU_TRAN_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    tbsw1039.set_DTH_STTU_TRAN_ORGL( AcqUtils::dateTime( params.origdate, params.origtime ) );
}

void TBSW1039RegrasFormatacaoBase::insert_COD_ISTT_ACQR_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0", 0 );
    tbsw1039.set_COD_ISTT_ACQR_ORGL( l_dect );
}


void TBSW1039RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW1039RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW1039RegrasFormatacaoBase::update_COD_MSG_ISO_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    gen_COD_MSG_ISO_ORGL( tbsw1039, params );
}

void TBSW1039RegrasFormatacaoBase::update_NUM_STAN_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    gen_NUM_STAN_ORGL( tbsw1039, params );
}

void TBSW1039RegrasFormatacaoBase::update_DTH_STTU_TRAN_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW1039RegrasFormatacaoBase::update_COD_ISTT_ACQR_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
{
    WARNING_INVALID_FUNCTION;
}
