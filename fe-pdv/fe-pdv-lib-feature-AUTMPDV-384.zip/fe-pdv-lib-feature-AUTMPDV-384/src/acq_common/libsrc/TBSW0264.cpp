#include "TBSW0264.hpp"

namespace dbaccess_pdv
{

TBSW0264::TBSW0264()
{
	initialize();

	where_condition = "";
    update_database_id(dbaccess::endpoint::DB_CAPTURA);

	m_log = logger::DebugWriter::getInstance();
}

TBSW0264::TBSW0264( const std::string& whereClause )
{
        initialize();

        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);

        m_log = logger::DebugWriter::getInstance();
}

TBSW0264::~TBSW0264()
{
}


void TBSW0264::bind_columns()
{
	bind( m_COD_EMP_pos,			m_COD_EMP );
	bind( m_COD_RAM_ATVD_pos,		m_COD_RAM_ATVD );
	bind( m_COD_RAM_ATVD_EMP_pos,	m_COD_RAM_ATVD_EMP );
	bind( m_IND_PRE_AUT_pos,		m_IND_PRE_AUT );
	bind( m_DTH_ATLZ_REG_pos,		&m_DTH_ATLZ_REG );

}

void TBSW0264::initialize()
{
	query_fields = "COD_EMP, COD_RAM_ATVD, COD_RAM_ATVD_EMP, IND_PRE_AUT, DTH_ATLZ_REG";

        table_name = "TBSW0264";

        m_COD_EMP_pos			= 1;
        m_COD_RAM_ATVD_pos		= 2;
        m_COD_RAM_ATVD_EMP_pos	= 3;
        m_IND_PRE_AUT_pos		= 4;
        m_DTH_ATLZ_REG_pos		= 5;

        m_COD_EMP				= 0;
        m_COD_RAM_ATVD			= 0;
        m_COD_RAM_ATVD_EMP		= 0;
        m_IND_PRE_AUT			= " ";
        m_DTH_ATLZ_REG			= 0;

}


void TBSW0264::set_COD_EMP( unsigned long a_COD_EMP )
{
	m_COD_EMP = a_COD_EMP;
}

void TBSW0264::set_COD_RAM_ATVD( unsigned long a_COD_RAM_ATVD )
{
	m_COD_RAM_ATVD = a_COD_RAM_ATVD;
}

void TBSW0264::set_COD_RAM_ATVD_EMP( unsigned long a_COD_RAM_ATVD_EMP )
{
	m_COD_RAM_ATVD_EMP = a_COD_RAM_ATVD_EMP;
}

void TBSW0264::set_IND_PRE_AUT( const std::string& a_IND_PRE_AUT )
{
	m_IND_PRE_AUT = a_IND_PRE_AUT;
}

void TBSW0264::set_DTH_ATLZ_REG( dbm_datetime_t  a_DTH_ATLZ_REG )
{
	m_DTH_ATLZ_REG = a_DTH_ATLZ_REG;
}


unsigned long TBSW0264::get_COD_EMP() const
{
	return m_COD_EMP;
}

unsigned long TBSW0264::get_COD_RAM_ATVD() const
{
	return m_COD_RAM_ATVD;
}

unsigned long TBSW0264::get_COD_RAM_ATVD_EMP() const
{
	return m_COD_RAM_ATVD_EMP;
}

const std::string TBSW0264::get_IND_PRE_AUT() const
{
	return m_IND_PRE_AUT;
}

dbm_datetime_t TBSW0264::get_DTH_ATLZ_REG() const
{
	return m_DTH_ATLZ_REG;
}

} //namespace dbaccess_pdv

