#include<TBSW0139RegrasFormatacaoBase.hpp>

TBSW0139RegrasFormatacaoBase::TBSW0139RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0139RegrasFormatacaoBase::~TBSW0139RegrasFormatacaoBase( )
{
}

void TBSW0139RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::COD_TERM( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TERM( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TERM( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::COD_PNPD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PNPD_PDV( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PNPD_PDV( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::TIP_CIP( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_CIP( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_CIP( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NUM_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_PDV( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_PDV( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NUM_VERS_SRVD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_VERS_SRVD_PDV( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_VERS_SRVD_PDV( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NUM_VERS_CLIT( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_VERS_CLIT( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_VERS_CLIT( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NUM_VERS_APLV_RCD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_VERS_APLV_RCD( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_VERS_APLV_RCD( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NUM_VERS_SFTW_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_VERS_SFTW_BBLT_PNPD( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_VERS_SFTW_BBLT_PNPD( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NUM_VERS_ESPF_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_VERS_ESPF_BBLT_PNPD( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_VERS_ESPF_BBLT_PNPD( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::COD_FBRC_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_FBRC_PDV( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_FBRC_PDV( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ACQR_ORGL( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ACQR_ORGL( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ACQR_ORGL( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ACQR_ORGL( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ACQR_ORGL( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ACQR_ORGL( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_SITE_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ISSR( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ISSR( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_HOST_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ISSR( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ISSR( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_FE_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ISSR( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ISSR( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ACQR_ATLZ( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ACQR_ATLZ( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ACQR_ATLZ( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ACQR_ATLZ( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ACQR_ATLZ( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ACQR_ATLZ( tbsw0139, params );
    }
}

void TBSW0139RegrasFormatacaoBase::TIP_GRU_TERM( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_GRU_TERM( tbsw0139, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_GRU_TERM( tbsw0139, params );
    }
}

// Tratamentos genericos

void TBSW0139RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_COD_TERM( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_COD_PNPD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_TIP_CIP( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if ( params.indCripto.size( ) > 0 ) 
    {
        tbsw0139.set_TIP_CIP( params.indCripto.substr( 0, 2 ) );
    }
    else
    {
        tbsw0139.set_TIP_CIP( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0139RegrasFormatacaoBase::gen_NUM_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_NUM_VERS_SRVD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_NUM_VERS_CLIT( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_NUM_VERS_APLV_RCD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_NUM_VERS_SFTW_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_NUM_VERS_ESPF_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_COD_FBRC_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.nom_site_acqr.size( ) != 0 )
    {
        tbsw0139.set_NOM_SITE_ACQR_ORGL( params.nom_site_acqr );
    }
    else
    {
        tbsw0139.set_NOM_SITE_ACQR_ORGL( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.nom_host_acqr.size( ) != 0 )
    {
        tbsw0139.set_NOM_HOST_ACQR_ORGL( params.nom_host_acqr );
    }
    else
    {
        tbsw0139.set_NOM_HOST_ACQR_ORGL( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.nom_fe_acqr.size( ) != 0 )
    {
        tbsw0139.set_NOM_FE_ACQR_ORGL( params.nom_fe_acqr );
    }
    else
    {
        tbsw0139.set_NOM_FE_ACQR_ORGL( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_SITE_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if ( !params.nom_site_issr.empty( ) )
    {
        tbsw0139.set_NOM_SITE_ISSR( params.nom_site_issr );
    }
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_HOST_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if ( !params.nom_host_issr.empty( ) )
    {
        tbsw0139.set_NOM_HOST_ISSR( params.nom_host_issr );
    }
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_FE_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if ( !params.nom_fe_issr.empty( ) )
    {
        tbsw0139.set_NOM_FE_ISSR( params.nom_fe_issr );
    }
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::gen_TIP_GRU_TERM( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

// Tratamentos de INSERTS

void TBSW0139RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    tbsw0139.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0139RegrasFormatacaoBase::insert_COD_TERM( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid.size( ) != 0 )
    {
        tbsw0139.set_COD_TERM( params.termid.substr( 0, 8 ) );
    }
    else
    {
        tbsw0139.set_COD_TERM( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0139RegrasFormatacaoBase::insert_COD_PNPD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid_type != "HY8583" )
    {
        if ( params.codver.size( ) > 0 )
        {
            tbsw0139.set_COD_PNPD_PDV( params.codver.substr( 0, 14 ) );
        }
        else
        {
            tbsw0139.set_COD_PNPD_PDV( params.codver );
        }
    }
}

void TBSW0139RegrasFormatacaoBase::insert_TIP_CIP( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_TIP_CIP( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::insert_NUM_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    tbsw0139.set_NUM_PDV( params.termloc );
    if (tbsw0139.get_NUM_PDV() > 999999999)
        tbsw0139.set_NUM_PDV( 0 );
}

void TBSW0139RegrasFormatacaoBase::insert_NUM_VERS_SRVD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::insert_NUM_VERS_CLIT( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid_type != "HY8583" )
    {
        if ( params.num_vers_clit.size( ) > 0 )
        {
            tbsw0139.set_NUM_VERS_CLIT( params.num_vers_clit.substr( 0, 10 ) );
        }
    }
}

void TBSW0139RegrasFormatacaoBase::insert_NUM_VERS_APLV_RCD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid_type != "HY8583" )
    {
        if ( params.num_vers_aplv_rcd.size( ) > 0 )
        {
            tbsw0139.set_NUM_VERS_APLV_RCD( params.num_vers_aplv_rcd.substr( 0, 10 ) );
        }
    }
}

void TBSW0139RegrasFormatacaoBase::insert_NUM_VERS_SFTW_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid_type != "HY8583" )
    {
        if ( params.versSotfwBiblCompartPinpad.size( ) > 0 )
        {
            tbsw0139.set_NUM_VERS_SFTW_BBLT_PNPD( params.versSotfwBiblCompartPinpad.substr( 0, 16 ) );
        }
        else
        {
            tbsw0139.set_NUM_VERS_SFTW_BBLT_PNPD( std::string( "" ) );
        }
    }
}

void TBSW0139RegrasFormatacaoBase::insert_NUM_VERS_ESPF_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid_type != "HY8583" )
    {
        if ( params.versEspecBiblCompartPinpad.size( ) > 0 )
        {
           tbsw0139.set_NUM_VERS_ESPF_BBLT_PNPD( params.versEspecBiblCompartPinpad.substr( 0, 4 ) );
        }
        else
        {
           tbsw0139.set_NUM_VERS_ESPF_BBLT_PNPD( std::string( "" ) );
        }
    }
}

void TBSW0139RegrasFormatacaoBase::insert_COD_FBRC_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid_type != "HY8583" )
    {
        tbsw0139.set_COD_FBRC_PDV( params.ecr_fabr_id );
    }
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_SITE_ACQR_ORGL( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_HOST_ACQR_ORGL( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_FE_ACQR_ORGL( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_SITE_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_SITE_ISSR( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_HOST_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_HOST_ISSR( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_FE_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_FE_ISSR( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::insert_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::insert_TIP_GRU_TERM( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if ( !params.termid_type.compare( "HY8583" ) )
    {
        tbsw0139.set_TIP_GRU_TERM( std::string( "3" ) );
    }
    else if ( !params.termid_type.compare( "PDVDIAL" ) )
    {
        tbsw0139.set_TIP_GRU_TERM( std::string( "2" ) );
    }
    else
    {
        tbsw0139.set_TIP_GRU_TERM( std::string( "1" ) );
    }
}

// Tratamentos de UPDATES

void TBSW0139RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::update_COD_TERM( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::update_COD_PNPD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::update_TIP_CIP( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_TIP_CIP( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::update_NUM_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::update_NUM_VERS_SRVD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::update_NUM_VERS_CLIT( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid_type != "HY8583" )
    {
        if ( params.num_vers_clit.size( ) > 0 )
        {
            tbsw0139.set_NUM_VERS_CLIT( params.num_vers_clit.substr( 0, 10 ) );
        }
    }
}

void TBSW0139RegrasFormatacaoBase::update_NUM_VERS_APLV_RCD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.termid_type != "HY8583" )
    {
        if ( params.num_vers_aplv_rcd.size( ) > 0 )
        {
            tbsw0139.set_NUM_VERS_APLV_RCD( params.num_vers_aplv_rcd.substr( 0, 10 ) );
        }
    }
}

void TBSW0139RegrasFormatacaoBase::update_NUM_VERS_SFTW_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::update_NUM_VERS_ESPF_BBLT_PNPD( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::update_COD_FBRC_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0139RegrasFormatacaoBase::update_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_SITE_ACQR_ORGL( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::update_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_HOST_ACQR_ORGL( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::update_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_FE_ACQR_ORGL( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::update_NOM_SITE_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_SITE_ISSR( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::update_NOM_HOST_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_HOST_ISSR( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::update_NOM_FE_ISSR( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    gen_NOM_FE_ISSR( tbsw0139, params );
}

void TBSW0139RegrasFormatacaoBase::update_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.nom_site_acqr.size( ) != 0 )
    {
        tbsw0139.set_NOM_SITE_ACQR_ATLZ( params.nom_site_acqr );
    }
    else
    {
        tbsw0139.set_NOM_SITE_ACQR_ATLZ( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0139RegrasFormatacaoBase::update_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.nom_host_acqr.size( ) != 0 )
    {
        tbsw0139.set_NOM_HOST_ACQR_ATLZ( params.nom_host_acqr );
    }
    else
    {
        tbsw0139.set_NOM_HOST_ACQR_ATLZ( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0139RegrasFormatacaoBase::update_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    if( params.nom_fe_acqr.size( ) != 0 )
    {
        tbsw0139.set_NOM_FE_ACQR_ATLZ( params.nom_fe_acqr );
    }
    else
    {
        tbsw0139.set_NOM_FE_ACQR_ATLZ( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0139RegrasFormatacaoBase::update_TIP_GRU_TERM( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
{
    WARNING_INVALID_FUNCTION;
}
