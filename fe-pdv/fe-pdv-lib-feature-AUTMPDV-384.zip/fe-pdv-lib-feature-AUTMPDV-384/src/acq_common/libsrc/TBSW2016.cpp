/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#include "TBSW2016.hpp"

namespace dbaccess_common
{

    TBSW2016::TBSW2016() {
        
        query_fields = "ID_CHAV_CRIP_KSN, COD_SIT_REG, DES_ORG_BLQO, COD_USR_ULT_ATLZ, DTH_ULT_ATLZ";
		table_name = "TBSW2016";

        chaveKSNPosicao = 1;
        codigoSituacaoRegistroPosicao = 2;
        descricaoBloqueioPosicao = 3;
        codigoUsuarioUltimaAlteracaoPosicao = 4;
        dataUltimaAlteracaoRegistroPosicao = 5;

        chaveKSN = "";
        codigoSituacaoRegistro = "";
        descricaoBloqueio = "" ; 
        codigoUsuarioUltimaAlteracao = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW2016::TBSW2016(const std::string& where) {
    
        query_fields = "ID_CHAV_CRIP_KSN, COD_SIT_REG, DES_ORG_BLQO, COD_USR_ULT_ATLZ, DTH_ULT_ATLZ";
        table_name = "TBSW2016";
        where_condition = where;

        chaveKSNPosicao = 1;
        codigoSituacaoRegistroPosicao = 2;
        descricaoBloqueioPosicao = 3;
        codigoUsuarioUltimaAlteracaoPosicao = 4;
        dataUltimaAlteracaoRegistroPosicao = 5;

        chaveKSN = "";
        codigoSituacaoRegistro = "";
        descricaoBloqueio = "" ; 
        codigoUsuarioUltimaAlteracao = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW2016::~TBSW2016() {
    }

    void TBSW2016::bind_columns() {
        bind(chaveKSNPosicao, chaveKSN);
        bind(codigoSituacaoRegistroPosicao, codigoSituacaoRegistro);
        bind(descricaoBloqueioPosicao, descricaoBloqueio);
        bind(codigoUsuarioUltimaAlteracaoPosicao, codigoUsuarioUltimaAlteracao);
        bind(dataUltimaAlteracaoRegistroPosicao, &dataAlteracaoRegistro);

    }

    // Getters
    const std::string& TBSW2016::GetChaveKSN() const {
        return chaveKSN;
    }

    const std::string& TBSW2016::GetCodigoSituacaoRegistro() const {
        return codigoSituacaoRegistro;
    }

    const std::string& TBSW2016::GetDescricaoBloqueio() const {
        return descricaoBloqueio;
    }    

    const std::string& TBSW2016::GetCodigoUsuarioUltimaAlteracao() const {
        return codigoUsuarioUltimaAlteracao;
    }

    const dbm_datetime_t& TBSW2016::GetDataUltimaAlteracaoRegistro() const {
        return dataAlteracaoRegistro;
    }


    // Setters
    void TBSW2016::SetChaveKSN(const std::string& value) {
        chaveKSN = value;
    }

    void TBSW2016::SetCodigoSituacaoRegistro(const std::string& value) {
        codigoSituacaoRegistro = value;
    }

    void TBSW2016::SetDescricaoBloqueio(const std::string& value) {
        descricaoBloqueio = value;
    }    
        
    void TBSW2016::SetCodigoUsuarioUltimaAlteracao(const std::string& value) {
        codigoUsuarioUltimaAlteracao = value;
    }

    void TBSW2016::SetDataUltimaAlteracaoRegistro(const dbm_datetime_t& value) {
        dataAlteracaoRegistro = value;
    }

}
