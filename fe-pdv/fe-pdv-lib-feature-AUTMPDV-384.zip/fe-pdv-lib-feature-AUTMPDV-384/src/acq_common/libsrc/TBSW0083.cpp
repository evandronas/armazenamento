#include "TBSW0083.hpp"

namespace dbaccess_common
{
	TBSW0083::TBSW0083()
	{
        initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0083::TBSW0083( const std::string& whereClause )
	{
        initialize();
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0083::~TBSW0083()
	{
	}
    
    void TBSW0083::initialize()
    {
		query_fields = "COD_CEP_PORT, COD_CEP_CMPM_PORT, TXT_ENDR_PORT, NUM_CPF_PORT, DAT_MOV_TRAN, NUM_SEQ_UNC, COD_RSPS_AVS, TXT_CMPM_ENDR_PORT";

		table_name = "TBSW0083";

		m_COD_CEP_PORT_pos = 1;
		m_COD_CEP_CMPM_PORT_pos = 2;
		m_TXT_ENDR_PORT_pos = 3;
		m_NUM_CPF_PORT_pos = 4;
		m_DAT_MOV_TRAN_pos = 5;
		m_NUM_SEQ_UNC_pos = 6;
		m_COD_RSPS_AVS_pos = 7;
		m_TXT_CMPM_ENDR_PORT_pos = 8;

        m_COD_CEP_PORT = "";
        m_COD_CEP_CMPM_PORT = "";
        m_TXT_ENDR_PORT = "";
        m_NUM_CPF_PORT = "";
        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_COD_RSPS_AVS = "";
        m_TXT_CMPM_ENDR_PORT = "";
        
    }
    

	void TBSW0083::bind_columns()
	{
		bind( m_COD_CEP_PORT_pos, m_COD_CEP_PORT );
		bind( m_COD_CEP_CMPM_PORT_pos, m_COD_CEP_CMPM_PORT );
		bind( m_TXT_ENDR_PORT_pos, m_TXT_ENDR_PORT );
		bind( m_NUM_CPF_PORT_pos, m_NUM_CPF_PORT );
		bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
		bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
		bind( m_COD_RSPS_AVS_pos, m_COD_RSPS_AVS );
		bind( m_TXT_CMPM_ENDR_PORT_pos, m_TXT_CMPM_ENDR_PORT );
	}
	void TBSW0083::set_COD_CEP_PORT( const std::string& a_COD_CEP_PORT )
	{
		m_COD_CEP_PORT = a_COD_CEP_PORT;
	}
	void TBSW0083::set_COD_CEP_CMPM_PORT( const std::string& a_COD_CEP_CMPM_PORT )
	{
		m_COD_CEP_CMPM_PORT = a_COD_CEP_CMPM_PORT;
	}
	void TBSW0083::set_TXT_ENDR_PORT( const std::string& a_TXT_ENDR_PORT )
	{
		m_TXT_ENDR_PORT = a_TXT_ENDR_PORT;
	}
	void TBSW0083::set_NUM_CPF_PORT( const std::string& a_NUM_CPF_PORT )
	{
		m_NUM_CPF_PORT = a_NUM_CPF_PORT;
	}
	void TBSW0083::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
	{
		m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
	}
	void TBSW0083::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
	{
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
	}
	void TBSW0083::set_COD_RSPS_AVS( const std::string& a_COD_RSPS_AVS )
	{
		m_COD_RSPS_AVS = a_COD_RSPS_AVS;
	}
	void TBSW0083::set_TXT_CMPM_ENDR_PORT( const std::string& a_TXT_CMPM_ENDR_PORT )
	{
		m_TXT_CMPM_ENDR_PORT = a_TXT_CMPM_ENDR_PORT;
	}
	const std::string& TBSW0083::get_COD_CEP_PORT() const
	{
		return m_COD_CEP_PORT;
	}
	const std::string& TBSW0083::get_COD_CEP_CMPM_PORT() const
	{
		return m_COD_CEP_CMPM_PORT;
	}
	const std::string& TBSW0083::get_TXT_ENDR_PORT() const
	{
		return m_TXT_ENDR_PORT;
	}
	const std::string& TBSW0083::get_NUM_CPF_PORT() const
	{
		return m_NUM_CPF_PORT;
	}
	unsigned long TBSW0083::get_DAT_MOV_TRAN() const
	{
		return m_DAT_MOV_TRAN;
	}
	oasis_dec_t TBSW0083::get_NUM_SEQ_UNC() const
	{
		return m_NUM_SEQ_UNC;
	}
	const std::string& TBSW0083::get_COD_RSPS_AVS() const
	{
		return m_COD_RSPS_AVS;
	}
	const std::string& TBSW0083::get_TXT_CMPM_ENDR_PORT() const
	{
		return m_TXT_CMPM_ENDR_PORT;
	}

} //namespace dbaccess_common

