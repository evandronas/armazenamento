#include "TBSW2012.hpp"

namespace dbaccess_common
{
	TBSW2012::TBSW2012()
	{

		query_fields = "COD_ROTA_ADMN, COD_MSG_ISO, COD_PCM_ISO, NETWORK_ID, NOM_HOST_ACQR, NOM_FE_ACQR, COD_ISSR_SW";

		table_name = "TBSW2012";

		m_COD_ROTA_ADMN_pos = 1;
		m_COD_MSG_ISO_pos = 2;
		m_COD_PCM_ISO_pos = 3;
		m_NETWORK_ID_pos = 4;
		m_NOM_HOST_ACQR_pos = 5;
		m_NOM_FE_ACQR_pos = 6;
		m_COD_ISSR_SW_pos = 7;

		m_COD_ROTA_ADMN = 0;
		m_COD_MSG_ISO = 0;
		m_COD_PCM_ISO = 0;
		m_NETWORK_ID = "";
		m_NOM_HOST_ACQR = " ";
		m_NOM_FE_ACQR = " ";
		m_COD_ISSR_SW = 0;

		where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW2012::TBSW2012( const std::string& whereClause )
	{

		query_fields = "COD_ROTA_ADMN, COD_MSG_ISO, COD_PCM_ISO, NETWORK_ID, NOM_HOST_ACQR, NOM_FE_ACQR, COD_ISSR_SW";

		table_name = "TBSW2012";

		m_COD_ROTA_ADMN_pos = 1;
		m_COD_MSG_ISO_pos = 2;
		m_COD_PCM_ISO_pos = 3;
		m_NETWORK_ID_pos = 4;
		m_NOM_HOST_ACQR_pos = 5;
		m_NOM_FE_ACQR_pos = 6;
		m_COD_ISSR_SW_pos = 7;

		m_COD_ROTA_ADMN = 0;
		m_COD_MSG_ISO = 0;
		m_COD_PCM_ISO = 0;
		m_NETWORK_ID = "";
		m_NOM_HOST_ACQR = " ";
		m_NOM_FE_ACQR = " ";
		m_COD_ISSR_SW = 0;

		where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW2012::~TBSW2012()
	{
	}

	void TBSW2012::bind_columns()
	{
		bind( m_COD_ROTA_ADMN_pos, m_COD_ROTA_ADMN );
		bind( m_COD_MSG_ISO_pos, m_COD_MSG_ISO );
		bind( m_COD_PCM_ISO_pos, m_COD_PCM_ISO );
		bind( m_NETWORK_ID_pos, m_NETWORK_ID );
		bind( m_NOM_HOST_ACQR_pos, m_NOM_HOST_ACQR );
		bind( m_NOM_FE_ACQR_pos, m_NOM_FE_ACQR );
		bind( m_COD_ISSR_SW_pos, m_COD_ISSR_SW );
	}
	void TBSW2012::set_COD_ROTA_ADMN( unsigned long a_COD_ROTA_ADMN )
	{
		m_COD_ROTA_ADMN = a_COD_ROTA_ADMN;
	}
	void TBSW2012::set_COD_MSG_ISO( unsigned long a_COD_MSG_ISO )
	{
		m_COD_MSG_ISO = a_COD_MSG_ISO;
	}
	void TBSW2012::set_COD_PCM_ISO( unsigned long a_COD_PCM_ISO )
	{
		m_COD_PCM_ISO = a_COD_PCM_ISO;
	}
	void TBSW2012::set_NETWORK_ID( const std::string& a_NETWORK_ID )
	{
		m_NETWORK_ID = a_NETWORK_ID;
	}
	void TBSW2012::set_NOM_HOST_ACQR( const std::string& a_NOM_HOST_ACQR )
	{
		m_NOM_HOST_ACQR = a_NOM_HOST_ACQR;
	}
	void TBSW2012::set_NOM_FE_ACQR( const std::string& a_NOM_FE_ACQR )
	{
		m_NOM_FE_ACQR = a_NOM_FE_ACQR;
	}
	void TBSW2012::set_COD_ISSR_SW( unsigned long a_COD_ISSR_SW )
	{
		m_COD_ISSR_SW = a_COD_ISSR_SW;
	}
	unsigned long TBSW2012::get_COD_ROTA_ADMN() const
	{
		return m_COD_ROTA_ADMN;
	}
	unsigned long TBSW2012::get_COD_MSG_ISO() const
	{
		return m_COD_MSG_ISO;
	}
	unsigned long TBSW2012::get_COD_PCM_ISO() const
	{
		return m_COD_PCM_ISO;
	}
	const std::string& TBSW2012::get_NETWORK_ID() const
	{
		return m_NETWORK_ID;
	}
	const std::string& TBSW2012::get_NOM_HOST_ACQR() const
	{
		return m_NOM_HOST_ACQR;
	}
	const std::string& TBSW2012::get_NOM_FE_ACQR() const
	{
		return m_NOM_FE_ACQR;
	}
	unsigned long TBSW2012::get_COD_ISSR_SW() const
	{
		return m_COD_ISSR_SW;
	}

} //namespace dbaccess_common

