#include <cstring>
#include <AcqUtils.hpp>
#include <TBSW0093RegrasFormatacaoBase.hpp>

TBSW0093RegrasFormatacaoBase::TBSW0093RegrasFormatacaoBase()
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0093RegrasFormatacaoBase::~TBSW0093RegrasFormatacaoBase( )
{
}

void TBSW0093RegrasFormatacaoBase::DAT_MOV_TRAN	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_DAT_MOV_TRAN( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::NUM_SEQ_UNC	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_NUM_SEQ_UNC( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::COD_OPER_ESTR( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_COD_OPER_ESTR( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_COD_OPER_ESTR( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::COD_ITEM( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_COD_ITEM( tbsw0093, tbsw0093_params );
	}
	else
	{
		if(operacao == acq_common::UPDATE )
		{
			update_COD_ITEM( tbsw0093, tbsw0093_params );
		}
	}
}
void TBSW0093RegrasFormatacaoBase::TIP_MODO_TRAN( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_TIP_MODO_TRAN( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_TIP_MODO_TRAN( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::TIP_MSG( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_TIP_MSG( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_TIP_MSG( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::TIP_VD_SAID	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_TIP_VD_SAID( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_TIP_VD_SAID( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::NUM_OPER_ETD	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_NUM_OPER_ETD( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_NUM_OPER_ETD( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::NUM_RD_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_NUM_RD_DEST( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_NUM_RD_DEST( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::COD_MOT_RSPS_EXT( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_COD_MOT_RSPS_EXT( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_COD_MOT_RSPS_EXT( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::COD_OPER_CNFR( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_COD_OPER_CNFR( tbsw0093, tbsw0093_params );
	}
    else if(operacao == acq_common::UPDATE )
    {
        update_COD_OPER_CNFR( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::COD_MOT_ESTR_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_COD_MOT_ESTR_DEST( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_COD_MOT_ESTR_DEST( tbsw0093, tbsw0093_params );
    }
}
void TBSW0093RegrasFormatacaoBase::COD_MOT_RSPS_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao )
{
	if(operacao == acq_common::INSERT )
	{
		insert_COD_MOT_RSPS_DEST( tbsw0093, tbsw0093_params );
	}
	else if(operacao == acq_common::UPDATE )
    {
        update_COD_MOT_RSPS_DEST( tbsw0093, tbsw0093_params );
    }
}

// INSERT'
void TBSW0093RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	tbsw0093.set_DAT_MOV_TRAN( tbsw0093_params.local_date );
}
void TBSW0093RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{    
    oasis_dec_t aux;
    dbm_chartodec( &aux, tbsw0093_params.refnum.c_str( ), 0 );
    tbsw0093.set_NUM_SEQ_UNC( aux );
}

void TBSW0093RegrasFormatacaoBase::insert_COD_OPER_ESTR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	tbsw0093.set_COD_OPER_ESTR( " " );
}
void TBSW0093RegrasFormatacaoBase::insert_COD_ITEM( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    std::string aux = " ";    
    if( tbsw0093_params.msg_name  == "CONS_PL_VEND" ||
        tbsw0093_params.msg_name  == "VEND_PL" ||
        tbsw0093_params.msg_name  == "VEND_PL_ZOLKIN" )
	{
		if ( tbsw0093_params.private_label_cod_item.size( ) )
		{
            aux = tbsw0093_params.private_label_cod_item;
		}
        else
        {   
            WARNING_EMPTY_STRING;
        }
	}
    tbsw0093.set_COD_ITEM( aux ); 
}
void TBSW0093RegrasFormatacaoBase::insert_TIP_MODO_TRAN	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	tbsw0093.set_TIP_MODO_TRAN( "2" ); // 1-offline, 2-online

}
void TBSW0093RegrasFormatacaoBase::insert_TIP_MSG( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	tbsw0093.set_TIP_MSG( " " ); // "S" (Standin), " " (outros)
}
void TBSW0093RegrasFormatacaoBase::insert_TIP_VD_SAID( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    std::string s_modo_captura;
    std::string l_tip_vd;

    if ( atoi( tbsw0093_params.pos_entry_code.c_str() ) == 21 ) 
    {
        s_modo_captura = "M";  // Magnetico
    }
    else if ( atoi( tbsw0093_params.pos_entry_code.c_str() )/10 == 79 ) 
    {
        s_modo_captura = "6";  // FALBACK DIGITADO
    }
    else if ( atoi( tbsw0093_params.pos_entry_code.c_str() )/10 == 80 ) 
    {
        s_modo_captura = "B";  // FALBACK MAGNETICO
    }
    else    
    {
        s_modo_captura = "D";  // Venda Digitada
    }
    
    
    switch( atoi( tbsw0093_params.common_transcode.c_str( ) ) )
    {
        // --------------------------------------
        // CREDITO
        // --------------------------------------
        // VENDA A VISTA
        case 3:
        case 4:
        case 39:
        case 68:
        case 69:
            l_tip_vd = "1";
            break;
        // PARCELADA COM JUROS
        case 5:
        case 6:
            l_tip_vd = "2";
            break;
        // PARCELADA SEM JUROS
        case 7:
        case 8:
        case 40:
        case 80:
        case 81:
            l_tip_vd = "3";
            break;
        // --------------------------------------
        // DEBITO PRE-DATADO
        // --------------------------------------
        case 57:
            l_tip_vd = "6";
            break;
        default:
            l_tip_vd = "0";
            break;
    }

	std::string s_tip_vd_said = s_modo_captura + l_tip_vd;

	tbsw0093.set_TIP_VD_SAID ( s_tip_vd_said );   

}
void TBSW0093RegrasFormatacaoBase::insert_NUM_OPER_ETD( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	oasis_dec_t l_dect;
	dbm_chartodec( &l_dect, "0", 0 );
	tbsw0093.set_NUM_OPER_ETD( l_dect );
}
void TBSW0093RegrasFormatacaoBase::insert_NUM_RD_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	tbsw0093.set_NUM_RD_DEST( 0 );
}
void TBSW0093RegrasFormatacaoBase::insert_COD_MOT_RSPS_EXT( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	tbsw0093.set_COD_MOT_RSPS_EXT( " " );
}
void TBSW0093RegrasFormatacaoBase::insert_COD_OPER_CNFR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    gen_COD_OPER_CNFR( tbsw0093, tbsw0093_params );
}
void TBSW0093RegrasFormatacaoBase::insert_COD_MOT_ESTR_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	tbsw0093.set_COD_MOT_ESTR_DEST( " " ); 
}
void TBSW0093RegrasFormatacaoBase::insert_COD_MOT_RSPS_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	if ( tbsw0093_params.common_pb_reason_code.size( ) > 0 ) 
	{
		if( tbsw0093_params.common_pb_reason_code.size( ) == 1 )
		{
			tbsw0093.set_COD_MOT_RSPS_DEST( "0" + tbsw0093_params.common_pb_reason_code );
		}
		else
		{
			tbsw0093.set_COD_MOT_RSPS_DEST( tbsw0093_params.common_pb_reason_code );
		}
	}
    else
    { 
        tbsw0093.set_COD_MOT_RSPS_DEST( " " );  
        WARNING_EMPTY_STRING;
    }
}

// UPDATE
void TBSW0093RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_COD_OPER_ESTR( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
}
void TBSW0093RegrasFormatacaoBase::update_COD_ITEM( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_TIP_MODO_TRAN( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_TIP_MSG( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_TIP_VD_SAID( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_NUM_OPER_ETD( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_NUM_RD_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_COD_MOT_RSPS_EXT( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_COD_OPER_CNFR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    gen_COD_OPER_CNFR( tbsw0093, tbsw0093_params );
}
void TBSW0093RegrasFormatacaoBase::update_COD_MOT_ESTR_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::update_COD_MOT_RSPS_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	if( tbsw0093_params.common_ext_network_code.size() > 0 )
	{
		char l_buffer[4];
		memset( l_buffer, 0, sizeof l_buffer );
		snprintf( l_buffer, sizeof( l_buffer ), "%02lu", atol( tbsw0093_params.common_ext_network_code.c_str() ) );

		tbsw0093.set_COD_MOT_RSPS_DEST( std::string( l_buffer ) );
	}
	else
	{
		tbsw0093.set_COD_MOT_RSPS_DEST( "00" );
	}
}

// GEN
void TBSW0093RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_COD_OPER_ESTR( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_COD_ITEM	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_TIP_MODO_TRAN( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_TIP_MSG	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_TIP_VD_SAID( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_NUM_OPER_ETD( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_NUM_RD_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_COD_MOT_RSPS_EXT	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_COD_OPER_CNFR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
	tbsw0093.set_COD_OPER_CNFR( "SIS" );
}
void TBSW0093RegrasFormatacaoBase::gen_COD_MOT_ESTR_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}
void TBSW0093RegrasFormatacaoBase::gen_COD_MOT_RSPS_DEST( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params )
{
    WARNING_INVALID_FUNCTION;
}

