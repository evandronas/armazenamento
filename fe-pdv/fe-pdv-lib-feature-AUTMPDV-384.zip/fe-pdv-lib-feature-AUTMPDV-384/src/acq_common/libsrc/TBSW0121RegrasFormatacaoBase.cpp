#include<TBSW0121RegrasFormatacaoBase.hpp>

TBSW0121RegrasFormatacaoBase::TBSW0121RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0121RegrasFormatacaoBase::~TBSW0121RegrasFormatacaoBase( )
{
}

void TBSW0121RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::NUM_SRE_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SRE_PNPD( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SRE_PNPD( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::COD_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CHCK_PDV( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CHCK_PDV( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::COD_MODL_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MODL_PNPD( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MODL_PNPD( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::COD_VERS_BBLT_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_BBLT_PNPD( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_BBLT_PNPD( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::COD_VERS_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_CHCK_PDV( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_CHCK_PDV( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::COD_VERS_SRVD_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_SRVD_PDV( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_SRVD_PDV( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::COD_VERS_SIS( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_SIS( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_SIS( tbsw0121, params );
    }
}

void TBSW0121RegrasFormatacaoBase::COD_VERS_SFTW( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_SFTW( tbsw0121, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_SFTW( tbsw0121, params );
    }
}

// Metodos utilizados por campos que tem input generico (INSERT/UPDATE)

void TBSW0121RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_NUM_SRE_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_COD_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_COD_MODL_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_COD_VERS_BBLT_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_COD_VERS_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_COD_VERS_SRVD_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_COD_VERS_SIS( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::gen_COD_VERS_SFTW( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

// Metodos especificos para INSERT

void TBSW0121RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    tbsw0121.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0121RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw0121.set_NUM_SEQ_UNC( l_dect );
}

void TBSW0121RegrasFormatacaoBase::insert_NUM_SRE_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    if( params.codver.size( ) != 0 )
    {
        tbsw0121.set_NUM_SRE_PNPD( params.codver );
    }
    else
    {
        tbsw0121.set_NUM_SRE_PNPD( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0121RegrasFormatacaoBase::insert_COD_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    if( params.termid.size( ) != 0 )
    {
        tbsw0121.set_COD_CHCK_PDV( params.termid );
    }
    else
    {
        tbsw0121.set_COD_CHCK_PDV( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0121RegrasFormatacaoBase::insert_COD_MODL_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::insert_COD_VERS_BBLT_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    if( params.cod_vers_sftw.size( ) > 11 )
    {
        tbsw0121.set_COD_VERS_BBLT_PNPD( params.cod_vers_sftw.substr( 11, 10 ) );
    }
    else
    {
        tbsw0121.set_COD_VERS_BBLT_PNPD( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0121RegrasFormatacaoBase::insert_COD_VERS_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::insert_COD_VERS_SRVD_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    if( params.ecr_sftw_verid.size( ) != 0 )
    {
        tbsw0121.set_COD_VERS_SRVD_PDV( params.ecr_sftw_verid.substr( 0, 5 ) );
    }
    else
    {
        tbsw0121.set_COD_VERS_SRVD_PDV( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0121RegrasFormatacaoBase::insert_COD_VERS_SIS( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    tbsw0121.set_COD_VERS_SIS( std::string( "SWF01.00" ) );
}

void TBSW0121RegrasFormatacaoBase::insert_COD_VERS_SFTW( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    if( params.ecr_sftw_verid.size( ) != 0 )
    {
        tbsw0121.set_COD_VERS_SFTW( params.ecr_sftw_verid );
    }
    else
    {
        tbsw0121.set_COD_VERS_SFTW( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

// Metodos especificos para UPDATE

void TBSW0121RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_NUM_SRE_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_COD_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_COD_MODL_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_COD_VERS_BBLT_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_COD_VERS_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_COD_VERS_SRVD_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_COD_VERS_SIS( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0121RegrasFormatacaoBase::update_COD_VERS_SFTW( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
{
    WARNING_INVALID_FUNCTION;
}
