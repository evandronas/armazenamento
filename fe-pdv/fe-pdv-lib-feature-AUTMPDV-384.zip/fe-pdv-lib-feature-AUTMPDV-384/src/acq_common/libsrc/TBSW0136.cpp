#include "TBSW0136.hpp"

namespace dbaccess_common
{
	TBSW0136::TBSW0136()
	{

		query_fields = "ID_BDK, COD_CRPA_CHAV, COD_CHCK_VLUE, DTH_ULT_ATLZ, COD_OPID_ULT_ATLZ";

		table_name = "TBSW0136";

		m_ID_BDK_pos = 1;
		m_COD_CRPA_CHAV_BDK_pos = 2;
		m_COD_CHCK_VLUE_pos = 3;
		m_DTH_ULT_ATLZ_pos = 4;
		m_COD_OPID_ULT_ATLZ_pos = 5;

		m_ID_BDK = 0;
		m_COD_CRPA_CHAV_BDK = " ";
		m_COD_CHCK_VLUE = " ";
		m_DTH_ULT_ATLZ = 0;
		m_COD_OPID_ULT_ATLZ = " ";

		where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0136::TBSW0136( const std::string& whereClause )
	{

		query_fields = "ID_BDK, COD_CRPA_CHAV, COD_CHCK_VLUE, DTH_ULT_ATLZ, COD_OPID_ULT_ATLZ";

		table_name = "TBSW0136";

		m_ID_BDK_pos = 1;
		m_COD_CRPA_CHAV_BDK_pos = 2;
		m_COD_CHCK_VLUE_pos = 3;
		m_DTH_ULT_ATLZ_pos = 4;
		m_COD_OPID_ULT_ATLZ_pos = 5;

		m_ID_BDK = 0;
		m_COD_CRPA_CHAV_BDK = " ";
		m_COD_CHCK_VLUE = " ";
		m_DTH_ULT_ATLZ = 0;
		m_COD_OPID_ULT_ATLZ = " ";

		where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0136::~TBSW0136()
	{
	}

	void TBSW0136::bind_columns()
	{
		bind( m_ID_BDK_pos, m_ID_BDK );
		bind( m_COD_CRPA_CHAV_BDK_pos, m_COD_CRPA_CHAV_BDK );
		bind( m_COD_CHCK_VLUE_pos, m_COD_CHCK_VLUE );
		bind( m_DTH_ULT_ATLZ_pos, &m_DTH_ULT_ATLZ );
		bind( m_COD_OPID_ULT_ATLZ_pos, m_COD_OPID_ULT_ATLZ );
	}
	void TBSW0136::set_ID_BDK( unsigned long a_ID_BDK )
	{
		m_ID_BDK = a_ID_BDK;
	}
	void TBSW0136::set_COD_CRPA_CHAV_BDK( const std::string& a_COD_CRPA_CHAV_BDK )
	{
		m_COD_CRPA_CHAV_BDK = a_COD_CRPA_CHAV_BDK;
	}
	void TBSW0136::set_COD_CHCK_VLUE( const std::string& a_COD_CHCK_VLUE )
	{
		m_COD_CHCK_VLUE = a_COD_CHCK_VLUE;
	}
	void TBSW0136::set_DTH_ULT_ATLZ( dbm_datetime_t a_DTH_ULT_ATLZ )
	{
		m_DTH_ULT_ATLZ = a_DTH_ULT_ATLZ;
	}
	void TBSW0136::set_COD_OPID_ULT_ATLZ( const std::string& a_COD_OPID_ULT_ATLZ )
	{
		m_COD_OPID_ULT_ATLZ = a_COD_OPID_ULT_ATLZ;
	}
	unsigned long TBSW0136::get_ID_BDK() const
	{
		return m_ID_BDK;
	}
	const std::string& TBSW0136::get_COD_CRPA_CHAV_BDK() const
	{
		return m_COD_CRPA_CHAV_BDK;
	}
	const std::string& TBSW0136::get_COD_CHCK_VLUE() const
	{
		return m_COD_CHCK_VLUE;
	}
	dbm_datetime_t TBSW0136::get_DTH_ULT_ATLZ() const
	{
		return m_DTH_ULT_ATLZ;
	}
	const std::string& TBSW0136::get_COD_OPID_ULT_ATLZ() const
	{
		return m_COD_OPID_ULT_ATLZ;
	}

} //namespace dbaccess_common

