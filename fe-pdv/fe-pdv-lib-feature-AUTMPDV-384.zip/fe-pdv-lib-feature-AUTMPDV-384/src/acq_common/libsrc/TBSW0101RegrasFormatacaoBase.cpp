#include<TBSW0101RegrasFormatacaoBase.hpp>

TBSW0101RegrasFormatacaoBase::TBSW0101RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0101RegrasFormatacaoBase::~TBSW0101RegrasFormatacaoBase( )
{
}

void TBSW0101RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0101, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0101, params );
    }
}

void TBSW0101RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0101, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0101, params );
    }
}

void TBSW0101RegrasFormatacaoBase::COD_NVL_SGRA_TKN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_NVL_SGRA_TKN( tbsw0101, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_NVL_SGRA_TKN( tbsw0101, params );
    }
}

void TBSW0101RegrasFormatacaoBase::COD_REF_CTA_PGMN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_REF_CTA_PGMN( tbsw0101, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_REF_CTA_PGMN( tbsw0101, params );
    }
}


// Metodos utilizados por campos que tem input generico (INSERT/UPDATE)

void TBSW0101RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0101RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0101RegrasFormatacaoBase::gen_COD_NVL_SGRA_TKN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0101RegrasFormatacaoBase::gen_COD_REF_CTA_PGMN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    WARNING_INVALID_FUNCTION;
}


// Metodos especificos para INSERT

void TBSW0101RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    tbsw0101.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0101RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    tbsw0101.set_NUM_SEQ_UNC( params.refnum );
}

void TBSW0101RegrasFormatacaoBase::insert_COD_NVL_SGRA_TKN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    if( params.tokenAssuranceLevel.size( ) != 0 )
    {
        tbsw0101.set_COD_NVL_SGRA_TKN( params.tokenAssuranceLevel );
    }
    else
    {
        tbsw0101.set_COD_NVL_SGRA_TKN( std::string( "" ) );
    }
}

void TBSW0101RegrasFormatacaoBase::insert_COD_REF_CTA_PGMN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    if( params.paymentAccountReference.size() != 0 )
    {
        tbsw0101.set_COD_REF_CTA_PGMN( params.paymentAccountReference );
    }
    else
    {
        tbsw0101.set_COD_REF_CTA_PGMN( std::string( "" ) );
    }
}


// Metodos especificos para UPDATE

void TBSW0101RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0101RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0101RegrasFormatacaoBase::update_COD_NVL_SGRA_TKN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    if( params.tokenAssuranceLevel.size( ) != 0 )
    {
        tbsw0101.set_COD_NVL_SGRA_TKN( params.tokenAssuranceLevel );
    }
    else
    {
        tbsw0101.set_COD_NVL_SGRA_TKN( std::string( "" ) );
    }
}

void TBSW0101RegrasFormatacaoBase::update_COD_REF_CTA_PGMN( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params )
{
    if( params.paymentAccountReference.size( ) != 0 )
    {
        tbsw0101.set_COD_REF_CTA_PGMN( params.paymentAccountReference );
    }
    else
    {
        tbsw0101.set_COD_REF_CTA_PGMN( std::string( "" ) );
    }
}

