/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Costa Duarte
/ Data de Cria��o: 2017, 11 de Setembro
/ Hist�rico Mudan�as:
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "TBSW0140.hpp"

namespace dbaccess_common
{
    TBSW0140::TBSW0140( )
    {
        query_fields = "COD_RAM_ATVD, COD_BNDR, COD_BNDR_CORP, COD_MCC, DAT_ATLZ_REG";
        table_name = "TBSW0140";
        where_condition = "";
        m_COD_RAM_ATVD_pos = 1;
        m_COD_BNDR_pos = 2;
        m_COD_BNDR_CORP_pos = 3;
        m_COD_MCC_pos = 4;
        m_DAT_ATLZ_REG_pos = 5;
        
        m_COD_RAM_ATVD = 0;
        m_COD_BNDR = 0;
        m_COD_BNDR_CORP = 0;
        m_COD_MCC = 0;
        m_DAT_ATLZ_REG = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW0140::TBSW0140( const std::string &str )
    {
        query_fields = "COD_RAM_ATVD, COD_BNDR, COD_BNDR_CORP, COD_MCC, DAT_ATLZ_REG";
        table_name = "TBSW0140";
        where_condition = str;
        m_COD_RAM_ATVD_pos = 1;
        m_COD_BNDR_pos = 2;
        m_COD_BNDR_CORP_pos = 3;
        m_COD_MCC_pos = 4;
        m_DAT_ATLZ_REG_pos = 5;
        
        m_COD_RAM_ATVD = 0;
        m_COD_BNDR = 0;
        m_COD_BNDR_CORP = 0;
        m_COD_MCC = 0;
        m_DAT_ATLZ_REG = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW0140::~TBSW0140( )
    {
    }
    long TBSW0140::getCOD_RAM_ATVD( ) const
    {
        return m_COD_RAM_ATVD;
    }
    long TBSW0140::getCOD_BNDR( ) const
    {
        return m_COD_BNDR;
    }
    long TBSW0140::getCOD_BNDR_CORP( ) const
    {
        return m_COD_BNDR_CORP;
    }
    long TBSW0140::getCOD_MCC( ) const
    {
        return m_COD_MCC;
    }
    dbm_datetime_t TBSW0140::getDAT_ATLZ_REG( ) const
    {
        return m_DAT_ATLZ_REG;
    }
    
    void TBSW0140::setCOD_RAM_ATVD( long a_COD_RAM_ATVD )
    {
        m_COD_RAM_ATVD = a_COD_RAM_ATVD;
    }
    void TBSW0140::setCOD_BNDR( long a_COD_BNDR )
    {
        m_COD_BNDR = a_COD_BNDR;
    }
    void TBSW0140::setCOD_BNDR_CORP( long a_COD_BNDR_CORP )
    {
        m_COD_BNDR_CORP = a_COD_BNDR_CORP;
    }
    void TBSW0140::setCOD_MCC( long a_COD_MCC )
    {
        m_COD_MCC = a_COD_MCC;
    }
    void TBSW0140::setDAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
    {
        m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    
    void TBSW0140::bind_columns( )
    {
        bind( m_COD_RAM_ATVD_pos, m_COD_RAM_ATVD );
        bind( m_COD_BNDR_pos, m_COD_BNDR );
        bind( m_COD_BNDR_CORP_pos, m_COD_BNDR_CORP );
        bind( m_COD_MCC_pos, m_COD_MCC );
        bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
    }
}//namespace dbaccess_common

