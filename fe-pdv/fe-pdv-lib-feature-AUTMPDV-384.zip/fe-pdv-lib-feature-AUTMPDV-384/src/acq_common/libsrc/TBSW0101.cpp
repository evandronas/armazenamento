#include "TBSW0101.hpp"
#include <syslg.h>
namespace dbaccess_common
{
    TBSW0101::TBSW0101( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0101::TBSW0101( const std::string& whereClause )
    {
        initialize( );
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0101::~TBSW0101( )
    {
    }

    void TBSW0101::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, COD_NVL_SGRA_TKN, COD_REF_CTA_PGMN";
        table_name = "TBSW0101";
        
        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_COD_NVL_SGRA_TKN_pos = 3;
        m_COD_REF_CTA_PGMN_pos = 4;

        m_DAT_MOV_TRAN = 0;
        m_NUM_SEQ_UNC = 0;
        m_COD_NVL_SGRA_TKN = "";
        m_COD_REF_CTA_PGMN = "";
    }

    void TBSW0101::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_COD_NVL_SGRA_TKN_pos, m_COD_NVL_SGRA_TKN );
        bind( m_COD_REF_CTA_PGMN_pos, m_COD_REF_CTA_PGMN );
    }
    
    void TBSW0101::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0101::set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }
    void TBSW0101::set_COD_NVL_SGRA_TKN( const std::string& a_COD_NVL_SGRA_TKN )
    {
        m_COD_NVL_SGRA_TKN = a_COD_NVL_SGRA_TKN;
    }
    void TBSW0101::set_COD_REF_CTA_PGMN( const std::string& a_COD_REF_CTA_PGMN )
    {
        m_COD_REF_CTA_PGMN = a_COD_REF_CTA_PGMN;
    }

    unsigned long TBSW0101::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    unsigned long TBSW0101::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }
    const std::string& TBSW0101::get_COD_NVL_SGRA_TKN( ) const
    {
        return( m_COD_NVL_SGRA_TKN );
    }
    const std::string& TBSW0101::get_COD_REF_CTA_PGMN( ) const
    {
        return( m_COD_REF_CTA_PGMN );
    }

} // namespace dbaccess_common


