/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t687342, Carolina Siqueira
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t687342, Carolina Siqueira, Versao Inicial
/                   : 2019, 07 de novembro,Daniel Nava e Renato de Camargo, inclusao Total de Mensagemns
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <cstdio>
#include <cstring>
#include "base/GenException.hpp"

namespace mailboxInterface
{
	class MailboxIn
	{
	public:
		MailboxIn( );
		virtual ~MailboxIn( );
		MailboxIn& setName( const char* a_name );
		bool open( );
		bool receive( );
		bool isFromNet( ) const;
		const unsigned char* receivedMessage( ) const;
		void close( );
		int inputAddress( ) const;
		int receivedAddress( ) const;
		int returnAddress( ) const;
		int messages() const;
		int GetTotalMessages( ) const ;
		int receivedLength( ) const;
		bool send( int a_mbidDest, const unsigned char* a_message, unsigned int a_messageLength );
		int senderAddress( ) const;
		int portAddress( ) const;
		bool error( ) const;
		bool isCommand( ) const;
		bool isEvent( ) const;
		int eventAddress( ) const;
		bool dequeueEvent( );
		void enableAutoDequeueEvent( bool a_autoDequeueEvent = true );
		bool isShutdownCommand( ) const;
	private:
		int m_inputAddress;
		int m_receivedAddress;
		int m_returnAddress;
		int m_senderAddress;
		int m_portAddress;
		int m_messageLen;
		const unsigned int MAX_BUFFER_LEN;
		unsigned char* m_buffer;
		char m_mailboxName[256];
		char m_portName[256];
		bool m_isFromNet;
		bool m_isCommand;
		bool m_isEvent;
		int m_eventId;
		bool m_autoDequeueEvent;
		bool m_eventDequeued;
		bool m_isShutdownCommand;
	};
}//namespace mailboxInterface

