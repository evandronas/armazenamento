/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t687342, Carolina Siqueira
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t687342, Carolina Siqueira, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <cstring>
#include "base/GenException.hpp"

namespace mailboxInterface
{
	class MailboxLocator
	{
	public:
		MailboxLocator( );
		virtual ~MailboxLocator( );
		bool open( const char* a_mbName );
		void close( );
		int getAddress( ) const;
        int getOutbound( ) const;
	private:
		int m_address;
        int	m_outbound;
	};
}//namespace mailboxInterface

