/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t687342, Carolina Siqueira
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t687342, Carolina Siqueira, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once

namespace mailboxInterface
{
	class MailboxInterface
	{
	public:
		virtual ~MailboxInterface( );
		static const MailboxInterface* getInstance( );
		bool init( ) const;
		const char* mbName( int a_mailboxId ) const;
		bool mailboxbIsPort( int a_mailboxId ) const;
		bool mailboxIsValid( int a_mailboxId ) const;
	private:
		MailboxInterface( );
		static MailboxInterface* m_instance;
		mutable bool m_started;
	};
};
//namespace mailboxInterface

