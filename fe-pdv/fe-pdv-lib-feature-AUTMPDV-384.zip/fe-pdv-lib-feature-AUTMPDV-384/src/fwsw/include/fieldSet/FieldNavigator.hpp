/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <map>
#include <deque>
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace fieldSet
{
	class FieldNavigator
	{
	public:
		FieldNavigator( );
		virtual ~FieldNavigator( );
		Field& navigate( const std::string& a_path ) const;
		bool addField( const std::string& a_symbol, Field* a_field );
		void enableDummyFieldException( bool a_enable ) const;
		
		typedef std::pair<std::string, Field*> TPPAIR;
		typedef std::deque<TPPAIR> TP_PATHS;
		
		void copyPaths( TP_PATHS& l_paths ) const;
	private:
		typedef std::map<std::string, Field*> TPMAP;
		mutable TPMAP m_fieldSets;
		mutable bool m_ignoreDummyFields;
	};
}//namespace fieldSet

