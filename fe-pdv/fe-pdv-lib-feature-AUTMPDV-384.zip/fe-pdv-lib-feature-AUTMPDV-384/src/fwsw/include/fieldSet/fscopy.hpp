/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"


namespace fieldSet
{
	class fscopy
	{
	public:
		fscopy( Field& a_field, const std::string& a_data );
		fscopy( Field& a_field, const char* a_data, unsigned int a_length );
		fscopy( Field& a_field, const unsigned char* a_data, unsigned int a_length );
		fscopy( Field& a_field, char a_data );
		fscopy( Field& a_field, unsigned char a_data );
		fscopy( Field& a_field, long a_data );
		fscopy( Field& a_field, unsigned long a_data );
		fscopy( Field& a_field, int a_data );
		fscopy( Field& a_field, unsigned int a_data );
		fscopy( Field& a_field, short a_data );
		fscopy( Field& a_field, float a_data );
		fscopy( Field& a_field, double a_data );
		fscopy( Field& a_field, unsigned short a_data );
		fscopy( FieldAccess& a_field, const std::string& a_data );
		fscopy( FieldAccess& a_field, const char* a_data, unsigned int a_length );
		fscopy( FieldAccess& a_field, const unsigned char* a_data, unsigned int a_length );
		fscopy( FieldAccess& a_field, char a_data );
		fscopy( FieldAccess& a_field, unsigned char a_data );
		fscopy( FieldAccess& a_field, long a_data );
		fscopy( FieldAccess& a_field, unsigned long a_data );
		fscopy( FieldAccess& a_field, int a_data );
		fscopy( FieldAccess& a_field, unsigned int a_data );
		fscopy( FieldAccess& a_field, short a_data );
		fscopy( FieldAccess& a_field, float a_data );
		fscopy( FieldAccess& a_field, double a_data );
		fscopy( FieldAccess& a_field, unsigned short a_data );
		fscopy( FieldAccess& a_fieldDestino, FieldAccess& a_fieldOrigem );
		fscopy( FieldAccess& a_fieldDestino, ConstFieldAccess& a_fieldOrigem );
	};
}//namespace fieldSet

