/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>


namespace fieldSet
{
	class Field
	{
	public:
		Field( const char* a_label );
		Field( );
		Field( bool a_isDummy );
		virtual ~Field( );
		Field( const Field& orig );
		virtual Field& operator=( const Field& a_orig );
		virtual Field& assign( const Field& a_orig );
		Field& input( const char* a_data, unsigned int a_maxLength );
		Field& input( const unsigned char* a_data, unsigned int a_length );
		Field& input( const Field& a_fieldToCopyData );
		Field& input( const Field* a_fieldToCopyData );
		Field& input( const std::string& a_data );
		Field& inputDefault( const char* a_data, unsigned int a_length );
		Field& inputDefault( const std::string& a_data );
		virtual Field& clearData( );
		const std::string& value( ) const;
		const unsigned char* data( ) const;
		const char* c_str( ) const;
		unsigned int length( ) const;
		unsigned int CstrLength( ) const;
		virtual Field* clone( ) const;
		virtual const Field& find( const std::string& a_label ) const;
		virtual Field& find( const std::string& a_label );
		Field* ptr( );
		const Field* constPtr( ) const;
		Field& ref( );
		const Field& constRef( ) const;
		virtual const Field& findRequired( const std::string& a_label ) const;
		virtual Field& findRequired( const std::string& a_label );
		virtual unsigned int findIndexer( const std::string& a_label ) const;
		virtual const Field& at( unsigned int a_indexer ) const;
		virtual Field& at( unsigned int a_indexer );
		virtual const Field& operator[]( unsigned int a_indexer ) const;
		virtual Field& operator[]( unsigned int a_indexer );
		virtual unsigned int size( ) const;
		Field& setMask( const std::string& a_mask );
		Field& setSecurityMask( const std::string& a_mask );
		const std::string& mask( ) const;
		const std::string& securityMask( ) const;
		bool isOn( ) const;
		virtual Field& turnOn( );
		virtual Field& turnOff( );
		bool isSecure( ) const;
		Field& setSecure( bool a_isSecure );
		virtual bool isDummy( ) const;
		static const unsigned int npos = static_cast<unsigned int>( -1 );
		Field& setLabel( const std::string& a_label );
		const std::string& label( ) const;
		virtual Field& addField( const Field& a_newField );
	private:
		std::string m_label;
		std::string m_data;
		std::string m_mask;
		std::string m_securityMask;
		bool m_isDummy;
		bool m_isOn;
		bool m_isSecure;
		std::string m_defaultData;
	};
}//namespace fieldSet

