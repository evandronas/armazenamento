/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "fieldSet/Field.hpp"


namespace fieldSet
{
	class FieldAccess
	{
	public:
		FieldAccess( );
		FieldAccess( Field& a_field, const std::string& a_label );
		FieldAccess( Field& a_field );
		virtual ~FieldAccess( );
		const std::string& value( ) const;
		const unsigned char* data( ) const;
		unsigned int Length( ) const;
		unsigned int CstrLength( ) const;
		bool operator!( ) const;
		Field& field( );
	private:
		Field* m_pField;
	};
}//namespace fieldSet

