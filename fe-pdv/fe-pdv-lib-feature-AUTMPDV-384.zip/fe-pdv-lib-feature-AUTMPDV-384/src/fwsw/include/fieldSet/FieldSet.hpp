/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <map>
#include "fieldSet/Field.hpp"


namespace fieldSet
{
	class FieldSet : public Field
	{
	public:
		FieldSet( );
		virtual ~FieldSet( );
		FieldSet( const FieldSet& a_orig );
		Field& operator=( const Field& a_orig );
		Field& assign( const Field& a_orig );
		Field& clearData( );
		Field& turnOff( );
		Field& turnOn( );
		const Field& find( const std::string& a_label ) const;
		Field& find( const std::string& a_label );
		const Field& findRequired( const std::string& a_label ) const;
		Field& findRequired( const std::string& a_label );
		unsigned int findIndexer( const std::string& a_label ) const;
		const Field& at( unsigned int a_indexer ) const;
		Field& at( unsigned int a_indexer );
		const Field& operator[]( unsigned int a_indexer ) const;
		Field& operator[]( unsigned int a_indexer );
		Field* clone( ) const;
		FieldSet& clear( );
		unsigned int size( ) const;
		Field& addField( const Field& a_newField );
	private:
		FieldSet& addField( Field* a_newField );
		typedef std::deque<Field*> DEQUE_FIELDS;
		typedef std::map<std::string, unsigned int> MAP_BY_LABEL;
		typedef std::pair<std::string, unsigned int> PAIR_MAP_BY_LABEL;
		DEQUE_FIELDS m_fields;
		MAP_BY_LABEL m_mapByLabel;
	};
}//namespace fieldSet

