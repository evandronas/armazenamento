/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"


namespace fieldSet
{
	class fsextr
	{
	public:
		fsextr( std::string& a_data, const Field& a_field );
		fsextr( char* a_data, unsigned int a_length, const Field& a_field );
		fsextr( unsigned char* a_data, unsigned int a_length, const Field& a_field );
		fsextr( char& a_data, const Field& a_field );
		fsextr( unsigned char& a_data, const Field& a_field );
		fsextr( long& a_data, const Field& a_field );
		fsextr( unsigned long& a_data, const Field& a_field );
		fsextr( int& a_data, const Field& a_field );
		fsextr( unsigned int& a_data, const Field& a_field );
		fsextr( short& a_data, const Field& a_field );
		fsextr( unsigned short& a_data, const Field& a_field );
		
		fsextr( float& a_data, const Field& a_field );
		fsextr( double& a_data, const Field& a_field );
		
		fsextr( std::string& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( char* a_data, unsigned int a_length, ConstFieldAccess& a_fieldAccess );
		fsextr( unsigned char* a_data, unsigned int a_length, ConstFieldAccess& a_fieldAccess );
		fsextr( char& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( unsigned char& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( long& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( unsigned long& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( int& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( unsigned int& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( short& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( unsigned short& a_data, ConstFieldAccess& a_fieldAccess );
		
		fsextr( float& a_data, ConstFieldAccess& a_fieldAccess );
		fsextr( double& a_data, ConstFieldAccess& a_fieldAccess );
		
		fsextr( std::string& a_data, FieldAccess& a_fieldAccess );
		fsextr( char* a_data, unsigned int a_length, FieldAccess& a_fieldAccess );
		fsextr( unsigned char* a_data, unsigned int a_length, FieldAccess& a_fieldAccess );
		fsextr( char& a_data, FieldAccess& a_fieldAccess );
		fsextr( unsigned char& a_data, FieldAccess& a_fieldAccess );
		fsextr( long& a_data, FieldAccess& a_fieldAccess );
		fsextr( unsigned long& a_data, FieldAccess& a_fieldAccess );
		fsextr( int& a_data, FieldAccess& a_fieldAccess );
		fsextr( unsigned int& a_data, FieldAccess& a_fieldAccess );
		fsextr( short& a_data, FieldAccess& a_fieldAccess );
		fsextr( unsigned short& a_data, FieldAccess& a_fieldAccess );
		
		fsextr( float& a_data, FieldAccess& a_fieldAccess );
		fsextr( double& a_data, FieldAccess& a_fieldAccess );
	};
}//namespace fieldSet

