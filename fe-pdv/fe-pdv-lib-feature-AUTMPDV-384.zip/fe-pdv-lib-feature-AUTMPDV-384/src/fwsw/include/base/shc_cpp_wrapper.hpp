/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/shc_structs.hpp"

namespace base
{
	int shc_locate_bin( struct shcpkg **a_shcpkg, const char* a_institutionId, const char* a_networdId );
	void disable_shc_log( );
  //void locate_extbin( const char *txnSrc, const char *pan, const int msgType, const char *deviceType, const long pcode, const int hasPIN, char *issuerBin );
  void locate_extbin( const char *txnSrc, const char *pan, const int msgType, const char *deviceType, const long pcode, const int hasPIN, char issuerBin[11] );
}//namespace base

