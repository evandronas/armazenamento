/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o: Gerenciador de log e debug com levels em runtime
/ Conte�do: Definicao da classe ToException
/ Autor: 246670 - Renato de Camargo
/ Data de Cria��o: 2019, 2 de abril
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>

namespace base
{
	class ToException
	{
	public:
		ToException( );
		ToException( const std::string& functionName, const std::string& what, const int paramOracleError );
		virtual ~ToException( );
		ToException& SetFunctionName( const std::string& functionName );
		ToException& SetWhat( const std::string& what );
		ToException& SetOracleError( const int paramOracleError );
		const char*  FunctionName( ) const;
		const char*  What( ) const;
		const int 	OracleError( );
	private:
		std::string functionName;
		std::string what;
		int         oracleError;
		inline void GenAssert( bool condition, const std::string& paramFunctionName, const std::string& paramWhat, const int paramOracleError );
		inline void GenAssertPtr( const void* ptr, const std::string& paramFunctionName, const std::string& paramWhat, const int paramOracleError );
	};
	#define RETURN_IF( CONDITION, RETURN_VALUE ) if ( CONDITION ){return RETURN_VALUE;}
	#define BREAK_IF( CONDITION ) if ( CONDITION ) break;
}//namespace base

