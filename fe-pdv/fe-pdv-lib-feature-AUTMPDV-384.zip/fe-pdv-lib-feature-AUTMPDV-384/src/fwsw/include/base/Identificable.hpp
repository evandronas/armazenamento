/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o: Gerenciador de log e debug com levels em runtime
/ Conte�do: Definicao da classe ThrottleWriter
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "configBase/Tag.hpp"

namespace base
{
	class Identificable
	{
	public:
		Identificable( );
		virtual ~Identificable( );
		Identificable& setLabel( const std::string& a_label );
		Identificable& setDescription( const std::string& a_description );
		Identificable& setVersion( const std::string& a_version );
		virtual bool startConfiguration( const configBase::Tag* a_tag );
		const std::string& label( ) const;
		const std::string& description( ) const;
		const std::string& version( ) const;
	private:
		std::string m_label;
		std::string m_description;
		std::string m_version;
	};
}//namespace base

