/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o: Gerenciador de log e debug com levels em runtime
/ Conte�do: Definicao da classe ThrottleWriter
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>

namespace base
{
	class GenException
	{
	public:
		GenException( );
		GenException( const std::string& a_functionName, const std::string& a_what );
		virtual ~GenException( );
		GenException& setFunctionName( const std::string& a_functionName );
		GenException& setWhat( const std::string& a_what );
		const char* functionName( ) const;
		const char* what( ) const;
	private:
		std::string m_functionName;
		std::string m_what;
	};
	inline void genAssert( bool a_condition, const std::string& a_functionName, const std::string& a_what )
	{
		if ( !a_condition )
		{
			throw GenException( a_functionName, a_what );
		}
	}
	inline void genAssertPtr( const void* a_ptr, const std::string& a_functionName, const std::string& a_what )
	{
		if ( a_ptr == 0 )
		{
			throw GenException( a_functionName, a_what );
		}
	}
	#define RETURN_IF( CONDITION, RETURN_VALUE ) if ( CONDITION ){return RETURN_VALUE;}
	#define BREAK_IF( CONDITION ) if ( CONDITION ) break;
}//namespace base

