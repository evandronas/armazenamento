/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once

namespace base
{
	#if !defined( dec_t )
	#	define dec_t oasis_dec_t
	#endif
	#define ESQL_DECSIZE 28
	struct esql_decimal
	{
		char    digits[ESQL_DECSIZE + 1];
	};
	typedef struct oasis_dec_tag
	{
		union v_tag
		{
			short align;
			char compat[29];
			struct esql_decimal esql_decimal;
		}
		v;
	}
	oasis_dec_t;
	typedef oasis_dec_t money_t;
	typedef dec_t	amount_t;
	typedef	char	bin_t[11];
	typedef	int 	date_t;
	struct  _seckey_t
	{
		char	key[74 + 1];
		char	chk[4];
	};
	typedef	struct	_seckey_t	seckey_t;
	struct  _secdukpt_t
	{
		char	KSNdesc[4];
		char	KSN[21];
	};
	typedef	struct	_secdukpt_t	secdukpt_t;
	#define SHC_NETWORK_DATA_BUF_LEN	11
	struct shc_data
	{
		char cvv2_resultcode;
		char cvv2_indicator;
		char avs_resultcode;
		char issuer_country_code[4];
		char mcard_sno[33];
		char ccard_sno[33];
		char expiry_date[5];
		char trans_id[41];
		char trans_stain[41];
		char device_cap[5];
		char service_code[4];
		char network_data[SHC_NETWORK_DATA_BUF_LEN];
		char avs_data[55];
		char cvv_resultcode;
		char pos_condition_code_x;
		char networkCAVVResult;
		char issuerCAVVResult;
		char promotion_code[7];
		char cin[5];
		char inter_program_ind;
		char pos_entry_conv_code;
	};
	#define SMS_DATA_LEN            	128
	#define SHC_PAN_LEN					19
	#define MAX_TXN_DESTINATION_LEN 	10
	#define MAX_ENTITY_ID_LEN 			30
	#define MAX_CARD_BRAND_NAME_LEN 	10
	#define SHC_PAN_LEN					19
	#define SHC_TRACK2_LEN				79
	#define SHC_TRACK3_LEN				104
	#define SHC_REFNUM_LEN				12
	#define SHC_AUTHNUM_LEN				6
	#define SHC_TERMID_LEN				8
	#define SHC_ACCEPT_LEN				40
	#define SHC_PIN_LEN					16
	#define SHC_TERMLOC_LEN				25
	#define SHC_MACVALUE_LEN			16
	#define SHC_BIN_LEN					10
	#define SHC_FORMATTER_USE			255
	#define SHC_ADDRESPONSE_LEN			25
	#define SHC_ACCT_LEN				65
	#define SHC_BANKNAME_LEN			22
	#define SHC_FILLER_LEN		    	50
	#define SHC_KEY_LEN		        	16
	#define MAC_DATA_LEN	        	512
	#define ADM_MSG_LEN	            	255
	#define KEY_CNT_LEN	            	20
	#define CVV_LEN	            		3
	#define SHC_CONF_PASSWORD_LEN		30
	#define SHC_CONF_BIRTHDATE_LEN		8
	#define SHC_CONF_EMBNAME_1_LEN		25
	#define SHC_CONF_CITY_LEN			35
	#define SHC_CONF_STREET_ADDR_LEN 	35
	#define SHC_CONF_COUNTRY_CODE_LEN	3
	#define SHC_CONF_POSTAL_CODE_LEN	10
	#define SHC_CONF_MMN_LEN			25
	#define SHC_CONF_SSN_LEN			10
	#define SHC_CONF_MAGIC_NUM			168
	#define SHC_DATA_LEN            	254
	struct  shcmsg {
	int	     msgtype;			/*      the message type */
	int	     flipped_msgtype;	/* To which message type the formatters/agents flipped. If no flipping, use 0 */

	char    pan[SHC_PAN_LEN + 1];   /*      pan of card */
	int pcode;				      /*      processing code */

	/*      Internaly coded values */
	unsigned int txntype;

	/* from_acct is also used to store flags for 8xx messages */
	/* Please refer to IST_ROLE_ definitions in shcdef.h */
	int from_acct;

	int to_acct;


	/*      these two fields are always in local currency:
		when we return to the device they are in the currency of the
		acquirer, when we forward to the issuer they are in the currency
		of the issuer.

		On the database they are always in the currency of the switch

		Now this has been changed, Please see LMCCY004.DOC for details.
		1997/09/09.
	*/
	amount_t	amount;			 /*      primary amount of transaction */
	amount_t	aval_balance;	   /*      available balance in issuer currency */

	amount_t	ledger_balance;	 /*      qd 21feb96  added ledger balance */
	amount_t	cash_back;		      /*      cash back amount (if any) */

	/*      foreign exchange stuff */
	amount_t	iss_conv_rate;		  /*      conversion rate as applied to txn */
	short	   iss_currency_code;	      /*      currencry of tranasction */
										/*      at issuer side */
	date_t	  iss_conv_date;		  /*      date conversion rate is good at */

	amount_t	acq_conv_rate;		  /*      conversion rate as applied to txn */
	short	   acq_currency_code;	      /*      currencry of tranasction */
										/*      at issuer side */
	date_t	  acq_conv_date;		  /*      date conversion rate is good at */

	/* qd 21feb96  added the following three fields */
	amount_t	tra_amount;			     /*      amount in ccy of the credit acct */
	amount_t	tra_conv_rate;		  /*      conversion rate as applied to txn */
	short	   tra_currency_code;	      /*      currencry of tranasction */
										/*      at transferee side */
	date_t	  tra_conv_date;		  /*      date conversion rate is good at */

	amount_t	amount_equiv;	   /*      the value of the transaction amount */
									/*      in the currency of the terminal */
	amount_t	fee;
	amount_t	new_fee;			/*  qd 21feb96 */
	amount_t	new_amount;		     /*  qd 21feb96, the replacement amount in 400 */
	amount_t	new_setl_amount;	/*  qd 21feb96 */
	amount_t	settlement_fee;		 /*  qd 21feb96 */
	amount_t	settlement_rate;	/*      conversion rate of settlement amount */
	short	   settlement_code;	/*      currency code of settlement */
	amount_t	settlement_amount;      /*      amount in settlement currency */



	date_t  trandate;			       /*      transmission date */
	int trantime;			   /*      transmission time */

	int trace;				      /*      system trace number */

	int local_time;			 /*      terminal local time */
	date_t  local_date;			     /*      terminal local date */

	date_t  settlement_date;			/*      settlement date */
	date_t  cap_date;			       /*      capture date */

	/*      service codes */
	short   pos_entry_code;		 /*      point of service code */
	short   pos_condition_code;
	unsigned char pos_pin_cap_code;
	short   pos_cap_code;
	char    pos_geo_loc[19];
	int life_cycle;	 /*      expressed in number of seconds */

	bin_t   acquirer;			       /*      acquiring institution id */
	bin_t   issuer;				 /*      issuing institution id */
	bin_t   transferee;			     /*      qd 21feb96 transferee institution id */
	bin_t   originator;			     /*      switch id which sent message */

	int	     respcode;			       /*      respcode on message */
	int	     reason_code;		    /*      qd 21feb96 added reason code */
	int	     revcode;				/*      reversal code */
	int	     shcerror;			       /*      internal processing code */

	/*      Reversal data elements */
	int	     origmsg;				/*      original message type */
	int	     origFlippedMsg;		 /*      original flipped message type */
	int	     origtrace;			      /*      original trace number */
	date_t  origdate;			       /*      original date */
	int origtime;			   /*      original time */

	/*      fields for visa / master card */
	short   merchant_type;
	short   acq_country;
	short   card_seqno;
	int serial_1;
	int serial_2;
	int	     origrespcode;

	/* R008717 BEGIN */
	char    alpha_response_code[3+1];

	/* Institution id to indicates where the txn comes from, If the txn source is a network,
	 * it's the network's institution, not the acquirer bin's institution
	 */
	char    txnSrc[MAX_TXN_DESTINATION_LEN+1];

	/* Institution id to indicates where the txn goes to, If the txn source is a network,
	 * it's the network's institution, not the issuer bin's institution
	 */
	char    txnDest[MAX_TXN_DESTINATION_LEN+1];

	/* Indicates alternate acquirer */
	bin_t   alternateAcquirer;

	/* Indicates acquiring entity id, same definition as in UDM */
	char    entityId[MAX_ENTITY_ID_LEN+1];

	/* Indicates issueing entity id, same definition as in UDM */
	char    iss_entityId[MAX_ENTITY_ID_LEN+1];

	/* The card brand used to acquirer this transaction */
	char    cardProduct[MAX_CARD_BRAND_NAME_LEN+1];

	/* The field 32 in XMF, because it's normally used as a key, it should be logged in shclog when possible */
	char    member_ID[11+1];

	/* The field 33 in XMF, because it's normally used as a key, it should be logged in shclog when possible */
	char    F_ID[11+1];

	/* Merchant Verification Value for VISA, other network can reuse this field only for same meaning
	 * This field is used in E-Commerce to verify the merchant
	 */
	char    MVV[10+1];

	/* The invoice number */
	char    invoice_number[6+1];

	/* The transaction ID for VISA, other network can reuse this only for same meaning */
	char    trans_id[15+1];

	/* The fee program indicator for VISA, other network can reuse this only for same meaning */
	char    FPI[3+1];

	/* R008717 END */
	char    track2[SHC_TRACK2_LEN+1];       /*      track 2 data */
	char    track3[SHC_TRACK3_LEN+1];       /*      qd 21feb96  added track 3 data */
	char    refnum[SHC_REFNUM_LEN+1];	       /*      referance number */
	char    authnum[SHC_AUTHNUM_LEN+1];     /*      issuers authorization number */
	char    termid[SHC_TERMID_LEN+1];	       /*      terminal identification */
	char    acceptorname[SHC_ACCEPT_LEN+1]; /*      acceptor name and location */
	char    termloc[SHC_TERMLOC_LEN+1];     /*      terminal location */
	char    addresponse[SHC_ADDRESPONSE_LEN + 1];
	char    acctnum[66];


	/*
	 *      Security information    as per RBC ISO8583
	 */
	char    pin[SHC_PIN_LEN];	       /*      encrypted pin */
	char    format_code[2];
	char    pin_algo[2];
	char    pin_index;
	char    mac_index;
	int	     netcode;				/*      network mgmnt code */

	seckey_t	mac;    /*      mac on this message */

	int	     device_cap;	     /*      device capabilities */
	short   branch;		 /*      branch number */


	/*      Internal Stuff */
	int	     senderid;	       /*      sender of message */
	unsigned char   formatter_use[SHC_FORMATTER_USE];
	short   saf;		    /*      saf indicator */

	int	     unit;		   /* Unit number of the ATM we are dealing with */

	/*
	 * qd 21feb96 added the following four(4) fields
	 */
	int device_devcap;
	int formatter_devcap;
	int shc_devcap;
	int auth_devcap;


	/*      stats stuff */
	int txn_start_time;     /*      first time txn entered the system */
	int txn_end_time;       /*      when txn entered the system */

	/*      ad:     02Jan92 */
	unsigned int storeid;
	unsigned int lane;
	unsigned int terminal_trace;
	unsigned int checker_id;
	unsigned int supervisor;
	unsigned short	  shift_number;
	int batch_id;

	amount_t	device_fee;     /* R002421 */

	/*
	 * qd: 06feb96  Filler spaces to store more info
	 */
	char    filler1[SHC_FILLER_LEN + 1];
	char    filler2[SHC_FILLER_LEN + 1];
	char    filler3[SHC_FILLER_LEN + 1];
	char    filler4[SHC_FILLER_LEN + 1];

	int origpcode;			  /*      original processing code */

    /*
     * yh: 1997/09/22.
     *       new fields for SMS development for agent usage
     *
     */
     char    issuer_data[SMS_DATA_LEN + 1];
     char    acquirer_data[SMS_DATA_LEN + 1];

    /*
     * yh: 1997/09/09.
     *       new fields for multiple currency support
     */
	amount_t	new_amount_equiv;	       /* replacement amount in issuer currency */

	amount_t	acq_aval_balance;	       /* aval_balance in acquirer currency */
	amount_t	acq_ledger_balance;	     /* ledger_balance in acquirer currency */
	amount_t	setl_aval_balance;	      /* aval_balance in settlement currency */
	amount_t	setl_ledger_balance;    /* ledger_balance in settlement currency */

	short	   aval_balance_type;	      /* aval_balance amount type */
	short	   ledger_balance_type;    /* ledger_balance amount type */

	amount_t	new_setl_fee;		   /* fee in the event of a partial reverssal */

	amount_t	txn_amount;			     /* txn amount in transaction currency */
	amount_t	txn_new_amount;		 /* replacement amount in transaction currency */
	short	   txn_currency_code;	      /* currency code of transaction */
	amount_t	txn_conv_rate;		  /* conversion rate applies in acquirer side */
	date_t	  txn_conv_date;		  /* date txn_conv_rate is good at */

	amount_t	ch_amount;			      /* txn amount in CH's billing currency */
	amount_t	ch_new_amount;		  /* replacement amount in CH's billing ccy */
	short	   ch_currency_code;	       /* CH's billing currency code */
	amount_t	ch_conv_rate;		   /* conversion rate applies in issuer side */
	date_t	  ch_conv_date;		   /* date ch_conv_rate is good at */

	/*
	* qd 24nov97 New fields added for ACXSYS
	*/
	char       kmac_mfk[74 + 1];	 /* KMAC Cryptogram */
	char       kmac_kekcnt[KEY_CNT_LEN+1];    /* KEK Counter for KMAC */
	char       mac_value[SHC_KEY_LEN];	/* MAC Value */

	char       kpe_mfk[74 + 1];	  /* KPE Cryptogram */
	char       kpe_kekcnt[KEY_CNT_LEN+1];     /* KEK Counter for KPE */

	char       kme_mfk[74 + 1];	  /* KME Cryptogram */
	char       kme_kekcnt[KEY_CNT_LEN+1];     /* KEK Counter for KME */
	char       kme_index;		     /* KME index */

	char       sec_fmt_code[3];	       /* Security format code */

	bin_t      forward_inst_id;	       /* Forwarding Institution ID */
	bin_t      receive_inst_id;	       /* Receiving Institution ID */

	short      slot_num;		      /* Reconciliation slot number */
	date_t     origcapdate;		   /* Original Capture Date */

	int saf_devcap;		    /* SAF related flags */

	char       expected_kekcnt[KEY_CNT_LEN+1]; /* Expected KEK Counter */
	char       cvv2[CVV_LEN+2];     /*  Card Verification Value(Code) */ /*R006976*/

	/*Note: field define below should not be used by formatters or agent to
			store any other data then that defined in structure shc_data.
			Mapping other structures may result in incompatiblity during
			further releases  R003928*/
	char	shc_data_buffer[SHC_DATA_LEN+1]; /*Buffer to store shc specific
												additional data */

	/*R005324 */
	int keylen;
	/* R006365 */
	secdukpt_t		      dukpt;

	char	shclog_id[21];
	date_t  processor_busday;			       /* Processor Business Day*/
	unsigned int    seq_trace_no;
	int site_id;
	int version;
	int src_node;
	int dest_node;


#ifdef USE_ELF_BUFFER
	/*
		On Alpha architecture, long is expected to be 8 byte width
		and aligned on 8-byte boundary.
		On other architecture, long is expected to be 4 byte width
		and aligned on 4-byte boundary.
	*/
	int alignment_adjust ;
	char    elfbuffer[ELF_BUFF_SIZE];
#endif
	long alignment_adjust_for_seg;
	};

	struct  shcbin
	{
		bin_t institutionid;
		bin_t userbinid;
		bin_t networkid;
		bin_t owner;
		int mailbox;
		int port;
		int netmgrid;
		int bintype;
		long timeout;
		unsigned long flags;
		date_t settle_date;
		int pinparm;
		int keyparm;
		short country_code;
		short currency_code;
		short cvvdate;
		int cardid;
		int statid;
		long last_online_activity;
		char bankname[SHC_BANKNAME_LEN + 1];
		int cammailboxid;
		unsigned long bin_cfg;
	};
	struct shctransaction
	{
		amount_t amount;
		short npintry;
		unsigned long txnset;
	};
	struct shcauth
	{
		short type;
		int authserver;
		amount_t floor_1;
		amount_t floor_2;
		amount_t floor_3;
		amount_t acq_minamount;
		amount_t iss_minamount;
		short def_from_acct;
		short def_to_acct;
	};
	struct shcsaf
	{
		short type;
		amount_t amount;
		int num;
		long refreshtime;
		int fd;
		int posmailbox;
		int replayid;
	};
	struct  shcpkg
	{
		struct  shcbin bin;
		struct  shctransaction txn;
		struct  shcauth auth;
		struct  shcsaf saf;
	};
}//namespace base

