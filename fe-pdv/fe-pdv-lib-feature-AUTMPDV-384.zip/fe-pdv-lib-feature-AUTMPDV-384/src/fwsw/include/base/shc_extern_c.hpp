/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/shc_structs.hpp"

extern "C" double dbm_dectodbl( base::oasis_dec_t *d1 );
extern "C" long dbm_dectolong( base::oasis_dec_t *d1 );
extern "C" int dbm_dectochar( base::oasis_dec_t *d1, char *bp );
extern "C" int dbm_dectocharnd( base::oasis_dec_t *d1, char *bp );
extern "C" int dbm_dectochar_conv( base::oasis_dec_t *src, char *dest, int ndigits );
extern "C" int dbm_chartodec( base::oasis_dec_t * d1, char * c, int decpoint );
extern "C" int dbm_dbltodec( base::oasis_dec_t *d1, double d2 );
extern "C" int dbm_decadd( base::oasis_dec_t *d1, base::oasis_dec_t *d2, base::oasis_dec_t *d3 );
extern "C" int dbm_decsub( base::oasis_dec_t *d1, base::oasis_dec_t *d2, base::oasis_dec_t *d3 );
extern "C" int dbm_decmul( base::oasis_dec_t *d1, base::oasis_dec_t *d2, base::oasis_dec_t *d3 );
extern "C" int dbm_decdiv( base::oasis_dec_t *d1, base::oasis_dec_t *d2, base::oasis_dec_t *d3 );
extern "C" int dbm_cmpzero( base::oasis_dec_t *d1 );
extern "C" int shc_init( );
extern "C" int dbm_init( );
extern "C" int dbm_init_dec( );

