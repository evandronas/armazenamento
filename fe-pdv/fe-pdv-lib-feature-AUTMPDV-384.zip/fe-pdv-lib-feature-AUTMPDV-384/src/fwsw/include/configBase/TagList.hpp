/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <string>
#include "configBase/Tag.hpp"


namespace configBase
{
	class TagList
	{
	public:
		TagList( );
		TagList( const std::string& a_tagListName );
		virtual ~TagList( );
		TagList& addTag( const Tag& a_tag );
		TagList& clear( );
		TagList& setName( const std::string& a_tagListName );
		unsigned int size( ) const;
		const Tag& at( unsigned int a_index ) const;
		Tag& at( unsigned int a_index );
		const Tag& operator[]( unsigned int a_index ) const;
		Tag& operator[]( unsigned int a_index );
		const Tag& front( ) const;
		Tag& front( );
		const Tag& back( ) const;
		Tag& back( );
	private:
		typedef std::deque<Tag> TAG_DEQUE;
		TAG_DEQUE m_tags;
		std::string m_tagListName;
	};
}//namespace configBase

