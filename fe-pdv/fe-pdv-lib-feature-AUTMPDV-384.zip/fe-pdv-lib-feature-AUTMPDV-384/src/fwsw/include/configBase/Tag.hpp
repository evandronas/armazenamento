/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <map>
#include <string>
#include "configBase/Property.hpp"


namespace configBase
{
	class TagList;
	class Tag
	{
	public:
		Tag( );
		Tag( const std::string& a_tagName, const std::string& a_sourceId, unsigned int a_sequence );
		virtual ~Tag( );
		Tag& setName( const std::string& a_name );
		Tag& setSourceId( const std::string& a_sourceId );
		Tag& setSequence( unsigned int a_sequence );
		Tag& addTag( const Tag& a_tag );
		Tag& addProperty( const Property& a_property );
		Tag& clear( );
		unsigned int tagCount( ) const;
		unsigned int propertyCount( ) const;
		Tag& tagAt( unsigned int a_index );
		const Tag& tagAt( unsigned int a_index ) const;
		Property& propertyAt( unsigned int a_index );
		const Property& propertyAt( unsigned int a_index ) const;
		const Tag& findTag( const std::string& a_tagName, TagList& a_tagList ) const;
		const Tag& findTag( const std::string& a_tagName, const std::string& a_propertyName, const std::string& a_propertyValue, TagList& a_tagList ) const;
		bool findTagNotRequired( const std::string& a_tagName, TagList& a_tagList ) const;
		bool findTagNotRequired( const std::string& a_tagName, const std::string& a_propertyName, const std::string& a_propertyValue, TagList& a_tagList ) const;
		Property findProperty( const std::string& a_propertyName ) const;
		Property findPropertyNotRequired( const std::string& a_propertyName ) const;
		const std::string& name( ) const;
		const std::string& sourceId( ) const;
		unsigned int sequence( ) const;
		static void enableDumpMode( bool a_enable = true );
	private:
		typedef std::deque<Tag> TAG_DEQUE;
		typedef std::deque<Property> PROP_DEQUE;
		typedef std::multimap<std::string, unsigned int> TAG_MAP;
		typedef std::pair<std::string, unsigned int> TAG_PAIR;
		typedef std::map<std::string, unsigned int> PROP_MAP;
		typedef std::pair<std::string, unsigned int> PROP_PAIR;
		TAG_DEQUE m_tags;
		PROP_DEQUE m_properties;
		TAG_MAP m_tagsIndex;
		PROP_MAP m_propertiesIndex;
		std::string m_name;
		std::string m_sourceId;
		unsigned int m_sequence;
		static bool m_dumpMode;
	};
}//namespace configBase

