/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>

namespace configBase
{
	class Property
	{
	public:
		Property( );
		Property( bool a_valid );
		Property( const std::string& a_name );
		Property( const std::string& a_name, const std::string& a_value );
		virtual ~Property( );
		Property& setName( const std::string& a_name );
		Property& setValue( const std::string& a_value );
		const std::string& name( ) const;
		std::string value( ) const;
		bool isValid( ) const;
	private:
		std::string m_name;
		std::string m_value;
		bool m_valid;
	};
}//namespace configBase

