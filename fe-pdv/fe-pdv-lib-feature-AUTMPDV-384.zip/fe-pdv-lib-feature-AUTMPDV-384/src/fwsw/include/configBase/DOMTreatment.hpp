/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "configBase/Tag.hpp"
#include "configBase/XMLParseErrorHandler.hpp"
#include "xercesc/dom/DOM.hpp"
#include "xercesc/dom/DOMNamedNodeMap.hpp"
#include "xercesc/dom/DOMNode.hpp"
#include "xercesc/dom/DOMNodeList.hpp"
#include "xercesc/dom/DOMTreeWalker.hpp"
#include "xercesc/framework/MemBufInputSource.hpp"
#include "xercesc/parsers/XercesDOMParser.hpp"
#include "xercesc/sax/HandlerBase.hpp"
#include "xercesc/util/PlatformUtils.hpp"
#include "xercesc/util/XMLString.hpp"

namespace configBase
{
	class DOMTreatment
	{
	public:
		DOMTreatment( );
		virtual ~DOMTreatment( );
		bool load( const std::string& a_path, const std::string& a_name, Tag& a_tag );
		bool load( const std::string& a_fullName, Tag& a_tag );
		const XMLParseErrorHandler::ERRMSGS& errors( ) const;
	private:
		std::string m_pathName;
		xercesc::DOMDocument *m_xmldoc;
		xercesc::XercesDOMParser* m_parser;
		XMLParseErrorHandler* m_errHandler;
		bool open( );
		xercesc::DOMElement* rootDocumentNode( );
		void setFile( const std::string& a_path, const std::string& a_name );
		bool xmlParser( xercesc::DOMNode *a_node, Tag& a_tag );
		void close( );
	};
}//namespace configBase

