/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <string>
#include <xercesc/sax/HandlerBase.hpp>
#include <xercesc/sax/SAXParseException.hpp>


namespace configBase
{
	class XMLParseErrorHandler : public xercesc::HandlerBase
	{
	public:
		class ErrorMsg
		{
		public:
			ErrorMsg( )
			{
			}
			ErrorMsg( const std::string& a_publicFile, const std::string& a_systemFile, const std::string& a_msg, unsigned int a_line, unsigned int a_column )
			{
				m_publicFile = a_publicFile;
				m_systemFile = a_systemFile;
				m_errorMessage = a_msg;
				m_lineNumber = a_line;
				m_columnNumber = a_column;
			}
			const std::string& publicFile( ) const
			{
				return m_publicFile;
			}
			const std::string& systemFile( ) const
			{
				return m_systemFile;
			}
			const std::string& message( ) const
			{
				return m_errorMessage;
			}
			unsigned int lineNumber( ) const
			{
				return m_lineNumber;
			}
			unsigned int columnNumber( ) const
			{
				return m_columnNumber;
			}
		private:
			std::string m_publicFile;
			std::string m_systemFile;
			std::string m_errorMessage;
			unsigned int m_lineNumber;
			unsigned int m_columnNumber;
		};
		typedef std::deque<ErrorMsg> ERRMSGS;
		XMLParseErrorHandler( );
		virtual ~XMLParseErrorHandler( );
		void warning( const xercesc::SAXParseException& a_saxParseException );
		void error( const xercesc::SAXParseException& a_saxParseException );
		void fatalError( const xercesc::SAXParseException& a_saxParseException );
		void resetErrors( const xercesc::SAXParseException& a_saxParseException );
		const ERRMSGS& errors( ) const;
		void clear( );
	private:
		ERRMSGS m_errors;
	};
}//namespace configBase

