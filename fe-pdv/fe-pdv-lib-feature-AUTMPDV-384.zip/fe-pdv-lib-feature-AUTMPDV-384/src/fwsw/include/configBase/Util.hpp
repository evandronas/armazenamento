/* Copyright 2014 Rede S.A.
Autor : Luiz Gustavo O Costa
Empresa : BSI Tecnologia
*/

#pragma once

namespace configBase
{
	// Util
	// Classe auxiliar para controle de sleep
	// EF/ET: 64145
	// Hist�rico: [24/06/2014] - 64145 - Release IV de 2014	
	class Util
	{
	public:
		Util( );
		virtual ~Util( );
		static void Sleep();
	private:
		static unsigned long min_usleeptime_init;
		static unsigned long margin_usleeptime_init;
	};
}//namespace configBase

