#pragma once
#include <sstream>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "logger/Logger.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createStrFunctions( );
	class StrFunctions: public dataManip::Command
	{
	public:
		StrFunctions( );
		virtual ~StrFunctions( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		
		fieldSet::ConstFieldAccess m_sourceField;
	
		std::vector< fieldSet::ConstFieldAccess > m_sourceFields;
		std::vector< configBase::Tag > tagsSourceFields;
		std::vector< fieldSet::FieldAccess > m_targetFields;
		std::vector< configBase::Tag > tagsTargetFields;
		
        configBase::Tag m_action;
        configBase::Tag m_sourceValueMask;
		
        std::string m_dateMask;
        std::string m_type_action;
		
        bool parseSources( );
        bool parseTargets( );

        bool isLeapYear( int year );
        void char_to_binary( char *dest, char *orig, int len);
        
        bool validaEstruturaSubstr( );
        bool validaValoresSubstr( const unsigned long &posInicial,
                                  const unsigned long &tamSubstr,
                                  const std::string &str );
                                  
        bool validaEstruturaFind( );
        bool validaEstruturaAppendPrepend( );
        bool validaEstruturaIsNumeric( );
        bool ValidarEstruturaIsAlpha( );
        bool ValidarEstruturaIsAlphaNumeric( );
        bool validaEstruturaIsDate( );
        bool validaValoresStrings( );
        bool validaEstruturaPadChar( );
        bool validaEstruturaCompare( );
	};
}//namespace standardPlugins
