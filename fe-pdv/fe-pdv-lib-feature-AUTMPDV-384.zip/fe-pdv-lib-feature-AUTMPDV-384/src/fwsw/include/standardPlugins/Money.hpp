/*
*******************************************************************
* (c) Moneyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW75
/ Descricao: Novo Plugin para Conversao de Valores e Money
/ Autor: Renato de Camargo
/ Data de Alteracao : 03/06/2019
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* CreateMoney( );
	class Money : public dataManip::Command
	{
	public:
		Money( );
		virtual ~Money( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Money& SetSourceFieldPath( const std::string& path );
		Money& SetTargetFieldPath( const std::string& path );
	private:
		bool startConfiguration( const configBase::Tag* tag );
		fieldSet::ConstFieldAccess sourceField;
		fieldSet::FieldAccess targetField;
		int  numberDecimal;

		std::string targetValueMask;
		std::string sourceFieldPath;
		std::string targetFieldPath;
	};
}//namespace standardPlugins

