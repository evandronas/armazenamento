/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Teller
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t689064, Raphael Teller, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <iostream>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "standardPlugins/MaskPiece.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createDateTime( );
	class DateTime : public dataManip::Command
	{
	public:
		DateTime( );
		virtual ~DateTime( );

		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;

		DateTime& setSourceFieldPath( const std::string& a_path );
		DateTime& setTargetFieldPath( const std::string& a_path );
		DateTime& setSourceValueMask( const std::string& a_sourceValueMask );
		DateTime& setTargetValueMask( const std::string& a_targetValueMask );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void dateCheck( std::string& a_date, const std::string& a_mask );

		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;

		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_sourceValueMask;
		std::string m_targetValueMask;

		std::deque<standardPlugins::MaskPiece> m_pieces;

		bool m_bothUnix;
		bool m_compareGMT;
	};
}//namespace standardPlugins

