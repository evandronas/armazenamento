/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once


namespace standardPlugins
{
	class MaskPiece
	{
	public:
		MaskPiece( );
		virtual ~MaskPiece( );
		void setSourceMask( std::string a_sourceMask );
		void setSourcePos( unsigned int a_sourcePos );
		void setSourceLength( unsigned int a_sourceLength );
		void setTargetMask( std::string a_targetMask );
		void setTargetPos( unsigned int a_targetPos );
		void setTargetLength( unsigned int a_targetLength );
		std::string sourceMask( );
		unsigned int sourcePos( );
		unsigned int sourceLength( );
		std::string targetMask( );
		unsigned int targetPos( );
		unsigned int targetLength( );
	private:
		std::string m_sourceMask;
		unsigned int m_sourcePos;
		unsigned int m_sourceLength;
		std::string m_targetMask;
		unsigned int m_targetPos;
		unsigned int m_targetLength;
	};
}//namespace standardPlugins

