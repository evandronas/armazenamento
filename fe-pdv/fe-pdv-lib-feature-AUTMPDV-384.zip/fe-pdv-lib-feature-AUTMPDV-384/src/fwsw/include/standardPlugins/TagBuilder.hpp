/* Copyright 2014 Rede S.A.
Autor : Luiz Gustavo O Costa
Empresa : BSI Tecnologia
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "msgConv/DataElementProperties.hpp"
#include "msgConv/DataCoding.hpp"
#include <map>

namespace standardPlugins
{
	extern "C" base::Identificable* createTagBuilder( );
	
	// TagBuilder
	// Classe para construcao de tags
	// EF/ET: 44179
	// Hist�rico: [06/10/2014] - 44179 - Release I de 2014
	class TagBuilder : public dataManip::Command
	{
	public:
		TagBuilder( );
		virtual ~TagBuilder( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		TagBuilder& setTargetFieldPath( const std::string& a_path );
		TagBuilder& setSourceFieldPath( const std::string& a_path );
		TagBuilder& setTagNameSize( unsigned int a_tagNameSize );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		msgConv::DataCoding getDataType( const std::string& a_type );
		void convertToAscii( std::string& a_ascii, const std::string& a_input, msgConv::DataCoding a_dataCoding );
		unsigned int convertToHEX( unsigned char*a_hex, unsigned int a_hexSize, const std::string& a_input, msgConv::DataCoding a_dataCoding );
		unsigned int calculateSize( unsigned int a_numDigits, msgConv::DataCoding a_dataCoding );
		fieldSet::FieldAccess m_targetField;
		std::string m_targetFieldPath;
		std::string m_headerValue;
		fieldSet::FieldAccess m_sourceField;
		std::string m_sourceFieldPath;
		unsigned int m_tagNameSize;
		unsigned int m_qtdTags;
		unsigned int m_defaultTagLengthSize;
		std::string m_listTags;
		typedef std::map<std::string,msgConv::DataElementProperties> TP_MAP;
		typedef std::pair<std::string,msgConv::DataElementProperties> TP_PAIR;
		TP_MAP m_descTags;
		unsigned char* m_auxBuffer;
		unsigned int m_auxBufferLength;
		unsigned int m_headerSize;
		msgConv::DataCoding m_tagNameDataType;
	};
}//namespace standardPlugins
