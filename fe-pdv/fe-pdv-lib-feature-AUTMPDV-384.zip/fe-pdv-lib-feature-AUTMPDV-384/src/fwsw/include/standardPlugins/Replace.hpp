/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2013, 10 de janeiro
/ Hist�rico Mudan�as: 2013, 10 de janeiro, t689066, Alexandre Teodoro Guimaraes
                                                               , Versao Inicial
/ -----------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createReplace( );
	class Replace : public dataManip::Command
	{
	public:
		Replace( );
		virtual ~Replace( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Replace& setSourceFieldPath( const std::string& a_path );
		Replace& setTargetFieldPath( const std::string& a_path );
		Replace& setSourceValue( const std::string& a_value );
		Replace& setLength( const int a_value );
		Replace& setStartPosition( const int a_value );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
        std::string m_sourceValue;           
		int m_length;
		int m_startPosition;
	};
}//namespace standardPlugins

