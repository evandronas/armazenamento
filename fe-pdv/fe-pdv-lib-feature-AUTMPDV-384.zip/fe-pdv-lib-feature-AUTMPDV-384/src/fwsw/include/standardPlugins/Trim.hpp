/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createTrim( );
	class Trim : public dataManip::Command
	{
	public:
		Trim( );
		virtual ~Trim( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Trim& setSourceFieldPath( const std::string& a_path );
		Trim& setTargetFieldPath( const std::string& a_path );
		Trim& setTrimmingChar( const std::string& a_value );
		Trim& enableLeftTrimming( bool a_leftTrimming );
		Trim& enableRightTrimming( bool a_rightTrimming );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_trimmingChar;
		bool m_leftTrimming;
		bool m_rightTrimming;
	};
}//namespace standardPlugins

