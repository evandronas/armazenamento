/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "engine/MessageDirection.hpp"
#include "engine/TrxEngine.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "logger/Logger.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createStandardTrxEngine( );
	class StandardTrxEngine : public engine::TrxEngine
	{
	public:
		StandardTrxEngine( );
		virtual ~StandardTrxEngine( );
		bool open( );
		void close( );
		engine::MessageDirection onRequest( );
		engine::MessageDirection onNegativeRequest( );
		engine::MessageDirection onResponse( );
		int onCommand( );
		int onEvent( );
		bool startConfiguration( const configBase::Tag* a_tag );
		void onRequestException( const base::GenException& a_exception );
		void onRequestNegativeException( const base::GenException& a_exception );
		void onResponseException( const base::GenException& a_exception );
		void onCommandException( const base::GenException& a_exception );
		void onEventException( const base::GenException& a_exception );		
		void onRequestException( const std::exception& a_exception );
		void onRequestNegativeException( const std::exception& a_exception );
		void onResponseException( const std::exception& a_exception );
		void onCommandException( const std::exception& a_exception );
		void onEventException( const std::exception& a_exception );
		void onRequestException( );
		void onRequestNegativeException( );
		void onResponseException( );
		void onCommandException( );
		void onEventException( );
	private:
		fieldSet::FieldAccess m_messageDirection;
		logger::Logger* m_logger;
	};
}//namespace standardPlugins

