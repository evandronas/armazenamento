/* Copyright 2020 Rede S.A.
Autor : Daniel Nava
Empresa : Leega
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "logger/LoggerGen.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createRemoveTagDE55( );

/// RemoveTagDE55
/// Classe herdada da dataManip::Command para localizar e remover tag do DE55
/// EF/ET: EAK-2361
/// Historico: 06/02/2020 � Daniel Nava - EAK-2361 - Versao inicial
	class RemoveTagDE55 : public dataManip::Command
	{
	public:
		RemoveTagDE55( );
		virtual ~RemoveTagDE55( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		RemoveTagDE55& setTargetFieldPath( const std::string& a_path );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );
        std::string FindChipTag( std::string dadoDe55, int &posicao );
        std::string FindChipConteudo( std::string dadoDe55, int &posicao, int tamanho );
        int FindChipLen( std::string dadoDe55, int &posicao );
		fieldSet::FieldAccess conteudoDe55;
		fieldSet::FieldAccess resultadoDe55;
		fieldSet::FieldAccess bufferDe55;
		fieldSet::FieldAccess headerDe55;
		fieldSet::FieldAccess tagDe55;
		fieldSet::FieldAccess sizeDe55;
		
		std::string targetPath;
	};
}//namespace standardPlugins

