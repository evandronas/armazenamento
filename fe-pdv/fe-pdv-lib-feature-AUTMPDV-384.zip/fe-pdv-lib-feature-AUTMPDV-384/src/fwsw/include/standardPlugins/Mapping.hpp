/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2012, 14 de agosto
/ Hist�rico Mudan�as: 2012, 14 de agosto, t689066, Alexandre Teodoro Guimaraes, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <map>
#include <vector>
#include <string>
#include "configBase/XMLParseErrorHandler.hpp"
#include "dataManip/Command.hpp"
#include "logger/Logger.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createMapping( );
	class Mapping : public dataManip::Command
	{
	public: 
		Mapping( ); 
		virtual ~Mapping( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Mapping& setXmlFullName( const std::string& a_path );
		Mapping& setReferenceLabel( const std::string& a_value );
		Mapping& setSourceValue( const std::string& a_value );
		Mapping& setSourceFieldPath( const std::string& a_path );
		Mapping& setTargetFieldPath( const std::string& a_path );
		
		static void clearTags( );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void reportXmlErrors( const configBase::XMLParseErrorHandler::ERRMSGS& a_errors );
		bool loadXmlFile( );
		
		std::vector<fieldSet::ConstFieldAccess> m_sourceField;
		std::vector<fieldSet::FieldAccess> m_targetField;		
		std::string m_sourceValue;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;		
		std::string m_xmlFullName;
		std::string m_referenceLabel;
		logger::Logger* m_logger;
		typedef std::map<std::string,configBase::Tag> TP_MAP;
		typedef std::pair<std::string,configBase::Tag> TP_PAIR;
		
		static TP_MAP m_mapXmlFile;
		
		typedef std::map<std::string, std::string> TP_USRMAP;
		typedef std::map<std::string, TP_USRMAP> TP_MAP_TO_USRMAP;
		typedef std::pair<std::string, TP_USRMAP> PAIR_MAP_TO_USRMAP;
		static TP_MAP_TO_USRMAP m_mapToUsrMapping;
		TP_MAP_TO_USRMAP::iterator m_mapping;
	};
}//namespace standardPlugins

