/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "expr/FieldElement.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createConcat( );
	class Concat : public dataManip::Command
	{
	public:
		Concat( );
		virtual ~Concat( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Concat& setSourceFieldPath( const std::string& a_path );
		Concat& setTargetFieldPath( const std::string& a_path );
		Concat& setConcatSide( const std::string& a_concatSide );
		Concat& setConcatValue( const std::string& a_concatValue );
		Concat& setConcatFieldSetPath( const std::string& a_concatFieldSetPath );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		bool CreateElement( const configBase::Tag & a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_concatSide;
		std::string m_concatValue;
		std::string m_concatFieldSetPath;
		typedef std::deque< configBase::Tag > DEF_DEQUE_TAGS;
		typedef std::deque< expr::Element * > DEF_DEQUE_VALUES;
		DEF_DEQUE_TAGS m_tags;
		DEF_DEQUE_VALUES m_values;
	};
}//namespace standardPlugins
