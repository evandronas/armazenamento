/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Amaral
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Amaral, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createExit( );
	class Exit : public dataManip::Command
	{
	public:
		Exit( );
		virtual ~Exit( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
	};
}//namespace standardPlugins

