/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descricao:
/ Conteudo:
/ Autor: 313825, Mauro T da Silva
/ Data de Criacao: 2020, 05 de julho
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "cryptography/CryptoHASH.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createHash( );
	class Hash : public dataManip::Command
	{
	public:
		Hash( );
		virtual ~Hash( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Hash& setSourceFieldPath( const std::string& a_path );
		Hash& setTargetFieldPath( const std::string& a_path );
		Hash& setStartPosition( unsigned int a_value );
		Hash& setLength( unsigned int a_length );
		Hash& setMode( unsigned short a_mode );
		Hash& setEndingChar( char a_char );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		fieldSet::ConstFieldAccess m_startVar;
		fieldSet::ConstFieldAccess m_lengthVar;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_strStartPosition;
		std::string m_strLength;
		unsigned int m_startPosition;
		unsigned int m_length;
        unsigned short m_mode;
        char m_endingChar;
		bool m_startIsVar;
		bool m_lengthIsVar;

		// Crypt
		cryptography::CryptoHASH cryptoHash;
		#define MAX_BUFF_SIZE 16
		fieldSet::FieldAccess m_result;
		char m_bufferHash[1024];
		std::string m_dataHashValue;
	};
}//namespace standardPlugins
