/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

#pragma once
#include <string>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "dataManip/Command.hpp"

namespace standardPlugins
{
    extern "C" base::Identificable* createSetBits( );
    class SetBits : public dataManip::Command
    {
        public:
            SetBits( );
            virtual ~SetBits( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            SetBits& setTargetFieldPath( const std::string& a_path );
            SetBits& setSourceFieldPath( const std::string& a_path );
            SetBits& setSourceValue( const std::string& a_value );
            SetBits& setOperation( const std::string& a_value );
        private:
            bool startConfiguration( const configBase::Tag* a_tag );
            fieldSet::FieldAccess m_targetField;
            fieldSet::ConstFieldAccess m_sourceField;
            std::string m_sourceValue;
            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_operation;
    };

}//namespace standardPlugins

