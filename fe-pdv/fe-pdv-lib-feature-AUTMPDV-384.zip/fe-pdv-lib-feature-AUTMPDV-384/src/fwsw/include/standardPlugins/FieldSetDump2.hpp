/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 07/11/2018
Empresa  : Rede
Descricao: Modifica��es para permitir controle do n�vel de log por par�metro (loggerLevel e SetLoggerLevel)
ID       : AM 237648
*************************************************************
*/

#pragma once
#include <sstream>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "logger/Logger.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createFieldSetDump2( );
	class FieldSetDump2: public dataManip::Command
	{
	public:
		FieldSetDump2( );
		virtual ~FieldSetDump2( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		FieldSetDump2& setSourceFieldPath( const std::string& a_path );
		FieldSetDump2& SetLoggerLevel( const std::string& logLvl );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void logField( const fieldSet::Field& a_field, const std::string& a_path );
		fieldSet::ConstFieldAccess m_sourceField;
		std::string m_sourceFieldPath;
		logger::Level loggerLevel;
		fieldSet::ConstFieldAccess m_label_dump;
		logger::Logger* m_logger;
	};
}//namespace standardPlugins

