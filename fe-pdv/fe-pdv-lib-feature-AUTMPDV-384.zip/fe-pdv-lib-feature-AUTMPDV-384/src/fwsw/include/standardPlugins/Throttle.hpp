/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ---------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o: Arquivo de cabe�alho da classe throttle::Throttle
/ Conte�do: Lista de M�dulos definidos
/ Autor: 689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2012, 08 de Junho
/ Hist�rico Mudan�as: 2012, 08 de Junho, t689066, Alexandre Teodoro Guimaraes
, Versao Inicial
/ ---------------------------------------------------------------------------
*/
#pragma once
#include "fieldSet/FieldSet.hpp"
#include "mailboxInterface/MailboxIn.hpp"
#include "dataManip/Command.hpp"
#include <map>
#include <vector>
//#define	FMTTHROTTLELOGDIR				"."
#define TRTL_MAX_LEVELS					20	
#define SHCTHROTTLE_RULE_NAME			"shc-throttle-params"
#define TRTL_STOP_LOG  					1
#define	TRTL_STOP_RESPOND				2
#define TRTL_DROP_MISC_REQ				4
#define TRTL_DROP_MISC_RESP				8
#define TRTL_DROP_0800_REQ				16	
#define TRTL_DROP_0800_RESP				32	
#define TRTL_DROP_ADVICE_REQ 			64		
#define TRTL_DROP_ADVICE_RESP 			128	
#define TRTL_DROP_AUTHORIZATION_REQ		256	
#define TRTL_DROP_AUTHORIZATION_RESP	512	
#define TRTL_DROP_FINANCIAL_REQ			1024		
#define TRTL_DROP_FINANCIAL_RESP		2048		
#define TRTL_DROP_REVERSAL_REQ			4096		
#define TRTL_DROP_REVERSAL_RESP			8192

namespace standardPlugins
{
	extern "C" base::Identificable* createThrottle();	
	class Throttle : public dataManip::Command	
	{
	public:
		Throttle();
		virtual ~Throttle();
		bool init();
		void finish();
		int execute( bool& a_stop );
		dataManip::Command* clone() const;
		typedef std::map<std::string, int> ThrottleMap;	
		Throttle& SetLocalFieldPath( const std::string& a_path );
		Throttle& setSourceFieldPath( const std::string& a_path );
		Throttle& setTargetFieldPath( const std::string& a_path );
		Throttle& setmailboxName( const std::string& a_value );
        Throttle& setPortNamePath( const std::string& a_path );
	private:			
		bool startConfiguration( const configBase::Tag* a_tag );	
		int curLevel(); 
		int checkThrottle();
		int determineFrequency( int a_level ); 
		int threshold( int a_index ); 
		int frequency( int a_index ); 
		int	action( int a_level );		
		void recordMsg( int a_level, bool a_brespond );
		int m_numOfLevels;
		int m_thresholds[TRTL_MAX_LEVELS];
		int m_frequencies[TRTL_MAX_LEVELS];
		long m_actions[TRTL_MAX_LEVELS];		
		int m_normalFrequency;
		static ThrottleMap* m_throttleMap; 
		mailboxInterface::MailboxIn m_throttleMailBoxIn;
		fieldSet::ConstFieldAccess m_sourceField;
        fieldSet::ConstFieldAccess m_portName;
		fieldSet::FieldAccess m_targetField;
		fieldSet::FieldAccess targetFieldTranscode;
		fieldSet::FieldAccess targetFieldTerminalPdv;
		fieldSet::FieldAccess targetFieldOrigTrace;
		fieldSet::FieldAccess targetFieldOrigDate;
		fieldSet::FieldAccess targetFieldOrigTime;
		fieldSet::FieldAccess targetFieldTranDate;
		fieldSet::FieldAccess targetFieldTranTime;
		fieldSet::FieldAccess localField;
		std::string m_sourceFieldPath;
		std::string localFieldPath;
		std::string m_targetFieldPath;
		std::string m_mailboxName;
        std::string m_portNamePath;        
	};
}//namespace throttle
