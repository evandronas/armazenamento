/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Teller
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t689064, Raphael Teller, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <iostream>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "standardPlugins/MaskPiece.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createDateTime2( );
	class DateTime2 : public dataManip::Command
	{
	public:
		DateTime2( );
		virtual ~DateTime2( );

		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;

		DateTime2& setSourceFieldPath( const std::string& a_path );
		DateTime2& setTargetFieldPath( const std::string& a_path );
		DateTime2& setSourceValueMask( const std::string& a_sourceValueMask );
		DateTime2& setTargetValueMask( const std::string& a_targetValueMask );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );

		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;

		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_sourceValueMask;
		std::string m_targetValueMask;

		std::deque<standardPlugins::MaskPiece> m_pieces;

		bool m_bothUnix;
		bool m_compareGMT;
	};
}//namespace standardPlugins

