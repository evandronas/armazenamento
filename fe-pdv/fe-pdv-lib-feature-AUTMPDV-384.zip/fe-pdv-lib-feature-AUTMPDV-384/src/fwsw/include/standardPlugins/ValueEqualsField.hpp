/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "dataManip/WhenClause.hpp"
#include "fieldSet/ConstFieldAccess.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createValueEqualsField( );
	class ValueEqualsField : public dataManip::WhenClause
	{
	public:
		ValueEqualsField( );
		virtual ~ValueEqualsField( );
		bool init( );
		void finish( );
		bool goAhead( ) const;
		dataManip::WhenClause* clone( ) const;
		ValueEqualsField& setCompareFieldPath( const std::string& a_path );
		ValueEqualsField& setCompareValue( const std::string& a_value );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_compareField;
		std::string m_compareValue;
		std::string m_compareFieldPath;
	};
}//namespace standardPlugins

