/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -----------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Guimaraes
/ Data de Cria��o: 2012, 20 de setembro
/ Hist�rico Mudan�as: 2012, 20 de setembro, t689066, Alexandre Guimaraes, 
/                                                                Versao Inicial
/ -----------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
//#include "fieldSet/FieldAccess.hpp"
//#include "fieldSet/FieldSet.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createStats( );
	class Stats : public dataManip::Command
	{
	public:
		Stats( );
		virtual ~Stats( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Stats& setSourceFieldPath( const std::string& a_path );
		Stats& setInputFile( const std::string& a_value );
        Stats& setVertice( const std::string& a_value );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		std::string m_sourceFieldPath;
		std::string m_inputFile;
        std::string m_vertice;
		static FILE * m_file;
        
	};
}//namespace standardPlugins

