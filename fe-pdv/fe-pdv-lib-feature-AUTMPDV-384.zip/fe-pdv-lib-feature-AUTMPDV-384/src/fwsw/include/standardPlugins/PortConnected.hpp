/*
Copyright 2019 Rede S.A.
*********************** MODIFICACOES ************************
/ -------------------------------------------------------------------------------------------------
Autor    : Renato de Camargo
Data     : 14/02/2019
Empresa  : Rede
Descricao: Vers�o Inicial
ID       : EAK 1420
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"


enum PortStatus 
{
	// Porta Stopada
	PORT_STOPPED = 1,
	
	// Porta Connected
	PORT_CONNECTED = 2,
	
	// Porta Disconectada
	PORT_DISCONNECTED = 4
};

namespace standardPlugins
{
	extern "C" base::Identificable* createPortConnected( );
	class PortConnected : public dataManip::Command
	{
	public:
		PortConnected( );
		virtual ~PortConnected( );
		bool init( );
		void finish( );
		int execute( bool& stop );
		dataManip::Command* clone( ) const;
	private:
		bool startConfiguration( const configBase::Tag* tag );
		int IsConnected();
		std::string portName;
		fieldSet::ConstFieldAccess sourceField;
		std::string sourceFieldPath;
		std::string targetFieldPath;
		fieldSet::FieldAccess targetField;
	};
}//namespace standardPlugins

