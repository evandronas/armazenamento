/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createSubstring( );
	class Substring : public dataManip::Command
	{
	public:
		Substring( );
		virtual ~Substring( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Substring& setSourceFieldPath( const std::string& a_path );
		Substring& setTargetFieldPath( const std::string& a_path );
		Substring& setStartPosition( unsigned int a_value );
		Substring& setLength( unsigned int a_length );
        Substring& setMode( unsigned short a_mode );
        Substring& setEndingChar( char a_char );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		fieldSet::ConstFieldAccess m_startVar;
		fieldSet::ConstFieldAccess m_lengthVar;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_strStartPosition;
		std::string m_strLength;
		unsigned int m_startPosition;
		unsigned int m_length;
        unsigned short m_mode;
        char m_endingChar;
		bool m_startIsVar;
		bool m_lengthIsVar;
	};
}//namespace standardPlugins

