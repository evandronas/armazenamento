/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

#pragma once

#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "mailboxInterface/MailboxLocator.hpp"

namespace undoingDeals
{
	extern "C" base::Identificable* createMBLocatorGeral( );
	class MBLocatorGeral : public dataManip::Command
	{
	public:
		MBLocatorGeral( );
		virtual ~MBLocatorGeral( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		MBLocatorGeral& setMailboxName( const std::string& a_mailboxName );
		MBLocatorGeral& setMailboxNameFieldPath( const std::string& a_mailboxNameFieldPath );
		MBLocatorGeral& setNetworkId( const std::string& a_networkId );
		MBLocatorGeral& setNetworkIdFieldPath( const std::string& a_networkIdFieldPath );
		MBLocatorGeral& setTargetFieldPath( const std::string& a_path );
        MBLocatorGeral& setPropertyToGet( const std::string& a_property );
		std::string getMailboxNameByNetworkId( const std::string& a_networkId );
		std::string getPortaByNetworkId( const std::string& a_networkId );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_targetField;
		fieldSet::FieldAccess m_mailboxField;
		fieldSet::FieldAccess m_networkIdField;
		std::string m_operacao;
		std::string m_mailboxName;
		std::string m_mailboxNameFieldPath;
		std::string m_networkId;
		std::string m_networkIdFieldPath;
		std::string m_targetFieldPath;
        std::string m_property;
		bool m_discoverByNetworkID;
		bool m_discoverByNetworkIDFieldPath;
		bool m_discoverByMailboxFieldPath;
		mailboxInterface::MailboxLocator m_mbLocator;
	};
}//namespace standardPlugins
