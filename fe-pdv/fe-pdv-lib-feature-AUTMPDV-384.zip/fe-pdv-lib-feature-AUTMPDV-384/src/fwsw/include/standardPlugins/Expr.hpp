/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "dataManip/WhenClause.hpp"
#include "expr/TestExpression.hpp"
#include "fieldSet/ConstFieldAccess.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createExpr( );
	class Expr : public dataManip::WhenClause
	{
	public:
		Expr( );
		Expr( const Expr& a_orig );
		virtual ~Expr( );
		bool init( );
		void finish( );
		bool goAhead( ) const;
		dataManip::WhenClause* clone( ) const;
		Expr& setExpr( const std::string& a_expr );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		expr::TestExpression* m_loadedExpr;
		std::string m_expr;
	};
}//namespace standardPlugins

