/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Gomes
/ Data de Cria��o: 2012, 13 de dezembro
/ Hist�rico Mudan�as: 2012, 13 de dezembro, t689064, Raphael Gomes, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <vector>
#include <string>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "dataManip/WhenClause.hpp"

namespace standardPlugins
{
  extern "C" base::Identificable* createCheckBits( );
  class CheckBits : public dataManip::WhenClause
  {
  public:
    CheckBits( );
    virtual ~CheckBits( );
    bool init( );
    void finish( );
    bool goAhead( ) const;
    dataManip::WhenClause* clone( ) const;
    CheckBits& setSourceFieldPath( const std::string& a_path );
    CheckBits& setDeniedFields( const std::string& a_deniedFields );
    CheckBits& setMandatoryFields( const std::string& a_mandatoryFields );
  private:
    bool startConfiguration( const configBase::Tag* a_tag );
    std::string m_sourceFieldPath;
    std::string m_mandatoryFields;
    std::string m_deniedFields;
    std::vector<fieldSet::ConstFieldAccess> m_mandFieldStack;
    std::vector<fieldSet::ConstFieldAccess> m_deniedFieldStack;
  
  };

}//namespace standardPlugins

