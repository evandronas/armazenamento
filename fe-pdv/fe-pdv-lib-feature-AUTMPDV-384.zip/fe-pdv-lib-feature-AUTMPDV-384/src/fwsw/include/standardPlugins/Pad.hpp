/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createPad( );
	class Pad : public dataManip::Command
	{
	public:
		Pad( );
		virtual ~Pad( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Pad& setSourceFieldPath( const std::string& a_path );
		Pad& setTargetFieldPath( const std::string& a_path );
		Pad& setPaddingChar( char a_paddingChar );
		Pad& setLength( unsigned int a_length );
		Pad& leftPaddingMode( bool a_leftPaddingMode );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		char m_paddingChar;
		unsigned int m_length;
		bool m_leftPaddingMode;
        // ID_231728 - Mascaramento do numero do cartao no cupom da PreAuth - INICIO
        fieldSet::ConstFieldAccess lengthVariable;
        std::string stringLength;
        unsigned int tempLength;
        bool lengthIsVar;
        // ID_231728 - Mascaramento do numero do cartao no cupom da PreAuth - FIM
	};
}//namespace standardPlugins

