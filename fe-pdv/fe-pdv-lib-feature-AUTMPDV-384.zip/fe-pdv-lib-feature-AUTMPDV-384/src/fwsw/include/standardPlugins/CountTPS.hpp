/*
/ -------------------------------------------------------------------------
/ Sigla: <standardPlugins::CountTPS>
/ Descri��o: <Arquivo de implementa��o da classe standardPlugins::CountTPS>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <694037, Fernando Amaral>
/ Data de Cria��o: <Tue Aug 14 18:57:32 2012>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once

#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"

namespace standardPlugins
{
    extern "C" base::Identificable* createCountTPS();
	
	struct TpsData
	{
		unsigned long frontEndCounter;
		unsigned long blockIncrement;
		unsigned long timeInterval;
		unsigned long currentTps;
	};

    class CountTPS : public dataManip::Command
    {
    public:
	
        CountTPS();
        virtual ~CountTPS();

        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;

		CountTPS& setTpsFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );
		
		TpsData* m_tpsData;
		
		std::string m_semaphore;
		int m_semid;
		int m_shmid;
		
		unsigned long m_individualCounter;
		unsigned long m_blockIncrement;
		
		std::string m_tpsFieldPath;
		fieldSet::FieldAccess m_tpsField[2];
    };
}
