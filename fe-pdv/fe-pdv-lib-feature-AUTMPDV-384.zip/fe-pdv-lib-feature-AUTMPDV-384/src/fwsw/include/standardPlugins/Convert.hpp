/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "msgConv/DataElementProperties.hpp"
#include "msgConv/DataCoding.hpp"
#include <map>

namespace standardPlugins
{
	extern "C" base::Identificable* createConvert( );
	class Convert : public dataManip::Command
	{
	public:
		Convert( );
		virtual ~Convert( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		Convert& setTargetFieldPath( const std::string& a_path );
		Convert& setSourceFieldPath( const std::string& a_path );
		Convert& setFrom( const std::string& a_from );
		Convert& setTo( const std::string& a_to );
		Convert& setStart( unsigned int a_start );
		Convert& setSize( unsigned int a_size );
		dataManip::Command* clone( ) const;
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void convertFromAscii( std::string& a_output, const std::string& a_input, msgConv::DataCoding a_dataCoding );
		void convertToAscii( std::string& a_ascii, const std::string& a_input, msgConv::DataCoding a_dataCoding );
		unsigned int convertToHEX( unsigned char* a_hex, unsigned int a_hexSize, const std::string& a_input, msgConv::DataCoding a_dataCoding );
		unsigned int ToBytes( std::string& a_output, const std::string& a_input, msgConv::DataCoding a_dataCoding );
		msgConv::DataCoding getDataType( const std::string& a_type );
		fieldSet::FieldAccess m_targetField;
		fieldSet::FieldAccess m_sourceField;
		std::string m_targetFieldPath;
		std::string m_sourceFieldPath;
		std::string m_from;
		std::string m_to;
		unsigned int m_auxBufferLength;
		unsigned char* m_auxBuffer;		
		unsigned int m_start;
		unsigned int m_size;
	};
}//namespace standardPlugins
