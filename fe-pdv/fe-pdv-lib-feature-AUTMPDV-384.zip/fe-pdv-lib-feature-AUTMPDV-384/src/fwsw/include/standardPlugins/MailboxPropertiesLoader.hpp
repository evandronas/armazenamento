/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "mailboxInterface/MailboxLocator.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createMailboxPropertiesLoader( );
	class MailboxPropertiesLoader : public dataManip::Command
	{
	public:
		MailboxPropertiesLoader( );
		virtual ~MailboxPropertiesLoader( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		
		MailboxPropertiesLoader& setMailboxAddressPath( const std::string& a_path );
		MailboxPropertiesLoader& setTargetFieldPath( const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_mailboxAddress;
		fieldSet::FieldAccess m_mailboxIsPort;
		fieldSet::FieldAccess m_mailboxName;
		std::string m_mailboxAddressPath;
		std::string m_targetFieldPath;
	};
}//namespace standardPlugins

