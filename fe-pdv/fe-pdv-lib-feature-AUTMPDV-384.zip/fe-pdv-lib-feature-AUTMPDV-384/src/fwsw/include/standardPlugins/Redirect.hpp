/*
Copyright 2019 Rede S.A.
*********************** MODIFICACOES ************************
/ -------------------------------------------------------------------------------------------------
Autor    : Renato de Camargo
Data     : 14/02/2019
Empresa  : Rede
Descricao: Vers�o Inicial
ID       : EAK 1420
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createRedirect( );
	class Redirect : public dataManip::Command
	{
	public:
		Redirect( );
		virtual ~Redirect( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
	private:
		bool startConfiguration( const configBase::Tag* tag );
		fieldSet::FieldAccess targetField;
		std::string mailBoxId;
		fieldSet::ConstFieldAccess mailBoxIdField;
	};
}//namespace standardPlugins

