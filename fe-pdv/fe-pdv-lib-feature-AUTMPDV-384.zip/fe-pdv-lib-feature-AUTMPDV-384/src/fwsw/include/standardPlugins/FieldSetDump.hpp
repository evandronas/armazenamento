/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "logger/Logger.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createFieldSetDump( );
	class FieldSetDump: public dataManip::Command
	{
	public:
		FieldSetDump( );
		virtual ~FieldSetDump( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		FieldSetDump& setSourceFieldPath( const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void logField( const fieldSet::Field& a_field, const std::string& a_path );
		fieldSet::ConstFieldAccess m_sourceField;
		std::string m_sourceFieldPath;
		logger::Logger* m_logger;
	};
}//namespace standardPlugins

