#pragma once
#include <sstream>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "logger/Logger.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createXDump( );
	class XDump: public dataManip::Command
	{
	public:
		XDump( );
		virtual ~XDump( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		XDump& setTagPattern( const std::string& a_value );
		XDump& setTagDbgLevel( const std::string& a_dbgLevel );
		XDump& setTagOptions( const std::string& a_options );        
        void logField( enum logger::Level l, const fieldSet::Field& a_field, const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void logField( const fieldSet::Field& a_field, const std::string& a_path );
        void logField( enum logger::Level l, const std::string pattern, const std::string options, const fieldSet::Field& a_field, const std::string& a_path );
		fieldSet::ConstFieldAccess m_sourceField;
		logger::Logger* m_logger;
		std::deque< fieldSet::ConstFieldAccess > m_sourceFields;
		std::deque< configBase::Tag > m_tags;
		//DEF_DEQUE_TAGS m_tags;
		//DEF_DEQUE_FIELDS m_sourceFields;
        std::string m_tag_pattern;
		std::string m_tag_dbglevel;        
        std::string m_tag_options;
        fieldSet::ConstFieldAccess m_pointDbgLevel;
        fieldSet::ConstFieldAccess m_pointPattern;
        fieldSet::ConstFieldAccess m_pointOptions;     
	};
}//namespace standardPlugins
