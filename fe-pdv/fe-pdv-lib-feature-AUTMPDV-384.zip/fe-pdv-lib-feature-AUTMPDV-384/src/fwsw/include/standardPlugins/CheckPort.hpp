/* Copyright 2014 Rede S.A.
Autor : Luiz Gustavo O Costa
Empresa : BSI Tecnologia
*/

#pragma once
#include <string>
#include "dataManip/Command.hpp"

namespace plugins_mqs
{
	extern "C" base::Identificable* createCheckPort( );
	
	// CheckPort
	// Classe auxiliar para checar status de portas com o MQ
	// EF/ET: 64145
	// Hist�rico: [24/06/2014] - 64145 - Release IV de 2014	
	class CheckPort : public dataManip::Command
	{
	public:
		CheckPort( );
		virtual ~CheckPort( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
    CheckPort& SetSourceFieldPath( const std::string& a_path );
    CheckPort& SetTargetFieldPath( const std::string& a_path );
			
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
    
    fieldSet::ConstFieldAccess m_sourceField;
    fieldSet::FieldAccess m_targetField;
    std::string m_sourceFieldPath;
    std::string m_targetFieldPath;

	};
}//namespace plugins_mqs

