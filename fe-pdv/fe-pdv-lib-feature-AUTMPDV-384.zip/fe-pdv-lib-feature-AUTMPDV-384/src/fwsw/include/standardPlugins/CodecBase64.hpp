/* Copyright 2018 REDE
Autor : Igor Oliveira
Empresa : Leega
*/

#ifndef _CODECBASE64_HPP_
#define _CODECBASE64_HPP_

//=========================================================================//
// Includes
//=========================================================================//
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"

#include "dbm.h"
#include "syslg.h"
#include "debug.h"
#include "ist_cfg.h"

#include <time.h>
#include <sstream>
#include <map>
#include <algorithm>
#include <string>


//=========================================================================//
// Defines
//=========================================================================//
#define BASE64_MAX_BUFFER_LEN 65536
#define BASE64_PADDING_CHAR '='

//=========================================================================//
// Namespace
//=========================================================================//
namespace standardPlugins
{
    // =========== Criacao da classe ==============
    extern "C" base::Identificable* CreateCodecBase64();

    /// CodecBase64
    /// Classe reponsavel pela conversao de dados em base64
    /// EF/ET : ET1
    /// Historico: [Data] – [Autor] - ET - Descricao
    /// 04/09/2018 - Igor Oliveira - ET1 - Criacao da versao inicial
    class CodecBase64 : public dataManip::Command
    {
        public:
            // ============== Basico =================
            CodecBase64( );
            virtual ~CodecBase64( );

            bool init( );
            void finish( );
            int execute( bool& stopRun );
            dataManip::Command* clone( ) const;

            // ========== Atribuicao dos paths ============
            CodecBase64& SetSourceFieldPath( const std::string& parameterPath );
            CodecBase64& SetTargetFieldPath( const std::string& parameterPath );

            CodecBase64& SetConvertOperation( const std::string& parameterPath );

        private:
            // ============== Basicos =================
            bool startConfiguration( const configBase::Tag* parameterTag );

            //=======================================//
            // Tratamento do Codec
            //=======================================//
            int encodeBase64(const char *buffer, char *base64, int bufferLength);
            int decodeBase64(const char *base64, char *buffer, int base64Length);

            // ========= Atributos de acesso dinamico ==========
            char workBuffer[BASE64_MAX_BUFFER_LEN];
            fieldSet::FieldAccess memberSourceFieldPath;
            fieldSet::FieldAccess memberTargetFieldPath;
            std::string targetFieldPath;
            std::string sourceFieldPath;
            std::string convertOperation;
    };
}

#endif //_CODECBASE64_HPP_

