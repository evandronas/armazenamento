/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descri��o:
/ Conte�do:
/ Autor: t694611, Carlos Cesar
/ Data de Cria��o: 2014, 06 de Maio
/ Hist�rico Mudan�as: 
/ -------------------------------------------------------------------------------------------------
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "logger/LoggerGen.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createFindTagDE55( );
	class FindTagDE55 : public dataManip::Command
	{
	public:
		FindTagDE55( );
		virtual ~FindTagDE55( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		FindTagDE55& setTargetFieldPath( const std::string& a_path );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );
        std::string findChipTag( std::string l_de55, int &l_pos );
        std::string findChipConteudo( std::string l_de55, int &l_pos, int l_len );
        int findChipLen( std::string l_de55, int &l_pos );
		fieldSet::FieldAccess m_conteudo;
		fieldSet::FieldAccess m_resultado;
		fieldSet::FieldAccess m_buffer;
		fieldSet::FieldAccess m_header;
		fieldSet::FieldAccess m_tag;
		
		std::string m_targetPath;
	};
}//namespace standardPlugins

