/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descrição: Copia mais de um valor ao mesmo tempo
/ Conteúdo:
/ Autor: t694446, Luiz Carlos do Lago
/ Data de Criação: 2013, 24 de Abril
/ Histórico Mudanças: 2013, 24 de Abril, t694446, Luiz Carlos do Lago, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

#pragma once
#include <deque>
#include <string>
#include <utility>  
#include "expr/Element.hpp"
#include "configBase/Tag.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createXCopy( );
	
	// Util
	// Classe auxiliar para copia de valores e manipulacao de dados
	// EF/ET: 44179
	// Histórico: [06/10/2014] - 44179 - Release I de 2014
	// Histórico: [08/11/2016] - 67959 - Release I de 2017
	class XCopy : public dataManip::Command
	{
	public:
		XCopy( );
		virtual ~XCopy( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
	private:
		bool createElement( const configBase::Tag & a_tag );
		bool startConfiguration( const configBase::Tag* a_tag );

		std::string GetMaskTypeFormat( const std::string & mask );
		
	private:
		typedef std::pair< expr::Element * , fieldSet::FieldAccess > DEF_PAIR_VALUES;
		typedef std::deque< configBase::Tag > DEF_DEQUE_TAGS;
		typedef std::deque< DEF_PAIR_VALUES > DEF_DEQUE_VALUES;
		DEF_DEQUE_TAGS tags;
		DEF_DEQUE_VALUES values;
	};
}//namespace standardPlugins
