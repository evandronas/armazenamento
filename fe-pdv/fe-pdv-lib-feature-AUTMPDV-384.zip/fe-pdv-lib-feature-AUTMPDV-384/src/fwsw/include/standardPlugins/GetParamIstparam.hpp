/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pos::TBSW0051Updater>
/ Descrição: <Arquivo de implementação da classe plugins_pos::TBSW0051Updater>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694449, Fernando Ramires>
/ Data de Criação: 
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ <Data, Módulo, Autor, Descrição da Mudança>
/ ---------------------------------------------------------------------------
*/

#pragma once

#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"

#include <algorithm>
#include "configBase/ConfigBase.hpp"
#include "configBase/Tag.hpp" 
#include "configBase/TagList.hpp" 
#include "configBase/DOMTreatment.hpp" 

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createGetParamIstparam( );

	class GetParamIstparam : public dataManip::Command
	{
		public:
	
			GetParamIstparam( );
			virtual ~GetParamIstparam( );
			
			bool init( );
			void finish( );
			int execute( bool& a_stop );
			dataManip::Command* clone( ) const;
    
			GetParamIstparam& setSourceFieldPath( const std::string& a_path );
			GetParamIstparam& setTargetFieldPath( const std::string& a_path );

		private:
			
			bool startConfiguration( const configBase::Tag* a_tag );
	
			std::string m_sourceFieldPath;
			std::string m_targetFieldPath;
			
			
			fieldSet::ConstFieldAccess m_param_name;
			fieldSet::FieldAccess m_param_value;
	};
} //namespace standardPlugins

