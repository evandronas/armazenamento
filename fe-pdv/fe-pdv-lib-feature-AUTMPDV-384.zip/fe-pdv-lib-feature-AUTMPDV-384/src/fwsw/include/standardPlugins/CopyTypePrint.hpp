/*
*******************************************************************
* REDECARD		                                                  *
*         		                                                  *
*******************************************************************
*/

#pragma once
#include <string>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"

namespace standardPlugins
{
  extern "C" base::Identificable* createCopyTypePrint( );
  class CopyTypePrint : public dataManip::Command
  {
  public:
    CopyTypePrint( );
    virtual ~CopyTypePrint( );
    bool init( );
    void finish( );
    int execute( bool& a_stop );
    dataManip::Command* clone( ) const;
    CopyTypePrint& setSourceFieldPath( const std::string& a_path );
    CopyTypePrint& setTargetFieldPath( const std::string& a_path );
    CopyTypePrint& setcharToPrint( const std::string& a_flag );
  private:
    bool startConfiguration( const configBase::Tag* a_tag );
    fieldSet::ConstFieldAccess m_sourceField;
    fieldSet::FieldAccess m_targetField;
    std::string m_sourceFieldPath;
    std::string m_targetFieldPath;
    std::string m_charToPrint;
  };

}//namespace standardPlugins
