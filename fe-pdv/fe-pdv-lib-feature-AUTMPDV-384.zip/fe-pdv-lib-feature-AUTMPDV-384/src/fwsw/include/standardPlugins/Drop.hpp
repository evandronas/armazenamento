/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: Inclusao de Opcao de DROP sem LOG
/ Autor: Gustavo Silva Franco
/ Data de Criacao: 29/11/2018
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createDrop( );
	class Drop : public dataManip::Command
	{
	public:
		Drop( );
		virtual ~Drop( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		std::string disableLog;
	};
}//namespace standardPlugins

