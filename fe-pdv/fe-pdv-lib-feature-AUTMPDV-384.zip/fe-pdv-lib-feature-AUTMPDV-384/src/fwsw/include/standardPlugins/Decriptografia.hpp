/*
Copyright 2019 REDE
*************************************************************
Autor    : Eduardo De Souza
Data     : 28/05/2019
Empresa  : Rede
Descricao: [POSIP] Erro decrypt de trilha 2 cart�o Amex Magn�tico
ID       : EAK-1516
*************************************************************
Autor    : Eduardo De Souza
Data     : 09/08/2019
Empresa  : Rede
Descricao: Transa��es Trilha 1 sendo negadas esporadicamente
ID       : EAK-1540
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 10/02/2021
Empresa  : Rede
Descricao: Sub-Adquirente
ID       : EAK-5604
*************************************************************
Autor    : Andre Morishita
Data     : 10/12/2021
Empresa  : Leega
Descri��o: AUT2-4397 - Tap On Phone
ID       : AUT2-4397
*************************************************************
*/

#pragma once
#include "cryptography/CryptoDUKPT.hpp"
#include "cryptography/CryptoDUKPTAES.hpp"
#include "cryptography/Crypto3DES.hpp"
#include "cryptography/CryptoDES.hpp"
#include "cryptography/Crypto.hpp"
#include "dataManip/Command.hpp"

#define DEFAULT_MSG_LENGTH  16
#define DEFAULT_MSG_FACTOR  8
#define DEFAULT_MSG_FACTOR_BCD  16

namespace standardPlugins
{
    extern "C" base::Identificable* createDecriptografia( );
    
    class Decriptografia : public dataManip::Command
    {
        public:
            
            Decriptografia( );
            virtual ~Decriptografia( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            Decriptografia& setSourceFieldPath( const std::string& a_path );
            Decriptografia& setTargetFieldPath( const std::string& a_path );
            Decriptografia& setResultFieldPath( const std::string& a_path );
            
        private:

            typedef enum decryptMode
            {
                DES,
                TRIPLEDES,
                DUPTK,
                DUKPTAES, // AUT2-4397 - Tap On Phone 
                NONE
            }
            DECR_MODE;

            fieldSet::ConstFieldAccess m_device_cap_orig;
            fieldSet::ConstFieldAccess m_track2_orig;
            fieldSet::ConstFieldAccess m_track3_orig;
            fieldSet::ConstFieldAccess m_indCripto;
            fieldSet::ConstFieldAccess m_cvc2_orig;
            fieldSet::ConstFieldAccess m_pan_orig;
            fieldSet::ConstFieldAccess m_mac_orig;
            fieldSet::ConstFieldAccess m_criptoQr_orig;
            fieldSet::ConstFieldAccess m_posip_ic;
            fieldSet::ConstFieldAccess m_DUKPTMAX;
            fieldSet::ConstFieldAccess m_KSN_PAN;
            fieldSet::ConstFieldAccess m_KSN_TR1;
            fieldSet::ConstFieldAccess m_KSN_TR2;
            fieldSet::ConstFieldAccess m_KSN_CVC;
            fieldSet::ConstFieldAccess m_KSN_MAC;
            fieldSet::ConstFieldAccess m_KSN_REF;
            /* JPFC - EAK-5604: Sub-Adquirente - Inicio */
            fieldSet::ConstFieldAccess m_KSN1; /* TAG016: Cripto PIN   (par com TAG058) */
            fieldSet::ConstFieldAccess m_KSN2; /* TAG017: Cripto CP    (par com TAG059) */
            fieldSet::ConstFieldAccess m_KSN3; /* TAG018: Cripto Dados (par com TAG054) */
            /* JPFC - EAK-5604: Sub-Adquirente - Fim */
            fieldSet::ConstFieldAccess m_track3Len;
            cryptography::CryptoDUKPT m_cryptoDUKPT;
            cryptography::Crypto3DES m_crypto3DES;
            cryptography::CryptoDES m_cryptoDES;
            cryptography::CryptoDUKPTAES cryptoDUKPTAES; // AUT2-4397 - Tap On Phone
            fieldSet::FieldAccess m_device_cap_dst;
            fieldSet::FieldAccess m_track2_decr;
            fieldSet::FieldAccess m_track3_decr;
            fieldSet::FieldAccess m_dukpt_orig;
            fieldSet::FieldAccess m_cvc2_decr; 
            fieldSet::FieldAccess m_pan_decr; 
            fieldSet::FieldAccess m_mac_decr;
            fieldSet::FieldAccess m_criptoQr_decr;
            fieldSet::FieldAccess m_termBDK;
            fieldSet::FieldAccess m_result;
            fieldSet::FieldAccess m_dukpt;
            fieldSet::FieldAccess m_msg_name;
            fieldSet::FieldAccess m_termTPK;
            DECR_MODE m_ReferralDecryptMode;
            DECR_MODE m_DataDecryptMode;
            std::string m_targetFieldPath;
            std::string m_sourceFieldPath;
            std::string m_resultFieldPath;
            std::string m_decryptDataMode;
            std::string m_maxDuktp;

            /* JPFC - EAK-5604: Sub-Adquirente - Inicio */
			/* TAG054: Cripto Dados (par com TAG018) */
			fieldSet::ConstFieldAccess m_tag054CriptoType;
			std::string s_tag054CriptoType;
			fieldSet::ConstFieldAccess m_tag054Index;
			std::string s_tag054Index;
			
			/* TAG058: Cripto PIN (par com TAG016) */
			fieldSet::ConstFieldAccess m_tag058CriptoType;
			std::string s_tag058CriptoType;
			fieldSet::ConstFieldAccess m_tag058Index; 
			std::string s_tag058Index;
			
			/* TAG059: Cripto CP (par com TAG017) */
			fieldSet::ConstFieldAccess m_tag059CriptoType;
			std::string s_tag059CriptoType;
			fieldSet::ConstFieldAccess m_tag059Index;
			std::string s_tag059Index;
		
			std::string l_ksn3;                  /* TAG018: Cripto Dados (par com TAG054) */

            std::string m_dataCriptoType;

            std::string m_termBDKSubAdq;
            /* JPFC - EAK-5604: Sub-Adquirente - Fim */

            bool startConfiguration( const configBase::Tag* a_tag );
            void DecryptyData( );
            void initFields( );
            void DecryptyPan( );
            void DecryptyTrilha1( );
            void DecryptyTrilha2( );
            void DecryptyCVC2( );
            void DecryptyMAC( );
            void DecryptyCriptoQr( );
            void DecryptyBdkFromKSN( );
            void SetDeviceCap();
            cryptography::Crypto *setDecryptDataMode( fieldSet::ConstFieldAccess &l_field );
            cryptography::Crypto *setDecryptMacMode( fieldSet::ConstFieldAccess &l_field );
            bool isDataDecryptModeDES( );
            bool isDataDecryptMode3DES( );
            bool isDataDecryptModeDukpt( );
            bool isDataDecryptModeNone( );
            bool isReferralDecryptModeDES( );
            bool isReferralDecryptMode3DES( );
            bool isReferralDecryptModeDukpt( );
            bool isReferralDecryptModeNone( );
            bool isCrypto_DUKPT( );
            bool isReferralDecryptModeDukpt( fieldSet::ConstFieldAccess &l_field );
            long getMsgLength( const std::string l_msg );
            long GetMsgLengthBCD( const std::string msg );
            void printInfoMsg( const std::string &l_msg );
            void TRIPLEDES_to_DUKPT( cryptography::Crypto *l_crypto, std::string &l_aux, fieldSet::FieldAccess &l_field, fieldSet::ConstFieldAccess l_key );
            std::string RemoveZeroFiller( const std::string &track3 );

            /* JPFC - EAK-5604: Sub-Adquirente - Inicio */
            void DecryptyBdkFromKSNSubAdq( );
            bool isCrypto_DUKPT_Subadq( );
            /* JPFC - EAK-5604: Sub-Adquirente - Fim */
    };
}


