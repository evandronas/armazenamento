/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createEventManager( );
	class EventManager : public dataManip::Command
	{
		enum operations
		{
			Unknown, 
			Create, 
			Recover, 
			Expired
		};
	public:
		EventManager( );
		virtual ~EventManager( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		std::string fieldsetToString( const fieldSet::Field& a_field, size_t a_deep = 0 );
		size_t stringToFieldset( fieldSet::Field& a_field, const std::string& a_str, size_t a_deep = 0 );
		EventManager& setOperation( const std::string& a_operation );
		EventManager& setMailBoxIdFieldPath( const std::string& a_path );
		EventManager& setTimeoutFieldPath( const std::string& a_path );
		EventManager& setActionFieldPath( const std::string& a_path );
		EventManager& setKeyFieldPath( const std::string& a_path );
		EventManager& setSourceFieldPath( const std::string& a_path );
		EventManager& setTargetFieldPath( const std::string& a_path );
		unsigned int operation( );
		const std::string& mailBoxIdFieldPath( );
		const std::string& timeoutFieldPath( );
		const std::string& actionFieldPath( );
		const std::string& keyFieldPath( );
		const std::string& sourceFieldPath( );
		const std::string& targetFieldPath( );
		dataManip::Command* clone( ) const;
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_mailBoxIdField;
		fieldSet::ConstFieldAccess m_timeoutField;
		fieldSet::ConstFieldAccess m_actionField;
		fieldSet::ConstFieldAccess m_keyField;
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		std::string m_mailBoxIdFieldPath;
		std::string m_timeoutFieldPath;
		std::string m_actionFieldPath;
		std::string m_keyFieldPath;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		unsigned int m_operation;
		int m_mailBoxId;
		long m_timeout;
		int m_action;
		int m_key;
		std::string m_source;
		char m_buffer[16384];
	};
}//namespace standardPlugins

