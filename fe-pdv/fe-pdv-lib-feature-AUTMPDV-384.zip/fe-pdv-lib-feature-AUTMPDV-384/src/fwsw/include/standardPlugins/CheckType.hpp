/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -----------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2012, 27 de dezembro
/ Hist�rico Mudan�as: 2012, 27 de dezembro, t689066 Alexandre Teodoro Guimaraes
                                                               , Versao Inicial
/                     2016, 02 de junho, t696193 Andre Morishita,
/                     Projeto CF160391 Correcao dos BTs de Inspecao de Codigo
/ -----------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "dataManip/WhenClause.hpp"

namespace standardPlugins
{
  extern "C" base::Identificable* createCheckType( );
  class CheckType : public dataManip::WhenClause
  {
  public:
    CheckType( );
    virtual ~CheckType( );
    bool init( );
    void finish( );
    bool goAhead( ) const;
    dataManip::WhenClause* clone( ) const;
    CheckType& setSourceFieldPath( const std::string& a_path );
    CheckType& SetResult( const bool a_flag );
    CheckType& setIsDigit( const bool a_flag );
    CheckType& setIsAlnum( const bool a_flag );
    CheckType& setIsAlpha( const bool a_flag );
    CheckType& setIsChars( const std::string& a_chars );
  private:
    bool startConfiguration( const configBase::Tag* a_tag );
    fieldSet::ConstFieldAccess m_sourceField;
    std::string m_sourceFieldPath;
    bool result;
    bool m_isDigit;
    bool m_isAlnum;
    bool m_isAlpha;
    std::string m_isChars;
  };

}//namespace standardPlugins
