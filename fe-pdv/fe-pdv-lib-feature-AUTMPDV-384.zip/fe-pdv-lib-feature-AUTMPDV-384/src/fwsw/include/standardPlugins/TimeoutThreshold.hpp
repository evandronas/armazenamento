/* 
Copyright 2019 REDE 


*********************** MODIFICACOES ************************ 
Autor    : Gustavo Silva Franco 
Data     : 22/05/2019
Empresa  : Rede 
Descricao: Vers�o inicial - Criando controle para limite de timeouts no dual_sync
ID       : AM 249.438 
************************************************************* 
*/

#pragma once
#include "dataManip/Command.hpp"
#include "configBase/TagList.hpp"
#include "logger/DebugWriter.hpp"
#include <fstream>

namespace standardPlugins
{
	#define DUALSYNC_DESF_FLAG "DUALSYNC_DESF"
	#define DUALSYNC_EST_FLAG "DUALSYNC_EST"
	#define DUALSYNC_CONF_FLAG "DUALSYNC_CONF"
	
	extern "C" base::Identificable* createTimeoutThreshold( );
	class TimeoutThreshold : public dataManip::Command
	{
	public:
		TimeoutThreshold( );
		virtual ~TimeoutThreshold( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		static int timeoutsCounter;
		static int respondedTrxCounter;
		int threshold;
		float timeInterval;
		float percentageThreshold;
		int minimalSampleSize;
		std::string timeoutOccurred;		
		std::string dualActiveFile;		
		logger::DebugWriter* debugWriter;
		static bool firstTime;
		static time_t startClock;
		static time_t endClock;
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		int RemoveFlagsFromFile( const char* filePath, char **flagsToFind, int numFlags );
	};
}//namespace standardPlugins

