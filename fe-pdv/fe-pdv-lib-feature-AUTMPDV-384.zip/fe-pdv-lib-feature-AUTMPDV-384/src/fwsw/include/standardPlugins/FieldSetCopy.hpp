/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createFieldSetCopy( );
	class FieldSetCopy: public dataManip::Command
	{
	public:
		FieldSetCopy( );
		virtual ~FieldSetCopy( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		FieldSetCopy& setSourceFieldPath( const std::string& a_path );
		FieldSetCopy& setTargetFieldPath( const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void logField( const fieldSet::Field& a_field, const std::string& a_path );
		void initLink( fieldSet::Field& a_target, const fieldSet::Field& a_source );
		typedef std::pair<fieldSet::FieldAccess, fieldSet::ConstFieldAccess> PAIR;
		typedef std::deque<PAIR> DEQUE_PAIRS;
		DEQUE_PAIRS m_pairs;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
	};
}//namespace standardPlugins

