/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o: Plugin para gerar chaves para eventos
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2012, 18 de outubro
/ Hist�rico Mudan�as: 2012, 18 de outubro, t689066, Alexandre Teodoro Guimaraes, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createKeyGen( );
	class KeyGen : public dataManip::Command
	{
	public:
		KeyGen( );
		virtual ~KeyGen( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		KeyGen& setSourceFieldPath( const std::string& a_path );
		KeyGen& setTargetFieldPath( const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		bool m_sourceIsDigit;
		long m_keyPfx;
	};
}//namespace standardPlugins

