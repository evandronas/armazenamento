/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Amaral
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Amaral, Versao que corrige o + como OR
/ -------------------------------------------------------------------------------------------------
*/


#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"

namespace standardPlugins
{
	extern "C" base::Identificable* createISTFlags( );
	class ISTFlags : public dataManip::Command
	{
	public:
		ISTFlags( );
		virtual ~ISTFlags( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		ISTFlags& setTargetFieldPath( const std::string& a_path );
		ISTFlags& setFlagName( const std::string& a_path );
		ISTFlags& setEnable( const bool a_value );
	
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		std::map<std::string, unsigned long> m_map_flags;
		fieldSet::FieldAccess m_targetField;
		std::string m_targetFieldPath;
		std::string m_flagName;
		bool m_enable;
	};
}//namespace standardPlugins

