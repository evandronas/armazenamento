/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o: Plugin para equacoes matematicas basicas
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t689066, Alexandre Teodoro Guimaraes, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace standardPlugins
{
	extern "C" base::Identificable* createMath( );
	class Math : public dataManip::Command
	{
	public:
		Math( );
		virtual ~Math( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		Math& setValue1( const std::string& a_value );
		Math& setValue2( const std::string& a_value );
		Math& setOperator( const char a_operator );
		Math& setTargetFieldPath( const std::string& a_path );
		Math& setRemoveDecimalPoint( const bool a_value );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		char m_operator;
		std::string m_strValue1;
		std::string m_strValue2;
		fieldSet::FieldAccess m_targetField;
		fieldSet::ConstFieldAccess m_value1Field;
		fieldSet::ConstFieldAccess m_value2Field;
		std::string m_targetFieldPath;
		bool m_removeDecimalPoint;
	};
}//namespace standardPlugins

