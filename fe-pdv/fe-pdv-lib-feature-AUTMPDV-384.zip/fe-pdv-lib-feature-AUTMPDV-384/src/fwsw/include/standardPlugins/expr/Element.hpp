/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>


namespace expr
{
	class Element
	{
	public:
		Element( );
		virtual ~Element( );
		virtual Element* clone( ) const = 0;
		virtual const std::string& value( ) const = 0;
		virtual const std::string& Mask( ) const;
	private:
		std::string mask;
	};
}//namespace expr

