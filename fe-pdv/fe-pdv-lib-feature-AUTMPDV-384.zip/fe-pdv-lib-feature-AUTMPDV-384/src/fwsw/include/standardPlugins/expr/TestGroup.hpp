/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include "expr/LogicOperator.hpp"
#include "expr/TestExpression.hpp"


namespace expr
{
	class TestGroup : public TestExpression
	{
	public:
		TestGroup( );
		virtual ~TestGroup( );
		void addExpression( TestExpression* a_expr );
		void setLogicOperator( LogicOperator a_logicOperator );
		LogicOperator logicOperator( ) const;
		unsigned int size( ) const;
	private:
		std::deque<TestExpression*> m_expressions;
		bool m_isSorted;
		LogicOperator m_logicOperator;
		bool specificTest( ) const;
	};
}//namespace expr

