/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "expr/Element.hpp"


namespace expr
{
	class TestExpression
	{
	public:
		TestExpression( );
		virtual ~TestExpression( );
		bool test( ) const;
		void setLeft( const Element& a_left );
		void setRight( const Element& a_right );
		const Element& left( ) const;
		const Element& right( ) const;
		bool invert( ) const;
		void enableInvert( bool a_enable );
	private:
		virtual bool specificTest( ) const = 0;
		Element* m_left;
		Element* m_right;
		bool m_invert;
	};
}//namespace expr

