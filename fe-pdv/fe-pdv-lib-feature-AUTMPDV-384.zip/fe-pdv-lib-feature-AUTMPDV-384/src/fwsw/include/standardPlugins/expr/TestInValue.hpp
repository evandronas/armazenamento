/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descrição:
/ Conteúdo:
/ Autor: t694446, Luiz Carlos do Lago
/ Data de Criação: 2013, 08 de abril
/ Histórico Mudanças: 2013, 08 de abril, t682566, Luiz Carlos do Lago, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "expr/TestExpression.hpp"


namespace expr
{
	class TestInValue : public TestExpression
	{
	public:
		TestInValue( );
		virtual ~TestInValue( );
		
	public:
		bool compare( const std::string & valueIn, const std::string & values, const char delimiter ) const;
		
	private:
		bool specificTest( ) const;
		std::string Trim( const std::string & a_value ) const;
		std::string LeftTrim( const std::string & a_value ) const;
		std::string RightTrim( const std::string & a_value ) const;
	};
}//namespace expr

