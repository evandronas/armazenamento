/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <string>
#include "expr/TestExpression.hpp"
#include "fieldSet/FieldNavigator.hpp"


namespace expr
{
	class Parser
	{
	public:
		typedef std::deque<std::string> ERR_VECTOR;
		Parser( );
		virtual ~Parser( );
		TestExpression* loadExpression( const std::string& a_expr );
		void setNavigator( const fieldSet::FieldNavigator& a_navigator );
		const ERR_VECTOR& getErrors( ) const;
	private:
		enum ExprState
		{
			BEGIN, START_LEFT, START_RIGHT, START_COMPARATOR, LEFT_IDENTIFICATOR, RIGHT_IDENTIFICATOR, EQUAL, NOT, GREATER, LESSER, NOT_EQUAL, START_AND, START_OR, AND, OR, LEFT_VALUE, RIGHT_VALUE, IN_EQUAL, COMPARATOR
		};
		TestExpression* loadExpression( const std::string& a_expr, unsigned int a_lineRef, unsigned int a_level );
		void changeState( ExprState& a_state, ExprState a_newState ) const;
		TestExpression* createExpression( const std::string& a_strLeftElement, const std::string& a_strRightElement, const std::string& a_comparator, bool a_leftIsVariable, bool a_rightIsVariable );
		fieldSet::FieldNavigator m_navigator;
		ERR_VECTOR m_errors;
		std::string m_fullExpr;
	};
}//namespace expr

