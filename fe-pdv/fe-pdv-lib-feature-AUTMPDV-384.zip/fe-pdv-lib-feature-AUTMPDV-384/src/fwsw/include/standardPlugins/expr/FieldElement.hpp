/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "expr/Element.hpp"
#include "fieldSet/ConstFieldAccess.hpp"


namespace expr
{
	class FieldElement : public Element
	{
	public:
		enum FIELD_FUNCTION
		{
			VALUE, LENGTH, IS_ON
		};
		FieldElement( );
		virtual ~FieldElement( );
		void setFunction( enum FIELD_FUNCTION a_fieldFunction );
		const std::string& value( ) const;
		void setAccess( const fieldSet::ConstFieldAccess& a_access );
		Element* clone( ) const;
		
		const std::string& Mask( ) const;
	private:
		fieldSet::ConstFieldAccess m_access;
		enum FIELD_FUNCTION m_function;
		mutable std::string m_functionValue;
	};
}//namespace expr

