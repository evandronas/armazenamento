/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "expr/Element.hpp"


namespace expr
{
	class ValueElement : public Element
	{
	public:
		ValueElement( );
		virtual ~ValueElement( );
		const std::string& value( ) const;
		void setValue( const std::string& a_value );
		Element* clone( ) const;
	private:
		std::string m_value;
	};
}//namespace expr

