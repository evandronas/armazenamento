/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689049, Celso Sato
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t689049, Celso Sato, Versao Inicial
/                     2013, 10 de julho, t689049, Jairo Borba, Inser��o de tipo ll/lll var dinamico vari�vel por tag
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "msgConv/DataElementProperties.hpp"
#include "msgConv/DataCoding.hpp"
#include <map>

namespace standardPlugins
{
	extern "C" base::Identificable* createTagParser( );
	class TagParser : public dataManip::Command
	{
	public:
		TagParser( );
		virtual ~TagParser( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		TagParser& setTargetFieldPath( const std::string& a_path );
		TagParser& setSourceFieldPath( const std::string& a_path );
		TagParser& setTagNameSize( unsigned int a_tagNameSize );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void PrintHex( std::string a_varname, const char* a_buf, unsigned int size ); // renamed from printHEX to PrintHex - esert - 20160715 - BT#67741
		msgConv::DataCoding getDataType( const std::string& a_type );
		void convertToAscii( std::string& a_ascii, const std::string& a_input, msgConv::DataCoding a_dataCoding );
		unsigned int calculateSize( unsigned int a_numDigits, msgConv::DataCoding a_dataCoding );
		fieldSet::FieldAccess m_targetField;
		std::string m_targetFieldPath;
		fieldSet::FieldAccess m_sourceField;
		std::string m_sourceFieldPath;
		unsigned int m_tagNameSize;
		unsigned int m_defaultTagLengthSize;
		typedef std::map<std::string,msgConv::DataElementProperties> TP_MAP;
		typedef std::pair<std::string,msgConv::DataElementProperties> TP_PAIR;
		TP_MAP m_descTags;
		unsigned char* m_auxBuffer;
		unsigned int m_auxBufferLength;
		unsigned int m_headerSize;
		msgConv::DataCoding m_tagNameDataType;
	};
}//namespace standardPlugins
