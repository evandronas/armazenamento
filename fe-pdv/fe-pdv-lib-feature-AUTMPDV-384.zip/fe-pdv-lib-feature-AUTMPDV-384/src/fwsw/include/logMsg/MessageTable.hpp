/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: 689068, Jose Gavazza
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, 689068, Jose Gavazza, Versao Inicial
/ Historico Mudancas: 2019, 12 de marco, Renato de Camargo, EAK-1420 (AM 243.932)
/ -------------------------------------------------------------------------------------------------
*/
#pragma once

#ifndef FWSW_LOGMSG_MESSAGETABLE_H
#define FWSW_LOGMSG_MESSAGETABLE_H

//ConfigBase
#define MSG_CONFIGBASE_0001  "-00-0001:Retrieving Tag at sequence"
#define MSG_CONFIGBASE_0002  "-00-0002:Retrieving property at sequence"
#define MSG_CONFIGBASE_0003  "-00-0003:Searching Tag"
#define MSG_CONFIGBASE_0004  "-00-0004:Searching property"
#define MSG_CONFIGBASE_0005  "-00-0005:Property value"
#define MSG_CONFIGBASE_0006  "-00-0005:Property not found"

//DataManip
#define MSG_DATAMANIP_0001  "-01-0001:Error loading xml:"
#define MSG_DATAMANIP_0002  "-01-0002:Error in dataManip:"
#define MSG_DATAMANIP_0003  "-01-0003:Error in ConditionalBlock "
#define MSG_DATAMANIP_0004  "-01-0004: Command excution WARNING: "
#define MSG_DATAMANIP_0005  "-01-0005: Command excution ERROR: "
#define MSG_DATAMANIP_0006  "-01-0006: Processing interrupted by the command: "
#define MSG_DATAMANIP_0007  "-01-0007: Start processing DATAMANIP: "
#define MSG_DATAMANIP_0008  "-01-0008: Processing command: "
#define MSG_DATAMANIP_0009  "-01-0009: Finish processing DATAMANIP: "
#define MSG_DATAMANIP_0010  "-01-0010: WhC initd : "
#define MSG_DATAMANIP_0011  "-01-0011: WhC procd : "
#define MSG_DATAMANIP_0012  "-01-0012: Cmd initd : "
#define MSG_DATAMANIP_0013  "-01-0013: Cmd procd : "

//MainEngine( -0002-XXXX )messages
#define MSG_MAINENGINE_0001  "-02-0001:Initializing Environment"
#define MSG_MAINENGINE_0002  "-02-0002:Initializing TrxEngine"
#define MSG_MAINENGINE_0003  "-02-0003:Initializing EventHandler"
#define MSG_MAINENGINE_0004  "-02-0004:Initializing OutboundConverter"
#define MSG_MAINENGINE_0005  "-02-0005:Initializing InboundConverter"
#define MSG_MAINENGINE_0006  "-02-0006:Initializing DataManipRequest"
#define MSG_MAINENGINE_0007  "-02-0007:Error:"
#define MSG_MAINENGINE_0008  "-02-0008:Initializing DataManipNegative"
#define MSG_MAINENGINE_0009  "-02-0009:Initializing DataManipResponse"
#define MSG_MAINENGINE_0010  "-02-0010:Initializing Input Mailbox"
#define MSG_MAINENGINE_0011  "-02-0011:Initializing Output Mailbox"
#define MSG_MAINENGINE_0012  "-02-0012:Success on MainEngine initialization"
#define MSG_MAINENGINE_0013  "-02-0013:System Up !"
#define MSG_MAINENGINE_0014  "-02-0014:Invalid parameters !"
#define MSG_MAINENGINE_0015  "-02-0015:Catch Signal "
#define MSG_MAINENGINE_0016  "-02-0016:Forwarding Message FROM NET"
#define MSG_MAINENGINE_0017  "-02-0017:Returning Message TO NET"
#define MSG_MAINENGINE_0018  "-02-0018:Receiving Message FROM NET"
#define MSG_MAINENGINE_0019  "-02-0019: Receiving Message TO NET"
#define MSG_MAINENGINE_0020  "-02-0020:Initializing DataManipCommand"
#define MSG_MAINENGINE_0021  "-02-0021:Initializing DataManipEvent"
#define MSG_MAINENGINE_0022  "-02-0022:Elapsed time for starting DataManip: "
#define MSG_MAINENGINE_0023  "-02-0022:Elapsed time for starting WhenClause/Command: "
#define MSG_MAINENGINE_0024  "-02-0024:Command received"
#define MSG_MAINENGINE_0025  "-02-0025:Expired event received"
#define MSG_MAINENGINE_0026  "-02-0026:Shutdown command received"
#define MSG_MAINENGINE_0027  "-02-0027:Stopping engine"
#define MSG_MAINENGINE_0028  "-02-0028:Stopping orfan engine"
#define MSG_MAINENGINE_0029  "-02-0029:Waiting message from "
#define MSG_MAINENGINE_0030  "-02-0030:Initializing OutboundPassthroughConverter"

//EngineLoader( -0003-XXXX ) messages
#define MSG_ENGINELOADER_0001  "-03-0001:Loading MainEngineXml"
#define MSG_ENGINELOADER_0002  "-03-0002:Loading XmlFilesSection"
#define MSG_ENGINELOADER_0003  "-03-0003:Loading XmlFilesProperties"
#define MSG_ENGINELOADER_0004  "-03-0004:Loading ObjectsReferencesTag"
#define MSG_ENGINELOADER_0005  "-03-0005:Loading ObjectsReferencesProperties"
#define MSG_ENGINELOADER_0006  "-03-0006:Searching Librarian"
#define MSG_ENGINELOADER_0007  "-03-0007:Searching PluginManager"
#define MSG_ENGINELOADER_0008  "-03-0008:Searching FieldSets"
#define MSG_ENGINELOADER_0009  "-03-0009:Searching DataManips"
#define MSG_ENGINELOADER_0010  "-03-0010:Searching Iso8583Properties"
#define MSG_ENGINELOADER_0011  "-03-0011:Loading Bibliotecas"
#define MSG_ENGINELOADER_0012  "-03-0012:Loading PluginManager"
#define MSG_ENGINELOADER_0013  "-03-0013:Loading FieldSets"
#define MSG_ENGINELOADER_0014  "-03-0014:Loading FieldNavigator"
#define MSG_ENGINELOADER_0015  "-03-0015:Loading DataManips"
#define MSG_ENGINELOADER_0016  "-03-0016:Loading Converters"
#define MSG_ENGINELOADER_0017  "-03-0017:Loading Mailboxes"
#define MSG_ENGINELOADER_0018  "-03-0018:Loading TrxEngine"
#define MSG_ENGINELOADER_0019  "-03-0019:Success loading EngineLoader"
#define MSG_ENGINELOADER_0020  "-03-0020:"
#define MSG_ENGINELOADER_0021  "-03-0021:Error loading xml:"
#define MSG_ENGINELOADER_0022  "-03-0022:Configuration error on PluginManager:"
#define MSG_ENGINELOADER_0023  "-03-0022:Configuration error on Librarian:"
#define MSG_ENGINELOADER_0024  "-03-0024:Loading DataManipTimeLogFlag"

//EventHandler
#define MSG_EVENTHANDLER_0001  "-04-0001: Message FROM NET"
#define MSG_EVENTHANDLER_0002  "-04-0002: Message TO NET"
#define MSG_EVENTHANDLER_0003  "-04-0003: Dropping message"
#define MSG_EVENTHANDLER_0004  "-04-0004: Invalid message processing"

//StandardTrxEngine
#define MSG_STDTRXENGINE_0001  "-05-0001: Command excution WARNING on request: "
#define MSG_STDTRXENGINE_0002  "-05-0002: Command excution ERROR on request: "
#define MSG_STDTRXENGINE_0003  "-05-0003: Processing interrupted by the command on request: "
#define MSG_STDTRXENGINE_0004  "-05-0004: Command excution WARNING on response: "
#define MSG_STDTRXENGINE_0005  "-05-0005: Command excution ERROR on response: "
#define MSG_STDTRXENGINE_0006  "-05-0006: Processing interrupted by the command on response: "
#define MSG_STDTRXENGINE_0007  "-05-0007: Command excution WARNING on denial: "
#define MSG_STDTRXENGINE_0008  "-05-0008: Command excution ERROR on denial: "
#define MSG_STDTRXENGINE_0009  "-05-0009: Processing interrupted by the command on denial: "
#define MSG_STDTRXENGINE_0010  "-05-0010: Elapsed time: "
#define MSG_STDTRXENGINE_0011  "-05-0011: Command excution WARNING on mailbox command: "
#define MSG_STDTRXENGINE_0012  "-05-0012: Command excution ERROR on mailbox command: "
#define MSG_STDTRXENGINE_0013  "-05-0013: Processing interrupted by the command on mailbox command: "
#define MSG_STDTRXENGINE_0014  "-05-0014: Command excution WARNING on mailbox event: "
#define MSG_STDTRXENGINE_0015  "-05-0015: Command excution ERROR on mailbox event: "
#define MSG_STDTRXENGINE_0016  "-05-0016: Processing interrupted by the command on mailbox event: "

//StartEngine
#define MSG_STARTENGINE_0001  "-06-0001:Error: Enter xml path, main xml filename, label and log acronym"
#define MSG_STARTENGINE_0002  "-06-0002:Loading xml file:"
#define MSG_STARTENGINE_0003  "-06-0003:Fatal error loading xml file"
#define MSG_STARTENGINE_0004  "-06-0004:Initializing module"
#define MSG_STARTENGINE_0005  "-06-0005:Fatal error initializing module"
#define MSG_STARTENGINE_0006  "-06-0006:Executing mainLoop( )"
#define MSG_STARTENGINE_0007  "-06-0007:Exception:"
#define MSG_STARTENGINE_0008  "-06-0008:Waiting reload or restart"

//Mapping
#define MSG_MAPPING_0001  "-07-0001:Error loading xml:"

//DataManipConfig
#define MSG_DATAMANIPCONFIG_0001  "-08-0001:Loading "

//Dispatcher( -0009-XXXX )messages
#define MSG_DISPATCHER_0001  "-09-0001:Initializing Environment"
#define MSG_DISPATCHER_0002  "-09-0002:Initializing TrxEngine"
#define MSG_DISPATCHER_0003  "-09-0003:Initializing EventHandler"
#define MSG_DISPATCHER_0004  "-09-0004:Initializing OutboundConverter"
#define MSG_DISPATCHER_0005  "-09-0005:Initializing InboundConverter"
#define MSG_DISPATCHER_0006  "-09-0006:Initializing DataManipRequest"
#define MSG_DISPATCHER_0007  "-09-0007:Error:"
#define MSG_DISPATCHER_0008  "-09-0008:Initializing DataManipNegative"
#define MSG_DISPATCHER_0009  "-09-0009:Initializing DataManipResponse"
#define MSG_DISPATCHER_0010  "-09-0010:Initializing Input Mailbox"
#define MSG_DISPATCHER_0011  "-09-0011:Initializing Output Mailbox"
#define MSG_DISPATCHER_0012  "-09-0012:Success on MainEngine initialization"
#define MSG_DISPATCHER_0013  "-09-0013:System Up !"
#define MSG_DISPATCHER_0014  "-09-0014:Invalid parameters !"
#define MSG_DISPATCHER_0015  "-09-0015:Catch Signal "
#define MSG_DISPATCHER_0016  "-09-0016: Forwarding Message FROM NET"
#define MSG_DISPATCHER_0017  "-09-0017: Returning Message TO NET"
#define MSG_DISPATCHER_0018  "-09-0018: Receiving Message FROM NET"
#define MSG_DISPATCHER_0019  "-09-0019: Receiving Message TO NET"

//DispatcherLoader( -0010-XXXX ) messages
#define MSG_DISPATCHERLOADER_0001  "-10-0001:Loading MainDispatcherXml"
#define MSG_DISPATCHERLOADER_0002  "-10-0002:Loading XmlFilesSection"
#define MSG_DISPATCHERLOADER_0003  "-10-0003:Loading XmlFilesProperties"
#define MSG_DISPATCHERLOADER_0004  "-10-0004:Loading ObjectsReferencesTag"
#define MSG_DISPATCHERLOADER_0005  "-10-0005:Loading ObjectsReferencesProperties"
#define MSG_DISPATCHERLOADER_0006  "-10-0006:Searching Librarian"
#define MSG_DISPATCHERLOADER_0007  "-10-0007:Searching PluginManager"
#define MSG_DISPATCHERLOADER_0008  "-10-0008:Searching FieldSets"
#define MSG_DISPATCHERLOADER_0009  "-10-0009:Searching DataManips"
#define MSG_DISPATCHERLOADER_0010  "-10-0010:Searching Iso8583Properties"
#define MSG_DISPATCHERLOADER_0011  "-10-0011:Loading Bibliotecas"
#define MSG_DISPATCHERLOADER_0012  "-10-0012:Loading PluginManager"
#define MSG_DISPATCHERLOADER_0013  "-10-0013:Loading FieldSets"
#define MSG_DISPATCHERLOADER_0014  "-10-0014:Loading FieldNavigator"
#define MSG_DISPATCHERLOADER_0015  "-10-0015:Loading DataManips"
#define MSG_DISPATCHERLOADER_0016  "-10-0016:Loading Converters"
#define MSG_DISPATCHERLOADER_0017  "-10-0017:Loading Mailboxes"
#define MSG_DISPATCHERLOADER_0018  "-10-0018:Loading TrxEngine"
#define MSG_DISPATCHERLOADER_0019  "-10-0019:Success loading EngineLoader"
#define MSG_DISPATCHERLOADER_0020  "-10-0020:"
#define MSG_DISPATCHERLOADER_0021  "-10-0021:Error loading xml:"
#define MSG_DISPATCHERLOADER_0022  "-10-0022:Configuration error on PluginManager:"
#define MSG_DISPATCHERLOADER_0023  "-10-0022:Configuration error on Librarian:"

//MainDispatcher( -0011-XXXX )messages
#define MSG_MAINDISPATCHER_0001  "-11-0001:Initializing Environment"
#define MSG_MAINDISPATCHER_0002  "-11-0002:Initializing TrxEngine"
#define MSG_MAINDISPATCHER_0003  "-11-0003:Initializing EventHandler"
#define MSG_MAINDISPATCHER_0004  "-11-0004:Initializing OutboundConverter"
#define MSG_MAINDISPATCHER_0005  "-11-0005:Initializing InboundConverter"
#define MSG_MAINDISPATCHER_0006  "-11-0006:Initializing DataManipRequest"
#define MSG_MAINDISPATCHER_0007  "-11-0007:Error:"
#define MSG_MAINDISPATCHER_0008  "-11-0008:Initializing DataManipNegative"
#define MSG_MAINDISPATCHER_0009  "-11-0009:Initializing DataManipResponse"
#define MSG_MAINDISPATCHER_0010  "-11-0010:Initializing Input Mailbox"
#define MSG_MAINDISPATCHER_0011  "-11-0011:Initializing Output Mailbox"
#define MSG_MAINDISPATCHER_0012  "-11-0012:Success on MainEngine initialization"
#define MSG_MAINDISPATCHER_0013  "-11-0013:System Up !"
#define MSG_MAINDISPATCHER_0014  "-11-0014:Invalid parameters !"
#define MSG_MAINDISPATCHER_0015  "-11-0015:Catch Signal "
#define MSG_MAINDISPATCHER_0016  "-11-0016: Forwarding Message FROM NET"
#define MSG_MAINDISPATCHER_0017  "-11-0017: Returning Message TO NET"
#define MSG_MAINDISPATCHER_0018  "-11-0018: Receiving Message FROM NET"
#define MSG_MAINDISPATCHER_0019  "-11-0019: Receiving Message TO NET"

//StartDispatcher
#define MSG_STARTDISPATCHER_0001  "-12-0001:Error: Enter xml path, main xml filename, label and log acronym"
#define MSG_STARTDISPATCHER_0002  "-12-0002:Loading xml file:"
#define MSG_STARTDISPATCHER_0003  "-12-0003:Fatal error loading xml file"
#define MSG_STARTDISPATCHER_0004  "-12-0004:Initializing module"
#define MSG_STARTDISPATCHER_0005  "-12-0005:Fatal error initializing module"
#define MSG_STARTDISPATCHER_0006  "-12-0006:Executing mainLoop( )"
#define MSG_STARTDISPATCHER_0007  "-12-0007:Exception:"
#define MSG_STARTDISPATCHER_0008  "-12-0008:Waiting reload or restart"

#endif
