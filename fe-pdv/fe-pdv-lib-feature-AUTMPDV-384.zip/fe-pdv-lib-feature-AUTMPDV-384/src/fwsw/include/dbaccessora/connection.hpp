/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 29/05/2019
Empresa  : Rede
Descricao: Adicionando Tratamento de timeout no BD no handleError (igual ao do statement.cpp)
ID       : AM 249438
*************************************************************
/ Sigla: SW - FE-POS
/ Descricao: EAK-1638 - Adicionando controle de Timeout no Execute
/ Autor: Renato de Camargo
/ Data de Criacao: 10/07/2019
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1832 - Tratamento de Erros Conhecidos (WhiteList)
/ Autor: Renato de Camargo
/ Data de Criacao: 03/10/2019
-------------------------------------------------------------------------------------------------
Autor    : Daniel Nava
Data     : 03/12/2019
Empresa  : Leega
Descricao: Tratamento de alarme diferenciado para processo dispatcher
ID       : EAK-1880
*************************************************************
*/
#pragma once
#include <DBM3.h>
#include <list>
#include <string>
#include <time.h>
#include <vector>


enum siteType { LOCAL_STATMENT, REMOTE_STATMENT };

#define DB_LAG_ALERT_TIME_LIMIT_FLAG "oracle.lag_alert_ms"

static std::string querySqlStatic;
// Necessidade de ser estatica pois SignalHandler eh Static 
static int siteStatmentStatic;   

namespace dbaccess
{
	class connection
	{
	public:
		connection( );
		virtual ~connection( );
		void connect( );
		// Connect using istparam.cfg information
		void connect( const std::string &server, const std::string &user, const std::string &password );
		void disconnect( );
		DBMHSTMT *get_new_statement( );
		void drop_statement( DBMHSTMT *stmt );
		void commit( );
		void rollback( );
		bool IsAlarmEnabled(bool isDispatcher = false);
		// Timeout implementation
		int  GetAlarmTimer(bool isDispatcher = false);		
		void EnableTimer(int seconds);
		void DisableTimer();
		void SetSql( const std::string sqlParam );
		std::string GetSql();
		static void SignalHandler(int signal);	
		bool  IsOracleWhiteListError( const char * OracleError );
        int GetAlarmLagTimeLimit();
        void VerifyLagDifference(struct timeval start);
        int ReadDBLagTimeLimit();
		void SetRemoteStatement();
		void SetLocalStatement();
		bool IsRemoteStatement();
		bool UseForUpdate();
	private:
		DBMHDBC conn;
		bool restartConnection;
		int oracleError;
		siteType siteStatment;  
		// Timeout implementation
		bool alarmEnabled;
		bool alarmDispatcherEnabled;
		bool removeForUpdate;
		int  alarmTimer;
		int  alarmDispatcherTimer;
		std::string querySql;
		std::vector< std::string > oracleWhiteList;		
        int alarmLagTimeLimit;

		typedef std::list<DBMHSTMT> statements_t;
		statements_t statements;
		void handleError( const std::string &method, const DBMHANDLE handle );
		void drop_statements( );
		static void KillProcess( char *, std::string );
		int  LoadWhiteList();
		bool LoadUseForUpdateFlag();
		
		bool IsRestartConnection();

	};
}

