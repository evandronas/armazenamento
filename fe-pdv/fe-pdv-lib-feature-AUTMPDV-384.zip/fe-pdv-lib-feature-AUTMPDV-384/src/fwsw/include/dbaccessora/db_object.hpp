/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 28/05/2019
Empresa  : Rede
Descricao: Adicionando controle para quando ocorrer timeout no commit/rollback
ID       : AM 249.438
*************************************************************
Autor    : Daniel Nava
Data     : 03/12/2019
Empresa  : Leega
Descricao: Altera��o dos m�todos prepare, execute e fetch para conter par�metro opcional (se usa timeout de dispatcher)
ID       : EAK-1880
*************************************************************
*/
#pragma once
#include <map>
#include <string>
#include "dbaccess/statement.hpp"
#include "dbaccess/storage_dev.hpp"
#include "base/ToException.hpp"



namespace dbaccess
{
    #define MAX_VARCHAR 512
    class db_object
    {
    protected:
        db_object( );
        // Using standard storage device
        db_object( storage_dev &stdev );
        // Using a specific storage device
        virtual ~db_object( );
        void handle_fetch( );
        // Perform some conversion in types that
        // are not supported by DBM low level API such as
        // std::string
        void bind_resultset( );
        void handle_parameters( );
        // Perform some conversion in types that
        // are not supported by DBM low level API such as
        // std::string
        void bind_parameters( );
    public:
        virtual void prepare( bool isDispatcher = false );
        virtual void prepare( statement * );
        void execute( bool isDispatcher = false );
        virtual bool fetch( bool isDispatcher = false );
        virtual void close_fetch( );
        void commit( );
        void rollback( );
        bool is_null( int &var ) const;
        bool is_null( char &var ) const;
        bool is_null( char *var ) const;
        bool is_null( std::string &var ) const;
        bool is_null( dbm_datetime_t *var ) const;
        bool is_null( unsigned int &var ) const;
        bool is_null( unsigned char &var ) const;
        bool is_null( long &var ) const;
        bool is_null( unsigned long &var ) const;
        bool is_null( float &var ) const;
        bool is_null( double &var ) const;
        bool is_null( oasis_dec_t &var ) const;
        bool is_null( sw_date_t &var ) const;
        void bind( const unsigned int pos, int &var );
        void bind( const unsigned int pos, char &var );
        void bind( const unsigned int pos, char *var, const size_t capacity=MAX_VARCHAR );
        void bind( const unsigned int pos, std::string &var, const size_t capacity=MAX_VARCHAR );
        void bind( const unsigned int pos, unsigned int &var );
        void bind( const unsigned int pos, unsigned char &var );
        void bind( const unsigned int pos, long &var );
        void bind( const unsigned int pos, unsigned long &var );
        void bind( const unsigned int pos, float &var );
        void bind( const unsigned int pos, double &var );
        void bind( const unsigned int pos, dbm_datetime_t *var );
        void bind( const unsigned int pos, oasis_dec_t &var );
        void bind( const unsigned int pos, sw_date_t &var );
        void bind( const unsigned int pos, int &var, int *ind_null );
        void bind( const unsigned int pos, char &var, int *ind_null );
        void bind( const unsigned int pos, unsigned int &var, int *ind_null );
        void bind( const unsigned int pos, unsigned char &var, int *ind_null );
        void bind( const unsigned int pos, long &var, int *ind_null );
        void bind( const unsigned int pos, unsigned long &var, int *ind_null );
        void bind( const unsigned int pos, float &var, int *ind_null );
        void bind( const unsigned int pos, double &var, int *ind_null );
        void bind( const unsigned int pos, dbm_datetime_t *var, int *ind_null );
        void bind( const unsigned int pos, oasis_dec_t &var, int *ind_null );
        void bind( const unsigned int pos, sw_date_t &var, int *ind_null );
		void TimeoutErrorHandler(base::ToException ex);
		void SetRemoteStatement();
		void SetLocalStatement();
		bool IsRemoteStatement();
		bool UseForUpdate();		
    protected:
        bool is_null( void *ptr ) const;
        virtual void bind_columns( );
        int rec_num;
        virtual std::string get_sql_statement( ) = 0;
        void clean_output_bindings( );
        bool stmt_is_prepared( );
        bool stmt_is_executed( );
        bool resultset_is_valid( );
        statement *get_stmt( );
        storage_dev *get_stdev( );
        connection *get_connection( );
        // For derived classes to perform some action
        virtual void do_release_bindings( );
        virtual void do_release_statement( );
        char *get_buff( const std::string &var, const size_t capacity );
        void register_buff_in( std::string &var, char *str, size_t len );
        void register_buff_out( std::string &var, char *str, size_t len );
        void handle_String_out( );
        void handle_String_in( );
        virtual int translate_pos( int pos ) const;
        statement *stmt;
        bool is_valid( ) const;
        void release_bindings( );
        void release_statement( );
        connection *conn;
    private:
        bool result_is_valid;
        typedef std::map<int, int*> status_t;
        status_t vstatus;
        typedef std::map<void*, int*> status_by_ptr_t;
        status_by_ptr_t vstatus_by_ptr;
        typedef struct
        {
            char *ptr;
            size_t allocated_len;
        }
        ptr_len_t;
        typedef std::map<std::string *, ptr_len_t *> string_bindings_t;
        string_bindings_t str_binds_in;
        string_bindings_t str_binds_out;
        storage_dev &stdev;
        bool is_prepared;
        bool is_executed;
    };
}

