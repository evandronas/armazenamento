/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "dbaccess/db_object.hpp"
#include "dbaccess/statement.hpp"



namespace dbaccess
{
	class resultset
	{
	public:
		resultset( );
		virtual ~resultset( );
		void bind_col( const std::string &field, int &var );
		void bind_col( const std::string &field, char &var );
		void bind_col( const std::string &field, char *var, const size_t capacity );
		void bind_col( const std::string &field, std::string &var, const size_t capacity=MAX_VARCHAR );
		void bind_col( const std::string &field, dbm_datetime_t *var );
		void bind_col( const std::string &field, unsigned int &var );
		void bind_col( const std::string &field, unsigned char &var );
		void bind_col( const std::string &field, long &var );
		void bind_col( const std::string &field, unsigned long &var );
		void bind_col( const std::string &field, float &var );
		void bind_col( const std::string &field, double &var );
		void bind_col( const std::string &field, oasis_dec_t &var );
		std::string get_query_fields( );
		void set_current_db_object( db_object *ob );
		bool fetch( );
		bool is_null( int &var ) const;
		bool is_null( char &var ) const;
		bool is_null( char *var ) const;
		bool is_null( std::string &var ) const;
		bool is_null( dbm_datetime_t *var ) const;
		bool is_null( unsigned int &var ) const;
		bool is_null( unsigned char &var ) const;
		bool is_null( long &var ) const;
		bool is_null( unsigned long &var ) const;
		bool is_null( float &var ) const;
		bool is_null( double &var ) const;
		bool is_null( oasis_dec_t &var ) const;
	protected:
		std::string query_fields;
		int last_field_nbr;
		int add_new_field( const std::string &field );
		virtual void close_fetch( );
		db_object *db_obj;
	};
}

