/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*********************** MODIFICACOES ************************
Autor    : Renato de Camargo
Data     : 06/05/2019
Empresa  : Rede
Descricao: Adicionando controle para dropar transa��o e refazer conex�o dbm no caso de timeout com o banco
ID       : AM 248.335
*************************************************************
Sigla: SW - FE-POS
Descricao: EAK-1638 - Adicionando controle de Timeout no Execute
Autor: Renato de Camargo
Data de Criacao: 10/07/2019
*************************************************************
Sigla: SW - FE-POS
Descricao: EAK-1766 - Adicionando controle para impossibilitar loop infinito
Autor: Renato de Camargo
Data de Criacao: 26/08/2019
*************************************************************
Sigla: SW - FE-POS
Descricao: EAK-1834 - [PacoteEstabilidade] Diferencia��o de erros em BD Local/Remoto
Autor: Renato de Camargo
Data de Criacao: 07/10/2019
*************************************************************
Autor    : Daniel Nava
Data     : 03/12/2019
Empresa  : Leega
Descricao: Altera��o dos m�todos prepare, execute e fetch para conter par�metro opcional (se usa timeout de dispatcher)
ID       : EAK-1880
*************************************************************
*/
#pragma once
#include <map>
#include <string>
#include <syslg.h>
#include "dbaccess/connection.hpp"

/*
** sw_date_t: Estrutura para armazenar data no formato YYYYMMDD (DBM_DATETYPE:dbm_date_t). 
** Este formado de data e utilizado para salvar no banco de dados, datas maiores que 2038.
** Na forma original (usando DBM_DATETIMETYPE:dbm_datetime_t) ocorre um overflow do (long).
** Eh necessario criar esta estrutura porque o bind do dbacess soh aceitava formato long,
** nao teria como diferenciar entre dbm_date_t e dbm_datetime_t na passagem de paremetros.
*/

/* 
Exemplo de TimeOut Gerado quando o parametro SQLNET.RECV_TIMEOUT esta setado no sqlnet.ora

<DBM method dbaccess::statement::execute() returned error message: Statement error: sqlstate=HY000 native_error=3113 msg=ORA-03113: end-of-file on communication channel
*/
/*
/ Sigla: SW - FE-POS
/ Descricao: Inclusao de Novo Erro Oracle
/ Autor: Renato de Camargo
/ Data de Criacao: 07/12/2018
/ -------------------------------------------------------------------------------------------------
*/

#define SQLNET_TIMEOUT_SIGNAL  4                  

#define MAX_DBMGETDIAGREC   10

typedef struct
{
    unsigned long date;
}
sw_date_t;

namespace dbaccess
{
    class statement
    {
    public:
        statement( connection &c );
        virtual ~statement( );
        void bind( const unsigned int pos, short &var, int *status, int *ind_null );
        void bind( const unsigned int pos, int &var, int *status, int *ind_null );
        void bind( const unsigned int pos, char &var, int *status, int *ind_null );
        void bind( const unsigned int pos, char *var, const size_t capacity, int *status, int *ind_null );
        void bind( const unsigned int pos, dbm_datetime_t *var, int *status, int *ind_null );
        void bind( const unsigned int pos, unsigned short &var, int *status, int *ind_null );
        void bind( const unsigned int pos, unsigned int &var, int *status, int *ind_null );
        void bind( const unsigned int pos, unsigned char &var, int *status, int *ind_null );
        void bind( const unsigned int pos, long &var, int *status, int *ind_null );
        void bind( const unsigned int pos, unsigned long &var, int *status, int *ind_null );
        void bind( const unsigned int pos, float &var, int *status, int *ind_null );
        void bind( const unsigned int pos, double &var, int *status, int *ind_null );
        void bind( const unsigned int pos, oasis_dec_t &var, int *status, int *ind_null );
        void bind( const unsigned int pos, sw_date_t &var, int *status, int *ind_null );
        void bind_param( const unsigned int pos, short &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, int &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, char &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, char *var, const size_t size, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, unsigned short &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, unsigned int &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, unsigned char &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, long &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, unsigned long &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, float &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, double &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, oasis_dec_t &var, int inout = DBM_PARAM_INPUT );
        void bind_param( const unsigned int pos, sw_date_t &var, int inout = DBM_PARAM_INPUT );
        void prepare( const std::string &str, bool isDispatcher = false );
        void execute( bool isDispatcher = false );
        bool fetch( bool isDispatcher = false );
        // prepare_positioned( ) for "update" purposes
        void prepare_positioned( statement *pstmt, const std::string &sql );
        void commit( );
        void rollback( );
        void close( );
    protected:
        DBMHSTMT *stmt;
        connection *con;
		bool       restartConnection;
		int        oracleError;
        void handle_retval( const char *, const DBMRETURN ret );
    public:
        // Binding information
        typedef struct
        {
            int type;
            void *buff;
            int buff_len;
            int *status;
            int *ind_null;
        }
        bind_t;
        typedef std::map<int, bind_t> bindings_t;
		void KillProcess( char * );
		void SetSql( std::string sqlParam );
    protected:
        bindings_t bindings;
    public:
        void positioned_upd_bind( statement *stmt );
		bool IsRestartConnection();
        std::string& get_sql_dump( statement *pstmt );
    private:
        std::string m_sql_dump;
    };
}

