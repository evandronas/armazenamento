/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-WEB
/ Descricao:
/ Conteudo:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Criacao: 2012, 21 de julho
/ Historico Mudancas: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/                     2013, 26 de marco, t698224, Raphael Gomes/ t694450, Lauro Sanches:
/                         - Inclusao de metodos set/get para atributo table_name
/ -------------------------------------------------------------------------------------------------
Autor    : Daniel Nava
Data     : 03/12/2019
Empresa  : Leega
Descricao: Alteração do método prepare para conter parâmetro opcional (se usa timeout de dispatcher)
ID       : EAK-1880
*************************************************************
*/
#pragma once
#include <string>
#include "dbaccess/db_object.hpp"
#include "dbaccess/statement.hpp"
#include "dbaccess/storage_dev.hpp"

#define FLAG_FORCE_FOR_UPDATE      1
#define FLAG_NON_FORCE_FOR_UPDATE  0

namespace dbaccess
{
    class table : public db_object
    {
    public:
        table( );
        table( storage_dev &stdev );
        // Using a specific storage device
        virtual ~table( );
        void prepare_for_update( );
		void prepare_for_update( int flag );
        void insert( );
        void update( );
		void update( int flag );
        void delete_record( );
        void prepare_insert( );
        typedef enum
        {
            SELECT, INSERT, UPDATE, DELETE, NONE
        }
        operation_t;
        void prepare( bool isDispatcher = false );
        void bind_resultset( void );
        void setTableName( const std::string tbName );
        const std::string getTableName() const;
		std::string getSqlDump();
    protected:
        std::string query_fields;
        std::string table_name;
        std::string where_condition;
        virtual std::string get_sql_statement( );
        virtual std::string get_sql_insert( );
        virtual std::string get_sql_select( );
        virtual std::string get_sql_update( );
        virtual std::string get_sql_delete( );
        void prepare_update( );
		void prepare_update( int flag );
        void prepare_delete( );
        void execute_update( );
        void execute_delete( );
        void execute_insert( );
        virtual void close_fetch( );
        virtual void bind_params( );
        virtual std::string parse_fields_for_update( const std::string &query_fields ) const;
        virtual std::string get_insert_values_string( const std::string &query_fields ) const;
        // Called by db_object whenever db_object::release_bindings( )
        // and db_object::release_statements( )    are executed.
        virtual void do_release_bindings( );
        virtual void do_release_statement( );
        void set_operation( operation_t op );
        operation_t get_operation( );
        void handle_bindings( );
    private:
        statement *upd_stmt;
        statement *ins_stmt;
        statement *del_stmt;
        bool update_already_prepared;
        bool insert_already_prepared;
        bool delete_already_prepared;
        void release_update_statement( );
        void release_insert_statement( );
        void release_delete_statement( );
        std::string update_addendum;
        operation_t operation;
    };
}

