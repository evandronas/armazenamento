/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Renato de Camargo
Data     : 18/10/2018
Empresa  : Rede
Descricao: Eliminacao de Conexao Pendente
ID       : AM 225800
*************************************************************
*/
#pragma once
#include "dbaccess/connection.hpp"
#include "dbaccess/storage_dev.hpp"



namespace dbaccess
{
	class single_db : public storage_dev
	{
	private:
		single_db( );
		~single_db( );
		// Singleton
		static single_db *_Instance;
		connection *conn;
	public:
		static single_db *get_instance( );
		connection *get_first( );
		connection *get_next( );
		void  DropConnection( );		
	};
}

