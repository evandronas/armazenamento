#pragma once

#include <time.h>
#include <dbm.h>
#include "dbaccess/table.hpp"

#define CHECK_ERR_SUCCESS              0
#define CHECK_ERR_ACCESS_BD_FAILURE   -1

namespace dbaccess
{
    class checkConnection : public dbaccess::table
    {
    public:
        checkConnection();
        virtual ~checkConnection();

        int keepAlive();
        void resetTimer();

    private:
        bool check();
        time_t lastCheck;
        time_t currentCheck;
    };
}//namespace dbaccess_pdv

