/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "dbaccess/db_object.hpp"
#include "dbaccess/resultset.hpp"
#include "dbaccess/statement.hpp"
#include "dbaccess/storage_dev.hpp"



namespace dbaccess
{
	class stfunc : public db_object
	{
	public:
		stfunc( storage_dev &stdev, const std::string &funcname );
		stfunc( const std::string &funcname );
		virtual ~stfunc( );
		typedef enum
		{
			RESULTSET, SINGLE_VALUE, NONE
		}
		ret_t;
		void bind_ret( resultset &res );
		void bind_ret( short &var );
		void bind_ret( int &var );
		void bind_ret( char &var );
		void bind_ret( char *var, const size_t size );
		void bind_ret( unsigned short &var );
		void bind_ret( unsigned int &var );
		void bind_ret( unsigned char &var );
		void bind_ret( long &var );
		void bind_ret( unsigned long &var );
		void bind_ret( float &var );
		void bind_ret( double &var );
		void bind_ret( oasis_dec_t &var );
		void bind_ret( std::string &var, const size_t max_len=MAX_VARCHAR );
		void bind_param( const unsigned int pos, short &var );
		void bind_param( const unsigned int pos, int &var );
		void bind_param( const unsigned int pos, char &var );
		void bind_param( const unsigned int pos, char *var, const size_t size );
		void bind_param( const unsigned int pos, unsigned short &var );
		void bind_param( const unsigned int pos, unsigned int &var );
		void bind_param( const unsigned int pos, unsigned char &var );
		void bind_param( const unsigned int pos, long &var );
		void bind_param( const unsigned int pos, unsigned long &var );
		void bind_param( const unsigned int pos, float &var );
		void bind_param( const unsigned int pos, double &var );
		void bind_param( const unsigned int pos, oasis_dec_t &var );
		void bind_param( const unsigned int pos, std::string &var, const size_t max_len=MAX_VARCHAR );
		void prepare( );
	protected:
		std::string function;
		virtual std::string get_sql_statement( );
		std::string get_funcname( const std::string &fname );
		bool any_binding_exists( ) const;
		void add_parameter( );
		void bind_columns( );
	private:
		void init( );
		std::string get_bindparams_str( );
		ret_t retval_binding_type;
		std::string bindparams_str;
		int translate_pos( int pos );
		bool parameter_binding_exists;
		resultset *res;
	};
}

