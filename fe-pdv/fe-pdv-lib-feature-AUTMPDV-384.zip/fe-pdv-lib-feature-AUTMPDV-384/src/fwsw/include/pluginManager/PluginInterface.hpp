/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "pluginManager/Librarian.hpp"
#include "pluginManager/ObjectsTransporter.hpp"


namespace pluginManager
{
	class PluginInterface
	{
	public:
		PluginInterface( );
		virtual ~PluginInterface( );
		bool open( );
		void close( );
		PluginInterface& setObjectLabel( const std::string& a_objectLabel );
		PluginInterface& setLibraryLabel( const std::string& a_libraryLabel );
		PluginInterface& setCreatorFunctionName( const std::string& a_creatorFunctionName );
		ObjectsTransporter createObject( ) const;
		const std::string& errorMessage( ) const;
	private:
		std::string m_objectLabel;
		std::string m_libraryLabel;
		std::string m_creatorFunctionName;
		std::string m_errorMessage;
		bool m_bOpen;
		typedef base::Identificable*( *CREATOR_FNC_TYPE )( );
		CREATOR_FNC_TYPE objectCreator;
	};
}//namespace pluginManager

