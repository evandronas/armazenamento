/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <map>
#include <string>
#include "pluginManager/ObjectsTransporter.hpp"
#include "pluginManager/PluginInterface.hpp"
#include "pluginManager/PluginManager.hpp"


namespace pluginManager
{
	class PluginManager
	{
	public:
		PluginManager( );
		virtual ~PluginManager( );
		bool open( );
		void close( );
		bool addPluginInterface( const std::string& a_objectLabel, const std::string& a_libraryLabel, const std::string& a_creatorFunctionName );
		ObjectsTransporter createObject( const std::string& a_objectLabel ) const;
		const std::string& errorMessage( ) const;
	private:
		typedef std::map<std::string, PluginInterface> TPMAP;
		typedef std::pair<std::string, PluginInterface> TPPAIR;
		TPMAP m_mapInterfaces;
		std::string m_errorMessage;
		bool m_opened;
	};
}//namespace pluginManager

