/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <map>
#include <string>
#include <vector>
#include "pluginManager/LibraryInterface.hpp"


namespace pluginManager
{
	class Librarian
	{
	public:
		typedef void* DLL_HANDLE;
		static Librarian* getInstance( );
		virtual ~Librarian( );
		bool addLibrary( const std::string& a_libraryLabel, const std::string& a_libraryPath, const std::string& a_libraryName );
		const LibraryInterface& findLibrary( const std::string& a_libraryLabel ) const;
		unsigned int size( ) const;
		LibraryInterface& at( unsigned int a_indexer );
		Librarian& clear( );
	private:
		Librarian( );
		static Librarian* m_instance;
		typedef std::vector<LibraryInterface> LIBVECTOR;
		typedef std::map<std::string, unsigned int> LIBMAP;
		typedef std::pair<std::string, unsigned int> LIBPAIR;
		LIBVECTOR m_libs;
		LIBMAP m_mapLibs;
		LibraryInterface m_dummy;
	};
}//namespace pluginManager

