/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <typeinfo>
#include "base/GenException.hpp"
#include "base/Identificable.hpp"
#include "pluginManager/PluginManager.hpp"


namespace pluginManager
{
	template<class T> class ObjectInterface
	{
	public:
		ObjectInterface( )
		{
			m_pluginManager = 0;
		}
		ObjectInterface( const pluginManager::PluginManager* a_pluginManager )
		{
			m_pluginManager = a_pluginManager;
		}
		virtual ~ObjectInterface( )
		{
		}
		ObjectInterface& setPluginManager( const pluginManager::PluginManager* a_pluginManager )
		{
			m_pluginManager = a_pluginManager;
			return *this;
		}
		T* create( const std::string& a_objectLabel )
		{
			base::genAssert( m_pluginManager != 0, __FUNCTION__, "PluginManager not defined" );
			ObjectsTransporter l_objTransporter = m_pluginManager->createObject( a_objectLabel );
			base::Identificable* l_newObject = l_objTransporter.objectPtr( );
			base::genAssert( l_newObject != 0, __FUNCTION__, "Invalid object <" +  a_objectLabel + ">, check its creator function" );
			T* l_newTypedObject = dynamic_cast<T*>( l_newObject );
			base::genAssert( l_newTypedObject != 0, __FUNCTION__, "Object <" + a_objectLabel
			+ "> is not of type <" + std::string( typeid( T ).name( ) ) + "> but <" + std::string( typeid( l_newObject ).name( ) ) + ">" );
			return l_newTypedObject;
		}
	private:
		const pluginManager::PluginManager* m_pluginManager;
	};
}//namespace pluginManager

