/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>


namespace pluginManager
{
	class LibraryInterface
	{
	public:
		typedef void* LIB_HANDLE;
		LibraryInterface( );
		LibraryInterface( bool a_isDummy );
		virtual ~LibraryInterface( );
		LibraryInterface& setLibraryPath( const std::string& a_libraryPath );
		LibraryInterface& setLibraryName( const std::string& a_libraryName );
		bool open( );
		void close( );
		LIB_HANDLE handle( ) const;
		const std::string& errorMessage( ) const;
		bool isDummy( ) const;
	private:
		std::string m_libraryPath;
		std::string m_libraryName;
		std::string m_errorMessage;
		LIB_HANDLE m_libHandle;
		bool m_isDummy;
	};
}//namespace pluginManager

