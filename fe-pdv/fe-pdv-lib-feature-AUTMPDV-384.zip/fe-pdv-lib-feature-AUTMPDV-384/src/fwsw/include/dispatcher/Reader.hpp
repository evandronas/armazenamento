/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "fieldSet/FieldNavigator.hpp"
#include "base/Identificable.hpp"

namespace dispatcher
{
	class Reader : public base::Identificable
	{
	public:
		Reader( );
		virtual ~Reader( );
		
		virtual bool open( ) = 0;
		virtual void close( ) = 0;
		virtual bool fetch( ) = 0;
		virtual int getTps( ) = 0;
		
		Reader& setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator );
		fieldSet::Field& navigate( const std::string& a_fieldPath );
		const fieldSet::FieldNavigator& navigator( ) const;
		
	private:
		fieldSet::FieldNavigator m_fieldNavigator;
	};
}//namespace dispatcher
