/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once

#include <iostream>
#include <sstream>
#include <string>
#include "configBase/DOMTreatment.hpp"
#include "configBase/Tag.hpp"
#include "configBase/TagList.hpp"
#include "configBase/XMLParseErrorHandler.hpp"
#include "dataManip/DataManip.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "fieldSet/FieldSet.hpp"
#include "mailboxInterface/MailboxIn.hpp"
#include "mailboxInterface/MailboxOut.hpp"
#include "msgConv/MessageConverter.hpp"
#include "pluginManager/PluginManager.hpp"
#include "dispatcher/MainDispatcher.hpp"
#include "logger/Logger.hpp"
#include "dispatcher/Reader.hpp"

namespace dispatcher
{
	class DispatcherLoader
	{
	public:
		DispatcherLoader( );
		virtual ~DispatcherLoader( );
		bool load( );
		void unload( );
		void setXmlPath( const std::string& a_path );
		void setXmlName( const std::string& a_name );
		void setMainDispatcher( MainDispatcher* a_mainDispatcher );
		void setDispatcherLabel( const std::string& a_label );
	private:
		bool loadXml( const std::string& a_xmlPath, const std::string& l_xmlName, configBase::Tag& a_tag );
		void reportXmlErrors( const configBase::XMLParseErrorHandler::ERRMSGS& a_errors );
		bool loadMainDispatcherXml( );
		bool loadXmlFilesSection( );
		bool loadObjectsReferencesTag( );
		bool loadXmlFilesProperties( );
		bool loadObjectsReferencesProperties( );
		bool loadLibrarian( );
		bool loadPluginManager( );
		bool loadFieldSets( );
		bool loadFieldNavigator( );
		bool loadDataManips( );
		bool loadConverters( );
		bool loadMailboxes( );
		bool loadReader( );
		bool loadIntervalSeconds( );
		bool selectLibrarian( );
		bool selectPluginManager( );
		bool selectFieldSets( );
		bool selectDataManips( );
		bool selectIso8583Properties( );
		void cleanup( );
		logger::Logger* m_logger;
		std::stringstream m_logmsg;
		MainDispatcher* m_mainDispatcher;
		pluginManager::PluginManager* m_pluginManager;
		fieldSet::FieldNavigator m_navigator;
		fieldSet::FieldSet* m_xmfFieldSet;
		fieldSet::FieldSet* m_imfFieldSet;
		std::deque<fieldSet::FieldSet*> dm_shdFieldSet;
		fieldSet::FieldSet* m_environment;
		dataManip::DataManip* m_dataManipDispatch;
		msgConv::MessageConverter* m_outboundConverter;
		msgConv::FieldSetLoader* m_outboundLoader;
		msgConv::FieldSetExtractor* m_outboundExtractor;
		dispatcher::Reader* m_reader;
		mailboxInterface::MailboxOut* m_mbOut;
		configBase::TagList m_selectedLibrarianTag;
		configBase::TagList m_selectedPluginManagerTag;
		configBase::Tag m_selectedXmfFieldSetTag;
		configBase::Tag m_selectedImfFieldSetTag;
		std::deque<configBase::Tag> dm_selectedShdFieldSetTag;
		configBase::Tag m_selectedInternalEnvironmentTag;
		configBase::Tag m_selectedDataManipDispatchTag;
		configBase::Tag m_selectedOutboundIso8583PropertiesTag;
		std::string m_mainXmlPath;
		std::string m_mainXmlName;
		std::string m_dispatcherLabel;
		configBase::TagList m_librarianXml;
		configBase::TagList m_pluginManagerXml;
		configBase::TagList m_fieldSetXml;
		configBase::TagList m_dataManipXml;
		configBase::TagList m_iso8583PropertiesXml;
		typedef std::pair<std::string, std::string> FILE_PATH;
		typedef std::deque<FILE_PATH> FILE_LIST;
		FILE_LIST m_librarianXmlPath;
		FILE_LIST m_pluginManagerXmlPath;
		FILE_LIST m_fieldSetXmlPath;
		FILE_LIST m_dataManipXmlPath;
		FILE_LIST m_iso8583PropertiesXmlPath;
		configBase::Tag m_dispatcherTag;
		configBase::TagList m_librarianTag;
		std::deque<std::string> m_librarianRefLabel;
		configBase::TagList m_pluginManagerTag;
		std::deque<std::string> m_pluginManagerRefLabel;
		configBase::Tag m_xmfFieldSetTag;
		std::string m_xmfFieldSetRefLabel;
		std::string m_xmfFieldSetSymbol;
		configBase::Tag m_imfFieldSetTag;
		std::string m_imfFieldSetRefLabel;
		std::string m_imfFieldSetSymbol;
		std::deque<configBase::Tag> dm_shdFieldSetTag;
		std::deque<std::string> dm_shdFieldSetRefLabel;
		std::deque<std::string> dm_shdFieldSetSymbol;
		configBase::Tag m_internalEnvironmentTag;
		std::string m_internalEnvironmentSymbol;
		configBase::Tag m_dataManipDispatchTag;
		std::string m_dataManipDispatchRefLabel;
		configBase::Tag m_converterTag;
		std::string m_outboundType;
		configBase::Tag m_outboundIso8583Property;
		configBase::Tag m_outboundCustomExtractor;
		configBase::Tag m_outboundCustomLoader;
		std::string m_outboundIso8583PropertyRefLabel;
		std::string m_outboundCustomExtractorRefLabel;
		std::string m_outboundCustomLoaderRefLabel;
		configBase::Tag m_trxDispatcherTag;
		std::string m_trxDispatcherRefLabel;
		configBase::Tag m_readerTag;
		std::string m_readerRefLabel;
		configBase::Tag m_intervalSecondsTag;
		unsigned int m_intervalSeconds;
		const std::string ISO8583_ID;
		const std::string QUERY_STRING_ID;
		const std::string SHC_ID;
		const std::string CUSTOM_ID;
	};
}//namespace dispatcher

