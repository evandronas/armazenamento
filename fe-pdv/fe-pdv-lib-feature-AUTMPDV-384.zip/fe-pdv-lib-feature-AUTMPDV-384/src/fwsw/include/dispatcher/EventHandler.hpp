/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once

#include "fieldSet/FieldSet.hpp"
#include "logger/LoggerFmt.hpp"
#include "msgConv/MessageConverter.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "dataManip/DataManip.hpp"

namespace dispatcher
{
	class EventHandler
	{
	public:
		EventHandler( );
		virtual ~EventHandler( );
		bool open( );
		void close( );
		int onStart( );
		bool onTransaction( );
		int onCommand( );
		int onShutDown( );
		int onReload( );
		EventHandler& setOutboundMessageConverter( msgConv::MessageConverter* a_outboundMessageConverter );
		const unsigned char* outboundMessage( ) const;
		unsigned int outboundMessageLength( ) const;
		EventHandler& setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator );
		EventHandler& setEnvironment( fieldSet::Field* a_environment );
		EventHandler& setDataManipDispatch( dataManip::DataManip* a_dataManipDispatch );
	private:
		msgConv::MessageConverter* m_outboundConverter;
		unsigned char* m_outboundBuffer;
		const unsigned int m_maxOutboundLength;
		unsigned int m_outboundMessageLength;
		logger::Logger* m_logger;
		fieldSet::FieldNavigator m_navigator;
		fieldSet::Field* m_environment;
		dataManip::DataManip* m_dataManipDispatch;
	};
}//namespace dispatcher

