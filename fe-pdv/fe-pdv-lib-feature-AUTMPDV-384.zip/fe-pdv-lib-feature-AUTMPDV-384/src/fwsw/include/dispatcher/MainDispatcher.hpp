/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <iostream>
#include <sstream>
#include "dataManip/DataManip.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "fieldSet/FieldSet.hpp"
#include "mailboxInterface/MailboxOut.hpp"
#include "msgConv/MessageConverter.hpp"
#include "pluginManager/PluginManager.hpp"
#include "dispatcher/EventHandler.hpp"
#include "dispatcher/MessageDirection.hpp"
#include "dispatcher/Reader.hpp"
#include "logger/Logger.hpp"

namespace dispatcher
{
	class MainDispatcher
	{

	public:
		MainDispatcher( );
		virtual ~MainDispatcher( );
		bool init( );
		int mainLoop( );
		bool fetchLoop( );
		void setPluginManager( pluginManager::PluginManager* a_pluginManager );
		void setNavigator( const fieldSet::FieldNavigator& a_navigator );
		void setMbOut( mailboxInterface::MailboxOut* a_mbOut );
		void setXmfSymbol( const std::string &a_xmfSymbol );
		void setImfSymbol( const std::string &a_imfSymbol );
		void setEnvSymbol( const std::string &a_envSymbol );
		void setXmfFieldSet( fieldSet::FieldSet* a_xmfFieldSet );
		void setImfFieldSet( fieldSet::FieldSet* a_imfFieldSet );
		void setEnvironment( fieldSet::FieldSet* a_environment );
		void setDataManipDispatch( dataManip::DataManip* a_dataManipDispatch );
		void setOutboundConverter( msgConv::MessageConverter* a_outboundConverter );
		void setReader( Reader* a_reader );
		void setIntervalSeconds( unsigned int a_intervalSeconds );
		void shutdown( );
		static void stop( );
	private:
		static bool m_stop;
		bool m_initialised;
		std::deque<int> splitAddress( const std::string& a_addressString ) const;
		int forwardMessage( );
		void markDate( fieldSet::FieldAccess& a_fieldData );
		bool reloadConfiguration( );
		bool loadEnvironment( );
		logger::Logger* m_logger;
		std::stringstream m_logmsg;
		EventHandler* m_eventHandler;
		pluginManager::PluginManager* m_pluginManager;
		fieldSet::FieldNavigator m_navigator;
		mailboxInterface::MailboxOut* m_mbOut;
		std::string m_xmfSymbol;
		std::string m_imfSymbol;
		std::string m_envSymbol;
		fieldSet::FieldSet* m_xmfFieldSet;
		fieldSet::FieldSet* m_imfFieldSet;
		fieldSet::FieldSet* m_environment;
		dataManip::DataManip* m_dataManipDispatch;
		msgConv::MessageConverter* m_outboundConverter;
		fieldSet::FieldAccess m_returnAddress;
		fieldSet::FieldAccess m_senderAddress;
		fieldSet::FieldAccess m_forwardAddress;
		fieldSet::FieldAccess m_processName;
		fieldSet::FieldAccess m_messageDirection;
		fieldSet::FieldAccess m_pid;
		fieldSet::FieldAccess m_upTimestamp;
		fieldSet::FieldAccess m_fromNetMessageCount;
		fieldSet::FieldAccess m_toNetMessageCount;
		fieldSet::FieldAccess m_messageArrivalTimestamp;
		Reader* m_reader;
		unsigned int m_intervalSeconds;
		int m_tps;
	};
}//namespace dispatcher

