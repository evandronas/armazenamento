/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "configBase/Tag.hpp"
#include "fieldSet/FieldSet.hpp"

namespace configLoader
{
	class FieldSetConfig
	{
	public:
		FieldSetConfig( );
		virtual ~FieldSetConfig( );
		bool load( fieldSet::FieldSet& a_fieldSet, const configBase::Tag& a_tag );
	private:
		bool loadField( fieldSet::Field& a_field, const configBase::Tag& a_tag );
	};
}//namespace configLoader

