/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "configBase/Tag.hpp"
#include "dataManip/DataManip.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "pluginManager/PluginManager.hpp"
#include "logger/Logger.hpp"

namespace configLoader
{
	class DataManipConfig
	{
	public:
		DataManipConfig( size_t a_depth );
		virtual ~DataManipConfig( );
		bool load( dataManip::DataManip& a_dataManip, const configBase::Tag& a_tag );
		DataManipConfig& setPluginManager( const pluginManager::PluginManager* a_pluginManager );
		DataManipConfig& setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator );
		size_t depth( ) const;
	private:
		const pluginManager::PluginManager* m_pluginManager;
		logger::Logger* m_logger;
		fieldSet::FieldNavigator m_fieldNavigator;
		bool loadSwitches( dataManip::DataManip& a_dataManip, const configBase::TagList& a_tag, const fieldSet::FieldNavigator& a_fieldNavigator );
		bool loadCommands( dataManip::DataManip& a_dataManip, const configBase::TagList& a_tag, const fieldSet::FieldNavigator& a_fieldNavigator );
		bool loadBlocks( dataManip::DataManip& a_dataManip, const configBase::TagList& a_tag, const fieldSet::FieldNavigator& a_fieldNavigator );
		bool loadCalls( dataManip::DataManip& a_dataManip, const configBase::TagList& a_tag, const fieldSet::FieldNavigator& a_fieldNavigator );
		size_t m_depth;
	};
}//namespace configLoader

