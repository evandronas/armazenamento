#pragma once

#include "dbaccess/StatementInterface.hpp"
#include "dbaccess/rdms_interface.hpp"

namespace dbaccess
{
    class StmtFactory
    {
    public:
        virtual ~StmtFactory(){};
        virtual StatementInterface * create() const = 0;
        virtual StatementInterface * create(RdmsInterface *) const = 0;
    };
}