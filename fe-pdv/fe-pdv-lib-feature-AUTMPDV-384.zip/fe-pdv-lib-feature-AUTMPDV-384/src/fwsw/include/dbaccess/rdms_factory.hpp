#ifndef DBACCESS_RDMSFACTORY_H
#define DBACCESS_RDMSFACTORY_H

#include "dbaccess/rdms_interface.hpp"

namespace dbaccess
{
    class RdmsFactory
    {
    public:
        virtual ~RdmsFactory(){};
        virtual RdmsInterface * create() const = 0;
    };
}

#endif //DBACCESS_RDMSFACTORY_H