/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#pragma once

#include <iostream>
#include <stdio.h>
#include <vector>
#include "dbaccess/rdms_interface.hpp"

#define SYSLG_CHAR_BY_LINE     100

enum Database
{
    Oracle,
    Postgre
};

namespace dbaccess
{
    class connection
    {
        public:
            ~connection();
            connection(connection &other) = delete; //should not be cloneable
            void operator=(const connection &) = delete; //should not be assignable

            static connection *GetInstance();

            RdmsInterface * getDatabase(int index);
            bool UseForUpdate();
            std::string GetSql();
            void SetSql(std::string);

        private:
            connection();
            void disconnect();
            void configure();
            void connect();

            static connection *m_instance;
            std::vector<RdmsInterface *> databases;

            bool removeForUpdate;
            int connection_retry;
            int connection_retry_interval;
            std::string database_prefix_ps;
            Database databaseType;
            std::string querySql;
            int database_count;
            std::string database_name[endpoint::DBACCESS_ENDPOINT_COUNT];
            std::string connection_timeout;
    };
}
