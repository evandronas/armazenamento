/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#pragma once

#include <libpq-fe.h>
#include <string>

#include "db_object.hpp"

#define FLAG_FORCE_FOR_UPDATE      1
#define FLAG_NON_FORCE_FOR_UPDATE  0

namespace dbaccess
{
    class table : public db_object
    {
        public:
            table();
            virtual ~table();

            void prepare( );
            void prepare( bool isDispatcher );
            void prepare_for_update( );
            void prepare_for_update( int flag );
            void insert( );
            void update( );
            void delete_record( );
            void execute( void );
            bool fetch( void );
            void setTableName( const std::string tbName );
            void bind_resultset( void );
            const std::string getTableName() const;
            std::string getSqlDump();

        protected:
            std::string query_fields;
            std::string table_name;
            std::string where_condition;
            std::string get_sql_insert( void );
            std::string get_sql_select( void );
            std::string get_sql_update( void );
            std::string get_sql_delete( void );

        private:
            std::string m_for_update;
            int GetCountFields( const std::string &queryFields );
            std::string parse_fields_for_insert( const std::string &query_fields );
            std::string parse_fields_for_update( const std::string &query_fields );
            void HandleDatabaseError(const char* functionName, const char* errorMessage);
    };
}
