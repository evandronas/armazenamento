#ifndef DBACCESS_RDMSINTERFACE_H
#define DBACCESS_RDMSINTERFACE_H

#include "dbaccess/alarm_restart_on_timeout.hpp"
#include <string>

#define DB_NO_DATA           100
#define DB_SUCCESS             0
#define DB_SUCCESS_WITH_INFO   1
#define DBM_HANDLE_STMT        3
#define DB_ERROR              -1
#define DB_INVALID_HANDLE     -2


// Tipos de dados dos parametros
enum DBTYPE
{
    DB_CHAR = 1,
    DB_INT,
    DB_UINT,
    DB_LONG,
    DB_ULONG,
    DB_ULLONG,
    DB_DOUBLE,
    DB_FLOAT,
    DB_DECIMAL,
    DB_MONEY,
    DB_DATE,
    DB_BIN,
    DB_NUM,
    DB_RAW,
    DB_DATETIME,
    DB_CHARSTRING,
    DB_STRING
};

namespace dbaccess
{
    class StatementInterface;

    enum endpoint {
        DB_CAPTURA = 0,
        DB_BASEUNICA,
        DBACCESS_ENDPOINT_COUNT
    };

    class RdmsInterface
    {
    public:
        virtual std::string connect(const char * query) = 0;
        virtual bool isConnected(void) = 0;
        virtual void disconnect(void) = 0;
        virtual void clear(void) = 0;
        virtual void begin(void) = 0;
        virtual void commit(void) = 0;
        virtual void insert(const char *, int, const char * const *, const int *, const int *) = 0;
        virtual void update(const char *, int, const char * const *, const int *, const int *) = 0;
        virtual void remove(const char *) = 0;
        virtual void rollback(void) = 0;
        virtual void select(const char *) = 0;
        virtual int isNullField(int, int) = 0;
        virtual int getIndexField(const char *) = 0;
        virtual char * readField(int, int) = 0;
        virtual int getQtdRows(void) = 0;
        virtual int getQtdColumns(void) = 0;
        // virtual void dump(voidresultSet) = 0;
        virtual void DropStatement(StatementInterface *) = 0;
        virtual int CloseStatement(StatementInterface *) = 0;
        virtual void dump() = 0;
    protected:
        AlarmRestartOnTimeout * alarm_restart_on_timeout;
    };
}

#endif //DBACCESS_RDMSINTERFACE_H