#ifndef DBACCESS_ALARMRESTARTONTIMEOUT_H
#define DBACCESS_ALARMRESTARTONTIMEOUT_H

#include <string>

#define SQLNET_TIMEOUT_SIGNAL       4
#define DEFAULT_ALARM               10
#define DEFAULT_DISPATCHER_ALARM    45

static std::string error_message;

namespace dbaccess
{
    class AlarmRestartOnTimeout
    {
    public:
        AlarmRestartOnTimeout();
        ~AlarmRestartOnTimeout();

        static void SignalHandler(int signal);

        void EnableTimer(const char *, bool isDispatcher = false);
        void DisableTimer();

        void VerifyLagDifference(struct timeval start);
        static void KillProcess(const char *);

    private:
        void configure();
        bool IsAlarmEnabled(bool isDispatcher);

        bool alarmEnabled;
        bool alarmDispatcherEnabled;
        int alarmLagTimeLimit;
        int alarmTimer;
        int alarmDispatcherTimer;
    };

}

#endif //DBACCESS_ALARMRESTARTONTIMEOUT_H