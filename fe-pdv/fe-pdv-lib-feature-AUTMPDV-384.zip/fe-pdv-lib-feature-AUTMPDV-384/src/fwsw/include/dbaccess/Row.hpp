/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#pragma once

#include <string>
#include <vector>
#include "assert.h"
#include <netinet/in.h>
#include <sstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "dbaccess/rdms_interface.hpp"

using namespace std;

/// Row
/// Classe responsavel por obter os dados da linha
/// EF/ET: ET1
/// Historico: [Data] - [Autor] - ET - Descricao
/// 08/02/2021 - Andre Morishita - ET1 - Criacao da versao inicial
struct Row 
{
    int rowno;
    dbaccess::RdmsInterface * database;

    Row(dbaccess::RdmsInterface* database, int _rowno = 0);

    template <typename _T>
    _T Get(int);

    /** gets the content of named column in a row*/
    template <typename _T>
    _T Get(const std::string&);

    bool operator ==(const Row& other) const;
    bool operator !=(const Row& other) const;
    bool operator < (const Row& other) const;

    /** iterate to next row in a result set*/
    const Row& operator ++();

   long GetDateTime(int colno);
   unsigned long GetDate(int colno);
   bool IsNull(int colno);
};

template <typename T>
T Row::Get(const std::string& colname) 
{
    int colno = database->getIndexField(colname.c_str());
    return Get<T>(colno);
}
