#pragma once

#include <vector>
#include "dbaccess/StatementInterface.hpp"
#include "dbaccess/rdms_interface.hpp"
#include <libpq-fe.h>

class RdmsInterface;

typedef struct _BindData
{
    unsigned int posicao;
    char *valor;
    DBTYPE type;
    void *ptrBind;
    bool isNull;
    int inout;

    bool operator==(const struct _BindData &a) const
    {
        return posicao == a.posicao;
    }
    bool operator<(const struct _BindData &a) const
    {
        return posicao < a.posicao;
    }
} BindData;


namespace dbaccess
{
    class PGStmt : public StatementInterface
    {
        public:
            PGStmt( );
            PGStmt( RdmsInterface* );

            int Bind( const unsigned int, int &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, short &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, char &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, char *, const size_t, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, long *, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, unsigned short &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, unsigned int &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, unsigned char &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, long &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, unsigned long &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, float &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, double &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, oasis_dec_t &, int *, int *, int inout = PARAM_INPUT );
            int Bind( const unsigned int, int, void *, int, int *, int inout = PARAM_INPUT );
            int Prepare( char * );
            int Execute();
            int PrepareParams( std::vector<BindData>&, char ** );
            int GetDiagRec( int, int, char*, int*, char *, int, int* );
            //const char* BindStrData( BindData& );
            int Fetch();
            std::string GetPreparedName() const;
            int PreparePositioned( StatementInterface *, char * );

        private:
            std::vector<BindData> paramValues;
            void PrepareSqlString( std::string& );

            PGresult *resultSet;
            int fetchPos;
    };
}
