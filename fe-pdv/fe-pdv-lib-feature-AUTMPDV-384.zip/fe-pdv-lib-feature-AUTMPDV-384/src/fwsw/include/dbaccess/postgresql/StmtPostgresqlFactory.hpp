#pragma once

#include "dbaccess/StmtFactory.hpp"
#include "dbaccess/StatementInterface.hpp"
#include "dbaccess/postgresql/PGStmt.hpp"

namespace dbaccess
{
    class StmtPostgresqlFactory : public StmtFactory
    {
    public:
        StatementInterface * create() const {
            return new PGStmt();
        };
        StatementInterface * create(RdmsInterface *con) const {
            return new PGStmt(con);
        };
    };
}