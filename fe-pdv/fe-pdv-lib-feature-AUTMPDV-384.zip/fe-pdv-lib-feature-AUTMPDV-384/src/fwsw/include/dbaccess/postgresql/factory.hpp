#ifndef DBACCESS_POSTGRESQL_FACTORY_H
#define DBACCESS_POSTGRESQL_FACTORY_H

#include "dbaccess/rdms_factory.hpp"
#include "dbaccess/postgresql/rdms.hpp"


namespace dbaccess
{
    class RdmsPostgresqlFactory : public RdmsFactory
    {
    public:
        RdmsInterface * create() const {
            return new RdmsPostgresql();
        };
    };
}

#endif //DBACCESS_POSTGRESQL_FACTORY_H
