#ifndef DBACCESS_POSTGRESQL_RDMS_H
#define DBACCESS_POSTGRESQL_RDMS_H

#include <unordered_map>
#include <memory>
#include "dbaccess/rdms_interface.hpp"
#include "dbaccess/postgresql/PGStmt.hpp"
#include <libpq-fe.h>

namespace dbaccess
{
    class RdmsPostgresql : public RdmsInterface
    {

    public:
        RdmsPostgresql();
        ~RdmsPostgresql();
        std::string connect(const char * query);
        bool isConnected(void);
        void disconnect(void);
        void clear(void);
        void begin(void);
        void commit(void);
        void insert(const char *, int, const char * const *, const int *, const int *);
        void update(const char *, int, const char * const *, const int *, const int *);
        void remove(const char *);
        void rollback(void);
        void select(const char * );
        int getQtdRows(void);
        int getQtdColumns(void);
        int isNullField(int, int);
        int getIndexField(const char *);
        char * readField(int, int);
        void dump();
        StatementInterface * GetNewStatement( );
        void DropStatement(StatementInterface *);
        PGconn * GetConn();
        int CloseStatement(StatementInterface *);

    private:
        PGconn * conn;
        PGresult * result;

    protected:
        typedef std::unordered_map<std::string,std::shared_ptr<PGStmt> > statements_t;
        statements_t mStatements;
    };
}

#endif //DBACCESS_POSTGRESQL_RDMS_H
