/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#pragma once

#include <libpq-fe.h>
#include <dbm.h>

#include <map>
#include <string>
#include <sstream>

#include "dbaccess/rdms_interface.hpp"
#include "connection.hpp"

#include <vector>

#define MAX_VARCHAR 512
#define DBM_NULL_DATA (-1)

// Params
#define MAX_PARAM  65535

typedef struct
{
    unsigned long date;
}
sw_date_t;

namespace dbaccess
{
	class db_object
	{
	public:
		db_object();
		virtual ~db_object();

        void update_database_id(int id);
		void commit( void );
		void rollback( void );

        virtual void prepare( );
        virtual void prepare( bool isDispatcher );
		virtual void execute( void );
        virtual bool fetch( );

        void Dump( PGresult *result );

        bool is_null( int &var ) const;
        bool is_null( char &var ) const;
        bool is_null( char *var ) const;
        bool is_null( std::string &var ) const;
        bool is_null( dbm_datetime_t *var ) const;
        bool is_null( unsigned int &var ) const;
        bool is_null( unsigned char &var ) const;
        bool is_null( long &var ) const;
        bool is_null( unsigned long &var ) const;
        bool is_null( float &var ) const;
        bool is_null( double &var ) const;
        bool is_null( oasis_dec_t &var ) const;
        bool is_null( sw_date_t &var ) const;

        void handle_parameters( void );
        void handle_fetch( void );
        void bind_param( const unsigned int posicao, const int type, void *buffer, int bufferLen, int *status, int *indNull );
        virtual void bind_resultset( void );

        void bind( const unsigned int pos, int &var );
        void bind( const unsigned int pos, char &var );
        void bind( const unsigned int pos, char *var, const size_t capacity=MAX_VARCHAR );
        void bind( const unsigned int pos, std::string &var, const size_t capacity=MAX_VARCHAR );
        void bind( const unsigned int pos, unsigned int &var );
        void bind( const unsigned int pos, unsigned char &var );
        void bind( const unsigned int pos, long &var );
        void bind( const unsigned int pos, unsigned long &var );
		void bind( const unsigned int pos, unsigned long long &var );
        void bind( const unsigned int pos, float &var );
        void bind( const unsigned int pos, double &var );
        void bind( const unsigned int pos, dbm_datetime_t *var );
        void bind( const unsigned int pos, oasis_dec_t &var );
        void bind( const unsigned int pos, sw_date_t &var );
        
        void bind( const unsigned int pos, int &var, int *ind_null );
        void bind( const unsigned int pos, char &var, int *ind_null );
        void bind( const unsigned int pos, unsigned int &var, int *ind_null );
        void bind( const unsigned int pos, unsigned char &var, int *ind_null );
        void bind( const unsigned int pos, long &var, int *ind_null );
        void bind( const unsigned int pos, unsigned long &var, int *ind_null );
        void bind( const unsigned int pos, unsigned long long &var, int *ind_null );
        void bind( const unsigned int pos, float &var, int *ind_null );
        void bind( const unsigned int pos, double &var, int *ind_null );
        void bind( const unsigned int pos, dbm_datetime_t *var, int *ind_null );
        void bind( const unsigned int pos, oasis_dec_t &var, int *ind_null );
        void bind( const unsigned int pos, sw_date_t &var, int *ind_null );

	protected:

        // campos nulos 
        typedef std::map<int, int*> status_t;
        status_t vstatus;
        typedef std::map<void*, int*> status_by_ptr_t;
        status_by_ptr_t vstatus_by_ptr;

        // Binding information
        typedef struct
        {
            int type;
            void *buffer;
            int bufferLen;
            int *status;
            int *indNull;
        } bind_t;
        typedef std::map<int, bind_t> bindings_t;
        bindings_t bindings;

        // Binding de campos string
        typedef struct
        {
            char *ptr;
            size_t allocated_len;
        } ptr_len_t;
        typedef std::map<std::string *, ptr_len_t *> string_bindings_t;
        string_bindings_t str_binds_in;
        string_bindings_t str_binds_out;

        std::vector<void *> allocated_pointers;
        std::vector<void *> allocated_array_pointers;

        connection * conn;
        RdmsInterface * database;
        int m_rowNumber;
        int m_rowCounter;

		char const *paramValues[MAX_PARAM] = {0};
		int  paramLengths[MAX_PARAM] = {0};
		int paramFormats[MAX_PARAM] = {0};
		Oid paramTypes[MAX_PARAM] = {0};
        int paramAllocatedTotal = 0;

        bool is_null( void *ptr ) const;
		virtual void bind_columns( void );
        char *get_buff( const std::string &var, const size_t capacity );
        void register_buff_in( std::string &var, char *str, size_t len );
        void register_buff_out( std::string &var, char *str, size_t len );
        void handle_String_out( );
        void handle_String_in( );
        void clean_output_bindings( );
        void release_bindings( );

	private:

	};
}
