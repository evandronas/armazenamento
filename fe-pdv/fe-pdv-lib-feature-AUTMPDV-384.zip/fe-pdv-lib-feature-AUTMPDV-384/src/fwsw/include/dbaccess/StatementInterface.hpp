#pragma once

#include "rdms_interface.hpp"
#include <DBM3.h>

#define DB_PARAM_INPUT      DBM_PARAM_INPUT
#define DB_PARAM_OUTPUT     DBM_PARAM_OUTPUT
#define DB_NULL_DATA        DBM_NULL_DATA
#define PARAM_INPUT         1
#define PARAM_OUTPUT        2
#define PARAM_INPUT_OUTPUT  4

typedef struct
{
    unsigned long date;
}
sw_date_t;

namespace dbaccess
{
    class StatementInterface
    {
        public:
            virtual std::string GetPreparedName() const = 0;
            virtual int Bind( const unsigned int, short &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, int &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, char &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, char *, const size_t, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, long *, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, unsigned short &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, unsigned int &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, unsigned char &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, long &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, unsigned long &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, float &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, double &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, oasis_dec_t &, int *, int *, int inout = PARAM_INPUT ) = 0;
            virtual int Bind( const unsigned int, int, void *, int, int *, int inout = PARAM_INPUT ) = 0;
            virtual int GetDiagRec( int, int, char*, int*, char *, int, int* ) = 0;
            virtual int Prepare( char * ) = 0;
            virtual int Execute() = 0;
            virtual int Fetch() = 0;
            virtual int PreparePositioned( StatementInterface *, char * ) = 0;

        protected:
            std::string preparedName;
            RdmsInterface *conn;
            bool isPrepared;
    };
}
