/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo Morais de Souza
Data     : 04/10/2018
Empresa  : Rede
Descricao: Geracao do log TCPIP descriptografado
ID       : AM 331044
*************************************************************
*/

/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 07/11/2018
Empresa  : Rede
Descricao: Adicionado nivel default como DUMP
ID       : AM 237648
*************************************************************
*/

#ifndef _LEVEL_HPP_
#define _LEVEL_HPP_

#pragma once
#include <ist_otrace.h>

namespace logger
{
	#define DEFAULT_LEVEL LEVEL_DUMP

	enum Level
	{
		LEVEL_NONE = OTRACE_NONE, 
		LEVEL_FATAL = OTRACE_FATAL, 
		LEVEL_ERROR = OTRACE_ERROR, 
		LEVEL_WARNING = OTRACE_WARNING, 
		LEVEL_INFO = OTRACE_INFO,  
		LEVEL_DUMP = OTRACE_DUMP, 
		LEVEL_DEBUG = OTRACE_DEBUG, 
		LEVEL_TRACE, LEVEL_DROPPED, 
		LEVEL_THROTTLE, 
		LEVEL_THROTTLE_REV,
		LEVEL_ALWAYS,
		LEVEL_POSIP_IN,
		LEVEL_POSIP_OUT
	};
}//namespace logger
#endif /*_LEVEL_HPP_ */

