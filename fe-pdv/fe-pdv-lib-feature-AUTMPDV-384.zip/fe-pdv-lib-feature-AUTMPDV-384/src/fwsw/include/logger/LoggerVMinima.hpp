#pragma once
#include "logger/Logger.hpp"

namespace logger
{
    class LoggerVMinima : public Logger
    {
    public:
        static LoggerVMinima* getInstance( );
    protected:
        LoggerVMinima( );
        virtual ~LoggerVMinima( );
        void createWriters( );
    private:
        static LoggerVMinima* m_instance;
    };
};
