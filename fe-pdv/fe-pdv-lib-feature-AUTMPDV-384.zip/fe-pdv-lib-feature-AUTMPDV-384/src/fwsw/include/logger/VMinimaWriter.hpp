#pragma once
#include <string>
#include "logger/Writer.hpp"

namespace logger
{
    class VMinimaWriter : public Writer
    {
    public:
        static VMinimaWriter* getInstance( );
        void open( );
        void write( Level a_level, const char* a_msg );
        void write( Level a_level, const char* a_msg, const int a_length );
        void close( );
    protected:
        VMinimaWriter( );
        virtual ~VMinimaWriter( );
    private:
        static VMinimaWriter* m_instance;
        std::string m_fileName;
    };
};
