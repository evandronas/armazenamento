/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include <vector>
#include "logger/Writer.hpp"

namespace logger
{
	class Logger
	{
	public:
		Logger( );
		virtual ~Logger( );
		void init( );
		virtual void print( Level a_level, const char* a_msg );
		virtual void print( Level a_level, const std::string& a_msg );
		virtual void print( Level a_level, const char* a_msg, const int a_length );
		void addWriter( Writer* a_writer );
	protected:
		virtual void createWriters( );
	private:
		std::vector<Writer*> m_writerList;
		bool m_Initialized;
	};
};

