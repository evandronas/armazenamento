/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "logger/Writer.hpp"

namespace logger
{
	class DebugWriter : public Writer
	{
	public:
		static DebugWriter* getInstance( );
		void open( );
		void write( Level a_level, const char* a_msg );
		void write( Level a_level, const char* a_msg, const int a_length );
		void setTypeAcronym( const char* a_acronym );
		void close( );
	protected:
		DebugWriter( );
		virtual ~DebugWriter( );
	private:
		static DebugWriter* m_instance;
		static bool m_opened;
		char m_typeAcronym[256];
		Level m_init_level;
	};
};

