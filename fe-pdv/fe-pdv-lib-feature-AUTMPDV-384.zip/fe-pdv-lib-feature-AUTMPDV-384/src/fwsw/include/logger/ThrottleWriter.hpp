/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "logger/Writer.hpp"

namespace logger
{
	class ThrottleWriter : public Writer
	{
	public:
		static ThrottleWriter* getInstance( );
		void open( );
		void write( Level a_level, const char* a_msg );
		void write( Level a_level, const char* a_msg, const int a_length );
		void close( );
	protected:
		ThrottleWriter( );
		virtual ~ThrottleWriter( );
	private:
		static ThrottleWriter* m_instance;
		std::string m_fileName;
		std::string fileNameUndoingDeals;
	};
};

