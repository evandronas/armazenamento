/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo Morais de Souza
Data     : 04/10/2018
Empresa  : Rede
Descricao: Geração do log TCPIP descriptografado
ID       : AM 225.800
*************************************************************
*/

#ifndef _POSIP_WRITER_HPP_
#define _POSIP_WRITER_HPP_

#pragma once
#include <string>
#include "logger/Writer.hpp"

namespace logger {
	class POSIPWriter : public Writer {

	public:
		static POSIPWriter* getInstance( );
		void open( );
		void write( Level level, const char* msg );
		void write( Level level, const char* msg, const int length );
		void close( );

	protected:
		 POSIPWriter( );
		virtual ~ POSIPWriter( );

	private:
		static  POSIPWriter* instance;
		std::string fileName;
	};
}//namespace logger
#endif /* _POSIP_WRITER_HPP_ */

