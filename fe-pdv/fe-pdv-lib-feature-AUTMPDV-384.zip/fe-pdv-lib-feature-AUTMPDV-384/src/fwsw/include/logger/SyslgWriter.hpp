/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 07/11/2018
Empresa  : Rede
Descricao: Adicionada constante SYSLG_MAX_BUFFSIZE usada no cpp
ID       : AM 237648
*************************************************************
*/

#pragma once
#include "logger/Writer.hpp"

#define SYSLG_MAX_BUFFSIZE 1023
namespace logger
{
	class SyslgWriter : public Writer
	{
	public:
		static SyslgWriter* getInstance( );
		void open( );
		void write( Level a_level, const char* a_msg );
		void write( Level a_level, const char* a_msg, const int a_length );
		void close( );
		void setTypeAcronym( const char* a_acronym );
	protected:
		SyslgWriter( );
		virtual ~SyslgWriter( );
	private:
		static SyslgWriter* m_instance;
		char m_typeAcronym[256];
	};
};

