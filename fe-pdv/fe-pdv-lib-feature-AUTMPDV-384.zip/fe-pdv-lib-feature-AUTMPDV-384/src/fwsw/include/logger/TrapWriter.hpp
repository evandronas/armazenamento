#pragma once
#include <string>
#include "logger/Writer.hpp"

namespace logger
{
    class TrapWriter : public Writer
    {
    public:
        static TrapWriter* getInstance( );
        void open( );
        void write( Level a_level, const char* a_msg );
        void write( Level a_level, const char* a_msg, const int a_length );
        void close( );
    protected:
        TrapWriter( );
        virtual ~TrapWriter( );
    private:
        static TrapWriter* m_instance;
        std::string m_fileName;
    };
};
