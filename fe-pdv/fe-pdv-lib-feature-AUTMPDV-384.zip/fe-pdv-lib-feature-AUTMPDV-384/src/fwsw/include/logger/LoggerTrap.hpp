#pragma once
#include "logger/Logger.hpp"

namespace logger
{
    class LoggerTrap : public Logger
    {
    public:
        static LoggerTrap* getInstance( );
    protected:
        LoggerTrap( );
        virtual ~LoggerTrap( );
        void createWriters( );
    private:
        static LoggerTrap* m_instance;
    };
};
