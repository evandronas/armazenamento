/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <exception>
#include "base/GenException.hpp"
#include "base/Identificable.hpp"
#include "dataManip/DataManip.hpp"
#include "fieldSet/FieldSet.hpp"
#include "engine/MessageDirection.hpp"

namespace engine
{
	class TrxEngine : public base::Identificable
	{
	public:
		TrxEngine( );
		virtual ~TrxEngine( );
		virtual bool open( ) = 0;
		virtual void close( ) = 0;
		virtual MessageDirection onRequest( ) = 0;
		virtual MessageDirection onNegativeRequest( ) = 0;
		virtual MessageDirection onResponse( ) = 0;
		virtual int onCommand( ) = 0;
		virtual int onEvent( ) = 0;
		virtual void onRequestException( const base::GenException& a_exception ) = 0;
		virtual void onRequestNegativeException( const base::GenException& a_exception ) = 0;
		virtual void onResponseException( const base::GenException& a_exception ) = 0;
		
		virtual void onCommandException( const base::GenException& a_exception ) = 0;
		virtual void onEventException( const base::GenException& a_exception ) = 0;
		
		virtual void onRequestException( const std::exception& a_exception ) = 0;
		virtual void onRequestNegativeException( const std::exception& a_exception ) = 0;
		
		virtual void onCommandException( const std::exception& a_exception ) = 0;
		virtual void onEventException( const std::exception& a_exception ) = 0;
		
		virtual void onResponseException( const std::exception& a_exception ) = 0;
		virtual void onRequestException( ) = 0;
		virtual void onRequestNegativeException( ) = 0;
		virtual void onResponseException( ) = 0;
		
		virtual void onCommandException( ) = 0;
		virtual void onEventException( ) = 0;
		
		fieldSet::Field& navigate( const std::string& a_fieldPath );
		const fieldSet::FieldNavigator& navigator( ) const;
		TrxEngine& setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator );
		TrxEngine& setEnvironment( fieldSet::Field* a_environment );
		TrxEngine& setDataManipRequest( dataManip::DataManip* a_dataManipFromNet );
		TrxEngine& setDataManipResponse( dataManip::DataManip* a_dataManipToNet );
		TrxEngine& setDataManipNegative( dataManip::DataManip* a_dataManipNegative );
		TrxEngine& setDataManipCommand( dataManip::DataManip* a_dataManipCommand );
		TrxEngine& setDataManipEvent( dataManip::DataManip* a_dataManipEvent );
		fieldSet::Field& environment( );
		fieldSet::Field& environment( const std::string& a_variable );
		dataManip::DataManip& dataManipRequest( );
		dataManip::DataManip& dataManipResponse( );
		dataManip::DataManip& dataManipNegative( );
		dataManip::DataManip& dataManipCommand( );
		dataManip::DataManip& dataManipEvent( );
	private:
		fieldSet::FieldNavigator m_navigator;
		fieldSet::Field* m_environment;
		dataManip::DataManip* m_dataManipRequest;
		dataManip::DataManip* m_dataManipResponse;
		dataManip::DataManip* m_dataManipNegative;
		dataManip::DataManip* m_dataManipCommand;
		dataManip::DataManip* m_dataManipEvent;
	};
}//namespace engine

