/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: Inclusao de Opcao de DROP sem LOG
/ Autor: Gustavo Silva Franco
/ Data de Criacao: 29/11/2018
/ -------------------------------------------------------------------------------------------------
/ Historico Mudancas: 2019, 12 de Marco, Renato de Camargo, Tratamento Redirect (EAK 1420)
*/
#pragma once


namespace engine
{
	enum MessageDirection
	{
		FROM_NET, TO_NET, DROP, DROP_NOLOG, REDIRECT
	};
}//namespace engine

