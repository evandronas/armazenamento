/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ Historico Mudan�as: 2019, 12 de marco, Renato de Camargo, EAK-1420  ==>  AM 243.932
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "engine/MessageDirection.hpp"
#include "engine/TrxEngine.hpp"
#include "fieldSet/FieldSet.hpp"
#include "logger/LoggerFmt.hpp"
#include "msgConv/MessageConverter.hpp"


namespace engine
{
	class EventHandler
	{
	public:
		EventHandler( );
		virtual ~EventHandler( );
		bool open( );
		void close( );
		int onStart( );
		MessageDirection onTransaction( const unsigned char* a_inboundMessage, unsigned int a_inboundMessageLength, MessageDirection a_direction );
		int onCommand( const unsigned char* a_inboundMessage, unsigned int a_inboundMessageLength );
		int onEvent( const unsigned char* a_inboundMessage, unsigned int a_inboundMessageLength );
		int onShutDown( );
		int onReload( );
		EventHandler& setTrxEngine( TrxEngine* a_trxEngine );
		EventHandler& setInboundMessageConverter( msgConv::MessageConverter* a_inboundMessageConverter );
		EventHandler& setOutboundMessageConverter( msgConv::MessageConverter* a_outboundMessageConverter );
		EventHandler& setOutboundMessageRedirectConverter( msgConv::MessageConverter* outboundMessageRedirectConverter );
		
		EventHandler& setCommandMessageConverter( msgConv::MessageConverter* a_commandMessageConverter );
		EventHandler& setEventMessageConverter( msgConv::MessageConverter* a_eventMessageConverter );
		const unsigned char* outboundMessage( ) const;
		unsigned int outboundMessageLength( ) const;
	private:
		msgConv::MessageConverter* m_inboundConverter;
		msgConv::MessageConverter* m_outboundConverter;
		msgConv::MessageConverter* outboundRedirectConverter;
		msgConv::MessageConverter* m_commandConverter;
		msgConv::MessageConverter* m_eventConverter;
		TrxEngine* m_trxEngine;
		unsigned char* m_outboundBuffer;
		const unsigned int m_maxOutboundLength;
		unsigned int m_outboundMessageLength;
		logger::Logger* m_logger;
	};
}//namespace engine

