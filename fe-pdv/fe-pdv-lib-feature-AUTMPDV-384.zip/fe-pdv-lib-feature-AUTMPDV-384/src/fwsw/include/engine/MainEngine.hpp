/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ Historico Mudancas: 2019, 12 de Marco, Renato de Camargo, Tratamento Passthrough (EAK 1420)
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <iostream>
#include <sstream>
#include "dataManip/DataManip.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "fieldSet/FieldSet.hpp"
#include "mailboxInterface/MailboxIn.hpp"
#include "mailboxInterface/MailboxOut.hpp"
#include "msgConv/MessageConverter.hpp"
#include "pluginManager/PluginManager.hpp"
#include "engine/EventHandler.hpp"
#include "engine/MessageDirection.hpp"
#include "logger/Logger.hpp"

namespace engine
{
	class MainEngine
	{
	public:
		MainEngine( );
		virtual ~MainEngine( );
		bool init( );
		int mainLoop( );
		void setTrxEngine( TrxEngine* a_trxEngine );
		void setPluginManager( pluginManager::PluginManager* a_pluginManager );
		void setNavigator( const fieldSet::FieldNavigator& a_navigator );
		void setMbIn( mailboxInterface::MailboxIn* a_mbIn );
		void setMbOut( mailboxInterface::MailboxOut* a_mbOut );
		void setXmfSymbol( const std::string &a_xmfSymbol );
		void setImfSymbol( const std::string &a_imfSymbol );
		void setEnvSymbol( const std::string &a_envSymbol );
		void setXmfFieldSet( fieldSet::FieldSet* a_xmfFieldSet );
		void setImfFieldSet( fieldSet::FieldSet* a_imfFieldSet );
		void setEnvironment( fieldSet::FieldSet* a_environment );
		void setDataManipRequest( dataManip::DataManip* a_dataManipRequest );
		void setDataManipResponse( dataManip::DataManip* a_dataManipResponse );
		void setDataManipNegative( dataManip::DataManip* a_dataManipNegative );
		void setDataManipCommand( dataManip::DataManip* a_dataManipCommand );
		void setDataManipEvent( dataManip::DataManip* a_dataManipEvent );
		void setInboundConverter( msgConv::MessageConverter* a_inboundConverter );
		void setOutboundConverter( msgConv::MessageConverter* a_outboundConverter );
		void setOutboundRedirectConverter( msgConv::MessageConverter* paramOutboundRedirectConverter );
		void shutdown( );
		static void stop( );
	private:
		static bool m_stop;
		bool m_initialised;
		std::deque<int> splitAddress( const std::string& a_addressString ) const;
		int forwardMessage( MessageDirection a_direction );
		void markDate( fieldSet::FieldAccess& a_fieldData );
		bool reloadConfiguration( );
		bool loadEnvironment( );
		logger::Logger* m_logger;
		std::stringstream m_logmsg;
		EventHandler* m_eventHandler;
		TrxEngine* m_trxEngine;
		pluginManager::PluginManager* m_pluginManager;
		fieldSet::FieldNavigator m_navigator;
		mailboxInterface::MailboxIn* m_mbIn;
		mailboxInterface::MailboxOut* m_mbOut;
		std::string m_xmfSymbol;
		std::string m_imfSymbol;
		std::string m_envSymbol;
		fieldSet::FieldSet* m_xmfFieldSet;
		fieldSet::FieldSet* m_imfFieldSet;
		fieldSet::FieldSet* m_environment;
		dataManip::DataManip* m_dataManipRequest;
		dataManip::DataManip* m_dataManipResponse;
		dataManip::DataManip* m_dataManipNegative;
		dataManip::DataManip* m_dataManipCommand;
		dataManip::DataManip* m_dataManipEvent;
		msgConv::MessageConverter* m_inboundConverter;
		msgConv::MessageConverter* m_outboundConverter;
		msgConv::MessageConverter* outboundRedirectConverter;
		fieldSet::FieldAccess m_inboundAddress;
		fieldSet::FieldAccess m_outboundAddress;
		fieldSet::FieldAccess m_returnAddress;
		fieldSet::FieldAccess m_senderAddress;
		fieldSet::FieldAccess m_forwardAddress;
		fieldSet::FieldAccess m_processName;
		fieldSet::FieldAccess m_messageDirection;
		fieldSet::FieldAccess m_pid;
		fieldSet::FieldAccess m_upTimestamp;
		fieldSet::FieldAccess m_fromNetMessageCount;
		fieldSet::FieldAccess m_toNetMessageCount;
		fieldSet::FieldAccess m_messageArrivalTimestamp;
		fieldSet::FieldAccess m_portAddress;
		fieldSet::FieldAccess m_eventDataBuffer;
		fieldSet::FieldAccess m_eventDataLength;
		fieldSet::FieldAccess redirectAddress;
	};
}//namespace engine

