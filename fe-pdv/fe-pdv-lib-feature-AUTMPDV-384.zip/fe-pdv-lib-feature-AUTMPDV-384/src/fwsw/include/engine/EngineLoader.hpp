/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ Hist�rico Mudan�as: 2019, 01 de Fevereiro, Renato de Camargo, Inclusao tratamento JSON
/ Historico Mudancas: 2019, 12 de Marco, Renato de Camargo, Tratamento Redirect (EAK 1420)
/ -------------------------------------------------------------------------------------------------
*/
#pragma once

#include <iostream>
#include <sstream>
#include <string>
#include "configBase/DOMTreatment.hpp"
#include "configBase/Tag.hpp"
#include "configBase/TagList.hpp"
#include "configBase/XMLParseErrorHandler.hpp"
#include "dataManip/DataManip.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "fieldSet/FieldSet.hpp"
#include "mailboxInterface/MailboxIn.hpp"
#include "mailboxInterface/MailboxOut.hpp"
#include "msgConv/MessageConverter.hpp"
#include "pluginManager/PluginManager.hpp"
#include "engine/MainEngine.hpp"
#include "engine/TrxEngine.hpp"
#include "logger/Logger.hpp"

namespace engine
{
	class EngineLoader
	{
	public:
		EngineLoader( );
		virtual ~EngineLoader( );
		bool load( );
		void unload( );
		void setXmlPath( const std::string& a_path );
		void setXmlName( const std::string& a_name );
		void setMainEngine( MainEngine* a_mainEngine );
		void setEngineLabel( const std::string& a_label );
	private:
		bool loadXml( const std::string& a_xmlPath, const std::string& l_xmlName, configBase::Tag& a_tag );
		void reportXmlErrors( const configBase::XMLParseErrorHandler::ERRMSGS& a_errors );
		bool loadMainEngineXml( );
		bool loadXmlFilesSection( );
		bool loadObjectsReferencesTag( );
		bool loadXmlFilesProperties( );
		bool loadObjectsReferencesProperties( );
		bool loadLibrarian( );
		bool loadPluginManager( );
		bool loadFieldSets( );
		bool loadFieldNavigator( );
		bool loadDataManips( );
		bool loadConverters( );
		bool loadMailboxes( );
		bool loadTrxEngine( );
		bool selectLibrarian( );
		bool selectPluginManager( );
		bool selectFieldSets( );
		bool selectDataManips( );
		bool selectIso8583Properties( );
		void cleanup( );
		logger::Logger* m_logger;
		std::stringstream m_logmsg;
		MainEngine* m_mainEngine;
		pluginManager::PluginManager* m_pluginManager;
		fieldSet::FieldNavigator m_navigator;
		fieldSet::FieldSet* m_xmfFieldSet;
		fieldSet::FieldSet* m_imfFieldSet;
        std::deque<fieldSet::FieldSet*> dm_shdFieldSet;
		fieldSet::FieldSet* m_environment;
		dataManip::DataManip* m_dataManipRequest;
		dataManip::DataManip* m_dataManipResponse;
		dataManip::DataManip* m_dataManipNegative;
		dataManip::DataManip* m_dataManipCommand;
		dataManip::DataManip* m_dataManipEvent;
		msgConv::MessageConverter* m_inboundConverter;
		msgConv::MessageConverter* m_outboundConverter;
		msgConv::MessageConverter* outboundConverterRedirect;
		msgConv::FieldSetLoader* m_inboundLoader;
		msgConv::FieldSetLoader* m_outboundLoader;
		msgConv::FieldSetLoader* outboundLoaderRedirect;
		msgConv::FieldSetExtractor* m_inboundExtractor;
		msgConv::FieldSetExtractor* m_outboundExtractor;
		msgConv::FieldSetExtractor* outboundExtractorRedirect;
		mailboxInterface::MailboxIn* m_mbIn;
		mailboxInterface::MailboxOut* m_mbOut;
		TrxEngine* m_trxEngine;
		configBase::TagList m_selectedLibrarianTag;
		configBase::TagList m_selectedPluginManagerTag;
		configBase::Tag m_selectedXmfFieldSetTag;
		configBase::Tag m_selectedImfFieldSetTag;
        std::deque<configBase::Tag> dm_selectedShdFieldSetTag;
		configBase::Tag m_selectedInternalEnvironmentTag;
		configBase::Tag m_selectedDataManipRequestTag;
		configBase::Tag m_selectedDataManipResponseTag;
		configBase::Tag m_selectedDataManipNegativeTag;
		configBase::Tag m_selectedDataManipCommandTag;
		configBase::Tag m_selectedDataManipEventTag;
		configBase::Tag m_selectedInboundIso8583PropertiesTag;
		configBase::Tag m_selectedOutboundIso8583PropertiesTag;
		std::string m_mainXmlPath;
		std::string m_mainXmlName;
		std::string m_engineLabel;
		configBase::TagList m_librarianXml;
		configBase::TagList m_pluginManagerXml;
		configBase::TagList m_fieldSetXml;
		configBase::TagList m_dataManipXml;
		configBase::TagList m_iso8583PropertiesXml;
		typedef std::pair<std::string, std::string> FILE_PATH;
		typedef std::deque<FILE_PATH> FILE_LIST;
		FILE_LIST m_librarianXmlPath;
		FILE_LIST m_pluginManagerXmlPath;
		FILE_LIST m_fieldSetXmlPath;
		FILE_LIST m_dataManipXmlPath;
		FILE_LIST m_iso8583PropertiesXmlPath;
		configBase::Tag m_engineTag;
		configBase::TagList m_librarianTag;
		std::deque<std::string> m_librarianRefLabel;
		configBase::TagList m_pluginManagerTag;
		std::deque<std::string> m_pluginManagerRefLabel;
		configBase::Tag m_xmfFieldSetTag;
		std::string m_xmfFieldSetRefLabel;
		std::string m_xmfFieldSetSymbol;
		configBase::Tag m_imfFieldSetTag;
		std::string m_imfFieldSetRefLabel;
		std::string m_imfFieldSetSymbol;
        std::deque<configBase::Tag> dm_shdFieldSetTag;
        std::deque<std::string> dm_shdFieldSetRefLabel;
        std::deque<std::string> dm_shdFieldSetSymbol;
		configBase::Tag m_internalEnvironmentTag;
		std::string m_internalEnvironmentSymbol;
		configBase::Tag m_dataManipRequestTag;
		std::string m_dataManipRequestRefLabel;
		configBase::Tag m_dataManipResponseTag;
		std::string m_dataManipResponseRefLabel;
		configBase::Tag m_dataManipNegativeTag;
		std::string m_dataManipNegativeRefLabel;
		configBase::Tag m_dataManipCommandTag;
		std::string m_dataManipCommandRefLabel;
		configBase::Tag m_dataManipEventTag;
		std::string m_dataManipEventRefLabel;
		configBase::Tag m_converterTag;
		std::string m_inboundType;
		std::string m_outboundType;
		std::string outboundRedirectType;
		configBase::Tag m_inboundIso8583Property;
		configBase::Tag m_outboundIso8583Property;
		configBase::Tag m_inboundCustomExtractor;
		configBase::Tag m_outboundCustomExtractor;
		configBase::Tag m_inboundCustomLoader;
		configBase::Tag m_outboundCustomLoader;
		std::string m_inboundIso8583PropertyRefLabel;
		std::string m_outboundIso8583PropertyRefLabel;
		std::string m_inboundCustomExtractorRefLabel;
		std::string m_outboundCustomExtractorRefLabel;
		std::string m_inboundCustomLoaderRefLabel;
		std::string m_outboundCustomLoaderRefLabel;
		configBase::Tag m_trxEngineTag;
		std::string m_trxEngineRefLabel;
		configBase::Tag m_inputMailboxNameTag;
		std::string m_inputMailboxName;
		configBase::Tag m_dataManipTimeLogTag;
		std::string m_dataManipTimeLog;
		
		const std::string ISO8583_ID;
		const std::string QUERY_STRING_ID;
		const std::string SHC_ID;
		const std::string JSON_ID;
		const std::string CUSTOM_ID;
	};
}//namespace engine

