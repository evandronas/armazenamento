/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once


namespace msgConv
{
	class StandardInputConverter : public fieldSet::Field
	{
	public:
		StandardInputConverter( const std::string& a_data );
		StandardInputConverter( const char* a_data, unsigned int a_length );
		StandardInputConverter( const unsigned char* a_data, unsigned int a_length );
		StandardInputConverter( char a_data );
		StandardInputConverter( long a_data );
		StandardInputConverter( unsigned lond a_data );
		StandardInputConverter( int a_data );
		StandardInputConverter( unsigned int a_data );
		StandardInputConverter( short a_data );
		unsigned char* data( ) const;
		unsigned int length( ) const;
	};
}//namespace msgConv

