/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/shc_structs.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldAccess.hpp"


namespace msgConv
{
	class fistmv
	{
	public:
		fistmv( fieldSet::Field& a_field, const base::amount_t& a_data );
		fistmv( fieldSet::Field& a_field, const base::date_t& a_data );
		fistmv( fieldSet::Field& a_field, const base::bin_t& a_data );
		fistmv( fieldSet::Field& a_field, const base::seckey_t& a_data );
		fistmv( fieldSet::Field& a_field, const base::secdukpt_t& a_data );
		fistmv( fieldSet::FieldAccess& a_fieldAccess, const base::amount_t& a_data );
		fistmv( fieldSet::FieldAccess& a_fieldAccess, const base::date_t& a_data );
		fistmv( fieldSet::FieldAccess& a_fieldAccess, const base::bin_t& a_data );
		fistmv( fieldSet::FieldAccess& a_fieldAccess, const base::seckey_t& a_data );
		fistmv( fieldSet::FieldAccess& a_fieldAccess, const base::secdukpt_t& a_data );
	};
}//namespace msgConv

