/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "msgConv/FieldSetExtractor.hpp"


namespace msgConv
{
	class QueryStringBuilder : public FieldSetExtractor
	{
	public:
		QueryStringBuilder( );
		virtual ~QueryStringBuilder( );
		bool open( );
		void close( );
		unsigned int build( unsigned char* a_target, unsigned int targetLen );
		QueryStringBuilder& setAssignChar( char a_assignChar );
		QueryStringBuilder& setToken( char a_token );
	private:
		char m_token;
		char m_assignChar;
	};
}//namespace msgConv

