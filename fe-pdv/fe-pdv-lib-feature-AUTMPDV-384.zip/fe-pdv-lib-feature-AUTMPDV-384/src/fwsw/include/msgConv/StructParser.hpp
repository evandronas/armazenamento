/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <map>
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "msgConv/FieldSetLoader.hpp"
#include "msgConv/StructFieldProperties.hpp"


namespace msgConv
{
	class StructParser : public FieldSetLoader
	{
	public:
		StructParser( );
		virtual ~StructParser( );
		bool open( );
		void close( );
		bool addProperty( const StructFieldProperties& a_structFieldProperties );
		bool parse( const unsigned char* a_source, unsigned int a_sourceLen );
	private:
		typedef std::pair<fieldSet::FieldAccess, StructFieldProperties> PAIR;
		std::deque<PAIR> m_segmentsFields;
		typedef std::map<std::string, StructFieldProperties> MAP_PROP;
		MAP_PROP m_properties;
		size_t m_segmentSize;
	};
}//namespace msgConv

