/// JsonLightParser.h
/// Esta Classe implementa o Parse de uma Estrutura JSON, baseado no projeto JSMN (Jasmine)
/// AM 243.002 - Upgrade da Captura (FE-POS)
/// Histórico: 
/// 01.02.2019 – Renato de Camargo - Versao Inicial
#ifndef __JSONLIGHTPARSER_H_
#define __JSONLIGHTPARSER_H_
#include <stddef.h>

/*
#ifdef __cplusplus
extern "C" {
#endif
*/

/**
 * JSON type identifier. 
 *  Basic types are:
 * 	   Object
 * 	   Array
 * 	   String
 * 	   Other primitive: number, boolean (true/false) or null
 */
typedef enum 
{
	JSMN_UNDEFINED = 0,
	JSMN_OBJECT = 1,
	JSMN_ARRAY = 2,
	JSMN_STRING = 3,
	JSMN_PRIMITIVE = 4
} JasmineType;

enum JasmineError 
{
	/* Not enough tokens were provided */
	JSMN_ERROR_NOMEM = -1,
	
	/* Invalid character inside JSON string */
	JSMN_ERROR_INVAL = -2,
	
	/* The string is not a full JSON packet, more bytes expected */
	JSMN_ERROR_PART = -3
};

/**
 * JSON token description.
 * type		type (object, array, string etc.)
 * start	start position in JSON data string
 * end		end position in JSON data string
 */
typedef struct 
{
	JasmineType type;
	int start;
	int end;
	int size;
#ifdef JSMN_PARENT_LINKS
	int parent;
#endif
} JasmineToken;

/**
 * JSON parser. Contains an array of token blocks available. Also stores
 * the string being parsed now and current position in that string
 */
typedef struct 
{
	unsigned int pos;      /* offset in the JSON string */
	unsigned int tokNext;  /* next token to allocate */
	int 		 tokSuper; /* superior token node, e.g parent object or array */
} JasmineParser;

class JsonLightParser  
{
	public:
		JsonLightParser();
		
		~JsonLightParser();
				
		static JsonLightParser* GetInstance();
	
		/* Create JSON parser over an array of tokens */
		void JsonParserInit(JasmineParser *parser);
		
		/* JSON parser. It parses a JSON data string into and array of tokens, each describing a single JSON object */
		int JsonParse(JasmineParser *parser, const char *jsonString, size_t len, JasmineToken *tokens, unsigned int numTokens);

	private :
		static JsonLightParser* instance;
	
		/* Allocates a fresh unused token from the token pool */
		JasmineToken *AllocateToken(JasmineParser *parser, JasmineToken *tokensList, size_t numTokens);
		
		/* Fills token type and boundaries */
		void FillToken(JasmineToken *token, JasmineType type, int start, int end);
		
		/* Fills next available token with JSON primitive */
		int ParsePrimtive(JasmineParser *parser, const char *jsonString, size_t tamanho, JasmineToken *tokensList, size_t numTokens);

		int ParseString(JasmineParser *parser, const char *jsonString, size_t tamanho, JasmineToken *token, size_t num_tokens);
};
/*
#ifdef __cplusplus
}
#endif
*/

#endif /* __JSONLIGHTPARSER_H_ */
