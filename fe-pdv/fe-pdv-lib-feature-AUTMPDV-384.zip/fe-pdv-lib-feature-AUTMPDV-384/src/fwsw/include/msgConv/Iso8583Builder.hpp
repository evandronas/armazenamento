/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "fieldSet/ConstFieldAccess.hpp"
#include "msgConv/DataCoding.hpp"
#include "msgConv/FieldSetExtractor.hpp"
#include "msgConv/Iso8583Properties.hpp"


namespace msgConv
{
	class Iso8583Builder : public FieldSetExtractor
	{
	public:
		Iso8583Builder( );
		Iso8583Builder( const Iso8583Properties& a_iso8583Properties );
		virtual ~Iso8583Builder( );
		bool open( );
		void close( );
		unsigned int build( unsigned char* a_target, unsigned int targetLen );
		Iso8583Builder& setIso8583Properties( const Iso8583Properties& a_iso8583Properties );
	private:
		bool turnBitOn( unsigned char* a_bitmaps, unsigned int a_bitmapSize, unsigned int a_bitNum );
		unsigned int calculateSize( unsigned int a_numDigits, DataCoding a_dataCoding );
		bool convertFromAscii( std::string& a_output, const std::string& a_input, DataCoding a_dataCoding );
		bool convertFromHEX( std::string& a_output, const std::string& a_input, DataCoding a_dataCoding );
		Iso8583Properties m_iso8583Properties;
		bool initialiseIndexers( );
		const fieldSet::Field& getDataElement( unsigned int a_deNumber ) const;
		static const unsigned int m_deCount = 128;
		fieldSet::ConstFieldAccess m_dataElements[m_deCount];
		fieldSet::ConstFieldAccess m_saltAccess;
		fieldSet::ConstFieldAccess m_headerAccess;
		fieldSet::ConstFieldAccess m_msgTypeAccess;
		unsigned char* m_auxBuffer;
		unsigned int m_auxBufferLength;
	};
}//namespace msgConv

