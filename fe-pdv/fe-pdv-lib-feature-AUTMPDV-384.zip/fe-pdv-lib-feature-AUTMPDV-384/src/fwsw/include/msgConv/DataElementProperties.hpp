/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "msgConv/DataCoding.hpp"

namespace msgConv
{
	class DataElementProperties
	{
	public:
		DataElementProperties( unsigned int m_dataElementNumber );
		virtual ~DataElementProperties( );
		unsigned int dataElementNumber( ) const;
		unsigned int dataElementSize( ) const;
		bool isLVar( ) const;
		bool IsValid( ) const;
		DataCoding dataCoding( ) const;
		DataCoding lvarDataCoding( ) const;
		DataElementProperties& setDataType( DataCoding a_dataCoding );
		DataElementProperties& setLVarDataType( DataCoding a_dataCoding );
		DataElementProperties& enableLVar( bool a_isLVar );
		DataElementProperties& setDataElementSize( unsigned int a_dataElementSize );            
		DataElementProperties& SetValid( bool a_isValid );
	private:
		unsigned int m_dataElementNumber;
		DataCoding m_dataCoding;
		DataCoding m_lvarDataCoding;
		bool m_isLVar;
		unsigned int m_dataElementSize;
		bool m_isValid;
	};
}//namespace msgConv

