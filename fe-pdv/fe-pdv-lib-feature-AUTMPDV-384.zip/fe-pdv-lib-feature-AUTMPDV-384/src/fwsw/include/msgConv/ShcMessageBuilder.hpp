/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include "msgConv/FieldSetExtractor.hpp"
#include "msgConv/StructConverter.hpp"


namespace msgConv
{
	class ShcMessageBuilder : public FieldSetExtractor
	{
	public:
		ShcMessageBuilder( );
		virtual ~ShcMessageBuilder( );
		bool open( );
		void close( );
		unsigned int build( unsigned char* a_target, unsigned int a_targetLen );
	private:
		StructConverter m_converterStructShcMsg;
		StructConverter m_converterStructShcData;
		typedef std::pair<std::string, StructConverter> PAIR_SEG;
		std::deque<PAIR_SEG> m_segments;
		unsigned int buildShcData( unsigned char* a_target, unsigned int a_targetLen );
		unsigned int buildShcMsg( unsigned char* a_target, unsigned int a_targetLen );
		unsigned int buildSegments( unsigned char* a_target, unsigned int a_targetLen );
		unsigned char m_tempBuffer[65536];
	};
}//namespace msgConv

