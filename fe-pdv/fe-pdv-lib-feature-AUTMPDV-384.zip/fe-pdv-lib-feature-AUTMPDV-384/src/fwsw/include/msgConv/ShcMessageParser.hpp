/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include "fieldSet/FieldAccess.hpp"
#include "msgConv/FieldSetLoader.hpp"
#include "msgConv/StructConverter.hpp"


namespace msgConv
{
	class ShcMessageParser : public FieldSetLoader
	{
	public:
		ShcMessageParser( );
		virtual ~ShcMessageParser( );
		bool open( );
		void close( );
		bool parse( const unsigned char* a_source, unsigned int a_sourceLen );
	private:
		bool parseSegments( const unsigned char* a_source, unsigned int a_sourceLen );
		StructConverter m_converterStructShcMsg;
		StructConverter m_converterStructShcData;
		typedef std::pair<std::string, StructConverter> PAIR_SEG;
		std::deque<PAIR_SEG> m_segments;
		unsigned char m_tempBuffer[65536];
	};
}//namespace msgConv

