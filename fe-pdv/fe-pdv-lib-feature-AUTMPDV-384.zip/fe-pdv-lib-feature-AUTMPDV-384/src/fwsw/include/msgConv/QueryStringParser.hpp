/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "msgConv/FieldSetLoader.hpp"


namespace msgConv
{
	class QueryStringParser : public FieldSetLoader
	{
	public:
		QueryStringParser( );
		virtual ~QueryStringParser( );
		bool open( );
		void close( );
		bool parse( const unsigned char* a_source, unsigned int a_sourceLen );
		QueryStringParser& setAssignChar( char a_assignChar );
		QueryStringParser& setToken( char a_token );
	private:
		char m_token;
		char m_assignChar;
	};
}//namespace msgConv

