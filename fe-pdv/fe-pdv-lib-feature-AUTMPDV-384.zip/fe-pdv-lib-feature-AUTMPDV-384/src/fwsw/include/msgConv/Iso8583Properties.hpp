/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <vector>
#include "msgConv/DataCoding.hpp"
#include "msgConv/DataElementProperties.hpp"


namespace msgConv
{
	class Iso8583Properties
	{
	public:
		Iso8583Properties( );
		virtual ~Iso8583Properties( );
		Iso8583Properties& setHeaderSize( unsigned int a_headerSize );
		Iso8583Properties& setEnvSource( const std::string& a_envSource);
		Iso8583Properties& setHeaderDataType( DataCoding a_headerDataType );
		Iso8583Properties& setMessageTypeDataType( DataCoding a_messageTypeDataType );
		Iso8583Properties& setBitmapDataType( DataCoding a_bitmapsDataType );
		unsigned int headerSize( ) const;
		std::string envSource( ) const;
		DataCoding saltDataType( ) const;
		DataCoding headerDataType( ) const;
		DataCoding messageTypeDataType( ) const;
		DataCoding bitmapsDataType( ) const;
		const DataElementProperties& dataElementsProperties( unsigned int a_dataElementNumber ) const;
		DataElementProperties& dataElementsProperties( unsigned int a_dataElementNumber );
	private:
		static const unsigned int m_deCount = 128;
		unsigned int m_headerSize;
		std::string m_envSource;
		DataCoding m_saltDataType;
		DataCoding m_headerDataType;
		DataCoding m_messageTypeDataType;
		DataCoding m_bitmapsDataType;
		std::vector<DataElementProperties> m_dataElementsProperties;
	};
}//namespace msgConv

