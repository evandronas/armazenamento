/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once


namespace msgConv
{
	class TextConv
	{
	public:
		static bool asciiToByte( unsigned char& byte, const unsigned char a_ascii );
		static unsigned int asciiToEbcdic( unsigned char* a_ebcdic, unsigned int a_maxEbcdicLength, const unsigned char* a_ascii, unsigned int a_asciiLength );
		static unsigned int unicodeToEbcdic( unsigned char* a_ebcdic, unsigned int a_maxEbcdicLength, const unsigned char* a_unicode, unsigned int a_unicodeLength );
		static unsigned int ebcdicToAscii( unsigned char* a_ascii, unsigned int a_maxAsciiLength, const unsigned char* a_ebcdic, unsigned int a_ebcdicLength );
		static unsigned int ebcdicToUnicode( unsigned char* a_unicode, unsigned int a_maxUnicodeLength, const unsigned char* a_ebcdic, unsigned int a_ebcdicLength );
		static unsigned int hexToAscii( unsigned char* a_ascii, unsigned int a_asciiMaxLength, const unsigned char* a_hex, unsigned int a_hexLength );
		static unsigned int asciiToHex( unsigned char* a_hex, unsigned int a_hexMaxLength, const unsigned char* a_ascii, unsigned int a_asciiLength );
		static unsigned int ebcdicToHex( unsigned char* a_hex, unsigned int a_hexMaxLength, const unsigned char* a_ebcdic, unsigned int a_ebcdicLength );
		static unsigned int hexToEbcdic( unsigned char* a_ebcdic, unsigned int a_asciiMaxLength, const unsigned char* a_hex, unsigned int a_hexLength );
		static unsigned int bcdToHex( unsigned char* a_hex, unsigned int a_hexMaxLength, const unsigned char* a_bcd, unsigned int a_bcdLength );
		static unsigned int hexToBcd( unsigned char* a_bcd, unsigned int a_bcdMaxLength, const unsigned char* a_hex, unsigned int a_hexLength );
		static unsigned int bcdToAscii( unsigned char* a_ascii, unsigned int a_asciiMaxLength, const unsigned char* a_bcd, unsigned int a_bcdLength );
		static unsigned int asciiToBcd( unsigned char* a_bcd, unsigned int a_bcdMaxLength, const unsigned char* a_ascii, unsigned int a_asciiLength );
		static unsigned int BytesToHexAscii( unsigned char* a_hex, unsigned int a_hexLength, const unsigned char* a_bytes, unsigned int a_bytesMaxLength );
		static unsigned int HexAsciiToBytes( unsigned char* a_bytes, unsigned int a_bytesMaxLength, const unsigned char* a_hex, unsigned int a_hexLength );

	private:
		static unsigned char m_convTable[4][256];
		static const unsigned int m_ASCII2EBCDIC = 0;
		static const unsigned int m_EBCDIC2ASCII = 1;
		static const unsigned int m_UNICODE2EBCDIC = 2;
		static const unsigned int m_EBCDIC2UNICODE = 3;
	};
}//namespace msgConv

