/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "base/Identificable.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldSet.hpp"


namespace msgConv
{
	class FieldSetExtractor : public base::Identificable
	{
	public:
		FieldSetExtractor( );
		virtual ~FieldSetExtractor( );
		virtual bool open( ) = 0;
		virtual void close( ) = 0;
		virtual unsigned int build( unsigned char* a_target, unsigned int targetLen ) = 0;
		FieldSetExtractor& setFieldSet( fieldSet::FieldSet* a_fieldSet );
		fieldSet::Field& source( const std::string& a_label = "" );
		FieldSetExtractor& setHasError( bool a_isOn );
		bool hasError( ) const;
		FieldSetExtractor& setErrorMessage( const std::string& a_errorMessage );
		const std::string& errorMessage( ) const;
	private:
		fieldSet::FieldSet* m_fieldSet;
		std::string m_errorMessage;
		bool m_errorOn;
	};
}//namespace msgConv

