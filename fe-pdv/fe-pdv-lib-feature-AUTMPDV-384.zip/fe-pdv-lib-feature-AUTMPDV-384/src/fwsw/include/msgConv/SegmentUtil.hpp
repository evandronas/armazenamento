/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once

namespace msgConv
{
	class SegmentUtil
	{
	public:
		SegmentUtil( );
		virtual ~SegmentUtil( );
		void init( void* a_shcMsgPtr );
		void add( void* a_shcMsgPtr, const char* a_segmentName, const char* a_data, int a_datalen );
		int end( void* a_shcMsgPtr );
		int getSegment( const void* a_shcMsgPtr, const char* a_segmentName, char* a_buffer, int a_bufferLen );
	private:
	};
}//namespace msgConv

