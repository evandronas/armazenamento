/*
Copyright 2019 Rede S.A.

*********************** MODIFICACOES ************************
/ -------------------------------------------------------------------------------------------------
Autor    : Gustavo Silva Franco
Data     : 20/02/2019
Empresa  : Rede
Descricao: Vers�o Inicial
ID       : EAK 1359
/ -------------------------------------------------------------------------------------------------
Autor    : Gustavo Silva Franco
Data     : 21/02/2019
Empresa  : Rede
Descricao: Refatora��o da constru��o/leitura do JSON para ser em �rvore, com objetivo de ter menor menor tamanho em bytes
ID       : EAK 1419
/ -------------------------------------------------------------------------------------------------
Autor    : Renato de Camargo
Data     : 08.05.2019
Empresa  : Rede
Descricao: Implementacao do TPDU Header
ID       : AM 248.141
/ -------------------------------------------------------------------------------------------------
*/

#pragma once
#include "msgConv/FieldSetExtractor.hpp"

namespace msgConv
{
	class JsonBuilder : public FieldSetExtractor
	{
	public:
		JsonBuilder( );
		virtual ~JsonBuilder( );
		bool open( );
		void close( );
		unsigned int build( unsigned char* a_target, unsigned int targetLen );
		fieldSet::Field* FindKeyInFieldSet(fieldSet::Field*, char*);
	private:
		void LogField(fieldSet::Field* paramField );
		std::string jsonString;
	};
}//namespace msgConv

