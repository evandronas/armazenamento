/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <map>
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "msgConv/FieldSetExtractor.hpp"
#include "msgConv/StructFieldProperties.hpp"

namespace msgConv
{
	class StructConverter
	{
	public:
		StructConverter( );
		virtual ~StructConverter( );
		bool open( );
		void close( );
		unsigned int build( unsigned char* a_target, unsigned int targetLen );
		bool parse( const unsigned char* a_source, unsigned int a_sourceLen );
		void setFieldSet( fieldSet::Field* a_fieldSet );
		size_t structSize( ) const;
		const StructFieldProperties& findFieldProperty( const std::string& a_label );
		bool isOn( ) const;
		void turnOn( ) const;
		void turnOff( ) const;
	private:
		typedef std::pair<fieldSet::FieldAccess, StructFieldProperties> PAIR;
		std::deque<PAIR> m_segmentsFields;
		size_t m_structSize;
		fieldSet::Field* m_fieldSet;
		std::map<std::string, StructFieldProperties*> m_mapProperties;
	};
}//namespace msgConv

