/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "base/Identificable.hpp"
#include "fieldSet/Field.hpp"
#include "fieldSet/FieldSet.hpp"


namespace msgConv
{
	class FieldSetLoader : public base::Identificable
	{
	public:
		FieldSetLoader( );
		virtual ~FieldSetLoader( );
		virtual bool open( ) = 0;
		virtual void close( ) = 0;
		virtual bool parse( const unsigned char* a_source, unsigned int sourceLen ) = 0;
		FieldSetLoader& setFieldSet( fieldSet::FieldSet* a_fieldSet );
		fieldSet::Field& target( const std::string& a_label = "" );
		FieldSetLoader& setHasError( bool a_isOn );
		bool hasError( ) const;
		FieldSetLoader& setErrorMessage( const std::string& a_errorMessage );
		const std::string& errorMessage( ) const;
	private:
		fieldSet::FieldSet* m_fieldSet;
		std::string m_errorMessage;
		bool m_errorOn;
	};
}//namespace msgConv

