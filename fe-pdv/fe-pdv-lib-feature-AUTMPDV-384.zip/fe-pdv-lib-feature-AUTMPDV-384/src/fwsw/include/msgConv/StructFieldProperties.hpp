/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "msgConv/DataType.hpp"


namespace msgConv
{
	class StructFieldProperties
	{
	public:
		StructFieldProperties( );
		StructFieldProperties( DataType a_dataType, size_t a_fieldSize, size_t a_posIni );
		virtual ~StructFieldProperties( );
		DataType getDataType( ) const;
		size_t getSize( ) const;
		const std::string& label( ) const;
		void setPosIni( size_t a_posIni );
		size_t posIni( ) const;
	private:
		DataType     m_fieldDataType;
		size_t       m_fieldSize;
		size_t m_posIni;
	};
}//namespace msgConv

