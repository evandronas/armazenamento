/*
Copyright 2019 Rede S.A.

*********************** MODIFICACOES ************************
/ -------------------------------------------------------------------------------------------------
Autor    : Gustavo Silva Franco
Data     : 20/02/2019
Empresa  : Rede
Descricao: Vers�o Inicial
ID       : EAK 1359
/ -------------------------------------------------------------------------------------------------
Autor    : Gustavo Silva Franco
Data     : 21/02/2019
Empresa  : Rede
Descricao: Refatora��o da constru��o/leitura do JSON para ser em �rvore, com objetivo de ter menor menor tamanho em bytes
ID       : EAK 1419
/ -------------------------------------------------------------------------------------------------
*/

#pragma once
#include <deque>
#include "msgConv/FieldSetLoader.hpp"
#include "msgConv/JsonLightParser.hpp"

#define JSON_BINARY_FIELD_SIZE  2
#define JSON_FORMAT_LABEL       "format"
#define JSON_VALUE_LABEL        "value"

namespace msgConv
{
	class JsonParser : public FieldSetLoader
	{
	public:
		JsonParser( );
		virtual ~JsonParser( );
		bool open( );
		void close( );
		bool parse( const unsigned char* a_source, unsigned int a_sourceLen );

	private:
		fieldSet::Field* FindKeyInFieldSet(fieldSet::Field* field, char* wholeKey);
		void HandleBinaryField(char* objectLabel, const unsigned char* a_source, JasmineToken* tokens, std::string variablePath, int& currIndex);
		void RecursiveParse(const unsigned char* a_source, JasmineToken* tokens, int numberOfTokens, std::string variablePath, int& currIndex);
    	bool IsBinaryField(char* objectLabel, const unsigned char* a_source, JasmineToken* tokens, int& currIndex);
	};
}//namespace msgConv

