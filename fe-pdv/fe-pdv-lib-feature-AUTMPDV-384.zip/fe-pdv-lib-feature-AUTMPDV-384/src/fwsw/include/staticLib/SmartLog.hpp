/* Copyright 2019 Rede */
/*
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 31/10/2019
Empresa  : Rede
Descricao: Versao Inicial
ID       : ---------
*************************************************************
*/

#pragma once
#include <stdio.h>
#include <string.h>
#include <syslg.h>
#include "logger/SyslgWriter.hpp"
#include <stdarg.h>
#include "logger/Level.hpp"
#include "logger/DebugWriter.hpp"


namespace staticlib {

    #define MAX_BUFF_SIZE         16384
    #define LOG_MAX_PER_LINE      100
    #define HEADER_MAX_SIZE       50

    enum LogFile
	{
		AIX_LOGFILE = 0, 
		DEBUG_LOGFILE 
	};

    class SmartLog {
        public: 
            static void SmartSyslg(char* optionalHeader, char* msgToFormat, ...);
            static void SmartDebug(logger::Level dbgLvl, char* optionalHeader, char* msgToFormat, ...);
        private:
            static bool ValidateString(char* buffer);
            static void LogMultipleLines(LogFile logfile, char *header, char *formattedBuffer, logger::Level dbgLvl = logger::DEFAULT_LEVEL);
    };

}
