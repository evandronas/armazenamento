/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo de Souza
Data     : 23/08/2018
Empresa  : Rede
Descricao: Correcao tratamento criptograma de validacao do host
ID       : AM 231211
*************************************************************
*/

#pragma once
#include "dataManip/Command.hpp"
#include "cryptography/Crypto.hpp"

#define ALG_SHA1                        0x00000020
#define ALG_SHA256                      0x00000040
#define E_CRYPT_ERROR_SUCCESS           0x00000000L
#define E_CRYPT_INVALID_PAN_SIZE        0x00000200L
#define E_CRYPT_BUFFER_TOO_LARGE        0x00000201L
#define E_CRYPT_INVALID_BLOCK_SIZE      0x00000202L
#define E_CRYPT_INVALID_JAVA_METHOD     0x00000203L
#define E_CRYPT_INVALID_ALGORITHM       0x00000204L
#define E_CRYPT_INVALID_PIN_SIZE        0x00000205L
#define E_CRYPT_INVALID_HEX_VALUE       0x00000206L
#define E_CRYPT_INCOMPATIBLE_ALGORITHM  0x00000207L
#define E_CRYPT_MEMORY_ALLOC            0x00000208L

namespace cryptography
{
    class CryptoHASH : public cryptography::Crypto
    {
        public:

            CryptoHASH( );
            ~CryptoHASH( );
            void receiveMsg( fieldSet::FieldAccess &l_field );
            bool encriptyMsg( const char l_msg[ ] );
            bool debugEncripty( const char l_msg[ ] );
            
        private:

            bool initInput( );
            void printInput( const char l_msg[ ], long length );
            void sendInput( const char l_msg[ ], long length );
            void printOutput( );
            bool checkOutput( );
            void printInfoMsg( const std::string &l_msg );
            void setMsgLength( const long &length );
                        
            long ( *m_ptrDoHash )( int l_tpyeAlgoritm, const char *l_msgIn, size_t l_msgInLen, int l_convertEBCDIC, int l_convertHex, char *l_msgOut );
            void *m_ptrDynamicLoading;
            char m_OutputMsg[64];
            long m_CodError;
            bool m_Loaded;
        	long msgLength;
    };
}

