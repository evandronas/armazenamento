/*
Copyright 2021 REDE
*********************** MODIFICACOES ************************
Autor    : Joao Paulo F. Costa
Data     : 15/09/2021
Empresa  : Rede
Descricao: Sub-Adquirente
ID       : EVO1-323
*************************************************************
*/


#pragma once
#include "dataManip/Command.hpp"
#include "cryptography/Crypto.hpp"

namespace cryptography
{
    class CryptoDUKPT : public cryptography::Crypto
    {
        public:

            CryptoDUKPT( );
            ~CryptoDUKPT( );
            void setKeys( fieldSet::ConstFieldAccess &l_field );
            void setKeys( const std::string &l_ksn );
            void setKeys( const long &m_termBDK );
			/* JPFC - EVO1-323 - Inicio */
			void setKeys( fieldSet::ConstFieldAccess &l_field, const long &l_termBDK );
			/* JPFC - EVO1-323 - Fim */
            void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_prefix, const std::string &l_sufix );
            void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_sufix );
            void receiveMsg( fieldSet::FieldAccess &l_field );
            void receiveMsg( std::string &l_field );
            void receiveMsg( unsigned char *l_msg,  long &l_length );
            bool decriptyMsg( const std::string &l_msg );
            bool decriptyMsg( const unsigned char *l_msg, long l_length );
            bool decriptyMsgSized( const unsigned char *l_msg, long l_length );
            bool encriptyMsg( const std::string &l_msg );
            void changeMsgLength( const long &l_length );

        private:
            
            /* ==============================================================================
            Campo                   Tipo Tamanho    Detalhes
            ---------------------------------------------------------------------------------
            Header                  N    4          Acredito que enviado pelo security
            Command Code            A    2          Valor �M2�
            Mode Flag               N    2          Valor �00�
            Input Format Flag       N    1          Valor "0" (binary) / �1� (hex-encoded)
            Output Format Flag      N    1          Valor "0" (binary) / �1� (hex-encoded)
            Key Type                A    3          Valor �00B�
            Key                     A    16/33      Chave DES / �U� + Chave 3DES
            Message Length          H    4          Valor �0010�
            Encrypted Message       A    16         Valor criptografado enviado pelo terminal
            ============================================================================== */

            typedef struct typeInputDukptCommand
            {
               char header[ 4 ];
               char command_code[ 2 ];
               char mode_flag[ 2 ];
               char input_format_flag[ 1 ];
               char output_format_flag[ 1 ];
               char key_type[ 3 ];
               char key_schema[ 1 ];
               char bdk[32];
               char metadado[3];
               char ksn[20];
               char message_length[ 4 ];
            }
            INPUT_DUKPT_CMD; 

            typedef struct typeInputDukpt
            {
               INPUT_DUKPT_CMD command;
               char message[ 2048 ];
            }
            INPUT_DUKPT_MSG; 

            /* ==============================================================================
            Campo                   Tipo Tamanho    Detalhes
            ---------------------------------------------------------------------------------
            Header                  N    4          Respondido o mesmo que enviado
            Response Code           A    2          Valor �M3�
            Error Code              N    2          Valor �00� = OK
            Message Length          H    4          Valor �0010�
            Decrypted Message       N    16         Valor aberto
            ============================================================================== */

            typedef struct typeOutputCommand
            {
                char header[ 4 ];
                char response_code[ 2 ];
                char error_code[ 2 ];
                char message_length[ 4 ];
            }
            OUTPUT_CMD;

            typedef struct typeOutputMessage
            {
                OUTPUT_CMD command;
                char message[ 2048 ];
            }
            OUTPUT_MSG;

            INPUT_DUKPT_MSG m_InputMsg;
            OUTPUT_MSG m_OutputMsg;
            std::string m_termKSN;
            std::string m_termBDK;
            long m_msgLength;

            void initDecriptHex(  );
            void initDecriptBinary(  );
            void initEncriptHex(  );
            void fillInput( const std::string &l_msg );
            void fillInput( const unsigned char *l_msg, long l_length );
            void printInput( );
            void sendInput( );
            void printOutput( );
            void printOutput( const std::string &l_msg );
            bool checkOutput( );
            long sizeInputMsg( );
            long sizeOutputMsg( );
            void setMsgLength( const long &l_length );
    };
}
