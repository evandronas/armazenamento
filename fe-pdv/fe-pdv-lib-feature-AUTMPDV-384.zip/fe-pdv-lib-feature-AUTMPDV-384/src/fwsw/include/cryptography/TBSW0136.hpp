#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

namespace cryptography
{
    class TBSW0136 : public dbaccess::table
    {
        public:
            TBSW0136();
            TBSW0136( const std::string& whereClause );
            ~TBSW0136();

            void bind_columns();

            void set_ID_BDK( unsigned long a_ID_BDK );
            void set_COD_CRPA_CHAV_BDK( const std::string& a_COD_CRPA_CHAV_BDK );
            void set_COD_CHCK_VLUE( const std::string& a_COD_CHCK_VLUE );
            void set_DTH_ULT_ATLZ( dbm_datetime_t a_DTH_ULT_ATLZ );
            void set_COD_OPID_ULT_ATLZ( const std::string& a_COD_OPID_ULT_ATLZ );

            unsigned long get_ID_BDK() const;
            const std::string& get_COD_CRPA_CHAV_BDK() const;
            const std::string& get_COD_CHCK_VLUE() const;
            dbm_datetime_t get_DTH_ULT_ATLZ() const;
            const std::string& get_COD_OPID_ULT_ATLZ() const;

        private:
            unsigned long			m_ID_BDK;
            std::string				m_COD_CRPA_CHAV_BDK;
            std::string				m_COD_CHCK_VLUE;
            dbm_datetime_t			m_DTH_ULT_ATLZ;
            std::string				m_COD_OPID_ULT_ATLZ;

            int m_ID_BDK_pos;
            int m_COD_CRPA_CHAV_BDK_pos;
            int m_COD_CHCK_VLUE_pos;
            int m_DTH_ULT_ATLZ_pos;
            int m_COD_OPID_ULT_ATLZ_pos;
    };
} //namespace standardPlugins
