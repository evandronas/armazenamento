/* Copyright 2021 Rede
Autor : Andre Morishita
Empresa : Leega
*/

#pragma once
#include "dataManip/Command.hpp"
#include "cryptography/Crypto.hpp"

namespace cryptography
{

    /// CryptoDUKPTAES
    /// Classe responsavel pela criptografia da mensagem
    /// EF/ET: ET1
    /// Historico: [Data] - [Autor] - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    class CryptoDUKPTAES : public cryptography::Crypto
    {
        public:

            CryptoDUKPTAES( );
            ~CryptoDUKPTAES( );
            
            // metodos herdados - inicio
            void setKeys( fieldSet::ConstFieldAccess &l_field );
            void setKeys( const std::string &l_ksn );
            void setKeys( const long &l_id_bdk );
            void setKeys( fieldSet::ConstFieldAccess &l_field, const long &l_id_bdk );
            void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_prefix, const std::string &l_sufix );
            void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_sufix );
            void receiveMsg( fieldSet::FieldAccess &l_field );
            void receiveMsg( std::string &l_field );
            void receiveMsg( unsigned char *l_msg,  long &l_length );
            bool decriptyMsg( const std::string &l_msg );
            bool decriptyMsg( const unsigned char *l_msg, long l_length );
            bool encriptyMsg( const std::string &l_msg );
            // metodos herdados - fim
            
            bool DecriptyMsgSized( const unsigned char *message, long length );

        private:
            
            /* ==============================================================================
            Campo                   Tipo Tamanho    Detalhes
            ---------------------------------------------------------------------------------
            Header                  N    4          Header
            Command Code            A    2          Valor "M2"
            Mode Flag               N    2          Valor "00"
            Input Format Flag       N    1          Valor "0" (binary) / "1" (hex-encoded)
            Output Format Flag      N    1          Valor "0" (binary) / "1" (hex-encoded)
            Key Type                A    3          Valor �FFF - Key Block LMK
            Key                     A    129        Chave AES
            KSN Descriptor          N    3          Valor "000"
            KSN                     A    24         Valor enviado no header pelo terminal
            Message Length          H    4          Valor "0010"
            Encrypted Message       A    16         Valor criptografado enviado pelo terminal
            Delimiter               A    1          Valor "%"
            LMK ID                  N    2          Valor "01"
            ============================================================================== */

            typedef struct typeInputDukptCommand
            {
               char header[ 4 ];
               char commandCode[ 2 ];
               char modeFlag[ 2 ];
               char inputFormatFlag[ 1 ];
               char outputFormatFlag[ 1 ];
               char keyType[ 3 ];
            //    char keySchema[ 1 ];
               char bdk[129];
               char metadado[3];
               char ksn[24];
               char messageLength[ 4 ];
            }
            INPUT_DUKPT_CMD; 

            typedef struct typeInputDukpt
            {
               INPUT_DUKPT_CMD command;
               char message[ 2051 ]; // Incluindo 3 bytes 2048 para 2051 para armazenar o complento do comando, caso necessario
            }
            INPUT_DUKPT_MSG; 

            typedef struct typeInputDukptCommandComplement
            {
               char delimiter[ 1 ];
               char lmkIdentifier[ 2 ];
            }
            INPUT_DUKPT_CMD_COMP;

            /* ==============================================================================
            Campo                   Tipo Tamanho    Detalhes
            ---------------------------------------------------------------------------------
            Header                  N    4          Respondido o mesmo que enviado
            Response Code           A    2          Valor �M3�
            Error Code              N    2          Valor �00� = OK
            Message Length          H    4          Valor �0010�
            Decrypted Message       N    16         Valor aberto
            ============================================================================== */

            typedef struct typeOutputCommand
            {
                char header[ 4 ];
                char responseCode[ 2 ];
                char errorCode[ 2 ];
                char messageLength[ 4 ];
            }
            OUTPUT_CMD;

            typedef struct typeOutputMessage
            {
                OUTPUT_CMD command;
                char message[ 2048 ];
            }
            OUTPUT_MSG;

            INPUT_DUKPT_MSG inputMessage;
            INPUT_DUKPT_CMD_COMP inputMessageComp;
            OUTPUT_MSG outputMessage;
            std::string terminalKSN;
            std::string terminalBDK;
            long messageLength;

            void InitDecriptHex(  );
            void InitDecriptBinary(  );
            void InitEncriptHex(  );
            void FillInput( const std::string &message );
            void FillInput( const unsigned char *message, long length );
            void PrintInput( );
            void SendInput( );
            void PrintOutput( );
            void PrintOutput( const std::string &message );
            bool CheckOutput( );
            long SizeInputMsg( );
            long SizeInputMsgComp( );
            long SizeOutputMsg( );
            void setMsgLength( const long &length );
    };
}
