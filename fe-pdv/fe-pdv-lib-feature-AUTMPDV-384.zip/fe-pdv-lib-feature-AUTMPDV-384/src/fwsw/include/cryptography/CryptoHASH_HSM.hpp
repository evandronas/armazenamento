#pragma once
#include "dataManip/Command.hpp"
#include "cryptography/Crypto.hpp"

namespace cryptography
{
    class CryptoHASH_HSM : public cryptography::Crypto
    {
    public:

        CryptoHASH_HSM();
        ~CryptoHASH_HSM();
        bool generateHashMsg(const std::string &l_msg);
        void receiveMsg(std::string &l_field);

    private:

        /* ==============================================================================
        Campo                   Tipo Tamanho    Detalhes
        ---------------------------------------------------------------------------------
        Header                  N    4          Acredito que enviado pelo security
        Command Code            A    2          Valor GM
        Hash Identifier         N    2          Valor 06
                                                01 - SHA-1
                                                02 - MD5
                                                03 - ISO 10118-2
                                                05 - SHA-224
                                                06 - SHA-256
                                                07 - SHA-384
                                                08 - SHA-512
        Data length             N    5          Tamanho do campo a ser "HASHEADO"
        Message Data            n    B          Dado a ser "HASHEADO"
        End Message Delimiter   1    C          Presente se trailer
        Message Trailer         n    A          Opcional 32 caracteres
        ============================================================================== */

        typedef struct typeInputHashSHA256command
        {
            char header[4];
            char command_code[2];
            char hash_identifier[2];
            char message_length[5];
        }
        INPUT_HASH_CMD;

        typedef struct typeInputDukpt
        {
            INPUT_HASH_CMD command;
            char message[2048];
        }
        INPUT_HASH_MSG;

        /* ==============================================================================
        Campo                   Tipo Tamanho    Detalhes
        ---------------------------------------------------------------------------------
        Header                  N    4          Respondido o mesmo que enviado
        Response Code           A    2          Valor GN
        Error Code              A    2          Valor 00 = OK
                                                      "05" = Invalid Hash Identifier
                                                      "68" = Command Disabled
        Hash Value              n    B          Hash Result (length depends on the algorithm used).
        ============================================================================== */

        typedef struct typeOutputCommand
        {
            char header[4];
            char response_code[2];
            char error_code[2];
        }
        OUTPUT_CMD;

        typedef struct typeOutputMessage
        {
            OUTPUT_CMD command;
            char message[64];
        }
        OUTPUT_MSG;

        INPUT_HASH_MSG m_InputMsg;
        OUTPUT_MSG m_OutputMsg;
        std::string m_termKSN;
        std::string m_termBDK;
        long m_msgLength;

        void initEncriptHex();
        void fillInput(const std::string &l_msg);
        void fillInput(const unsigned char *l_msg, long l_length);
        void printInput();
        void sendInput();
        void printOutput();
        void printOutput(const std::string &l_msg);
        bool checkOutput();
        long sizeInputMsg();
        long sizeOutputMsg();
    };
}