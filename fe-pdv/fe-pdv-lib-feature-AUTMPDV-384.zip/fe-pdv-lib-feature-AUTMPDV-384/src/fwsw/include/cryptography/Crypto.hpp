/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo de Souza
Data     : 23/08/2018
Empresa  : Rede
Descricao: Correcao tratamento criptograma de validacao do host
ID       : AM 231211
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 08/01/2019
Empresa  : Rede
Descricao: Adicionando tratamento de situacao de erro no HSM na decriptografia
ID       : EAK 36
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 15/09/2021
Empresa  : Rede
Descricao: Sub-Adquirente
ID       : EVO1-323
*************************************************************
*/

#pragma once
#include "dataManip/Command.hpp"

namespace cryptography
{
    class Crypto
    {
        public:

            Crypto( );
            ~Crypto( );
            virtual void setKeys( fieldSet::ConstFieldAccess &l_field );
            virtual void setKeys( const std::string &l_ksn );
            virtual void setKeys( const long &l_id_bdk );
			/* JPFC - EVO1-323 - Inicio */
			virtual void setKeys( fieldSet::ConstFieldAccess &l_field, const long &l_id_bdk );
			/* JPFC - EVO1-323 - Fim */
            virtual void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_prefix, const std::string &l_sufix );
            virtual void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_sufix );
            virtual void receiveMsg( fieldSet::FieldAccess &l_field );
            virtual void receiveMsg( std::string &l_field );
            virtual void receiveMsg( unsigned char *l_msg,  long &l_length );
            virtual void receiveMsg( fieldSet::FieldAccess &field,  long &length );
            virtual bool decriptyMsg( const std::string &l_msg );
            virtual bool decriptyMsg( const unsigned char *l_msg, long l_length );
            virtual bool encriptyMsg( const std::string &l_msg );
            virtual bool encriptyMsg( const char l_msg[ ] );
            virtual bool debugEncripty( const std::string &l_msg );
            virtual void setMsgLength( const long &l_length );
            std::string selectTBSW0136( const long &l_id_bdk );
            std::string selectTBSW0167( const std::string &localCodIdChav );
			void SetDataCategory(const std::string &newCategory);
			std::string GetDataCategory();

            std::string dataCategory;

    };
}
