#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

namespace cryptography
{
    class TBSW0167 : public dbaccess::table
    {
        public:
            TBSW0167();
            TBSW0167( const std::string& whereClause );
            ~TBSW0167();

            void InitVar();
            void bind_columns();

            void SetCodIdChav( unsigned long localCodIdChav );
            void SetCodCrpaChav( const std::string& localCodCrpaChav );
            void SetCodChckVlue( const std::string& localCodChckVlue );
            void SetDthUltAtlz( dbm_datetime_t localDthUltAtlz );
            void SetCodOpidUltAtlz( const std::string& localCodOpidUltAtlz );

            const std::string& GetCodIdChav() const;
            const std::string& GetCodCrpaChav() const;
            const std::string& GetCodChckVlue() const;
            dbm_datetime_t GetDthUltAtlz() const;
            const std::string& GetCodOpidUltAtlz() const;

        private:
            std::string codIdChav;
            std::string codCrpaChav;
            std::string codChckVlue;
            dbm_datetime_t dthUltAtlz;
            std::string codOpidUltAtlz;

            enum fieldPosition {
                codIdChavPosicao = 1,
                codCrpaChavPosicao,
                codChckVluePosicao,
                dthUltAtlzPosicao,
                codOpidUltAtlzPosicao,
            };
    };
} //namespace cryptography
