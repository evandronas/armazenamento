/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo de Souza
Data     : 23/08/2018
Empresa  : Rede
Descricao: Correcao tratamento criptograma de validacao do host
ID       : AM 231211
*************************************************************
*/

#pragma once
#include "dataManip/Command.hpp"
#include "cryptography/Crypto.hpp"

namespace cryptography
{
    class Crypto3DES : public cryptography::Crypto
    {
        public:

            Crypto3DES( );
            ~Crypto3DES( );
            void setKeys( fieldSet::ConstFieldAccess &l_field );
            void setKeys( const long &l_key );
            void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_prefix, const std::string &l_sufix );
            void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_sufix );
            void receiveMsg( fieldSet::FieldAccess &l_field );
            void receiveMsg( std::string &l_field );
            void receiveMsg( fieldSet::FieldAccess &field,  long &length );
            bool decriptyMsg( const std::string &l_msg );
            bool encriptyMsg( const char l_msg[ ] );
            bool debugEncripty( const char l_msg[ ] );
            
        private:
            
            /* ==============================================================================
            Campo                   Tipo Tamanho    Detalhes
            ---------------------------------------------------------------------------------
            Header                  N    4          Acredito que enviado pelo security
            Command Code            A    2          Valor �M2�
            Mode Flag               N    2          Valor �00�
            Input Format Flag       N    1          Valor �1�
            Output Format Flag      N    1          Valor �1�
            Key Type                A    3          Valor �00B�
            Key                     A    16/33      Chave DES / �U� + Chave 3DES
            Key_Schema              A    1          Valor "U"
            Message Length          H    4          Valor �0010�
            Encrypted Message       A    16         Valor criptografado enviado pelo terminal
            ============================================================================== */

            typedef struct typeInput3DESCommand
            {
                char header[ 4 ];
                char command_code[ 2 ];
                char mode_flag[ 2 ];
                char input_format_flag[ 1 ];
                char output_format_flag[ 1 ];
                char key_type[ 3 ];
                char key_schema[ 1 ];
                char key[ 32 ];
                char message_length[ 4 ];
            }
            INPUT_3DES_CMD; 

            typedef struct typeInput3DESMessage
            {
                INPUT_3DES_CMD command;
                char message[ 16 ];
            }
            INPUT_3DES_MSG; 

            /* ==============================================================================
            Campo                   Tipo Tamanho    Detalhes
            ---------------------------------------------------------------------------------
            Header                  N    4          Respondido o mesmo que enviado
            Response Code           A    2          Valor �M3�
            Error Code              N    2          Valor �00� = OK
            Message Length          H    4          Valor �0010�
            Decrypted Message       N    16         Valor aberto
            ============================================================================== */

            typedef struct typeOutputCommand
            {
                char header[ 4 ];
                char response_code[ 2 ];
                char error_code[ 2 ];
                char message_length[ 4 ];
            }
            OUTPUT_CMD;

            typedef struct typeOutputMessage
            {
                OUTPUT_CMD command;
                char message[ 16 ];
            }
            OUTPUT_MSG;

            INPUT_3DES_MSG m_InputMsg;
            OUTPUT_MSG m_OutputMsg;
            std::string m_key;

            void initDecript(  );
            void initEncript(  );
            void initDebug( );
            void fillInput( const std::string &l_msg );
            void fillInput( const char l_msg[ ] );
            void printInput( );
            void sendInput( );
            void printOutput( );
            void printOutput( const std::string &l_msg );
            bool checkOutput( ); 
            long sizeInputMsg( );
            long sizeOutputMsg( );
    };
}
