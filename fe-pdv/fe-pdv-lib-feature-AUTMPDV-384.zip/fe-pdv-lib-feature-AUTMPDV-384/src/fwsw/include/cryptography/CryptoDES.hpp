#pragma once
#include "dataManip/Command.hpp"
#include "cryptography/Crypto.hpp"

namespace cryptography
{
    class CryptoDES : public cryptography::Crypto
    {
        public:

            CryptoDES( );
            ~CryptoDES( );
            void setKeys( fieldSet::ConstFieldAccess &l_field );
            void setKeys( const long &l_key );
            void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_prefix, const std::string &l_sufix );
            void receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_sufix );
            void receiveMsg( fieldSet::FieldAccess &l_field );
            void receiveMsg( std::string &l_field );
            bool decriptyMsg( const std::string &l_msg );
            
        private:
            
            /* ==============================================================================
            Campo                   Tipo Tamanho    Detalhes
            ---------------------------------------------------------------------------------
            Header                  N    4          Acredito que enviado pelo security
            Command Code            A    2          Valor �M2�
            Mode Flag               N    2          Valor �00�
            Input Format Flag       N    1          Valor �1�
            Output Format Flag      N    1          Valor �1�
            Key Type                A    3          Valor �00B�
            Key                     A    16/33      Chave DES / �U� + Chave 3DES
            Message Length          H    4          Valor �0010�
            Encrypted Message       A    16         Valor criptografado enviado pelo terminal
            ============================================================================== */

            typedef struct typeInputDESCommand
            {
                char header[ 4 ];
                char command_code[ 2 ];
                char mode_flag[ 2 ];
                char input_format_flag[ 1 ];
                char output_format_flag[ 1 ];
                char key_type[ 3 ];
                char key[ 16 ];
                char message_length[ 4 ];
            }
            INPUT_DES_CMD; 

            typedef struct typeInputDESMessage
            {
                INPUT_DES_CMD command;
                char message[ 16 ];
            }
            INPUT_DES_MSG; 

            /* ==============================================================================
            Campo                   Tipo Tamanho    Detalhes
            ---------------------------------------------------------------------------------
            Header                  N    4          Respondido o mesmo que enviado
            Response Code           A    2          Valor �M3�
            Error Code              N    2          Valor �00� = OK
            Message Length          H    4          Valor �0010�
            Decrypted Message       N    16         Valor aberto
            ============================================================================== */

            typedef struct typeOutputCommand
            {
                char header[ 4 ];
                char response_code[ 2 ];
                char error_code[ 2 ];
                char message_length[ 4 ];
            }
            OUTPUT_CMD;

            typedef struct typeOutputMessage
            {
                OUTPUT_CMD command;
                char message[ 16 ];
            }
            OUTPUT_MSG;

            INPUT_DES_MSG m_InputMsg;
            OUTPUT_MSG m_OutputMsg;
            std::string m_key;

            void initInput(  );
            void fillInput( const std::string &l_msg );
            void printInput( );
            void sendInput( );
            void printOutput( );
            void printOutput( const std::string &l_msg );
            bool checkOutput( );
            long sizeInputMsg( );
            long sizeOutputMsg( );
    };
}
