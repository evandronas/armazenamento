/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <map>
#include <string>
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"


namespace dataManip
{
	class SwitchCase : public Command
	{
	public:
		SwitchCase( );
		SwitchCase( const SwitchCase& a_orig );
		virtual ~SwitchCase( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		SwitchCase& setCompareFieldPath( const std::string& a_path );
		Command* clone( ) const;
	private:
		void clear( );
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_compareField;
		std::string m_compareFieldPath;
		typedef std::map<std::string, Command*> CASE_MAP;
		typedef std::pair<std::string, Command*> CASE_PAIR;
		typedef std::pair<CASE_MAP::iterator, bool> CASE_RET;
		CASE_MAP m_cases;
		Command* m_cmdDefault;
		configBase::Tag m_tag;
	};
}//namespace dataManip

