/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/Identificable.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "pluginManager/PluginManager.hpp"


namespace dataManip
{
	class Command : public base::Identificable
	{
	public:
		Command( );
		virtual ~Command( );
		virtual bool init( ) = 0;
		virtual void finish( ) = 0;
		virtual int execute( bool& a_stop ) = 0;
		fieldSet::Field& navigate( const std::string& a_fieldPath );
		const fieldSet::FieldNavigator& navigator( ) const;
		Command& setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator );
		const pluginManager::PluginManager* pluginManager( ) const;
		Command& setPluginManager( const pluginManager::PluginManager* a_pluginManager );
		Command& enableWarning( bool a_isOn );
		Command& enableError( bool a_isOn );
		Command& setWarningMessage( const std::string& a_warningMessage );
		Command& setErrorMessage( const std::string& a_errorMessage );
		Command& ref( );
		const Command& constRef( ) const;
		virtual Command* clone( ) const = 0;
		const std::string& warningMessage( ) const;
		const std::string& errorMessage( ) const;
		bool warningOn( ) const;
		bool errorOn( ) const;
		void setProcessingUSecs( long a_processingUSecs );
		long processingUSecs( ) const;
		void setInitUSecs( long a_initUSecs );
		long initUSecs( ) const;
	private:
		fieldSet::FieldNavigator m_navigator;
		const pluginManager::PluginManager* m_pluginManager;
		bool m_warningOn;
		bool m_errorOn;
		std::string m_warningMessage;
		std::string m_errorMessage;
		long m_processingUSecs;
		long m_initUSecs;
	};
}//namespace dataManip

