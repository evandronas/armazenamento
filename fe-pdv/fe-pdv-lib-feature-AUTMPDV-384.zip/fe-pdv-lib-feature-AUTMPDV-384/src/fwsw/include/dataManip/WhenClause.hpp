/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/Identificable.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "fieldSet/FieldSet.hpp"


namespace dataManip
{
	class WhenClause : public base::Identificable
	{
	public:
		WhenClause( );
		virtual ~WhenClause( );
		virtual bool init( ) = 0;
		virtual void finish( ) = 0;
		virtual bool goAhead( ) const = 0;
		const fieldSet::Field& navigate( const std::string& a_fieldPath );
		WhenClause& setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator );
		const fieldSet::FieldNavigator& navigator( ) const;
		virtual WhenClause* clone( ) const = 0;
		const std::string& warningMessage( ) const;
		const std::string& errorMessage( ) const;
		bool warningOn( ) const;
		bool errorOn( ) const;
		WhenClause& enableWarning( bool a_isOn );
		WhenClause& enableError( bool a_isOn );
		WhenClause& setWarningMessage( const std::string& a_warningMessage );
		WhenClause& setErrorMessage( const std::string& a_errorMessage );
		void setProcessingUSecs( long a_processingUSecs );
		long processingUSecs( ) const;
		void setInitUSecs( long a_initUSecs );
		long initUSecs( ) const;
	private:
		fieldSet::FieldNavigator m_navigator;
		bool m_warningOn;
		bool m_errorOn;
		std::string m_warningMessage;
		std::string m_errorMessage;
		long m_processingUSecs;
		long m_initUSecs;
	};
}//namespace dataManip

