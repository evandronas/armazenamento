/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <ctime>
#include <deque>
#include <string>
#include <utility>
#include "configBase/TagList.hpp"
#include "dataManip/Command.hpp"
#include "dataManip/DataManip.hpp"


namespace dataManip
{
	class ConditionalBlock : public Command
	{
	public:
		ConditionalBlock( size_t a_depth );
		ConditionalBlock( const ConditionalBlock& a_orig );
		virtual ~ConditionalBlock( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		Command* clone( ) const;
	private:
		void clear( );
		bool startConfiguration( const configBase::Tag* a_tag );
		bool loadBlock( const configBase::Tag& a_tag );
		bool timevalSubtract( struct timeval *a_result, struct timeval *a_t2, struct timeval *a_t1 );
		typedef std::pair<WhenClause*, DataManip> BLOCK;
		typedef std::deque<BLOCK*> BLOCK_LIST;
		BLOCK_LIST m_blocks;
		configBase::Tag m_tagIf;
		configBase::TagList m_tagListElseIf;
		configBase::TagList m_tagListElse;
		size_t m_depth;
	};
}//namespace dataManip

