/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include <map>
#include <string>
#include <utility>
#include "configBase/DOMTreatment.hpp"
#include "configBase/TagList.hpp"
#include "configBase/XMLParseErrorHandler.hpp"
#include "dataManip/Command.hpp"
#include "dataManip/DataManip.hpp"
#include "logger/Logger.hpp"


namespace dataManip
{
	class Call : public Command
	{
	public:
		Call( size_t a_depth );
		virtual ~Call( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		Command* clone( ) const;
		
		static void clearTags( );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		void reportXmlErrors( const configBase::XMLParseErrorHandler::ERRMSGS& a_errors );
		DataManip* m_dataManip;
		std::string m_xmlFullName;
		std::string m_referenceLabel;
		logger::Logger* m_logger;
		configBase::TagList m_targetFieldPath;
		size_t m_depth;
		
		typedef std::map<std::string,configBase::Tag> TP_MAP;
		typedef std::pair<std::string,configBase::Tag> TP_PAIR;
		
		static TP_MAP m_mapXmlFile;
	};
}//namespace dataManip

