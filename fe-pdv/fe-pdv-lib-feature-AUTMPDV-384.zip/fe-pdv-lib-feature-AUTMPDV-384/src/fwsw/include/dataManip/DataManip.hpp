/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 06/05/2019
Empresa  : Rede
Descricao: Adicionando controle para dropar transa��o e refazer conex�o dbm no caso de timeout com o banco
ID       : AM 248.335
*************************************************************
*/

#pragma once
#include <ctime>
#include <deque>
#include "dataManip/CommandComparator.hpp"
#include "dataManip/CommandToCondition.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "fieldSet/FieldSet.hpp"
#include "logger/Logger.hpp"

namespace dataManip
{
	class DataManip : public Command
	{
	public:
		typedef std::deque<std::string> ERR_VECTOR;
		DataManip( );
		virtual ~DataManip( );
		DataManip& setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator );
		const fieldSet::FieldNavigator& fieldNavigator( ) const;
		bool init( );
		void finish( );
		int execute( );
		int execute( bool &a_stop );
		Command* clone( ) const;
		DataManip& clear( );
		bool addCommand( unsigned int a_sequence, const Command& a_command, const WhenClause& a_whenClause, bool a_stopCommand = false );
		bool addCommand( unsigned int a_sequence, Command* a_command, WhenClause* a_whenClause, bool a_stopCommand );
		unsigned int commandCount( ) const;
		unsigned int whenClauseCount( ) const;
		const Command& command( unsigned int a_commandIndex ) const;
		const WhenClause& whenClause( unsigned int a_commandIndex ) const;
		const Command& stopCommand( ) const;
		const Command& lastCommand( ) const;
		bool stopped( ) const;
		const ERR_VECTOR& getStartErrors( ) const;
		const ERR_VECTOR& getExecuteWarnings( ) const;
		const ERR_VECTOR& getExecuteErrors( ) const;
		fieldSet::FieldSet& localFields( );
		int referenceCount( ) const;
		void incReference( );
		void decReference( );
		static void enableTimeLogOn( bool a_timeLogOn );
		static bool GetDbDropTrx();
		static void SetDbDropTrx(bool newVal);

	private:
		bool timevalSubtract( struct timeval *a_result, struct timeval *a_t2, struct timeval *a_t1 );
		typedef std::deque<dataManip::CommandToCondition> CMD_VECTOR;
		CMD_VECTOR m_commands;
		ERR_VECTOR m_initErrors;
		ERR_VECTOR m_executeWarnings;
		ERR_VECTOR m_executeErrors;
		fieldSet::FieldNavigator m_fieldNavigator;
		bool m_initialised;
		CommandComparator m_commandComparator;
		bool m_stopped;
		Command* m_stopCommand;
		Command* m_lastCommand;
		logger::Logger* m_logger;
		fieldSet::FieldSet m_localFields;
		int m_referenceCounter;
		static bool m_timeLogOn;
		
		static bool dbDropTrx;
	};
}//namespace dataManip

