/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#include <ist_argv0.h>
#include "base/GenException.hpp"
#include "logger/Logger.hpp"


namespace logger
{
	Logger::Logger( )
	{
		m_writerList.clear( );
		m_Initialized = false;
	}
	Logger::~Logger( )
	{
		if ( m_Initialized == true )
		for ( unsigned int it = 0; it < m_writerList.size( ); it++ )
		m_writerList[it]->close( );
	}
	void Logger::addWriter( Writer* a_writer )
	{
		base::genAssert( !m_Initialized, __FUNCTION__, "Log initialised already" );
		m_writerList.push_back( a_writer );
	}
	void Logger::init( )
	{
		if ( (
		m_Initialized == false ) &&( argv0 != NULL ) )
		{
			createWriters( );
			for ( unsigned int it = 0; it < m_writerList.size( ); it++ )
			m_writerList[it]->open( );
			m_Initialized = true;
		}
	}
	void Logger::createWriters( )
	{
	}
	void Logger::print( Level a_level, const char* a_msg, const int a_length )
	{
		for ( unsigned int it = 0; it < m_writerList.size( ); it++ )
		m_writerList[it]->write( a_level, a_msg, a_length );
	}
	void Logger::print( Level a_level, const char* a_msg )
	{
		for ( unsigned int it = 0; it < m_writerList.size( ); it++ )
		m_writerList[it]->write( a_level, a_msg );
	}
	void Logger::print( Level a_level, const std::string& a_msg )
	{
		print( a_level, a_msg.data( ), a_msg.length( ) );
	}
}

