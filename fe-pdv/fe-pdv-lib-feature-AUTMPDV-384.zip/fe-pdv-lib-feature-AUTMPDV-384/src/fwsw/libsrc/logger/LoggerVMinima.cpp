#include "logger/LoggerVMinima.hpp"
#include "logger/VMinimaWriter.hpp"

namespace logger
{
    LoggerVMinima* LoggerVMinima::m_instance = 0;
    LoggerVMinima::LoggerVMinima( )
    {
    }
    LoggerVMinima::~LoggerVMinima( )
    {
    }
    LoggerVMinima* LoggerVMinima::getInstance( )
    {
        if ( !m_instance )
        m_instance = new LoggerVMinima( );
        return m_instance;
    }
    void LoggerVMinima::createWriters( )
    {
        addWriter( VMinimaWriter::getInstance( ) );
    }
}
