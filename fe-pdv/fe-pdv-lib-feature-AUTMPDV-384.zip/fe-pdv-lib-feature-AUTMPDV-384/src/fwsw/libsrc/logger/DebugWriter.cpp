/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 07/11/2018
Empresa  : Rede
Descricao: Modifica��es para permitir controle do n�vel de log por par�metro
ID       : AM 237648
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 03/02/2021
Empresa  : Rede
Descricao: EAK-5456 - Ping of Death
ID       : AM282751
*************************************************************
*/
#pragma once
#include <debug.h>
#include <ist_argv0.h>
#include <ist_otrace.h>
#include <string>
#include <cstring>
#include "logger/DebugWriter.hpp"
#include "configBase/ConfigBase.hpp"
#include <iostream>

namespace logger
{
	DebugWriter* DebugWriter::m_instance = 0;
	bool DebugWriter::m_opened = false;
	DebugWriter::DebugWriter( )
	{
		m_init_level = LEVEL_NONE;		
		snprintf( m_typeAcronym, sizeof m_typeAcronym, "GEN" );
	}
	DebugWriter::~DebugWriter( )
	{
	}
	DebugWriter* DebugWriter::getInstance( )
	{
		if ( !m_instance )
			m_instance = new DebugWriter( );
		return m_instance;
	}
	void DebugWriter::open( )
	{
		if ( !DebugWriter::m_opened )
		{
			bool l_findLevel = false;
			std::string l_param = "";
			char l_param_buffer[1024];
			char* l_token = NULL;
			
			if( configBase::ConfigBase::getInstance()->findFirst( "fwsw", l_param ) )
			{
				for( ;; )
				{
					strncpy(l_param_buffer, l_param.c_str(), sizeof(l_param_buffer));
					
					l_token = strtok(l_param_buffer, " ");
					
					if( l_token && !strcmp( l_token, argv0 ) )
					{
						if ( l_token = strtok(NULL, " ") ) //get debug level parameter
						{
							l_findLevel = true;
							if ( !strcmp(l_token, "DEBUG") )
								m_init_level = LEVEL_DEBUG;
							else if ( !strcmp(l_token, "INFO") )
								m_init_level = LEVEL_INFO;
							else if ( !strcmp(l_token, "WARNING") )
								m_init_level = LEVEL_WARNING;				
							else if ( !strcmp(l_token, "ERROR") )
								m_init_level = LEVEL_ERROR;				
							else if ( !strcmp(l_token, "FATAL") )
								m_init_level = LEVEL_FATAL;
							else
								m_init_level = LEVEL_NONE;
						}
						
						l_token = strtok (NULL, " "); //skip log file name parameter
						
						if ( l_token = strtok (NULL, " ") ) //get debug file name parameter
						{
							std::string localClearLogName = (const char*)l_token;
							size_t localPos = localClearLogName.find( "debug/" );
							if ( localPos != std::string::npos )
							{
								localClearLogName.erase( localPos, 6 );
							}
							localPos = localClearLogName.find( ".debug" );
							if ( localPos != std::string::npos )
							{
								localClearLogName.erase( localPos, 6 );
							}
							char localBuffer[1024];
							strcpy( localBuffer, localClearLogName.c_str( ) );
							OTraceOn( localBuffer );	
							ist_otrace_set(localBuffer, m_init_level);
							DebugWriter::m_opened = true;
							return;
						}					
					}

					if( !configBase::ConfigBase::getInstance()->findNext( l_param ) )
						break;
				}
			}
	
			OTraceOn( argv0 );	
			if( l_findLevel )
				ist_otrace_set(argv0, m_init_level);

			DebugWriter::m_opened = true;
		}
	}
	void DebugWriter::setTypeAcronym( const char* a_acronym )
	{
		snprintf( m_typeAcronym, sizeof m_typeAcronym, "%s", a_acronym );
	}
	void DebugWriter::write( Level a_level, const char* a_msg, const int a_length )
	{
		static char l_fullMessage[4096];
		switch ( a_level )
		{
			case LEVEL_FATAL:
			snprintf( l_fullMessage, sizeof l_fullMessage, "F-%s%s\n", m_typeAcronym, a_msg );
			OTraceFatal( l_fullMessage );
			break;
			case LEVEL_ERROR:
			snprintf( l_fullMessage, sizeof l_fullMessage, "E-%s%s\n", m_typeAcronym, a_msg );
			OTraceError( l_fullMessage );
			break;
			case LEVEL_WARNING:
			snprintf( l_fullMessage, sizeof l_fullMessage, "W-%s%s\n", m_typeAcronym, a_msg );
			OTraceWarning( l_fullMessage );
			break;
			case LEVEL_INFO:
			snprintf( l_fullMessage, sizeof l_fullMessage, "I-%s%s\n", m_typeAcronym, a_msg );
			OTraceInfo( l_fullMessage );
			break;
			case LEVEL_DUMP:
			snprintf( l_fullMessage, sizeof l_fullMessage, "U-%s%s\n", m_typeAcronym, a_msg );
			// Imprimindo como Info para manter o header com datetime
			if ( ist_otrace_get_level() >= 6 )
				/* EAK-5456 - JPFC - Inicio */
				OTraceInfo("%s", l_fullMessage );
				/* EAK-5456 - JPFC - Fim */
			break;
			case LEVEL_DEBUG:
			snprintf( l_fullMessage, sizeof l_fullMessage, "D-%s%s\n", m_typeAcronym, a_msg );
			OTraceDebug( l_fullMessage );
			break;
			case LEVEL_ALWAYS:
			snprintf( l_fullMessage, sizeof l_fullMessage, "A-%s%s\n", m_typeAcronym, a_msg );
			debugts( l_fullMessage );
			break;
			default:
			break;
		}
	}
	void DebugWriter::write( Level a_level, const char* a_msg )
	{
		static char l_fullMessage[4096];
		switch ( a_level )
		{
			case LEVEL_FATAL:
			snprintf( l_fullMessage, sizeof l_fullMessage, "F-%s%s\n", m_typeAcronym, a_msg );
			OTraceFatal( l_fullMessage );
			break;
			case LEVEL_ERROR:
			snprintf( l_fullMessage, sizeof l_fullMessage, "E-%s%s\n", m_typeAcronym, a_msg );
			OTraceError( l_fullMessage );
			break;
			case LEVEL_WARNING:
			snprintf( l_fullMessage, sizeof l_fullMessage, "W-%s%s\n", m_typeAcronym, a_msg );
			OTraceWarning( l_fullMessage );
			break;
			case LEVEL_INFO:
			snprintf( l_fullMessage, sizeof l_fullMessage, "I-%s%s\n", m_typeAcronym, a_msg );
			OTraceInfo( l_fullMessage );
			break;
			case LEVEL_DUMP:
			snprintf( l_fullMessage, sizeof l_fullMessage, "U-%s%s\n", m_typeAcronym, a_msg );
			// Imprimindo como Info para manter o header com datetime
			if ( ist_otrace_get_level() >= 6 )
				/* EAK-5456 - JPFC - Inicio */
				OTraceInfo("%s", l_fullMessage );
				/* EAK-5456 - JPFC - Fim */
			break;
			case LEVEL_DEBUG:
			snprintf( l_fullMessage, sizeof l_fullMessage, "D-%s%s\n", m_typeAcronym, a_msg );
			OTraceDebug( l_fullMessage );
			break;
            case LEVEL_ALWAYS:
            snprintf( l_fullMessage, sizeof l_fullMessage, "A-%s%s\n", m_typeAcronym, a_msg );
            debugts( l_fullMessage );
            break;
			default:
			break;
		}
	}
	void DebugWriter::close( )
	{
		OTraceOff( );
	}
}

