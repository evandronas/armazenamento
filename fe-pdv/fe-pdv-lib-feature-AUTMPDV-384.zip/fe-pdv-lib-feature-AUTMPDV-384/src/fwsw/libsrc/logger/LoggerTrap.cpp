#include "logger/LoggerTrap.hpp"
#include "logger/TrapWriter.hpp"

namespace logger
{
    LoggerTrap* LoggerTrap::m_instance = 0;
    LoggerTrap::LoggerTrap( )
    {
    }
    LoggerTrap::~LoggerTrap( )
    {
    }
    LoggerTrap* LoggerTrap::getInstance( )
    {
        if ( !m_instance )
        m_instance = new LoggerTrap( );
        return m_instance;
    }
    void LoggerTrap::createWriters( )
    {
        addWriter( TrapWriter::getInstance( ) );
    }
}
