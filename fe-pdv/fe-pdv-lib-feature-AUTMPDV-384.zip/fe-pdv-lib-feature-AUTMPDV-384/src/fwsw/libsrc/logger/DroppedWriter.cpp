/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

/*
Copyright 2018 REDE
*********************** MODIFICA��ES ************************
Autor    : Fabio Mazzer
Data     : 04/07/2018
Empresa  : Rede
Descri��o: Modifica��o do log para retirar o nome do arquivo e incluir a data
*************************************************************
*/


#include <ist_argv0.h>
#include <ist_trace.h>
#include <oasisenv.h>
#include <stdlib.h>
#include "logger/DroppedWriter.hpp"
#include <string>
#include <cstring>

namespace logger
{
	DroppedWriter* DroppedWriter::m_instance = 0;
	DroppedWriter::DroppedWriter( )
	{
		m_fileName.clear( );
	}
	DroppedWriter::~DroppedWriter( )
	{
	}
	DroppedWriter* DroppedWriter::getInstance( )
	{
		if ( !m_instance )
		m_instance = new DroppedWriter( );
		return m_instance;
	}
	void DroppedWriter::open( )
	{
		if ( m_fileName.length( ) > 0 )
		{
			return;
		}
		char* l_path = getenv( OLOGDIR_ENV );
		if ( l_path != NULL )
		{
			m_fileName += l_path;
			m_fileName += "/sys/";
		}
		m_fileName += argv0;
		m_fileName += "-dropped.log";
	}
	void DroppedWriter::write( Level a_level, const char* a_msg, const int a_length )
	{
		if ( a_level == LEVEL_DROPPED )
		{
			time_t nowRawTime;
			struct tm * nowTimeInfo;
			char nowTimeAscii[128];
			
			memset(nowTimeAscii, 0, sizeof nowTimeAscii );
			time ( &nowRawTime );
			nowTimeInfo = localtime ( &nowRawTime );
		
			snprintf(
				nowTimeAscii,
				sizeof nowTimeAscii,
				"%04d.%02d.%02d %02d:%02d:%02d ",
				nowTimeInfo->tm_year + 1900,
				nowTimeInfo->tm_mon + 1,
				nowTimeInfo->tm_mday,
				nowTimeInfo->tm_hour,
				nowTimeInfo->tm_min,
				nowTimeInfo->tm_sec
			);

			ist_trace_set_file( m_fileName.c_str( ) );
            char* l_path = getenv( OLOGDIR_ENV );
			
			int msgLenght = a_length;
			
			
			if (strlen(a_msg) < a_length)
			{
				msgLenght = strlen(a_msg);
			}
			
			ist_trace_output_direct( nowTimeAscii, strlen(nowTimeAscii) );
			ist_trace_output_direct( a_msg, msgLenght );
		}
	}
	void DroppedWriter::write( Level a_level, const char* a_msg )
	{
		if ( a_level == LEVEL_DROPPED )
		{

			time_t nowRawTime;
			struct tm * nowTimeInfo;
			char nowTimeAscii[128];
			
			memset(nowTimeAscii, 0, sizeof nowTimeAscii );
			time ( &nowRawTime );
			nowTimeInfo = localtime ( &nowRawTime );
		
			snprintf(
				nowTimeAscii,
				sizeof nowTimeAscii,
				"%04d.%02d.%02d %02d:%02d:%02d ",
				nowTimeInfo->tm_year + 1900,
				nowTimeInfo->tm_mon + 1,
				nowTimeInfo->tm_mday,
				nowTimeInfo->tm_hour,
				nowTimeInfo->tm_min,
				nowTimeInfo->tm_sec
			);

	
			ist_trace_set_file( m_fileName.c_str( ) );
            char* l_path = getenv( OLOGDIR_ENV );

			ist_trace_output_direct( nowTimeAscii, strlen(nowTimeAscii) );
			ist_trace_output_direct( a_msg, strlen(a_msg) );
		}
	}
	void DroppedWriter::close( )
	{
		m_fileName.clear( );
		ist_trace_set_file( "" );
	}
}

