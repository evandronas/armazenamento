/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#include "logger/DebugWriter.hpp"
#include "logger/LoggerAcqSrv.hpp"
#include "logger/SyslgWriter.hpp"
#include "logger/TraceWriter.hpp"


namespace logger
{
	LoggerAcqSrv* LoggerAcqSrv::m_instance = 0;
	LoggerAcqSrv::LoggerAcqSrv( )
	{
	}
	LoggerAcqSrv::~LoggerAcqSrv( )
	{
	}
	LoggerAcqSrv* LoggerAcqSrv::getInstance( )
	{
		if ( !m_instance )
		m_instance = new LoggerAcqSrv( );
		return m_instance;
	}
	void LoggerAcqSrv::createWriters( )
	{
		addWriter( DebugWriter::getInstance( ) );
		addWriter( SyslgWriter::getInstance( ) );
		addWriter( TraceWriter::getInstance( ) );
	}
}

