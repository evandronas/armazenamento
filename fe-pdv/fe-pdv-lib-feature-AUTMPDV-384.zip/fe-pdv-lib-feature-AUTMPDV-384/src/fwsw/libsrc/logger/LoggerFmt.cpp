/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo Morais de Souza
Data     : 04/10/2018
Empresa  : Rede
Descricao: Geracao do log TCPIP descriptografado
ID       : AM 331.044
*************************************************************
*/

#include "logger/DebugWriter.hpp"
#include "logger/DroppedWriter.hpp"
#include "logger/LoggerFmt.hpp"
#include "logger/SyslgWriter.hpp"
#include "logger/ThrottleWriter.hpp"
#include "logger/TraceWriter.hpp"
#include "logger/POSIPWriter.hpp"

namespace logger {

	LoggerFmt* LoggerFmt::m_instance = 0;

	LoggerFmt::LoggerFmt( )	{ }

	LoggerFmt::~LoggerFmt( ) {	}

	LoggerFmt* LoggerFmt::getInstance( ) {
		if ( !m_instance )
		m_instance = new LoggerFmt( );
		return m_instance;
	}

	void LoggerFmt::createWriters( )
	{
		addWriter( DebugWriter::getInstance( ) );
		addWriter( SyslgWriter::getInstance( ) );
		addWriter( TraceWriter::getInstance( ) );
		addWriter( ThrottleWriter::getInstance( ) );
		addWriter( DroppedWriter::getInstance( ) );
		addWriter( POSIPWriter::getInstance( ) );
	}
}

