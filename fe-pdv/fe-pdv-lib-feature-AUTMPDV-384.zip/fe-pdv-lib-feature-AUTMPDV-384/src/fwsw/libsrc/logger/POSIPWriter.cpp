/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

/*
Copyright 2018 REDE
*********************** MODIFICA��ES ************************
Autor    : Fabio Mazzer
Data     : 04/07/2018
Empresa  : Rede
Descri��o: Modifica��o do log para retirar o nome do arquivo e incluir a data
*************************************************************
Autor    : Eduardo Morais de Souza
Data     : 04/10/2018
Empresa  : Rede
Descricao: Geração do log TCPIP descriptografado
ID       : AM 225.800
*************************************************************
*/

#include <ist_argv0.h>
#include <ist_trace.h>
#include <oasisenv.h>
#include <oasis.h>
#include <stdlib.h>
#include <mb.h>
#include <unistd.h>
#include "logger/POSIPWriter.hpp"
#include "base/shc_cpp_wrapper.hpp"
#include "base/shc_structs.hpp"
#include "mailboxInterface/MailboxIn.hpp"
#include "mailboxInterface/MailboxInterface.hpp"
#include "fieldSet/ConstFieldAccess.hpp"

namespace logger
{
	POSIPWriter* POSIPWriter::instance = 0;

/// Nome do método: Constructor.
/// Descrição: Responsavel por inicializar as propriedades do objeto
/// EF/ET: (ID27650/AM225.800)
/// Histórico: [04/10/2018] - Eduardo De Souza - ET - AM225.800 - Update Captura 75
///                                              EF - ID27650 - Update Captura 75
	POSIPWriter::POSIPWriter( )	{
		fileName.clear( );
	}

/// Nome do método: Destructor.
/// Descrição: Responsavel por desalocar areas de memoria do objeto.
/// EF/ET: (ID27650/AM225.800)
/// Histórico: [04/10/2018] - Eduardo De Souza - ET - AM225.800 - Update Captura 75
///                                              EF - ID27650 - Update Captura 75
	POSIPWriter::~POSIPWriter( ){}

/// Nome do método: getInstance.
/// Descrição: Responsavel por instanciar um novo objeto da classe.
/// EF/ET: (ID27650/AM225.800)
/// Histórico: [04/10/2018] - Eduardo De Souza - ET - AM225.800 - Update Captura 75
///                                              EF - ID27650 - Update Captura 75	
	POSIPWriter* POSIPWriter::getInstance( ) {
		if ( !instance )
			instance = new POSIPWriter( );
		return instance;
	}

/// Nome do método: open.
/// Descrição: Responsavel por abrir o arquivo de log caso não exista ainda.
/// EF/ET: (ID27650/AM225.800)
/// Histórico: [04/10/2018] - Eduardo De Souza - ET - AM225.800 - Update Captura 75
///                                              EF - ID27650 - Update Captura 75 
	void POSIPWriter::open( )	{
		char cfgParam[255] = {0};
		char aux[255] = {0};
		char logPath[255] = {0};

		if ( fileName.length( ) > 0 )
			return;

		sprintf(cfgParam,"%s.logtcp", getenv("SWCONFIG_KEY"));

		if (cf_locate(cfgParam, aux) > 0) {
			sprintf(logPath, "%s%s", getenv(OLOGDIR_ENV), aux);
		} else {
			ODebug("Nao foi possivel encontar o parametro [%s]\n", cfgParam);
			syslg("LOG-F: Nao foi possivel encontar o parametro [%s]\n", cfgParam);
		}

		if ( logPath != NULL ) {
			fileName += logPath;
		}
	}

/// Nome do método: write.
/// Descrição: Responsavel por obter e inicializar algumas variaveis
/// EF/ET: (ID27650/AM225.800)
/// Histórico: [04/10/2018] - Eduardo De Souza - ET - AM225.800 - Update Captura 75
///                                              EF - ID27650 - Update Captura 75 
	void POSIPWriter::write( Level level, const char* msg, const int length )
	{
		if ( level == LEVEL_POSIP_IN || level == LEVEL_POSIP_OUT)
		{
			char mailboxName[256];
			char portName[256];
			char nowTimeAscii[128];
			char buffer [ (length + 128) ];
			int logLen=0;
			int locRet=0;
			struct tm * nowTimeInfo;
			struct base::shcpkg* pkg = 0;
			std::string networdId;
			std::string institutionId;
			time_t nowRawTime;
			pid_t pid = getpid( );
			const char* ptrInstId = getenv( "INSTITUTIONID" );
			const char* ptrNetworkId = getenv( "NETWORKID" );

			memset( mailboxName, 0, sizeof mailboxName );
			memset( portName, 0, sizeof portName );
			memset(nowTimeAscii, 0, sizeof nowTimeAscii );
			time ( &nowRawTime );
			nowTimeInfo = localtime ( &nowRawTime );

			snprintf(
				nowTimeAscii,
				sizeof nowTimeAscii,
				"%04d.%02d.%02d %02d:%02d:%02d",
				nowTimeInfo->tm_year + 1900,
				nowTimeInfo->tm_mon + 1,
				nowTimeInfo->tm_mday,
				nowTimeInfo->tm_hour,
				nowTimeInfo->tm_min,
				nowTimeInfo->tm_sec
			);

			if ( ptrInstId != NULL && ptrNetworkId != NULL )
			{
				institutionId = ptrInstId == NULL ? "" : ptrInstId;
				networdId = ptrNetworkId == NULL ? "" : ptrNetworkId;
				locRet = base::shc_locate_bin( &pkg, institutionId.c_str( ), networdId.c_str( ) );
				snprintf( mailboxName, sizeof mailboxName, "%s", mbMailBoxName( pkg->bin.mailbox ) );
				snprintf( portName, sizeof portName, "%s", mbMailBoxName( pkg->bin.port ) );
			}
			else
			{
                ODebug( "Nao foi possivel encontar a variavel de ambiente INSTITUTIONID e NETWORKID\n" );
                syslg("LOG-F: Nao foi possivel encontar a variavel de ambiente INSTITUTIONID e NETWORKID\n" );
			}

			logLen = snprintf( buffer, sizeof buffer, "%s %1.1s %0.8d %20.20s %s\n",
					             nowTimeAscii, //2018.10.03 13:48:44
					             level == LEVEL_POSIP_IN ? "I" : "O",
						         pid,		   // Process ID 09044006
								 strlen(portName)!= 0 ? portName : "-",  //P9009_IP001_4371
					             msg		   //HEADER+ISO8583
			                   );

			ist_trace_set_file( fileName.c_str( ) );
			ist_trace_output_direct(buffer, logLen);
		}
	}

/// Nome do método: write.
/// Descrição: Responsavel por obter e inicializar algumas variaveis 
/// EF/ET: (ID27650/AM225.800)
/// Histórico: [04/10/2018] - Eduardo De Souza - ET - AM225.800 - Update Captura 75
///                                              EF - ID27650 - Update Captura 75 
	void POSIPWriter::write( Level level, const char* msg )
	{
		if ( level == LEVEL_POSIP_IN || level == LEVEL_POSIP_OUT)
		{

			time_t nowRawTime;
			struct tm * nowTimeInfo;
			char nowTimeAscii[128];
			
			memset(nowTimeAscii, 0, sizeof nowTimeAscii );
			time ( &nowRawTime );
			nowTimeInfo = localtime ( &nowRawTime );
		
			snprintf(
				nowTimeAscii,
				sizeof nowTimeAscii,
				"%04d.%02d.%02d %02d:%02d:%02d ",
				nowTimeInfo->tm_year + 1900,
				nowTimeInfo->tm_mon + 1,
				nowTimeInfo->tm_mday,
				nowTimeInfo->tm_hour,
				nowTimeInfo->tm_min,
				nowTimeInfo->tm_sec
			);

			ist_trace_set_file( fileName.c_str( ) );
			ist_trace_output_direct( nowTimeAscii, strlen(nowTimeAscii) );
			ist_trace_output_direct( msg, strlen(msg) );
		}
	}

/// Nome do método: close.
/// Descrição: Responsavel por limpar algumas variaveis 
/// EF/ET: (ID27650/AM225.800)
/// Histórico: [04/10/2018] - Eduardo De Souza - ET - AM225.800 - Update Captura 75
///                                              EF - ID27650 - Update Captura 75 
	void POSIPWriter::close( )
	{
		fileName.clear( );
		ist_trace_set_file( "" );
	}
}//namespace logger

