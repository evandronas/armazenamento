
/*
Copyright 2021 REDE
*/

#pragma once
#include <sstream>
#include <cstring>
#include <unistd.h>
#include <security.h>
#include "base/GenException.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "msgConv/TextConv.hpp"
#include "cryptography/Crypto.hpp"
#include "cryptography/CryptoHASH_HSM.hpp"

namespace cryptography
{
    CryptoHASH_HSM::CryptoHASH_HSM()
    {
    }

    CryptoHASH_HSM::~CryptoHASH_HSM()
    {
    }

    bool CryptoHASH_HSM::generateHashMsg(const std::string &l_msg)
    {
        initEncriptHex();
        fillInput(l_msg);
        printInput();
        sendInput();
        printOutput();
        return(checkOutput());
    }

    void CryptoHASH_HSM::initEncriptHex()
    {
        memset(&m_InputMsg, ' ', sizeof(m_InputMsg));
        memcpy(m_InputMsg.command.header, "0001", sizeof(m_InputMsg.command.header));
        memcpy(m_InputMsg.command.command_code, "GM", sizeof(m_InputMsg.command.command_code));
        memcpy(m_InputMsg.command.hash_identifier, "06", sizeof(m_InputMsg.command.hash_identifier));
    }

    void CryptoHASH_HSM::fillInput(const std::string &l_msg)
    {
        sprintf(m_InputMsg.command.message_length, "%05d", l_msg.length());
        memset(m_InputMsg.message, 0, sizeof(m_InputMsg.message));
        memcpy(m_InputMsg.message, l_msg.c_str(), l_msg.length());
    }

    void CryptoHASH_HSM::fillInput(const unsigned char *l_msg, long l_length)
    {
        sprintf(m_InputMsg.command.message_length, "%05d", l_length);
        memset(m_InputMsg.message, 0, sizeof(m_InputMsg.message));
        memcpy(m_InputMsg.message, l_msg, l_length);
    }

    void CryptoHASH_HSM::printInput()
    {
        unsigned char l_buffer[sizeof(INPUT_HASH_MSG) * 2 + 1];

        memset(l_buffer, 0, sizeof(l_buffer));
        msgConv::TextConv::hexToAscii(l_buffer, sizeof(l_buffer), reinterpret_cast<const unsigned char*>(&m_InputMsg), sizeof(m_InputMsg.command) + sizeInputMsg());
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, "========= Buffer HASH SHA256 enviada para o HSM =========");
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, reinterpret_cast<const char*>(l_buffer), sizeof(l_buffer));
    }

    void CryptoHASH_HSM::sendInput()
    {
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, "========= sendInput( ) INI =========");
        security_direct(reinterpret_cast<char*>(&m_InputMsg), sizeof(m_InputMsg.command) + sizeInputMsg(), reinterpret_cast<char*>(&m_OutputMsg), sizeof(m_OutputMsg));
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, "========= sendInput( ) FIM =========");
    }

    void CryptoHASH_HSM::printOutput()
    {
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, "========= printOutput( ) INI =========");
        unsigned char l_buffer[sizeof(OUTPUT_MSG) * 2 + 1];

        memset(l_buffer, 0, sizeof(l_buffer));
        msgConv::TextConv::hexToAscii(l_buffer, sizeof(l_buffer), reinterpret_cast<const unsigned char*>(&m_OutputMsg), sizeof(m_OutputMsg.command) + sizeOutputMsg());
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, "========= Buffer HASH SHA256 recebida do HSM =========");
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, reinterpret_cast<const char*>(l_buffer), sizeof(l_buffer));
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, "========= printOutput( ) FIM =========");
    }

    void CryptoHASH_HSM::printOutput(const std::string &l_msg)
    {
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, std::string(" Mensagem recebida do HSM[" + l_msg + "]").c_str());
    }

    bool CryptoHASH_HSM::checkOutput()
    {
        char l_error[3];

        memset(l_error, 0, sizeof(l_error));
        strncpy(l_error, m_OutputMsg.command.error_code, sizeof(m_OutputMsg.command.error_code));
        logger::DebugWriter::getInstance()->write(logger::LEVEL_DEBUG, std::string("========= Codigo de retorno recebido do HSM [" + std::string(l_error) + "] =========").c_str());

        if (strncmp(l_error, "00", sizeof(m_OutputMsg.command.error_code)) == 0) {
            return true;
        }
        else {
            std::stringstream errMsg;
            errMsg << "========= ERRO HSM HASH SHA256 falhou, codigo de erro [" << l_error << "] =========";
            throw base::GenException(__FUNCTION__, errMsg.str().c_str());
        }
    }

    long CryptoHASH_HSM::sizeInputMsg()
    {
        std::stringstream l_stream;
        long l_size;
        l_stream << std::dec << std::string(m_InputMsg.command.message_length).substr(0, 5);
        l_stream >> l_size;
        return(l_size);
    }

    long CryptoHASH_HSM::sizeOutputMsg()
    {
        std::stringstream l_stream;
        long l_size;

        // tamanho fixo SHA256
        l_size = 32;
        return(l_size);
    }

    void CryptoHASH_HSM::receiveMsg(std::string &l_field)
    {
        l_field = std::string(m_OutputMsg.message, sizeOutputMsg());
        printOutput(l_field);
    }

}