/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 08/01/2019
Empresa  : Rede
Descricao: Adicionando tratamento de situacao de erro no HSM na decriptografia
ID       : EAK 36
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 15/09/2021
Empresa  : Rede
Descricao: Sub-Adquirente
ID       : EVO1-323
*************************************************************
*/

#pragma once
#include <cstring>
#include <sstream>
#include <unistd.h>
#include <security.h>
#include "base/GenException.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "msgConv/TextConv.hpp"
#include "cryptography/Crypto.hpp"
#include "cryptography/CryptoDUKPT.hpp"


namespace cryptography
{
    CryptoDUKPT::CryptoDUKPT( )
    {
    }
    
    CryptoDUKPT::~CryptoDUKPT( )
    {
    }

    void CryptoDUKPT::setKeys( fieldSet::ConstFieldAccess &l_field )
    {
        fieldSet::fsextr( m_termKSN, l_field );
        m_termBDK = selectTBSW0136( strtol( m_termKSN.substr( 5, 5 ).c_str( ), 0, 16 ) );
    }

    void CryptoDUKPT::setKeys( const std::string &l_ksn )
    {
        m_termKSN = l_ksn;
        m_termBDK = selectTBSW0136( strtol( m_termKSN.substr( 5, 5 ).c_str( ), 0, 16 ) );
    }

    void CryptoDUKPT::setKeys( const long &l_termBDK )
    {
        m_termBDK = selectTBSW0136( l_termBDK );
    }

	/* JPFC - EVO1-323 - Inicio */
	void CryptoDUKPT::setKeys( fieldSet::ConstFieldAccess &l_field, const long &l_termBDK )
    {
        fieldSet::fsextr( m_termKSN, l_field );
        m_termBDK = selectTBSW0136( l_termBDK );
    }
	/* JPFC - EVO1-323 - Fim */
	
    void CryptoDUKPT::receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_prefix, const std::string &l_sufix )
    {
        std::string l_msg;
        char l_buff[100];
        int l_pos = 0;

        for( int i = 0; i < sizeOutputMsg( ); i++ )
        {
            if( ( i % 2 ) != 0 )
            {
                l_buff[ l_pos ] = m_OutputMsg.message[ i ];
                l_pos++;
            }
        }
        l_buff[ l_pos ] = 0;
        l_msg = l_prefix + std::string( l_buff ) + l_sufix;;
        fieldSet::fscopy( l_field, l_msg.c_str( ), l_msg.length( ) );
        printOutput( l_msg );
    }

    void CryptoDUKPT::receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_sufix )
    {
        std::string l_msg;
        
        l_msg = std::string( m_OutputMsg.message, sizeOutputMsg( ) ) + l_sufix;;
        fieldSet::fscopy( l_field, l_msg.c_str( ), l_msg.length( ) );
        printOutput( l_msg );
    }

    void CryptoDUKPT::receiveMsg( fieldSet::FieldAccess &l_field )
    {
        std::string l_msg;
        
        l_msg = std::string( m_OutputMsg.message, sizeOutputMsg( ) );
        fieldSet::fscopy( l_field, l_msg.c_str( ), l_msg.length( ) );
        printOutput( l_msg );
    }

    void CryptoDUKPT::receiveMsg( std::string &l_field )
    {
        l_field = std::string( m_OutputMsg.message, sizeOutputMsg( ) );
        printOutput( l_field );
    }

    void CryptoDUKPT::receiveMsg( unsigned char *l_msg, long &l_length )
    {
        memcpy( l_msg, m_OutputMsg.message, sizeOutputMsg( ) );
        l_length = sizeOutputMsg( );
    }

    bool CryptoDUKPT::decriptyMsg( const std::string &l_msg )
    {
        /*
		initDecriptHex( );
        fillInput( l_msg );
        printInput( );
        sendInput( );
        printOutput( );
        return( checkOutput( ) );
		*/
		//const unsigned char * constStr = reinterpret_cast<const unsigned char *> (l_msg.c_str());
        return( decriptyMsgSized((const unsigned char*)l_msg.c_str( ) , m_msgLength) );
    }

    bool CryptoDUKPT::decriptyMsgSized( const unsigned char *l_msg, long l_length )
    {
        initDecriptHex( );
        fillInput( l_msg, l_length );
        printInput( );
        sendInput( );
        printOutput( );
        return( checkOutput( ) );
    }


    bool CryptoDUKPT::decriptyMsg( const unsigned char *l_msg, long l_length )
    {
        initDecriptBinary( );
        fillInput( l_msg, l_length );
        printInput( );
        sendInput( );
        printOutput( );
        return( checkOutput( ) );
    }
    
    bool CryptoDUKPT::encriptyMsg( const std::string &l_msg )
    {
        initEncriptHex( );
        fillInput( l_msg );
        printInput( );
        sendInput( );
        printOutput( );
        return( checkOutput( ) );
    }
 
    void CryptoDUKPT::initDecriptHex( )
    {
        memset( &m_InputMsg, ' ', sizeof( m_InputMsg ) );
        memcpy( m_InputMsg.command.header, "0001", sizeof( m_InputMsg.command.header ) );
        memcpy( m_InputMsg.command.command_code, "M2", sizeof( m_InputMsg.command.command_code ) );
        memcpy( m_InputMsg.command.mode_flag, "00", sizeof( m_InputMsg.command.mode_flag ) );
        memcpy( m_InputMsg.command.input_format_flag, "1", sizeof( m_InputMsg.command.input_format_flag ) );
        memcpy( m_InputMsg.command.output_format_flag, "1", sizeof( m_InputMsg.command.output_format_flag ) );
        memcpy( m_InputMsg.command.key_type, "009", sizeof( m_InputMsg.command.key_type ) );
        memcpy( m_InputMsg.command.key_schema, "U" , sizeof( m_InputMsg.command.key_schema ) );
        memcpy( m_InputMsg.command.bdk, m_termBDK.c_str( ), sizeof( m_InputMsg.command.bdk ) );
        memcpy( m_InputMsg.command.metadado, "A05", sizeof( m_InputMsg.command.metadado ) );
        memcpy( m_InputMsg.command.ksn, m_termKSN.c_str( ), sizeof( m_InputMsg.command.ksn ) );
    }
 
    void CryptoDUKPT::initDecriptBinary( )
    {
        memset( &m_InputMsg, ' ', sizeof( m_InputMsg ) );
        memcpy( m_InputMsg.command.header, "0001", sizeof( m_InputMsg.command.header ) );
        memcpy( m_InputMsg.command.command_code, "M2", sizeof( m_InputMsg.command.command_code ) );
        memcpy( m_InputMsg.command.mode_flag, "00", sizeof( m_InputMsg.command.mode_flag ) );
        memcpy( m_InputMsg.command.input_format_flag, "0", sizeof( m_InputMsg.command.input_format_flag ) );
        memcpy( m_InputMsg.command.output_format_flag, "0", sizeof( m_InputMsg.command.output_format_flag ) );
        memcpy( m_InputMsg.command.key_type, "009", sizeof( m_InputMsg.command.key_type ) );
        memcpy( m_InputMsg.command.key_schema, "U" , sizeof( m_InputMsg.command.key_schema ) );
        memcpy( m_InputMsg.command.bdk, m_termBDK.c_str( ), sizeof( m_InputMsg.command.bdk ) );
        memcpy( m_InputMsg.command.metadado, "A05", sizeof( m_InputMsg.command.metadado ) );
        memcpy( m_InputMsg.command.ksn, m_termKSN.c_str( ), sizeof( m_InputMsg.command.ksn ) );
    }

    void CryptoDUKPT::initEncriptHex( )
    {
        memset( &m_InputMsg, ' ', sizeof( m_InputMsg ) );
        memcpy( m_InputMsg.command.header, "0001", sizeof( m_InputMsg.command.header ) );
        memcpy( m_InputMsg.command.command_code, "M0", sizeof( m_InputMsg.command.command_code ) );
        memcpy( m_InputMsg.command.mode_flag, "00", sizeof( m_InputMsg.command.mode_flag ) );
        memcpy( m_InputMsg.command.input_format_flag, "1", sizeof( m_InputMsg.command.input_format_flag ) );
        memcpy( m_InputMsg.command.output_format_flag, "1", sizeof( m_InputMsg.command.output_format_flag ) );
        memcpy( m_InputMsg.command.key_type, "009", sizeof( m_InputMsg.command.key_type ) );
        memcpy( m_InputMsg.command.key_schema, "U" , sizeof( m_InputMsg.command.key_schema ) );
        memcpy( m_InputMsg.command.bdk, m_termBDK.c_str( ), sizeof( m_InputMsg.command.bdk ) );
        memcpy( m_InputMsg.command.metadado, "A05", sizeof( m_InputMsg.command.metadado ) );
        memcpy( m_InputMsg.command.ksn, m_termKSN.c_str( ), sizeof( m_InputMsg.command.ksn ) );
    }

    void CryptoDUKPT::fillInput( const std::string &l_msg )
    {
        sprintf( m_InputMsg.command.message_length, "%04X", strlen( l_msg.c_str( ) ) );
        memset( m_InputMsg.message, 0 , sizeof( m_InputMsg.message ) );
        memcpy( m_InputMsg.message, l_msg.c_str( ), sizeInputMsg( ) );
    }
    
    void CryptoDUKPT::fillInput( const unsigned char *l_msg, long l_length )
    {
        sprintf( m_InputMsg.command.message_length, "%04X", l_length );
        memset( m_InputMsg.message, 0 , sizeof( m_InputMsg.message ) );
        memcpy( m_InputMsg.message, l_msg, l_length );
    }   

    void CryptoDUKPT::printInput( )
    {
        unsigned char l_buffer[ sizeof( INPUT_DUKPT_MSG ) * 2  + 1 ];

        memset(l_buffer, 0, sizeof( l_buffer ) );
        msgConv::TextConv::hexToAscii( l_buffer, sizeof( l_buffer ), reinterpret_cast<const unsigned char*>( &m_InputMsg ), sizeof( m_InputMsg.command ) + sizeInputMsg( ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "========= Buffer DUKPT enviada para o HSM =========" );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, reinterpret_cast<const char*>( l_buffer ), sizeof( l_buffer ) );
    }

    void CryptoDUKPT::sendInput( )
    {
        security_direct( reinterpret_cast< char* >( &m_InputMsg ), sizeof( m_InputMsg.command ) + sizeInputMsg( ), reinterpret_cast< char* >( &m_OutputMsg ), sizeof( m_OutputMsg ) );
    }

    void CryptoDUKPT::printOutput( )
    {
        unsigned char l_buffer[ sizeof( OUTPUT_MSG ) * 2 + 1 ];

        memset( l_buffer, 0, sizeof( l_buffer ) );
        msgConv::TextConv::hexToAscii( l_buffer, sizeof( l_buffer ), reinterpret_cast<const unsigned char*>( &m_OutputMsg ),  sizeof( m_OutputMsg.command ) + sizeOutputMsg(  ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "========= Buffer DUKPT recebida do HSM =========" );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, reinterpret_cast<const char*>( l_buffer ), sizeof( l_buffer ) );
    }

    void CryptoDUKPT::printOutput( const std::string &l_msg )
    {
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, std::string ( " Mensagem recebida do HSM[" + l_msg + "]" ).c_str( ) );
    }

    bool CryptoDUKPT::checkOutput( )
    {
        char l_error[ 3 ];

        memset( l_error, 0, sizeof( l_error ) );
        strncpy( l_error, m_OutputMsg.command.error_code, sizeof ( m_OutputMsg.command.error_code ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, std::string( "========= Codigo de retorno recebido do HSM [" + std::string( l_error ) + "] =========" ).c_str() );

		if ( strncmp( l_error, "00", sizeof ( m_OutputMsg.command.error_code ) ) == 0 ) {
			return true;
		} else {
			std::stringstream errMsg;
			errMsg << "========= ERRO HSM DUKPT falhou, codigo de erro [" << l_error << "] =========";
			throw base::GenException( __FUNCTION__, errMsg.str().c_str());
		}
	}

    long CryptoDUKPT::sizeInputMsg( )
    {
        std::stringstream l_stream;
        long l_size;
        
        l_stream << std::hex << std::string( m_InputMsg.command.message_length ).substr( 0, 4 );
        l_stream >> l_size;
        return( l_size );
    }

    long CryptoDUKPT::sizeOutputMsg( )
    {
        std::stringstream l_stream;
        long l_size;
        
        l_stream << std::hex << std::string( m_OutputMsg.command.message_length ).substr( 0, 4 );
        l_stream >> l_size;
        return( l_size );
    }
    
    void CryptoDUKPT::setMsgLength( const long &l_length )
    {
        m_msgLength = l_length;
    }
}
