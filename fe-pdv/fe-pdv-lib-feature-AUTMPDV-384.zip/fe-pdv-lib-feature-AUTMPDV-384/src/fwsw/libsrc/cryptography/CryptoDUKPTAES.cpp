/* Copyright 2021 Rede
Autor : Andre Morishita
Empresa : Leega
*/

#pragma once
#include <cstring>
#include <sstream>
#include <unistd.h>
#include <security.h>
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "msgConv/TextConv.hpp"
#include "cryptography/Crypto.hpp"
#include "cryptography/CryptoDUKPTAES.hpp"
#include "base/GenException.hpp"

using namespace std;

namespace cryptography
{

    /// CryptoDUKPTAES 
    /// Construtor da classe
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    CryptoDUKPTAES::CryptoDUKPTAES( )
    {
    }
    
    /// ~CryptoDUKPTAES 
    /// Destrutor da classe
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    CryptoDUKPTAES::~CryptoDUKPTAES( )
    {
    }

    /// setKeys 
    /// Atribuicao da Key
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::setKeys( fieldSet::ConstFieldAccess &l_field )
    {
        fieldSet::fsextr( terminalKSN, l_field );
        terminalBDK = selectTBSW0167( terminalKSN.substr(0, 16) );
    }

    /// setKeys 
    /// Atribuicao da Key
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::setKeys( const string &l_ksn )
    {
        terminalKSN = l_ksn;
        terminalBDK = selectTBSW0167( terminalKSN.substr(0, 16) );
    }

    /// setKeys 
    /// Atribuicao da Key
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::setKeys( const long &l_id_bdk )
    {
        terminalBDK = selectTBSW0136( l_id_bdk );
    }

    /// setKeys 
    /// Atribuicao da Key
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::setKeys( fieldSet::ConstFieldAccess &l_field, const long &l_id_bdk )
    {
        fieldSet::fsextr( terminalKSN, l_field );
        terminalBDK = selectTBSW0136( l_id_bdk );
    }

    /// receiveMsg 
    /// Recebendo mensagem do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::receiveMsg( fieldSet::FieldAccess &l_field, const string &l_prefix, const string &l_sufix )
    {
        string message;
        char buffer[100];
        int posicao = 0;

        for( int i = 0; i < SizeOutputMsg( ); i++ )
        {
            if( ( i % 2 ) != 0 )
            {
                buffer[ posicao ] = outputMessage.message[ i ];
                posicao++;
            }
        }
        buffer[ posicao ] = 0;
        message = l_prefix + string( buffer ) + l_sufix;;
        fieldSet::fscopy( l_field, message.c_str( ), message.length( ) );
        PrintOutput( message );
    }

    /// receiveMsg 
    /// Recebendo mensagem do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::receiveMsg( fieldSet::FieldAccess &l_field, const string &l_sufix )
    {
        string message;
        
        message = string( outputMessage.message, SizeOutputMsg( ) ) + l_sufix;;
        fieldSet::fscopy( l_field, message.c_str( ), message.length( ) );
        PrintOutput( message );
    }

    /// receiveMsg 
    /// Recebendo mensagem do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::receiveMsg( fieldSet::FieldAccess &l_field )
    {
        string message;
        
        message = string( outputMessage.message, SizeOutputMsg( ) );
        fieldSet::fscopy( l_field, message.c_str( ), message.length( ) );
        PrintOutput( message );
    }

    /// receiveMsg 
    /// Recebendo mensagem do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::receiveMsg( string &l_field )
    {
        l_field = string( outputMessage.message, SizeOutputMsg( ) );
        PrintOutput( l_field );
    }

    /// receiveMsg 
    /// Recebendo mensagem do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::receiveMsg( unsigned char *l_msg, long &l_length )
    {
        memcpy( l_msg, outputMessage.message, SizeOutputMsg( ) );
        l_length = SizeOutputMsg( );
    }

    /// decriptyMsg 
    /// Descriptografa mensagem do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    bool CryptoDUKPTAES::decriptyMsg( const string &l_msg )
    {
        return( DecriptyMsgSized((const unsigned char*)l_msg.c_str( ) , messageLength) );
    }

    /// DecriptyMsgSized 
    /// Descriptografa mensagem do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    bool CryptoDUKPTAES::DecriptyMsgSized( const unsigned char *message, long length )
    {
        InitDecriptHex( );
        FillInput( message, length );
        PrintInput( );
        SendInput( );
        PrintOutput( );
        return( CheckOutput( ) );
    }

    /// decriptyMsg 
    /// Descriptografa mensagem do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    bool CryptoDUKPTAES::decriptyMsg( const unsigned char *l_msg, long l_length )
    {
        InitDecriptBinary( );
        FillInput( l_msg, l_length );
        PrintInput( );
        SendInput( );
        PrintOutput( );
        return( CheckOutput( ) );
    }
    
    /// encriptyMsg 
    /// Encripta mensagem
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    bool CryptoDUKPTAES::encriptyMsg( const string &l_msg )
    {
        InitEncriptHex( );
        FillInput( l_msg );
        PrintInput( );
        SendInput( );
        PrintOutput( );
        return( CheckOutput( ) );
    }
 
    /// InitDecriptHex 
    /// Inicializa comando do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::InitDecriptHex( )
    {
        memset( &inputMessage, ' ', sizeof( inputMessage ) );
        memcpy( inputMessage.command.header, "0001", sizeof( inputMessage.command.header ) );
        memcpy( inputMessage.command.commandCode, "M2", sizeof( inputMessage.command.commandCode ) );
        memcpy( inputMessage.command.modeFlag, "00", sizeof( inputMessage.command.modeFlag ) );
        memcpy( inputMessage.command.inputFormatFlag, "1", sizeof( inputMessage.command.inputFormatFlag ) );
        memcpy( inputMessage.command.outputFormatFlag, "1", sizeof( inputMessage.command.outputFormatFlag ) );
        memcpy( inputMessage.command.keyType, "FFF", sizeof( inputMessage.command.keyType ) );
        // memcpy( inputMessage.command.keySchema, "" , sizeof( inputMessage.command.keySchema ) );
        memcpy( inputMessage.command.bdk, terminalBDK.c_str( ), sizeof( inputMessage.command.bdk ) );
        memcpy( inputMessage.command.metadado, "000", sizeof( inputMessage.command.metadado ) );
        memcpy( inputMessage.command.ksn, terminalKSN.c_str( ), sizeof( inputMessage.command.ksn ) );

        memset( &inputMessageComp, ' ', sizeof( inputMessageComp ) );
        memcpy( inputMessageComp.delimiter, "%", sizeof( inputMessageComp.delimiter ) );
        memcpy( inputMessageComp.lmkIdentifier, "01", sizeof( inputMessageComp.lmkIdentifier ) );
    }
 
    /// InitDecriptBinary 
    /// Inicializa comando do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::InitDecriptBinary( )
    {
        memset( &inputMessage, ' ', sizeof( inputMessage ) );
        memcpy( inputMessage.command.header, "0001", sizeof( inputMessage.command.header ) );
        memcpy( inputMessage.command.commandCode, "M2", sizeof( inputMessage.command.commandCode ) );
        memcpy( inputMessage.command.modeFlag, "00", sizeof( inputMessage.command.modeFlag ) );
        memcpy( inputMessage.command.inputFormatFlag, "0", sizeof( inputMessage.command.inputFormatFlag ) );
        memcpy( inputMessage.command.outputFormatFlag, "0", sizeof( inputMessage.command.outputFormatFlag ) );
        memcpy( inputMessage.command.keyType, "FFF", sizeof( inputMessage.command.keyType ) );
        // memcpy( inputMessage.command.keySchema, "" , sizeof( inputMessage.command.keySchema ) );
        memcpy( inputMessage.command.bdk, terminalBDK.c_str( ), sizeof( inputMessage.command.bdk ) );
        memcpy( inputMessage.command.metadado, "000", sizeof( inputMessage.command.metadado ) );
        memcpy( inputMessage.command.ksn, terminalKSN.c_str( ), sizeof( inputMessage.command.ksn ) );

        memset( &inputMessageComp, ' ', sizeof( inputMessageComp ) );
        memcpy( inputMessageComp.delimiter, "%", sizeof( inputMessageComp.delimiter ) );
        memcpy( inputMessageComp.lmkIdentifier, "01", sizeof( inputMessageComp.lmkIdentifier ) );
    }

    /// InitEncriptHex 
    /// Inicializa comando do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::InitEncriptHex( )
    {
        memset( &inputMessage, ' ', sizeof( inputMessage ) );
        memcpy( inputMessage.command.header, "0001", sizeof( inputMessage.command.header ) );
        memcpy( inputMessage.command.commandCode, "M2", sizeof( inputMessage.command.commandCode ) );
        memcpy( inputMessage.command.modeFlag, "00", sizeof( inputMessage.command.modeFlag ) );
        memcpy( inputMessage.command.inputFormatFlag, "0", sizeof( inputMessage.command.inputFormatFlag ) );
        memcpy( inputMessage.command.outputFormatFlag, "0", sizeof( inputMessage.command.outputFormatFlag ) );
        memcpy( inputMessage.command.keyType, "FFF", sizeof( inputMessage.command.keyType ) );
        // memcpy( inputMessage.command.keySchema, "" , sizeof( inputMessage.command.keySchema ) );
        memcpy( inputMessage.command.bdk, terminalBDK.c_str( ), sizeof( inputMessage.command.bdk ) );
        memcpy( inputMessage.command.metadado, "000", sizeof( inputMessage.command.metadado ) );
        memcpy( inputMessage.command.ksn, terminalKSN.c_str( ), sizeof( inputMessage.command.ksn ) );

        memset( &inputMessageComp, ' ', sizeof( inputMessageComp ) );
        memcpy( inputMessageComp.delimiter, "%", sizeof( inputMessageComp.delimiter ) );
        memcpy( inputMessageComp.lmkIdentifier, "01", sizeof( inputMessageComp.lmkIdentifier ) );
    }

    /// FillInput 
    /// Preenche comando do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::FillInput( const string &message )
    {
        sprintf( inputMessage.command.messageLength, "%04X", strlen( message.c_str( ) ) );
        memcpy( inputMessage.message, 0 , sizeof( inputMessage.message ) );
        memcpy( inputMessage.message, message.c_str( ), SizeInputMsg( ) );

        // incluindo complemento do comando apos a mensagem que serah descriptografada
        int sizeMessage = SizeInputMsg( );
        int sizeDelimiter = sizeof(inputMessageComp.delimiter);
        memcpy(&inputMessage.message[sizeMessage], inputMessageComp.delimiter, sizeDelimiter );
        memcpy(&inputMessage.message[sizeMessage+sizeDelimiter], inputMessageComp.lmkIdentifier, sizeof(inputMessageComp.lmkIdentifier) );
    }
    
    /// FillInput 
    /// Preenche comando do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::FillInput( const unsigned char *message, long length )
    {
        sprintf( inputMessage.command.messageLength, "%04X", length );
        memset( inputMessage.message, 0 , sizeof( inputMessage.message ) );
        memcpy( inputMessage.message, message, length );

        // incluindo complemento do comando apos a mensagem que serah descriptografada
        int sizeDelimiter = sizeof(inputMessageComp.delimiter);
        memcpy(&inputMessage.message[length], inputMessageComp.delimiter, sizeDelimiter );
        memcpy(&inputMessage.message[length+sizeDelimiter], inputMessageComp.lmkIdentifier, sizeof(inputMessageComp.lmkIdentifier) );
    }

    /// PrintInput 
    /// Mostra comando do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::PrintInput( )
    {
        unsigned char buffer[ sizeof( INPUT_DUKPT_MSG ) * 2  + 1 ];

        memset(buffer, 0, sizeof( buffer ) );
        msgConv::TextConv::hexToAscii( buffer, sizeof( buffer ), reinterpret_cast<const unsigned char*>( &inputMessage ), sizeof( inputMessage.command ) + SizeInputMsg( ) + SizeInputMsgComp( ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "========= Buffer DUKPT AES enviada para o HSM =========" );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, reinterpret_cast<const char*>( buffer ), sizeof( buffer ) );
    }

    /// SendInput 
    /// Envia comando do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::SendInput( )
    {
        security_direct( reinterpret_cast< char* >( &inputMessage ), sizeof( inputMessage.command ) + SizeInputMsg( ) + SizeInputMsgComp( ), reinterpret_cast< char* >( &outputMessage ), sizeof( outputMessage ) );
    }

    /// PrintOutput 
    /// Mostra comando do HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::PrintOutput( )
    {
        unsigned char buffer[ sizeof( OUTPUT_MSG ) * 2 + 1 ];

        memset( buffer, 0, sizeof( buffer ) );
        msgConv::TextConv::hexToAscii( buffer, sizeof( buffer ), reinterpret_cast<const unsigned char*>( &outputMessage ),  sizeof( outputMessage.command ) + SizeOutputMsg(  ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "========= Buffer DUKPT AES recebida do HSM =========" );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, reinterpret_cast<const char*>( buffer ), sizeof( buffer ) );
    }

    /// PrintOutput 
    /// Mostra mensagem
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::PrintOutput( const string &message )
    {
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, string ( " Mensagem recebida do HSM[" + message + "]" ).c_str( ) );
    }

    /// CheckOutput 
    /// Check retorno HSM
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    bool CryptoDUKPTAES::CheckOutput( )
    {
        char error[ 3 ];

        memset( error, 0, sizeof( error ) );
        strncpy( error, outputMessage.command.errorCode, sizeof ( outputMessage.command.errorCode ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, string( "========= Codigo de retorno recebido do HSM [" + string( error ) + "] =========" ).c_str() );

		if ( strncmp( error, "00", sizeof ( outputMessage.command.errorCode ) ) == 0 ) {
			return true;
		} else {
			stringstream errorMessage;
			errorMessage << "========= ERRO HSM DUKPT AES falhou, codigo de erro [" << error << "] =========";
			throw base::GenException(__FUNCTION__, errorMessage.str().c_str());
		}   
	}

    /// SizeInputMsg 
    /// Calculo do tamanho da mensagem de entrada
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    long CryptoDUKPTAES::SizeInputMsg( )
    {
        stringstream stream;
        long size;
        
        stream << hex << string( inputMessage.command.messageLength ).substr( 0, 4 );
        stream >> size;
        return( size );
    }

    /// SizeInputMsgComp 
    /// Calculo do tamanho da mensagem de complemento do comando
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    long CryptoDUKPTAES::SizeInputMsgComp( )
    {
        return( sizeof(inputMessageComp) );
    }

    /// SizeOutputMsg 
    /// Calculo do tamanho da mensagem de saida
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    long CryptoDUKPTAES::SizeOutputMsg( )
    {
        stringstream stream;
        long size;
        
        stream << hex << string( outputMessage.command.messageLength ).substr( 0, 4 );
        stream >> size;
        return( size );
    }
    
    /// setMsgLength 
    /// Atribui tamanho da mensagem
    /// EF/ET: EF1
    /// Historico: [Data]  - ET - Descricao
    /// 10/12/2021 - Andre Morishita - ET1 - Criacao da versao inicial
    void CryptoDUKPTAES::setMsgLength( const long &length )
    {
        messageLength = length;
    }
}
