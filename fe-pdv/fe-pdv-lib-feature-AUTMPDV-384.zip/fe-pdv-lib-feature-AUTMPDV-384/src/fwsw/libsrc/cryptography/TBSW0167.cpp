#include <dbm.h>
#include <dbaccess/table.hpp>
#include "cryptography/TBSW0167.hpp"

namespace cryptography
{
    TBSW0167::TBSW0167()
    {
        InitVar();
        where_condition = "";
	update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0167::TBSW0167( const std::string& whereClause )
    {
        InitVar();
        where_condition = whereClause;
	update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0167::~TBSW0167()
    {
    }

    void TBSW0167::InitVar()
    {
        query_fields = "COD_ID_CHAV, COD_CRPA_CHAV, COD_CHCK_VLUE, DTH_ULT_ATLZ, COD_OPID_ULT_ATLZ";
        table_name = "TBSW0167";

        codIdChav = " ";
        codCrpaChav = " ";
        codChckVlue = " ";
        dthUltAtlz = 0;
        codOpidUltAtlz = " ";
    }

    void TBSW0167::bind_columns()
    {
        bind( codIdChavPosicao, codIdChav );
        bind( codCrpaChavPosicao, codCrpaChav );
        bind( codChckVluePosicao, codChckVlue );
        bind( dthUltAtlzPosicao, &dthUltAtlz );
        bind( codOpidUltAtlzPosicao, codOpidUltAtlz );
    }

    void TBSW0167::SetCodIdChav( unsigned long localCodIdChav )
    {
        codIdChav = localCodIdChav;
    }
    void TBSW0167::SetCodCrpaChav( const std::string& localCodCrpaChav )
    {
        codCrpaChav = localCodCrpaChav;
    }
    void TBSW0167::SetCodChckVlue( const std::string& localCodChckVlue )
    {
        codChckVlue = localCodChckVlue;
    }
    void TBSW0167::SetDthUltAtlz( dbm_datetime_t localDthUltAtlz )
    {
        dthUltAtlz = localDthUltAtlz;
    }
    void TBSW0167::SetCodOpidUltAtlz( const std::string& localCodOpidUltAtlz )
    {
        codOpidUltAtlz = localCodOpidUltAtlz;
    }

    const std::string& TBSW0167::GetCodIdChav() const
    {
        return codIdChav;
    }
    const std::string& TBSW0167::GetCodCrpaChav() const
    {
        return codCrpaChav;
    }
    const std::string& TBSW0167::GetCodChckVlue() const
    {
        return codChckVlue;
    }
    dbm_datetime_t TBSW0167::GetDthUltAtlz() const
    {
        return dthUltAtlz;
    }
    const std::string& TBSW0167::GetCodOpidUltAtlz() const
    {
        return codOpidUltAtlz;
    }
} //namespace cryptography
