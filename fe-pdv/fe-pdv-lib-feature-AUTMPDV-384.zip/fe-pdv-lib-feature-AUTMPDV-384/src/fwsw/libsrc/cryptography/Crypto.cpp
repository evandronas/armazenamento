/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo de Souza
Data     : 23/08/2018
Empresa  : Rede
Descricao: Correcao tratamento criptograma de validacao do host
ID       : AM 231211
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 08/01/2019
Empresa  : Rede
Descricao: Adicionando tratamento de situacao de erro no HSM na decriptografia
ID       : EAK 36
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 15/09/2021
Empresa  : Rede
Descricao: Sub-Adquirente
ID       : EVO1-323
*************************************************************
*/
#pragma once
#include <sstream>
#include "dataManip/Command.hpp"
#include "cryptography/Crypto.hpp"
#include "cryptography/TBSW0136.hpp"
#include "cryptography/TBSW0167.hpp"
#include "base/GenException.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace cryptography
{
    Crypto::Crypto( ) 
	{ 
		this->dataCategory = std::string( "" );
	};
	
    Crypto::~Crypto( ) { };
    void Crypto::setKeys( fieldSet::ConstFieldAccess &l_field ) { };
    void Crypto::setKeys( const std::string &l_ksn ) { };
    void Crypto::setKeys( const long &l_id_bdk ) { };
	/* JPFC - EVO1-323 - Inicio */
    void Crypto::setKeys( fieldSet::ConstFieldAccess &l_field, const long &l_id_bdk ) { };
	/* JPFC - EVO1-323 - Fim */
    void Crypto::receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_prefix, const std::string &l_sufix ) { };
    void Crypto::receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_sufix ) { };
    void Crypto::receiveMsg( fieldSet::FieldAccess &l_field ) { };
    void Crypto::receiveMsg( std::string &l_field ) { };
    void Crypto::receiveMsg( unsigned char *l_msg,  long &l_length ) { };
    void Crypto::receiveMsg( fieldSet::FieldAccess &field,  long &length ) { };
    bool Crypto::decriptyMsg( const std::string &l_msg ) { return( false ); };
    bool Crypto::decriptyMsg( const unsigned char *l_msg, long l_length ) { return( false ); };        
    bool Crypto::encriptyMsg( const std::string &l_msg ) { return( false ); };
    bool Crypto::encriptyMsg( const char l_msg[ ] ) { return( false ); };
    bool Crypto::debugEncripty( const std::string &l_msg ) { return( false ); };
    void Crypto::setMsgLength( const long &l_length ) { };
	
    std::string Crypto::selectTBSW0136( const long &l_id_bdk )
    {
        try
        {
            std::ostringstream l_whereClause;
            l_whereClause << "ID_BDK = " << l_id_bdk;
            cryptography::TBSW0136 l_TBSW0136( l_whereClause.str( ) );

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str() );

            l_TBSW0136.prepare();
            l_TBSW0136.execute();
            if( 0 < l_TBSW0136.fetch() )
            {
                return( l_TBSW0136.get_COD_CRPA_CHAV_BDK( ) );
            }
        }
        catch( base::GenException e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0136Loader <" + l_what + ">";
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_msg.c_str() );
        }
        catch( std::exception  e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0136Loader <" + l_what + ">";
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_msg.c_str() );
        }
        return( std::string( "" ) );
    }

    std::string Crypto::selectTBSW0167( const std::string &localCodIdChav )
    {
        try
        {
            std::ostringstream localWhereClause;
            localWhereClause << "COD_ID_CHAV = '" << localCodIdChav << "'";
            cryptography::TBSW0167 localTbsw0167( localWhereClause.str( ) );

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, localWhereClause.str( ).c_str() );

            localTbsw0167.prepare();
            localTbsw0167.execute();
            if( 0 < localTbsw0167.fetch() )
            {
                return( localTbsw0167.GetCodCrpaChav( ) );
            }
        }
        catch( base::GenException e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0167Loader <" + l_what + ">";
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_msg.c_str() );
        }
        catch( std::exception  e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0167Loader <" + l_what + ">";
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_msg.c_str() );
        }
        return( std::string( "" ) );
    }

	/// SetDataCategory
	/// Atribui um novo valor ao dataCategory, que indica qual criptografia está sendo realizada no momento (ex: TR2, CVC2, PAN, ...) - para tratar erro no HSM
	/// EF/ET: EAK-36
	/// Histórico: [Data] - ET - Descrição
	/// [08/01/2019] - EAK 36 - Versão inicial
	void Crypto::SetDataCategory(const std::string &newCategory) {
		this->dataCategory = newCategory;
	}
	
	/// GetDataCategory
	/// Retorna o valor do dataCategory, que indica qual criptografia está sendo realizada no momento (ex: TR2, CVC2, PAN, ...) - para tratar erro no HSM
	/// EF/ET: EAK-36
	/// Histórico: [Data] - ET - Descrição
	/// [08/01/2019] - EAK 36 - Versão inicial
	std::string Crypto::GetDataCategory() {
		return this->dataCategory;
	}
}
