/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo de Souza
Data     : 23/08/2018
Empresa  : Rede
Descricao: Correcao tratamento criptograma de validacao do host
ID       : AM 231211
*************************************************************
*/

#pragma once
#include <cstring>
#include <sstream>
#include <unistd.h>
#include <security.h>
#include <dlfcn.h>
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "msgConv/TextConv.hpp"
#include "cryptography/Crypto.hpp"
#include "cryptography/CryptoHASH.hpp"

namespace cryptography
{
    CryptoHASH::CryptoHASH( )
    {
        m_Loaded = false;
    }
    
    CryptoHASH::~CryptoHASH( )
    {
    }

    void CryptoHASH::receiveMsg( fieldSet::FieldAccess &l_field )
    {
        std::string l_msg;
        
        l_msg = std::string( m_OutputMsg );
        fieldSet::fscopy( l_field, l_msg.c_str( ), l_msg.length( ) );
        printInfoMsg( l_msg );
    }
    
    bool CryptoHASH::encriptyMsg( const char l_msg[ ] )
    {
        printInfoMsg( std::string( "CryptoHASH::encriptyMsg, Inicio)" ) );

        if ( initInput( ) == false )
        {
            return( false );
        }

        printInput( l_msg, msgLength );
        sendInput( l_msg, msgLength );
        printOutput( );
        return( checkOutput( ) );
    }

    bool CryptoHASH::initInput( )
    {
        printInfoMsg( std::string( "itauCryptLibSha2(), Inicio)" ) );
        if ( m_Loaded == false)
        {
            m_ptrDynamicLoading = dlopen( "libItauCryptLib.so", RTLD_LAZY );           
            if ( m_ptrDynamicLoading == NULL )
            {
                printInfoMsg ( std::string( "Erro no carregamento da biblioteca libItauCryptLib.so: " ) +  std::string( dlerror( ) ) );
                return( false );
            }
            printInfoMsg( std::string( "itauCryptLibSha2() dlopen (libItauCryptLib.so) - OK" ) );
            *( void** )( &m_ptrDoHash ) = dlsym( m_ptrDynamicLoading, "DoHash" );
            if ( m_ptrDynamicLoading == NULL )
            {
                printInfoMsg ( std::string( "Erro no carregamento da funcao DoHash: " ) +  std::string( dlerror( ) ) );
                dlclose( m_ptrDynamicLoading );
                m_ptrDynamicLoading = NULL;
                m_ptrDoHash = NULL;
                return( false );
            }
            m_Loaded = true;
        }
        return( true );
    }

    void CryptoHASH::printInput( const char l_msg[ ], long length )
    {
    	unsigned char l_buffer[ 1024 * 2  + 1 ];

        msgConv::TextConv::hexToAscii( l_buffer, sizeof( l_buffer ), reinterpret_cast<const unsigned char*>( l_msg ), length  );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "========= Buffer enviado para LIBCRYPTO =========" );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, reinterpret_cast<const char*>( l_buffer ), sizeof( l_buffer ) );
    }

    void CryptoHASH::sendInput( const char l_msg[ ], long length )
    {
        memset(m_OutputMsg, 0, sizeof( m_OutputMsg ));

        /* Gera o SHA2 */
        m_CodError = (* CryptoHASH::m_ptrDoHash)(
        		                                 ALG_SHA256,
        		                                 l_msg, 		/* [in] Dado para ser calculado o HASH                          */
        		                                 length, 		/* [in] Quantidade de d�gitos contidos na mensagem              */
        		                                 0, 			/* [in] Nao realiza convers�o para EBCDIC antes de cifrar       */
        		                                 0, 			/* [in] Nao ir� converter os dados para bin�rio antes de cifrar */
        		                                 m_OutputMsg 	/* [out] HASH Calculado                                         */
        		                                 );
    }

    void CryptoHASH::printOutput( )
    {
        unsigned char l_buffer[ sizeof( m_OutputMsg ) * 2 + 1 ];

        memset( l_buffer, 0, sizeof( l_buffer ) );

        msgConv::TextConv::hexToAscii( l_buffer, sizeof( l_buffer ), reinterpret_cast<const unsigned char*>( &m_OutputMsg ),  sizeof( m_OutputMsg ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "========= Buffer HASH recebido da LIBCRYPTO =========" );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, reinterpret_cast<const char*>( l_buffer ), sizeof( l_buffer ) );
    }

    bool CryptoHASH::checkOutput( )
    {
        std::string l_error;

        if( m_CodError )
        {
            switch( m_CodError )
            {
                case E_CRYPT_INVALID_PAN_SIZE:
                    l_error = std::string( "E_CRYPT_INVALID_PAN_SIZE");
                    break;
                case E_CRYPT_BUFFER_TOO_LARGE:
                    l_error = std::string( "E_CRYPT_BUFFER_TOO_LARGE");
                    break;
                case E_CRYPT_INVALID_BLOCK_SIZE:
                    l_error = std::string( "E_CRYPT_INVALID_BLOCK_SIZE");
                    break;
                case E_CRYPT_INVALID_JAVA_METHOD:
                    l_error = std::string( "E_CRYPT_INVALID_JAVA_METHOD");
                    break;
                case E_CRYPT_INVALID_ALGORITHM:
                    l_error = std::string( "E_CRYPT_INVALID_ALGORITHM");
                    break;
                case E_CRYPT_INVALID_PIN_SIZE:
                    l_error = std::string( "E_CRYPT_INVALID_PIN_SIZE");
                    break;
                case E_CRYPT_INVALID_HEX_VALUE:
                    l_error = std::string( "E_CRYPT_INVALID_HEX_VALUE");
                    break;
                case E_CRYPT_INCOMPATIBLE_ALGORITHM:
                    l_error = std::string( "E_CRYPT_INCOMPATIBLE_ALGORITHM");
                    break;
                case E_CRYPT_MEMORY_ALLOC:
                    l_error = std::string( "E_CRYPT_MEMORY_ALLOC");
                    break;
                default:
                    l_error = std::string( "DESCONHECIDO");
                    break;
            }
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, std::string( "========= Codigo de retorno recebido da LIBCRYPTO [" + std::string( l_error ) + "] =========" ).c_str() );
            return( false );
        }
        else
        {
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, std::string( "========= Codigo de retorno recebido da LIBCRYPTO [" + std::string( "00" ) + "] =========" ).c_str() );
            return( true );
        }
    }
    
    void CryptoHASH::printInfoMsg( const std::string &l_msg )
    {
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, std::string( "========= " + l_msg + " =========" ).c_str( ) );
    }

/// Nome do m�todo: setMsgLength
/// Descri��o: Define o tamanho da mensagem para criptografia
/// EF/ET: (ID230.840/AM231.211)
/// Hist�rico: [03/09/2018] - Eduardo De Souza - ET - AM231.211 - Implanta��o da do Release da Captura J09
///                                              EF - ID230.840 - Release da Captura J09
/// length = Tamanho da mensagem
    void CryptoHASH::setMsgLength( const long &length )
    {
        char msg[1024] = {0};

        msgLength = length;

        sprintf( msg, " - CryptoHASH: setMsgLength m_msgLength[%d]", msgLength );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, msg, sizeof( msg ) );
    }
}
