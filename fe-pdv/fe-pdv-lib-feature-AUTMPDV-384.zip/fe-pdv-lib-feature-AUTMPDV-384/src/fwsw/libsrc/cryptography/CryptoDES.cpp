#pragma once
#include <cstring>
#include <sstream>
#include <unistd.h>
#include <security.h>
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "msgConv/TextConv.hpp"
#include "cryptography/Crypto.hpp"
#include "cryptography/CryptoDES.hpp"

namespace cryptography
{
    CryptoDES::CryptoDES( )
    {
        m_key = std::string( "" );
    }
    
    CryptoDES::~CryptoDES( )
    {
    }

    void CryptoDES::setKeys( fieldSet::ConstFieldAccess &l_field )
    {
        if ( m_key.empty( ) == true )
        {
            m_key = selectTBSW0136( 4 );
        }
    }

    void CryptoDES::setKeys( const long &l_key )
    {
        m_key = selectTBSW0136( l_key );
    }


    void CryptoDES::receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_prefix, const std::string &l_sufix )
    {
        std::string l_msg;
        char l_buff[100];
        int l_pos = 0;

        for( int i = 0; i < sizeOutputMsg( ); i++ )
        {
            if( ( i % 2 ) != 0 )
            {
                l_buff[ l_pos ] = m_OutputMsg.message[ i ];
                l_pos++;
            }
        }
        l_buff[ l_pos ] = 0;
        l_msg = l_prefix + std::string( l_buff ) + l_sufix;;
        fieldSet::fscopy( l_field, l_msg.c_str( ), l_msg.length( ) );
        printOutput( l_msg );
    }

    void CryptoDES::receiveMsg( fieldSet::FieldAccess &l_field, const std::string &l_sufix )
    {
        std::string l_msg;
        
        l_msg = std::string( m_OutputMsg.message, sizeOutputMsg( ) ) + l_sufix;;
        fieldSet::fscopy( l_field, l_msg.c_str( ), l_msg.length( ) );
        printOutput( l_msg );
    }

    void CryptoDES::receiveMsg( fieldSet::FieldAccess &l_field )
    {
        std::string l_msg;
        
        l_msg = std::string( m_OutputMsg.message, sizeOutputMsg( ) );
        fieldSet::fscopy( l_field, l_msg.c_str( ), l_msg.length( ) );
        printOutput( l_msg );
    }

    void CryptoDES::receiveMsg( std::string &l_field )
    {
        l_field = std::string( m_OutputMsg.message, sizeOutputMsg( ) );
        printOutput( l_field );
    }

    bool CryptoDES::decriptyMsg( const std::string &l_msg )
    {
        initInput( );
        fillInput( l_msg );
        printInput( );
        sendInput( );
        printOutput( );
        return( checkOutput( ) );
    }
 
    void CryptoDES::initInput( )
    {
        memset( &m_InputMsg, ' ', sizeof( m_InputMsg ) );
        memcpy( m_InputMsg.command.header, "0001", sizeof( m_InputMsg.command.header ) );
        memcpy( m_InputMsg.command.command_code, "M2", sizeof( m_InputMsg.command.command_code ) );
        memcpy( m_InputMsg.command.mode_flag, "00", sizeof( m_InputMsg.command.mode_flag ) );
        memcpy( m_InputMsg.command.input_format_flag, "1", sizeof( m_InputMsg.command.input_format_flag ) );
        memcpy( m_InputMsg.command.output_format_flag, "1", sizeof( m_InputMsg.command.output_format_flag ) );
        memcpy( m_InputMsg.command.key_type, "00B", sizeof( m_InputMsg.command.key_type ) );
        memcpy( m_InputMsg.command.key, m_key.c_str( ), m_key.length( ) );
    }

    void CryptoDES::fillInput( const std::string &l_msg )
    {
        memcpy( m_InputMsg.command.message_length, "0010" , sizeof( m_InputMsg.command.message_length ) );
        memset( m_InputMsg.message, 0 , sizeof( m_InputMsg.message ) );
        memcpy( m_InputMsg.message, l_msg.c_str( ), sizeInputMsg( ) );
    }
    
    void CryptoDES::printInput( )
    {
        unsigned char l_buffer[ sizeof( INPUT_DES_MSG ) * 2  + 1 ];

        memset(l_buffer, 0, sizeof( l_buffer ) );
        msgConv::TextConv::hexToAscii( l_buffer, sizeof( l_buffer ), reinterpret_cast<const unsigned char*>( &m_InputMsg ), sizeof( m_InputMsg.command ) + sizeInputMsg( ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "========= Buffer DES enviada para o HSM =========" );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, reinterpret_cast<const char*>( l_buffer ), sizeof( l_buffer ) );
    }

    void CryptoDES::sendInput( )
    {
        security_direct( reinterpret_cast< char* >( &m_InputMsg ), sizeof( m_InputMsg ), reinterpret_cast< char* >( &m_OutputMsg ), sizeof( m_OutputMsg ) );
    }

    void CryptoDES::printOutput( )
    {
        unsigned char l_buffer[ sizeof( OUTPUT_MSG ) * 2 + 1 ];

        memset( l_buffer, 0, sizeof( l_buffer ) );
        msgConv::TextConv::hexToAscii( l_buffer, sizeof( l_buffer ), reinterpret_cast<const unsigned char*>( &m_OutputMsg ),  sizeof( m_OutputMsg.command ) + sizeOutputMsg(  ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "========= Buffer DES recebida do HSM =========" );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, reinterpret_cast<const char*>( l_buffer ), sizeof( l_buffer ) );
    }

    void CryptoDES::printOutput( const std::string &l_msg )
    {
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, std::string ( " Mensagem recebida do HSM[" + l_msg + "]" ).c_str( ) );
    }

    bool CryptoDES::checkOutput( )
    {
        char l_error[ 3 ];

        memset( l_error, 0, sizeof( l_error ) );
        strncpy( l_error, m_OutputMsg.command.error_code, sizeof ( m_OutputMsg.command.error_code ) );
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, std::string( "========= Codigo de retorno recebido do HSM [" + std::string( l_error ) + "] =========" ).c_str() );
        return( strncmp( l_error, "00", sizeof ( m_OutputMsg.command.error_code ) ) == 0 );
    }

    long CryptoDES::sizeInputMsg( )
    {
        std::stringstream l_stream;
        long l_size;
        
        l_stream << std::hex << std::string( m_InputMsg.command.message_length ).substr( 0, 4 );
        l_stream >> l_size;
        return( l_size );
    }

    long CryptoDES::sizeOutputMsg( )
    {
        std::stringstream l_stream;
        long l_size;
        
        l_stream << std::hex << std::string( m_OutputMsg.command.message_length ).substr( 0, 4 );
        l_stream >> l_size;
        return( l_size );
    }
}
