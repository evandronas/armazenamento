/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, 
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o de 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#include <cstdio>
#include <exception>
#include "base/GenException.hpp"
#include "base/Identificable.hpp"

namespace base
{
	Identificable::Identificable( )
	{
	}
	Identificable::~Identificable( )
	{
	}
	Identificable& Identificable::setLabel( const std::string& a_label )
	{
		m_label = a_label;
		return *this;
	}
	Identificable& Identificable::setDescription( 
	    const std::string& a_description )
	{
		m_description = a_description;
		return *this;
	}
	Identificable& Identificable::setVersion( const std::string& a_version )
	{
		m_version = a_version;
		return *this;
	}
	const std::string& Identificable::label( ) const
	{
		return m_label;
	}
	const std::string& Identificable::description( ) const
	{
		return m_description;
	}
	const std::string& Identificable::version( ) const
	{
		return m_version;
	}
	bool Identificable::startConfiguration( const configBase::Tag* a_tag )
	{
		return false;
	}
}//namespace base

