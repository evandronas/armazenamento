/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, 
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o de 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#include "base/GenException.hpp"

namespace base
{
	GenException::GenException( )
	{
	}
	GenException::GenException( const std::string& a_functionName, 
	                            const std::string& a_what )
	{
		m_functionName = a_functionName;
		m_what = a_what;
	}
	GenException::~GenException( )
	{
	}
	GenException& GenException::setFunctionName( 
	    const std::string& a_functionName )
	{
		m_functionName = a_functionName;
		return *this;
	}
	GenException& GenException::setWhat( const std::string& a_what )
	{
		m_what = a_what;
		return *this;
	}
	const char* GenException::functionName( ) const
	{
		return m_functionName.c_str( );
	}
	const char* GenException::what( ) const
	{
		return m_what.c_str( );
	}
}//namespace base

