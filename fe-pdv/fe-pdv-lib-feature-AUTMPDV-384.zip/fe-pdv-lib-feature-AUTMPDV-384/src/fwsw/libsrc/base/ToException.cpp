/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o: Gerenciador de log e debug com levels em runtime
/ Conte�do: Definicao da classe ToException
/ Autor: 246670 - Renato de Camargo
/ Data de Cria��o: 2019, 2 de abril
/ -------------------------------------------------------------------------------------------------
*/
#include "base/ToException.hpp"

namespace base
{
	/// ToException::ToException
	/// Construtor
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial 
	ToException::ToException( )
	{
	}
	
	/// ToException::ToException
	/// Construtor
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial 
	ToException::ToException( const std::string& paramFunctionName, 
	                            const std::string& paramWhat,
								const int paramOracleError )
	{
		functionName = paramFunctionName;
		what = paramWhat;
		oracleError = paramOracleError;
	}
	
	/// ToException::~ToException
	/// Destrutor
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial 
	ToException::~ToException( )
	{
	}
	
	/// ToException::SetFunctionName
	/// Setter para o nome da fun��o em que ocorreu a exception
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial
	ToException& ToException::SetFunctionName( 
	    const std::string& paramFunctionName )
	{
		functionName = paramFunctionName;
		return *this;
	}

	/// ToException::SetFunctionName
	/// Setter para a descri��o da exception
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial
	ToException& ToException::SetWhat( const std::string& paramWhat )
	{
		what = paramWhat;
		return *this;
	}
	
	/// ToException::SetFunctionName
	/// Setter para o n�mero do erro Oracle que ocorreu
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial
	ToException& ToException::SetOracleError( const int paramOracleError )
	{
		oracleError = paramOracleError;
		return *this;
	}	
	
	/// ToException::SetFunctionName
	/// Getter para o nome da fun��o que ocorreu a Exception
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial
	const char* ToException::FunctionName( ) const
	{
		return functionName.c_str( );
	}
	
	/// ToException::SetFunctionName
	/// Getter para a descri��o da Exception
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial
	const char* ToException::What( ) const
	{
		return what.c_str( );
	}
	
	/// ToException::SetFunctionName
	/// Getter para o n�mero do erro Oracle que ocorreu
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial
	const int ToException::OracleError()
	{
		return oracleError;
	}

	/// ToException::GenAssert
	/// Generate Exception for assert condition
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial	
	inline void ToException::GenAssert( bool condition, const std::string& paramFunctionName, const std::string& paramWhat, const int paramOracleError )
	{
		if ( !condition )
		{
			throw ToException( paramFunctionName, paramWhat, paramOracleError );
		}
	}
	
	/// ToException::GenAssertPtr
	/// Generate Exception for assert condition with message
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [02/04/2019] - EAK 1390 - Vers�o inicial	
	inline void ToException::GenAssertPtr( const void* ptr, const std::string& paramFunctionName, const std::string& paramWhat, const int paramOracleError )
	{
		if ( ptr == 0 )
		{
			throw ToException( paramFunctionName, paramWhat, paramOracleError );
		}
	}	
}//namespace base

