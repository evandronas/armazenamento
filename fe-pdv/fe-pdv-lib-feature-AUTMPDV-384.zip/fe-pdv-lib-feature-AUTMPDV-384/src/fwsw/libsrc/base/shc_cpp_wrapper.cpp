/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, 
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o de 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#include <shc.h>
#include <rules.h>
#include <shcdef.h>
#include "base/shc_cpp_wrapper.hpp"
#include <ShcKeyHelper.h>
#include <ShcAppBase.h>
#include <multi_institution.h>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "IssProfile.h"
namespace base
{
	int shc_locate_bin( struct shcpkg **a_shcpkg, const char* a_institutionId,
                    	const char* a_networdId )
	{
		char l_cstrInstId[256];
		char l_cstrNetworkId[256];
		snprintf( l_cstrInstId, sizeof l_cstrInstId, "%s", a_institutionId );
		snprintf( l_cstrNetworkId, sizeof l_cstrNetworkId, "%s", a_networdId );
		struct ::shcpkg *l_shcpkg;
		int l_locRet = ::shc_locate_bin( &l_shcpkg, l_cstrInstId, 
		                                  l_cstrNetworkId );
		*a_shcpkg =( struct shcpkg* )
		l_shcpkg;
		return l_locRet;
	}
	
	void disable_shc_log( )
	{
		/* Disable txn logging at Shc in shclog */
		for ( int l_shc_bin_rec = 0; l_shc_bin_rec < shcNumberOfText; ++l_shc_bin_rec )
			::shcBinPkg[l_shc_bin_rec].bin.bintype |= SH_NO_LOG;
	}	
	
	//void locate_extbin (const char *txnSrc, const char *pan, const int msgType, const char *deviceType, const long pcode, const int hasPIN, char *issuerBin )
	void locate_extbin (const char *txnSrc, const char *pan, const int msgType, const char *deviceType, const long pcode, const int hasPIN, char issuerBin[11] )
	{
		
		//logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "--->locate_extbin" ); 												 
		
		IssuerInfo issuerInfo;
		
		if (shcApp == NULL)
		{
		  shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
		}
		shcApp->issProfileObj->locate_extbin(txnSrc, pan, msgType, deviceType, pcode, hasPIN, issuerInfo);
    
           //char buf[50];
           //sprintf(buf, "---issuerInfo.getIssuerBin=[%s]", issuerInfo.getIssuerBin( ) );
           //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, buf ); 												 
										 
           OCString locate_port;
           locate_port += issuerInfo.getIssuerBin();
           if ( locate_port.length() > 0 ) 
           {
            sprintf(issuerBin, "%s\0", issuerInfo.getIssuerBin( ) );
            //sprintf(buf, "--->>>Changed issuerBin=[%s]", issuerBin );
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, buf ); 												 
           }
 							 
  }//locate_extbin
  
}//namespace base

