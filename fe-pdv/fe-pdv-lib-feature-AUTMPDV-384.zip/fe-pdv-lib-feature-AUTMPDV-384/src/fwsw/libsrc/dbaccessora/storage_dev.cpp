/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "dbaccess/storage_dev.hpp"
namespace dbaccess
{
	connection *storage_dev::get_next( )
	{
		throw base::GenException( __FUNCTION__, "Invalid call to storage_dev::get_next( )" );
	}
}

