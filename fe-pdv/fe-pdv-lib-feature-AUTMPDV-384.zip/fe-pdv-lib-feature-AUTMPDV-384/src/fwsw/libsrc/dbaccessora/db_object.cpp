/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 06/05/2019
Empresa  : Rede
Descricao: Adicionando controle para dropar transa��o e refazer conex�o dbm no caso de timeout com o banco
ID       : AM 248.335
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 28/05/2019
Empresa  : Rede
Descricao: Adicionando controle para quando ocorrer timeout no commit/rollback
ID       : AM 249.438
*************************************************************
Sigla: SW - FE-POS
Descricao: EAK-1638 - Adicionando controle de Timeout no Execute
Autor: Renato de Camargo
Data de Criacao: 10/07/2019
*************************************************************
Sigla: SW - FE-POS
Descricao: EAK-1834 - [PacoteEstabilidade] Diferencia��o de erros em BD Local/Remoto
Autor: Renato de Camargo
Data de Criacao: 07/10/2019
*************************************************************
Autor    : Daniel Nava
Data     : 03/12/2019
Empresa  : Leega
Descricao: Altera��o dos m�todos prepare, execute e fetch para conter par�metro opcional (se usa timeout de dispatcher)
ID       : EAK-1880
*************************************************************
*/

#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "base/ToException.hpp"
#include "dbaccess/db_object.hpp"
#include "dbaccess/single_db.hpp"
#include "dataManip/DataManip.hpp"
#include "logger/DebugWriter.hpp"
#include "ShmMonDb.hpp"

namespace dbaccess
{
    db_object::db_object( )
    : stdev( *single_db::get_instance( ) )
    {
        stmt = NULL;
        is_prepared = false;
        is_executed = false;
        conn = stdev.get_first( );
        rec_num = 0;
        result_is_valid = false;
    }
    db_object::db_object( storage_dev &stdev )
    : stdev( stdev )
    {
        stmt = NULL;
        is_prepared = false;
        is_executed = false;
        conn = stdev.get_first( );
        rec_num = 0;
        result_is_valid = false;
    }
    db_object::~db_object( )
    {
        release_bindings( );
        release_statement( );
    }
    bool db_object::is_valid( ) const
    {
        if ( conn != NULL && stmt != NULL )
            return true;
        return false;
    }
    void db_object::handle_fetch( )
    {
        // Some data types are not supported by DBM low level API. Ie: String
        // So here is where we handle this data types any time
        // a new fetch( ) is performed for this resultset.
        handle_String_out( );
    }
    void db_object::prepare( statement *pstmt )
    {	
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        if ( stmt != NULL && stmt != pstmt )
        {
            release_bindings( );
            release_statement( );
        }
        stmt = pstmt;
        stmt->prepare( get_sql_statement( ) );
		// Setar SQL para timeout
		stmt->SetSql( get_sql_statement( ) );
        is_prepared = true;
    }

/// prepare
/// Efetua prepare
/// EF/ET: EAK-1880
/// Hist�rico:
/// 03/12/2019 - EAK-1880 - Inclusao da flag nas chamadas ao banco para utiliza��o do timeout diferenciado
    void db_object::prepare( bool isDispatcher )
    {
		if ( stmt != NULL )
		{
			release_bindings( );
			release_statement( );
		}
        stmt = new statement( *conn );
        if ( stmt == NULL )
            throw base::GenException( __FUNCTION__, " unable to get new statement" );
        stmt->prepare( get_sql_statement( ), isDispatcher );
		// Setar SQL para timeout
		stmt->SetSql( get_sql_statement( ) );
        is_prepared = true;
    }
    void db_object::bind_resultset( )
    {
        // Call custom bind from derived classes
        bind_columns( );
    }
    void db_object::bind_columns( )
    {
    }
    void db_object::bind_parameters( )
    {
        // Call custom bind from derived classes
        handle_parameters( );
    }
    void db_object::handle_parameters( )
    {
        handle_String_in( );
    }
    void db_object::bind( const unsigned int pos, int &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, char &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, unsigned int &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, unsigned char &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, long &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, unsigned long &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, float &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, double &var )
    {
		this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, dbm_datetime_t *var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, oasis_dec_t &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, sw_date_t &var )
    {
        this->bind( pos, var, NULL );
    }
    void db_object::bind( const unsigned int pos, int &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, char &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, char *var, const size_t capacity )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, capacity-1, status, NULL );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, std::string &var, const size_t capacity )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        char *str = get_buff( var, capacity + 1 );
        strncpy(str, var.c_str(), capacity);
        register_buff_out( var, str, capacity );
        register_buff_in( var, str, capacity );
        stmt->bind( pos, str, capacity, status, NULL );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, dbm_datetime_t *var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[var] = status;
    }
    void db_object::bind( const unsigned int pos, unsigned int &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, unsigned char &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, long &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, unsigned long &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, float &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, double &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, oasis_dec_t &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    void db_object::bind( const unsigned int pos, sw_date_t &var, int *ind_null )
    {
        base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
        int *status = new int;
        stmt->bind( pos, var, status, ind_null );
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
    }
    bool db_object::is_null( int &var ) const
    {
        return is_null( ( void* ) &var );
    }
    bool db_object::is_null( char &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( char *var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( std::string &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( dbm_datetime_t *var ) const
    {
        return is_null( ( void* )var );
    }
    bool db_object::is_null( unsigned int &var ) const
    {
        return is_null( ( void* ) &var );
    }
    bool db_object::is_null( unsigned char &var ) const
    {
        return is_null( ( void* ) &var );
    }
    bool db_object::is_null( long &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( unsigned long &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( float &var ) const
    {
        return is_null( ( void* ) &var );
    }
    bool db_object::is_null( double &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( oasis_dec_t &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( sw_date_t &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( void *ptr ) const
    {
        base::genAssert( vstatus_by_ptr.find( ptr ) != vstatus_by_ptr.end( ), __FUNCTION__, "Pointer not found" );
        int *status =( *vstatus_by_ptr.find( ptr ) ).second;
        bool res =  *status ==( int )DBM_NULL_DATA;
        return res;
    }
    void db_object::release_bindings( )
    {
        // First call do_release_bindings( ) from derived classes
        do_release_bindings( );
        // Status bindings. Variables have to be freed
        status_t::iterator vsit = vstatus.begin( );
        status_t::iterator vsend = vstatus.end( );
        for ( ; vsit != vsend; vsit ++ )
            delete( *vsit ).second;
        vstatus.clear( );
        vstatus_by_ptr.clear( );
        // String bindings. Buffers have to be freed
        string_bindings_t::iterator it = str_binds_in.begin( );
        string_bindings_t::iterator end = str_binds_in.end( );
        for ( ; it != end; it ++ )
        {
            delete[]( (*it ).second )->ptr;
            delete( *it ).second;
        }
        string_bindings_t::iterator oit = str_binds_out.begin( );
        string_bindings_t::iterator oend = str_binds_out.end( );
        for ( ; oit != oend; oit ++ )
        {
            // Nao pode apagar o [] pois ele e excluido anteriormente e possuem o mesmo endereco
            // delete[]( ( *oit ).second )->ptr;
            delete( *oit ).second;
        }
        str_binds_in.clear( );
        str_binds_out.clear( );
    }
    void db_object::release_statement( )
    {
        // First call do_release_statement( ) from derived classes
        do_release_statement( );
        if ( stmt != NULL )
        {
            delete stmt;
            stmt = NULL;
        }
        is_prepared = false;
        is_executed = false;
        rec_num = 0;
    }

/// execute
/// Efetua execute
/// EF/ET: EAK-1880
/// Hist�rico:
/// 03/12/2019 - EAK-1880 - Inclusao da flag nas chamadas ao banco para utiliza��o do timeout diferenciado
    void db_object::execute( bool isDispatcher )
    {
        if ( ! is_prepared )
            throw base::GenException( __FUNCTION__, ": prepare( ) method must be invoked before this method" );
        if ( is_executed )
        {
            // Remove all pending results
            stmt->close( );
        }
        bind_parameters( );
        clean_output_bindings( );

		try
		{
			stmt->execute( isDispatcher );
		} 
        catch( base::ToException e )
		{ 
			this->TimeoutErrorHandler(e);
		}
		
        bind_resultset( );
        is_executed = true;
	}

/// fetch
/// Efetua fetch
/// EF/ET: EAK-1880
/// Hist�rico:
/// 03/12/2019 - EAK-1880 - Inclusao da flag nas chamadas ao banco para utiliza��o do timeout diferenciado
    bool db_object::fetch( bool isDispatcher )
    {
        if ( ! is_executed )
            throw base::GenException( __FUNCTION__, ": execute( ) method must be invoked before this method" );
        result_is_valid = stmt->fetch( isDispatcher );
        if ( result_is_valid )
            handle_fetch( );
        rec_num ++;
        return result_is_valid;
    }
    void db_object::close_fetch( )
    {
        release_bindings( );
        release_statement( );
        result_is_valid = false;
        rec_num = 0;
    }
    bool db_object::stmt_is_prepared( )
    {
        return is_prepared;
    }
    bool db_object::stmt_is_executed( )
    {
        return is_executed;
    }
    bool db_object::resultset_is_valid( )
    {
        return result_is_valid;
    }
    statement *db_object::get_stmt( )
    {
        return stmt;
    }
    storage_dev *db_object::get_stdev( )
    {
        return &stdev;
    }
    connection *db_object::get_connection( )
    {
        return conn;
    }
    void db_object::commit( )
    {
		try
		{	
			stmt->commit( );
		} 
        catch( base::ToException e )
		{ 
			this->TimeoutErrorHandler(e);
		}
    }
    void db_object::rollback( )
    {
		try
		{
			stmt->rollback( );
		} 
        catch( base::ToException e )
		{ 
			this->TimeoutErrorHandler(e);
		}
    }
    void db_object::do_release_bindings( )
    {
        // Do Nothing, to be implemented by derived classes
    }
    void db_object::do_release_statement( )
    {
        // Do Nothing, to be implemented by derived classes
    }
    char *db_object::get_buff( const std::string &var, const size_t capacity )
    {
        char *str;
        str = new char[capacity];
        if ( str == 0 )
            throw base::GenException( __FUNCTION__, " Out of memory trying to allocate a new buffer" );
        return str;
    }
    void db_object::register_buff_out( std::string &var, char *str, size_t len )
    {
        ptr_len_t *node = new ptr_len_t;
        if ( node == 0 )
            throw base::GenException( __FUNCTION__, " Out of memory trying to allocate a new buffer" );
        node->allocated_len = len;
        node->ptr = str;
        str_binds_out[&var]    = node;
    }
    void db_object::register_buff_in( std::string &var, char *str, size_t len )
    {
        ptr_len_t *node = new ptr_len_t;
        if ( node == 0 )
            throw base::GenException( __FUNCTION__, " Out of memory trying to allocate a new buffer" );
        node->allocated_len = len;
        node->ptr = str;
        str_binds_in[&var] = node;
    }
    void db_object::handle_String_out( )
    {
        // String bindings.
        string_bindings_t::iterator it = str_binds_out.begin( );
        string_bindings_t::iterator end = str_binds_out.end( );
        for ( ; it != end; it ++ )
            ( *( (*it ).first ) ) = ( (*it ).second )->ptr;
    }
    void db_object::clean_output_bindings( )
    {
        // String bindings.
        string_bindings_t::iterator it = str_binds_out.begin( );
        string_bindings_t::iterator end = str_binds_out.end( );
        for ( ; it != end; it ++ )
            memset( (( *it ).second )->ptr, 0, (( *it ).second )->allocated_len );
    }
    void db_object::handle_String_in( )
    {
        // String bindings.
        string_bindings_t::iterator it = str_binds_in.begin( );
        string_bindings_t::iterator end = str_binds_in.end( );
        for ( ; it != end; it ++ )
        {
            size_t len =( (
            *it ).second )->allocated_len;
            strncpy( (( *it ).second )->ptr, (( *it ).first )->c_str( ), len );( (
            *it ).second )->ptr[len]
            = '\0';
        }
    }
    // The following function is meant to be overriden by derived
    // classes which perform parameter bindings for stored function calls
    // In those cases, the first parameter binding is the stored function' return code itself.
    int db_object::translate_pos( int pos ) const
    {
        return pos;
    }
	
	void db_object::TimeoutErrorHandler(base::ToException ex)
	{
		std::stringstream errorMsg;
		char localRemoto[20] = {0};
		char msgLog[400] = {0};
		
		sprintf( localRemoto, "%s", ( conn->IsRemoteStatement() ? "Remoto" : "Local" ));
		
		ShmMonDb * shm = ShmMonDb::getInstance();
		syslg("Shm Timeout = RC[%d]\n", ( conn->IsRemoteStatement() ? shm->IncrementRemoteTimeout(0) : shm->IncrementLocalTimeout(0)));
		
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, " ============== [ ORACLE TIMEOUT ERROR - BEGIN ] ============== " );
		
		snprintf(msgLog,sizeof(msgLog),"ERROR: ORACLE Timeout %s => %s", localRemoto, ex.What() );
		syslg(msgLog);
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, msgLog );			
		
		errorMsg << " === ERROR: [" << ex.What() << "]";
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, errorMsg.str().c_str() );
		
		// Limpando a variavel sstream
		errorMsg.str(std::string());
		
		errorMsg << " === CODE: [" << ex.OracleError() << "]";
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, errorMsg.str().c_str() );		
		
		// Limpando a variavel sstream
		errorMsg.str(std::string());
		
		errorMsg << " === FUNCTION: [" << ex.FunctionName() << "]";
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, errorMsg.str().c_str() );	

		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, " /============== [ ORACLE TIMEOUT ERROR - END ] ==============/ " );
		
		// Faz a mensagem ser dropada na volta pro StandardTrxEngine
		dataManip::DataManip::SetDbDropTrx(true);

		// Throw na GenException que eh capturada num nivel acima, para interromper processamento do plugin
		throw base::GenException();
	}	
	
	/// db_object::SetRemoteStatement
	/// Setar que querie eh remota
	/// EF/ET: EAK-1834
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial		
	void db_object::SetRemoteStatement()
	{
		conn->SetRemoteStatement();
	}

	/// db_object::SetLocalStatement
	/// Setar que local eh remota
	/// EF/ET: EAK-1834
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial		
	void db_object::SetLocalStatement()
	{
		conn->SetLocalStatement();
	}
	
	/// db_object::IsRemoteStatement
	/// Retorna se Statement for Remoto
	/// EF/ET: EAK-1834
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial	
	bool db_object::IsRemoteStatement()
	{
		return conn->IsRemoteStatement();
	}

	/// db_object::UseForUpdate
	/// Retorna se Statement for Remoto
	/// EF/ET: EAK-1847
	/// Historico: [Data] - ET - Descricao
	/// [07/10/2019] - Versao inicial	
	bool db_object::UseForUpdate() {
		return conn->UseForUpdate();
	}
}
