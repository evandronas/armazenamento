/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-WEB
/ Descricao:
/ Conteudo:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Criacao: 2012, 21 de julho
/ Historico Mudancas: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/                     2013, 26 de marco, t698224, Raphael Gomes/ t694450, Lauro Sanches:
/                         - Inclusao de metodos set/get para atributo table_name
/ -------------------------------------------------------------------------------------------------
/*
-------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1847 - [PacoteEstabilidade] Desativa��o do uso do "FOR UPDATE"
/ Autor: Renato de Camargo
/ Data de Criacao: 03/10/2019
-------------------------------------------------------------------------------------------------
Autor    : Daniel Nava
Data     : 03/12/2019
Empresa  : Leega
Descricao: Altera��o do m�todo prepare para conter par�metro opcional (se usa timeout de dispatcher)
ID       : EAK-1880
*************************************************************
*/
#pragma once
#include "base/GenException.hpp"
#include "dbaccess/table.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess
{
	table::table( storage_dev &stdev )
	: db_object( stdev )
	{
		update_already_prepared = false;
		delete_already_prepared = false;
		insert_already_prepared = false;
		upd_stmt = NULL;
		ins_stmt = NULL;
		del_stmt = NULL;
		operation = NONE;
	}
	table::table( )
	{
		update_already_prepared = false;
		delete_already_prepared = false;
		insert_already_prepared = false;
		upd_stmt = NULL;
		ins_stmt = NULL;
		del_stmt = NULL;
		operation = NONE;
	}
	table::~table( )
	{
		release_update_statement( );
		release_insert_statement( );
		release_delete_statement( );
		close_fetch( );
	}
	void table::update( )
	{
		update( FLAG_NON_FORCE_FOR_UPDATE );
	}
	void table::update( int flag )
	{
		if ( stmt_is_prepared( ) && stmt_is_executed( ) && resultset_is_valid( ) )
		{
			set_operation( UPDATE );
			if ( ! update_already_prepared )
				prepare_update( flag );
			handle_bindings( );
			execute_update( );
		}
		else
			throw base::GenException( __FUNCTION__, " cannot perform an update without a valid resultset" );
	}
	void table::delete_record( )
	{
		if ( stmt_is_prepared( ) && stmt_is_executed( ) && resultset_is_valid( ) )
		{
			set_operation( DELETE );
			if ( ! delete_already_prepared )
				prepare_delete( );
			execute_delete( );
		}
		else
			throw base::GenException( __FUNCTION__, " cannot perform an update without a valid resultset" );
	}
	void table::insert( )
	{
		if ( ! insert_already_prepared )
		{
			// Insert needs the query to be also prepared
			if ( ! stmt_is_prepared( ) )
			{
				set_operation( SELECT );
				db_object::prepare( );
				bind_resultset( );
			}
			prepare_insert( );
		}
		handle_bindings( );
		execute_insert( );
	}
	std::string table::get_sql_statement( )
	{
		std::string sql;
		switch ( get_operation( ) )
		{
			case SELECT:
			sql = get_sql_select( );
			break;
			case INSERT:
			sql = get_sql_insert( );
			break;
			case UPDATE:
			sql = get_sql_update( );
			break;
			case DELETE:
			sql = get_sql_delete( );
			break;
			default:
			// Invalid operation
			throw base::GenException( __FUNCTION__, " Error. Invalid operation" );
		}
		return sql;
	}
	std::string table::get_sql_select( )
	{
		if ( query_fields.empty( )
		||
		table_name.empty( ) )
		throw base::GenException( __FUNCTION__, "Error. table was not properly initialized" );
		std::string sql = "SELECT ";
		sql += query_fields + " FROM ";
		sql += table_name;
		if ( !where_condition.empty( ) )
		sql += std::string( " WHERE " ) + where_condition;
		sql += update_addendum;
		return sql;
	}
	std::string table::get_sql_insert( )
	{
		if ( query_fields.empty( )
		||
		table_name.empty( ) )
		throw base::GenException( __FUNCTION__, "Error. table was not properly initialized" );
		std::string sql = "INSERT INTO ";
		sql += table_name + "( " + query_fields + " ) VALUES( ";
		sql += get_insert_values_string( query_fields ) + " )";
		return sql;
	}
	void table::prepare_update( )
	{
		prepare_update( FLAG_NON_FORCE_FOR_UPDATE );
	}
	void table::prepare_update( int flag )
	{
		std::string sqlUpdate = get_sql_update();

		
		
		if ( upd_stmt != NULL )
		{
			release_update_statement( );
		}
		upd_stmt = new statement( *get_connection( ) );
		if ( upd_stmt == NULL )
		throw base::GenException( __FUNCTION__, " unable to get new statement" );
		
		if( conn->UseForUpdate() || flag == FLAG_FORCE_FOR_UPDATE ) 
			upd_stmt->prepare_positioned( get_stmt( ), (const std::string) sqlUpdate );
		else
		{
			sqlUpdate += " where ";
			sqlUpdate += where_condition;		
			upd_stmt->prepare( sqlUpdate );
		}
			
		bind_params( );
		update_already_prepared = true;
	}
	void table::prepare_delete( )
	{
		std::string sqlDelete = get_sql_delete( );
		
		if ( upd_stmt != NULL )
		{
			release_delete_statement( );
		}
		del_stmt = new statement( *get_connection( ) );
		if ( del_stmt == NULL )
		throw base::GenException( __FUNCTION__, " unable to get new statement" );
		if( conn->UseForUpdate())
			del_stmt->prepare_positioned( get_stmt( ), sqlDelete );
		else {
			sqlDelete += " where ";
			sqlDelete += where_condition;			
			del_stmt->prepare( sqlDelete );
		}
		delete_already_prepared = true;
	}
	void table::prepare_insert( )
	{
		if ( ins_stmt != NULL )
		{
			release_insert_statement( );
		}
		ins_stmt = new statement( *get_connection( ) );
		if ( ins_stmt == NULL )
		throw base::GenException( __FUNCTION__, " unable to get new statement" );
		set_operation( INSERT );
		ins_stmt->prepare( get_sql_insert( ) );
		bind_params( );
		insert_already_prepared = true;
	}
	std::string table::get_sql_update( )
	{
		if ( query_fields.empty( )
		||
		table_name.empty( ) )
		throw base::GenException( __FUNCTION__, " Error. table was not properly initialized" );
		std::string sql = "UPDATE ";
		sql += table_name;
		sql += " SET ";
		sql += parse_fields_for_update( query_fields );
		return sql;
	}
	std::string table::get_sql_delete( )
	{
		if ( query_fields.empty( )
		||
		table_name.empty( ) )
		throw base::GenException( __FUNCTION__, " Error. table was not properly initialized" );
		std::string sql = "DELETE ";
		sql += table_name;
		return sql;
	}
	void table::execute_update( )
	{
		if ( ! update_already_prepared )
		throw base::GenException( __FUNCTION__, ": prepare( ) method must be invoked before this method" );
		upd_stmt->execute( );
	}
	void table::execute_delete( )
	{
		if ( ! delete_already_prepared )
		throw base::GenException( __FUNCTION__, ": prepare( ) method must be invoked before this method" );
		del_stmt->execute( );
	}
	void table::execute_insert( )
	{
		if ( ! insert_already_prepared )
		throw base::GenException( __FUNCTION__, ": prepare( ) method must be invoked before this method" );
		ins_stmt->execute( );
	}
	void table::close_fetch( )
	{
		// Master statement is about to be deleted, invalidate all statements.
		release_update_statement( );
		// Execute base class member function
		db_object::close_fetch( );
	}
	void table::do_release_bindings( )
	{
		// Nothing to do.
	}
	void table::do_release_statement( )
	{
		release_update_statement( );
		release_delete_statement( );
		release_insert_statement( );
	}
	void table::release_update_statement( )
	{
		if ( upd_stmt != NULL )
		{
			delete upd_stmt;
			upd_stmt = NULL;
		}
		update_already_prepared = false;
	}
	void table::release_delete_statement( )
	{
		if ( del_stmt != NULL )
		{
			delete del_stmt;
			del_stmt = NULL;
		}
		delete_already_prepared = false;
	}
	void table::release_insert_statement( )
	{
		if ( ins_stmt != NULL )
		{
			delete ins_stmt;
			ins_stmt = NULL;
		}
		insert_already_prepared = false;
	}
	void table::bind_params( )
	{
		if ( operation == UPDATE )
		upd_stmt->positioned_upd_bind( get_stmt( ) );
		else
		{
			// should be INSERT
			ins_stmt->positioned_upd_bind( get_stmt( ) );
		}
	}
	void table::prepare_for_update( )
	{
		prepare_for_update( FLAG_NON_FORCE_FOR_UPDATE );
	}
	void table::prepare_for_update( int flag )
	{
		set_operation( SELECT );
		
		// Efetua teste se deve utilizar for update ou apenas um select simples
		if( UseForUpdate() || flag == FLAG_FORCE_FOR_UPDATE )
			update_addendum = " FOR UPDATE";
		else
			update_addendum = "";
		
		db_object::prepare( );
	}	
	std::string table::parse_fields_for_update( const std::string &query_fields ) const
	{
		std::string update_string;
		int query_len = query_fields.length( );
		int init_pos = 0;
		for ( int pos = 0; pos <= query_len; pos ++ )
		{
			if ( query_fields[pos] == ',' || pos == query_len )
			{
				// Put a new field into update statement
				// If this is not the first field in the statement, put a ',' first.
				if ( !update_string.empty( ) )
					update_string += ", ";
				int field_name_len = pos - init_pos;
				update_string += std::string( query_fields, init_pos, field_name_len );
				update_string += " = ?";
				init_pos = pos + 1;
				// Where the next field name starts
			}
		}
		if ( update_string.empty( ) )
			throw base::GenException( __FUNCTION__, " Cannot parse query fields" );
		return update_string;
	}
	std::string table::get_insert_values_string( const std::string &query_fields ) const
	{
		std::string values_string;
		int query_len = query_fields.length( );
		int init_pos = 0;
		for ( int pos = 0; pos <= query_len; pos ++ )
		{
			if ( query_fields[pos] == ',' || pos == query_len )
			{
				// Put a new field into update statement
				// If this is not the first field in the statement, put a ', ' first.
				if ( !values_string.empty( ) )
				values_string += ", ";
				values_string += " ?";
				init_pos = pos + 1;
				// Where the next field name starts
			}
		}
		if ( values_string.empty( ) )
			throw base::GenException( __FUNCTION__, " Cannot parse query fields" );
		return values_string;
	}
	void table::set_operation( table::operation_t op )
	{
		operation = op;
	}
	table::operation_t table::get_operation( )
	{
		return operation;
	}

/// prepare
/// Efetua prepare
/// EF/ET: EAK-1880
/// Hist�rico:
/// 03/12/2019 - EAK-1880 - Inclus�o da flag se � dispatcher
	void table::prepare( bool isDispatcher )
	{
		// This can only be called from a class user, so it's assumed that a read-only
		// query is about to be executed.
		update_addendum = "";
		set_operation( SELECT );
		db_object::prepare( isDispatcher );
	}
	void table::handle_bindings( )
	{
		// Handles unsuported data types by DBM low level API
		handle_String_in( );
	}

    void table::setTableName( const std::string tbName )
    {
        table_name = tbName;
    }
    
    const std::string table::getTableName() const
    {
        return table_name;
    }

	// getSqlDump
	// Retorna o dump de acordo com a operacao (UPDATE ou INSERT) que sera realizada no banco de dados
	// EF/ET: 44179
	// Historico: [06/10/2014] - 44179 - Release I de 2014
	std::string table::getSqlDump()
	{
		if ( operation == UPDATE && update_already_prepared && upd_stmt )
		{
			handle_bindings( );
			return upd_stmt->get_sql_dump( get_stmt( ) );
		}
		else if ( operation == INSERT && insert_already_prepared && ins_stmt )
		{
			handle_bindings( );
			return ins_stmt->get_sql_dump( get_stmt( ) );
		}
		
		return std::string( "" );
	}
}


