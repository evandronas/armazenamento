#pragma once
#include "base/GenException.hpp"
#include "dbaccess/checkConnection.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <unistd.h> 

#define DELAY_BD_KEEPALIVE        600 //10min

namespace dbaccess
{
    checkConnection::checkConnection()
    {
        query_fields = "1";
        table_name = "dual";
        lastCheck = time(0);
        currentCheck = time(0);

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    checkConnection::~checkConnection()
    {
    }

    void checkConnection::resetTimer() {
        lastCheck = time(0);
    }

    int checkConnection::keepAlive() {
        currentCheck = time(0);

        if (currentCheck > lastCheck + DELAY_BD_KEEPALIVE) {
            if (! check()) {
                return CHECK_ERR_ACCESS_BD_FAILURE;
            }
            resetTimer();
        }

        return CHECK_ERR_SUCCESS;
    }

    bool checkConnection::check()
    {
        prepare();

        if (! is_valid()) {
            return false;
        }

        execute();

        if (! fetch()) {
            return false;
        }

        return true;
    }
}//namespace dbaccess_common
