/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "dbaccess/stfunc.hpp"
namespace dbaccess
{
	stfunc::stfunc( storage_dev &stdev, const std::string &funcname )
	: db_object( stdev )
	{
		function = get_funcname( funcname );
		retval_binding_type = NONE;
		parameter_binding_exists = false;
		init( );
	}
	stfunc::stfunc( const std::string &funcname )
	{
		function = get_funcname( funcname );
		retval_binding_type = NONE;
		parameter_binding_exists = false;
		init( );
	}
	void stfunc::init( )
	{
		// In order to handle this kind of bindings, a new statement must be allocated for db_object, // so that all bindings made before "prepare" will remain.
		if ( stmt != NULL )
		{
			release_bindings( );
			release_statement( );
		}
		stmt = new statement( *conn );
	}
	std::string stfunc::get_funcname( const std::string &fname )
	{
		// Remove all invalid chars.( ), *;
		// TODO
		return fname;
	}
	stfunc::~stfunc( )
	{
	}
	std::string stfunc::get_sql_statement( )
	{
		std::string sql;
		if ( function.empty( ) )
		throw base::GenException( __FUNCTION__, " Error. Missing stored function name" );
		switch ( retval_binding_type )
		{
			case RESULTSET:
			// Pipelined table funcion
			if ( res->get_query_fields( ).empty( ) )
			throw base::GenException( __FUNCTION__, " Error. Resultset not initialized" );
			sql = std::string( "SELECT " ) + res->get_query_fields( ) + " FROM TABLE( " + function + "( " + get_bindparams_str( ) + " ) )";
			break;
			case NONE:
			// Stored function without return code
			//sql = std::string( "SELECT " ) + function + "( " + get_bindparams_str( ) + " ) FROM DUAL";
			sql = std::string( "BEGIN " ) + function + "( " + get_bindparams_str( ) + " );END;";
			break;
			default:
			// Stored function with return code
			sql = std::string( "BEGIN :ret := " ) + function + "( " + get_bindparams_str( ) + " );END;";
		}
		return sql;
	}
	std::string stfunc::get_bindparams_str( )
	{
		// Return a string containing as many question marks as input parameters exist, separated by comma
		return bindparams_str;
	}
	void stfunc::bind_ret( resultset &res )
	{
		retval_binding_type = RESULTSET;
		stfunc::res = &res;
		res.set_current_db_object( this );
	}
	void stfunc::prepare( )
	{
		base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
		db_object::prepare( stmt );
	}
	void stfunc::bind_ret( short &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( int &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( char &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( char *var, const size_t size )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, size, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( unsigned short &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( unsigned int &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( unsigned char &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( long &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( unsigned long &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( float &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( double &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( oasis_dec_t &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		stmt->bind_param( 1, var, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	void stfunc::bind_ret( std::string &var, const size_t max_len )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		// Return code MUST be the first binding, check whether there's already any parameter binding
		if ( any_binding_exists( ) )
			throw base::GenException( __FUNCTION__, " Error. Parameter bindings already exist." );
		char *str = get_buff( var, max_len + 1 );
		register_buff_out( var, str, max_len );
		stmt->bind_param( 1, str, max_len, DBM_PARAM_OUTPUT );
		retval_binding_type = SINGLE_VALUE;
	}
	int stfunc::translate_pos( int pos )
	{
		parameter_binding_exists = true;
		if ( retval_binding_type == SINGLE_VALUE )
			return pos + 1;
		// The first parameter is the stored function' return code
		return pos;
	}
	void stfunc::bind_param( const unsigned int pos, short &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, int &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, char &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, char *var, const size_t size )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var, size );
	}
	void stfunc::bind_param( const unsigned int pos, unsigned short &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, unsigned int &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, unsigned char &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, long &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, unsigned long &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, float &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, double &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, oasis_dec_t &var )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		stmt->bind_param( translate_pos( pos ), var );
	}
	void stfunc::bind_param( const unsigned int pos, std::string &var, const size_t max_len )
	{
		base::genAssert( db_object::is_valid( ), __FUNCTION__, "Invalid db_object" );
		add_parameter( );
		char *str = get_buff( var, max_len + 1 );
		register_buff_in( var, str, max_len );
		stmt->bind_param( translate_pos( pos ), str, max_len );
	}
	void stfunc::add_parameter( )
	{
		if ( parameter_binding_exists )
			bindparams_str += ", ";
		else
			parameter_binding_exists = true;
		bindparams_str += "?";
	}
	bool stfunc::any_binding_exists( ) const
	{
		return parameter_binding_exists;
	}
	void stfunc::bind_columns( )
	{
		// Some data types are not supported by DBM low level API. Ie: std::string
		// So here is where we handle this data types any time
		// a new fetch( ) is performed for this resultset.
		// In the case of Single Return value, handle std::string
		if ( retval_binding_type == SINGLE_VALUE )
		{
			handle_String_out( );
		}
	}
}

