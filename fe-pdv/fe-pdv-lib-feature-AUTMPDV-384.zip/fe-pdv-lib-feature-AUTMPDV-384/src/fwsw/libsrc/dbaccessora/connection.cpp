/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Renato de Camargo
Data     : 18/10/2018
Empresa  : Rede
Descricao: Eliminacao de conexao presa
ID       : AM 225800
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 29/05/2019
Empresa  : Rede
Descricao: Adicionando Tratamento de timeout no BD no handleError (igual ao do statement.cpp)
ID       : AM 249438
*************************************************************
/ Sigla: SW - FE-POS
/ Descricao: EAK-1638 - Adicionando controle de Timeout no Execute
/ Autor: Renato de Camargo
/ Data de Criacao: 10/07/2019
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1832 - Tratamento de Erros Conhecidos (WhiteList)
/ Autor: Renato de Camargo
/ Data de Criacao: 03/10/2019
-------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1847 - [PacoteEstabilidade] Desativa��o do uso do "FOR UPDATE"
/ Autor: Renato de Camargo
/ Data de Criacao: 03/10/2019
-------------------------------------------------------------------------------------------------
Autor    : Daniel Nava
Data     : 03/12/2019
Empresa  : Leega
Descricao: Tratamento de alarme diferenciado para processo dispatcher
ID       : EAK-1880
*************************************************************
Autor    : Daniel Nava
Data     : 26/12/2019
Empresa  : Leega
Descricao: Altera��o de exit para kill nos error de Oracle fora da white list para n�o ficar com private mailbox do security preso
ID       : EAK-2001
*************************************************************
*/

#pragma once
#include <iostream>
#include <sstream>
#include <signal.h>
#include <sys/time.h>
#include "base/GenException.hpp"
#include "dbaccess/connection.hpp"
#include <syslg.h>
#include <unistd.h>
#include <ist_cfg.h>
#include <algorithm>
#include "base/GenException.hpp"
#include "base/ToException.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <time.h>
#include "ShmMonDb.hpp"
#include "staticLib/SmartLog.hpp"


extern "C" { int delete_private_mbox(void ); }

namespace dbaccess
{
	connection::connection( )
	{
		conn = 0;
		alarmEnabled = false;
		removeForUpdate = false;
		alarmTimer = 0;
		querySql = "";
		querySqlStatic = "";
        alarmLagTimeLimit = 0;
		siteStatment = LOCAL_STATMENT;
		siteStatmentStatic = LOCAL_STATMENT;
	}
	connection::~connection( )
	{
		rollback( );
		drop_statements( );
		disconnect( );
	}
	void connection::drop_statements( )
	{
		statements_t::iterator it = statements.begin( );
		statements_t::iterator end = statements.end( );
		for ( ; it != end; it ++ )
		delete *it;
		statements.clear( );
	}
	void connection::disconnect( )
	{
		if ( conn != 0 )
		{
			commit( );
			drop_statements( );		
			DBMRETURN ret = DBMDisconnect( conn );
			if ( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
			this->handleError( "DBMAllocConnect( )", conn );
			DBMFreeConnect( conn );
			conn = 0;
		}
	}

/// connect
/// Efetua connect
/// EF/ET: EAK-1880
/// Hist�rico:
/// 03/12/2019 - EAK-1880 - Inicializa��o dos par�metros de timeout dispatcher
	void connection::connect( const std::string &server, const std::string &user, const std::string &password )
	{
		char istparamFlag[128] = {0};		
		
		DBMRETURN ret = DBMAllocConnect( &conn );
		if ( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
		this->handleError( "DBMAllocConnect( )", conn );
		ret = DBMConnect( conn, server.data( ), user.data( ), password.data( ) );
		if ( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
		this->handleError( "DBMConnect( )", conn );
	
		alarmEnabled = false;
		alarmDispatcherEnabled = false;
		alarmTimer = 0;
		alarmDispatcherTimer = 0;
		
		if( cf_locate( "restart_on_timeout_byapp", istparamFlag ) > 0 )
		{
			syslg("Restart on TimeOut by Application : [%s]\n", istparamFlag );
			
			if (strcmp(istparamFlag, "Y") == 0) {
				alarmEnabled = true;
				if( cf_locate( "restart_on_timeout_byapp_time", istparamFlag ) > 0 )
				{
					alarmTimer = atoi(istparamFlag);
				} else {
					alarmTimer = DEFAULT_ALARM;
				}
				syslg("Restart on TimeOut by Application - Time : [%d]\n", alarmTimer );
			}
		}
		if( cf_locate( "restart_on_dispatcher_timeout_byapp", istparamFlag ) > 0 )
		{
			syslg("Restart on Dispatcher TimeOut by Application : [%s]\n", istparamFlag );
			
			if (strcmp(istparamFlag, "Y") == 0) {
				alarmDispatcherEnabled = true;
				if( cf_locate( "restart_on_dispatcher_timeout_byapp_time", istparamFlag ) > 0 )
				{
					alarmDispatcherTimer = atoi(istparamFlag);
				} else {
					alarmDispatcherTimer = DEFAULT_DISPATCHER_ALARM;
				}
				syslg("Restart on Dispatcher TimeOut by Application - Time : [%d]\n", alarmDispatcherTimer );
			}
		}
		LoadWhiteList();
		alarmLagTimeLimit = ReadDBLagTimeLimit();
		removeForUpdate = LoadUseForUpdateFlag();
	}
	DBMHSTMT *connection::get_new_statement( )
	{
		DBMHSTMT *sh = new DBMHSTMT;
		if ( sh == NULL )
		throw base::GenException( __FUNCTION__, " - unable to allocate DBMHSTMT" );
		DBMRETURN ret = DBMAllocStmt( conn, sh );
		if ( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
		this->handleError( "DBMAllocStmt( )", conn );
		statements.push_back( sh );
		return sh;
	}
	void connection::drop_statement( DBMHSTMT *stmt )
	{
		base::genAssert( stmt != NULL, __FUNCTION__, "Statement not defined" );
		statements.remove( stmt );
		delete stmt;
	}
	void connection::commit( )
	{
		// Setar comando commit
		SetSql("COMMIT");
		
		// Somente usa o timeout pela app se o parametro restart_on_timeout_byapp for Y no ISTPARAM
		if( IsAlarmEnabled() )
			EnableTimer(GetAlarmTimer());
		
        struct timeval start;
        gettimeofday(&start, 0);

		DBMRETURN ret = DBMEndTran( conn, DBM_COMMIT );

		if (alarmLagTimeLimit > 0) {
            VerifyLagDifference(start);
        }

		DisableTimer();
		if ( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
			this->handleError( "DBMEndTran( DBM_COMMIT )", conn );
	}
	void connection::rollback( )
	{
        staticlib::SmartLog::SmartDebug(logger::LEVEL_INFO, ROLLBACK_LOG_HEADER, "Query: %s", GetSql().c_str());
		// Setar comando rollback
		SetSql("ROLLBACK");
		// Somente usa o timeout pela app se o parametro restart_on_timeout_byapp for Y no ISTPARAM
		if( IsAlarmEnabled() )
			EnableTimer(GetAlarmTimer());
		
        struct timeval start;
        gettimeofday(&start, 0);

		DBMRETURN ret = DBMEndTran( conn, DBM_ROLLBACK );

        if (alarmLagTimeLimit > 0) {
            VerifyLagDifference(start);
        }

		DisableTimer();		
		if ( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
			this->handleError( "DBMEndTran( DBM_ROLLBACK )", conn );
	}
	void connection::handleError( const std::string &method, const DBMHANDLE handle )
	{
		DBMRETURN ret;
		char sqlstate[50];
		int native_error;
		int rec_num;
		int finish;
		char msg_text[200];
		char oracleTimeoutFlag[128] = {0};
		std::ostringstream message;
		char whiteListCheck[10] = {0};
				
		message << "DBM method " << method << " returned error message: ";
		finish = 0;
		for ( rec_num = 1; !finish; rec_num++ )
		{
			ret = DBMGetDiagRec( DBM_HANDLE_DBC, handle, rec_num, sqlstate, &native_error, msg_text, sizeof( msg_text ), NULL );
			switch ( ret )
			{
				case DBM_SUCCESS_WITH_INFO:
				case DBM_SUCCESS:
					message << "Connection error: sqlstate=" << sqlstate << " native_error=" << native_error << " msg=" << msg_text;
					
					oracleError = native_error;
					sprintf(whiteListCheck,"%05d",native_error);					
					
					// Se a conexao com o Banco de Dados apresenta TimeOut o processo fara o kill/restart
					if( native_error != 0 && !IsOracleWhiteListError( whiteListCheck ))					
					{
						restartConnection = true; 
						
						if( cf_locate( "restart_on_timeout", oracleTimeoutFlag ) > 0 )
						{
							if (strcmp(oracleTimeoutFlag, "Y") == 0) {
								KillProcess( msg_text, GetSql());
							}
						}
						finish = 1;
					}
				
				break;
				case DBM_INVALID_HANDLE:
				message << "DBMGetDiagRec: Connection error: invalid handle";
				finish = 1;
				break;
				case DBM_NO_DATA:
				finish = 1;
				break;
				case DBM_ERROR:
				message << "DBMGetDiagRec: invalid argument";
				finish = 1;
				break;
				default:
				message << "DBMGetDiagRec: returned unexpected retcode: " << ret;
				finish = 1;
				break;
			}
		}
		if ( IsRestartConnection() ) {
			throw base::ToException( method, message.str( ), oracleError );
		} else {
			throw base::GenException( method, message.str( ) );
		}	
	}
	
	/// connection::IsRestartConnection
	/// Getter para a variavel restartConnection, que diz se a conexao deve ser refeita 
	/// EF/ET: EAK 1552
	/// Historico: [Data] - ET - Descricao
	/// [29/05/2019] - EAK 1552 - Versao inicial 
	bool connection::IsRestartConnection( )
	{
		return restartConnection;
	}
	/// statement::EnableTimer
	/// Ativar o Alarme de Timeout
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [10/07/2019] - Versao inicial	
	void connection::EnableTimer(int seconds)
	{
		struct sigaction sigact;
		DisableTimer();
		sigact.sa_handler = connection::SignalHandler;
		sigact.sa_flags   = SA_RESETHAND;
		sigemptyset(&sigact.sa_mask);
		sigaction(SIGALRM, &sigact, NULL);
		// Utilizacao da funcao ualarm, portanto * 1000000us
		//ualarm(seconds * 1000000, 0);
		alarm(seconds);
	}
	/// statement::DisableTimer
	/// Desativar o Alarme de Timeout
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [10/07/2019] - Versao inicial		
	void connection::DisableTimer()
	{
		alarm(0);
		//ualarm(0,0);
	}
	/// statement::SignalHandler
	/// Tratamento do Alarme de Timeout
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [10/07/2019] - Versao inicial	
	extern "C" void connection::SignalHandler(int signal)
	{
		char oracleTimeoutFlag[128] = {0};		
		if (signal == SIGALRM) {
			KillProcess ( "APPLICATION TIMEOUT\n", querySqlStatic );
			syslg("delete_private_mbox [%d]\n", delete_private_mbox());
			exit(SQLNET_TIMEOUT_SIGNAL);			
		}
	}
	/// connection::KillProcess
	/// Mata o processo atual
	/// EF/ET: EAK 1552
	/// Historico: [Data] - ET - Descricao
	/// [29/05/2019] - EAK 1552 - Versao inicial
	void connection::KillProcess( char * msgText, std::string msg )
	{
		char msgLog[2000] = {0};
		char localRemoto[20] = {0};
		
		sprintf( localRemoto, "%s", ( siteStatmentStatic == REMOTE_STATMENT ? "Remoto" : "Local" ));
		strncpy( msgLog, msg.c_str(), sizeof(msgLog) - 1);
		
		ShmMonDb * shm = ShmMonDb::getInstance();
		syslg("Shm Timeout = RC[%d]\n", ( siteStatmentStatic == REMOTE_STATMENT ? shm->IncrementRemoteTimeout(0) : shm->IncrementLocalTimeout(0)));
		
		sprintf(msgLog,"ERROR: ORACLE Timeout %s => %s", localRemoto, msgText );
		syslg(msgLog);
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, msgLog );
		
		sprintf(msgLog,"ERROR: ORACLE Timeout %s => Enviando Signal %d\n", localRemoto, SQLNET_TIMEOUT_SIGNAL);
		syslg(msgLog);		
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, msgLog );
		
		for( int indice = 0; indice < (msg.length() / SYSLG_CHAR_BY_LINE) + 1; indice++ ) 
		{
			sprintf(msgLog,"SQL:[%-*.*s]", SYSLG_CHAR_BY_LINE, SYSLG_CHAR_BY_LINE, msg.substr(indice*SYSLG_CHAR_BY_LINE).c_str());
			syslg("%s\n",msgLog);
			logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, msgLog );
		}

		// Envia Signal 4
		kill(getpid(), SQLNET_TIMEOUT_SIGNAL);
		//exit(SQLNET_TIMEOUT_SIGNAL);
	}
	
	/// connection::IsAlarmEnabled
	/// Getter para a variavel IsAlarmEnabled, que diz se deve usar o timeout alarm
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [10/07/2019] - Versao inicial	
	/// [03/12/2019 - EAK-1880 - Inclus�o de flag para selecionar tipo de alarme para verificar habilita��o
	bool connection::IsAlarmEnabled( bool isDispatcher )
	{
		if(isDispatcher)
			return alarmDispatcherEnabled;
		else
			return alarmEnabled;
	}
	
	/// connection::GetAlarmTimer
	/// Getter para a variavel alarmTimer, que diz se deve usar timeout pela App
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [10/07/2019] - Versao inicial		
	/// [03/12/2019 - EAK-1880 - Inclus�o de flag para selecionar tipo de alarme para recuperar tempo de timeout
	int  connection::GetAlarmTimer( bool isDispatcher ) {
		if(isDispatcher)
			return alarmDispatcherTimer;
		else
			return alarmTimer;
	}
	
	/// connection::SetSql
	/// Setar Query em Execucao
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [17/07/2019] - Versao inicial
	void connection::SetSql( const std::string sqlParam )
	{
		std::size_t posicao;
		
		posicao = sqlParam.find( " FROM " );
		if( posicao != std::string::npos )
			querySql = sqlParam.substr( posicao + 6 );
		else
			querySql = sqlParam;
		
		querySqlStatic = querySql;
	}
	
	/// connection::GetSql
	/// Obter Query em Execucao
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [17/07/2019] - Versao inicial		
	std::string connection::GetSql() {
		return querySql;
	}

	/// connection::LoadWhiteList
	/// Carregar uma WhiteList em memoria
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial		
	int connection::LoadWhiteList() {
		char aux[200] = {0};
		int  oracleError = 0;
		char oracleErrorWhiteList[10] = {0};
		
		oracleWhiteList.clear();
		if (cf_locate("oracle.whitelist", aux) > 0)
		{
			do
			{
				if (sscanf(aux, "%d", &oracleError) != 1)
					syslg("Error reading parameters from ISTPARAM. Discarding '%s'\n", aux);
				else
				{
					sprintf(oracleErrorWhiteList,"%05d", oracleError);
					oracleWhiteList.push_back( oracleErrorWhiteList );
				}
			} while (cf_nextparm("oracle.whitelist", aux) > 0);
		}
		else {
			syslg("ERROR: Parameter oracle.whitelist not found in ISTPARAM\n", aux);
		}
		std::sort( oracleWhiteList.begin(), oracleWhiteList.end() );
		
		//for (int i = 0; i < oracleWhiteList.size(); i++) syslg("oracle.whitelist %d>>[%s]\n",i,oracleWhiteList.at(i).c_str());
		
		return 0;
	}

	/// connection::IsOracleWhiteListError
	/// Pesquisar item na WhiteList em memoria
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial		
    bool connection::IsOracleWhiteListError( const char *oracleError )
    {
		return std::binary_search( oracleWhiteList.begin(), oracleWhiteList.end(), oracleError );
    }	

	/// connection::SetRemoteStatement
	/// Setar que querie eh remota
	/// EF/ET: EAK-1834
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial		
	void connection::SetRemoteStatement()
	{
		this->siteStatment = REMOTE_STATMENT;
		siteStatmentStatic = REMOTE_STATMENT;
	}

	/// connection::SetLocalStatement
	/// Setar que local eh remota
	/// EF/ET: EAK-1834
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial		
	void connection::SetLocalStatement()
	{
		this->siteStatment = LOCAL_STATMENT;
		siteStatmentStatic = LOCAL_STATMENT;
	}
	
	/// connection::IsRemoteStatement
	/// Retorna se Statement for Remoto
	/// EF/ET: EAK-1834
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial	
	bool connection::IsRemoteStatement()
	{
		return ( this->siteStatment == REMOTE_STATMENT );
	}

   /// connection::GetDBLagTimeLimit
    /// EAK-1838
	/// Obtem do istparam a flag DB_LAG_ALERT_TIME_LIMIT_FLAG e checa se ela ? valida (> 0)
    /// Retorna o valor da flag caso seja valida ou '0' caso n?o seja valida
    int connection::ReadDBLagTimeLimit() {
        
        char istparamFlag[128] = {0};
        int timeLimit = 0;

        if( cf_locate( DB_LAG_ALERT_TIME_LIMIT_FLAG, istparamFlag ) > 0 )
		{
            timeLimit = atoi(istparamFlag);			
			if ( timeLimit > 0 ) 
                return timeLimit;
            else // Parametro menor ou igual a 0, nao usar o alerta
            {
			    syslg("DB_LAG_ALERT_TIME_LIMIT_FLAG [%d] is <= 0 - will not log db lag\n", timeLimit);
                return 0;
            }
		} 
        else // Parametro nao encontrado
        {
            syslg("DB_LAG_ALERT_TIME_LIMIT_FLAG [%s] not found in istparam\n", DB_LAG_ALERT_TIME_LIMIT_FLAG);
            return 0;
        }
    }

    int connection::GetAlarmLagTimeLimit() {
        return alarmLagTimeLimit;
    }

    /// connection::VerifyLagDifference
    /// EAK-1838
    /// Verifica se o tempo desde um clock estourou o limite de lag, caso seja verdade faz o log no AIXsyslg e no debug
	/// Recebe por parametro:
    ///     => o timeval a partir do qual deseja-se calcular a diferenca
    void connection::VerifyLagDifference(struct timeval start) {
        try 
        {
            struct timeval now;
            gettimeofday(&now, 0);
            float diff = (float) ((now.tv_sec - start.tv_sec) * 1000000 + ((int)now.tv_usec - (int)start.tv_usec));
            diff /= 1000; // Transformando em milisegundos

            if (diff > alarmLagTimeLimit) {
                char msgLog[4096] = {0};
                snprintf(msgLog, sizeof(msgLog) - 1, "[ALERT] connection::VerifyLagDifference - DB Lag [%llf ms] reached time limit [%d ms]           Query: [%s]", diff, alarmLagTimeLimit, querySqlStatic.c_str());

                staticlib::SmartLog::SmartDebug(logger::LEVEL_WARNING, LAG_LOG_HEADER, msgLog);
                staticlib::SmartLog::SmartSyslg(LAG_LOG_HEADER, msgLog);
            } 
        }
        catch (std::exception e) {
            syslg("Exception occurred while checking lag time in DB => [%s]\n", e.what());
        }
    }
	
	/// connection::LoadUseForUpdateFlag
	/// Carregar Flag se vai Utilizar For Update do ISTPARAM
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial		
	bool connection::LoadUseForUpdateFlag() {
		char istparamFlag[128] = {0};
		
		removeForUpdate = false;
		if( cf_locate( "oracle.remove_for_update", istparamFlag ) > 0 )
		{
			if (strcmp(istparamFlag, "Y") == 0) 
				removeForUpdate = true;
		}
		else
			syslg("Remove For Update flag not found in istparam. Setted to use For Update\n");

		return removeForUpdate;
	}
	
	/// connection::UseForUpdate
	/// Verificar se utiliza For Update
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [02/10/2019] - Versao inicial		
	bool connection::UseForUpdate() {
		return ( removeForUpdate == false );
	}	
}
