/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: Inclusao de Novo Erro Oracle
/ Autor: Renato de Camargo
/ Data de Criacao: 07/12/2018
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: Adicionando controle para dropar transa��o e refazer conex�o dbm no caso de timeout com o banco
/ Autor: Renato de Camargo
/ Data de Criacao: 06/05/2019
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1638 - Adicionando controle de Timeout no Execute
/ Autor: Renato de Camargo
/ Data de Criacao: 10/07/2019
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1766 - Adicionando controle para impossibilitar loop infinito
/ Autor: Renato de Camargo
/ Data de Criacao: 26/08/2019
-------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1832 - Tratamento de Erros Conhecidos (WhiteList)
/ Autor: Renato de Camargo
/ Data de Criacao: 03/10/2019
-------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1834 - [PacoteEstabilidade] Diferencia��o de erros em BD Local/Remoto
/ Autor: Renato de Camargo
/ Data de Criacao: 07/10/2019
-------------------------------------------------------------------------------------------------
Autor    : Daniel Nava
Data     : 03/12/2019
Empresa  : Leega
Descricao: Altera��o dos m�todos prepare, execute e fetch para conter par�metro opcional (se usa timeout de dispatcher)
ID       : EAK-1880
*************************************************************
Autor    : Daniel Nava
Data     : 26/12/2019
Empresa  : Leega
Descricao: Altera��o de exit para kill nos error de Oracle fora da white list para n�o ficar com private mailbox do security preso
ID       : EAK-2001
*************************************************************
*/
#pragma once
#include "base/GenException.hpp"
#include "base/ToException.hpp"
#include <iostream>
#include <sstream>
#include "dbaccess/statement.hpp"
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ist_cfg.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/timeb.h> 
#include <math.h>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "ShmMonDb.hpp"

namespace dbaccess
{
    statement::statement( connection &c )
    {
        con = &c;
        stmt = c.get_new_statement( );
        m_sql_dump = "";
		restartConnection = false;
		oracleError = 0;
    }
    statement::~statement( )
    {
        close( );
        con->drop_statement( stmt );
        bindings.clear( );
    }
	void statement::KillProcess( char * msgText )
	{
		char msgLog[800] = {0};
		char query[SYSLG_CHAR_BY_LINE*2] = {0};
		char localRemoto[20] = {0};
		
		sprintf( localRemoto, "%s", ( con->IsRemoteStatement() ? "Remoto" : "Local" ));

		ShmMonDb * shm = ShmMonDb::getInstance();
		syslg("Shm Timeout = RC[%d]\n", ( con->IsRemoteStatement() == REMOTE_STATMENT ? shm->IncrementRemoteTimeout(0) : shm->IncrementLocalTimeout(0)));
		
		snprintf(msgLog, sizeof(msgLog)-1,"ERROR: ORACLE Timeout %s => %s", localRemoto, msgText );
		syslg(msgLog);
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, msgLog );
		
		snprintf(msgLog, sizeof(msgLog)-1, "ERROR: ORACLE Timeout %s => Enviando Signal %d\n", localRemoto, SQLNET_TIMEOUT_SIGNAL);
		syslg(msgLog);
		logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, msgLog );

		strncpy( msgLog, con->GetSql().c_str(), sizeof(msgLog) - 1);
		
		for( int indice = 0; indice < (strlen(msgLog) / SYSLG_CHAR_BY_LINE) + 1; indice++ ) 
		{
			sprintf(query,"SQL:[%-*.*s]", SYSLG_CHAR_BY_LINE, SYSLG_CHAR_BY_LINE, &msgLog[indice*SYSLG_CHAR_BY_LINE]);
			syslg("%s\n",query);
			logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, query );
		}

		// Envia Signal 4
		kill(getpid(), SQLNET_TIMEOUT_SIGNAL);
		//exit(SQLNET_TIMEOUT_SIGNAL);
	}
	/// statement::IsRestartConnection
	/// Getter para a vari�vel restartConnection, que diz se a conex�o deve ser refeita 
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [06/05/2019] - EAK 1390 - Vers�o inicial 
	bool statement::IsRestartConnection( )
	{
		return restartConnection;
	}
    void statement::close( )
    {
        DBMRETURN retval = DBMFreeStmt( *stmt, DBM_DROP );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind( const unsigned int pos, short &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_INTTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_INTTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, int &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_LONGTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_LONGTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, char &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_CHARTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_CHARTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, char *var, const size_t capacity, int *status, int *ind_null )
    {
        if ( var == NULL )
        throw base::GenException( __FUNCTION__, " char* received an invalid NULL argument" );
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_STRINGTYPE, var, capacity, status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_STRINGTYPE, var, capacity, status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, dbm_datetime_t *var, int *status, int *ind_null )
    {
        if ( var == NULL )
        throw base::GenException( __FUNCTION__, " dbm_datetime_t* received an invalid NULL argument" );
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_DATETIMETYPE, var, sizeof( dbm_datetime_t ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_DATETIMETYPE, var, sizeof( dbm_datetime_t ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, unsigned short &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_INTTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_INTTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, unsigned int &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_LONGTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_LONGTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, unsigned char &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_CHARTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_CHARTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, long &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_LONGTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_LONGTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, unsigned long &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_LONGTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_LONGTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, float &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_FLOATTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_FLOATTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, double &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_DOUBLETYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_DOUBLETYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, oasis_dec_t &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_DECIMALTYPE, &var, sizeof( var ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_DECIMALTYPE, &var, sizeof( var ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind( const unsigned int pos, sw_date_t &var, int *status, int *ind_null )
    {
        DBMRETURN retval = DBMBindCol( *stmt, pos, DBM_DATETYPE, &var.date, sizeof( var.date ), status );
        handle_retval( __FUNCTION__, retval );
        bind_t bind =
        {
            DBM_DATETYPE, &var.date, sizeof( var.date ), status, ind_null
        };
        bindings[pos]
        = bind;
    }
    void statement::bind_param( const unsigned int pos, short &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_INTTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, int &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_LONGTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, char &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_CHARTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, char *var, const size_t size, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_STRINGTYPE, var, size, NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, unsigned short &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_INTTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, unsigned int &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_LONGTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, unsigned char &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_CHARTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, long &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_LONGTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, unsigned long &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_LONGTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, float &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_FLOATTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, double &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_DOUBLETYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, oasis_dec_t &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_DECIMALTYPE, &var, sizeof( var ), NULL );
        handle_retval( __FUNCTION__, retval );
    }
    void statement::bind_param( const unsigned int pos, sw_date_t &var, int inout )
    {
        DBMRETURN retval = DBMBindParam( *stmt, pos, inout, DBM_DATETYPE, &(var.date), sizeof( var.date ), NULL );
        handle_retval( __FUNCTION__, retval );
    }

/// prepare
/// Efetua prepare
/// EF/ET: EAK-1880
/// Hist�rico:
/// 03/12/2019 - EAK-1880 - Inclusao da flag nas chamadas ao banco para utiliza��o do timeout diferenciado
    void statement::prepare( const std::string &str, bool isDispatcher )
    {
        // Setando que eh um Prepare para o log
		SetSql("PREPARE");
        
        // Somente usa o timeout pela app se o parametro restart_on_timeout_byapp for Y no ISTPARAM
		if( con->IsAlarmEnabled(isDispatcher) )
			con->EnableTimer(con->GetAlarmTimer(isDispatcher));

        DBMRETURN retval = DBMPrepare( *stmt, str.data( ) );
        
        // Desativa o Alarme
		con->DisableTimer();

        handle_retval( __FUNCTION__, retval );
    }

/// execute
/// Efetua execute
/// EF/ET: EAK-1880
/// Hist�rico:
/// 03/12/2019 - EAK-1880 - Inclusao da flag nas chamadas ao banco para utiliza��o do timeout diferenciado
    void statement::execute( bool isDispatcher )
    {
		// Somente usa o timeout pela app se o parametro restart_on_timeout_byapp for Y no ISTPARAM
		if( con->IsAlarmEnabled(isDispatcher) )
			con->EnableTimer(con->GetAlarmTimer(isDispatcher));

        struct timeval start;
        gettimeofday(&start, 0);

        DBMRETURN retval = DBMExecute( *stmt );
		
        if (con->GetAlarmLagTimeLimit() > 0) {
            con->VerifyLagDifference(start);
        }

		//Desativa o Alarme
		con->DisableTimer();
        handle_retval( __FUNCTION__, retval );
    }

/// fetch
/// Efetua fetch
/// EF/ET: EAK-1880
/// Hist�rico:
/// 03/12/2019 - EAK-1880 - Inclusao da flag nas chamadas ao banco para utiliza��o do timeout diferenciado
    bool statement::fetch( bool isDispatcher )
    {
        // Setando que eh um fetch para o log
		SetSql("FETCH");

        // Somente usa o timeout pela app se o parametro restart_on_timeout_byapp for Y no ISTPARAM
		if( con->IsAlarmEnabled(isDispatcher) )
			con->EnableTimer(con->GetAlarmTimer(isDispatcher));

        DBMRETURN retval = DBMFetch( *stmt );

		//Desativa o Alarme
		con->DisableTimer();

        if ( retval == DBM_NO_DATA )
        return false;
        handle_retval( __FUNCTION__, retval );
        return true;
    }
    void statement::handle_retval( const char* method, const DBMRETURN dbmret )
    {
        DBMRETURN diagret;
        char sqlstate[50];
        int native_error;
        int rec_num;
        int finish;
        char msg_text[200];
        std::ostringstream message;
		char oracleTimeoutFlag[128] = {0};
		char whiteListCheck[10] = {0};		

        if ( dbmret != DBM_SUCCESS && dbmret != DBM_SUCCESS_WITH_INFO )
        {
            message << "DBM method " << method << " returned error message: ";
            finish = 0;
			// Alterado looping para obter no maximo 10 msgs do Comando DBMGetDiagRec
            for ( rec_num = 1; !finish && rec_num < MAX_DBMGETDIAGREC ; rec_num++ )
            {
                diagret = DBMGetDiagRec( DBM_HANDLE_STMT, *stmt, rec_num, sqlstate, &native_error, msg_text, sizeof( msg_text ), NULL );
                switch ( diagret )
                {
                    case DBM_SUCCESS_WITH_INFO:
                    case DBM_SUCCESS:
						message << "Statement error: sqlstate=" << sqlstate << " native_error=" << native_error << " msg=" << msg_text;
						
						oracleError = native_error;
						sprintf(whiteListCheck,"%05d",native_error);
						
						// Se a conexao com o Banco de Dados apresenta TimeOut o processo fara o kill/restart
						if( native_error != 0 && !con->IsOracleWhiteListError( whiteListCheck ))						
						{
							restartConnection = true; 
							
							if( cf_locate( "restart_on_timeout", oracleTimeoutFlag ) > 0 )
							{
								if (strcmp(oracleTimeoutFlag, "Y") == 0) {
									KillProcess( msg_text );
								}
							}
							finish = 1;
						}
						break;
                    case DBM_INVALID_HANDLE:
                    message << "DBM_INVALID_HANDLE DBMGetDiagRec: Statement error: invalid handle";
                    finish = 1;
                    break;
                    case DBM_NO_DATA:
                    finish = 1;
                    break;
                    case DBM_ERROR:
                    message << "DBM_ERROR DBMGetDiagRec: invalid argument";
                    finish = 1;
                    break;
                    default:
                    message << "Unknown error DBMGetDiagRec: returned unexpected retcode: " << diagret;
                    finish = 1;
                    break;
                }
            }
			if ( IsRestartConnection() ) {
				throw base::ToException( method, message.str( ), oracleError );
			} else {
				throw base::GenException( method, message.str( ) );
			}
        }
    }
    void statement::positioned_upd_bind( statement *pstmt )
    {
        // Copy all bindings from stmt into the current object for update
        bindings_t::iterator it = pstmt->bindings.begin( );
        bindings_t::iterator end = pstmt->bindings.end( );
        DBMRETURN retval;
        for ( ; it != end; it ++ )
        {
            bind_t bind =( *it ).second;
            int pos =( *it ).first;
            
            if ( bind.ind_null != NULL && *bind.ind_null == DBM_NULL_DATA )
                retval = DBMBindParam( *stmt, pos, DBM_PARAM_INPUT, bind.type, bind.buff, bind.buff_len, bind.ind_null );
            else
                retval = DBMBindParam( *stmt, pos, DBM_PARAM_INPUT, bind.type, bind.buff, bind.buff_len, NULL );
            handle_retval( __FUNCTION__, retval );
        }
    }
    void statement::prepare_positioned( statement *pstmt, const std::string &sql )
    {
        // Setando que � um Prepare Positioned para o log
		SetSql("PREPARE POSITIONED - SQL:" + sql);
		
        // Somente usa o timeout pela app se o parametro restart_on_timeout_byapp for Y no ISTPARAM
		if( con->IsAlarmEnabled() )
			con->EnableTimer(con->GetAlarmTimer());

        DBMRETURN retval = DBMPreparePositioned( *stmt, *( pstmt->stmt ), sql.data( ) );
        
        //Desativa o Alarme
		con->DisableTimer();
        handle_retval( __FUNCTION__, retval );
    }
    void statement::commit( )
    {
        con->commit( );
    }
    void statement::rollback( )
    {
        con->rollback( );
    }
    
	// get_sql_dump
	// Retorna o Dump SQL
	// EF/ET: 44179
	// Hist�rico: [06/10/2014] - 44179 - Release I de 2014
	// pstmt: Statement SQL
    std::string& statement::get_sql_dump( statement *pstmt )
    {
        // Copy all bindings from stmt into the current object for update
        bindings_t::iterator it = pstmt->bindings.begin( );
        bindings_t::iterator end = pstmt->bindings.end( );
        char l_log_buffer[1024];
        char l_type_buffer[1024];        

		// Iteracao
        for ( ; it != end; it ++ )
        {
            bind_t bind =( *it ).second;
            int pos =( *it ).first;

            memset(l_log_buffer, 0, sizeof(l_log_buffer));
            memset(l_type_buffer, 0, sizeof(l_type_buffer));

			// Valida tipo de bind
            if ( bind.ind_null != NULL && *bind.ind_null == DBM_NULL_DATA )
                snprintf(l_log_buffer, sizeof l_log_buffer, "[%03d] NULL, ", pos);
            else
            {
                switch( bind.type )
                {            
                case DBM_INTTYPE:
                case DBM_LONGTYPE:
                    snprintf(l_log_buffer, sizeof l_log_buffer, "[%03d] %ld, ", pos, *(static_cast<long*>(bind.buff)));
                    break;
                case DBM_CHARTYPE:
                    snprintf(l_log_buffer, sizeof l_log_buffer, "[%03d] '%c', ", pos, *(static_cast<char*>(bind.buff)));
                    break;
                case DBM_STRINGTYPE:
                    snprintf(l_log_buffer, sizeof l_log_buffer, "[%03d] '%s', ", pos, static_cast<char*>(bind.buff));
                    break;
                case DBM_DATETIMETYPE:
                    strftime(l_type_buffer, sizeof l_type_buffer, "TO_DATE('%d/%m/%Y %T','DD/MM/YYYY HH24:MI:SS'), ", localtime(static_cast<time_t*>(bind.buff)));
                    snprintf(l_log_buffer, sizeof l_log_buffer, "[%03d] %s", pos, l_type_buffer );
                    break;
                case DBM_FLOATTYPE:
                case DBM_DOUBLETYPE:
                    snprintf(l_log_buffer, sizeof l_log_buffer, "[%03d] '%4.2f', ", pos, static_cast<double*>(bind.buff));
                    break;
                case DBM_DECIMALTYPE:
                    dbm_dectochar(static_cast<oasis_dec_t*>(bind.buff), l_type_buffer);
                    snprintf(l_log_buffer, sizeof l_log_buffer, "[%03d] %s, ", pos, l_type_buffer);
                    break;
                default:
                    snprintf(l_log_buffer, sizeof l_log_buffer, "[%03d] ?, ", pos );
                    break;
                }
            }
            
            m_sql_dump += l_log_buffer;
        }
        
        return m_sql_dump;
    }
	
	/// connection::SetSql
	/// Setar Query em Execucao
	/// EF/ET: 
	/// Historico: [Data] - ET - Descricao
	/// [17/07/2019] - Versao inicial
	void statement::SetSql( std::string sqlParam )
	{
		con->SetSql( sqlParam );
	}
};

