/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Renato de Camargo
Data     : 18/10/2018
Empresa  : Rede
Descricao: EAK-682 - Eliminacao de Conexoes Oracle Pendentes
ID       : AM 225800
*************************************************************
*/
#pragma once
#include <cstring>
#include <string>
#include <dbm.h>
#include <syslg.h>
#include "dbaccess/single_db.hpp"
#include "AwsBase.hpp"
#include "SystemManager.hpp"
#include "SecretsManager.hpp"

namespace dbaccess
{
	single_db *single_db::_Instance = NULL;
	single_db *single_db::get_instance( )
	{
		if ( _Instance == NULL )
		{
			_Instance = new single_db;
		}
		return _Instance;
	}
	single_db::single_db( )
	{
		conn = NULL;
	}
	single_db::~single_db( )
	{
	}
	connection *single_db::get_first( )
	{
		if ( conn == NULL )
		{
			conn = new connection;

			internalAws::ssm::SystemManager systemManager;
            std::string parameter("/online/oracle/");
            parameter.append(std::getenv("FE"));
            parameter.append("/");
            parameter.append(internalAws::Base::GetInstance()->GetAZ().c_str());
            std::string secret = systemManager.GetParameterStore(parameter.c_str());

			internalAws::sm::SecretsManager secretsManager;
			std::string db_username = secretsManager.RetrieveSecretName(secret, "username");
			std::string db_password = secretsManager.RetrieveSecretName(secret, "password");
			std::string db_name = secretsManager.RetrieveSecretName(secret, "dbname");

			conn->connect(db_name.c_str(), db_username.c_str(), db_password.c_str());
		}
		return conn;
	}
	connection *single_db::get_next( )
	{
		return NULL;
	}
	
	// DropConnection
	// Efetua a desconexao do Banco de Dados
	// AM 225800
	// Hist�rico: 18/10/2018 - Versao Inicial
	void single_db::DropConnection( )
	{
		if ( conn != NULL )
		{
			conn->disconnect( );
			syslg("D R O P P I N G    C O N N E C T I O N\n");
			conn = NULL;
		}
	}	
}

