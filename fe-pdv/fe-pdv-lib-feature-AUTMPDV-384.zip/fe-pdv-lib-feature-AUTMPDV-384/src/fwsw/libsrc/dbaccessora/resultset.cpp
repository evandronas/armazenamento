/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "dbaccess/resultset.hpp"
namespace dbaccess
{
	resultset::resultset( )
	{
		last_field_nbr = 0;
		db_obj = NULL;
	}
	resultset::~resultset( )
	{
		close_fetch( );
	}
	bool resultset::fetch( )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->fetch( );
	}
	void resultset::close_fetch( )
	{
		// Execute db_obj member function
		if ( db_obj != NULL )
		db_obj->close_fetch( );
	}
	int resultset::add_new_field( const std::string &field )
	{
		// Precondition: field must not be NULL
		if ( field.empty( ) )
		throw base::GenException( __FUNCTION__, " received an invalid EMPTY string" );
		if ( last_field_nbr++ != 0 )
		{
			// This is NOT the first field in the list, add a comma.
			query_fields += ", ";
		}
		query_fields += field;
		return last_field_nbr;
	}
	std::string resultset::get_query_fields( )
	{
		return query_fields;
	}
	void resultset::bind_col( const std::string &field, int &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, char &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, char *var, const size_t capacity )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var, capacity );
	}
	void resultset::bind_col( const std::string &field, std::string &var, const size_t capacity )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, dbm_datetime_t *var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, unsigned int &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, unsigned char &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, long &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, unsigned long &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, float &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, double &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	void resultset::bind_col( const std::string &field, oasis_dec_t &var )
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		int field_nbr = add_new_field( field );
		db_obj->bind( field_nbr, var );
	}
	bool resultset::is_null( int &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( char &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( char *var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( std::string &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( dbm_datetime_t *var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( unsigned int &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( unsigned char &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( long &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( unsigned long &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( float &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( double &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	bool resultset::is_null( oasis_dec_t &var ) const
	{
		base::genAssert( db_obj != NULL, __FUNCTION__, "db_obj not defined" );
		return db_obj->is_null( var );
	}
	void resultset::set_current_db_object( db_object *ob )
	{
		db_obj = ob;
	}
}

