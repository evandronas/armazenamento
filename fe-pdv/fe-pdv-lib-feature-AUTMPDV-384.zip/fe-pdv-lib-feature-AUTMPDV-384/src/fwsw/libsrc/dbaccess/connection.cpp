/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#include "dbaccess/connection.hpp"
#include "dbaccess/postgresql/factory.hpp"

#include <cstring>
#include <string>
#include <dbm.h>
#include <syslg.h>
#include <unistd.h>
#include <ist_cfg.h>
#include <ist_otrace.h>

#include "base/ToException.hpp"
#include "base/GenException.hpp"

#include "AwsBase.hpp"
#include "SystemManager.hpp"
#include "SecretsManager.hpp"


using namespace std;

namespace dbaccess
{
    connection *connection::m_instance = NULL;

    connection::connection()
    {
        removeForUpdate                       = false;
        connection_retry                      = 0; // no retry by default
        connection_retry_interval             = 1; // 1 second by default
        database_prefix_ps                    = "/online/postgresql"; //default prefix
        database_name[endpoint::DB_BASEUNICA] = std::string(std::getenv("FE")) + "/baseunica";
        database_name[endpoint::DB_CAPTURA]   = std::string(std::getenv("FE")) + "/captura";
        connection_timeout                    = "5";
    }

    connection::~connection() {
        disconnect();
    }

    connection *connection::GetInstance()
    {
        if (m_instance == NULL) {
            cf_open("cfg/istparam.cfg");
            m_instance = new connection;
            m_instance->configure();
            m_instance->connect();
        }
        return m_instance;
    }

    void connection::configure()
    {
        char istparamFlag[128] = {0};

        if (cf_locate("database.remove_for_update", istparamFlag ) > 0) {
            if (strcmp(istparamFlag, "Y") == 0) {
                removeForUpdate = true;
            }
        }

        if (cf_locate("database.connection_retry", istparamFlag) > 0) {
            connection_retry = atoi(istparamFlag);
        }

        if (cf_locate("database.connection_retry_interval", istparamFlag) > 0) {
            connection_retry_interval = atoi(istparamFlag);
        }

        if (cf_locate("database.ps_prefix", istparamFlag) > 0) {
            database_prefix_ps = istparamFlag;
        }

        if (cf_locate("database.ps_dbname_baseunica", istparamFlag) > 0) {
            database_name[endpoint::DB_BASEUNICA] = istparamFlag;
        }

        if (cf_locate("database.ps_dbname_captura", istparamFlag) > 0) {
            database_name[endpoint::DB_CAPTURA] = istparamFlag;
        }

        if (cf_locate("database.connection_timeout", istparamFlag) > 0) {
            connection_timeout = istparamFlag;
        }
    }

    void connection::connect()
    {
        internalAws::ssm::SystemManager systemManager;
        internalAws::sm::SecretsManager secretsManager;

        RdmsFactory * factory = new RdmsPostgresqlFactory();

        for (int i=0; i < endpoint::DBACCESS_ENDPOINT_COUNT; i++) {
            string parameter = database_prefix_ps + "/" + database_name[i] + "/" + std::string(internalAws::Base::GetInstance()->GetAZ().c_str());
            string secret = systemManager.GetParameterStore(parameter.c_str());

            databases.push_back(factory->create());

            string timeout = secretsManager.RetrieveSecretName(secret, "timeout");
            if (!timeout.empty()) {
                connection_timeout = timeout;
            }

            string strConnection = "host=" + secretsManager.RetrieveSecretName(secret, "host") + \
                                   " port=" + secretsManager.RetrieveSecretName(secret, "port") + \
                                   " user=" + secretsManager.RetrieveSecretName(secret, "username") + \
                                   " password=" + secretsManager.RetrieveSecretName(secret, "password") + \
                                   " dbname=" + secretsManager.RetrieveSecretName(secret, "dbname") + \
                                   " connect_timeout=" + connection_timeout + \
                                   " client_encoding=LATIN1";

            std::string error_message;
            for (int retry=0; retry <= connection_retry; retry++) {

                error_message = databases[i]->connect(strConnection.c_str());
                if (databases[i]->isConnected()) {
                    syslg("RDMS %s has been connected!\n", database_name[i].c_str());
                    break;

                } else if(retry == connection_retry) {
                    delete factory;
                    throw base::GenException( __PRETTY_FUNCTION__, " - connection failed: " +  error_message);

                } else {
                    sleep(connection_retry_interval);
                }
            }
        }

        delete factory;
    }

    RdmsInterface * connection::getDatabase(int index)
    {
        return databases[index];
    }

    bool connection::UseForUpdate() 
    {
        return (removeForUpdate == false);
    }

    void connection::disconnect()
    {
        cout << __PRETTY_FUNCTION__ << endl;

        for (int i=0; i < endpoint::DBACCESS_ENDPOINT_COUNT; i++) {
            if (databases[i] != NULL) {
                databases[i]->disconnect();
                databases.erase(databases.begin() + i);
            }
        }
    }

    StatementInterface * get_new_statement()
    {
    }

	// Setar Query em Execucao
	void connection::SetSql( const std::string sqlParam )
	{
		std::size_t posicao;
		
		posicao = sqlParam.find( " FROM " );
		if( posicao != std::string::npos )
			querySql = sqlParam.substr( posicao + 6 );
		else
			querySql = sqlParam;
	}
	
	// Obter Query em Execucao
	std::string connection::GetSql() {
		return querySql;
	}

}
