/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#include "dbaccess/db_object.hpp"
#include <string>
#include <string.h>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "base/ToException.hpp"
#include "base/GenException.hpp"

using namespace std;

namespace dbaccess
{
    db_object::db_object() {
        cout << __PRETTY_FUNCTION__ << endl;
        this->conn = connection::GetInstance();
        this->database = NULL;
    }

    db_object::~db_object()
    {
        cout << __PRETTY_FUNCTION__ << endl;
        release_bindings();
    }

    void db_object::update_database_id(int id) {
        this->database = this->conn->getDatabase(id);
    }

    void db_object::commit( void )
    {
        /* There is no need begin and commit on Postgresql */
    }

    void db_object::rollback( void )
    {
        database->rollback();
    }

    bool db_object::is_null( int &var ) const
    {
        return is_null( ( void* ) &var );
    }
    bool db_object::is_null( char &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( char *var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( string &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( dbm_datetime_t *var ) const
    {
        return is_null( ( void* )var );
    }
    bool db_object::is_null( unsigned int &var ) const
    {
        return is_null( ( void* ) &var );
    }
    bool db_object::is_null( unsigned char &var ) const
    {
        return is_null( ( void* ) &var );
    }
    bool db_object::is_null( long &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( unsigned long &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( float &var ) const
    {
        return is_null( ( void* ) &var );
    }
    bool db_object::is_null( double &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( oasis_dec_t &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( sw_date_t &var ) const
    {
        return is_null( ( void* )&var );
    }
    bool db_object::is_null( void *ptr ) const
    {
        base::genAssert( vstatus_by_ptr.find( ptr ) != vstatus_by_ptr.end( ), __PRETTY_FUNCTION__, "is_null() - Pointer not found" );
        int *status = ( *vstatus_by_ptr.find( ptr ) ).second;
        bool res = *status == ( int )DBM_NULL_DATA;
        return res;
    }

    void db_object::bind_param(const unsigned int posicao, const int type, void *buffer, int bufferLen, int *status, int *indNull)
    {
        bind_t bind = { type, buffer, bufferLen, status, indNull };
        bindings[posicao] = bind;
        paramAllocatedTotal++;
    }

    void db_object::bind( const unsigned int pos, int &var )
    {
        bind( pos, var, NULL );
    }

    void db_object::bind( const unsigned int pos, char &var )
    {
        bind( pos, var, NULL );
    }

    void db_object::bind( const unsigned int pos, char *var, const size_t capacity )
    {
        if ( var == NULL )
        {
            throw base::GenException( __FUNCTION__, " char* received an invalid NULL argument" );
        }

        int posicao = pos - 1;

        int dataLen = strlen(var);
        char* stringFormat = new char[capacity];
        strncpy(stringFormat, var, dataLen);
        allocated_array_pointers.push_back(stringFormat);

        if ( dataLen == 0 ) 
        {
            paramValues[posicao] = nullptr;    
        }
        else 
        {
            paramValues[posicao] = stringFormat;
        }
        paramLengths[posicao] = dataLen;
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);


        bind_param(pos, DB_CHARSTRING, stringFormat, capacity, status, NULL);
    }

    void db_object::bind( const unsigned int pos, string &var, const size_t capacity ) 
    {
        int posicao = pos - 1;

        char* stringFormat = new char[capacity];
        memset(stringFormat, 0, capacity);
        strncpy(stringFormat, var.c_str(), var.size());
        allocated_array_pointers.push_back(stringFormat);

        if ( var.length() == 0 ) 
        {
            paramValues[posicao] = nullptr;
        }
        else 
        {
            paramValues[posicao] = stringFormat;
        }
        paramLengths[posicao] = var.size();
        paramFormats[posicao] = 0;

        register_buff_out( var, stringFormat, var.size() );
        register_buff_in( var, stringFormat, var.size() );

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_STRING, stringFormat, capacity, status, NULL);
    }

    void db_object::bind( const unsigned int pos, unsigned int &var )
    {
        bind( pos, var, NULL );
    }

    void db_object::bind( const unsigned int pos, unsigned char &var )
    {
        bind( pos, var, NULL );
    }

    void db_object::bind( const unsigned int pos, long &var )
    {
        bind( pos, var, NULL );
    }

    void db_object::bind( const unsigned int pos, unsigned long &var )
    {
        bind( pos, var, NULL );
    }

    void db_object::bind( const unsigned int pos, unsigned long long &var )
    {
        bind( pos, var, NULL);
    }

    void db_object::bind( const unsigned int pos, float &var )
    {
        bind( pos, var, NULL );
    }

    void db_object::bind( const unsigned int pos, double &var )
    {
        bind( pos, var, NULL );
    }

    void db_object::bind( const unsigned int pos, dbm_datetime_t *var )
    {
        bind( pos, var, NULL);
    }

    void db_object::bind( const unsigned int pos, oasis_dec_t &var )
    {
        bind( pos, var, NULL);
    }

    void db_object::bind( const unsigned int pos, sw_date_t &var )
    {
        bind( pos, var, NULL);
    }

    void db_object::bind( const unsigned int pos, int &var, int *ind_null )
    {
        int posicao = pos - 1;

        std::stringstream streamData;
		streamData << var;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_INT, &var, sizeof(var), status, ind_null);  
    }

    void db_object::bind( const unsigned int pos, char &var, int *ind_null )
    {
        int posicao = pos - 1;

        char* stringFormat = new char[sizeof(char)];
        memcpy(stringFormat, &var, sizeof(char));
        allocated_array_pointers.push_back(stringFormat);

        paramValues[posicao] = stringFormat;
        paramLengths[posicao] = sizeof(var);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_CHAR, stringFormat, sizeof(var), status, NULL);
    }

    void db_object::bind( const unsigned int pos, unsigned int &var, int *ind_null )
    {
        int posicao = pos - 1;

        std::stringstream streamData;
		streamData << var;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_UINT, &var, sizeof(var), status, ind_null);  
    }

    void db_object::bind( const unsigned int pos, unsigned char &var, int *ind_null )
    {
        int posicao = pos - 1;

        char* stringFormat = new char[sizeof(unsigned char)];
        memcpy(stringFormat, &var, sizeof(unsigned char));
        allocated_array_pointers.push_back(stringFormat);

        paramValues[posicao] = stringFormat;
        paramLengths[posicao] = sizeof(var);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_CHAR, stringFormat, sizeof(var), status, NULL);
    }

    void db_object::bind( const unsigned int pos, long &var, int *ind_null )
    {
        int posicao = pos - 1;

        std::stringstream streamData;
		streamData << var;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_LONG, &var, sizeof(var), status, ind_null);
    }

    void db_object::bind( const unsigned int pos, unsigned long &var, int *ind_null )
    {
        int posicao = pos - 1;

        std::stringstream streamData;
		streamData << var;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_ULONG, &var, sizeof(var), status, ind_null);
    }

    void db_object::bind( const unsigned int pos, unsigned long long &var, int *ind_null )
    {
        int posicao = pos - 1;

        std::stringstream streamData;
		streamData << var;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
		bind_param(pos, DB_ULLONG, &var, sizeof(var), status, ind_null); 
    }

    void db_object::bind( const unsigned int pos, float &var, int *ind_null )
    {
        int posicao = pos - 1;

        std::stringstream streamData;
		streamData << var;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_FLOAT, &var, sizeof(var), status, ind_null);  
    }

    void db_object::bind( const unsigned int pos, double &var, int *ind_null )
    {
        int posicao = pos - 1;

        std::stringstream streamData;
		streamData << var;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_DOUBLE, &var, sizeof(var), status, ind_null);  
    }

    void db_object::bind( const unsigned int pos, dbm_datetime_t *var, int *ind_null )
    {
        if ( var == NULL )
        {
            throw base::GenException( __FUNCTION__, " dbm_datetime_t* received an invalid NULL argument" );
        }
        int posicao = pos - 1;
        struct tm *timeinfo;
        char dataHora[80] = {0};

        // *var recebe uma struct time_t 
        timeinfo = localtime (var);
        memset(dataHora, 0, sizeof(dataHora));
        strftime ( dataHora, sizeof(dataHora), "%Y%m%d%H%M%S", timeinfo );

        // tratamento para nao inserir data zerada
        if (atoll(dataHora) <= 0)
        {
            paramValues[posicao] = nullptr;
            paramLengths[posicao] = 0;
            paramFormats[posicao] = 0;

            int *status = new int;
            vstatus[pos] = status;
            vstatus_by_ptr[var] = status;
            allocated_pointers.push_back(status);

            bind_param(pos, DB_DATETIME, var, 0, status, ind_null);
            return;
        }

        long datePart = atoll(dataHora) / 1000000;
        long timePart = atoll(dataHora) % 1000000;

        long dateYear = datePart / 10000;
        long dateMonth = datePart / 100 % 100;
        long dateDay = datePart % 100;

        long timeHour = timePart / 10000;
        long timeMinute = timePart / 100 % 100;
        long timeSecond = timePart % 100;

        std::stringstream streamData;

        streamData << std::setfill('0') << std::setw(4) << dateYear << "-";
        streamData << std::setfill('0') << std::setw(2) << dateMonth << "-";
        streamData << std::setfill('0') << std::setw(2) << dateDay;

        streamData << " " << std::setfill('0') << std::setw(2) << timeHour << ":";
        streamData << std::setfill('0') << std::setw(2) << timeMinute << ":";
        streamData << std::setfill('0') << std::setw(2) << timeSecond;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_DATETIME, var, sizeof(dbm_datetime_t), status, ind_null);
    }

    void db_object::bind( const unsigned int pos, oasis_dec_t &var, int *ind_null )
    {
        int posicao = pos - 1;

		double valueDouble = 0.0;
		valueDouble = dbm_dectodbl(&var);

        std::string data = std::to_string(valueDouble);

        int dataLength = data.length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, data.c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }
        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_DECIMAL, &var, sizeof(var), status, ind_null);
    }

    void db_object::bind( const unsigned int pos, sw_date_t &var, int *ind_null )
    {
        int posicao = pos - 1;

        // tratamento para nao inserir data zerada
        if (var.date <= 0)
        {
            paramValues[posicao] = nullptr;
            paramLengths[posicao] = 0;
            paramFormats[posicao] = 0;

            int *status = new int;
            vstatus[pos] = status;
            vstatus_by_ptr[&var.date] = status;
            allocated_pointers.push_back(status);
            bind_param(pos, DB_DATE, &var.date, 0, status, ind_null);
            return;
        }

        long datePart = var.date;

        std::stringstream streamData;

        streamData << std::setfill('0') << std::setw(8) << datePart;

        int dataLength = streamData.str().length()+1;
        char* convValue = new char[ dataLength ];
        memcpy(convValue, streamData.str().c_str(), dataLength);
        allocated_array_pointers.push_back(convValue);

        if ( ind_null != NULL && *ind_null == DBM_NULL_DATA )
        {
            convValue = NULL;
        }

        paramValues[posicao] = convValue;
        paramLengths[posicao] = sizeof(convValue);
        paramFormats[posicao] = 0;

        int *status = new int;
        vstatus[pos] = status;
        vstatus_by_ptr[&var.date] = status;
        allocated_pointers.push_back(status);
        bind_param(pos, DB_DATE, &var.date, sizeof(sw_date_t), status, ind_null);
    }

    void db_object::prepare( void )
    {
        release_bindings();
    }

    void db_object::prepare( bool isDispatcher )
    {
        release_bindings();
    }

    void db_object::execute( void )
    {
    }

    bool db_object::fetch( void )
    {
    }

    void db_object::bind_columns( void )
    {
    }

    void db_object::bind_resultset( void )
    {
    }

    char *db_object::get_buff( const std::string &var, const size_t capacity )
    {
        char *str;
        str = new char[capacity];
        if ( str == 0 )
        {
            throw base::GenException( __PRETTY_FUNCTION__, " Out of memory trying to allocate a new buffer" );
        }

        memset(str, 0, sizeof(str));
        return str;
    }
    void db_object::register_buff_out( std::string &var, char *str, size_t len )
    {
        ptr_len_t *node = new ptr_len_t;
        if ( node == 0 )
        {
            throw base::GenException( __PRETTY_FUNCTION__, " Out of memory trying to allocate a new buffer" );
        }

        node->allocated_len = len;
        node->ptr = str;
        str_binds_out[&var] = node;
        allocated_pointers.push_back(node);
    }
    void db_object::register_buff_in( std::string &var, char *str, size_t len )
    {
        ptr_len_t *node = new ptr_len_t;
        if ( node == 0 )
        {
            throw base::GenException( __PRETTY_FUNCTION__, " Out of memory trying to allocate a new buffer" );
        }

        node->allocated_len = len;
        node->ptr = str;
        str_binds_in[&var] = node;
        allocated_pointers.push_back(node);
    }

    void db_object::handle_parameters( void )
    {
        handle_String_in();
    }

    void db_object::handle_fetch( void )
    {
        handle_String_out();
    }

    void db_object::handle_String_out( )
    {
        // String bindings.
        string_bindings_t::iterator it = str_binds_out.begin( );
        string_bindings_t::iterator end = str_binds_out.end( );
        for ( ; it != end; it ++ )
        {
            ( *( (*it ).first ) ) = ( (*it ).second )->ptr;
        }
    }
    void db_object::handle_String_in( )
    {
        // String bindings.
        string_bindings_t::iterator it = str_binds_in.begin( );
        string_bindings_t::iterator end = str_binds_in.end( );
        for ( ; it != end; it ++ )
        {
            size_t len =( (*it ).second )->allocated_len;
            strncpy( (( *it ).second )->ptr, (( *it ).first )->c_str( ), len );
            ( (*it ).second )->ptr[len] = '\0';
        }
    }

    void db_object::Dump( PGresult *resultSet )
    {
        int rows = PQntuples(resultSet);
        int cols = PQnfields(resultSet);
        
        for( int i=0; i < rows; i++ ) 
        {
            cout << "-------------------" << endl;
            for ( int j=0; j < cols; j++)
            {
                cout << PQfname(resultSet, j) << " => [" << PQgetvalue(resultSet, i, j) << "]" << endl;
            }
        }
    }

    void db_object::clean_output_bindings( )
    {
        // String bindings.
        string_bindings_t::iterator it = str_binds_out.begin( );
        string_bindings_t::iterator end = str_binds_out.end( );
        for ( ; it != end; it ++ )
        {
            memset( (( *it ).second )->ptr, 0, (( *it ).second )->allocated_len );
        }
    }

    void db_object::release_bindings( )
    {
        cout << __PRETTY_FUNCTION__ << endl;

        // Every C-pointer malloc/new should be in allocated_pointers or allocated_array_pointers in order to be freed
        //       (int*, char*, struct*, etc.)
        // If new[] was used, it should be in allocated_array_pointers
        for ( auto ptr : allocated_pointers) {
            delete ptr;
            ptr = nullptr;
        }

        for ( auto ptr : allocated_array_pointers) {
            delete[] ptr;
            ptr = nullptr;
        }

        // PostgreSQL parameters
        for ( int pos = 0; pos <= paramAllocatedTotal; pos++ )
        {
            paramValues[pos] = nullptr;
        }
        paramAllocatedTotal = 0;

        str_binds_in.clear( );
        str_binds_out.clear( );
        bindings.clear();
        allocated_pointers.clear();
        allocated_array_pointers.clear();
    }
}
