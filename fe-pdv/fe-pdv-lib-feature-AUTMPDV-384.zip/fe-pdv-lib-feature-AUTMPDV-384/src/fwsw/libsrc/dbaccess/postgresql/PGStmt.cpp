#include "dbaccess/postgresql/PGStmt.hpp"
#include "dbaccess/postgresql/rdms.hpp"
#include <cstring>
#include <algorithm>

using namespace std;

bool compBD( const BindData &a, const BindData &b ) { return a.posicao < b.posicao; }

namespace dbaccess
{
    PGStmt::PGStmt( )
    {
        conn = NULL;
        isPrepared = false;
    }

    PGStmt::PGStmt( RdmsInterface *pgconn )
    {
        conn = pgconn;
        isPrepared = false;
    }

    string PGStmt::GetPreparedName() const
    {
        return preparedName;
    }

    int PGStmt::Bind( const unsigned int pos, short &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(var).c_str(),
            DB_INT,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, int &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(var).c_str(),
            DB_INT,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, char &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)string(1, var).c_str(),
            DB_CHAR,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, char *var, const size_t capacity, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            var,
            DB_CHARSTRING,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, long *var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(*var).c_str(),
            DB_LONG,
            var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, unsigned short &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(var).c_str(),
            DB_UINT,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }
    
    int PGStmt::Bind( const unsigned int pos, unsigned int &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(var).c_str(),
            DB_UINT,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }
    
    int PGStmt::Bind( const unsigned int pos, unsigned char &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)string(1, var).c_str(),
            DB_CHAR,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, long &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(var).c_str(),
            DB_LONG,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, unsigned long &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(var).c_str(),
            DB_ULONG,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, float &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(var).c_str(),
            DB_FLOAT,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }
    
    int PGStmt::Bind( const unsigned int pos, double &var, int *status, int *indNull, int inout )
    {
        BindData bind = {
            pos,
            (char*)to_string(var).c_str(),
            DB_DOUBLE,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, oasis_dec_t &var, int *status, int *indNull, int inout )
    {
        char valor[256];

        dbm_dectochar( &var, valor );

        BindData bind = {
            pos,
            valor,
            DB_DECIMAL,
            &var,
            indNull,
            inout
        };
        paramValues.push_back( bind );
    }

    int PGStmt::Bind( const unsigned int pos, int type, void *var, int len, int *indNull, int inout )
    {
        char bindVal[1024];
        int status = 0;

        switch ( type )
        {
            case DB_CHAR:
                sprintf( bindVal, "%c", *( (char*)var) );
                break;
            case DB_INT:
                sprintf( bindVal, "%d", *( (int*)var) );
                break;
            case DB_UINT:
                sprintf( bindVal, "%u", *( (unsigned int*)var) );
                break;
            case DB_LONG:
                sprintf( bindVal, "%ld", *( (int*)var) );
                break;
            case DB_ULONG:
                sprintf( bindVal, "%lu", *( (unsigned int*)var) );
                break;
            case DB_ULLONG:
                sprintf( bindVal, "%llu", *( (unsigned int*)var) );
                break;
            case DB_DOUBLE:
            case DB_FLOAT:
                sprintf( bindVal, "%f", *( (unsigned int*)var) );
                break;
            case DB_DECIMAL:
                dbm_dectochar( (oasis_dec_t*)var, bindVal );
                break;
            case DB_DATE:
                sprintf( bindVal, "%lu", ((sw_date_t*)var)->date );
                break;
            case DB_DATETIME:
                sprintf( bindVal, "%lu", *( (unsigned long*)var) );
                break;
            case DB_CHARSTRING:
            case DB_STRING:
                sprintf( bindVal, "%s", (char*)var );
                break;
            default:
                return -1;
        }
        len = ( len < strlen( bindVal ) ? len : strlen( bindVal ) );

        return Bind( pos, bindVal, len, &status, indNull, inout );
    }

    int PGStmt::Prepare( char * sql )
    {
        ExecStatusType resultStatus;
        string strSql( sql );

        PrepareSqlString( strSql );

        preparedName = to_string( hash<string>{}( strSql.c_str() ) );

        auto maxEl = max_element( paramValues.begin(), paramValues.end(), compBD );
        int numEl = maxEl->posicao;

        PQclear( resultSet );

        resultSet = PQprepare ( ((RdmsPostgresql *)conn)->GetConn(), preparedName.c_str(), strSql.c_str(), numEl, NULL );

        if( ( resultStatus = PQresultStatus( resultSet ) ) == PGRES_COMMAND_OK )
        {
            isPrepared = true;
        }

        return (int)resultStatus;
    }

    int PGStmt::Execute()
    {
        char ** arr;
        int tam = PrepareParams( paramValues, arr );

        PQclear( resultSet );

        resultSet = PQexecPrepared( ((RdmsPostgresql *)conn)->GetConn(), preparedName.c_str(), tam, (const char * const *)arr, NULL, NULL, 0 );

        return (int)PQresultStatus( resultSet );
    }

    void PGStmt::PrepareSqlString( std::string& sql )
    {
        int i = 0;
        size_t pos = string::npos;
        
        while( (pos = sql.find_first_of( "?" )) != string::npos )
        {
            string sub(1, '?');
            i++;
            sub += to_string(i);
            sql.replace( pos, 1, sub );
        }
    }

    int PGStmt::PrepareParams( std::vector<BindData>& vec, char **arr )
    {
        vector<const char*> params;

        for( BindData bd : vec)
            params.push_back( bd.valor );
        sort( params.begin(), params.end() );
        params.erase( unique( params.begin(), params.end() ), params.end() );
        arr = (char**)params.data();

        return params.size();
    }

//    const char* PGStmt::BindStrData( BindData& bd )
//    {
//        if( bd.type == DB_INT )
//            return (const char*) to_string( *((int*)bd.valor) ).c_str();
//        if( bd.type == typeid( unsigned int ) )
//            return (const char*) to_string( *((unsigned int*)bd.valor ).c_str();
//        if( bd.type == typeid( long ) )
//            return (const char*) to_string( *((long*)bd.valor) ).c_str();
//        if( bd.type == typeid( unsigned long ) )
//            return (const char*) to_string( *((unsigned long*)bd.valor ).c_str();
//        if( bd.type == typeid( float ) )
//            return (const char*) to_string( *((float*)bd.valor) ).c_str();
//        if( bd.type == typeid( double ) )
//            return (const char*) to_string( *((double*)bd.valor) ).c_str();
//        if( bd.type == typeid( char ) )
//        {
//            string str(1, ((char*)bd.valor)[0] );
//            return (const char*) str.c_str();
//        }
//        if( bd.type == typeid( char* ) )
//            return (const char*) bd.valor;
//
//        return NULL;
//    }

    int PGStmt::Fetch()
    {
        if( !isPrepared )
            return -1;

        int nrFields = PQnfields( resultSet );

        fetchPos++;

        for( int i = 0; i< paramValues.size(); i++ )
        {
            if( paramValues[i].posicao >= nrFields )
                continue;

            if( paramValues[i].type == DB_INT ||
                paramValues[i].type == DB_UINT )
                *((int*)paramValues[i].ptrBind) = atoi( PQgetvalue( resultSet, fetchPos, paramValues[i].posicao ) );
            if( paramValues[i].type == DB_LONG ||
                paramValues[i].type == DB_ULONG )
                *((long*)paramValues[i].ptrBind) = atol( PQgetvalue( resultSet, fetchPos, paramValues[i].posicao ) );
            if( paramValues[i].type == DB_FLOAT ||
                paramValues[i].type == DB_DOUBLE )
                *((double*)paramValues[i].ptrBind) = atof( PQgetvalue( resultSet, fetchPos, paramValues[i].posicao ) );

            if( paramValues[i].type == DB_CHAR )
                *((char*)paramValues[i].ptrBind) = ( PQgetvalue( resultSet, fetchPos, paramValues[i].posicao ) )[0];
            if( paramValues[i].type == DB_CHARSTRING )
                strcpy((char*)(paramValues[i].ptrBind), PQgetvalue( resultSet, fetchPos, paramValues[i].posicao ) );
            if( paramValues[i].type == DB_DECIMAL )
            {
                dbm_chartodec(((oasis_dec_t*)paramValues[i].ptrBind), PQgetvalue( resultSet, fetchPos, paramValues[i].posicao ), 0);
            }
        }

        return 0;
    }

    int PGStmt::GetDiagRec( int handle, int recNbr, char* sqlState, int* nativeErr, char * msgText, int buffLen, int* msgLen )
    {
        char * pgSqlState = PQresultErrorField(resultSet, PG_DIAG_SQLSTATE);
        char * pgMsg = PQresultErrorField(resultSet, PG_DIAG_MESSAGE_PRIMARY);
        char * pgMsgDet = PQresultErrorField(resultSet, PG_DIAG_MESSAGE_DETAIL);
        int msgRetLen = strlen(pgMsg);
        int msgDetRetLen = strlen(pgMsgDet);

        strcpy( sqlState, pgSqlState );
        if( msgRetLen + msgDetRetLen < buffLen - 1 )
        {
            strcpy( msgText, pgMsg );
            strcat( msgText, "\n" );
            strcat( msgText, pgMsgDet );
        }
        else
        {
            strncpy( msgText, pgMsg, buffLen - 1 );
        }

        *msgLen = strlen( msgText );

        return 0;
    }

    int PGStmt::PreparePositioned( StatementInterface *stmtPar, char * sql )
    {
        return stmtPar->Prepare( sql );
    }

};
