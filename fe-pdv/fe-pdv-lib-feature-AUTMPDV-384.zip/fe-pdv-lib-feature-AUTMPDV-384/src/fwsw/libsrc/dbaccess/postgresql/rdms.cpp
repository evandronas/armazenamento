#include "dbaccess/postgresql/rdms.hpp"
#include "dbaccess/StatementInterface.hpp"
#include "base/GenException.hpp"
#include "logger/LoggerGen.hpp"
#include <string>
#include <syslg.h>
#include <sys/time.h>

namespace dbaccess {

    RdmsPostgresql::RdmsPostgresql() {
        this->alarm_restart_on_timeout = new AlarmRestartOnTimeout;
        this->result = NULL;
    }

    RdmsPostgresql::~RdmsPostgresql() {
        if (this->conn) {
            delete this->conn;
        }
        if (this->result) {
            delete this->result;
        }
        if (this->alarm_restart_on_timeout) {
            delete this->alarm_restart_on_timeout;
        }
    }

    void RdmsPostgresql::begin(void) {
        this->result = PQexec(this->conn, "BEGIN");
        if (PQresultStatus(this->result) != PGRES_COMMAND_OK)
        {
            throw base::GenException( __PRETTY_FUNCTION__, " BEGIN command failed" );
        }

        this->clear();
    }

    void RdmsPostgresql::commit(void) {

        this->alarm_restart_on_timeout->EnableTimer("commit");

        struct timeval start;
        gettimeofday(&start, 0);

        this->result = PQexec(this->conn, "COMMIT");
        if (PQresultStatus(this->result) != PGRES_COMMAND_OK)
        {
            throw base::GenException( __PRETTY_FUNCTION__, " COMMIT command failed" );
        }

        this->alarm_restart_on_timeout->VerifyLagDifference(start);
        this->alarm_restart_on_timeout->DisableTimer();

        this->clear();
    }

    std::string RdmsPostgresql::connect(const char * query)
    {
        this->conn = PQconnectdb(query);
        return std::string(PQerrorMessage(this->conn));
    }

    bool RdmsPostgresql::isConnected() {
        if (PQstatus(this->conn) != CONNECTION_OK) {
            return false;
        }
        return true;
    }

    void RdmsPostgresql::disconnect()
    {
        if (PQstatus(this->conn) == CONNECTION_OK) {
                PQfinish(this->conn);
        }
    }

    void RdmsPostgresql::clear() {
        if (this->result) {
            PQclear(this->result);
            this->result = nullptr;
        }
    }

    void RdmsPostgresql::insert(const char * query, int nParams, const char * const * paramValues, const int * paramLengths, const int * paramFormats)
    {
        this->alarm_restart_on_timeout->EnableTimer(query);
        struct timeval start;
        gettimeofday(&start, 0);

        this->result = PQexecParams(this->conn, query, nParams, NULL, paramValues, paramLengths, paramFormats, 0);
        if (PQresultStatus(this->result) != PGRES_COMMAND_OK) {
            this->clear();
            throw base::GenException( __PRETTY_FUNCTION__, " Insert Error: " + std::string( PQerrorMessage(this->conn) ) );
        }

        this->alarm_restart_on_timeout->VerifyLagDifference(start);
        this->alarm_restart_on_timeout->DisableTimer();
    }

    void RdmsPostgresql::update(const char * query, int nParams, const char * const * paramValues, const int * paramLengths, const int * paramFormats)
    {
        this->alarm_restart_on_timeout->EnableTimer(query);

        struct timeval start;
        gettimeofday(&start, 0);

        this->result = PQexecParams(this->conn, query, nParams, NULL, paramValues, paramLengths, paramFormats, 0);
        if (PQresultStatus(this->result) != PGRES_COMMAND_OK) {
            this->clear();
            throw base::GenException( __PRETTY_FUNCTION__, " Update Error: " + std::string( PQerrorMessage(this->conn) ) );
        }

        this->alarm_restart_on_timeout->VerifyLagDifference(start);
        this->alarm_restart_on_timeout->DisableTimer();
    }

    void RdmsPostgresql::remove(const char * query)
    {
        this->alarm_restart_on_timeout->EnableTimer(query);

        struct timeval start;
        gettimeofday(&start, 0);

        this->result = PQexec(this->conn, query);
        if (PQresultStatus(this->result) != PGRES_COMMAND_OK) {
            this->clear();
            throw base::GenException( __PRETTY_FUNCTION__, " Delete Error: " + std::string( PQerrorMessage(this->conn) ) );
        }

        this->alarm_restart_on_timeout->VerifyLagDifference(start);
        this->alarm_restart_on_timeout->DisableTimer();
    }

    void RdmsPostgresql::select(const char * query)
    {
        this->alarm_restart_on_timeout->EnableTimer(query);

        struct timeval start;
        gettimeofday(&start, 0);

        this->result = PQexec(this->conn, query);
        if (PQresultStatus(this->result) != PGRES_COMMAND_OK && PQresultStatus(this->result) != PGRES_TUPLES_OK)
        {
            this->clear();
            throw base::GenException( __PRETTY_FUNCTION__, " Select Error " + std::string( PQerrorMessage(conn) ) );
        }

        this->alarm_restart_on_timeout->VerifyLagDifference(start);
        this->alarm_restart_on_timeout->DisableTimer();
    }

    void RdmsPostgresql::rollback(void)
    {
        this->alarm_restart_on_timeout->EnableTimer("rollback");
        struct timeval start;
        gettimeofday(&start, 0);

        this->result = PQexec(this->conn, "ROLLBACK");
        if (PQresultStatus(this->result) != PGRES_COMMAND_OK)
        {
            this->clear();
            throw base::GenException( __PRETTY_FUNCTION__, " ROLLBACK command failed" );
        }

        this->alarm_restart_on_timeout->VerifyLagDifference(start);
        this->alarm_restart_on_timeout->DisableTimer();

        this->clear();
    }

    int RdmsPostgresql::getQtdRows()
    {
        return PQntuples(this->result);
    }

    int RdmsPostgresql::getQtdColumns()
    {
        return PQnfields(this->result);
    }

    int RdmsPostgresql::isNullField(int row, int column) {
        return PQgetisnull(this->result, row, column);
    }

    int RdmsPostgresql::getIndexField(const char * name) {
        return PQfnumber(this->result, name);
    }

    char * RdmsPostgresql::readField(int row, int column) {
        char * retValue;
        this->alarm_restart_on_timeout->EnableTimer("readField");
        retValue = PQgetvalue(this->result, row, column);
        this->alarm_restart_on_timeout->DisableTimer();
        return retValue;
    }

    void RdmsPostgresql::dump() {
        ;
    }

    StatementInterface * RdmsPostgresql::GetNewStatement( )
    {
        return new PGStmt( this );
    }

    void RdmsPostgresql::DropStatement(StatementInterface *stmt)
    {
        CloseStatement(stmt);
    }

    int RdmsPostgresql::CloseStatement(StatementInterface *stmt)
    {
        int qtdRem = 0;
        if( stmt )
        {
            if( !stmt->GetPreparedName().empty() )
            {
                qtdRem = mStatements.erase(stmt->GetPreparedName());
            }
            delete stmt;
        }
        stmt = NULL;

        return qtdRem;
    }

    PGconn * RdmsPostgresql::GetConn()
    {
        return conn;
    }
}
