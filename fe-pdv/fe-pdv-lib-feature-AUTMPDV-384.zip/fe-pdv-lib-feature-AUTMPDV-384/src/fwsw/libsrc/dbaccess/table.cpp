/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <sys/types.h>

/* for ntohl/htonl */
#include <netinet/in.h>
#include <arpa/inet.h>

#include <ist_cfg.h>

#include "time.h"
#include "dbaccess/table.hpp"
#include "dbaccess/Row.hpp"
#include "dbaccess/alarm_restart_on_timeout.hpp"

#include "base/GenException.hpp"

#include "dataManip/DataManip.hpp"

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

using namespace std;

namespace dbaccess
{
    table::table()
    {
        m_for_update = "";
    }

    table::~table()
    {
        cout << __PRETTY_FUNCTION__ << endl;
        database->clear();
    }

    string table::get_sql_insert( void )
    {
        if( query_fields.empty() || table_name.empty() )
        {
            throw base::GenException( __PRETTY_FUNCTION__, " query_fiels ou table_name vazio" );
        }

        string sql = "INSERT INTO ";
        sql.append( table_name );
        sql.append( " ( " );
        sql.append( query_fields );
        sql.append( " ) ");
        sql.append( " VALUES " );
        sql.append( " ( " );
        sql.append( parse_fields_for_insert(query_fields) );
        sql.append( " ) ");

        return sql;
    }

    string table::get_sql_select( void )
    {
        if( query_fields.empty() || table_name.empty() )
        {
            throw base::GenException( __PRETTY_FUNCTION__, " query_fiels ou table_name vazio" );
        }

        string sql = "SELECT ";
        sql.append( query_fields );
        sql.append( " FROM ");
        sql.append( table_name );

        if ( !where_condition.empty( ) )
        {
            sql.append( " WHERE ");
            sql.append( where_condition );
        }

        sql.append(m_for_update);

        return sql;
    }

    string table::get_sql_update( void )
    {
        if( query_fields.empty() || table_name.empty() )
        {
            throw base::GenException( __PRETTY_FUNCTION__, " query_fiels ou table_name vazio" );
        }

        string sql = "UPDATE ";
        sql.append( table_name );
        sql.append( " SET ");       
        sql.append( parse_fields_for_update(query_fields) );

        if ( !where_condition.empty( ) )
        {
            sql.append( " WHERE ");
            sql.append( where_condition );
        }

        return sql;
    }

    string table::get_sql_delete( void )
    {
        if( query_fields.empty() || table_name.empty() )
        {
            throw base::GenException( __PRETTY_FUNCTION__, " query_fiels ou table_name vazio" );
        }

        string sql = "DELETE FROM ";
        sql.append( table_name );
        sql.append( " WHERE ");
        sql.append( where_condition );

        return sql;
    }

    void table::prepare()
    {
        db_object::prepare();
    }

    void table::prepare( bool isDispatcher )
    {
        db_object::prepare( isDispatcher );
    }


    void table::prepare_for_update( int flag )
    {
		// Efetua teste se deve utilizar for update ou apenas um select simples
		if( conn->UseForUpdate() || flag == FLAG_FORCE_FOR_UPDATE )
        {
            m_for_update = " FOR UPDATE";
        }
		else
        {
			m_for_update = "";
        }

        db_object::prepare();
    }

    void table::prepare_for_update( )
    {  
        prepare_for_update( FLAG_NON_FORCE_FOR_UPDATE );
    }

    int table::GetCountFields( const string &queryFields )
    {
        int query_len = queryFields.length();
        int count = 0;

        for (int i = 0; i < queryFields.size(); i++ )
        {
            if (queryFields[i] == ',')
            {
                count++;
            }
        }

        if ( count > 1 )
        {
            count++;
        }

        return count;
    }
    string table::parse_fields_for_insert( const string &queryFields )
    {
        int count = GetCountFields(queryFields);
        string fields = "";
        char param[500] = {0};

        for ( int i=1; i <= count; i++ )
        {
            memset(param, 0, sizeof(param));
            if ( i < count )
            {
                switch ( bindings[i].type )
                {
                    case DB_DATETIME:
                        if ( bindings[i].bufferLen > 0 )
                        {
                            snprintf(param, sizeof(param), " to_timestamp($%d, 'YYYY-MM-DD HH24:MI:SS'),", i);
                        }
                        else
                        {
                            snprintf(param, sizeof(param), " $%d,", i);
                        }
                        break;

                    case DB_DATE:
                        if ( bindings[i].bufferLen > 0 )
                        {
                            snprintf(param, sizeof(param), " to_timestamp($%d, 'YYYYMMDD'),", i);
                        }
                        else
                        {
                            snprintf(param, sizeof(param), " $%d,", i);
                        }
                        break;

                    default:
                        snprintf(param, sizeof(param), " $%d,", i);
                        break;
                }
            }
            else
            {
                switch ( bindings[i].type )
                {
                    case DB_DATETIME:
                        if ( bindings[i].bufferLen > 0 )
                        {
                            snprintf(param, sizeof(param), " to_timestamp($%d, 'YYYY-MM-DD HH24:MI:SS') ", i);
                        }
                        else
                        {
                            snprintf(param, sizeof(param), " $%d ", i);
                        }
                        break;

                    case DB_DATE:
                        if ( bindings[i].bufferLen > 0 )
                        {
                            snprintf(param, sizeof(param), " to_timestamp($%d, 'YYYYMMDD') ", i);
                        }
                        else
                        {
                            snprintf(param, sizeof(param), " $%d ", i);
                        }
                        break;

                    default:
                        snprintf(param, sizeof(param), " $%d ", i);
                        break;
                }
            }
            
            fields.append(param);
        }

        return string(fields);
    }

    string table::parse_fields_for_update( const std::string &query_fields )
    {
		string update_string;
		int query_len = query_fields.length( );
		int init_pos = 0;
        char param[500] = {0};
        int i = 1;
        int field_name_len = 0;

		for ( int posicao = 0; posicao <= query_len; posicao ++ )
		{
			if ( query_fields[posicao] == ',' || posicao == query_len )
			{
				// Put a new field into update statement
				// If this is not the first field in the statement, put a ',' first.
				if ( !update_string.empty( ) )
                {
					update_string += ", ";
                }

				field_name_len = posicao - init_pos;

                memset(param, 0, sizeof(param));
                snprintf(param, sizeof(param), "%s = $%d", std::string( query_fields, init_pos, field_name_len ).c_str(), i++ );
				update_string.append(param);

				init_pos = posicao + 1;
				// Where the next field name starts
			}
		}

		if ( update_string.empty( ) )
        {
			throw base::GenException( __PRETTY_FUNCTION__, " Cannot parse query fields" );
        }

		return update_string;
    }

    void table::insert( void )
    {
        bind_columns();
        string sql = get_sql_insert();
        try {
            database->insert(sql.c_str(), GetCountFields(query_fields), paramValues, paramLengths, paramFormats);
        }
        catch (base::GenException e)
        {
            HandleDatabaseError(e.functionName(), e.what());
        }
        database->clear();
    }

    void table::update( void )
    {
        release_bindings();
        bind_columns();
        string sql = get_sql_update();
        try {
            database->clear();
            database->update(sql.c_str(), GetCountFields(query_fields), paramValues, paramLengths, paramFormats);
        }
        catch (base::GenException e)
        {
            HandleDatabaseError(e.functionName(), e.what());
        }
        database->clear();
    }

    void table::delete_record( void )
    {
        string sql = get_sql_delete();
        try {
            database->remove(sql.c_str());
        }
        catch (base::GenException e) {
            HandleDatabaseError(e.functionName(), e.what());
        }
        database->clear();
    }

    void table::bind_resultset( void )
    {
        bind_columns();
    }

    bool table::fetch()
    {
        if ( m_rowCounter <= 0 )
        {
            return false;
        }

        if ( ( m_rowNumber + 1 ) > m_rowCounter )
        {
            release_bindings();
            return false;
        }
        
        Row rowTable = Row(database, m_rowNumber++);
        bindings_t::iterator it = bindings.begin( );
        bindings_t::iterator end = bindings.end( );

        int i = -1;
        for ( ; it != end; it++ )
        {
            bind_t bind =( *it ).second;
            int pos =( *it ).first;
            i++;
            string value(rowTable.Get<string>(i).c_str());

            switch (bind.type)
            {
                case DB_CHAR:
                    memset( bind.buffer, 0, bind.bufferLen );
                    memcpy( bind.buffer, value.c_str(), value.size() );
                    break;
                case DB_INT:
                    *(int *)bind.buffer = rowTable.Get<int>(i);
                    break;
                case DB_UINT:
                    *(unsigned int *)bind.buffer = rowTable.Get<unsigned int>(i); 
                    break;
                case DB_LONG:
                    *(long *)bind.buffer = rowTable.Get<unsigned long>(i);
                    break;
                case DB_ULONG:
                    *(unsigned long *) bind.buffer = rowTable.Get<unsigned long>(i);
                    break;
                case DB_ULLONG:
                    *(unsigned long long *)bind.buffer = rowTable.Get<unsigned long long>(i);
                    break;
                case DB_DOUBLE:
                    *(double *)bind.buffer = atof(value.c_str());
                    break;
                case DB_FLOAT:
                    *(float *)bind.buffer = atof(value.c_str());
                    break;
                case DB_DECIMAL:
                    memset( bind.buffer, 0, bind.bufferLen );
                    memcpy( bind.buffer, value.c_str(), value.size() );
                    break;
                case DB_MONEY:
                    memcpy( bind.buffer, value.c_str(), value.size() );
                    break;
                case DB_DATE:
                    *(unsigned long *) bind.buffer = rowTable.GetDate(i);
                    break;
                case DB_DATETIME:
                    *(long *) bind.buffer = (dbm_datetime_t) rowTable.GetDateTime(i);
                    break;
                case DB_STRING:
                    memset( bind.buffer, 0, bind.bufferLen );
                    memcpy( bind.buffer, value.c_str(), value.size() );
                    break;
                default:
                    throw base::GenException( __PRETTY_FUNCTION__, "fetch() - DataType Unknow " );
                    break;
            }

            // se campo for nulo na tabela, ativa flag de campo retornou nulo
            if ( rowTable.IsNull(i) )
            {
                *(int *)bind.status = (int) DBM_NULL_DATA;
            }
            else
            {
                *(int *)bind.status = (int) 0;
            }

        }

        handle_fetch();
        return true;
    }

    void table::execute()
    {
        string sql = get_sql_select();
        clean_output_bindings( );
        handle_parameters();
        
        try {
            database->clear();
            database->select(sql.c_str());
        }
        catch (base::GenException e) {
            HandleDatabaseError(e.functionName(), e.what());
            printf("passei aqui depois do Handle\n");
        }
        
        if (database->getQtdRows()  <= 0){
            m_rowCounter = 0;
        } else {
            m_rowNumber = 0;
            m_rowCounter = database->getQtdRows();
        }

        bind_resultset();
   }

    void table::setTableName( const string tbName )
    {
        table_name = tbName;
    }
    
    const std::string table::getTableName() const
    {
        return table_name;
    }

	std::string table::getSqlDump()
	{
		return std::string( "dbaccess: getSqlDump() has not been implemented" );
	}

    void table::HandleDatabaseError(const char* functionName, const char* errorMessage)
    {
        database->clear();
        char logMessage[2048] = {0};
        snprintf(logMessage, sizeof(logMessage) - 1, "%s - %s", functionName, errorMessage);

        char restartOnTimeoutFlag[128] = {0};
        if( cf_locate( "restart_on_timeout", restartOnTimeoutFlag ) > 0 )
		{
			if (strcmp(restartOnTimeoutFlag, "Y") == 0) {
				AlarmRestartOnTimeout::KillProcess(logMessage);
			}
		}
		
        // Caso flag restart_on_timeout esteja desligada/inexistente
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, logMessage );
		dataManip::DataManip::SetDbDropTrx(true); // Faz a mensagem ser dropada na volta pro StandardTrxEngine
		throw base::GenException();	// Para interromper processamento do plugin
    }

}
