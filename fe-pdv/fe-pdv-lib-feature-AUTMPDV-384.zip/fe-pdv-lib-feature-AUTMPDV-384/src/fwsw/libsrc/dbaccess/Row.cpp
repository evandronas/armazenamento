/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#include "dbaccess/Row.hpp"

#include "base/ToException.hpp"
#include "base/GenException.hpp"

using namespace std;

Row::Row(dbaccess::RdmsInterface* _database, int _rowno):
    database(_database),
    rowno(_rowno)
{}

bool Row::operator ==(const Row &other) const
{
    return rowno == other.rowno && database == other.database;
}

bool Row::operator !=(const Row &other) const
{
    return !((*this) == other);
}

bool Row::operator <(const Row &other) const
{
    assert(database == other.database);
    return rowno < other.rowno;
}

const Row &Row::operator ++()
{
    rowno++;
    return *this;
}

long Row::GetDateTime(int colno)
{
    assert(rowno < database->getQtdRows());
    assert(colno < database->getQtdColumns());

    struct tm timeStamp;
    char dataHora[20] = {0};
    string dateTime(database->readField(rowno, colno));

    strptime(dateTime.c_str(), "%Y-%m-%d %H:%M:%S", &timeStamp);
    timeStamp.tm_isdst = -1;

    return mktime(&timeStamp);
}

unsigned long Row::GetDate(int colno)
{
    assert(rowno < database->getQtdRows());
    assert(colno < database->getQtdColumns());

    struct tm timeStamp;
    char dataHora[20] = {0};
    string dateTime(database->readField(rowno, colno));

    strptime(dateTime.c_str(), "%Y-%m-%d %H:%M:%S", &timeStamp);
    memset(dataHora, 0, sizeof(dataHora));
    strftime(dataHora, sizeof(dataHora), "%Y%m%d", &timeStamp);
    return atoll(dataHora);
}

bool Row::IsNull(int colno)
{
    assert(rowno < database->getQtdRows());
    assert(colno < database->getQtdColumns());

    return database->isNullField(rowno, colno);
}

template <>
string Row::Get<string> (int colno) 
{
    assert(rowno < database->getQtdRows());
    assert(colno < database->getQtdColumns());
    return string(database->readField(rowno, colno));
}

template <>
int Row::Get<int> (int colno) 
{
    assert(rowno < database->getQtdRows());
    assert(colno < database->getQtdColumns());

    return atoi(database->readField(rowno, colno));
}

template <>
unsigned Row::Get<unsigned> (int colno) 
{
    assert(rowno < database->getQtdRows());
    assert(colno < database->getQtdColumns());

    return (unsigned int ) atoi(database->readField(rowno, colno));
}

template <>
long Row::Get<long> (int colno)
{
    assert(rowno < database->getQtdRows());
    assert(colno < database->getQtdColumns());

    char* value = database->readField(rowno, colno);
    long ret = atol(value);
    return ret;
}

template <>
unsigned long Row::Get<unsigned long> (int colno) 
{    
    return static_cast<unsigned long>(this->Get<long>(colno));
}

template <>
long long Row::Get<long long> (int colno) 
{
    assert(rowno < database->getQtdRows());
    assert(colno < database->getQtdColumns());

    char* value = database->readField(rowno, colno);
    long ret = atoll(value);

    return ret;
}

template <>
unsigned long long Row::Get<unsigned long long> (int colno) 
{
    return static_cast<unsigned long long>(this->Get<long long>(colno));
}
