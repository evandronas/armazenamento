#include "dbaccess/alarm_restart_on_timeout.hpp"

#include <iostream>
#include <sstream>
#include <time.h>
#include <signal.h>
#include <sys/time.h>
#include <unistd.h>
#include <ist_cfg.h>
#include <algorithm>

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "ShmMonDb.hpp"
#include "staticLib/SmartLog.hpp"

#define ALARM_TIME_DEFAULT           10
#define DISPATCHER_ALARM_DEFAULT     45
#define SQLNET_TIMEOUT_SIGNAL        4

extern "C" { int delete_private_mbox(void); }

namespace dbaccess
{
    AlarmRestartOnTimeout::AlarmRestartOnTimeout() {
        this->alarmEnabled           = false;
        this->alarmDispatcherEnabled = false;
        this->alarmLagTimeLimit      = 0;
        this->alarmTimer             = ALARM_TIME_DEFAULT;
        this->alarmDispatcherTimer   = DISPATCHER_ALARM_DEFAULT;

        cf_open("cfg/istparam.cfg");
        configure();
    }


    AlarmRestartOnTimeout::~AlarmRestartOnTimeout() {}


    void AlarmRestartOnTimeout::configure()
    {
        char istparamFlag[128] = {0};

        if (cf_locate("restart_on_timeout_byapp", istparamFlag) > 0) {
            syslg("Restart on TimeOut by Application : [%s]\n", istparamFlag);

            if (strcmp(istparamFlag, "Y") == 0) {
                this->alarmEnabled = true;

                if (cf_locate("restart_on_timeout_byapp_time", istparamFlag) > 0) {
                    this->alarmTimer = atoi(istparamFlag);
                }
                syslg("Restart on TimeOut by Application - Time : [%d]\n", this->alarmTimer);
            }
        }

        if (cf_locate("restart_on_dispatcher_timeout_byapp", istparamFlag) > 0) {
            syslg("Restart on Dispatcher TimeOut by Application : [%s]\n", istparamFlag);

            if (strcmp(istparamFlag, "Y") == 0) {
                this->alarmDispatcherEnabled = true;

                if (cf_locate("restart_on_dispatcher_timeout_byapp_time", istparamFlag) > 0) {
                    this->alarmDispatcherTimer = atoi(istparamFlag);
                }
                syslg("Restart on Dispatcher TimeOut by Application - Time : [%d]\n", this->alarmDispatcherTimer);
            }
        }

        if (cf_locate("database.lag_alert_ms", istparamFlag ) > 0 ) {
            syslg("Lag Alert (ms): [%s]\n", istparamFlag);

            int limit = atoi(istparamFlag);
            this->alarmLagTimeLimit = limit > 0 ? limit : 0;
        }
    }

    /** EnableTimer
    * Ativar o Alarme de Timeout
    **/
    void AlarmRestartOnTimeout::EnableTimer(const char * message, bool isDispatcher)
    {
        error_message.assign(message);

        if (IsAlarmEnabled(isDispatcher) == false) {
            return;
        }

        int timer = (isDispatcher == true ? this->alarmDispatcherTimer : this->alarmTimer);
        DisableTimer();

        struct sigaction sigact;
        sigact.sa_handler = AlarmRestartOnTimeout::SignalHandler;
        sigact.sa_flags   = SA_RESETHAND;
        sigemptyset(&sigact.sa_mask);
        sigaction(SIGALRM, &sigact, NULL);

        alarm(timer);
    }

    /** DisableTimer
    * Desativar o Alarme de Timeout
    **/
    void AlarmRestartOnTimeout::DisableTimer()
    {
        alarm(0);
        error_message.assign("");
    }


    /** VerifyLagDifference
    * Verifica se o tempo desde um clock estourou o limite de lag, caso seja verdade faz o log no AIXsyslg e no debug
    * param: 
    *   start: o timeval a partir do qual deseja-se calcular a diferenca
    **/
    void AlarmRestartOnTimeout::VerifyLagDifference(struct timeval start)
    {
        try {
            struct timeval now;
            gettimeofday(&now, 0);

            float diff = (float) ((now.tv_sec - start.tv_sec) * 1000000 + ((int)now.tv_usec - (int)start.tv_usec));
            diff /= 1000; // em milisegundos

            if (diff > this->alarmLagTimeLimit) {
                char msgLog[200] = {0};
                snprintf(msgLog, sizeof(msgLog) - 1,
                    "[ALERT] connection::VerifyLagDifference - DB Lag [%f ms] reached time limit [%d ms]", diff, alarmLagTimeLimit);

                staticlib::SmartLog::SmartDebug(logger::LEVEL_WARNING, "[LAG]", msgLog);
                staticlib::SmartLog::SmartSyslg("[LAG]", msgLog);
            }
        }
        catch (std::exception e) {
            syslg("Exception occurred while checking lag time in DB => [%s]\n", e.what());
        }
    }

    /** IsAlarmEnabled
    * Getter para a variavel IsAlarmEnabled, que diz se deve usar o timeout alarm
    **/
    bool AlarmRestartOnTimeout::IsAlarmEnabled(bool isDispatcher)
    {
        if (isDispatcher)
            return this->alarmDispatcherEnabled;
        else
            return this->alarmEnabled;
    }

    /** SignalHandler
    * Tratamento do Alarme de Timeout
    **/
    extern "C" void AlarmRestartOnTimeout::SignalHandler(int signal)
    {
        if (signal == SIGALRM) 
        {
            KillProcess("APPLICATION TIMEOUT\n");
            syslg("delete_private_mbox [%d]\n", delete_private_mbox());
            exit(SQLNET_TIMEOUT_SIGNAL);
        }
    }

    /** KillProcess
    * Mata o processo atual
    **/
    void AlarmRestartOnTimeout::KillProcess(const char * msgText)
    {
        ShmMonDb * shm = ShmMonDb::getInstance();
        syslg("Shm Timeout = RC[%d]\n", shm->IncrementLocalTimeout(0));

        char msgLog[200] = {0};
        sprintf(msgLog, "ERROR: POSTGRESQL => %s [%s]\n", msgText, error_message.c_str());
        syslg(msgLog);
        logger::DebugWriter::getInstance( )->write( logger::LEVEL_FATAL, msgLog );

        syslg("Killing pid %d\n", getpid());
        kill(getpid(), SQLNET_TIMEOUT_SIGNAL);
    }
}