/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "fieldSet/ConstFieldAccess.hpp"

namespace fieldSet
{
	ConstFieldAccess::ConstFieldAccess( )
	{
		m_pField = 0;
	}
	ConstFieldAccess::ConstFieldAccess( const Field& a_field )
	{
		m_pField = a_field.constPtr( );
	}
	ConstFieldAccess::ConstFieldAccess( const Field& a_field, const std::string& a_label )
	{
		m_pField = a_field.find( a_label ).constPtr( );
	}
	ConstFieldAccess::~ConstFieldAccess( )
	{
	}
	const Field& ConstFieldAccess::field( ) const
	{
		base::genAssertPtr( m_pField, __FUNCTION__, "Field not initialised" );
		return *m_pField;
	}
	const std::string& ConstFieldAccess::value( ) const
	{
		base::genAssertPtr( m_pField, __FUNCTION__, "Field not initialised" );
		return m_pField->value( );
	}
	const unsigned char* ConstFieldAccess::data( ) const
	{
		base::genAssertPtr( m_pField, __FUNCTION__, "Field not initialised" );
		return m_pField->data( );
	}
	bool ConstFieldAccess::operator!( ) const
	{
		if ( m_pField == 0 )
		{
			return true;
		}
		bool l_ret = m_pField->isDummy( );
		return l_ret;
	}
	
	// length
	// Retorna o valor do argumento length da classe Field
	// EF/ET: 44179
	// Historico: [06/10/2014] - 44179 - Release I de 2014
	unsigned int ConstFieldAccess::Length( ) const
	{
		return m_pField->length( );
	}

	// CstrLength
	// Retorna o valor do argumento CstrLength da classe Field
	// EF/ET: 44179
	// Historico: [06/10/2014] - 44179 - Release I de 2014
	unsigned int ConstFieldAccess::CstrLength( ) const
	{
		return m_pField->CstrLength( );
	}
}//namespace fieldSet

