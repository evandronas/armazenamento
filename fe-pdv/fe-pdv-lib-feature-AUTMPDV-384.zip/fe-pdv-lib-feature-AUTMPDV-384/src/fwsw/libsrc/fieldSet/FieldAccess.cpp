/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace fieldSet
{
	FieldAccess::FieldAccess( )
	{
		m_pField = 0;
	}
	FieldAccess::FieldAccess( Field& a_field )
	{
		m_pField = a_field.ptr( );
	}
	FieldAccess::FieldAccess( Field& a_field, const std::string& a_label )
	{
		m_pField = a_field.find( a_label ).ptr( );
	}
	FieldAccess::~FieldAccess( )
	{
	}
	Field& FieldAccess::field( )
	{
		base::genAssertPtr( m_pField, __FUNCTION__, "Field not initialised" );
		return *m_pField;
	}
	const std::string& FieldAccess::value( ) const
	{
		base::genAssertPtr( m_pField, __FUNCTION__, "Field not initialised" );
		return m_pField->value( );
	}
	const unsigned char* FieldAccess::data( ) const
	{
		base::genAssertPtr( m_pField, __FUNCTION__, "Field not initialised" );
		return m_pField->data( );
	}
	bool FieldAccess::operator!( ) const
	{
		if ( m_pField == 0 )
		{
			return true;
		}
		bool l_ret = m_pField->isDummy( );
		return l_ret;
	}

	// Length
	// Retorna o valor do argumento Length da classe FieldAccess
	// EF/ET: 44179
	// Hist�rico: [06/10/2014] - 44179 - Release I de 2014
	unsigned int FieldAccess::Length( ) const
	{
		return m_pField->length( );
	}
	
	// CstrLength
	// Retorna o valor do argumento CstrLength da classe FieldAccess
	// EF/ET: 44179
	// Hist�rico: [06/10/2014] - 44179 - Release I de 2014
	unsigned int FieldAccess::CstrLength( ) const
	{
		return m_pField->CstrLength( );
	}
}//namespace fieldSet

