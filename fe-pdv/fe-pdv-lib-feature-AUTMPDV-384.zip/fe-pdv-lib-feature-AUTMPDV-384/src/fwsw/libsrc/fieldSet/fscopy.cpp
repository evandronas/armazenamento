/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <string>
#include "fieldSet/fscopy.hpp"

namespace fieldSet
{
	fscopy::fscopy( Field& a_field, const char* a_data, unsigned int a_length )
	{
		a_field.input( a_data, a_length );
	}
	fscopy::fscopy( Field& a_field, const unsigned char* a_data, unsigned int a_length )
	{
		a_field.input( a_data, a_length );
	}
	fscopy::fscopy( Field& a_field, char a_data )
	{
		char l_value[8];
		int l_len = snprintf( l_value, sizeof l_value, "%c", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, unsigned char a_data )
	{
		char l_value[8];
		int l_len = snprintf( l_value, sizeof l_value, "%c", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, long a_data )
	{
		char l_value[64];
		int l_len = snprintf( l_value, sizeof l_value, "%ld", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, unsigned long a_data )
	{
		char l_value[64];
		int l_len = snprintf( l_value, sizeof l_value, "%lu", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, int a_data )
	{
		char l_value[64];
		int l_len = snprintf( l_value, sizeof l_value, "%d", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, unsigned int a_data )
	{
		char l_value[64];
		int l_len = snprintf( l_value, sizeof l_value, "%u", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, short a_data )
	{
		char l_value[64];
		int l_len = snprintf( l_value, sizeof l_value, "%hd", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, float a_data )
	{
		char l_value[64];
		int l_len = snprintf( l_value, sizeof l_value, "%f", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, double a_data )
	{
		char l_value[64];
		int l_len = snprintf( l_value, sizeof l_value, "%f", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( Field& a_field, unsigned short a_data )
	{
		char l_value[64];
		int l_len = snprintf( l_value, sizeof l_value, "%hu", a_data );
		if ( l_len > 0 )
		{
			a_field.input( l_value, static_cast<unsigned int>( l_len ) );
		}
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, const char* a_data, unsigned int a_length )
	{
		fscopy( a_fieldAccess.field( ), a_data, a_length );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, const unsigned char* a_data, unsigned int a_length )
	{
		fscopy( a_fieldAccess.field( ), a_data, a_length );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, char a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, unsigned char a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, long a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, unsigned long a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, int a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, unsigned int a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, short a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, float a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, double a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldAccess, unsigned short a_data )
	{
		fscopy( a_fieldAccess.field( ), a_data );
	}
	fscopy::fscopy( FieldAccess& a_fieldDestino, FieldAccess& a_fieldOrigem )
	{
		fscopy( a_fieldDestino.field( ), a_fieldOrigem.value( ) );
	}
	fscopy::fscopy( FieldAccess& a_fieldDestino, ConstFieldAccess& a_fieldOrigem )
	{
		fscopy( a_fieldDestino.field( ), a_fieldOrigem.value( ) );
	}
	fscopy::fscopy( FieldAccess& a_field, const std::string& a_data )
	{
		fscopy( a_field.field( ), a_data );
	}
	fscopy::fscopy( Field& a_field, const std::string& a_data )
	{
		a_field.input( a_data );
	}
}//namespace fieldSet

