/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <cstring>
#include "base/GenException.hpp"
#include "fieldSet/Field.hpp"

namespace fieldSet
{
	Field::Field( )
	{
		this->setLabel( "nolabel" );
		m_isDummy		= false;
		m_isOn			= true;
		m_isSecure		= false;
		m_data          = "";
		m_mask          = "";
		m_securityMask  = "";
		m_defaultData   = "";

	}
	Field::Field( const char* a_label )
	{
		std::string l_label = std::string( a_label ).length( ) == 0 ? "nolabel" : a_label;
		this->setLabel( l_label );
		m_isDummy		= false;
		m_isOn			= true;
		m_isSecure		= false;
                m_data          = "";
                m_mask          = "";
                m_securityMask  = "";
                m_defaultData   = "";

	}
	Field::Field( bool a_isDummy )
	{
		std::string l_label		= a_isDummy ? "dummy" : "nolabel";
		this->setLabel( l_label );
		m_isDummy	= a_isDummy;
		m_isOn		= !a_isDummy;
		m_isSecure	= false;
                m_data          = "";
                m_mask          = "";
                m_securityMask  = "";
                m_defaultData   = "";
	}
	Field::Field( const Field& a_orig )
	{
		m_isDummy = false;
		this->assign( a_orig );
	}
	Field& Field::operator=( const Field& a_orig )
	{
		return this->assign( a_orig );
	}
	Field::~Field( )
	{
	}
	Field& Field::setLabel( const std::string& a_label )
	{
		m_label = a_label;
		return *this;
	}
	const std::string& Field::label( ) const
	{
		return m_label;
	}
	unsigned int Field::size( ) const
	{
		return 0;
	}
	Field& Field::assign( const Field& a_orig )
	{
		if ( m_isDummy )
		{
			return *this;
		}
		m_label			= a_orig.m_label;
		m_data			= a_orig.m_data;
		m_mask			= a_orig.m_mask;
		m_securityMask	= a_orig.m_securityMask;
		m_isDummy		= a_orig.m_isDummy;
		m_isOn			= a_orig.m_isOn;
		m_isSecure		= a_orig.m_isSecure;
		m_defaultData	= a_orig.m_defaultData;
		return *this;
	}
	Field& Field::input( const Field& a_fieldToCopyData )
	{
		if ( !this->isDummy( ) )
		{
			m_data.assign( reinterpret_cast<const char*>( a_fieldToCopyData.data( ) ), a_fieldToCopyData.length( ) );
		}
		return *this;
	}
	Field& Field::input( const char* a_data, unsigned int a_maxLength )
	{
		if ( !this->isDummy( ) )
		{
			m_data.assign( a_data, strnlen( a_data, a_maxLength ) );
		}
		return *this;
	}
	Field& Field::input( const unsigned char* a_data, unsigned int a_length )
	{
		if ( !this->isDummy( ) )
		{
			m_data.assign( reinterpret_cast<const char*>( a_data ), a_length );
		}
		return *this;
	}
	Field& Field::inputDefault( const char* a_data, unsigned int a_length )
	{
		if ( !this->isDummy( ) )
		{
			m_defaultData.assign( a_data, a_length );
		}
		return *this;
	}
	Field& Field::input( const Field* a_fieldToCopyData )
	{
		base::genAssert( a_fieldToCopyData == 0, __FUNCTION__, "Invalid fieldSet::Field pointer" );
		if ( !this->isDummy( ) )
		{
			m_data.assign( reinterpret_cast<const char*>( a_fieldToCopyData->data( ) ), a_fieldToCopyData->length( ) );
		}
		return *this;
	}
	Field& Field::input( const std::string& a_data )
	{
		m_data = a_data;
		return *this;
	}
	Field& Field::inputDefault( const std::string& a_data )
	{
		m_defaultData = a_data;
		return *this;
	}
	Field& Field::clearData( )
	{
		m_data = m_defaultData;
		return *this;
	}
	const Field& Field::find( const std::string& a_label ) const
	{
		base::genAssert( this->isDummy( ), __FUNCTION__, "No subfields for <" + label( ) + ">" );
		return *this;
	}
	Field& Field::find( const std::string& a_label )
	{
		base::genAssert( this->isDummy( ), __FUNCTION__, "No subfields for <" + label( ) + ">" );
		return *this;
	}
	const Field& Field::findRequired( const std::string& a_label ) const
	{
		throw base::GenException( __FUNCTION__, "No subfields for <" + label( ) + ">" );
	}
	Field& Field::findRequired( const std::string& a_label )
	{
		throw base::GenException( __FUNCTION__, "No subfields for <" + label( ) + ">" );
	}
	unsigned int Field::findIndexer( const std::string& a_label ) const
	{
		base::genAssert( this->isDummy( ), __FUNCTION__, "No subfields for <" + label( ) + ">" );
		return 0;
	}
	const Field& Field::at( unsigned int a_indexer ) const
	{
		base::genAssert( this->isDummy( ), __FUNCTION__, "No subfields for <" + label( ) + ">" );
		return *this;
	}
	Field& Field::at( unsigned int a_indexer )
	{
		base::genAssert( this->isDummy( ), __FUNCTION__, "No subfields for <" + label( ) + ">" );
		return *this;
	}
	const Field& Field::operator[]( unsigned int a_indexer ) const
	{
		base::genAssert( this->isDummy( ), __FUNCTION__, "No subfields for <" + label( ) + ">" );
		return *this;
	}
	Field& Field::operator[]( unsigned int a_indexer )
	{
		base::genAssert( this->isDummy( ), __FUNCTION__, "No subfields for <" + label( ) + ">" );
		return *this;
	}
	Field& Field::setMask( const std::string& a_mask )
	{
		m_mask = a_mask;
		return *this;
	}
	Field& Field::setSecurityMask( const std::string& a_securityMask )
	{
		m_securityMask = a_securityMask;
		return *this;
	}
	const std::string& Field::mask( ) const
	{
		return m_mask;
	}
	const std::string& Field::securityMask( ) const
	{
		return m_securityMask;
	}
	bool Field::isDummy( ) const
	{
		return m_isDummy;
	}
	bool Field::isOn( ) const
	{
		return m_isOn;
	}
	Field& Field::turnOn( )
	{
		m_isOn = true;
		return *this;
	}
	Field& Field::turnOff( )
	{
		m_isOn = false;
		return *this;
	}
	bool Field::isSecure( ) const
	{
		return m_isSecure;
	}
	Field& Field::setSecure( bool a_isSecure )
	{
		m_isSecure = a_isSecure;
		return *this;
	}
	Field* Field::clone( ) const
	{
		return new Field( *this );
	}
	const std::string& Field::value( ) const
	{
		return m_data;
	}
	const unsigned char* Field::data( ) const
	{
		return reinterpret_cast<const unsigned char*>( m_data.data( ) );
	}
	const char* Field::c_str( ) const
	{
		return m_data.c_str( );
	}
	unsigned int Field::length( ) const
	{
		return m_data.length( );
	}
	
	// CstrLength
	// Retorna tamanho da string de dados
	// EF/ET: 44179
	// Hist�rico: [06/10/2014] - 44179 - Release I de 2014
	// Hist�rico: [08/11/2016] - 67514 - Release I de 2017
	unsigned int Field::CstrLength( ) const
	{
		unsigned int localLength = strlen( m_data.c_str( ) );
		return localLength;
	}
	Field* Field::ptr( )
	{
		return this;
	}
	const Field* Field::constPtr( ) const
	{
		return this;
	}
	Field& Field::ref( )
	{
		return *this;
	}
	const Field& Field::constRef( ) const
	{
		return *this;
	}
	Field& Field::addField( const Field& a_newField )
	{
		throw base::GenException( __FUNCTION__, "This is a simple field, it can not to have subfields." );
		return *this;
	}
}//namespace fieldSet

