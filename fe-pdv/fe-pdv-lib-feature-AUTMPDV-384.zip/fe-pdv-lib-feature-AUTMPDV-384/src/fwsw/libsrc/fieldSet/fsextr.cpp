/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <cstring>
#include <cstdlib>
#include "fieldSet/fsextr.hpp"

namespace fieldSet
{
	fsextr::fsextr( std::string& a_data, const Field& a_field )
	{
		a_data.assign( reinterpret_cast<const char*>( a_field.data( ) ), a_field.length( ) );
	}
	fsextr::fsextr( char* a_data, unsigned int a_length, const Field& a_field )
	{
		memset( a_data, 0, a_length );
		unsigned int l_size =
			a_length <= a_field.length( ) ? a_length - 1 : a_field.length( );
		memcpy( a_data, a_field.data( ), l_size );
	}
	fsextr::fsextr( unsigned char* a_data, unsigned int a_length, const Field& a_field )
	{
		memset( a_data, 0, a_length );
		unsigned int l_size =
			a_length <= a_field.length( ) ? a_length : a_field.length( );
		memcpy( a_data, a_field.data( ), l_size );
	}
	fsextr::fsextr( char& a_data, const Field& a_field )
	{
		if ( a_field.length( ) > 0 )
		{
			a_data = ( char )a_field.data( )[0];
		}
	}
	fsextr::fsextr( unsigned char& a_data, const Field& a_field )
	{
		if ( a_field.length( )> 0 )
		{
			a_data =( unsigned char )a_field.data( )[0];
		}
	}
	fsextr::fsextr( long& a_data, const Field& a_field )
	{
		a_data = strtol( a_field.c_str( ), NULL, 10 );
	}
	fsextr::fsextr( unsigned long& a_data, const Field& a_field )
	{
		a_data = static_cast<unsigned long>( strtoul( a_field.c_str( ), NULL, 10 ) );
	}
	fsextr::fsextr( int& a_data, const Field& a_field )
	{
		a_data = atoi( a_field.c_str( ) );
	}
	fsextr::fsextr( unsigned int& a_data, const Field& a_field )
	{
		a_data = static_cast<unsigned int>( strtoul( a_field.c_str( ), NULL, 10 ) );
	}
	fsextr::fsextr( short& a_data, const Field& a_field )
	{
		a_data = static_cast<short>( atoi( a_field.c_str( ) ) );
	}
	fsextr::fsextr( unsigned short& a_data, const Field& a_field )
	{
		a_data = static_cast<unsigned short>( strtoul( a_field.c_str( ), NULL, 10 ) );
	}
	fsextr::fsextr( float& a_data, const Field& a_field )
	{
		a_data = static_cast<float>( atof( a_field.c_str( ) ) );
	}
	fsextr::fsextr( double& a_data, const Field& a_field )
	{
		a_data = atof( a_field.c_str( ) );
	}
	fsextr::fsextr( std::string& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( char* a_data, unsigned int a_length, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_length, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned char* a_data, unsigned int a_length, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_length, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( char& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned char& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( long& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned long& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( int& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned int& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( short& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned short& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	
	fsextr::fsextr( float& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( double& a_data, ConstFieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	/////////////////////////////
	//////////////////////////////
	fsextr::fsextr( std::string& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( char* a_data, unsigned int a_length, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_length, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned char* a_data, unsigned int a_length, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_length, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( char& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned char& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( long& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned long& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( int& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned int& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( short& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( unsigned short& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	
	fsextr::fsextr( float& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
	fsextr::fsextr( double& a_data, FieldAccess& a_fieldAccess )
	{
		fsextr( a_data, a_fieldAccess.field( ) );
	}
}//namespace fieldSet

