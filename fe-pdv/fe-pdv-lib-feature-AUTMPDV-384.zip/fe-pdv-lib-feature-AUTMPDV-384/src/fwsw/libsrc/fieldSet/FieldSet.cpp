/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "fieldSet/FieldSet.hpp"

namespace fieldSet
{
	FieldSet::FieldSet( )
	: Field( )
	{
		this->clear( );
	}
	FieldSet::~FieldSet( )
	{
		DEQUE_FIELDS::const_iterator l_it;
		for ( l_it = m_fields.begin( ); l_it != m_fields.end( ); ++l_it )
		{
			delete *l_it;
		}
		m_fields.clear( );
		m_mapByLabel.clear( );
	}
	FieldSet::FieldSet( const FieldSet& a_orig )
	{
		this->assign( a_orig );
	}
	Field& FieldSet::operator=( const Field& a_orig )
	{
		return this->assign( a_orig );
	}
	Field& FieldSet::assign( const Field& a_orig )
	{
		Field::assign( a_orig );
		DEQUE_FIELDS::const_iterator l_it;
		this->clear( );
		for ( unsigned int l_pos = 0; l_pos < a_orig.size( ); ++l_pos )
		{
			this->addField( a_orig[l_pos] );
		}
		return *this;
	}
	FieldSet& FieldSet::clear( )
	{
		DEQUE_FIELDS::const_iterator l_it;
		for ( l_it = m_fields.begin( ); l_it != m_fields.end( ); ++l_it )
		{
			delete *l_it;
		}
		m_fields.clear( );
		m_mapByLabel.clear( );
		Field l_dummy( true );
		this->addField( l_dummy );
		return *this;
	}
	Field& FieldSet::clearData( )
	{
		DEQUE_FIELDS::iterator l_it;
		for ( l_it = m_fields.begin( ); l_it != m_fields.end( ); ++l_it )
		{
			( *l_it )->clearData( );
		}
		Field::clearData( );
		return *this;
	}
	Field& FieldSet::turnOff( )
	{
		DEQUE_FIELDS::iterator l_it;
		for ( l_it = m_fields.begin( ); l_it != m_fields.end( ); ++l_it )
		{
			( *l_it )->turnOff( );
		}
		Field::turnOff( );
		return *this;
	}
	Field& FieldSet::turnOn( )
	{
		DEQUE_FIELDS::iterator l_it;
		for ( l_it = m_fields.begin( ); l_it != m_fields.end( ); ++l_it )
		{
			( *l_it )->turnOn( );
		}
		Field::turnOn( );
		return *this;
	}
	unsigned int FieldSet::size( ) const
	{
		return m_fields.size( ) == 0 ? 0 : m_fields.size( ) - 1;
	}
	const Field& FieldSet::find( const std::string& a_label ) const
	{
		MAP_BY_LABEL::const_iterator l_it = m_mapByLabel.find( a_label );
		if ( l_it == m_mapByLabel.end( ) )
		{
			return *( m_fields[0] );
		}
		return *( m_fields[l_it->second] );
	}
	Field& FieldSet::find( const std::string& a_label )
	{
		MAP_BY_LABEL::iterator l_it = m_mapByLabel.find( a_label );
		if ( l_it == m_mapByLabel.end( ) )
		{
			return *( m_fields[0] );
		}
		return *( m_fields[l_it->second] );
	}
	const Field& FieldSet::findRequired( const std::string& a_label ) const
	{
		MAP_BY_LABEL::const_iterator l_it = m_mapByLabel.find( a_label );
		if ( l_it == m_mapByLabel.end( ) )
		{
			throw base::GenException( __FUNCTION__, "Subfield <" + a_label + "> not found into <" + this->label( ) + ">" );
		}
		return *( m_fields[l_it->second] );
	}
	Field& FieldSet::findRequired( const std::string& a_label )
	{
		MAP_BY_LABEL::iterator l_it = m_mapByLabel.find( a_label );
		if ( l_it == m_mapByLabel.end( ) )
		{
			throw base::GenException( __FUNCTION__, "Subfield <" + a_label + "> not found into <" + this->label( ) + ">" );
		}
		return *( m_fields[l_it->second] );
	}
	unsigned int FieldSet::findIndexer( const std::string& a_label ) const
	{
		MAP_BY_LABEL::const_iterator l_it = m_mapByLabel.find( a_label );
		if ( l_it == m_mapByLabel.end( ) )
		{
			return npos;
			//Dummy Field Position
		}
		return l_it->second - 1;
	}
	const Field& FieldSet::at( unsigned int a_indexer ) const
	{
		if ( a_indexer == npos )
		{
			return *( m_fields[0] );
		}
		if ( a_indexer + 1 > m_fields.size( ) )
		{
			return *( m_fields[0] );
		}
		return *( m_fields[a_indexer+1] );
	}
	Field& FieldSet::at( unsigned int a_indexer )
	{
		if ( a_indexer == npos )
		{
			return *( m_fields[0] );
		}
		if ( a_indexer + 1 > m_fields.size( ) )
		{
			return *( m_fields[0] );
		}
		return *( m_fields[a_indexer+1] );
	}
	const Field& FieldSet::operator[]( unsigned int a_indexer ) const
	{
		return this->at( a_indexer );
	}
	Field& FieldSet::operator[]( unsigned int a_indexer )
	{
		return this->at( a_indexer );
	}
	FieldSet& FieldSet::addField( Field* a_newField )
	{
		unsigned int l_indexer = m_fields.size( );
		std::pair<MAP_BY_LABEL::iterator, bool> l_ret;
		l_ret = m_mapByLabel.insert( PAIR_MAP_BY_LABEL( a_newField->label( ), l_indexer ) );
		if ( l_ret.second )
		{
			m_fields.push_back( a_newField );
		}
		else
		{
			delete a_newField;
		}
		return *this;
	}
	Field& FieldSet::addField( const Field& a_newField )
	{
		Field* l_newField = a_newField.clone( );
		unsigned int l_indexer = m_fields.size( );
		std::pair<MAP_BY_LABEL::iterator, bool> l_ret;
		l_ret = m_mapByLabel.insert( PAIR_MAP_BY_LABEL( l_newField->label( ), l_indexer ) );
		if ( l_ret.second )
		{
			m_fields.push_back( l_newField );
		}
		else
		{
			delete l_newField;
		}
		return *this;
	}
	Field* FieldSet::clone( ) const
	{
		return new FieldSet( *this );
	}
}//namespace fieldSet

