/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "fieldSet/FieldNavigator.hpp"
#include "configBase/Util.hpp"


namespace fieldSet
{
	FieldNavigator::FieldNavigator( )
	{
		m_ignoreDummyFields = true;
	}
	FieldNavigator::~FieldNavigator( )
	{
	}
	void FieldNavigator::enableDummyFieldException( bool a_enable ) const
	{
		m_ignoreDummyFields = !a_enable;
	}
	void FieldNavigator::copyPaths( TP_PATHS& l_paths ) const
	{
		TPMAP::const_iterator l_it;
		
		for ( l_it = m_fieldSets.begin( ); l_it != m_fieldSets.end( ); ++l_it )
		{
			l_paths.push_back( TPPAIR( l_it->first, l_it->second ) );
		}
	}
	Field& FieldNavigator::navigate( const std::string& a_path ) const
	{
		size_t l_found = a_path.find( "." );
		std::string l_symbol = l_found == std::string::npos ? a_path : a_path.substr( 0, l_found );
		TPMAP::iterator l_it = m_fieldSets.find( l_symbol );
		base::genAssert( l_it != m_fieldSets.end( ), __FUNCTION__, "Symbol <" + l_symbol + "> not found in path <" + a_path + ">" );
		Field* l_fset = l_it->second;
		size_t l_next;
		while ( l_found != std::string::npos )
		{
			configBase::Util::Sleep();
			l_next = a_path.find( ".", ++l_found );
			size_t l_len = l_next == std::string::npos ? a_path.length( ) - l_found : l_next - l_found;
			std::string l_subFieldLabel = a_path.substr( l_found, l_len );
			l_fset = l_fset->find( l_subFieldLabel ).ptr( );
			base::genAssert( !l_fset->isDummy() || m_ignoreDummyFields , __FUNCTION__, "Field <" + a_path + "> not found" );
			l_found = l_next;
		}
		return *l_fset;
	}
	bool FieldNavigator::addField( const std::string& a_symbol, Field* a_field )
	{
		std::pair<TPMAP::iterator, bool> l_insertRet = m_fieldSets.insert( TPPAIR( a_symbol, a_field ) );
		base::genAssert( l_insertRet.second, __FUNCTION__, "Field Symbol duplicated <" + a_symbol + ">" );
		bool l_ret = !a_field->isDummy( );
		return l_ret;
	}
}//namespace fieldSet

