/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "engine/TrxEngine.hpp"

namespace engine
{
	TrxEngine::TrxEngine( )
	{
	}
	TrxEngine::~TrxEngine( )
	{
	}
	TrxEngine& TrxEngine::setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator )
	{
		m_navigator = a_fieldNavigator;
		return *this;
	}
	TrxEngine& TrxEngine::setDataManipRequest( dataManip::DataManip* a_dataManipRequest )
	{
		m_dataManipRequest = a_dataManipRequest;
		return *this;
	}
	TrxEngine& TrxEngine::setDataManipResponse( dataManip::DataManip* a_dataManipResponse )
	{
		m_dataManipResponse = a_dataManipResponse;
		return *this;
	}
	TrxEngine& TrxEngine::setDataManipNegative( dataManip::DataManip* a_dataManipNegative )
	{
		m_dataManipNegative = a_dataManipNegative;
		return *this;
	}
	TrxEngine& TrxEngine::setDataManipCommand( dataManip::DataManip* a_dataManipCommand )
	{
		m_dataManipCommand = a_dataManipCommand;
		return *this;
	}
	TrxEngine& TrxEngine::setDataManipEvent( dataManip::DataManip* a_dataManipEvent )
	{
		m_dataManipEvent = a_dataManipEvent;
		return *this;
	}
	fieldSet::Field& TrxEngine::navigate( const std::string& a_fieldPath )
	{
		return m_navigator.navigate( a_fieldPath );
	}
	const fieldSet::FieldNavigator& TrxEngine::navigator( ) const
	{
		return m_navigator;
	}
	TrxEngine& TrxEngine::setEnvironment( fieldSet::Field* a_environment )
	{
		m_environment = a_environment;
		return *this;
	}
	fieldSet::Field& TrxEngine::environment( )
	{
		return m_environment->ref( );
	}
	fieldSet::Field& TrxEngine::environment( const std::string& a_variable )
	{
		fieldSet::Field& l_field = m_environment->find( a_variable );
		return l_field;
	}
	dataManip::DataManip& TrxEngine::dataManipRequest( )
	{
		return *m_dataManipRequest;
	}
	dataManip::DataManip& TrxEngine::dataManipResponse( )
	{
		return *m_dataManipResponse;
	}
	dataManip::DataManip& TrxEngine::dataManipNegative( )
	{
		return *m_dataManipNegative;
	}
	dataManip::DataManip& TrxEngine::dataManipCommand( )
	{
		return *m_dataManipCommand;
	}
	dataManip::DataManip& TrxEngine::dataManipEvent( )
	{
		return *m_dataManipEvent;
	}
}//namespace engine

