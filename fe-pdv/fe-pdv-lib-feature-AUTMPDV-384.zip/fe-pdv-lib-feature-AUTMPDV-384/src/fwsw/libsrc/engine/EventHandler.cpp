/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
/ -------------------------------------------------------------------------------------------------
Autor    : Renato de Camargo
Data     : 14/02/2019
Empresa  : Rede
Descricao: EAK 1420
ID       : AM 243.932
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "engine/EventHandler.hpp"
#include "logMsg/MessageTable.hpp"
#include "msgConv/TextConv.hpp"

namespace engine
{
	EventHandler::EventHandler( )
	: m_maxOutboundLength( 262144 )
	{
		m_inboundConverter	= 0;
		m_outboundConverter	= 0;
		outboundRedirectConverter = 0;
		m_trxEngine			= 0;
		m_outboundMessageLength	= 0;
		m_outboundBuffer	= new unsigned char[m_maxOutboundLength];
		m_logger = logger::LoggerFmt::getInstance( );
		m_logger->init( );
	}
	EventHandler::~EventHandler( )
	{
		delete[]
		m_outboundBuffer;
	}
	bool EventHandler::open( )
	{
		return true;
	}
	void EventHandler::close( )
	{
	}
	int EventHandler::onStart( )
	{
		return 0;
	}
	EventHandler& EventHandler::setTrxEngine( TrxEngine* a_trxEngine )
	{
		m_trxEngine = a_trxEngine;
		return *this;
	}
	EventHandler& EventHandler::setCommandMessageConverter( msgConv::MessageConverter* a_commandMessageConverter )
	{
		m_commandConverter = a_commandMessageConverter;
		return *this;
	}
	EventHandler& EventHandler::setEventMessageConverter( msgConv::MessageConverter* a_eventMessageConverter )
	{
		m_eventConverter = a_eventMessageConverter;
		return *this;
	}
	EventHandler& EventHandler::setInboundMessageConverter( msgConv::MessageConverter* a_inboundMessageConverter )
	{
		m_inboundConverter = a_inboundMessageConverter;
		return *this;
	}
	EventHandler& EventHandler::setOutboundMessageConverter( msgConv::MessageConverter* a_outboundMessageConverter )
	{
		m_outboundConverter = a_outboundMessageConverter;
		return *this;
	}
	/// setOutboundMessageRedirectConverter
	/// Setar Conversor para Redirect
	/// Hist�rico: [Data] - ET - Descri��o
	/// [19/03/2019] - EAK 1420 - Versao inicial
	EventHandler& EventHandler::setOutboundMessageRedirectConverter( msgConv::MessageConverter* outboundMessageRedirectConverter )
	{
		outboundRedirectConverter = outboundMessageRedirectConverter;
		return *this;
	}	
	MessageDirection EventHandler::onTransaction( const unsigned char* a_inboundMessage, unsigned int a_inboundMessageLength, MessageDirection a_direction )
	{
		base::genAssertPtr( m_inboundConverter, __FUNCTION__, "Inbound converter not defined" );
		base::genAssertPtr( m_outboundConverter, __FUNCTION__, "Outbound converter not defined" );
		base::genAssertPtr( m_trxEngine, __FUNCTION__, "Transaction engine not defined" );
		
		MessageDirection l_ret;
		char l_logMessage[1024];
		bool l_result = false;
		switch ( a_direction )
		{
		case FROM_NET:
			snprintf( l_logMessage, sizeof l_logMessage, "%s( %d bytes )", MSG_EVENTHANDLER_0001, a_inboundMessageLength );
			m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
			l_result = m_inboundConverter->specific2FieldSet( a_inboundMessage, a_inboundMessageLength );
			
			if ( l_result )
			{
				l_ret = m_trxEngine->onRequest( );
				if ( l_ret == FROM_NET )
				{
					m_outboundMessageLength = m_inboundConverter->fieldSet2Specific( m_outboundBuffer, m_maxOutboundLength );
				}
				else if ( l_ret == TO_NET )
				{
					l_ret = m_trxEngine->onNegativeRequest( );
					if ( l_ret == TO_NET )
					{
						m_outboundMessageLength = m_outboundConverter->fieldSet2Specific( m_outboundBuffer, m_maxOutboundLength );
					} 
					else if( l_ret == REDIRECT ) 
					{
						m_outboundMessageLength = outboundRedirectConverter->fieldSet2Specific( m_outboundBuffer, m_maxOutboundLength );
					}
				} 
				else if ( l_ret == REDIRECT ) 
				{
					m_outboundMessageLength = outboundRedirectConverter->fieldSet2Specific( m_outboundBuffer, m_maxOutboundLength );					
				}
			}

			if ( !l_result || l_ret == DROP )
			{
				m_logger->print( logger::LEVEL_DEBUG, MSG_EVENTHANDLER_0003 );
				unsigned int l_droppedBufferSize =( a_inboundMessageLength * 2 ) + 2;//ascii + '\n' + '\0'
				unsigned char* l_droppedBuffer = new unsigned char[l_droppedBufferSize];
				msgConv::TextConv::hexToAscii( l_droppedBuffer, l_droppedBufferSize, a_inboundMessage, a_inboundMessageLength );
				l_droppedBuffer[l_droppedBufferSize-2] = '\n';
				l_droppedBuffer[l_droppedBufferSize-1] = '\0';
				m_logger->print( logger::LEVEL_DROPPED, reinterpret_cast<const char*>( l_droppedBuffer ), l_droppedBufferSize );
				delete l_droppedBuffer;
				l_ret = DROP;
			}			
			break;
		case TO_NET:
			snprintf( l_logMessage, sizeof l_logMessage, "%s( %d bytes )", MSG_EVENTHANDLER_0002, a_inboundMessageLength );
			m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
			l_result = m_outboundConverter->specific2FieldSet( a_inboundMessage, a_inboundMessageLength );
			if ( l_result )
			{
				l_ret = m_trxEngine->onResponse( );
				if ( l_ret == DROP )
				{
					m_logger->print( logger::LEVEL_ERROR, MSG_EVENTHANDLER_0004 );
				}
			} 
			else
			{
				m_logger->print( logger::LEVEL_ERROR, MSG_EVENTHANDLER_0003 );
			}			
			
			if ( !l_result || l_ret == DROP )
			{
				unsigned int l_droppedBufferSize =( a_inboundMessageLength * 2 ) + 2;
				//ascii + '\n' + '\0'
				unsigned char* l_droppedBuffer = new unsigned char[l_droppedBufferSize];
				msgConv::TextConv::hexToAscii( l_droppedBuffer, l_droppedBufferSize, a_inboundMessage, a_inboundMessageLength );
				l_droppedBuffer[l_droppedBufferSize-2] = '\n';
				l_droppedBuffer[l_droppedBufferSize-1] = '\0';
				m_logger->print( logger::LEVEL_DROPPED, reinterpret_cast<const char*>( l_droppedBuffer ), l_droppedBufferSize );
				delete l_droppedBuffer;
				l_ret = DROP;
			}
			else
			{
				if( l_ret == REDIRECT ) 
				{
					m_outboundMessageLength = outboundRedirectConverter->fieldSet2Specific( m_outboundBuffer, m_maxOutboundLength );
				} 
				else 
				{
					m_outboundMessageLength = m_outboundConverter->fieldSet2Specific( m_outboundBuffer, m_maxOutboundLength );
				}
			}
			break;
		}
		return l_ret;
	}
	const unsigned char* EventHandler::outboundMessage( ) const
	{
		return m_outboundBuffer;
	}
	unsigned int EventHandler::outboundMessageLength( ) const
	{
		return m_outboundMessageLength;
	}
	int EventHandler::onCommand( const unsigned char* a_inboundMessage, unsigned int a_inboundMessageLength )
	{
		return 0;
	}
	int EventHandler::onEvent( const unsigned char* a_inboundMessage, unsigned int a_inboundMessageLength )
	{
		base::genAssertPtr( m_trxEngine, __FUNCTION__, "Transaction engine not defined" );
		
		int l_ret = 0;
		l_ret = m_trxEngine->onEvent( );
		m_outboundMessageLength = m_outboundConverter->fieldSet2Specific( m_outboundBuffer, m_maxOutboundLength );
		return l_ret;
	}
	int EventHandler::onShutDown( )
	{
		return 0;
	}
	int EventHandler::onReload( )
	{
		return 0;
	}
}//namespace engine

