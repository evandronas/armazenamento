/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*********************** MODIFICACOES ************************
Autor    : Renato de Camargo
Data     : 12/03/2019
Empresa  : Rede
Descricao: EAK-1420
ID       : AM 243.932
*************************************************************
*/
#pragma once
#include "base/GenException.hpp"
#include "configLoader/DataManipConfig.hpp"
#include "configLoader/FieldSetConfig.hpp"
#include "configLoader/Iso8583Config.hpp"
#include "configLoader/LibrarianConfig.hpp"
#include "configLoader/PluginManagerConfig.hpp"
#include "engine/EngineLoader.hpp"
#include "logMsg/MessageTable.hpp"
#include "logger/LoggerGen.hpp"
#include "msgConv/Iso8583Builder.hpp"
#include "msgConv/Iso8583Parser.hpp"
#include "msgConv/JsonBuilder.hpp"
#include "msgConv/JsonParser.hpp"
#include "msgConv/QueryStringBuilder.hpp"
#include "msgConv/QueryStringParser.hpp"
#include "msgConv/ShcMessageBuilder.hpp"
#include "msgConv/ShcMessageParser.hpp"
#include "pluginManager/ObjectInterface.hpp"

#include <syslg.h>

namespace engine
{
	EngineLoader::EngineLoader( )
	: ISO8583_ID( "ISO8583" ), QUERY_STRING_ID( "QUERY_STRING" ), SHC_ID( "SHC" ), JSON_ID("JSON"), CUSTOM_ID( "CUSTOM" )
	{
		m_mainEngine			= 0;
		m_pluginManager			= 0;
		m_xmfFieldSet			= 0;
		m_imfFieldSet			= 0;
        for( std::deque<fieldSet::FieldSet*>::iterator itm_shdFieldSet = dm_shdFieldSet.begin(); itm_shdFieldSet != dm_shdFieldSet.end(); ++itm_shdFieldSet )
        {
            delete *itm_shdFieldSet;
        }
		m_environment			= 0;
		m_dataManipRequest		= 0;
		m_dataManipResponse		= 0;
		m_dataManipNegative		= 0;
		m_dataManipCommand		= 0;
		m_dataManipEvent		= 0;
		m_inboundConverter		= 0;
		m_outboundConverter		= 0;
		m_inboundLoader			= 0;
		m_outboundLoader		= 0;
		m_inboundExtractor		= 0;
		m_outboundExtractor		= 0;

		outboundConverterRedirect = 0;
		outboundLoaderRedirect	  = 0;
		outboundExtractorRedirect = 0;		
		
		m_mbIn					= 0;
		m_mbOut					= 0;
		m_trxEngine				= 0;
		m_logger = logger::LoggerGen::getInstance( );
		m_logger->init( );
	}
	EngineLoader::~EngineLoader( )
	{
	}
	void EngineLoader::setMainEngine( MainEngine* a_mainEngine )
	{
		m_mainEngine = a_mainEngine;
	}
	void EngineLoader::setEngineLabel( const std::string& a_label )
	{
		m_engineLabel = a_label;
	}
	void EngineLoader::unload( )
	{
		delete m_environment;
		delete m_dataManipRequest;
		delete m_dataManipResponse;
		delete m_dataManipNegative;
		delete m_dataManipCommand;
		delete m_dataManipEvent;
		delete m_inboundConverter;
		delete m_outboundConverter;
		delete m_inboundLoader;
		delete m_outboundLoader;
		delete m_inboundExtractor;
		delete m_outboundExtractor;
		
		delete outboundConverterRedirect;
		delete outboundLoaderRedirect;
		delete outboundExtractorRedirect;				
		
		delete m_mbIn;
		delete m_mbOut;
		delete m_xmfFieldSet;
		delete m_imfFieldSet;
        for( std::deque<fieldSet::FieldSet*>::iterator itm_shdFieldSet = dm_shdFieldSet.begin(); itm_shdFieldSet != dm_shdFieldSet.end(); ++itm_shdFieldSet )
        {
            delete *itm_shdFieldSet;
        }
		delete m_trxEngine;
		m_pluginManager->close( );
		pluginManager::Librarian::getInstance( )->clear( );
		delete m_pluginManager;
	}
	void EngineLoader::cleanup( )
	{
		m_selectedLibrarianTag.clear( );
		m_selectedPluginManagerTag.clear( );
		m_selectedXmfFieldSetTag.clear( );
		m_selectedImfFieldSetTag.clear( );
		m_selectedInternalEnvironmentTag.clear( );
		m_selectedDataManipRequestTag.clear( );
		m_selectedDataManipResponseTag.clear( );
		m_selectedDataManipNegativeTag.clear( );
		m_selectedInboundIso8583PropertiesTag.clear( );
		m_selectedOutboundIso8583PropertiesTag.clear( );
		m_mainXmlPath.clear( );
		m_mainXmlName.clear( );
		m_engineLabel.clear( );
		m_librarianXml.clear( );
		m_pluginManagerXml.clear( );
		m_fieldSetXml.clear( );
		m_dataManipXml.clear( );
		m_iso8583PropertiesXml.clear( );
		m_librarianXmlPath.clear( );
		m_pluginManagerXmlPath.clear( );
		m_fieldSetXmlPath.clear( );
		m_dataManipXmlPath.clear( );
		m_iso8583PropertiesXmlPath.clear( );
		m_engineTag.clear( );
		m_librarianTag.clear( );
		m_librarianRefLabel.clear( );
		m_pluginManagerTag.clear( );
		m_pluginManagerRefLabel.clear( );
		m_xmfFieldSetTag.clear( );
		m_xmfFieldSetRefLabel.clear( );
		m_xmfFieldSetSymbol.clear( );
		m_imfFieldSetTag.clear( );
		m_imfFieldSetRefLabel.clear( );
		m_imfFieldSetSymbol.clear( );
		m_internalEnvironmentTag.clear( );
		m_internalEnvironmentSymbol.clear( );
		m_dataManipRequestTag.clear( );
		m_dataManipRequestRefLabel.clear( );
		m_dataManipResponseTag.clear( );
		m_dataManipResponseRefLabel.clear( );
		m_dataManipNegativeTag.clear( );
		m_dataManipNegativeRefLabel.clear( );
		m_dataManipCommandTag.clear( );
		m_dataManipCommandRefLabel.clear( );
		m_dataManipEventTag.clear( );
		m_dataManipEventRefLabel.clear( );
		m_converterTag.clear( );
		m_inboundType.clear( );
		m_outboundType.clear( );
		m_inboundIso8583Property.clear( );
		m_outboundIso8583Property.clear( );
		m_inboundCustomExtractor.clear( );
		m_outboundCustomExtractor.clear( );
		m_inboundCustomLoader.clear( );
		m_outboundCustomLoader.clear( );
		m_inboundIso8583PropertyRefLabel.clear( );
		m_outboundIso8583PropertyRefLabel.clear( );
		m_inboundCustomExtractorRefLabel.clear( );
		m_outboundCustomExtractorRefLabel.clear( );
		m_inboundCustomLoaderRefLabel.clear( );
		m_outboundCustomLoaderRefLabel.clear( );
		m_trxEngineTag.clear( );
		m_trxEngineRefLabel.clear( );
		m_inputMailboxNameTag.clear( );
		m_inputMailboxName.clear( );
		m_dataManipTimeLogTag.clear( );
		m_dataManipTimeLog.clear( );
	}
	bool EngineLoader::load( )
	{
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0001 );
		RETURN_IF( !loadMainEngineXml( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0002 );
		RETURN_IF( !loadXmlFilesSection( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0003 );
		RETURN_IF( !loadXmlFilesProperties( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0004 );
		RETURN_IF( !loadObjectsReferencesTag( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0005 );
		RETURN_IF( !loadObjectsReferencesProperties( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0006 );
		RETURN_IF( !selectLibrarian( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0011 );
		RETURN_IF( !loadLibrarian( ), false );
		m_selectedLibrarianTag.clear( );
		m_librarianXml.clear( );
		m_librarianXmlPath.clear( );
		m_librarianTag.clear( );
		m_librarianRefLabel.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0007 );
		RETURN_IF( !selectPluginManager( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0012 );
		RETURN_IF( !loadPluginManager( ), false );
		m_selectedPluginManagerTag.clear( );
		m_pluginManagerXml.clear( );
		m_pluginManagerXmlPath.clear( );
		m_pluginManagerTag.clear( );
		m_pluginManagerRefLabel.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0008 );
		RETURN_IF( !selectFieldSets( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0013 );
		RETURN_IF( !loadFieldSets( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0014 );
		RETURN_IF( !loadFieldNavigator( ), false );
		m_selectedXmfFieldSetTag.clear( );
		m_selectedImfFieldSetTag.clear( );
		m_selectedInternalEnvironmentTag.clear( );
		m_fieldSetXml.clear( );
		m_fieldSetXmlPath.clear( );
		m_xmfFieldSetTag.clear( );
		m_xmfFieldSetRefLabel.clear( );
		m_xmfFieldSetSymbol.clear( );
		m_imfFieldSetTag.clear( );
		m_imfFieldSetRefLabel.clear( );
		m_imfFieldSetSymbol.clear( );
		m_internalEnvironmentTag.clear( );
		m_internalEnvironmentSymbol.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0009 );
		RETURN_IF( !selectDataManips( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0015 );
		RETURN_IF( !loadDataManips( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0010 );
		RETURN_IF( !selectIso8583Properties( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0016 );
		RETURN_IF( !loadConverters( ), false );
		m_selectedInboundIso8583PropertiesTag.clear( );
		m_selectedOutboundIso8583PropertiesTag.clear( );
		m_iso8583PropertiesXml.clear( );
		m_inboundIso8583Property.clear( );
		m_outboundIso8583Property.clear( );
		m_inboundIso8583PropertyRefLabel.clear( );
		m_outboundIso8583PropertyRefLabel.clear( );
		m_inboundCustomExtractorRefLabel.clear( );
		m_outboundCustomExtractorRefLabel.clear( );
		m_inboundCustomLoaderRefLabel.clear( );
		m_outboundCustomLoaderRefLabel.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0017 );
		RETURN_IF( !loadMailboxes( ), false );
		m_inputMailboxNameTag.clear( );
		m_inputMailboxName.clear( );		
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0018 );
		RETURN_IF( !loadTrxEngine( ), false );
		m_trxEngineTag.clear( );
		m_trxEngineRefLabel.clear( );
		m_dataManipTimeLogTag.clear( );
		m_dataManipTimeLog.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_ENGINELOADER_0019 );
		
		cleanup( );
		return true;
	}
	bool EngineLoader::loadXmlFilesProperties( )
	{
		for ( unsigned int l_ind = 0; l_ind < m_librarianXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_ENGINELOADER_0020 << "path:" << m_librarianXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_librarianXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_librarianXmlPath.push_back( FILE_PATH( m_librarianXml[l_ind].findProperty( "filePath" ).value( ), m_librarianXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		for ( unsigned int l_ind = 0; l_ind < m_pluginManagerXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_ENGINELOADER_0020 << "path:" << m_pluginManagerXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_pluginManagerXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_pluginManagerXmlPath.push_back( FILE_PATH( m_pluginManagerXml[l_ind].findProperty( "filePath" ).value( ), m_pluginManagerXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		for ( unsigned int l_ind = 0; l_ind < m_fieldSetXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_ENGINELOADER_0020 << "path:" << m_fieldSetXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_fieldSetXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_fieldSetXmlPath.push_back( FILE_PATH( m_fieldSetXml[l_ind].findProperty( "filePath" ).value( ), m_fieldSetXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		for ( unsigned int l_ind = 0; l_ind < m_dataManipXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_ENGINELOADER_0020 << "path:" << m_dataManipXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_dataManipXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_dataManipXmlPath.push_back( FILE_PATH( m_dataManipXml[l_ind].findProperty( "filePath" ).value( ), m_dataManipXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		for ( unsigned int l_ind = 0; l_ind < m_iso8583PropertiesXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_ENGINELOADER_0020 << "path:" << m_iso8583PropertiesXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_iso8583PropertiesXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_iso8583PropertiesXmlPath.push_back( FILE_PATH( m_iso8583PropertiesXml[l_ind].findProperty( "filePath" ).value( ), m_iso8583PropertiesXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		return true;
	}
	
	bool EngineLoader::loadXmlFilesSection( )
	{
		configBase::TagList l_xmlFilesTagList;
		m_engineTag.findTag( "xmlFiles", l_xmlFilesTagList );
		configBase::Tag l_xmlFiles = l_xmlFilesTagList.front( );
		l_xmlFiles.findTag( "librarianXml", m_librarianXml );
		l_xmlFiles.findTag( "pluginManagerXml", m_pluginManagerXml );
		l_xmlFiles.findTag( "fieldSetXml", m_fieldSetXml );
		l_xmlFiles.findTag( "dataManipXml", m_dataManipXml );
		l_xmlFiles.findTagNotRequired( "iso8583PropertiesXml", m_iso8583PropertiesXml );
		return true;
	}
	bool EngineLoader::loadMainEngineXml( )
	{
		configBase::Tag l_fullTag;
		RETURN_IF( !loadXml( m_mainXmlPath, m_mainXmlName, l_fullTag ), false );
		configBase::TagList l_targetEngineConfig;
		l_fullTag.findTag( "engine", "label", m_engineLabel, l_targetEngineConfig );
		m_engineTag = l_targetEngineConfig.front( );
		return true;
	}
	bool EngineLoader::loadObjectsReferencesProperties( )
	{
		for ( unsigned int l_lbrInd = 0; l_lbrInd < m_librarianTag.size( ); ++l_lbrInd )
		{
			m_librarianRefLabel.push_back( m_librarianTag[l_lbrInd].findProperty( "referenceLabel" ).value( ) );
		}
		for ( unsigned int l_plmInd = 0; l_plmInd < m_pluginManagerTag.size( ); ++l_plmInd )
		{
			m_pluginManagerRefLabel.push_back( m_pluginManagerTag[l_plmInd].findProperty( "referenceLabel" ).value( ) );
		}
		m_xmfFieldSetRefLabel = m_xmfFieldSetTag.findProperty( "referenceLabel" ).value( );
		m_xmfFieldSetSymbol = m_xmfFieldSetTag.findProperty( "symbol" ).value( );
		m_imfFieldSetRefLabel = m_imfFieldSetTag.findProperty( "referenceLabel" ).value( );
		m_imfFieldSetSymbol = m_imfFieldSetTag.findProperty( "symbol" ).value( );
        for( std::deque<configBase::Tag>::iterator itm_shdFieldSetTag = dm_shdFieldSetTag.begin(); itm_shdFieldSetTag != dm_shdFieldSetTag.end(); ++itm_shdFieldSetTag )
        {
            dm_shdFieldSetRefLabel.push_back( itm_shdFieldSetTag->findProperty( "referenceLabel" ).value( ) );
            dm_shdFieldSetSymbol.push_back( itm_shdFieldSetTag->findProperty( "symbol" ).value( ) );
        }
		m_internalEnvironmentSymbol = m_internalEnvironmentTag.findProperty( "symbol" ).value( );
		m_dataManipRequestRefLabel = m_dataManipRequestTag.findProperty( "referenceLabel" ).value( );
		m_dataManipResponseRefLabel = m_dataManipResponseTag.findProperty( "referenceLabel" ).value( );
		m_dataManipNegativeRefLabel = m_dataManipNegativeTag.findProperty( "referenceLabel" ).value( );
		m_dataManipCommandRefLabel = m_dataManipCommandTag.findPropertyNotRequired( "referenceLabel" ).value( );
		m_dataManipEventRefLabel = m_dataManipEventTag.findPropertyNotRequired( "referenceLabel" ).value( );
		m_inboundType = m_converterTag.findProperty( "inboundType" ).value( );
		m_outboundType = m_converterTag.findProperty( "outboundType" ).value( );
		outboundRedirectType = m_converterTag.findPropertyNotRequired( "redirectType" ).value( );
		if ( m_inboundType == ISO8583_ID )
		{
			m_inboundIso8583PropertyRefLabel = m_inboundIso8583Property.findProperty( "referenceLabel" ).value( );
		}
		if ( m_outboundType == ISO8583_ID )
		{
			m_outboundIso8583PropertyRefLabel = m_outboundIso8583Property.findProperty( "referenceLabel" ).value( );
		}
		if ( m_inboundType == CUSTOM_ID )
		{
			m_inboundCustomExtractorRefLabel = m_inboundCustomExtractor.findProperty( "referenceLabel" ).value( );
			m_inboundCustomLoaderRefLabel = m_inboundCustomLoader.findProperty( "referenceLabel" ).value( );
		}
		if ( m_outboundType == CUSTOM_ID )
		{
			m_outboundCustomExtractorRefLabel = m_outboundCustomExtractor.findProperty( "referenceLabel" ).value( );
			m_outboundCustomLoaderRefLabel = m_outboundCustomLoader.findProperty( "referenceLabel" ).value( );
		}
		m_trxEngineRefLabel = m_trxEngineTag.findProperty( "objectReferenceLabel" ).value( );
		return true;
	}
	bool EngineLoader::loadObjectsReferencesTag( )
	{
		m_engineTag.findTag( "librarian", m_librarianTag );
		m_engineTag.findTag( "pluginManager", m_pluginManagerTag );
		configBase::TagList l_xmfFieldSetTagList;
		m_engineTag.findTag( "xmfFieldSet", l_xmfFieldSetTagList );
		m_xmfFieldSetTag = l_xmfFieldSetTagList.front( );
		configBase::TagList l_imfFieldSetTagList;
		m_engineTag.findTag( "imfFieldSet", l_imfFieldSetTagList );
		m_imfFieldSetTag = l_imfFieldSetTagList.front( );
        configBase::TagList l_shdFieldSetTagList;
        m_engineTag.findTagNotRequired( "shdFieldSet", l_shdFieldSetTagList );
        for ( unsigned int i = 0; i < l_shdFieldSetTagList.size(); i++ )
        {
            dm_shdFieldSetTag.push_back( l_shdFieldSetTagList.at( i ) );
        }
		configBase::TagList l_internalEnvironmentTagList;
		m_engineTag.findTag( "internalEnvironment", l_internalEnvironmentTagList );
		m_internalEnvironmentTag = l_internalEnvironmentTagList.front( );
		configBase::TagList l_dataManipRequestTagList;
		m_engineTag.findTag( "dataManipRequest", l_dataManipRequestTagList );
		m_dataManipRequestTag = l_dataManipRequestTagList.front( );
		configBase::TagList l_dataManipResponseTagList;
		m_engineTag.findTag( "dataManipResponse", l_dataManipResponseTagList );
		m_dataManipResponseTag = l_dataManipResponseTagList.front( );
		configBase::TagList l_dataManipNegativeList;
		m_engineTag.findTag( "dataManipNegative", l_dataManipNegativeList );
		m_dataManipNegativeTag = l_dataManipNegativeList.front( );
		
		configBase::TagList l_dataManipCommandList;
		m_engineTag.findTagNotRequired( "dataManipCommand", l_dataManipCommandList );
		m_dataManipCommandTag = l_dataManipCommandList.size( ) > 0 ? l_dataManipCommandList.front( ) : configBase::Tag( );
		configBase::TagList l_dataManipEventList;
		m_engineTag.findTagNotRequired( "dataManipEvent", l_dataManipEventList );
		m_dataManipEventTag = l_dataManipEventList.size( ) > 0 ? l_dataManipEventList.front( ) : configBase::Tag( );
		
		configBase::TagList l_converterTagList;
		m_engineTag.findTag( "converter", l_converterTagList );
		m_converterTag = l_converterTagList.front( );
		if ( m_converterTag.findProperty( "inboundType" ).value( ) == ISO8583_ID )
		{
			configBase::TagList l_inbound8583TagList;
			m_converterTag.findTag( "inboundIso8583Property", l_inbound8583TagList );
			m_inboundIso8583Property = l_inbound8583TagList.front( );
		}
		else if ( m_converterTag.findProperty( "inboundType" ).value( ) == CUSTOM_ID )
		{
			configBase::TagList l_inboundCustomLoaderTagList;
			m_converterTag.findTag( "inboundCustomLoader", l_inboundCustomLoaderTagList );
			m_inboundCustomLoader = l_inboundCustomLoaderTagList.front( );
			configBase::TagList l_inboundCustomExtractorTagList;
			m_converterTag.findTag( "inboundCustomExtractor", l_inboundCustomExtractorTagList );
			m_inboundCustomExtractor = l_inboundCustomExtractorTagList.front( );
		}
		if ( m_converterTag.findProperty( "outboundType" ).value( ) == ISO8583_ID )
		{
			configBase::TagList l_outbound8583TagList;
			m_converterTag.findTag( "outboundIso8583Property", l_outbound8583TagList );
			m_outboundIso8583Property = l_outbound8583TagList.front( );
		}
		else if ( m_converterTag.findProperty( "outboundType" ).value( ) == CUSTOM_ID )
		{
			configBase::TagList l_outboundCustomLoaderTagList;
			m_converterTag.findTag( "outboundCustomLoader", l_outboundCustomLoaderTagList );
			m_outboundCustomLoader = l_outboundCustomLoaderTagList.front( );
			configBase::TagList l_outboundCustomExtractorTagList;
			m_converterTag.findTag( "outboundCustomExtractor", l_outboundCustomExtractorTagList );
			m_outboundCustomExtractor = l_outboundCustomExtractorTagList.front( );
		}
		configBase::TagList l_trxEngineTagList;
		m_engineTag.findTag( "trxEngine", l_trxEngineTagList );
		m_trxEngineTag = l_trxEngineTagList.front( );
		configBase::TagList l_inputMailboxNameTagList;
		bool l_hasMailBoxName = m_engineTag.findTagNotRequired( "inputMailboxName", l_inputMailboxNameTagList );
		if ( l_hasMailBoxName )
		{
			m_inputMailboxNameTag = l_inputMailboxNameTagList.front( );
			m_inputMailboxName = m_inputMailboxNameTag.findProperty( "value" ).value( );
		}
		else
		{
			m_inputMailboxName.clear( );
		}
		
		configBase::TagList l_dataManipTimeLogTagList;
		bool l_hasDataManipTimeLog = m_engineTag.findTagNotRequired( "dataManipTimeLog", l_dataManipTimeLogTagList );
		if ( l_hasDataManipTimeLog )
		{
			m_dataManipTimeLogTag = l_dataManipTimeLogTagList.front( );
			m_dataManipTimeLog = m_dataManipTimeLogTag.findProperty( "status" ).value( );
		}
		else
		{
			m_dataManipTimeLog.clear( );
		}
		
		return true;
	}
	bool EngineLoader::loadXml( const std::string& a_xmlPath, const std::string& l_xmlName, configBase::Tag& a_tag )
	{
		configBase::DOMTreatment l_domTreat;
		bool l_xmlret = l_domTreat.load( a_xmlPath, l_xmlName, a_tag );
		if ( !l_xmlret )
		{
			const configBase::XMLParseErrorHandler::ERRMSGS& l_errors = l_domTreat.errors( );
			this->reportXmlErrors( l_errors );
		}
		return l_xmlret;
	}
	void EngineLoader::reportXmlErrors( const configBase::XMLParseErrorHandler::ERRMSGS& a_errors )
	{
		unsigned int l_count = a_errors.size( );
		for ( unsigned int i = 0; i < l_count; ++i )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_ENGINELOADER_0021 << "[" << a_errors[i].systemFile( ) << "][" << a_errors[i].lineNumber( ) << "][" << a_errors[i].columnNumber( ) << "][" << a_errors[i].message( ) << "]";
			m_logger->print( logger::LEVEL_FATAL, m_logmsg.str( ).c_str( ) );
		}
	}
	void EngineLoader::setXmlPath( const std::string& a_path )
	{
		m_mainXmlPath = a_path;
	}
	void EngineLoader::setXmlName( const std::string& a_name )
	{
		m_mainXmlName = a_name;
	}
	bool EngineLoader::selectLibrarian( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_librarianXmlPath.begin( ); l_it != m_librarianXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		for ( unsigned int l_ind = 0; l_ind < m_librarianRefLabel.size( ); ++l_ind )
		{
			configBase::TagList l_list;
			l_full.findTag( "librarian", "label", m_librarianRefLabel[l_ind], l_list );
			m_selectedLibrarianTag.addTag( l_list.front( ) );
		}
		return true;
	}
	bool EngineLoader::selectPluginManager( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_pluginManagerXmlPath.begin( ); l_it != m_pluginManagerXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		for ( unsigned int l_ind = 0; l_ind < m_pluginManagerRefLabel.size( ); ++l_ind )
		{
			configBase::TagList l_list;
			l_full.findTag( "pluginManager", "label", m_pluginManagerRefLabel[l_ind], l_list );
			m_selectedPluginManagerTag.addTag( l_list.front( ) );
		}
		return true;
	}
	bool EngineLoader::selectFieldSets( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_fieldSetXmlPath.begin( ); l_it != m_fieldSetXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		configBase::TagList l_list;
		l_full.findTag( "fieldSet", "label", m_xmfFieldSetRefLabel, l_list );
		m_selectedXmfFieldSetTag = l_list.front( );
		l_full.findTag( "fieldSet", "label", m_imfFieldSetRefLabel, l_list );
		m_selectedImfFieldSetTag = l_list.front( );

        for( std::deque<std::string>::iterator itm_shdFieldSetRefLabel = dm_shdFieldSetRefLabel.begin(); itm_shdFieldSetRefLabel != dm_shdFieldSetRefLabel.end(); ++itm_shdFieldSetRefLabel )
        {
            l_full.findTag( "fieldSet", "label", *itm_shdFieldSetRefLabel, l_list );
            for ( unsigned int i = 0; i < l_list.size(); i++ )
            {
                dm_selectedShdFieldSetTag.push_back( l_list.at( i ) );
            }
        }
		return true;
	}
	bool EngineLoader::selectDataManips( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_dataManipXmlPath.begin( ); l_it != m_dataManipXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		configBase::TagList l_list;
		l_full.findTag( "dataManip", "label", m_dataManipRequestRefLabel, l_list );
		m_selectedDataManipRequestTag = l_list.front( );
		l_full.findTag( "dataManip", "label", m_dataManipResponseRefLabel, l_list );
		m_selectedDataManipResponseTag = l_list.front( );
		l_full.findTag( "dataManip", "label", m_dataManipNegativeRefLabel, l_list );
		m_selectedDataManipNegativeTag = l_list.front( );
		if ( !m_dataManipCommandRefLabel.empty( ) )
		{
			l_full.findTag( "dataManip", "label", m_dataManipCommandRefLabel, l_list );
			m_selectedDataManipCommandTag = l_list.front( );
		}
		if ( !m_dataManipEventRefLabel.empty( ) )
		{
			l_full.findTag( "dataManip", "label", m_dataManipEventRefLabel, l_list );
			m_selectedDataManipEventTag = l_list.front( );
		}
		return true;
	}
	bool EngineLoader::selectIso8583Properties( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_iso8583PropertiesXmlPath.begin( ); l_it != m_iso8583PropertiesXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		configBase::TagList l_list;
		if ( m_inboundType == ISO8583_ID )
		{
			l_full.findTag( "Iso8583Properties", "label", m_inboundIso8583PropertyRefLabel, l_list );
			m_selectedInboundIso8583PropertiesTag = l_list.front( );
		}
		if ( m_outboundType == ISO8583_ID )
		{
			l_full.findTag( "Iso8583Properties", "label", m_outboundIso8583PropertyRefLabel, l_list );
			m_selectedOutboundIso8583PropertiesTag = l_list.front( );
		}
		return true;
	}
	bool EngineLoader::loadLibrarian( )
	{
		configLoader::LibrarianConfig l_libConfig;
		for ( unsigned int l_ind = 0; l_ind < m_selectedLibrarianTag.size( ); ++l_ind )
		{
			if ( !l_libConfig.load( m_selectedLibrarianTag[l_ind] ) )
			{
				m_logmsg.str( "" );
				m_logmsg << MSG_ENGINELOADER_0023 << l_libConfig.errorMessage( );
				m_logger->print( logger::LEVEL_FATAL, m_logmsg.str( ).c_str( ) );
				return false;
			}
		}
		return true;
	}
	bool EngineLoader::loadPluginManager( )
	{
		base::genAssertPtr( m_mainEngine, __FUNCTION__, "MainEngine not defined to load" );
		configLoader::PluginManagerConfig l_plmConfig;
		m_pluginManager = new pluginManager::PluginManager;
		for ( unsigned int l_ind = 0; l_ind < m_selectedPluginManagerTag.size( ); ++l_ind )
		{
			if ( !l_plmConfig.load( *m_pluginManager, m_selectedPluginManagerTag[l_ind] ) )
			{
				m_logmsg.str( "" );
				m_logmsg << MSG_ENGINELOADER_0022 << l_plmConfig.errorMessage( );
				m_logger->print( logger::LEVEL_FATAL, m_logmsg.str( ).c_str( ) );
				return false;
			}
		}
		m_mainEngine->setPluginManager( m_pluginManager );
		if ( !m_pluginManager->open( ) )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_ENGINELOADER_0022 << "*" << std::endl << m_pluginManager->errorMessage( );
			m_logger->print( logger::LEVEL_FATAL, m_logmsg.str( ).c_str( ) );
			return false;
		}
		return true;
	}
	bool EngineLoader::loadFieldSets( )
	{
        fieldSet::FieldSet *m_shdFieldSet;
		base::genAssertPtr( m_mainEngine, __FUNCTION__, "MainEngine not defined to load" );
		configLoader::FieldSetConfig l_fsConfig;
		m_xmfFieldSet = new fieldSet::FieldSet;
		m_imfFieldSet = new fieldSet::FieldSet;
        for ( unsigned int l_ind = 0; l_ind < dm_selectedShdFieldSetTag.size( ); ++l_ind )
        {
            m_shdFieldSet = new fieldSet::FieldSet; dm_shdFieldSet.push_back( m_shdFieldSet );
        }
		m_environment = new fieldSet::FieldSet;
		RETURN_IF( !l_fsConfig.load( *m_xmfFieldSet, m_selectedXmfFieldSetTag ), false );
		RETURN_IF( !l_fsConfig.load( *m_imfFieldSet, m_selectedImfFieldSetTag ), false );

        std::deque<configBase::Tag>::iterator itm_selectedShdFieldSetTag = dm_selectedShdFieldSetTag.begin();
        for( std::deque<fieldSet::FieldSet*>::iterator itm_shdFieldSet = dm_shdFieldSet.begin(); itm_shdFieldSet != dm_shdFieldSet.end(); ++itm_shdFieldSet )
        {
            RETURN_IF( !l_fsConfig.load( **itm_shdFieldSet, *itm_selectedShdFieldSetTag ), false );
            ++itm_selectedShdFieldSetTag;
        }

		m_environment->setLabel( m_internalEnvironmentSymbol );
		m_mainEngine->setXmfFieldSet( m_xmfFieldSet );
		m_mainEngine->setImfFieldSet( m_imfFieldSet );
		m_mainEngine->setEnvironment( m_environment );
		return true;
	}
	bool EngineLoader::loadFieldNavigator( )
	{
		m_navigator.addField( m_xmfFieldSetSymbol, m_xmfFieldSet );
		m_navigator.addField( m_imfFieldSetSymbol, m_imfFieldSet );
        std::deque<std::string>::iterator itm_shdFieldSetSymbol = dm_shdFieldSetSymbol.begin();
        for( std::deque<fieldSet::FieldSet*>::iterator itm_shdFieldSet = dm_shdFieldSet.begin(); itm_shdFieldSet != dm_shdFieldSet.end(); ++itm_shdFieldSet )
        {
            m_navigator.addField( *itm_shdFieldSetSymbol, *itm_shdFieldSet );
            itm_shdFieldSetSymbol++;
        }
		m_navigator.addField( m_internalEnvironmentSymbol, m_environment );
		m_mainEngine->setNavigator( m_navigator );
		return true;
	}
	bool EngineLoader::loadDataManips( )
	{
		base::genAssertPtr( m_mainEngine, __FUNCTION__, "MainEngine not defined to load" );
		configLoader::DataManipConfig l_dataManipConfig( 1 );
		l_dataManipConfig.setPluginManager( m_pluginManager );
		l_dataManipConfig.setFieldNavigator( m_navigator );
		m_dataManipRequest		= new dataManip::DataManip;
		l_dataManipConfig.load( *m_dataManipRequest, m_selectedDataManipRequestTag );
		m_selectedDataManipRequestTag.clear( );
		
		m_dataManipResponse		= new dataManip::DataManip;
		l_dataManipConfig.load( *m_dataManipResponse, m_selectedDataManipResponseTag );
		m_selectedDataManipResponseTag.clear( );
		m_dataManipResponseRefLabel.clear( );
		
		fieldSet::FieldNavigator::TP_PATHS l_requestPaths;
		m_dataManipRequest->fieldNavigator( ).copyPaths( l_requestPaths );
		fieldSet::FieldNavigator l_negativeNavigator = m_navigator;
		
		for ( fieldSet::FieldNavigator::TP_PATHS::const_iterator l_it = l_requestPaths.begin( ); l_it != l_requestPaths.end( ); ++l_it )
		{
			l_negativeNavigator.addField( m_dataManipRequestRefLabel + "::" + l_it->first, l_it->second );
		}
		m_dataManipRequestRefLabel.clear( );		
		l_dataManipConfig.setFieldNavigator( l_negativeNavigator );
		
		m_dataManipNegative		= new dataManip::DataManip;
		l_dataManipConfig.load( *m_dataManipNegative, m_selectedDataManipNegativeTag );
		m_selectedDataManipNegativeTag.clear( );
		m_dataManipNegativeRefLabel.clear( );
		
		m_dataManipCommand		= new dataManip::DataManip;
		if ( m_selectedDataManipCommandTag.tagCount( ) > 0 )
		{
			l_dataManipConfig.load( *m_dataManipCommand, m_selectedDataManipCommandTag );
			m_selectedDataManipCommandTag.clear( );
		}
		m_dataManipEvent		= new dataManip::DataManip;
		if ( m_selectedDataManipEventTag.tagCount( ) > 0 )
		{
			l_dataManipConfig.load( *m_dataManipEvent, m_selectedDataManipEventTag );
			m_selectedDataManipEventTag.clear( );
		}
		
		dataManip::DataManip::enableTimeLogOn( m_dataManipTimeLog == "on" || m_dataManipTimeLog == "ON" );
		
		m_dataManipTimeLogTag.clear( );
		m_dataManipTimeLog.clear( );
		
		m_dataManipXml.clear( );
		m_dataManipXmlPath.clear( );
		m_mainEngine->setDataManipRequest( m_dataManipRequest );
		m_mainEngine->setDataManipResponse( m_dataManipResponse );
		m_mainEngine->setDataManipNegative( m_dataManipNegative );
		m_mainEngine->setDataManipCommand( m_dataManipCommand );
		m_mainEngine->setDataManipEvent( m_dataManipEvent );
		return true;
	}
	bool EngineLoader::loadConverters( )
	{
		base::genAssertPtr( m_mainEngine, __FUNCTION__, "MainEngine not defined to load" );
		m_inboundConverter	= new msgConv::MessageConverter;
		m_outboundConverter	= new msgConv::MessageConverter;
		outboundConverterRedirect = new msgConv::MessageConverter;
		m_inboundLoader		    = 0;
		m_outboundLoader		= 0;
		m_inboundExtractor		= 0;
		m_outboundExtractor		= 0;
		outboundLoaderRedirect    = 0;
		outboundExtractorRedirect = 0;
		if ( m_inboundType == ISO8583_ID )
		{
			configLoader::Iso8583Config l_iso8583Config;
			msgConv::Iso8583Properties l_isoProperties;
			RETURN_IF( !l_iso8583Config.load( l_isoProperties, m_selectedInboundIso8583PropertiesTag ), false );
			m_inboundLoader		= new msgConv::Iso8583Parser( l_isoProperties );
			m_inboundExtractor	= new msgConv::Iso8583Builder( l_isoProperties );
		}
		else if ( m_inboundType == SHC_ID )
		{
			m_inboundLoader		= new msgConv::ShcMessageParser;
			m_inboundExtractor	= new msgConv::ShcMessageBuilder;
		}
		else if ( m_inboundType == QUERY_STRING_ID )
		{
			m_inboundLoader		= new msgConv::QueryStringParser;
			m_inboundExtractor	= new msgConv::QueryStringBuilder;
		}
		else if ( m_inboundType == CUSTOM_ID )
		{
			pluginManager::ObjectInterface<msgConv::FieldSetLoader> l_fieldsetLoaderObjInterface( m_pluginManager );
			m_inboundLoader = l_fieldsetLoaderObjInterface.create( m_inboundCustomLoaderRefLabel );
			base::genAssert( m_inboundLoader->startConfiguration( &m_inboundCustomLoader ), __FUNCTION__, "Error starting inbound custom loader for message converter" );
			pluginManager::ObjectInterface<msgConv::FieldSetExtractor> l_fieldsetExtractorObjInterface( m_pluginManager );
			m_inboundExtractor = l_fieldsetExtractorObjInterface.create( m_inboundCustomExtractorRefLabel );
			base::genAssert( m_inboundExtractor->startConfiguration( &m_inboundCustomExtractor ), __FUNCTION__, "Error starting inbound custom extractor for message converter" );
		}
		else if ( m_inboundType == JSON_ID ) 
		{
			m_inboundLoader		= new msgConv::JsonParser;
			m_inboundExtractor	= new msgConv::JsonBuilder;
		}
		else
		{
			return false;
		}
		
		m_inboundLoader->setFieldSet( m_xmfFieldSet );
		m_inboundExtractor->setFieldSet( m_xmfFieldSet );
		if ( m_outboundType == ISO8583_ID )
		{
			configLoader::Iso8583Config l_iso8583Config;
			msgConv::Iso8583Properties l_isoProperties;
			RETURN_IF( !l_iso8583Config.load( l_isoProperties, m_selectedOutboundIso8583PropertiesTag ), false );
			m_outboundLoader	= new msgConv::Iso8583Parser( l_isoProperties );
			m_outboundExtractor	= new msgConv::Iso8583Builder( l_isoProperties );
		}
		else if ( m_outboundType == SHC_ID )
		{
			m_outboundLoader		= new msgConv::ShcMessageParser;
			m_outboundExtractor		= new msgConv::ShcMessageBuilder;
		}
		else if ( m_outboundType == QUERY_STRING_ID )
		{
			m_outboundLoader		= new msgConv::QueryStringParser;
			m_outboundExtractor		= new msgConv::QueryStringBuilder;
		}
		else if ( m_outboundType == CUSTOM_ID )
		{
			pluginManager::ObjectInterface<msgConv::FieldSetLoader> l_fieldsetLoaderObjInterface( m_pluginManager );
			m_outboundLoader = l_fieldsetLoaderObjInterface.create( m_outboundCustomLoaderRefLabel );
			base::genAssert( m_outboundLoader->startConfiguration( &m_outboundCustomLoader ), __FUNCTION__, "Error starting outbound custom loader for message converter" );
			pluginManager::ObjectInterface<msgConv::FieldSetExtractor> l_fieldsetExtractorObjInterface( m_pluginManager );
			m_outboundExtractor = l_fieldsetExtractorObjInterface.create( m_outboundCustomExtractorRefLabel );
			base::genAssert( m_outboundExtractor->startConfiguration( &m_outboundCustomExtractor ), __FUNCTION__, "Error starting outbound custom extractor for message converter" );
		}
		else if ( m_outboundType == JSON_ID ) 
		{
			m_outboundLoader		= new msgConv::JsonParser;
			m_outboundExtractor		= new msgConv::JsonBuilder;
		}
		else
		{
			return false;
		}
		m_outboundLoader->setFieldSet( m_imfFieldSet );
		m_outboundExtractor->setFieldSet( m_imfFieldSet );
		m_inboundConverter->setFieldSetLoader( m_inboundLoader );
		m_inboundConverter->setFieldSetExtractor( m_outboundExtractor );
		m_outboundConverter->setFieldSetLoader( m_outboundLoader );
		m_outboundConverter->setFieldSetExtractor( m_inboundExtractor );
		m_mainEngine->setInboundConverter( m_inboundConverter );
		m_mainEngine->setOutboundConverter( m_outboundConverter );
		
		/* Load Passthrough Convert, If Exist */
		if ( outboundRedirectType == ISO8583_ID )
		{
			configLoader::Iso8583Config l_iso8583Config;
			msgConv::Iso8583Properties l_isoProperties;
			RETURN_IF( !l_iso8583Config.load( l_isoProperties, m_selectedOutboundIso8583PropertiesTag ), false );
			outboundLoaderRedirect		= new msgConv::Iso8583Parser( l_isoProperties );
			outboundExtractorRedirect	= new msgConv::Iso8583Builder( l_isoProperties );
		}
		else if ( outboundRedirectType == SHC_ID )
		{
			outboundLoaderRedirect		= new msgConv::ShcMessageParser;
			outboundExtractorRedirect	= new msgConv::ShcMessageBuilder;
		}
		else if ( outboundRedirectType == QUERY_STRING_ID )
		{
			outboundLoaderRedirect		= new msgConv::QueryStringParser;
			outboundExtractorRedirect	= new msgConv::QueryStringBuilder;
		}
		else if ( outboundRedirectType == CUSTOM_ID )
		{
			pluginManager::ObjectInterface<msgConv::FieldSetLoader> l_fieldsetLoaderObjInterface( m_pluginManager );
			outboundLoaderRedirect = l_fieldsetLoaderObjInterface.create( m_outboundCustomLoaderRefLabel );
			base::genAssert( outboundLoaderRedirect->startConfiguration( &m_outboundCustomLoader ), __FUNCTION__, "Error starting outbound custom loader for message converter" );
			pluginManager::ObjectInterface<msgConv::FieldSetExtractor> l_fieldsetExtractorObjInterface( m_pluginManager );
			outboundExtractorRedirect = l_fieldsetExtractorObjInterface.create( m_outboundCustomExtractorRefLabel );
			base::genAssert( outboundExtractorRedirect->startConfiguration( &m_outboundCustomExtractor ), __FUNCTION__, "Error starting outbound custom extractor for message converter" );
		}
		else if ( outboundRedirectType == JSON_ID ) 
		{
			outboundLoaderRedirect		= new msgConv::JsonParser;
			outboundExtractorRedirect	= new msgConv::JsonBuilder;
		}
		
		if( outboundLoaderRedirect && outboundExtractorRedirect && outboundConverterRedirect )
		{
			syslg( "Loader Redirect Converter\n" );
			outboundLoaderRedirect->setFieldSet( m_imfFieldSet );
			outboundExtractorRedirect->setFieldSet( m_imfFieldSet );	

			outboundConverterRedirect->setFieldSetLoader( outboundLoaderRedirect );
			outboundConverterRedirect->setFieldSetExtractor( outboundExtractorRedirect );
			m_mainEngine->setOutboundRedirectConverter( outboundConverterRedirect );
		}
		return true;
	}
	bool EngineLoader::loadMailboxes( )
	{
		m_mbOut = new mailboxInterface::MailboxOut;
		m_mbIn = new mailboxInterface::MailboxIn;
		m_mbIn->setName( m_inputMailboxName.c_str( ) );
		m_mainEngine->setMbIn( m_mbIn );
		m_mainEngine->setMbOut( m_mbOut );
		return true;
	}
	bool EngineLoader::loadTrxEngine( )
	{
		pluginManager::ObjectInterface<TrxEngine> l_trxEngineObjInterface( m_pluginManager );
		m_trxEngine = l_trxEngineObjInterface.create( m_trxEngineRefLabel );
		base::genAssert( m_trxEngine->startConfiguration( &m_trxEngineTag ), __FUNCTION__, "Error starting TrxEngine" );
		m_trxEngine->setFieldNavigator( m_navigator );
		m_trxEngine->setEnvironment( m_environment );
		m_trxEngine->setDataManipRequest( m_dataManipRequest );
		m_trxEngine->setDataManipResponse( m_dataManipResponse );
		m_trxEngine->setDataManipNegative( m_dataManipNegative );
		m_trxEngine->setDataManipCommand( m_dataManipCommand );
		m_trxEngine->setDataManipEvent( m_dataManipEvent );
		m_mainEngine->setTrxEngine( m_trxEngine );
		return true;
	}
}//namespace engine

