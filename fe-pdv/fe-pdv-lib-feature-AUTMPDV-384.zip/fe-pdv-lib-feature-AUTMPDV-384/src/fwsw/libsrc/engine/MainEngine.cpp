/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Renato de Camargo
Data     : 18/10/2018
Empresa  : Rede
Descricao: EAK-682 - Eliminacao de Conexoes Pendentes
ID       : AM 225800
*************************************************************
*********************** MODIFICACOES ************************
Autor    : Renato de Camargo
Data     : 12/03/2019
Empresa  : Rede
Descricao: EAK-1420
ID       : AM 225.800
*************************************************************
Autor    : Renato de Camargo
Data     : 25/06/2019
Empresa  : Rede
Descricao: EAK-1490
ID       : AM 246.215
*************************************************************
Autor    : Renato de Camargo
Data     : 18/09/2019
Empresa  : Rede
Descricao: Exclusao de MB Temporarios 
ID       : AM 253.511
*************************************************************
*/
#pragma once
#include <unistd.h>
#include <ist_argv0.h>
#include "configBase/DOMTreatment.hpp"
#include "configBase/TagList.hpp"
#include "configLoader/DataManipConfig.hpp"
#include "configLoader/FieldSetConfig.hpp"
#include "configLoader/LibrarianConfig.hpp"
#include "configLoader/PluginManagerConfig.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/LoggerGen.hpp"
#include "pluginManager/ObjectInterface.hpp"
#include "engine/MainEngine.hpp"
#include "logMsg/MessageTable.hpp"
#include "mailboxInterface/MailboxInterface.hpp"
#include <syslg.h>

extern "C" { int delete_private_mbox(void ); }

namespace engine
{
	bool MainEngine::m_stop = false;
	MainEngine::MainEngine( )
	{
		m_eventHandler = new EventHandler;
		m_pluginManager = 0;
		m_mbIn = 0;
		m_mbOut = 0;
		m_xmfFieldSet = 0;
		m_imfFieldSet = 0;
		m_environment = 0;
		m_dataManipRequest = 0;
		m_dataManipResponse = 0;
		m_dataManipNegative = 0;
		m_dataManipCommand = 0;
		m_dataManipEvent = 0;
		m_inboundConverter = 0;
		m_outboundConverter = 0;
		outboundRedirectConverter = 0;
		m_trxEngine = 0;
		m_logger = 0;
		m_initialised = false;
	}
	MainEngine::~MainEngine( )
	{
		if ( m_eventHandler != 0 )
		{
			delete m_eventHandler;
		}
	}
	void MainEngine::shutdown( )
	{
		if ( m_trxEngine != 0 )
		{
			m_trxEngine->close( );
		}
		if ( m_outboundConverter != 0 )
		{
			m_outboundConverter->close( );
		}
		if ( m_inboundConverter != 0 )
		{
			m_inboundConverter->close( );
		}
		if ( outboundRedirectConverter != 0 )
		{
			outboundRedirectConverter->close( );
		}		
		if ( m_eventHandler != 0 )
		{
			m_eventHandler->close( );
		}
		if ( m_dataManipRequest != 0 )
		{
			m_dataManipRequest->finish( );
		}
		if ( m_dataManipNegative != 0 )
		{
			m_dataManipNegative->finish( );
		}
		if ( m_dataManipResponse != 0 )
		{
			m_dataManipResponse->finish( );
		}
		if ( m_dataManipCommand != 0 )
		{
			m_dataManipCommand->finish( );
		}
		if ( m_dataManipEvent != 0 )
		{
			m_dataManipEvent->finish( );
		}

		// // Eliminar connection
		// dbaccess::single_db::get_instance()->DropConnection();

		if ( m_mbIn != 0 )
		{
			m_mbIn->close( );
		}
		if ( m_mbOut != 0 )
		{
			m_mbOut->close( );
		}
		syslg("delete_private_mbox [%d]\n", delete_private_mbox());
		m_initialised = false;
	}
	void MainEngine::stop( )
	{
		MainEngine::m_stop = true;
	}
	void MainEngine::markDate( fieldSet::FieldAccess& a_fieldData )
	{
		time_t l_rawtime;
		struct tm * l_timeinfo;
		char l_timeAscii[128];
		
		memset(l_timeAscii, 0, sizeof(l_timeAscii) );
		time ( &l_rawtime );
		l_timeinfo = localtime ( &l_rawtime );
		
		base::genAssertPtr( l_timeinfo, __FUNCTION__, "Invalid timeinfo" );

		snprintf(
			l_timeAscii,
			sizeof l_timeAscii,
			"%04d%02d%02d%02d%02d%02d",
			l_timeinfo->tm_year + 1900,
			l_timeinfo->tm_mon + 1,
			l_timeinfo->tm_mday,
			l_timeinfo->tm_hour,
			l_timeinfo->tm_min,
			l_timeinfo->tm_sec
		);
		
		fieldSet::fscopy( a_fieldData, std::string(l_timeAscii) );
	}
	int MainEngine::mainLoop( )
	{
		MainEngine::m_stop = false;
		m_eventHandler->onStart( );
		MessageDirection l_inputDirection;
		MessageDirection l_forwardDirection;
		m_inboundAddress				.field( ).clearData( );
		m_outboundAddress				.field( ).clearData( );
		m_portAddress					.field( ).clearData( );
		fieldSet::fscopy( m_inboundAddress, m_mbIn->inputAddress( ) );
		fieldSet::fscopy( m_outboundAddress, m_mbIn->returnAddress( ) );
		fieldSet::fscopy( m_portAddress, m_mbIn->portAddress( ) );
		m_logger->print( logger::LEVEL_ALWAYS, MSG_MAINENGINE_0013 );
		
		char l_mblog[256];
		int l_inputAddress = m_mbIn->inputAddress( );
		std::string l_mbName = mailboxInterface::MailboxInterface::getInstance()->mbName( l_inputAddress );
		snprintf( l_mblog, sizeof l_mblog, "%s%s( %d )", MSG_MAINENGINE_0029, l_mbName.c_str( ), l_inputAddress );
		m_logger->print( logger::LEVEL_INFO,  l_mblog );
		bool l_recv = m_mbIn->receive( );

		for ( ;; )
		{
			m_xmfFieldSet->clearData();
			m_imfFieldSet->clearData();
			
			m_returnAddress				.field( ).clearData( );
			m_senderAddress				.field( ).clearData( );
			m_forwardAddress			.field( ).clearData( );
			redirectAddress             .field( ).clearData( );
			m_messageDirection			.field( ).clearData( );
			m_messageArrivalTimestamp	.field( ).clearData( );
			m_eventDataBuffer			.field( ).clearData( );
			m_eventDataLength			.field( ).clearData( );

			if ( l_recv && !m_mbIn->isCommand( ) && !m_mbIn->isEvent( ) )
			{
				markDate( m_messageArrivalTimestamp );
				if ( m_mbIn->isFromNet( ) )
				{
					l_inputDirection = FROM_NET;
					fieldSet::fscopy( m_messageDirection, "FROM_NET" );
				}
				else
				{
					l_inputDirection = TO_NET;
					fieldSet::fscopy( m_messageDirection, "TO_NET" );
				}

				std::string l_standardMessage = l_inputDirection == FROM_NET ? MSG_MAINENGINE_0018 : MSG_MAINENGINE_0019;
				char l_logMessage[1024];
				
				snprintf( l_logMessage, sizeof l_logMessage, "%s( %d bytes ) from %s in %s",
					l_standardMessage.c_str( ),
					m_mbIn->receivedLength( ),
					mailboxInterface::MailboxInterface::getInstance()->mbName( m_mbIn->senderAddress( ) ),
					mailboxInterface::MailboxInterface::getInstance()->mbName( m_mbIn->receivedAddress( ) )
				);
				m_logger->print( logger::LEVEL_INFO, l_logMessage );
				fieldSet::fscopy( m_returnAddress, m_mbIn->returnAddress( ) );
				fieldSet::fscopy( m_senderAddress, m_mbIn->senderAddress( ) );
				l_forwardDirection = m_eventHandler->onTransaction( m_mbIn->receivedMessage( ), m_mbIn->receivedLength( ), l_inputDirection );
				this->forwardMessage( l_forwardDirection );
			}
			else if ( l_recv && m_mbIn->isCommand( ) )
			{
				m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0024 );
				m_eventHandler->onCommand( m_mbIn->receivedMessage( ), m_mbIn->receivedLength( ) );
			}
			else if ( l_recv && m_mbIn->isEvent( ) )
			{
				markDate( m_messageArrivalTimestamp );
				fieldSet::fscopy( m_messageDirection, "FROM_EVENT" );

				char l_logMessage[1024];				
				snprintf( l_logMessage, sizeof l_logMessage, "%s( %d bytes ) from %s in %s",
					MSG_MAINENGINE_0025,
					m_mbIn->receivedLength( ),
					mailboxInterface::MailboxInterface::getInstance()->mbName( m_mbIn->senderAddress( ) ),
					mailboxInterface::MailboxInterface::getInstance()->mbName( m_mbIn->receivedAddress( ) )
				);
				m_logger->print( logger::LEVEL_INFO, l_logMessage );

				fieldSet::fscopy( m_returnAddress, m_mbIn->returnAddress( ) );
				fieldSet::fscopy( m_senderAddress, m_mbIn->senderAddress( ) );
				fieldSet::fscopy( m_eventDataBuffer, m_mbIn->receivedMessage( ), m_mbIn->receivedLength( ) );
				fieldSet::fscopy( m_eventDataLength, m_mbIn->receivedLength( ) );
				
				m_eventHandler->onEvent( m_mbIn->receivedMessage( ), m_mbIn->receivedLength( ) );
				this->forwardMessage( TO_NET );
			}
			else if ( l_recv && m_mbIn->isShutdownCommand( ) )
			{
				m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0026 );
				m_eventHandler->onShutDown( );
				MainEngine::m_stop = true;
			}
			
			if ( MainEngine::m_stop )
			{
				m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0027 );
				break;
			}
			
			if ( getppid( ) == 1 )
			{
				m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0028 );
				break;
			}
			if ( l_recv )
			{
				snprintf( l_mblog, sizeof l_mblog, "%s%s( %d )", MSG_MAINENGINE_0029, l_mbName.c_str( ), l_inputAddress );
				m_logger->print( logger::LEVEL_INFO, l_mblog);
			}
			l_recv = m_mbIn->receive( );
		}
		return 0;
	}
	std::deque<int> MainEngine::splitAddress( const std::string& a_addressString ) const
	{
		std::deque<int> l_addrs;
		size_t l_iniPos = 0;
		size_t l_tokenPos = 0;
		size_t l_substrLen = 0;
        size_t l_addrsLimit = 5;        
		do
		{
			l_tokenPos = a_addressString.find( ":", l_tokenPos + 1 );
			l_substrLen = l_tokenPos == std::string::npos ? std::string::npos : l_tokenPos - l_iniPos;
			int l_addr = atoi( a_addressString.substr( l_iniPos, l_substrLen ).c_str( ) );
			l_addrs.push_back( l_addr );
            l_iniPos = l_tokenPos + 1;
            --l_addrsLimit;            
		} while ( l_tokenPos != std::string::npos && l_addrsLimit > 0 );
		return l_addrs;
	}
	int MainEngine::forwardMessage( MessageDirection a_direction )
	{
		int l_ret = 0;
		std::deque<int> l_addrs;
		std::deque<int>::const_iterator l_addrIt;
		std::string mailboxRedirect;
		
		switch ( a_direction )
		{
			case FROM_NET:
			{
				int l_destinyAddress = 0;
				l_addrs = splitAddress( m_forwardAddress.value() );
				
				for ( l_addrIt = l_addrs.begin( ); l_addrIt != l_addrs.end( ); ++l_addrIt )
				{
					l_destinyAddress = *l_addrIt;
					char l_logMessage[1024];
					snprintf( l_logMessage, sizeof l_logMessage, "%s( %d bytes ) from %s to %s",
						MSG_MAINENGINE_0016,
						m_eventHandler->outboundMessageLength( ),
						mailboxInterface::MailboxInterface::getInstance()->mbName( m_mbIn->inputAddress( ) ),
						mailboxInterface::MailboxInterface::getInstance()->mbName( l_destinyAddress )
					);
					m_logger->print( logger::LEVEL_INFO, l_logMessage );
					m_mbOut->send( 
						l_destinyAddress,
						m_mbIn->returnAddress( ),
						m_eventHandler->outboundMessage( ),
						m_eventHandler->outboundMessageLength( )
					);
				}
			}
			break;
			case TO_NET:
			{
				int l_senderAddress = 0;
				l_addrs = splitAddress( m_senderAddress.value() );
				
				for ( l_addrIt = l_addrs.begin( ); l_addrIt != l_addrs.end( ); ++l_addrIt )
				{
					l_senderAddress = *l_addrIt;
					char l_logMessage[1024];
					snprintf( l_logMessage, sizeof l_logMessage, "%s( %d bytes ) from %s to %s",
						MSG_MAINENGINE_0017,
						m_eventHandler->outboundMessageLength( ),
						mailboxInterface::MailboxInterface::getInstance()->mbName( m_mbIn->inputAddress( ) ),
						mailboxInterface::MailboxInterface::getInstance()->mbName( l_senderAddress )
					);
					m_logger->print( logger::LEVEL_INFO, l_logMessage );
					m_mbIn->send( l_senderAddress, m_eventHandler->outboundMessage( ), m_eventHandler->outboundMessageLength( ) );
				}
			}
			break;
			case REDIRECT:
			{
				mailboxRedirect = redirectAddress.value();
				m_mbIn->send( atoi(mailboxRedirect.c_str()), m_eventHandler->outboundMessage( ), m_eventHandler->outboundMessageLength( ));
			}
			break;
		}
		return l_ret;
	}
	bool MainEngine::init( )
	{
		m_logger = logger::LoggerGen::getInstance( );
		m_logger->init( );
		base::genAssertPtr( m_pluginManager, __FUNCTION__, "PluginManager not defined" );
		base::genAssertPtr( m_mbIn, __FUNCTION__, "MbIn not defined" );
		base::genAssertPtr( m_mbOut, __FUNCTION__, "MbOut not defined" );
		base::genAssertPtr( m_xmfFieldSet, __FUNCTION__, "XmfFieldSet not defined" );
		base::genAssertPtr( m_imfFieldSet, __FUNCTION__, "ImfFieldSet not defined" );
		base::genAssertPtr( m_environment, __FUNCTION__, "Environment not defined" );
		base::genAssertPtr( m_dataManipRequest, __FUNCTION__, "DataManipRequest not defined" );
		base::genAssertPtr( m_dataManipResponse, __FUNCTION__, "DataManipResponse not defined" );
		base::genAssertPtr( m_dataManipNegative, __FUNCTION__, "DataManipNegative not defined" );
		base::genAssertPtr( m_dataManipCommand, __FUNCTION__, "DataManipCommand not defined" );
		base::genAssertPtr( m_dataManipEvent, __FUNCTION__, "DataManipEvent not defined" );
		base::genAssertPtr( m_inboundConverter, __FUNCTION__, "InboundConverter not defined" );
		base::genAssertPtr( m_outboundConverter, __FUNCTION__, "OutboundConverter not defined" );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0001 );
		RETURN_IF( !this->loadEnvironment( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0002 );
		RETURN_IF( !m_trxEngine->open( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0004 );
		RETURN_IF( !m_outboundConverter->open( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0005 );
		RETURN_IF( !m_inboundConverter->open( ), false );
		
		if( outboundRedirectConverter ) {
			m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0030 );	
			RETURN_IF( !outboundRedirectConverter->open( ), false );
		}
		
		m_eventHandler->setTrxEngine( m_trxEngine );
		m_eventHandler->setInboundMessageConverter( m_inboundConverter );
		m_eventHandler->setOutboundMessageConverter( m_outboundConverter );
		m_eventHandler->setOutboundMessageRedirectConverter( outboundRedirectConverter );

		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0003 );
		RETURN_IF( !m_eventHandler->open( ), false );
		
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0006 );
		bool l_dtmanipSuccess = true;
		if ( !m_dataManipRequest->init( ) )
		{
			dataManip::DataManip::ERR_VECTOR::const_iterator l_it;
			dataManip::DataManip::ERR_VECTOR l_errors = m_dataManipRequest->getStartErrors( );
			for ( l_it = l_errors.begin( ); l_it != l_errors.end( ); ++l_it )
			{
				m_logger->print( logger::LEVEL_FATAL, MSG_MAINENGINE_0007 + *l_it );
			}
			l_dtmanipSuccess = false;
		}
		
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0008 );
		if ( !m_dataManipNegative->init( ) )
		{
			dataManip::DataManip::ERR_VECTOR::const_iterator l_it;
			dataManip::DataManip::ERR_VECTOR l_errors = m_dataManipNegative->getStartErrors( );
			for ( l_it = l_errors.begin( ); l_it != l_errors.end( ); ++l_it )
			{
				m_logger->print( logger::LEVEL_FATAL, MSG_MAINENGINE_0007+*l_it );
			}
			l_dtmanipSuccess = false;
		}
		
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0009 );
		if ( !m_dataManipResponse->init( ) )
		{
			dataManip::DataManip::ERR_VECTOR::const_iterator l_it;
			dataManip::DataManip::ERR_VECTOR l_errors = m_dataManipResponse->getStartErrors( );
			for ( l_it = l_errors.begin( ); l_it != l_errors.end( ); ++l_it )
			{
				m_logger->print( logger::LEVEL_FATAL, MSG_MAINENGINE_0007 + *l_it );
			}
			l_dtmanipSuccess = false;
		}
		
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0020 );
		if ( !m_dataManipCommand->init( ) )
		{
			dataManip::DataManip::ERR_VECTOR::const_iterator l_it;
			dataManip::DataManip::ERR_VECTOR l_errors = m_dataManipCommand->getStartErrors( );
			for ( l_it = l_errors.begin( ); l_it != l_errors.end( ); ++l_it )
			{
				m_logger->print( logger::LEVEL_FATAL, MSG_MAINENGINE_0007 + *l_it );
			}
			l_dtmanipSuccess = false;
		}
		
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0021 );
		if ( !m_dataManipEvent->init( ) )
		{
			dataManip::DataManip::ERR_VECTOR::const_iterator l_it;
			dataManip::DataManip::ERR_VECTOR l_errors = m_dataManipEvent->getStartErrors( );
			for ( l_it = l_errors.begin( ); l_it != l_errors.end( ); ++l_it )
			{
				m_logger->print( logger::LEVEL_FATAL, MSG_MAINENGINE_0007 + *l_it );
			}
			l_dtmanipSuccess = false;
		}
				
		if ( !l_dtmanipSuccess )
		{
			return false;
		}
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0010 );
		RETURN_IF( !m_mbIn->open( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0011 );
		RETURN_IF( !m_mbOut->open( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINENGINE_0012 );
		m_initialised = true;
		return true;
	}
	
	bool MainEngine::reloadConfiguration( )
	{
		return false;
	}
	bool MainEngine::loadEnvironment( )
	{
		m_environment->addField( "INBOUND_ADDRESS" ).addField( "OUTBOUND_ADDRESS" ).addField( "RETURN_ADDRESS" ).addField( "SENDER_ADDRESS" ).addField( "FORWARD_ADDRESS" ).addField( "PROCESS_NAME" ).addField( "MESSAGE_DIRECTION" ).addField( "PID" ).addField( "UP_TIMESTAMP" ).addField( "FROM_NET_MESSAGE_COUNT" ).addField( "TO_NET_MESSAGE_COUNT" ).addField( "MESSAGE_ARRIVAL_TIMESTAMP" ).addField( "PORT_ADDRESS" ).addField( "EVENT_DATA_BUFFER" ).addField( "EVENT_DATA_LENGTH" ).addField( "REDIRECT_ADDRESS" );
		m_inboundAddress			= m_environment->find( "INBOUND_ADDRESS" );
		m_outboundAddress			= m_environment->find( "OUTBOUND_ADDRESS" );
		m_returnAddress				= m_environment->find( "RETURN_ADDRESS" );
		m_senderAddress				= m_environment->find( "SENDER_ADDRESS" );
		m_forwardAddress			= m_environment->find( "FORWARD_ADDRESS" );
		m_processName				= m_environment->find( "PROCESS_NAME" );
		m_messageDirection			= m_environment->find( "MESSAGE_DIRECTION" );
		m_pid						= m_environment->find( "PID" );
		m_upTimestamp				= m_environment->find( "UP_TIMESTAMP" );
		m_fromNetMessageCount		= m_environment->find( "FROM_NET_MESSAGE_COUNT" );
		m_toNetMessageCount			= m_environment->find( "TO_NET_MESSAGE_COUNT" );
		m_messageArrivalTimestamp	= m_environment->find( "MESSAGE_ARRIVAL_TIMESTAMP" );
		m_portAddress				= m_environment->find( "PORT_ADDRESS" );
		m_eventDataBuffer			= m_environment->find( "EVENT_DATA_BUFFER" );
		m_eventDataLength			= m_environment->find( "EVENT_DATA_LENGTH" );
		redirectAddress             = m_environment->find( "REDIRECT_ADDRESS" );
		
		fieldSet::fscopy( m_pid, getpid() );
		
		markDate( m_upTimestamp );
		fieldSet::fscopy( m_processName, std::string(argv0) );
		
		return true;
	}
	void MainEngine::setTrxEngine( TrxEngine* a_trxEngine )
	{
		m_trxEngine = a_trxEngine;
	}
	void MainEngine::setPluginManager( pluginManager::PluginManager* a_pluginManager )
	{
		m_pluginManager = a_pluginManager;
	}
	void MainEngine::setNavigator( const fieldSet::FieldNavigator& a_navigator )
	{
		m_navigator = a_navigator;
	}
	void MainEngine::setMbIn( mailboxInterface::MailboxIn* a_mbIn )
	{
		m_mbIn = a_mbIn;
	}
	void MainEngine::setMbOut( mailboxInterface::MailboxOut* a_mbOut )
	{
		m_mbOut = a_mbOut;
	}
	void MainEngine::setXmfSymbol( const std::string &a_xmfSymbol )
	{
		m_xmfSymbol = a_xmfSymbol;
	}
	void MainEngine::setImfSymbol( const std::string &a_imfSymbol )
	{
		m_imfSymbol = a_imfSymbol;
	}
	void MainEngine::setEnvSymbol( const std::string &a_envSymbol )
	{
		m_envSymbol = a_envSymbol;
	}
	void MainEngine::setXmfFieldSet( fieldSet::FieldSet* a_xmfFieldSet )
	{
		m_xmfFieldSet = a_xmfFieldSet;
	}
	void MainEngine::setImfFieldSet( fieldSet::FieldSet* a_imfFieldSet )
	{
		m_imfFieldSet = a_imfFieldSet;
	}
	void MainEngine::setEnvironment( fieldSet::FieldSet* a_environment )
	{
		m_environment = a_environment;
	}
	void MainEngine::setDataManipRequest( dataManip::DataManip* a_dataManipRequest )
	{
		m_dataManipRequest = a_dataManipRequest;
	}
	void MainEngine::setDataManipResponse( dataManip::DataManip* a_dataManipResponse )
	{
		m_dataManipResponse = a_dataManipResponse;
	}
	void MainEngine::setDataManipNegative( dataManip::DataManip* a_dataManipNegative )
	{
		m_dataManipNegative = a_dataManipNegative;
	}
	void MainEngine::setDataManipCommand( dataManip::DataManip* a_dataManipCommand )
	{
		m_dataManipCommand = a_dataManipCommand;
	}
	void MainEngine::setDataManipEvent( dataManip::DataManip* a_dataManipEvent )
	{
		m_dataManipEvent = a_dataManipEvent;
	}
	void MainEngine::setInboundConverter( msgConv::MessageConverter* a_inboundConverter )
	{
		m_inboundConverter = a_inboundConverter;
	}
	void MainEngine::setOutboundConverter( msgConv::MessageConverter* a_outboundConverter )
	{
		m_outboundConverter = a_outboundConverter;
	}
	/// setOutboundRedirectConverter
	/// Setar Conversor para Redirect
	/// Hist�rico: [Data] - ET - Descri��o
	/// [19/03/2019] - EAK 1420 - Versao inicial	
	void MainEngine::setOutboundRedirectConverter( msgConv::MessageConverter* paramOutboundRedirectConverter )
	{
		outboundRedirectConverter = paramOutboundRedirectConverter;
	}	
}//namespace engine

