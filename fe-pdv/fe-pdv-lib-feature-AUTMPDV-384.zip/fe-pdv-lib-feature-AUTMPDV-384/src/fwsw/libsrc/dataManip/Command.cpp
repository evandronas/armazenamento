/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "dataManip/Command.hpp"

namespace dataManip
{
	Command::Command( )
	{
		m_warningOn			= false;
		m_errorOn			= false;
		m_warningMessage	= "warning not reported";
		m_errorMessage		= "error not reported";
		m_pluginManager		= 0;
		m_processingUSecs	= 0;
		m_initUSecs			= 0;
	}
	Command::~Command( )
	{
	}
	Command& Command::ref( )
	{
		return *this;
	}
	const Command& Command::constRef( ) const
	{
		return *this;
	}
	Command& Command::enableWarning( bool a_isOn )
	{
		m_warningOn = a_isOn;
		return *this;
	}
	Command& Command::enableError( bool a_isOn )
	{
		m_errorOn = a_isOn;
		return *this;
	}
	fieldSet::Field& Command::navigate( const std::string& a_fieldPath )
	{
		return m_navigator.navigate( a_fieldPath );
	}
	const fieldSet::FieldNavigator& Command::navigator( ) const
	{
		return m_navigator;
	}
	Command& Command::setFieldNavigator( const fieldSet::FieldNavigator& 
	                                     a_fieldNavigator )
	{
		m_navigator = a_fieldNavigator;
		return *this;
	}
	Command& Command::setPluginManager( const pluginManager::PluginManager* 
	                                    a_pluginManager )
	{
		m_pluginManager = a_pluginManager;
		return *this;
	}
	const pluginManager::PluginManager* Command::pluginManager( ) const
	{
		base::genAssertPtr( m_pluginManager, 
		                    __FUNCTION__, 
							"Plugin Manager not defined for command <" 
							+ this->label( ) + ">" );
		return m_pluginManager;
	}
	Command& Command::setWarningMessage( const std::string& a_warningMessage )
	{
		m_warningMessage = a_warningMessage;
		return *this;
	}
	Command& Command::setErrorMessage( const std::string& a_errorMessage )
	{
		m_errorMessage = a_errorMessage;
		return *this;
	}
	const std::string& Command::warningMessage( ) const
	{
		return m_warningMessage;
	}
	const std::string& Command::errorMessage( ) const
	{
		return m_errorMessage;
	}
	bool Command::warningOn( ) const
	{
		return m_warningOn;
	}
	bool Command::errorOn( ) const
	{
		return m_errorOn;
	}
	void Command::setProcessingUSecs( long a_processingUSecs )
	{
		m_processingUSecs = a_processingUSecs;
	}
	long Command::processingUSecs( ) const
	{
		return m_processingUSecs;
	}
	void Command::setInitUSecs( long a_initUSecs )
	{
		m_initUSecs = a_initUSecs;
	}
	long Command::initUSecs( ) const
	{
		return m_initUSecs;
	}
}//namespace dataManip

