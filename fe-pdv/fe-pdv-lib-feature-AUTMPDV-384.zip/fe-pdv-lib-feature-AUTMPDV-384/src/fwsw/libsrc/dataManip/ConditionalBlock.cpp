/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include <sys/time.h>
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "configLoader/DataManipConfig.hpp"
#include "dataManip/Always.hpp"
#include "dataManip/ConditionalBlock.hpp"
#include "dataManip/SwitchCase.hpp"
#include "fieldSet/fscopy.hpp"
#include "logMsg/MessageTable.hpp"
#include "logger/LoggerGen.hpp"
#include "pluginManager/ObjectInterface.hpp"
#include "pluginManager/ObjectInterface.hpp"
#include "configBase/Util.hpp"

namespace dataManip
{
	ConditionalBlock::ConditionalBlock( size_t a_depth )
	{
		m_depth = a_depth;
	}
	ConditionalBlock::ConditionalBlock( const ConditionalBlock& a_orig )
	: Command( )
	{
	}
	ConditionalBlock::~ConditionalBlock( )
	{
		this->clear( );
	}
	Command* ConditionalBlock::clone( ) const
	{
		ConditionalBlock* l_clone = new ConditionalBlock( *this );
		return l_clone;
	}
	void ConditionalBlock::clear( )
	{
		BLOCK* l_curBlock = 0;
		unsigned int l_countBlocks = m_blocks.size( );
		for ( unsigned int l_indBlock = 0; 
		      l_indBlock < l_countBlocks; ++l_indBlock )
		{
			l_curBlock = m_blocks[l_indBlock];
			delete l_curBlock->first;
			delete l_curBlock;
		}
		m_blocks.clear( );
	}
	bool ConditionalBlock::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_listIf;
		this->setLabel( a_tag->findProperty( "label" ).value( ) );
		a_tag->findTag( "if", l_listIf );
		if ( l_listIf.size( ) != 1 )
		{
			this->enableError( true );
			this->setErrorMessage( 
			      "More than one <if> tag inside the conditional block" );
			return false;
		}
		m_tagIf = l_listIf.front( );
		a_tag->findTagNotRequired( "else-if", m_tagListElseIf );
		a_tag->findTagNotRequired( "else", m_tagListElse );
		if ( m_tagListElse.size( ) != 0 && m_tagListElse.size( ) != 1 )
		{
			this->enableError( true );
			this->setErrorMessage( 
			      "More than one <else> tag inside the conditional block" );
			return false;
		}
		return true;
	}
	bool ConditionalBlock::loadBlock( const configBase::Tag& a_tag )
	{
		BLOCK* l_ifBlock = new BLOCK;
		m_blocks.push_back( l_ifBlock );
		if ( a_tag.name( ) != "else" )
		{
			std::string l_whenRefObject;
			l_whenRefObject = a_tag.findProperty( 
			                  "objectReferenceLabel" ).value( );
			pluginManager::ObjectInterface<dataManip::WhenClause>
			l_whenObjInterface( pluginManager( ) );
			dataManip::WhenClause* l_when =
			l_whenObjInterface.create( l_whenRefObject );
			l_when->setLabel( this->label( ) );
			bool l_startRet = l_when->startConfiguration( &a_tag );
			if ( l_when->warningOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_when->warningMessage( ) 
				<< " at ConditionalBlock <"
				<< this->label( ) 
				<< ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_WARNING, l_logMsg.str( ).c_str( ) );
			}
			if ( l_when->errorOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_when->warningMessage( ) 
				<< " at ConditionalBlock <"
				<< this->label( ) 
				<< ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_ERROR, l_logMsg.str( ).c_str( ) );
			}
			if ( !l_startRet )
			{
				return false;
			}
			l_when->setFieldNavigator( navigator( ) );
			l_when->setLabel( a_tag.name( ) );
			l_ifBlock->first = l_when;
		}
		else
		{
			dataManip::WhenClause* l_when = new dataManip::Always;
			l_when->setFieldNavigator( navigator( ) );
			l_when->setLabel( a_tag.name( ) );
			l_ifBlock->first = l_when;
		}
		configLoader::DataManipConfig l_dataManipConfig( m_depth + 1 );
		l_dataManipConfig.setPluginManager( pluginManager( ) );
		l_dataManipConfig.setFieldNavigator( navigator( ) );
		bool l_ret = l_dataManipConfig.load( l_ifBlock->second, a_tag );
		return l_ret;
	}
	bool ConditionalBlock::init( )
	{
		logger::LoggerGen::getInstance( )->init( );
		this->clear( );
		bool l_retIf = loadBlock( m_tagIf );
		for ( unsigned int l_indElseIf = 0; 
		      l_indElseIf < m_tagListElseIf.size( ); ++l_indElseIf )
		{
			configBase::Tag l_elseIfTag = m_tagListElseIf[l_indElseIf];
			bool l_retElseIf = loadBlock( l_elseIfTag );
			configBase::Util::Sleep();
		}
		if ( m_tagListElse.size( )> 0 )
		{
			configBase::Tag l_elseTag = m_tagListElse.front( );
			bool l_retElseIf = loadBlock( l_elseTag );
			configBase::Util::Sleep();
		}
		bool l_success = true;
		for ( unsigned int l_blockInd = 0; 
		      l_blockInd < m_blocks.size( ); ++l_blockInd )
		{
			if ( !m_blocks[l_blockInd]->first->init( ) )
			{
				if ( m_blocks[l_blockInd]->first->warningOn( ) )
				{
					std::ostringstream l_msg;
					l_msg
					<< MSG_DATAMANIP_0003 
					<< this->label( ) 
					<< " condition number <" 
					<< l_blockInd 
					<< "> "
					<< m_blocks[l_blockInd]->first->warningMessage( );
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_FATAL, l_msg.str( ).c_str( ) );
				}
				if ( m_blocks[l_blockInd]->first->errorOn( ) )
				{
					std::ostringstream l_msg;
					l_msg
					<< MSG_DATAMANIP_0003 
					<< this->label( ) 
					<< " condition number <" 
					<< l_blockInd 
					<< "> "
					<< m_blocks[l_blockInd]->first->errorMessage( );
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_FATAL, l_msg.str( ).c_str( ) );
				}
				l_success = false;
			}
			if ( !m_blocks[l_blockInd]->second.init( ) )
			{
				dataManip::DataManip::ERR_VECTOR::const_iterator l_it;
				dataManip::DataManip::ERR_VECTOR l_errors = 
				m_blocks[l_blockInd]->second.getStartErrors( );
				for ( l_it = l_errors.begin( ); 
				      l_it != l_errors.end( ); ++l_it )
				{
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_FATAL, MSG_DATAMANIP_0002+*l_it );
				}
				l_success = false;
			}
			
			configBase::Util::Sleep();
		}
		if ( !l_success )
		{
			this->enableError( true );
			this->setErrorMessage( 
			"ConditionalBlock with invalid commands and or conditions clauses" 
			);
		}
		return l_success;
	}
	void ConditionalBlock::finish( )
	{
		this->clear( );
	}
	bool ConditionalBlock::timevalSubtract( struct timeval *a_result, 
	                                        struct timeval *a_t2, 
											struct timeval *a_t1 )
	{
		long int diff =( a_t2->tv_usec + 1000000 * a_t2->tv_sec ) 
		              -( a_t1->tv_usec + 1000000 * a_t1->tv_sec );
		a_result->tv_sec = diff / 1000000;
		a_result->tv_usec = diff % 1000000;
		bool l_ret = diff < 0;
		return l_ret;
	}
	int ConditionalBlock::execute( bool& a_stop )
	{
		BLOCK* l_curBlock = 0;
		unsigned int l_countBlocks = m_blocks.size( );
		int l_ret = 0;
		a_stop = false;
		struct timeval l_tvBegin;
		struct timeval l_tvEnd;
		struct timeval l_tvDiff;
		for ( unsigned int l_indBlock = 0; 
		      l_indBlock < l_countBlocks; ++l_indBlock )
		{
			l_curBlock = m_blocks[l_indBlock];
			WhenClause* l_when = l_curBlock->first;
			gettimeofday( &l_tvBegin, NULL );
			bool l_goAhead = l_when->goAhead( );
			gettimeofday( &l_tvEnd, NULL );
			timevalSubtract( &l_tvDiff, &l_tvEnd, &l_tvBegin );
			l_when->setProcessingUSecs( l_tvDiff.tv_usec );
			if ( l_goAhead )
			{
				DataManip& l_dataManip = l_curBlock->second;
				gettimeofday( &l_tvBegin, NULL );
				l_ret = l_dataManip.execute( a_stop );
				gettimeofday( &l_tvEnd, NULL );
				timevalSubtract( &l_tvDiff, &l_tvEnd, &l_tvBegin );
				l_dataManip.setProcessingUSecs( l_tvDiff.tv_usec );
				const dataManip::DataManip::ERR_VECTOR& l_warnings = 
				l_dataManip.getExecuteWarnings( );
				const dataManip::DataManip::ERR_VECTOR& l_errors = 
				l_dataManip.getExecuteErrors( );
				for ( unsigned int l_war = 0; 
				      l_war < l_warnings.size( ); ++l_war )
				{
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_ERROR, MSG_DATAMANIP_0004 
					+ l_warnings[l_war] );
				}
				for ( unsigned int l_err = 0; 
				      l_err < l_errors.size( ); ++l_err )
				{
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_ERROR, MSG_DATAMANIP_0005 
					+ l_errors[l_err] );
				}
				if ( l_dataManip.stopped( ) )
				{
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_INFO, MSG_DATAMANIP_0006 
					+ l_dataManip.stopCommand( ).label( ) );
				}
				break;
			}
		}
		return l_ret;
	}
}//namespace dataManip

