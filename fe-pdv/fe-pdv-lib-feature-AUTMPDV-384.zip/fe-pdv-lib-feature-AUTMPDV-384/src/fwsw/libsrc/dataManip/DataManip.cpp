/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha                    
--------------------------------------------------------------------------------
*********************** MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 06/05/2019
Empresa  : Rede
Descricao: Adicionando controle para dropar transa��o e refazer conex�o dbm no caso de timeout com o banco
ID       : AM 248.335
*************************************************************
*/

#pragma once
#include <sys/time.h>
#include <algorithm>
#include <ctime>
#include "base/GenException.hpp"
#include "dataManip/DataManip.hpp"
#include "logMsg/MessageTable.hpp"
#include "logger/LoggerGen.hpp"
#include "configBase/Util.hpp"

namespace dataManip
{
	bool DataManip::m_timeLogOn = false;
	bool DataManip::dbDropTrx = false;
	DataManip::DataManip( )
	{
		m_initialised		= false;
		m_stopped			= false;
		m_stopCommand		= 0;
		m_referenceCounter	= 0;
		m_logger			= 0;
	}
	DataManip::~DataManip( )
	{
		base::genAssert( m_referenceCounter == 0, 
		                 __FUNCTION__, 
						 "Invalid destruction, object has still been used" );
		this->clear( );
	}
	int DataManip::referenceCount( ) const
	{
		return m_referenceCounter;
	}
	void DataManip::incReference( )
	{
		++m_referenceCounter;
	}
	void DataManip::decReference( )
	{
		--m_referenceCounter;
	}
	const fieldSet::FieldNavigator& DataManip::fieldNavigator( ) const
	{
		return m_fieldNavigator;
	}
	DataManip& DataManip::setFieldNavigator( const fieldSet::FieldNavigator& 
	                                         a_fieldNavigator )
	{
		m_fieldNavigator = a_fieldNavigator;
		return *this;
	}
	Command* DataManip::clone( ) const
	{
		throw base::GenException( __FUNCTION__, "Datamanip can not be cloned" );
	}
	bool DataManip::timevalSubtract( struct timeval *a_result, 
	                                 struct timeval *a_t2, 
									 struct timeval *a_t1 )
	{
		long int diff =( a_t2->tv_usec + 1000000 * a_t2->tv_sec ) 
		              -( a_t1->tv_usec + 1000000 * a_t1->tv_sec );
		a_result->tv_sec = diff / 1000000;
		a_result->tv_usec = diff % 1000000;
		bool l_ret = diff < 0;
		return l_ret;
	}
	bool DataManip::init( )
	{
		if ( m_initialised )
		{
			return true;
		}
		
		m_logger = logger::LoggerGen::getInstance( );
		m_logger->init( );
		
		CMD_VECTOR::iterator l_it;
		bool l_success = true;
		std::deque<dataManip::Command*> l_startedCmd;
		std::deque<dataManip::WhenClause*> l_startedWhen;
		struct timeval l_tvBegin;
		struct timeval l_tvEnd;
		struct timeval l_tvDiff;

		for ( l_it = m_commands.begin( ); l_it != m_commands.end( ); ++l_it )
		{
			gettimeofday( &l_tvBegin, NULL );
			bool l_retWhen = l_it->whenClause( )->init( );
			gettimeofday( &l_tvEnd, NULL );
			timevalSubtract( &l_tvDiff, &l_tvEnd, &l_tvBegin );
			l_it->whenClause( )->setInitUSecs( l_tvDiff.tv_usec );
			
			if ( m_timeLogOn )
			{
				char l_msgBuffer[256];
				snprintf( l_msgBuffer, sizeof l_msgBuffer, "%s usecs[%08d]-%s", MSG_DATAMANIP_0010, l_tvDiff.tv_usec, l_it->whenClause( )->label( ).c_str( ) );
				m_logger->print( logger::LEVEL_DEBUG, l_msgBuffer );
			}
			
			if ( !l_retWhen )
			{
				std::string l_errMsg( "WhenClause <" 
				                      + l_it->whenClause( )->label( ) 
									  + "> init error - " 
									  + l_it->whenClause( )->errorMessage( ) );
				m_initErrors.push_back( l_errMsg );
				l_success = l_success ? l_retWhen : false;
			}
			else
			{
				l_startedWhen.push_back( l_it->whenClause( ) );
			}
			gettimeofday( &l_tvBegin, NULL );
			bool l_retCmd = l_it->command( )->init( );
			gettimeofday( &l_tvEnd, NULL );
			timevalSubtract( &l_tvDiff, &l_tvEnd, &l_tvBegin );
			l_it->command( )->setInitUSecs( l_tvDiff.tv_usec );
			
			if ( m_timeLogOn )
			{
				char l_msgBuffer[256];
				snprintf( l_msgBuffer, sizeof l_msgBuffer, "%s usecs[%08d]-%s", MSG_DATAMANIP_0012, l_tvDiff.tv_usec, l_it->command( )->label( ).c_str( ) );
				m_logger->print( logger::LEVEL_DEBUG, l_msgBuffer );
			}
			
			if ( !l_retCmd )
			{
				std::string l_errMsg( "Command <" + l_it->command( )->label( ) 
				                      + "> init error - " 
									  + l_it->command( )->errorMessage( ) );
				m_initErrors.push_back( l_errMsg );
				l_success = l_success ? l_retCmd : false;
			}
			else
			{
				l_startedCmd.push_back( l_it->command( ) );
			}
			
			configBase::Util::Sleep();
		}
		if ( !l_success )
		{
			for ( std::deque<dataManip::Command*>::iterator l_it = 
			      l_startedCmd.begin( ); l_it != l_startedCmd.end( ); ++l_it )
			{
				( *l_it )->finish( );
				configBase::Util::Sleep();
			}
			for ( std::deque<dataManip::WhenClause*>::iterator l_it = 
			      l_startedWhen.begin( ); l_it != l_startedWhen.end( ); ++l_it )
			{
				( *l_it )->finish( );
				configBase::Util::Sleep();
			}
			m_initialised = false;
		}
		else
		{
			std::sort( m_commands.begin( ), 
			           m_commands.end( ), 
					   m_commandComparator );
			m_initialised = true;
			m_stopped = false;
		}
		return m_initialised;
	}
	const DataManip::ERR_VECTOR& DataManip::getStartErrors( ) const
	{
		return m_initErrors;
	}
	const DataManip::ERR_VECTOR& DataManip::getExecuteWarnings( ) const
	{
		return m_executeWarnings;
	}
	const DataManip::ERR_VECTOR& DataManip::getExecuteErrors( ) const
	{
		return m_executeErrors;
	}
	fieldSet::FieldSet& DataManip::localFields( )
	{
		return m_localFields;
	}
	unsigned int DataManip::whenClauseCount( ) const
	{
		return m_commands.size( );
	}
	const WhenClause& DataManip::whenClause( unsigned int a_whenClauseIndex ) const
	{
		base::genAssert( 
			a_whenClauseIndex < m_commands.size( ), __FUNCTION__, 
			"Invalid whenClause requisition, index array out of bound" );
		const WhenClause& l_ret = 
		*( m_commands[a_whenClauseIndex].whenClause( ) );
		return l_ret;
	}
	void DataManip::finish( )
	{
		if ( !m_initialised )
		{
			return;
		}
		CMD_VECTOR::iterator l_it;
		for ( l_it = m_commands.begin( ); l_it != m_commands.end( ); ++l_it )
		{
			l_it->command( )->finish( );
			l_it->whenClause( )->finish( );
		}
		m_initialised = false;
	}
	int DataManip::execute( )
	{
		bool l_stop;
		int l_ret = execute( l_stop );
		return l_ret;
	}
	int DataManip::execute( bool &a_stop )
	{
		CMD_VECTOR::iterator l_it;
		int l_ret		= 0;
		int l_execRet	= 0;
		bool l_stop		= false;
		m_stopped		= false;
		m_localFields.clearData( );
		m_executeWarnings.clear( );
		m_executeErrors.clear( );
		m_lastCommand	= 0;
		m_stopCommand	= 0;
		struct timeval l_tvBegin;
		struct timeval l_tvEnd;
		struct timeval l_tvDiff;
#if 0
		std::string l_logDataManip( MSG_DATAMANIP_0007 );
		l_logDataManip += this->label( );
		m_logger->print( logger::LEVEL_DEBUG, l_logDataManip );
#endif
		for ( l_it = m_commands.begin( ); l_it != m_commands.end( ); ++l_it )
		{
			gettimeofday( &l_tvBegin, NULL );
			bool l_goAhead = l_it->whenClause( )->goAhead( );
			gettimeofday( &l_tvEnd, NULL );
			timevalSubtract( &l_tvDiff, &l_tvEnd, &l_tvBegin );
			l_it->whenClause( )->setProcessingUSecs( l_tvDiff.tv_usec );
			
			if ( m_timeLogOn )
			{
				char l_msgBuffer[256];
				snprintf( l_msgBuffer, sizeof l_msgBuffer, "%s usecs[%08d]-%s", MSG_DATAMANIP_0011, l_tvDiff.tv_usec, l_it->whenClause( )->label( ).c_str( ) );
				m_logger->print( logger::LEVEL_DEBUG, l_msgBuffer );
			}
			
			if ( l_goAhead )
			{
				m_lastCommand = l_it->command( );
				l_it->command( )->enableWarning( false );
				l_it->command( )->enableError( false );
				l_it->command( )->setWarningMessage( "" );
				l_it->command( )->setErrorMessage( "" );
				gettimeofday( &l_tvBegin, NULL );
#if 0
				std::string l_logStep( MSG_DATAMANIP_0008 );
				l_logStep += l_it->command( )->label( );
				m_logger->print( logger::LEVEL_DEBUG, l_logStep );
#endif
				l_execRet = l_it->command( )->execute( l_stop );
				
				gettimeofday( &l_tvEnd, NULL );
				timevalSubtract( &l_tvDiff, &l_tvEnd, &l_tvBegin );
				l_it->command( )->setProcessingUSecs( l_tvDiff.tv_usec );
				if ( m_timeLogOn )
				{
					char l_msgBuffer[256];
					snprintf( l_msgBuffer, sizeof l_msgBuffer, "%s usecs[%08d]-%s", MSG_DATAMANIP_0013, l_tvDiff.tv_usec, l_it->command( )->label( ).c_str( ) );
					m_logger->print( logger::LEVEL_DEBUG, l_msgBuffer );
				}
				if ( l_it->command( )->warningOn( ) )
				{
					std::string l_msg( "Command Label <" 
					                   + l_it->command( )->label( ) 
									   + "> - " 
									   + l_it->command( )->warningMessage( ) );
					m_executeWarnings.push_back( l_msg );
				}
				if ( l_it->command( )->errorOn( ) )
				{
					std::string l_msg( "Command Label <" 
					                   + l_it->command( )->label( ) 
									   + "> - " 
									   + l_it->command( )->errorMessage( ) );
					m_executeErrors.push_back( l_msg );
				}
			}
			if ( l_stop && l_it->stopEnabled( ) )
			{
				m_stopped			= true;
				m_stopCommand		= l_it->command( );
				l_ret				= l_execRet;
				break;
			}
			
            // Caso deva dropar a transacao, quebra o loop dos comandos do DataManip, para retornar � engine e dropar (ret -2 = drop)
			if (this->GetDbDropTrx())
			{
				m_stopped			= true;
				m_stopCommand		= l_it->command( );
				l_ret = l_execRet = -2;
				this->SetDbDropTrx(false);
				m_logger->print( logger::LEVEL_DEBUG, " ===[ DROPPING MESSAGE DUE TO DB TIMEOUT ]=== " );
				break;
			}
		}
#if 0
		l_logDataManip = MSG_DATAMANIP_0009;
		l_logDataManip += this->label( );
		m_logger->print( logger::LEVEL_DEBUG, l_logDataManip );
#endif		

		if ( l_execRet < 0 )
		{
			a_stop = m_stopped;//Se o retorno do plugin que ordenou a parada for 0, habilita propagacao
		}
		else if ( l_execRet == 0 )
		{
			a_stop = false;//Se o retorno do plugin que ordenou a parada for 1, desabilita propagacao
			m_stopped = false;
		}
		else
		{
			a_stop = m_stopped;
			--l_ret;
		}
		return l_ret;
	}
	const Command& DataManip::lastCommand( ) const
	{
		base::genAssert( m_lastCommand != 0, 
		                 __FUNCTION__, "No one command executed" );
		return *m_lastCommand;
	}
	const Command& DataManip::stopCommand( ) const
	{
		base::genAssert( m_stopCommand != 0, 
		                 __FUNCTION__, "Invalid requisition for stop command" );
		return *m_stopCommand;
	}
	bool DataManip::stopped( ) const
	{
		return m_stopped;
	}
	DataManip& DataManip::clear( )
	{
		this->finish( );
		CMD_VECTOR::iterator l_it;
		for ( l_it = m_commands.begin( ); l_it != m_commands.end( ); ++l_it )
		{
			WhenClause* l_when = l_it->whenClause( );
			Command* l_command = l_it->command( );
			delete l_when;
			delete l_command;
		}
		m_commands.clear( );
		return *this;
	}
	bool DataManip::addCommand( unsigned int a_sequence, Command* a_command, 
	                            WhenClause* a_whenClause, bool a_stopCommand )
	{
		CommandToCondition l_cmdc( a_sequence, a_command, a_whenClause );
		l_cmdc.enableStop( a_stopCommand );
		m_commands.push_back( l_cmdc );
		return true;
	}
	bool DataManip::addCommand( unsigned int a_sequence, 
	                            const Command& a_command, 
								const WhenClause& a_whenClause, 
								bool a_stopCommand )
	{
		bool l_ret = addCommand( a_sequence, 
		                         a_command.clone( ), 
								 a_whenClause.clone( ), a_stopCommand );
		return l_ret;
	}
	unsigned int DataManip::commandCount( ) const
	{
		return m_commands.size( );
	}
	const Command& DataManip::command( unsigned int a_commandIndex ) const
	{
		base::genAssert( 
		a_commandIndex < m_commands.size( ),
		__FUNCTION__, "Invalid command requisition, index array out of bound" );
		const Command& l_ret = *( m_commands[a_commandIndex].command( ) );
		return l_ret;
	}
	void DataManip::enableTimeLogOn( bool a_timeLogOn )
	{
		m_timeLogOn = a_timeLogOn;
	}

	/// DataManip::SetDbDropTrx
	/// Getter para a vari�vel dbDropTrx, que controla quando a transa��o deve ser dropada por erro de timeout no banco
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [06/05/2019] - EAK 1390 - Vers�o inicial 
	bool DataManip::GetDbDropTrx() 
	{
		return dbDropTrx;
	}

	/// DataManip::SetDbDropTrx
	/// Setter para a vari�vel dbDropTrx, que controla quando a transa��o deve ser dropada por erro de timeout no banco
	/// EF/ET: EAK 1390
	/// Hist�rico: [Data] - ET - Descri��o
	/// [06/05/2019] - EAK 1390 - Vers�o inicial 
	void DataManip::SetDbDropTrx(bool newVal) 
	{
		dbDropTrx = newVal;
	}

}//namespace dataManip

