/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/CommandToCondition.hpp"

namespace dataManip
{
	CommandToCondition::CommandToCondition( unsigned int a_sequence, 
	                                        Command* a_command, 
											WhenClause* a_whenClause )
	{
		m_sequence = a_sequence;
		m_command = a_command;
		m_whenClause = a_whenClause;
		m_stopEnabled = false;
	}
	CommandToCondition::~CommandToCondition( )
	{
	}
	bool CommandToCondition::stopEnabled( ) const
	{
		return m_stopEnabled;
	}
	unsigned int CommandToCondition::sequence( ) const
	{
		return m_sequence;
	}
	Command* CommandToCondition::command( ) const
	{
		return m_command;
	}
	WhenClause* CommandToCondition::whenClause( ) const
	{
		return m_whenClause;
	}
	CommandToCondition& CommandToCondition::enableStop( bool a_stopEnabled )
	{
		m_stopEnabled = a_stopEnabled;
		return *this;
	}
}//namespace dataManip

