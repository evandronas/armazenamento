/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "configLoader/DataManipConfig.hpp"
#include "dataManip/Always.hpp"
#include "dataManip/Call.hpp"
#include "dataManip/SwitchCase.hpp"
#include "fieldSet/fscopy.hpp"
#include "logMsg/MessageTable.hpp"
#include "logger/LoggerGen.hpp"
#include "pluginManager/ObjectInterface.hpp"
#include "pluginManager/ObjectInterface.hpp"
#include "configBase/Util.hpp"

namespace dataManip
{
	Call::TP_MAP Call::m_mapXmlFile;
	
	Call::Call( size_t a_depth )
	{
		m_logger = 0;
		m_dataManip = 0;
		m_depth = a_depth;
	}
	Call::~Call( )
	{
		this->finish( );
	}
	Command* Call::clone( ) const
	{
		Call* l_clone = new Call( *this );
		return l_clone;
	}
	void Call::clearTags( )
	{
		m_mapXmlFile.clear( );
	}
	bool Call::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_dataManipXml;
		a_tag->findTagNotRequired( "dataManipXml", l_dataManipXml );
		if ( l_dataManipXml.size( ) == 0 )
		{
			m_xmlFullName = a_tag->sourceId( );
		}
		else
		{
			std::string l_xmlFilePath = 
			l_dataManipXml.front( ).findProperty( "filePath" ).value( );
			std::string l_xmlFileName = 
			l_dataManipXml.front( ).findProperty( "fileName" ).value( );
			m_xmlFullName = l_xmlFilePath + "/" + l_xmlFileName;
		}
		configBase::TagList l_dataManipRef;
		a_tag->findTag( "subDataManip", l_dataManipRef );
		m_referenceLabel = 
		l_dataManipRef.front( ).findProperty( "objectReferenceLabel" ).value( );
		a_tag->findTagNotRequired( "targetFieldPath", m_targetFieldPath );
		return true;
	}
	bool Call::init( )
	{
		m_logger = logger::LoggerGen::getInstance( );
		m_logger->init( );
		if ( m_dataManip != 0 )
		{
			this->finish();
		}
		
		m_dataManip = new DataManip;
		
		TP_MAP::iterator l_itMap = m_mapXmlFile.find( m_xmlFullName );
		TP_MAP::iterator l_tagIterator;
		
		if ( l_itMap == m_mapXmlFile.end( ) )
		{
			configBase::DOMTreatment l_domTreat;
			std::pair<TP_MAP::iterator,bool> l_insret = m_mapXmlFile.insert( TP_PAIR( m_xmlFullName, configBase::Tag( ) ) );
			l_tagIterator = l_insret.first;
	
			bool l_xmlret = l_domTreat.load( m_xmlFullName, l_tagIterator->second );
			if ( !l_xmlret )
			{
				const configBase::XMLParseErrorHandler::ERRMSGS& l_errors = 
				l_domTreat.errors( );
				this->reportXmlErrors( l_errors );
				this->enableError( true );
				this->setErrorMessage( "Invalid DataManip with label <" 
									   + m_referenceLabel + "> in <" 
									   + m_xmlFullName + ">" );
				return false;
			}
		}
		else
		{
			l_tagIterator = l_itMap;
		}
		configBase::TagList l_selectedDataManip;
		l_tagIterator->second.findTagNotRequired( "dataManip", "label", 
		                          m_referenceLabel, 
								  l_selectedDataManip );

		if ( l_selectedDataManip.size( ) == 0 )
		{
			this->enableError( true );
			this->setErrorMessage( "DataManip with label <" 
			                       + m_referenceLabel 
								   + "> not found in <" + m_xmlFullName + ">" );
			return false;
		}
		fieldSet::FieldNavigator l_scopeNavigator;
		char l_argName[256];
		for ( unsigned int l_ind = 0; 
		      l_ind < m_targetFieldPath.size( ); ++l_ind )
		{
			fieldSet::Field& l_field = this->navigate( 
			                           m_targetFieldPath[l_ind].findProperty( 
									   "value" ).value( ) );
			snprintf( l_argName, sizeof l_argName, "arg%d", l_ind );
			l_scopeNavigator.addField( l_argName, &l_field );
			configBase::Util::Sleep();
		}
		configLoader::DataManipConfig l_dataManipConfig( m_depth + 1 );
		l_dataManipConfig.setPluginManager( pluginManager( ) );
		l_dataManipConfig.setFieldNavigator( l_scopeNavigator );
		l_dataManipConfig.load( *m_dataManip, l_selectedDataManip.front( ) );
		l_selectedDataManip.clear( );
		if ( !m_dataManip->init( ) )
		{
			dataManip::DataManip::ERR_VECTOR::const_iterator l_it;
			dataManip::DataManip::ERR_VECTOR l_errors = 
			m_dataManip->getStartErrors( );
			std::ostringstream l_logmsg;
			for ( l_it = l_errors.begin( ); l_it != l_errors.end( ); ++l_it )
			{
				l_logmsg.str( "" );
				l_logmsg << MSG_DATAMANIP_0002 << *l_it;
				m_logger->print( logger::LEVEL_FATAL, l_logmsg.str( ).c_str( ) );
			}
			this->enableError( true );
			this->setErrorMessage( "Invalid DataManip with label <" 
			                       + m_referenceLabel + "> in <" 
								   + m_xmlFullName + ">" );
			return false;
		}
		return true;
	}
	void Call::reportXmlErrors( const configBase::XMLParseErrorHandler::ERRMSGS&
	                            a_errors )
	{
		std::ostringstream l_logmsg;
		unsigned int l_count = a_errors.size( );
		for ( unsigned int i = 0; i < l_count; ++i )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_DATAMANIP_0001
			         << "[" 
					 << a_errors[i].systemFile( ) 
					 << "][" << a_errors[i].lineNumber( ) 
					 << "][" << a_errors[i].columnNumber( ) 
					 << "][" << a_errors[i].message( ) << "]";
			m_logger->print( logger::LEVEL_FATAL, l_logmsg.str( ).c_str( ) );
		}
	}
	void Call::finish( )
	{
		clearTags( );
		if ( m_dataManip == 0 )
		{
			return;
		}
		delete m_dataManip;
		m_dataManip = 0;
	}
	int Call::execute( bool& a_stop )
	{
		base::genAssertPtr( m_logger, __FUNCTION__, "Logger not initialised" );
		int l_ret	= m_dataManip->execute( a_stop );
		const dataManip::DataManip::ERR_VECTOR& l_warnings = 
		m_dataManip->getExecuteWarnings( );
		const dataManip::DataManip::ERR_VECTOR& l_errors = 
		m_dataManip->getExecuteErrors( );
		for ( unsigned int l_war = 0; l_war < l_warnings.size( ); ++l_war )
		{
			m_logger->print( logger::LEVEL_DEBUG, MSG_DATAMANIP_0004 
			                 + l_warnings[l_war] );
		}
		for ( unsigned int l_err = 0; l_err < l_errors.size( ); ++l_err )
		{
			m_logger->print( logger::LEVEL_ERROR, MSG_DATAMANIP_0005 
			                 + l_errors[l_err] );
		}
		if ( m_dataManip->stopped( ) )
		{
			m_logger->print( logger::LEVEL_INFO, MSG_DATAMANIP_0006 
			                 + m_dataManip->stopCommand( ).label( ) );
            /*
            ** BT 51669: Imprimir debug do TRAP no AIXSyslg.log
            ** Para imprimir o debug no AIXSyslg.log, eh necessario alterar o level de 
            ** LEVEL_INFO para LEVEL_ERROR. Entretando alem de TRAP e DROP, as chamadas
            ** de EXIT e RETURN tambem executam o stop. 
            ** Estas duas ultimas chamadas nao devem logar no AIXSyslg. 
            ** Para evitar isto vamos usar os codigos de retornos das funcoes para 
            ** identificar quando for TRAP(-1) ou DROP(-2).
            */
            if ( (l_ret == -1) || (l_ret == -2) )
            {
                m_logger->print( logger::LEVEL_ERROR, MSG_DATAMANIP_0006 
                    + m_dataManip->stopCommand( ).label( ) );
            }
			a_stop = true;
		}
		
		if ( l_ret > 0 )
		{
			--l_ret;
		}
		
		return l_ret;
	}
}//namespace dataManip

