/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Always.hpp"

namespace dataManip
{
	Always::Always( )
	{
	}
	Always::~Always( )
	{
	}
	bool Always::startConfiguration( const configBase::Tag* a_tag )
	{
		return true;
	}
	bool Always::init( )
	{
		return true;
	}
	void Always::finish( )
	{
	}
	bool Always::goAhead( ) const
	{
		return true;
	}
	WhenClause* Always::clone( ) const
	{
		return new Always( *this );
	}
}//namespace dataManip

