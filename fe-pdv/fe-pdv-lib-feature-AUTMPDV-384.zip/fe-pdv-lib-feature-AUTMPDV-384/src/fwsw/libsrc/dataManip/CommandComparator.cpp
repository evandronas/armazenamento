/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/CommandComparator.hpp"

namespace dataManip
{
	bool CommandComparator::operator( )( const dataManip::CommandToCondition& 
	                                     a_first, 
										 const dataManip::CommandToCondition& 
										 a_second )
	{
		bool l_ret = a_first.sequence( ) < a_second.sequence( );
		return l_ret;
	}
}//namespace dataManip

