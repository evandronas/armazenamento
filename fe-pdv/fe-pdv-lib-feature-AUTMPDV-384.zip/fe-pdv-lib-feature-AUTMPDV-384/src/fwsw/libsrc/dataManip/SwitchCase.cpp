/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "dataManip/SwitchCase.hpp"
#include "fieldSet/fscopy.hpp"
#include "logMsg/MessageTable.hpp"
#include "logger/LoggerGen.hpp"
#include "pluginManager/ObjectInterface.hpp"

namespace dataManip
{
	SwitchCase::SwitchCase( )
	{
		m_cmdDefault = 0;
	}
	SwitchCase::SwitchCase( const SwitchCase& a_orig )
	: Command( )
	{
		m_cmdDefault = 0;
		this->clear( );
		const CASE_MAP& l_origCaseMap = a_orig.m_cases;
		CASE_MAP::const_iterator l_it;
		for ( l_it = l_origCaseMap.begin( ); 
		      l_it != l_origCaseMap.end( ); ++l_it )
		{
			m_cases.insert( CASE_PAIR( l_it->first, l_it->second->clone( ) ) );
		}
		m_cmdDefault = a_orig.m_cmdDefault->clone( );
		m_compareFieldPath = a_orig.m_compareFieldPath;
		m_compareField = a_orig.m_compareField;
		m_tag.clear( );
		m_tag = a_orig.m_tag;
	}
	SwitchCase::~SwitchCase( )
	{
		this->clear( );
	}
	Command* SwitchCase::clone( ) const
	{
		SwitchCase* l_clone = new SwitchCase( *this );
		return l_clone;
	}
	void SwitchCase::clear( )
	{
		CASE_MAP::iterator l_it;
		for ( l_it = m_cases.begin( ); l_it != m_cases.end( ); ++l_it )
		{
			delete l_it->second;
		}
		m_cases.clear( );
		if ( m_cmdDefault != 0 )
		{
			delete m_cmdDefault;
		}
		m_cmdDefault = 0;
	}
	bool SwitchCase::startConfiguration( const configBase::Tag* a_tag )
	{
		std::string l_fieldPath = 
		a_tag->findProperty( "compareFieldPath" ).value( );
		this->setCompareFieldPath( l_fieldPath );
		m_tag.clear( );
		m_tag = *a_tag;
		return true;
	}
	bool SwitchCase::init( )
	{
		logger::LoggerGen::getInstance( )->init( );
		configBase::TagList l_tagCases;
		m_tag.findTag( "case", l_tagCases );
		this->clear( );
		for ( unsigned int l_caseInd = 0; 
		      l_caseInd < l_tagCases.size( ); ++l_caseInd )
		{
			const configBase::Tag& l_caseTag = l_tagCases[l_caseInd];
			std::string l_compareValue = 
			l_caseTag.findProperty( "compareValue" ).value( );
			std::string l_cmdRefObject = 
			l_caseTag.findProperty( "commandReference" ).value( );
			pluginManager::ObjectInterface<dataManip::Command> 
			l_cmdObjInterface( this->pluginManager( ) );
			dataManip::Command* l_command = l_cmdObjInterface.create( 
			                                l_cmdRefObject );
			bool l_startRet = l_command->startConfiguration( &l_caseTag );
			if ( l_command->warningOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_command->warningMessage( ) 
				<< " - in command <"
				<< l_command->label( ) 
				<< "> at switch <"
				<< m_tag.name( ) 
				<< ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_DEBUG, l_logMsg.str( ).c_str( ) );
			}
			if ( l_command->errorOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_command->errorMessage( ) 
				<< " - in command <"
				<< l_command->label( ) 
				<< "> at switch <"
				<< m_tag.name( ) 
				<< ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_ERROR, l_logMsg.str( ).c_str( ) );
			}
			l_command->setFieldNavigator( this->navigator( ) );
			l_command->setPluginManager( this->pluginManager( ) );
			CASE_RET l_ret = m_cases.insert( CASE_PAIR( l_compareValue, 
			                                            l_command ) );
			if ( !l_ret.second )
			{
				this->enableError( true );
				std::string l_errorMsg( "Ambiguous compare value <" 
				                        + l_compareValue
				                        + "> for switch <" + this->label( ) 
										+ "> at <" + m_tag.sourceId( ) + ">" );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		configBase::TagList l_defaultTag;
		m_tag.findTag( "default", l_defaultTag );
		if ( l_defaultTag.size( )> 0 )
		{
			std::string l_cmdRefObject = l_defaultTag.front( ).findProperty( 
			                             "commandReference" ).value( );
			pluginManager::ObjectInterface<dataManip::Command> 
			l_cmdObjInterface( this->pluginManager( ) );
			dataManip::Command* l_command = l_cmdObjInterface.create( 
			                                l_cmdRefObject );
			configBase::Tag l_default = l_defaultTag.front( );
			bool l_startRet = l_command->startConfiguration( &l_default );
			if ( l_command->warningOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_command->warningMessage( ) << " - in command <"
				<< l_command->label( ) << "> at switch <"
				<< m_tag.name( ) << ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_DEBUG,l_logMsg.str( ).c_str( ) );
			}
			if ( l_command->errorOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_command->errorMessage( ) 
				<< " - in command <"
				<< l_command->label( ) 
				<< "> at switch <"
				<< m_tag.name( ) 
				<< ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_ERROR, l_logMsg.str( ).c_str( ) );
			}
			l_command->setFieldNavigator( this->navigator( ) );
			l_command->setPluginManager( this->pluginManager( ) );
			m_cmdDefault = l_command;
		}
		m_compareField = this->navigate( m_compareFieldPath );
		if ( !m_compareField )
		{
			this->enableError( true );
			std::string l_errorMsg( "Compare field <" + m_compareFieldPath 
			                        + "> not found" );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		if ( m_cmdDefault != 0 )
		{
			if ( !m_cmdDefault->init( ) )
			{
				this->enableError( true );
				std::string l_errorMsg( 
				"Error starting default command of switch <" + label( ) + ">" );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		CASE_MAP::iterator l_it;
		int l_count = 0;
		std::string l_cmdComparingValue;
		for ( l_it = m_cases.begin( ); l_it != m_cases.end( ); ++l_it )
		{
			l_cmdComparingValue = l_it->first;
			bool l_ret = l_it->second->init( );
			BREAK_IF( !l_ret );
			++l_count;
		}
		if ( l_it != m_cases.end( ) )
		{
			for ( l_it = m_cases.begin( ); 
			      l_it != m_cases.end( ) && l_count > 0; ++l_it, l_count-- )
			{
				l_it->second->finish( );
			}
			this->enableError( true );
			std::string l_errorMsg( 
			"Error starting command for comparing value <" 
			+ l_cmdComparingValue + "> of switch <" + label( ) + ">" );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		return true;
	}
	void SwitchCase::finish( )
	{
		CASE_MAP::iterator l_it;
		for ( l_it = m_cases.begin( ); l_it != m_cases.end( ); ++l_it )
		{
			l_it->second->finish( );
		}
	}
	int SwitchCase::execute( bool& a_stop )
	{
		a_stop = false;
		CASE_MAP::iterator l_it = m_cases.find( m_compareField.value( ) );
		Command* l_cmd = l_it == m_cases.end( )
		? m_cmdDefault : l_it->second;
		base::genAssertPtr( l_cmd, __FUNCTION__, 
		                    "No default option for switch <" 
							+ this->label( ) + ">" );
		l_cmd->enableWarning( false );
		l_cmd->enableError( false );
		l_cmd->setWarningMessage( "" );
		l_cmd->setErrorMessage( "" );
		int l_ret	= l_cmd->execute( a_stop );
		this->enableWarning( l_cmd->warningOn( ) );
		this->enableError( l_cmd->errorOn( ) );
		this->setWarningMessage( l_cmd->warningMessage( ) );
		this->setErrorMessage( l_cmd->errorMessage( ) );
		return l_ret;
	}
	SwitchCase& SwitchCase::setCompareFieldPath( const std::string& a_path )
	{
		m_compareFieldPath = a_path;
		return *this;
	}
}//namespace dataManip

