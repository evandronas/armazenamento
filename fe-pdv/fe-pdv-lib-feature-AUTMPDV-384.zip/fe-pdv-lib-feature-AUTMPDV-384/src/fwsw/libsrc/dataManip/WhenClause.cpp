/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "dataManip/WhenClause.hpp"

namespace dataManip
{
	WhenClause::WhenClause( )
	{
		m_warningOn			= false;
		m_errorOn			= false;
		m_warningMessage	= "warning not reported";
		m_errorMessage		= "error not reported";
		m_processingUSecs	= 0;
		m_initUSecs			= 0;
	}
	WhenClause::~WhenClause( )
	{
	}
	const fieldSet::FieldNavigator& WhenClause::navigator( ) const
	{
		return m_navigator;
	}
	const fieldSet::Field& WhenClause::navigate( const std::string& 
	                                             a_fieldPath )
	{
		return m_navigator.navigate( a_fieldPath );
	}
	WhenClause& WhenClause::setFieldNavigator( const fieldSet::FieldNavigator&
	                                           a_fieldNavigator )
	{
		m_navigator = a_fieldNavigator;
		return *this;
	}
	WhenClause& WhenClause::enableWarning( bool a_isOn )
	{
		m_warningOn = a_isOn;
		return *this;
	}
	WhenClause& WhenClause::enableError( bool a_isOn )
	{
		m_errorOn = a_isOn;
		return *this;
	}
	const std::string& WhenClause::warningMessage( ) const
	{
		return m_warningMessage;
	}
	const std::string& WhenClause::errorMessage( ) const
	{
		return m_errorMessage;
	}
	bool WhenClause::warningOn( ) const
	{
		return m_warningOn;
	}
	bool WhenClause::errorOn( ) const
	{
		return m_errorOn;
	}
	WhenClause& WhenClause::setWarningMessage( const std::string& 
	                                           a_warningMessage )
	{
		m_warningMessage = a_warningMessage;
		return *this;
	}
	WhenClause& WhenClause::setErrorMessage( const std::string& 
	                                         a_errorMessage )
	{
		m_errorMessage = a_errorMessage;
		return *this;
	}
	void WhenClause::setProcessingUSecs( long a_processingUSecs )
	{
		m_processingUSecs = a_processingUSecs;
	}
	long WhenClause::processingUSecs( ) const
	{
		return m_processingUSecs;
	}
	void WhenClause::setInitUSecs( long a_initUSecs )
	{
		m_initUSecs = a_initUSecs;
	}
	long WhenClause::initUSecs( ) const
	{
		return m_initUSecs;
	}
}//namespace dataManip

