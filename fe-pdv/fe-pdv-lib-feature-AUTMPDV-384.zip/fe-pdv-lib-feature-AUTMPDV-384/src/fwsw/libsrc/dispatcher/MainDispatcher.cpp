/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <unistd.h>
#include <ist_argv0.h>
#include "configBase/DOMTreatment.hpp"
#include "configBase/TagList.hpp"
#include "configLoader/DataManipConfig.hpp"
#include "configLoader/FieldSetConfig.hpp"
#include "configLoader/LibrarianConfig.hpp"
#include "configLoader/PluginManagerConfig.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/LoggerGen.hpp"
#include "pluginManager/ObjectInterface.hpp"
#include "dispatcher/MainDispatcher.hpp"
#include "logMsg/MessageTable.hpp"
#include "mailboxInterface/MailboxInterface.hpp"
#include <time.h>

namespace dispatcher
{
	bool MainDispatcher::m_stop = false;

	MainDispatcher::MainDispatcher( )
	{
		m_eventHandler = new EventHandler;
		m_pluginManager = 0;
		m_mbOut = 0;
		m_xmfFieldSet = 0;
		m_imfFieldSet = 0;
		m_environment = 0;
		m_dataManipDispatch = 0;
		m_outboundConverter = 0;
		m_logger = 0;
		m_reader = 0;
		m_initialised = false;
		m_intervalSeconds = 30;
		m_tps = 0;
	}
	MainDispatcher::~MainDispatcher( )
	{
		if ( m_eventHandler != 0 )
		{
			delete m_eventHandler;
		}
	}
	void MainDispatcher::shutdown( )
	{
		if ( m_outboundConverter != 0 )
		{
			m_outboundConverter->close( );
		}
		if ( m_eventHandler != 0 )
		{
			m_eventHandler->close( );
		}
		if ( m_dataManipDispatch != 0 )
		{
			m_dataManipDispatch->finish( );
		}
		if ( m_mbOut != 0 )
		{
			m_mbOut->close( );
		}
		m_initialised = false;
	}
	void MainDispatcher::stop( )
	{
		MainDispatcher::m_stop = true;
	}
	void MainDispatcher::markDate( fieldSet::FieldAccess& a_fieldData )
	{
		time_t l_rawtime;
		struct tm * l_timeinfo;
		char l_timeAscii[128];
		
		memset(l_timeAscii, 0, sizeof(l_timeAscii) );
		time ( &l_rawtime );
		l_timeinfo = localtime ( &l_rawtime );
		
		base::genAssertPtr( l_timeinfo, __FUNCTION__, "Invalid timeinfo" );

		snprintf(
			l_timeAscii,
			sizeof l_timeAscii,
			"%04d%02d%02d%02d%02d%02d",
			l_timeinfo->tm_year + 1900,
			l_timeinfo->tm_mon + 1,
			l_timeinfo->tm_mday,
			l_timeinfo->tm_hour,
			l_timeinfo->tm_min,
			l_timeinfo->tm_sec
		);
		
		fieldSet::fscopy( a_fieldData, std::string(l_timeAscii) );
	}
	bool MainDispatcher::fetchLoop( )
	{
		bool l_openOk = m_reader->open( );
		long tpsSleep = 0;

		m_tps = m_reader->getTps();
		
		if(m_tps > 0) 
			tpsSleep = 1000000L / m_tps;
		
		if ( l_openOk )
		{
			bool l_fetchSuccess = m_reader->fetch( );

			while ( l_fetchSuccess ) {

				bool l_trxSuccess = m_eventHandler->onTransaction( );
				
				if ( l_trxSuccess )	{
						
						forwardMessage( );

						if(m_tps > 0) {
							usleep(tpsSleep);						
						}
				}

				l_fetchSuccess = m_reader->fetch( );
			}

		} else
		{
			return false;
		}
		
		m_reader->close( );
		return true;
	}
	int MainDispatcher::mainLoop( )
	{
		MainDispatcher::m_stop = false;
		m_eventHandler->onStart( );
		m_logger->print( logger::LEVEL_WARNING, MSG_MAINDISPATCHER_0013 );
		bool l_fetchLoopSuccess = fetchLoop( );
		for ( ;; )
		{
			if ( !l_fetchLoopSuccess )
			{
				break;
			}
			
			if ( MainDispatcher::m_stop || getppid( ) == 1 )
			{
				break;
			}
			sleep( m_intervalSeconds );
			l_fetchLoopSuccess = fetchLoop( );
		}
		return 0;
	}
	std::deque<int> MainDispatcher::splitAddress( const std::string& a_addressString ) const
	{
		std::deque<int> l_addrs;
		size_t l_iniPos = 0;
		size_t l_tokenPos = 0;
		size_t l_substrLen = 0;
        size_t l_addrsLimit = 3;        
		do
		{
			l_tokenPos = a_addressString.find( ":", l_tokenPos + 1 );
			l_substrLen = l_tokenPos == std::string::npos ? std::string::npos : l_tokenPos - l_iniPos;
			int l_addr = atoi( a_addressString.substr( l_iniPos, l_substrLen ).c_str( ) );
			l_addrs.push_back( l_addr );
            l_iniPos = l_tokenPos + 1;
            --l_addrsLimit;            
		} while ( l_tokenPos != std::string::npos && l_addrsLimit > 0 );
		return l_addrs;
	}
	int MainDispatcher::forwardMessage( )
	{
		int l_ret = 0;
		std::deque<int> l_addrs;
		std::deque<int>::const_iterator l_addrIt;

		int l_destinyAddress = 0;
		l_addrs = splitAddress( m_forwardAddress.value() );
		
		for ( l_addrIt = l_addrs.begin( ); l_addrIt != l_addrs.end( ); ++l_addrIt )
		{
			l_destinyAddress = *l_addrIt;
			char l_logMessage[1024];
			snprintf( l_logMessage, sizeof l_logMessage, "%s( %d bytes ) from %s to %s",
				MSG_MAINDISPATCHER_0016,
				m_eventHandler->outboundMessageLength( ),
				m_processName.value( ).c_str( ),
				mailboxInterface::MailboxInterface::getInstance()->mbName( l_destinyAddress )
			);
			m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
			m_mbOut->send( 
				l_destinyAddress,
				0,
				m_eventHandler->outboundMessage( ),
				m_eventHandler->outboundMessageLength( )
			);
		}			
		return l_ret;
	}
	bool MainDispatcher::init( )
	{
		m_logger = logger::LoggerGen::getInstance( );
		m_logger->init( );
		base::genAssertPtr( m_pluginManager, __FUNCTION__, "PluginManager not defined" );
		base::genAssertPtr( m_mbOut, __FUNCTION__, "MbOut not defined" );
		base::genAssertPtr( m_xmfFieldSet, __FUNCTION__, "XmfFieldSet not defined" );
		base::genAssertPtr( m_imfFieldSet, __FUNCTION__, "ImfFieldSet not defined" );
		base::genAssertPtr( m_environment, __FUNCTION__, "Environment not defined" );
		base::genAssertPtr( m_dataManipDispatch, __FUNCTION__, "DataManipDispatch not defined" );
		base::genAssertPtr( m_outboundConverter, __FUNCTION__, "OutboundConverter not defined" );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINDISPATCHER_0001 );
		RETURN_IF( !this->loadEnvironment( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINDISPATCHER_0004 );
		RETURN_IF( !m_outboundConverter->open( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINDISPATCHER_0003 );
		m_eventHandler->setOutboundMessageConverter( m_outboundConverter );
		m_eventHandler->setDataManipDispatch( m_dataManipDispatch );
		m_eventHandler->setFieldNavigator( m_navigator );
		m_eventHandler->setEnvironment( m_environment );
		RETURN_IF( !m_eventHandler->open( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINDISPATCHER_0006 );
		bool l_dtmanipSuccess = true;
		if ( !m_dataManipDispatch->init( ) )
		{
			dataManip::DataManip::ERR_VECTOR::const_iterator l_it;
			dataManip::DataManip::ERR_VECTOR l_errors = m_dataManipDispatch->getStartErrors( );
			for ( l_it = l_errors.begin( ); l_it != l_errors.end( ); ++l_it )
			{
				m_logger->print( logger::LEVEL_FATAL, MSG_MAINDISPATCHER_0007 + *l_it );
			}
			l_dtmanipSuccess = false;
		}
		
		if ( !l_dtmanipSuccess )
		{
			return false;
		}
		m_logger->print( logger::LEVEL_INFO, MSG_MAINDISPATCHER_0011 );
		RETURN_IF( !m_mbOut->open( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_MAINDISPATCHER_0012 );
		m_initialised = true;
		return true;
	}
	bool MainDispatcher::reloadConfiguration( )
	{
		return false;
	}
	bool MainDispatcher::loadEnvironment( )
	{
		m_environment->addField( "RETURN_ADDRESS" ).addField( "SENDER_ADDRESS" ).addField( "FORWARD_ADDRESS" ).addField( "PROCESS_NAME" ).addField( "MESSAGE_DIRECTION" ).addField( "PID" ).addField( "UP_TIMESTAMP" ).addField( "FROM_NET_MESSAGE_COUNT" ).addField( "TO_NET_MESSAGE_COUNT" ).addField( "MESSAGE_ARRIVAL_TIMESTAMP" );
		m_returnAddress				= m_environment->find( "RETURN_ADDRESS" );
		m_senderAddress				= m_environment->find( "SENDER_ADDRESS" );
		m_forwardAddress			= m_environment->find( "FORWARD_ADDRESS" );
		m_processName				= m_environment->find( "PROCESS_NAME" );
		m_messageDirection			= m_environment->find( "MESSAGE_DIRECTION" );
		m_pid						= m_environment->find( "PID" );
		m_upTimestamp				= m_environment->find( "UP_TIMESTAMP" );
		m_fromNetMessageCount		= m_environment->find( "FROM_NET_MESSAGE_COUNT" );
		m_toNetMessageCount			= m_environment->find( "TO_NET_MESSAGE_COUNT" );
		m_messageArrivalTimestamp	= m_environment->find( "MESSAGE_ARRIVAL_TIMESTAMP" );
		
		fieldSet::fscopy( m_pid, getpid() );
		
		markDate( m_upTimestamp );
		fieldSet::fscopy( m_processName, std::string(argv0) );
		
		return true;
	}
	void MainDispatcher::setPluginManager( pluginManager::PluginManager* a_pluginManager )
	{
		m_pluginManager = a_pluginManager;
	}
	void MainDispatcher::setNavigator( const fieldSet::FieldNavigator& a_navigator )
	{
		m_navigator = a_navigator;
	}
	void MainDispatcher::setMbOut( mailboxInterface::MailboxOut* a_mbOut )
	{
		m_mbOut = a_mbOut;
	}
	void MainDispatcher::setXmfSymbol( const std::string &a_xmfSymbol )
	{
		m_xmfSymbol = a_xmfSymbol;
	}
	void MainDispatcher::setImfSymbol( const std::string &a_imfSymbol )
	{
		m_imfSymbol = a_imfSymbol;
	}
	void MainDispatcher::setEnvSymbol( const std::string &a_envSymbol )
	{
		m_envSymbol = a_envSymbol;
	}
	void MainDispatcher::setXmfFieldSet( fieldSet::FieldSet* a_xmfFieldSet )
	{
		m_xmfFieldSet = a_xmfFieldSet;
	}
	void MainDispatcher::setImfFieldSet( fieldSet::FieldSet* a_imfFieldSet )
	{
		m_imfFieldSet = a_imfFieldSet;
	}
	void MainDispatcher::setEnvironment( fieldSet::FieldSet* a_environment )
	{
		m_environment = a_environment;
	}
	void MainDispatcher::setDataManipDispatch( dataManip::DataManip* a_dataManipDispatch )
	{
		m_dataManipDispatch = a_dataManipDispatch;
	}
	void MainDispatcher::setOutboundConverter( msgConv::MessageConverter* a_outboundConverter )
	{
		m_outboundConverter = a_outboundConverter;
	}
	void MainDispatcher::setReader( Reader* a_reader )
	{
		m_reader = a_reader;
	}
	void MainDispatcher::setIntervalSeconds( unsigned int a_intervalSeconds )
	{
		m_intervalSeconds = a_intervalSeconds;
	}
}//namespace dispatcher

