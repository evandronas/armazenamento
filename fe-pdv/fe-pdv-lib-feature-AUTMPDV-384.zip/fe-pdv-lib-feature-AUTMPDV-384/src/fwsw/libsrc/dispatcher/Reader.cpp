/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dispatcher/Reader.hpp"

namespace dispatcher
{
	Reader::Reader( )
	{
	}
	Reader::~Reader( )
	{
	}
	Reader& Reader::setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator )
	{
		m_fieldNavigator = a_fieldNavigator;
		return *this;
	}
	fieldSet::Field& Reader::navigate( const std::string& a_fieldPath )
	{
		return m_fieldNavigator.navigate( a_fieldPath );
	}
	const fieldSet::FieldNavigator& Reader::navigator( ) const
	{
		return m_fieldNavigator;
	}
}//namespace dispatcher
