/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "dispatcher/EventHandler.hpp"
#include "logMsg/MessageTable.hpp"
#include "msgConv/TextConv.hpp"

namespace dispatcher
{
	EventHandler::EventHandler( )
	: m_maxOutboundLength( 262144 )
	{
		m_outboundConverter	= 0;
		m_outboundMessageLength	= 0;
		m_environment = 0;
		m_dataManipDispatch = 0;
		m_outboundBuffer	= new unsigned char[m_maxOutboundLength];
		m_logger = logger::LoggerFmt::getInstance( );
		m_logger->init( );
	}
	EventHandler::~EventHandler( )
	{
		delete[] m_outboundBuffer;
	}
	bool EventHandler::open( )
	{
		return true;
	}
	void EventHandler::close( )
	{
	}
	int EventHandler::onStart( )
	{
		return 0;
	}
	EventHandler& EventHandler::setOutboundMessageConverter( msgConv::MessageConverter* a_outboundMessageConverter )
	{
		m_outboundConverter = a_outboundMessageConverter;
		return *this;
	}
	bool EventHandler::onTransaction( )
	{
		base::genAssertPtr( m_dataManipDispatch, __FUNCTION__, "DataManip dispatch not defined" );
		base::genAssertPtr( m_outboundConverter, __FUNCTION__, "Outbound converter not defined" );
				
		int l_manipRet = m_dataManipDispatch->execute( );
		m_outboundMessageLength = m_outboundConverter->fieldSet2Specific( m_outboundBuffer, m_maxOutboundLength );
		
		bool l_ret = l_manipRet == 0;
		
		return l_ret;
	}
	const unsigned char* EventHandler::outboundMessage( ) const
	{
		return m_outboundBuffer;
	}
	unsigned int EventHandler::outboundMessageLength( ) const
	{
		return m_outboundMessageLength;
	}
	int EventHandler::onCommand( )
	{
		return 0;
	}
	int EventHandler::onShutDown( )
	{
		return 0;
	}
	int EventHandler::onReload( )
	{
		return 0;
	}
	EventHandler& EventHandler::setFieldNavigator( const fieldSet::FieldNavigator& a_fieldNavigator )
	{
		m_navigator = a_fieldNavigator;
		return *this;
	}
	EventHandler& EventHandler::setEnvironment( fieldSet::Field* a_environment )
	{
		m_environment = a_environment;
		return *this;
	}
	EventHandler& EventHandler::setDataManipDispatch( dataManip::DataManip* a_dataManipDispatch )
	{
		m_dataManipDispatch = a_dataManipDispatch;
		return *this;
	}
}//namespace dispatcher

