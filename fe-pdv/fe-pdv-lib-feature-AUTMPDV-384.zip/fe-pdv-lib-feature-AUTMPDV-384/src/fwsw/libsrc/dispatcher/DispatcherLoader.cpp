/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "configLoader/DataManipConfig.hpp"
#include "configLoader/FieldSetConfig.hpp"
#include "configLoader/Iso8583Config.hpp"
#include "configLoader/LibrarianConfig.hpp"
#include "configLoader/PluginManagerConfig.hpp"
#include "dispatcher/DispatcherLoader.hpp"
#include "logMsg/MessageTable.hpp"
#include "logger/LoggerGen.hpp"
#include "msgConv/Iso8583Builder.hpp"
#include "msgConv/Iso8583Parser.hpp"
#include "msgConv/QueryStringBuilder.hpp"
#include "msgConv/QueryStringParser.hpp"
#include "msgConv/ShcMessageBuilder.hpp"
#include "msgConv/ShcMessageParser.hpp"
#include "pluginManager/ObjectInterface.hpp"

namespace dispatcher
{
	DispatcherLoader::DispatcherLoader( )
	: ISO8583_ID( "ISO8583" ), QUERY_STRING_ID( "QUERY_STRING" ), SHC_ID( "SHC" ), CUSTOM_ID( "CUSTOM" )
	{
		m_mainDispatcher			= 0;
		m_pluginManager			= 0;
		m_xmfFieldSet			= 0;
		m_imfFieldSet			= 0;
		m_environment			= 0;
		m_dataManipDispatch		= 0;
		m_outboundConverter		= 0;
		m_outboundLoader		= 0;
		m_outboundExtractor		= 0;
		m_reader				= 0;
		m_mbOut					= 0;
		m_logger = logger::LoggerGen::getInstance( );
		m_logger->init( );
	}
	DispatcherLoader::~DispatcherLoader( )
	{
	}
	void DispatcherLoader::setMainDispatcher( MainDispatcher* a_mainDispatcher )
	{
		m_mainDispatcher = a_mainDispatcher;
	}
	void DispatcherLoader::setDispatcherLabel( const std::string& a_label )
	{
		m_dispatcherLabel = a_label;
	}
	void DispatcherLoader::unload( )
	{
		delete m_environment;
		delete m_dataManipDispatch;
		delete m_outboundConverter;
		delete m_outboundLoader;
		delete m_outboundExtractor;
		delete m_reader;
		delete m_mbOut;
		delete m_xmfFieldSet;
		delete m_imfFieldSet;
		for( std::deque<fieldSet::FieldSet*>::iterator itm_shdFieldSet = dm_shdFieldSet.begin(); itm_shdFieldSet != dm_shdFieldSet.end(); ++itm_shdFieldSet )
        {
            delete *itm_shdFieldSet;
        }
		m_pluginManager->close( );
		pluginManager::Librarian::getInstance( )->clear( );
		delete m_pluginManager;
	}
	void DispatcherLoader::cleanup( )
	{
		m_selectedLibrarianTag.clear( );
		m_selectedPluginManagerTag.clear( );
		m_selectedXmfFieldSetTag.clear( );
		m_selectedImfFieldSetTag.clear( );
		m_selectedInternalEnvironmentTag.clear( );
		m_selectedDataManipDispatchTag.clear( );
		m_selectedOutboundIso8583PropertiesTag.clear( );
		m_mainXmlPath.clear( );
		m_mainXmlName.clear( );
		m_dispatcherLabel.clear( );
		m_librarianXml.clear( );
		m_pluginManagerXml.clear( );
		m_fieldSetXml.clear( );
		m_dataManipXml.clear( );
		m_iso8583PropertiesXml.clear( );
		m_librarianXmlPath.clear( );
		m_pluginManagerXmlPath.clear( );
		m_fieldSetXmlPath.clear( );
		m_dataManipXmlPath.clear( );
		m_iso8583PropertiesXmlPath.clear( );
		m_dispatcherTag.clear( );
		m_librarianTag.clear( );
		m_librarianRefLabel.clear( );
		m_pluginManagerTag.clear( );
		m_pluginManagerRefLabel.clear( );
		m_xmfFieldSetTag.clear( );
		m_xmfFieldSetRefLabel.clear( );
		m_xmfFieldSetSymbol.clear( );
		m_imfFieldSetTag.clear( );
		m_imfFieldSetRefLabel.clear( );
		m_imfFieldSetSymbol.clear( );
		m_internalEnvironmentTag.clear( );
		m_internalEnvironmentSymbol.clear( );
		m_dataManipDispatchTag.clear( );
		m_dataManipDispatchRefLabel.clear( );
		m_converterTag.clear( );
		m_outboundType.clear( );
		m_outboundIso8583Property.clear( );
		m_outboundCustomExtractor.clear( );
		m_outboundCustomLoader.clear( );
		m_outboundIso8583PropertyRefLabel.clear( );
		m_outboundCustomExtractorRefLabel.clear( );
		m_outboundCustomLoaderRefLabel.clear( );
		m_readerTag.clear( );
		m_readerRefLabel.clear( );
	}
	bool DispatcherLoader::load( )
	{
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0001 );
		RETURN_IF( !loadMainDispatcherXml( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0002 );
		RETURN_IF( !loadXmlFilesSection( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0003 );
		RETURN_IF( !loadXmlFilesProperties( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0004 );
		RETURN_IF( !loadObjectsReferencesTag( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0005 );
		RETURN_IF( !loadObjectsReferencesProperties( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0006 );
		RETURN_IF( !selectLibrarian( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0011 );
		RETURN_IF( !loadLibrarian( ), false );
		m_selectedLibrarianTag.clear( );
		m_librarianXml.clear( );
		m_librarianXmlPath.clear( );
		m_librarianTag.clear( );
		m_librarianRefLabel.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0007 );
		RETURN_IF( !selectPluginManager( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0012 );
		RETURN_IF( !loadPluginManager( ), false );
		m_selectedPluginManagerTag.clear( );
		m_pluginManagerXml.clear( );
		m_pluginManagerXmlPath.clear( );
		m_pluginManagerTag.clear( );
		m_pluginManagerRefLabel.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0008 );
		RETURN_IF( !selectFieldSets( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0013 );
		RETURN_IF( !loadFieldSets( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0014 );
		RETURN_IF( !loadFieldNavigator( ), false );
		m_selectedXmfFieldSetTag.clear( );
		m_selectedImfFieldSetTag.clear( );
		m_selectedInternalEnvironmentTag.clear( );
		m_fieldSetXml.clear( );
		m_fieldSetXmlPath.clear( );
		m_xmfFieldSetTag.clear( );
		m_xmfFieldSetRefLabel.clear( );
		m_xmfFieldSetSymbol.clear( );
		m_imfFieldSetTag.clear( );
		m_imfFieldSetRefLabel.clear( );
		m_imfFieldSetSymbol.clear( );
		m_internalEnvironmentTag.clear( );
		m_internalEnvironmentSymbol.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0009 );
		RETURN_IF( !selectDataManips( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0015 );
		RETURN_IF( !loadDataManips( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0010 );
		RETURN_IF( !selectIso8583Properties( ), false );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0016 );
		RETURN_IF( !loadConverters( ), false );
		m_selectedOutboundIso8583PropertiesTag.clear( );
		m_iso8583PropertiesXml.clear( );
		m_outboundIso8583Property.clear( );
		m_outboundIso8583PropertyRefLabel.clear( );
		m_outboundCustomExtractorRefLabel.clear( );
		m_outboundCustomLoaderRefLabel.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0017 );
		RETURN_IF( !loadMailboxes( ), false );
		RETURN_IF( !loadReader( ), false );
		RETURN_IF( !loadIntervalSeconds( ), false );
		m_readerTag.clear( );
		m_readerRefLabel.clear( );
		m_logger->print( logger::LEVEL_INFO, MSG_DISPATCHERLOADER_0019 );
		cleanup( );
		return true;
	}
	bool DispatcherLoader::loadXmlFilesProperties( )
	{
		for ( unsigned int l_ind = 0; l_ind < m_librarianXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_DISPATCHERLOADER_0020 << "path:" << m_librarianXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_librarianXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_librarianXmlPath.push_back( FILE_PATH( m_librarianXml[l_ind].findProperty( "filePath" ).value( ), m_librarianXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		for ( unsigned int l_ind = 0; l_ind < m_pluginManagerXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_DISPATCHERLOADER_0020 << "path:" << m_pluginManagerXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_pluginManagerXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_pluginManagerXmlPath.push_back( FILE_PATH( m_pluginManagerXml[l_ind].findProperty( "filePath" ).value( ), m_pluginManagerXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		for ( unsigned int l_ind = 0; l_ind < m_fieldSetXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_DISPATCHERLOADER_0020 << "path:" << m_fieldSetXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_fieldSetXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_fieldSetXmlPath.push_back( FILE_PATH( m_fieldSetXml[l_ind].findProperty( "filePath" ).value( ), m_fieldSetXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		for ( unsigned int l_ind = 0; l_ind < m_dataManipXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_DISPATCHERLOADER_0020 << "path:" << m_dataManipXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_dataManipXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_dataManipXmlPath.push_back( FILE_PATH( m_dataManipXml[l_ind].findProperty( "filePath" ).value( ), m_dataManipXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		for ( unsigned int l_ind = 0; l_ind < m_iso8583PropertiesXml.size( ); ++l_ind )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_DISPATCHERLOADER_0020 << "path:" << m_iso8583PropertiesXml[l_ind].findProperty( "filePath" ).value( ) << ", arquivo:" << m_iso8583PropertiesXml[l_ind].findProperty( "fileName" ).value( );
			m_logger->print( logger::LEVEL_DEBUG, m_logmsg.str( ).c_str( ) );
			m_iso8583PropertiesXmlPath.push_back( FILE_PATH( m_iso8583PropertiesXml[l_ind].findProperty( "filePath" ).value( ), m_iso8583PropertiesXml[l_ind].findProperty( "fileName" ).value( ) ) );
		}
		return true;
	}
	bool DispatcherLoader::loadXmlFilesSection( )
	{
		configBase::TagList l_xmlFilesTagList;
		m_dispatcherTag.findTag( "xmlFiles", l_xmlFilesTagList );
		configBase::Tag l_xmlFiles = l_xmlFilesTagList.front( );
		l_xmlFiles.findTag( "librarianXml", m_librarianXml );
		l_xmlFiles.findTag( "pluginManagerXml", m_pluginManagerXml );
		l_xmlFiles.findTag( "fieldSetXml", m_fieldSetXml );
		l_xmlFiles.findTag( "dataManipXml", m_dataManipXml );
		l_xmlFiles.findTagNotRequired( "iso8583PropertiesXml", m_iso8583PropertiesXml );
		return true;
	}
	bool DispatcherLoader::loadMainDispatcherXml( )
	{
		configBase::Tag l_fullTag;
		RETURN_IF( !loadXml( m_mainXmlPath, m_mainXmlName, l_fullTag ), false );
		configBase::TagList l_targetDispatcherConfig;
		l_fullTag.findTag( "dispatcher", "label", m_dispatcherLabel, l_targetDispatcherConfig );
		m_dispatcherTag = l_targetDispatcherConfig.front( );
		return true;
	}
	bool DispatcherLoader::loadObjectsReferencesProperties( )
	{
		for ( unsigned int l_lbrInd = 0; l_lbrInd < m_librarianTag.size( ); ++l_lbrInd )
		{
			m_librarianRefLabel.push_back( m_librarianTag[l_lbrInd].findProperty( "referenceLabel" ).value( ) );
		}
		for ( unsigned int l_plmInd = 0; l_plmInd < m_pluginManagerTag.size( ); ++l_plmInd )
		{
			m_pluginManagerRefLabel.push_back( m_pluginManagerTag[l_plmInd].findProperty( "referenceLabel" ).value( ) );
		}
		m_xmfFieldSetRefLabel = m_xmfFieldSetTag.findProperty( "referenceLabel" ).value( );
		m_xmfFieldSetSymbol = m_xmfFieldSetTag.findProperty( "symbol" ).value( );
		m_imfFieldSetRefLabel = m_imfFieldSetTag.findProperty( "referenceLabel" ).value( );
		m_imfFieldSetSymbol = m_imfFieldSetTag.findProperty( "symbol" ).value( );
        for( std::deque<configBase::Tag>::iterator itm_shdFieldSetTag = dm_shdFieldSetTag.begin(); itm_shdFieldSetTag != dm_shdFieldSetTag.end(); ++itm_shdFieldSetTag )
        {
		    dm_shdFieldSetRefLabel.push_back( itm_shdFieldSetTag->findProperty( "referenceLabel" ).value( ) );
		    dm_shdFieldSetSymbol.push_back( itm_shdFieldSetTag->findProperty( "symbol" ).value( ) );
        }
		m_internalEnvironmentSymbol = m_internalEnvironmentTag.findProperty( "symbol" ).value( );
		m_dataManipDispatchRefLabel = m_dataManipDispatchTag.findProperty( "referenceLabel" ).value( );
		m_outboundType = m_converterTag.findProperty( "outboundType" ).value( );
		if ( m_outboundType == ISO8583_ID )
		{
			m_outboundIso8583PropertyRefLabel = m_outboundIso8583Property.findProperty( "referenceLabel" ).value( );
		}
		if ( m_outboundType == CUSTOM_ID )
		{
			m_outboundCustomExtractorRefLabel = m_outboundCustomExtractor.findProperty( "referenceLabel" ).value( );
			m_outboundCustomLoaderRefLabel = m_outboundCustomLoader.findProperty( "referenceLabel" ).value( );
		}
		
		m_readerRefLabel = m_readerTag.findProperty( "referenceLabel" ).value( );

		return true;
	}
	bool DispatcherLoader::loadObjectsReferencesTag( )
	{
		m_dispatcherTag.findTag( "librarian", m_librarianTag );
		m_dispatcherTag.findTag( "pluginManager", m_pluginManagerTag );
		configBase::TagList l_xmfFieldSetTagList;
		m_dispatcherTag.findTag( "xmfFieldSet", l_xmfFieldSetTagList );
		m_xmfFieldSetTag = l_xmfFieldSetTagList.front( );
		configBase::TagList l_imfFieldSetTagList;
		m_dispatcherTag.findTag( "imfFieldSet", l_imfFieldSetTagList );
		m_imfFieldSetTag = l_imfFieldSetTagList.front( );
		configBase::TagList l_shdFieldSetTagList;
		m_dispatcherTag.findTagNotRequired( "shdFieldSet", l_shdFieldSetTagList );
        for ( unsigned int i = 0; i < l_shdFieldSetTagList.size(); i++ )
        {
            dm_shdFieldSetTag.push_back( l_shdFieldSetTagList.at( i ) );
        }
		configBase::TagList l_internalEnvironmentTagList;
		m_dispatcherTag.findTag( "internalEnvironment", l_internalEnvironmentTagList );
		m_internalEnvironmentTag = l_internalEnvironmentTagList.front( );
		configBase::TagList l_dataManipDispatchTagList;
		m_dispatcherTag.findTag( "dataManipDispatch", l_dataManipDispatchTagList );
		m_dataManipDispatchTag = l_dataManipDispatchTagList.front( );
		configBase::TagList l_converterTagList;
		m_dispatcherTag.findTag( "converter", l_converterTagList );
		m_converterTag = l_converterTagList.front( );
		
		if ( m_converterTag.findProperty( "outboundType" ).value( ) == ISO8583_ID )
		{
			configBase::TagList l_outbound8583TagList;
			m_converterTag.findTag( "outboundIso8583Property", l_outbound8583TagList );
			m_outboundIso8583Property = l_outbound8583TagList.front( );
		}
		else if ( m_converterTag.findProperty( "outboundType" ).value( ) == CUSTOM_ID )
		{
			configBase::TagList l_outboundCustomLoaderTagList;
			m_converterTag.findTag( "outboundCustomLoader", l_outboundCustomLoaderTagList );
			m_outboundCustomLoader = l_outboundCustomLoaderTagList.front( );
			configBase::TagList l_outboundCustomExtractorTagList;
			m_converterTag.findTag( "outboundCustomExtractor", l_outboundCustomExtractorTagList );
			m_outboundCustomExtractor = l_outboundCustomExtractorTagList.front( );
		}
		
		configBase::TagList l_readerTagList;
		m_dispatcherTag.findTag( "reader", l_readerTagList );
		m_readerTag = l_readerTagList.front( );
		
		configBase::TagList l_intervalSecondsTagList;
		m_dispatcherTag.findTag( "intervalSeconds", l_intervalSecondsTagList );
		m_intervalSecondsTag = l_intervalSecondsTagList.front( );
		
		return true;
	}
	bool DispatcherLoader::loadXml( const std::string& a_xmlPath, const std::string& l_xmlName, configBase::Tag& a_tag )
	{
		configBase::DOMTreatment l_domTreat;
		bool l_xmlret = l_domTreat.load( a_xmlPath, l_xmlName, a_tag );
		if ( !l_xmlret )
		{
			const configBase::XMLParseErrorHandler::ERRMSGS& l_errors = l_domTreat.errors( );
			this->reportXmlErrors( l_errors );
		}
		return l_xmlret;
	}
	void DispatcherLoader::reportXmlErrors( const configBase::XMLParseErrorHandler::ERRMSGS& a_errors )
	{
		unsigned int l_count = a_errors.size( );
		for ( unsigned int i = 0; i < l_count; ++i )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_DISPATCHERLOADER_0021 << "[" << a_errors[i].systemFile( ) << "][" << a_errors[i].lineNumber( ) << "][" << a_errors[i].columnNumber( ) << "][" << a_errors[i].message( ) << "]";
			m_logger->print( logger::LEVEL_FATAL, m_logmsg.str( ).c_str( ) );
		}
	}
	void DispatcherLoader::setXmlPath( const std::string& a_path )
	{
		m_mainXmlPath = a_path;
	}
	void DispatcherLoader::setXmlName( const std::string& a_name )
	{
		m_mainXmlName = a_name;
	}
	bool DispatcherLoader::selectLibrarian( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_librarianXmlPath.begin( ); l_it != m_librarianXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		for ( unsigned int l_ind = 0; l_ind < m_librarianRefLabel.size( ); ++l_ind )
		{
			configBase::TagList l_list;
			l_full.findTag( "librarian", "label", m_librarianRefLabel[l_ind], l_list );
			m_selectedLibrarianTag.addTag( l_list.front( ) );
		}
		return true;
	}
	bool DispatcherLoader::selectPluginManager( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_pluginManagerXmlPath.begin( ); l_it != m_pluginManagerXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		for ( unsigned int l_ind = 0; l_ind < m_pluginManagerRefLabel.size( ); ++l_ind )
		{
			configBase::TagList l_list;
			l_full.findTag( "pluginManager", "label", m_pluginManagerRefLabel[l_ind], l_list );
			m_selectedPluginManagerTag.addTag( l_list.front( ) );
		}
		return true;
	}
	bool DispatcherLoader::selectFieldSets( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_fieldSetXmlPath.begin( ); l_it != m_fieldSetXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		configBase::TagList l_list;
		l_full.findTag( "fieldSet", "label", m_xmfFieldSetRefLabel, l_list );
		m_selectedXmfFieldSetTag = l_list.front( );
		l_full.findTag( "fieldSet", "label", m_imfFieldSetRefLabel, l_list );
		m_selectedImfFieldSetTag = l_list.front( );

        for( std::deque<std::string>::iterator itm_shdFieldSetRefLabel = dm_shdFieldSetRefLabel.begin(); itm_shdFieldSetRefLabel != dm_shdFieldSetRefLabel.end(); ++itm_shdFieldSetRefLabel )
        {
		    l_full.findTag( "fieldSet", "label", *itm_shdFieldSetRefLabel, l_list );
            for ( unsigned int i = 0; i < l_list.size(); i++ )
            {
                dm_selectedShdFieldSetTag.push_back( l_list.at( i ) );
            }
        }
		return true;
	}
	bool DispatcherLoader::selectDataManips( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_dataManipXmlPath.begin( ); l_it != m_dataManipXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		configBase::TagList l_list;
		l_full.findTag( "dataManip", "label", m_dataManipDispatchRefLabel, l_list );
		m_selectedDataManipDispatchTag = l_list.front( );
		return true;
	}
	bool DispatcherLoader::selectIso8583Properties( )
	{
		configBase::Tag l_full;
		for ( FILE_LIST::const_iterator l_it = m_iso8583PropertiesXmlPath.begin( ); l_it != m_iso8583PropertiesXmlPath.end( ); ++l_it )
		{
			RETURN_IF( !loadXml( l_it->first, l_it->second, l_full ), false );
		}
		configBase::TagList l_list;
		if ( m_outboundType == ISO8583_ID )
		{
			l_full.findTag( "Iso8583Properties", "label", m_outboundIso8583PropertyRefLabel, l_list );
			m_selectedOutboundIso8583PropertiesTag = l_list.front( );
		}
		return true;
	}
	bool DispatcherLoader::loadLibrarian( )
	{
		configLoader::LibrarianConfig l_libConfig;
		for ( unsigned int l_ind = 0; l_ind < m_selectedLibrarianTag.size( ); ++l_ind )
		{
			if ( !l_libConfig.load( m_selectedLibrarianTag[l_ind] ) )
			{
				m_logmsg.str( "" );
				m_logmsg << MSG_DISPATCHERLOADER_0023 << l_libConfig.errorMessage( );
				m_logger->print( logger::LEVEL_FATAL, m_logmsg.str( ).c_str( ) );
				return false;
			}
		}
		return true;
	}
	bool DispatcherLoader::loadPluginManager( )
	{
		base::genAssertPtr( m_mainDispatcher, __FUNCTION__, "MainDispatcher not defined to load" );
		configLoader::PluginManagerConfig l_plmConfig;
		m_pluginManager = new pluginManager::PluginManager;
		for ( unsigned int l_ind = 0; l_ind < m_selectedPluginManagerTag.size( ); ++l_ind )
		{
			if ( !l_plmConfig.load( *m_pluginManager, m_selectedPluginManagerTag[l_ind] ) )
			{
				m_logmsg.str( "" );
				m_logmsg << MSG_DISPATCHERLOADER_0022 << l_plmConfig.errorMessage( );
				m_logger->print( logger::LEVEL_FATAL, m_logmsg.str( ).c_str( ) );
				return false;
			}
		}
		m_mainDispatcher->setPluginManager( m_pluginManager );
		if ( !m_pluginManager->open( ) )
		{
			m_logmsg.str( "" );
			m_logmsg << MSG_DISPATCHERLOADER_0022 << "*" << std::endl << m_pluginManager->errorMessage( );
			m_logger->print( logger::LEVEL_FATAL, m_logmsg.str( ).c_str( ) );
			return false;
		}
		return true;
	}
	bool DispatcherLoader::loadFieldSets( )
	{
        fieldSet::FieldSet *m_shdFieldSet;
		base::genAssertPtr( m_mainDispatcher, __FUNCTION__, "MainDispatcher not defined to load" );
		configLoader::FieldSetConfig l_fsConfig;
		m_xmfFieldSet = new fieldSet::FieldSet;
		m_imfFieldSet = new fieldSet::FieldSet;
		for ( unsigned int l_ind = 0; l_ind < dm_selectedShdFieldSetTag.size( ); ++l_ind )
        {
		    m_shdFieldSet = new fieldSet::FieldSet; dm_shdFieldSet.push_back( m_shdFieldSet );
        }
		m_environment = new fieldSet::FieldSet;
		RETURN_IF( !l_fsConfig.load( *m_xmfFieldSet, m_selectedXmfFieldSetTag ), false );
		RETURN_IF( !l_fsConfig.load( *m_imfFieldSet, m_selectedImfFieldSetTag ), false );

        std::deque<configBase::Tag>::iterator itm_selectedShdFieldSetTag = dm_selectedShdFieldSetTag.begin();
        for( std::deque<fieldSet::FieldSet*>::iterator itm_shdFieldSet = dm_shdFieldSet.begin(); itm_shdFieldSet != dm_shdFieldSet.end(); ++itm_shdFieldSet )
        {
		    RETURN_IF( !l_fsConfig.load( **itm_shdFieldSet, *itm_selectedShdFieldSetTag ), false );
            ++itm_selectedShdFieldSetTag;
        }

		m_environment->setLabel( m_internalEnvironmentSymbol );
		m_mainDispatcher->setXmfFieldSet( m_xmfFieldSet );
		m_mainDispatcher->setImfFieldSet( m_imfFieldSet );
		m_mainDispatcher->setEnvironment( m_environment );
		return true;
	}
	bool DispatcherLoader::loadFieldNavigator( )
	{
		m_navigator.addField( m_xmfFieldSetSymbol, m_xmfFieldSet );
		m_navigator.addField( m_imfFieldSetSymbol, m_imfFieldSet );
        std::deque<std::string>::iterator itm_shdFieldSetSymbol = dm_shdFieldSetSymbol.begin();
        for( std::deque<fieldSet::FieldSet*>::iterator itm_shdFieldSet = dm_shdFieldSet.begin(); itm_shdFieldSet != dm_shdFieldSet.end(); ++itm_shdFieldSet )
        {
		    m_navigator.addField( *itm_shdFieldSetSymbol, *itm_shdFieldSet );
            itm_shdFieldSetSymbol++;
        }
		m_navigator.addField( m_internalEnvironmentSymbol, m_environment );
		m_mainDispatcher->setNavigator( m_navigator );
		return true;
	}
	bool DispatcherLoader::loadDataManips( )
	{
		base::genAssertPtr( m_mainDispatcher, __FUNCTION__, "MainDispatcher not defined to load" );
		configLoader::DataManipConfig l_dataManipConfig( 1 );
		l_dataManipConfig.setPluginManager( m_pluginManager );
		l_dataManipConfig.setFieldNavigator( m_navigator );
		m_dataManipDispatch		= new dataManip::DataManip;
		l_dataManipConfig.load( *m_dataManipDispatch, m_selectedDataManipDispatchTag );
		m_selectedDataManipDispatchTag.clear( );
		m_dataManipDispatchRefLabel.clear( );		
		m_dataManipXml.clear( );
		m_dataManipXmlPath.clear( );
		m_mainDispatcher->setDataManipDispatch( m_dataManipDispatch );

		return true;
	}
	bool DispatcherLoader::loadConverters( )
	{
		base::genAssertPtr( m_mainDispatcher, __FUNCTION__, "MainDispatcher not defined to load" );
		m_outboundConverter	= new msgConv::MessageConverter;
		m_outboundLoader		= 0;
		m_outboundExtractor		= 0;
		
		if ( m_outboundType == ISO8583_ID )
		{
			configLoader::Iso8583Config l_iso8583Config;
			msgConv::Iso8583Properties l_isoProperties;
			RETURN_IF( !l_iso8583Config.load( l_isoProperties, m_selectedOutboundIso8583PropertiesTag ), false );
			m_outboundLoader	= new msgConv::Iso8583Parser( l_isoProperties );
			m_outboundExtractor	= new msgConv::Iso8583Builder( l_isoProperties );
		}
		else if ( m_outboundType == SHC_ID )
		{
			m_outboundLoader		= new msgConv::ShcMessageParser;
			m_outboundExtractor		= new msgConv::ShcMessageBuilder;
		}
		else if ( m_outboundType == QUERY_STRING_ID )
		{
			m_outboundLoader		= new msgConv::QueryStringParser;
			m_outboundExtractor		= new msgConv::QueryStringBuilder;
		}
		else if ( m_outboundType == CUSTOM_ID )
		{
			pluginManager::ObjectInterface<msgConv::FieldSetLoader> l_fieldsetLoaderObjInterface( m_pluginManager );
			m_outboundLoader = l_fieldsetLoaderObjInterface.create( m_outboundCustomLoaderRefLabel );
			base::genAssert( m_outboundLoader->startConfiguration( &m_outboundCustomLoader ), __FUNCTION__, "Error starting outbound custom loader for message converter" );
			pluginManager::ObjectInterface<msgConv::FieldSetExtractor> l_fieldsetExtractorObjInterface( m_pluginManager );
			m_outboundExtractor = l_fieldsetExtractorObjInterface.create( m_outboundCustomExtractorRefLabel );
			base::genAssert( m_outboundExtractor->startConfiguration( &m_outboundCustomExtractor ), __FUNCTION__, "Error starting outbound custom extractor for message converter" );
		}
		else
		{
			return false;
		}
		m_outboundLoader->setFieldSet( m_imfFieldSet );
		m_outboundExtractor->setFieldSet( m_imfFieldSet );
		m_outboundConverter->setFieldSetLoader( m_outboundLoader );
		m_outboundConverter->setFieldSetExtractor( m_outboundExtractor );
		m_mainDispatcher->setOutboundConverter( m_outboundConverter );
		return true;
	}
	bool DispatcherLoader::loadMailboxes( )
	{
		m_mbOut = new mailboxInterface::MailboxOut;
		m_mainDispatcher->setMbOut( m_mbOut );
		return true;
	}
	bool DispatcherLoader::loadReader( )
	{
		pluginManager::ObjectInterface<Reader> l_readerLoaderObjInterface( m_pluginManager );
		m_reader = l_readerLoaderObjInterface.create( m_readerRefLabel );
		base::genAssert( m_reader->startConfiguration( &m_readerTag ), __FUNCTION__, "Error starting source reader" );
		
		m_reader->setFieldNavigator( m_navigator );
		m_mainDispatcher->setReader( m_reader );
		return true;
	}
	bool DispatcherLoader::loadIntervalSeconds( )
	{
		m_intervalSeconds = atoi( m_intervalSecondsTag.findProperty( "value" ).value( ).c_str( ) );
		m_mainDispatcher->setIntervalSeconds( m_intervalSeconds );
		return true;
	}
}//namespace dispatcher

