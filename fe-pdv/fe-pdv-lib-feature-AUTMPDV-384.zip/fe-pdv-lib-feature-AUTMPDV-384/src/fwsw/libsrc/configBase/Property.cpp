/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, 
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include <cstdio>
#include <cstdlib>
#include "configBase/Property.hpp"
namespace configBase
{
	Property::Property( )
	: m_valid( true )
	{
	}
	Property::Property( const std::string& a_name )
	: m_name( a_name ), m_valid( true )
	{
	}
	Property::Property( const std::string& a_name, const std::string& a_value )
	: m_name( a_name ), m_value( a_value ), m_valid( true )
	{
	}
	Property::Property( bool a_valid )
	: m_valid( a_valid )
	{
	}
	Property::~Property( )
	{
	}
	bool Property::isValid( ) const
	{
		return m_valid;
	}
	Property& Property::setName( const std::string& a_name )
	{
		m_name = a_name;
		return *this;
	}
	Property& Property::setValue( const std::string& a_value )
	{
		m_value = a_value;
		return *this;
	}
	const std::string& Property::name( ) const
	{
		return m_name;
	}
	std::string Property::value( ) const
	{
		size_t l_pos = m_value.find( "$(" );
		std::string l_retValue = m_value;
		while ( l_pos != std::string::npos )
		{
			size_t l_endVarPos = l_retValue.find( ")", l_pos );
			size_t l_nameIniPos = l_pos + 2;
			std::string l_var = m_value.substr( l_nameIniPos, 
			                                    l_endVarPos - l_nameIniPos );
			char* l_value = getenv( l_var.c_str( ) );
			std::string l_strValue = l_value == 0 ? "" : l_value;
			size_t l_lenReplace = l_endVarPos - l_pos + 1;
			l_retValue.replace( l_pos, l_lenReplace, l_strValue );
			l_pos = l_retValue.find( "$(" );
		}
		return l_retValue;
	}
}//namespace configBase

