/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"

namespace configBase
{
	TagList::TagList( )
	{
	}
	TagList::TagList( const std::string& a_tagListName )
	{
		m_tagListName = a_tagListName;
	}
	TagList::~TagList( )
	{
	}
	TagList& TagList::setName( const std::string& a_tagListName )
	{
		m_tagListName = a_tagListName;
		return *this;
	}
	TagList& TagList::addTag( const Tag& a_tag )
	{
		m_tags.push_back( a_tag );
		return *this;
	}
	unsigned int TagList::size( ) const
	{
		return m_tags.size( );
	}
	Tag& TagList::at( unsigned int a_index )
	{
		base::genAssert( a_index < m_tags.size( ), __FUNCTION__, 
		                 "Index out of bound" );
		return m_tags[a_index];
	}
	const Tag& TagList::at( unsigned int a_index ) const
	{
		base::genAssert( a_index < m_tags.size( ), __FUNCTION__, 
		                 "Index out of bound" );
		return m_tags[a_index];
	}
	Tag& TagList::operator[]( unsigned int a_index )
	{
		Tag& l_ret = at( a_index );
		return l_ret;
	}
	const Tag& TagList::operator[]( unsigned int a_index ) const
	{
		const Tag& l_ret = at( a_index );
		return l_ret;
	}
	const Tag& TagList::front( ) const
	{
		base::genAssert( m_tags.size( )> 0, __FUNCTION__, "Void tag list <" 
		                 + m_tagListName + ">" );
		const Tag& l_ret = m_tags.front( );
		return l_ret;
	}
	Tag& TagList::front( )
	{
		base::genAssert( m_tags.size( )> 0, __FUNCTION__, "Void tag list <" 
		                 + m_tagListName + ">" );
		Tag& l_ret = m_tags.front( );
		return l_ret;
	}
	const Tag& TagList::back( ) const
	{
		base::genAssert( m_tags.size( )> 0, __FUNCTION__, "Void tag list <" 
		                 + m_tagListName + ">" );
		const Tag& l_ret = m_tags.back( );
		return l_ret;
	}
	Tag& TagList::back( )
	{
		base::genAssert( m_tags.size( )> 0, __FUNCTION__, "Void tag list <" 
		                 + m_tagListName + ">" );
		Tag& l_ret = m_tags.back( );
		return l_ret;
	}
	TagList& TagList::clear( )
	{
		m_tags.clear( );
		return *this;
	}
}//namespace configBase

