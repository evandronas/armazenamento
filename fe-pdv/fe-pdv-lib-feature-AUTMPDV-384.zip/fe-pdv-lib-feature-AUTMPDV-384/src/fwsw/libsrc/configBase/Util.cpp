/* Copyright 2014 Rede S.A.
Autor : Luiz Gustavo O Costa
Empresa : BSI Tecnologia
*/

#pragma once

#include <unistd.h>
#include "configBase/Util.hpp"
#include "configBase/ConfigBase.hpp"
#include <string>

namespace configBase
{
		unsigned long Util::min_usleeptime_init = 0;
		unsigned long Util::margin_usleeptime_init = 0;

		// Util
		// Construtor default da classe
		// EF/ET: 64145
		// Hist�rico: [24/06/2014] - 64145 - Release IV de 2014	
		Util::Util( )
		{
		}
		
		// Util
		// Destrutor default da classe
		// EF/ET: 64145
		// Hist�rico: [24/06/2014] - 64145 - Release IV de 2014	
		Util::~Util( )
		{
		}
		
		// Sleep
		// Controla a chamadas de sleep realizadas
		// EF/ET: 64145
		// Hist�rico: [24/06/2014] - 64145 - Release IV de 2014			
		void Util::Sleep()
		{
			static bool l_already_init = false;
			//Se o sleep ja esta em execucao
			if( l_already_init == false )
			{
				std::string l_retValue;

				if( ConfigBase::getInstance()->findFirst("fwsw.min_usleeptime_init", l_retValue) )
					min_usleeptime_init = atol(l_retValue.c_str());
				else
					min_usleeptime_init = 0;
				
				if( ConfigBase::getInstance()->findFirst("fwsw.margin_usleeptime_init", l_retValue) )
					margin_usleeptime_init = atol(l_retValue.c_str());
				else
					margin_usleeptime_init = 0;
				
				l_already_init = true;
			}
			//Se esta configurado o tempo de sleep
			if( min_usleeptime_init && margin_usleeptime_init )
				usleep( rand() % margin_usleeptime_init + min_usleeptime_init );
		}
}//namespace configBase

