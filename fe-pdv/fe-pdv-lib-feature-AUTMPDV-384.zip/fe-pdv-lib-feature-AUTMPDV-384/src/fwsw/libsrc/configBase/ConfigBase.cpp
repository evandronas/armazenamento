/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include <ist_cfg.h>
#include "configBase/ConfigBase.hpp"


namespace configBase
{
	ConfigBase* ConfigBase::m_instance = 0;
	std::string ConfigBase::m_currentParm;
	ConfigBase::ConfigBase( )
	{
	}
	ConfigBase::~ConfigBase( )
	{
	}
	ConfigBase* ConfigBase::getInstance( )
	{
		if ( !m_instance )
		m_instance = new ConfigBase( );
		return m_instance;
	}
	void ConfigBase::init( )
	{
		cf_open( NULL );
		cf_rewind( );
	}
	bool ConfigBase::findFirst( const char* a_paramName, 
	                            std::string& a_retValue )
	{
		char l_retValue[4096];
		m_currentParm = a_paramName;
		if ( cf_locate( a_paramName, l_retValue )> 0 )
		{
			a_retValue = l_retValue;
			return true;
		}
		return false;
	}
	bool ConfigBase::findNext( std::string& a_retValue )
	{
		char l_retValue[4096];
		if ( cf_nextparm( m_currentParm.c_str( ), l_retValue )> 0 )
		{
			a_retValue = l_retValue;
			return true;
		}
		return false;
	}
};

