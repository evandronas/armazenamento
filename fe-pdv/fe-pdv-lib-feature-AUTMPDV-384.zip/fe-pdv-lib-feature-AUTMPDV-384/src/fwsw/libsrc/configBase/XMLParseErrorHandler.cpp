/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "configBase/XMLParseErrorHandler.hpp"

namespace configBase
{
	XMLParseErrorHandler::XMLParseErrorHandler( )
	{
	}
	XMLParseErrorHandler::~XMLParseErrorHandler( )
	{
	}
	const XMLParseErrorHandler::ERRMSGS& XMLParseErrorHandler::errors( ) const
	{
		return m_errors;
	}
	void XMLParseErrorHandler::warning( const xercesc::SAXParseException&
	                                    a_saxParseException )
	{
		char* l_publicFile = xercesc::XMLString::transcode( 
		    a_saxParseException.getPublicId( ) );
		char* l_systemFile = xercesc::XMLString::transcode( 
		    a_saxParseException.getSystemId( ) );
		char* l_errorMessage = xercesc::XMLString::transcode( 
			a_saxParseException.getMessage( ) );
		m_errors.push_back( ErrorMsg( std::string( l_publicFile ),
		                              std::string( l_systemFile ),
									  std::string( l_errorMessage ),
									  a_saxParseException.getLineNumber( ),
									  a_saxParseException.getColumnNumber( ) )
						   );
		xercesc::XMLString::release( &l_publicFile );
		xercesc::XMLString::release( &l_systemFile );
		xercesc::XMLString::release( &l_errorMessage );
	}
	void XMLParseErrorHandler::error( const xercesc::SAXParseException&
	                                  a_saxParseException )
	{
		char* l_publicFile = xercesc::XMLString::transcode( 
			a_saxParseException.getPublicId( ) );
		char* l_systemFile = xercesc::XMLString::transcode( 
			a_saxParseException.getSystemId( ) );
		char* l_errorMessage = xercesc::XMLString::transcode( 
			a_saxParseException.getMessage( ) );
		m_errors.push_back( ErrorMsg( std::string( l_publicFile ),
		                              std::string( l_systemFile ),
									  std::string( l_errorMessage ),
									  a_saxParseException.getLineNumber( ),
									  a_saxParseException.getColumnNumber( ) )
						   );
		xercesc::XMLString::release( &l_publicFile );
		xercesc::XMLString::release( &l_systemFile );
		xercesc::XMLString::release( &l_errorMessage );
	}
	void XMLParseErrorHandler::fatalError( const xercesc::SAXParseException&
	                                       a_saxParseException )
	{
		char* l_publicFile = xercesc::XMLString::transcode( 
			a_saxParseException.getPublicId( ) );
		char* l_systemFile = xercesc::XMLString::transcode( 
			a_saxParseException.getSystemId( ) );
		char* l_errorMessage = xercesc::XMLString::transcode( 
			a_saxParseException.getMessage( ) );
		m_errors.push_back( ErrorMsg( std::string( l_publicFile ),
                                	  std::string( l_systemFile ),
									  std::string( l_errorMessage ),
									  a_saxParseException.getLineNumber( ),
									  a_saxParseException.getColumnNumber( ) )
						   );
		xercesc::XMLString::release( &l_publicFile );
		xercesc::XMLString::release( &l_systemFile );
		xercesc::XMLString::release( &l_errorMessage );
	}
	void XMLParseErrorHandler::resetErrors( const xercesc::SAXParseException&
	                                        a_saxParseException )
	{
	}
	void XMLParseErrorHandler::clear( )
	{
		m_errors.clear( );
	}
}//namespace configBase

