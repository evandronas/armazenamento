/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "configBase/DOMTreatment.hpp"
#include "configBase/Util.hpp"

namespace configBase
{
	DOMTreatment::DOMTreatment( )
	{
		m_xmldoc		= 0;
		m_parser		= 0;
		m_errHandler	= 0;
	}
	DOMTreatment::~DOMTreatment( )
	{
	}
	const XMLParseErrorHandler::ERRMSGS& DOMTreatment::errors( ) const
	{
		return m_errHandler->errors( );
	}
	bool DOMTreatment::open( )
	{
		try
		{
			xercesc::XMLPlatformUtils::Initialize( );
			m_parser = new xercesc::XercesDOMParser( );
			m_parser->setValidationScheme( 
			          xercesc::XercesDOMParser::Val_Always );
			m_parser->setIncludeIgnorableWhitespace( false );
			m_parser->setCreateCommentNodes( false );
			m_errHandler = new XMLParseErrorHandler( );
			m_parser->setErrorHandler( m_errHandler );
			m_parser->parse( m_pathName.c_str( ) );
			int l_errorCount = m_parser->getErrorCount( );
			RETURN_IF( l_errorCount > 0, false );
			m_xmldoc = m_parser->getDocument( );
			base::genAssert( m_xmldoc != 0, __FUNCTION__, 
			                 "Error getting xml parser document for xml file<" 
							 + m_pathName + ">" );
		}
		catch( const xercesc::XMLException &a_xmlException )
		{
			char* l_pMsg = xercesc::XMLString::transcode( 
			               a_xmlException.getMessage( ) );
			std::string l_msg( l_pMsg );
			xercesc::XMLString::release( &l_pMsg );
			throw base::GenException( __FUNCTION__, "Xml Exception in file <" 
			                          +  m_pathName + "> - " + l_msg );
		}
		catch( const xercesc::DOMException& a_xmlException )
		{
			char* l_pMsg = xercesc::XMLString::transcode( 
			               a_xmlException.getMessage( ) );
			std::string l_msg( l_pMsg );
			xercesc::XMLString::release( &l_pMsg );
			throw base::GenException( __FUNCTION__, "DOM Exception in file <" 
			                          + m_pathName + "> - " + l_msg );
		}
		catch( ... )
		{
			throw base::GenException( __FUNCTION__, 
			                          "Unknown Exception reading xml file <" 
									  + m_pathName + ">" );
		}
		return true;
	}
	void DOMTreatment::setFile( const std::string& a_path, 
	                            const std::string& a_name )
	{
		m_pathName = a_path + "/" + a_name;
	}
	void DOMTreatment::close( )
	{
		if ( m_parser )
		{
			delete m_parser;
			m_parser = 0;
		}
		if ( m_errHandler )
		{
			delete m_errHandler;
			m_errHandler = 0;
		}
		try
		{
			xercesc::XMLPlatformUtils::Terminate( );
		}
		catch( const xercesc::XMLException &a_xmlException )
		{
		}
	}
	xercesc::DOMElement* DOMTreatment::rootDocumentNode( )
	{
		return this->m_xmldoc->getDocumentElement( );
	}
	bool DOMTreatment::xmlParser( xercesc::DOMNode *a_node, Tag& a_tag )
	{
		RETURN_IF( a_node == 0, false );
		xercesc::DOMNamedNodeMap *l_atts = a_node->getAttributes( );
		RETURN_IF( l_atts == 0, false );
		for ( XMLSize_t i = 0; i < l_atts->getLength( ); i++ )
		{
			xercesc::DOMNode *a_attr = l_atts->item( i );
			RETURN_IF( a_attr == 0, false );
			char* l_ptrNodeName = xercesc::XMLString::transcode( 
			                      a_attr->getNodeName( ) );
			char* l_ptrNodeValue = xercesc::XMLString::transcode( 
			                       a_attr->getNodeValue( ) );
			std::string l_nodeName = l_ptrNodeName;
			std::string l_nodeValue = l_ptrNodeValue;
			xercesc::XMLString::release( &l_ptrNodeName );
			xercesc::XMLString::release( &l_ptrNodeValue );
			a_tag.addProperty( Property( l_nodeName, l_nodeValue ) );
			configBase::Util::Sleep();
		}
		xercesc::DOMNodeList *l_ChildrenList = a_node->getChildNodes( );
		RETURN_IF( l_ChildrenList == 0, false );
		for ( XMLSize_t i = 0; i < l_ChildrenList->getLength( ); i++ )
		{
			xercesc::DOMNode *a_child = l_ChildrenList->item( i );
			RETURN_IF( a_child == 0, false );
			char* l_ptrTagName = xercesc::XMLString::transcode( 
			                     a_child->getNodeName( ) );
			std::string l_tagName = l_ptrTagName;
			xercesc::XMLString::release( &l_ptrTagName );
			Tag& l_newTag = a_tag.addTag( Tag( l_tagName, m_pathName, i ) );
			configBase::Util::Sleep();
			RETURN_IF( !this->xmlParser( a_child, l_newTag ), false );
		}
		return true;
	}
	bool DOMTreatment::load( const std::string& a_fullName, Tag& a_tag )
	{
		m_pathName = a_fullName;
		RETURN_IF( !this->open( ), false );
		xercesc::DOMElement* l_root = this->rootDocumentNode( );
		RETURN_IF( l_root == 0, false );
		char* l_ptrTagName = xercesc::XMLString::transcode( 
		                     l_root->getNodeName( ) );
		std::string l_tagName = l_ptrTagName;
		xercesc::XMLString::release( &l_ptrTagName );
		a_tag.setName( l_tagName );
		a_tag.setSourceId( m_pathName );
		xercesc::DOMNodeList* l_ChildrenList = l_root->getChildNodes( );
		RETURN_IF( l_ChildrenList == 0, false );
		for ( XMLSize_t i = 0; i < l_ChildrenList->getLength( ); i++ )
		{
			xercesc::DOMNode* l_currentNode = l_ChildrenList->item( i );
			RETURN_IF( l_currentNode == 0, false );
			char* l_ptrTagName = xercesc::XMLString::transcode( 
			                     l_currentNode->getNodeName( ) );
			std::string l_tagName = l_ptrTagName;
			xercesc::XMLString::release( &l_ptrTagName );
			Tag& l_newTag = a_tag.addTag( Tag( l_tagName, m_pathName, i ) );
			configBase::Util::Sleep();
			RETURN_IF( !this->xmlParser( l_currentNode, l_newTag ), false );
		}
		this->close( );
		return true;
	}
	bool DOMTreatment::load( const std::string& a_path, 
	                         const std::string& a_name, Tag& a_tag )
	{
		std::string l_fullName = a_path + "/" + a_name;
		bool l_ret = this->load( l_fullName, a_tag );
		return l_ret;
	}
}//namespace configBase

