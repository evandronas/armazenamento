/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/Tag.hpp"
#include "configBase/TagList.hpp"
#include "logMsg/MessageTable.hpp"
#include "logger/LoggerGen.hpp"
#include "configBase/Util.hpp"

namespace configBase
{
	bool Tag::m_dumpMode = false;
	Tag::Tag( )
	{
	}
	Tag::Tag( const std::string& a_tagName, const std::string& a_sourceId, 
	          unsigned int a_sequence )
	: m_name( a_tagName ), m_sourceId( a_sourceId ), m_sequence( a_sequence )
	{
	}
	Tag::~Tag( )
	{
	}
	Tag& Tag::setName( const std::string& a_name )
	{
		m_name = a_name;
		return *this;
	}
	Tag& Tag::setSourceId( const std::string& a_sourceId )
	{
		m_sourceId = a_sourceId;
		return *this;
	}
	Tag& Tag::setSequence( unsigned int a_sequence )
	{
		m_sequence = a_sequence;
		return *this;
	}
	unsigned int Tag::sequence( ) const
	{
		return m_sequence;
	}
	void Tag::enableDumpMode( bool a_enable )
	{
		m_dumpMode = a_enable;
	}
	Tag& Tag::addTag( const Tag& a_tag )
	{
		m_tags.push_back( a_tag );
		unsigned int l_newInd = m_tags.size( ) - 1;
		m_tagsIndex.insert( TAG_PAIR( a_tag.name( ), l_newInd ) );
		Tag& l_ret = m_tags.back( );
		return l_ret;
	}
	Tag& Tag::addProperty( const Property& a_property )
	{
		std::pair<PROP_MAP::iterator, bool> l_ret;
		PROP_PAIR l_pair( a_property.name( ), m_properties.size( ) );
		l_ret = m_propertiesIndex.insert( l_pair );
		if ( l_ret.second )
		{
			m_properties.push_back( a_property );
		}
		else
		{
			throw base::GenException( __FUNCTION__, "Duplicated property <" 
			                          + a_property.name( ) + ">" );
		}
		return *this;
	}
	unsigned int Tag::tagCount( ) const
	{
		return m_tags.size( );
	}
	unsigned int Tag::propertyCount( ) const
	{
		return m_properties.size( );
	}
	Tag& Tag::tagAt( unsigned int a_index )
	{
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0001 << "[" << a_index << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		base::genAssert( a_index < m_tags.size( ), __FUNCTION__,
		                 "Index out of bound" );
		return m_tags[a_index];
	}
	const Tag& Tag::tagAt( unsigned int a_index ) const
	{
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0001 << "[" << a_index << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		base::genAssert( a_index < m_tags.size( ), __FUNCTION__,
		                 "Index out of bound" );
		return m_tags[a_index];
	}
	Property& Tag::propertyAt( unsigned int a_index )
	{
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0002 << "[" << a_index << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		base::genAssert( a_index < m_properties.size( ), __FUNCTION__,
		                 "Index out of bound" );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0005 << "[" 
			<< m_properties[a_index].value( ) << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		return m_properties[a_index];
	}
	const Property& Tag::propertyAt( unsigned int a_index ) const
	{
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0002 << "[" << a_index << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		base::genAssert( a_index < m_properties.size( ), __FUNCTION__,
		                 "Index out of bound" );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0005 << "[" 
			<< m_properties[a_index].value( ) << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		return m_properties[a_index];
	}
	const Tag& Tag::findTag( const std::string& a_tagName,
	                         TagList& a_tagList ) const
	{
		TAG_MAP::const_iterator l_itLower = 
		m_tagsIndex.lower_bound( a_tagName );
		TAG_MAP::const_iterator l_itUpper = 
		m_tagsIndex.upper_bound( a_tagName );
		a_tagList.clear( );
		a_tagList.setName( m_name );
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg
			<< MSG_CONFIGBASE_0003 << "[" << a_tagName << "]in xml["
			<< m_sourceId << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		for ( TAG_MAP::const_iterator l_it = l_itLower;
              l_it != l_itUpper; ++l_it )
		{
			a_tagList.addTag( m_tags[l_it->second] );
			configBase::Util::Sleep();
		}
		base::genAssert( a_tagList.size( )> 0, __FUNCTION__, "Tag <" 
		                 +  a_tagName + "> not found in <" + m_sourceId + ">" );
		return *this;
	}
	const Tag& Tag::findTag( const std::string& a_tagName, 
	                         const std::string& a_propertyName, 
							 const std::string& a_propertyValue, 
							 TagList& a_tagList ) const
	{
		TagList l_tags( m_name );
		a_tagList.clear( );
		a_tagList.setName( m_name );
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg
			<< MSG_CONFIGBASE_0003 << "[" << a_tagName
			<< "]for property["
			<< a_propertyName << "]with value[" << a_propertyValue
			<< "]in xml["
			<< m_sourceId << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		findTag( a_tagName, l_tags );
		for ( unsigned int l_index = 0; l_index < l_tags.size( ); ++l_index )
		{
			const Tag& l_tag = l_tags[l_index];
			Property l_property = l_tag.findProperty( a_propertyName );
			configBase::Util::Sleep();
			if ( l_property.value( ) != a_propertyValue )
			{
				continue;
			}
			a_tagList.addTag( l_tag );
		}
		base::genAssert( a_tagList.size( )> 0, __FUNCTION__, "Tag <" 
						 +  a_tagName
						 + "> not found for property <" + a_propertyName
						 + "> with value <" + a_propertyValue + ">" + "> in <" 
						 + m_sourceId
						 + ">" );
		return *this;
	}
	bool Tag::findTagNotRequired( const std::string& a_tagName, 
	                              TagList& a_tagList ) const
	{
		TAG_MAP::const_iterator l_itLower = 
		m_tagsIndex.lower_bound( a_tagName );
		TAG_MAP::const_iterator l_itUpper = 
		m_tagsIndex.upper_bound( a_tagName );
		a_tagList.clear( );
		a_tagList.setName( m_name );
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg
			<< MSG_CONFIGBASE_0003 << "[" << a_tagName << "]in xml["
			<< m_sourceId << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		for ( TAG_MAP::const_iterator l_it = l_itLower; 
		      l_it != l_itUpper; ++l_it )
		{
			a_tagList.addTag( m_tags[l_it->second] );
		}
		bool l_ret = a_tagList.size( )> 0;
		return l_ret;
	}
	bool Tag::findTagNotRequired( const std::string& a_tagName, 
								  const std::string& a_propertyName, 
								  const std::string& a_propertyValue, 
								  TagList& a_tagList ) const
	{
		TagList l_tags;
		a_tagList.clear( );
		a_tagList.setName( m_name );
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg
			<< MSG_CONFIGBASE_0003 << "[" << a_tagName
			<< "]for property["
			<< a_propertyName << "]with value[" << a_propertyValue
			<< "]in xml["
			<< m_sourceId << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		findTag( a_tagName, l_tags );
		for ( unsigned int l_index = 0; l_index < l_tags.size( ); ++l_index )
		{
			const Tag& l_tag = l_tags[l_index];
			Property l_property = l_tag.findProperty( a_propertyName );
			if ( l_property.value( ) != a_propertyValue )
			{
				continue;
			}
			a_tagList.addTag( l_tag );
		}
		bool l_ret = a_tagList.size( )> 0;
		return l_ret;
	}
	Property Tag::findPropertyNotRequired( const std::string& 
	                                       a_propertyName ) const
	{
		PROP_MAP::const_iterator l_it = 
		m_propertiesIndex.find( a_propertyName );
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0004 << "[" << a_propertyName
			<< "]in Tag[" << m_name << "]in xml[" << m_sourceId << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		if ( l_it == m_propertiesIndex.end( ) )
		{
			if ( m_dumpMode )
			{
				l_logmsg.str( "" );
				l_logmsg << MSG_CONFIGBASE_0006;
				l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
			}
			return Property( false );
		}
		const Property& l_ret = m_properties[l_it->second];
		return l_ret;
	}
	Property Tag::findProperty( const std::string& a_propertyName ) const
	{
		PROP_MAP::const_iterator l_it = 
		m_propertiesIndex.find( a_propertyName );
		std::stringstream l_logmsg;
		logger::Logger& l_logger = *logger::LoggerGen::getInstance( );
		l_logger.init( );
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0004 << "[" << a_propertyName
			<< "]in Tag[" << m_name << "]in xml[" << m_sourceId << "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		base::genAssert( l_it != m_propertiesIndex.end( ),
                         __FUNCTION__, "Property <" + a_propertyName
		+ "> not found in Tag <" + m_name
		+ "> in <" + m_sourceId + ">" );
		const Property& l_ret = m_properties[l_it->second];
		if ( m_dumpMode )
		{
			l_logmsg.str( "" );
			l_logmsg << MSG_CONFIGBASE_0005 << "[" << l_ret.value( ) 
			<< "]";
			l_logger.print( logger::LEVEL_DEBUG, l_logmsg.str( ).c_str( ) );
		}
		return l_ret;
	}
	const std::string& Tag::name( ) const
	{
		return m_name;
	}
	const std::string& Tag::sourceId( ) const
	{
		return m_sourceId;
	}
	Tag& Tag::clear( )
	{
		m_tags.clear( );
		m_properties.clear( );
		m_tagsIndex.clear( );
		m_propertiesIndex.clear( );
		return *this;
	}
}//namespace configBase

