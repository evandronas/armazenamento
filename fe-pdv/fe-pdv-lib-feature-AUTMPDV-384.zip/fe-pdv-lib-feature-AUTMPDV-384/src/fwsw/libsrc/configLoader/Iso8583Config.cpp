/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/                     2013, 19 DE marco, t694017 acrescimo do atributo l_sizeMultiplier
/                     para ajuste do tamanho do Hex 
/                     2016, 14 de junho, t696193, Andre Morishita, Projeto CF160391 Correcao 
/                     dos BTs de Inspecao de Codigo
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "configBase/TagList.hpp"
#include "configLoader/Iso8583Config.hpp"

namespace configLoader
{
	Iso8583Config::Iso8583Config( )
	{
	}
	Iso8583Config::~Iso8583Config( )
	{
	}
	msgConv::DataCoding Iso8583Config::getDataType( const std::string& a_type )
	{
		msgConv::DataCoding l_DataTypeEnum;
		
		if ( !a_type.compare( "ASCII" ) )
			l_DataTypeEnum = msgConv::ASCII;
		else if ( !a_type.compare( "EBCDIC" ) )
			l_DataTypeEnum = msgConv::EBCDIC;
		else if ( !a_type.compare( "EBCDIC_UNICODE" ) )
			l_DataTypeEnum = msgConv::EBCDIC_UNICODE;
		else if ( !a_type.compare( "HEX" ) )
			l_DataTypeEnum = msgConv::HEX;
		else if ( !a_type.compare( "BCD" ) )
			l_DataTypeEnum = msgConv::BCD;
		else if ( !a_type.compare( "RAW" ) )
			l_DataTypeEnum = msgConv::RAW;
			
		return l_DataTypeEnum;
	}
	bool Iso8583Config::load( msgConv::Iso8583Properties& a_iso8583Properties, 
	                          const configBase::Tag& a_tag )
	{
		unsigned int l_headerSize = atoi( a_tag.findProperty( "headerSize" ).value( ).c_str( ) );
		msgConv::DataCoding l_headerDataType = getDataType( a_tag.findProperty( "headerDataType" ).value( ) );
		msgConv::DataCoding l_messageTypeDataType = getDataType( a_tag.findProperty( "messageTypeDataType" ).value( ) );
		msgConv::DataCoding l_bitmapDataType = getDataType( a_tag.findProperty( "bitmapDataType" ).value( ) );		
		
		std::string aux = a_tag.findPropertyNotRequired("envSource").value();
		
		if (!aux.empty()) {
			std::string l_envSource = a_tag.findPropertyNotRequired("envSource").value().c_str();
			a_iso8583Properties.setEnvSource(l_envSource);
		}
		
		a_iso8583Properties.setHeaderSize( l_headerSize );
		a_iso8583Properties.setHeaderDataType( l_headerDataType );
		a_iso8583Properties.setMessageTypeDataType( l_messageTypeDataType );
		a_iso8583Properties.setBitmapDataType( l_bitmapDataType );

		configBase::TagList l_tagDataElement;

		a_tag.findTag( "dataElement", l_tagDataElement );

		for ( unsigned short l_tag = 0;l_tag < l_tagDataElement.size( ); l_tag++ )
		{
			unsigned int l_deNumber = atoi( l_tagDataElement[l_tag].findProperty( "deNumber" ).value( ).c_str( ) );

			msgConv::DataCoding l_dataType = getDataType( l_tagDataElement[l_tag].findProperty( "dataType" ).value( ) );

			bool l_isLvar = !l_tagDataElement[l_tag].findProperty( "isLVar" ).value( ).compare( "TRUE" )? true : false;

			msgConv::DataCoding l_lvarDataType = getDataType( l_tagDataElement[l_tag].findProperty( "lvarDataType" ).value( ) );

			unsigned int l_size = atoi( l_tagDataElement[l_tag].findProperty( "size" ).value( ).c_str( ) );

			a_iso8583Properties.dataElementsProperties( l_deNumber ).SetValid( true );
			a_iso8583Properties.dataElementsProperties( l_deNumber ).setDataType( l_dataType );
			a_iso8583Properties.dataElementsProperties( l_deNumber ).enableLVar( l_isLvar );
			a_iso8583Properties.dataElementsProperties( l_deNumber ).setLVarDataType( l_lvarDataType );
			a_iso8583Properties.dataElementsProperties( l_deNumber ).setDataElementSize( l_size );
		}
		return true;
	}
}//namespace configLoader

