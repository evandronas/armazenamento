/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/					  Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include <cstdlib>
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "configLoader/DataManipConfig.hpp"
#include "dataManip/Always.hpp"
#include "dataManip/Call.hpp"
#include "dataManip/ConditionalBlock.hpp"
#include "dataManip/SwitchCase.hpp"
#include "logMsg/MessageTable.hpp"
#include "logger/LoggerGen.hpp"
#include "pluginManager/ObjectInterface.hpp"

namespace configLoader
{
	DataManipConfig::DataManipConfig( size_t a_depth )
	{
		m_pluginManager = 0;
		m_depth = a_depth;
		m_logger = 0;
		base::genAssert( m_depth < 13, __FUNCTION__, "Too many levels" );
	}
	DataManipConfig::~DataManipConfig( )
	{
	}
	size_t DataManipConfig::depth( ) const
	{
		return m_depth;
	}
	bool DataManipConfig::loadCommands( dataManip::DataManip& a_dataManip, 
	                                    const configBase::TagList& a_tag, 
										const fieldSet::FieldNavigator& 
										a_fieldNavigator )
	{
		char l_logMessage[1024];
		for ( unsigned int l_commInd = 0; 
		      l_commInd < a_tag.size( ); ++l_commInd )
		{
			const configBase::Tag& l_cmdTag = a_tag[l_commInd];
			std::string l_cmdRefLabel = l_cmdTag.findProperty( "label" ).value( );
			std::string l_cmdRefObject = l_cmdTag.findProperty( "objectReferenceLabel" ).value( );
			
			//snprintf( l_logMessage, sizeof l_logMessage, "%s command %s %s", MSG_DATAMANIPCONFIG_0001, l_cmdRefObject.c_str(), l_cmdRefLabel.c_str() );
			//m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
			
			configBase::TagList l_whenTag;
			dataManip::WhenClause* l_when = 0;
			bool l_specificWhen = 
			l_cmdTag.findTagNotRequired( "when", l_whenTag );
			if ( l_specificWhen )
			{
				std::string l_whenRefObject;
				l_whenRefObject = 
				l_whenTag.front( ).findProperty( 
				"objectReferenceLabel" ).value( );
				pluginManager::ObjectInterface<dataManip::WhenClause> 
				l_whenObjInterface( m_pluginManager );
				l_when = l_whenObjInterface.create( l_whenRefObject );
				const configBase::Tag& l_selWhen = l_whenTag.front( );
				l_when->setLabel( l_cmdRefLabel );
				l_when->setFieldNavigator( a_fieldNavigator );
				bool l_startRet = l_when->startConfiguration( &l_selWhen );
				if ( l_when->warningOn( ) )
				{
					std::ostringstream l_logMsg;
					l_logMsg
					<< MSG_DATAMANIP_0002
					<< l_when->warningMessage( ) 
					<< " - in when clause in command<"
					<< l_cmdRefLabel
					<< "> at datamanip <"
					<< a_dataManip.label( ) << ">";
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_WARNING, l_logMsg.str( ).c_str( ) );
				}
				if ( l_when->errorOn( ) )
				{
					std::ostringstream l_logMsg;
					l_logMsg
					<< MSG_DATAMANIP_0002
					<< l_when->errorMessage( ) 
					<< " - in when clause in command <"
					<< l_cmdRefLabel
					<< "> at datamanip <"
					<< a_dataManip.label( ) << ">";
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_ERROR, l_logMsg.str( ).c_str( ) );
				}
				base::genAssert( l_startRet, __FUNCTION__, 
				"Invalid when clause in command<" + l_cmdRefLabel + ">" );
			}
			else
			{
				l_when = new dataManip::Always;
				l_when->setLabel( l_cmdRefLabel );
				l_when->setFieldNavigator( a_fieldNavigator );
			}
			bool l_enableStop = true;
			pluginManager::ObjectInterface<dataManip::Command> 
			l_commandObjInterface( m_pluginManager );
			dataManip::Command* l_command = 
			l_commandObjInterface.create( l_cmdRefObject );
			l_command->setLabel( l_cmdTag.findProperty( "label" ).value() );
			bool l_startRet = l_command->startConfiguration( &l_cmdTag );
			if ( l_command->warningOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_command->warningMessage( ) << " - in command <"
				<< l_command->label( ) << "> at datamanip <"
				<< a_dataManip.label( ) << ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_WARNING, l_logMsg.str( ).c_str( ) );
			}
			if ( l_command->errorOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_command->errorMessage( ) << " - in command <"
				<< l_command->label( ) << "> at datamanip <"
				<< a_dataManip.label( ) << ">";
				logger::LoggerGen::getInstance( )->print( logger::LEVEL_ERROR,
				l_logMsg.str( ).c_str( ) );
			}
			base::genAssert( l_startRet, __FUNCTION__, "Invalid command <" 
			                 + l_command->label( ) + ">" );
			
			l_command->setFieldNavigator( a_fieldNavigator );
			l_command->setPluginManager( m_pluginManager );
			l_command->setLabel( l_cmdRefLabel );
			
			unsigned int l_seq = l_cmdTag.sequence( );
			a_dataManip.addCommand( l_seq, l_command, l_when, l_enableStop );
		}
		return true;
	}
	bool DataManipConfig::loadSwitches( dataManip::DataManip& a_dataManip, 
	                                    const configBase::TagList& a_tag, 
										const fieldSet::FieldNavigator& 
										a_fieldNavigator )
	{
		char l_logMessage[1024];
		for ( unsigned int l_switchInd = 0;
		      l_switchInd < a_tag.size( ); ++l_switchInd )
		{
			const configBase::Tag& l_switchTag	= a_tag[l_switchInd];
			std::string l_switchRefLabel = l_switchTag.findProperty( "label" ).value( );
			
			//snprintf( l_logMessage, sizeof l_logMessage, "%s switch %s", MSG_DATAMANIPCONFIG_0001, l_switchRefLabel.c_str() );
			//m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
			
			configBase::TagList l_whenTag;
			dataManip::WhenClause* l_when = 0;
			bool l_specificWhen = l_switchTag.findTagNotRequired( "when",
			                                                      l_whenTag );
			if ( l_specificWhen )
			{
				std::string l_whenRefObject;
				l_whenRefObject = 
				l_whenTag.front( ).findProperty( 
				"objectReferenceLabel" ).value( );
				pluginManager::ObjectInterface<dataManip::WhenClause> 
				l_whenObjInterface( m_pluginManager );
				l_when = l_whenObjInterface.create( l_whenRefObject );
				configBase::Tag l_whenSelTag = l_whenTag.front( );
				l_when->setLabel( l_switchRefLabel );
				l_when->setFieldNavigator( a_fieldNavigator );
				bool l_startRet = l_when->startConfiguration( &l_whenSelTag );
				if ( l_when->warningOn( ) )
				{
					std::ostringstream l_logMsg;
					l_logMsg
					<< MSG_DATAMANIP_0002
					<< l_when->warningMessage( ) 
					<< " - in when clause in switch <"
					<< l_switchRefLabel
					<< "> at datamanip <"
					<< a_dataManip.label( ) << ">";
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_WARNING, l_logMsg.str( ).c_str( ) );
				}
				if ( l_when->errorOn( ) )
				{
					std::ostringstream l_logMsg;
					l_logMsg
					<< MSG_DATAMANIP_0002
					<< l_when->errorMessage( ) 
					<< " - in when clause in switch <"
					<< l_switchRefLabel
					<< "> at datamanip <"
					<< a_dataManip.label( ) << ">";
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_ERROR, l_logMsg.str( ).c_str( ) );
				}
				base::genAssert( l_startRet, __FUNCTION__,
				"Invalid when clause in SwitchCase <" + l_switchRefLabel + ">" 
				);
			}
			else
			{
				l_when = new dataManip::Always;
				l_when->setLabel( l_switchRefLabel );
				l_when->setFieldNavigator( a_fieldNavigator );
			}
			bool l_enableStop = true;
			dataManip::Command* l_command = new dataManip::SwitchCase;
			l_command->setFieldNavigator( a_fieldNavigator );
			l_command->setPluginManager( m_pluginManager );
			l_command->setLabel( l_switchRefLabel );
			base::genAssert( l_command->startConfiguration( &l_switchTag ),
             			     __FUNCTION__, "Invalid SwitchCase <" 
							 + l_switchRefLabel + ">" );
			unsigned int l_seq = l_switchTag.sequence( );
			a_dataManip.addCommand( l_seq, l_command, l_when, l_enableStop );
		}
		return true;
	}
	bool DataManipConfig::loadBlocks( dataManip::DataManip& a_dataManip, 
	                                  const configBase::TagList& a_tag, 
									  const fieldSet::FieldNavigator& 
									  a_fieldNavigator )
	{
		char l_logMessage[1024];
		for ( unsigned int l_condInd = 0;
        	  l_condInd < a_tag.size( ); ++l_condInd )
		{
			const configBase::Tag& l_condTag = a_tag[l_condInd];
			std::string l_condRefLabel = l_condTag.findProperty( "label" ).value( );
			
			//snprintf( l_logMessage, sizeof l_logMessage, "%s Block %s - START", MSG_DATAMANIPCONFIG_0001, l_condRefLabel.c_str() );
			//m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
			
			configBase::TagList l_whenTag;
			dataManip::WhenClause* l_when = new dataManip::Always;
			l_when->setFieldNavigator( a_fieldNavigator );
			l_when->setLabel( l_condRefLabel );
			bool l_enableStop = true;
			dataManip::Command* l_command = new dataManip::ConditionalBlock( m_depth );
			l_command->setFieldNavigator( a_fieldNavigator );
			l_command->setPluginManager( m_pluginManager );
			l_command->setLabel( l_condRefLabel );
			bool l_startRet = l_command->startConfiguration( &l_condTag );
			if ( l_command->warningOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_command->warningMessage( ) << " - <"
				<< l_command->label( ) << "> at datamanip <"
				<< a_dataManip.label( ) << ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_WARNING, l_logMsg.str( ).c_str( ) );
			}
			if ( l_command->errorOn( ) )
			{
				std::ostringstream l_logMsg;
				l_logMsg
				<< MSG_DATAMANIP_0002
				<< l_command->errorMessage( ) << " - label <"
				<< l_command->label( ) << "> at datamanip <"
				<< a_dataManip.label( ) << ">";
				logger::LoggerGen::getInstance( )->print( 
				logger::LEVEL_ERROR, l_logMsg.str( ).c_str( ) );
			}
			base::genAssert( l_startRet, __FUNCTION__, "Invalid command <" 
			                 + l_command->label( ) + ">" );
			
			unsigned int l_seq = l_condTag.sequence( );
			a_dataManip.addCommand( l_seq, l_command, l_when, l_enableStop );
			
			//snprintf( l_logMessage, sizeof l_logMessage, "%s Block %s - END", MSG_DATAMANIPCONFIG_0001, l_condRefLabel.c_str() );
			//m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
		}
		return true;
	}
	bool DataManipConfig::loadCalls( dataManip::DataManip& a_dataManip, 
	                                 const configBase::TagList& a_tag, 
									 const fieldSet::FieldNavigator& 
									 a_fieldNavigator )
	{
		char l_logMessage[1024];
		for ( unsigned int l_callInd = 0; 
		      l_callInd < a_tag.size( ); ++l_callInd )
		{
			const configBase::Tag& l_callTag			= a_tag[l_callInd];
			std::string l_callRefLabel	= 
			l_callTag.findProperty( "label" ).value( );
			
			//snprintf( l_logMessage, sizeof l_logMessage, "%s CALL %s - START", MSG_DATAMANIPCONFIG_0001, l_callRefLabel.c_str() );
			//m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
			
			configBase::TagList l_whenTag;
			dataManip::WhenClause* l_when = 0;
			bool l_specificWhen = 
			l_callTag.findTagNotRequired( "when", l_whenTag );
			if ( l_specificWhen )
			{
				std::string l_whenRefObject;
				l_whenRefObject = 
				l_whenTag.front( ).findProperty( 
				"objectReferenceLabel" ).value( );
				pluginManager::ObjectInterface<dataManip::WhenClause> 
				l_whenObjInterface( m_pluginManager );
				l_when = l_whenObjInterface.create( l_whenRefObject );
				const configBase::Tag& l_selWhen =  l_whenTag.front( );
				l_when->setLabel( l_callRefLabel );
				l_when->setFieldNavigator( a_fieldNavigator );
				bool l_startRet = l_when->startConfiguration( &l_selWhen );
				if ( l_when->warningOn( ) )
				{
					std::ostringstream l_logMsg;
					l_logMsg
					<< MSG_DATAMANIP_0002
					<< l_when->warningMessage( ) 
					<< " - in when clause in call <"
					<< l_callRefLabel
					<< "> at datamanip <"
					<< a_dataManip.label( ) << ">";
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_WARNING, l_logMsg.str( ).c_str( ) );
				}
				if ( l_when->errorOn( ) )
				{
					std::ostringstream l_logMsg;
					l_logMsg
					<< MSG_DATAMANIP_0002
					<< l_when->errorMessage( ) << " - in when clause in call <"
					<< l_callRefLabel
					<< "> at datamanip <"
					<< a_dataManip.label( ) << ">";
					logger::LoggerGen::getInstance( )->print( 
					logger::LEVEL_ERROR, l_logMsg.str( ).c_str( ) );
				}
				base::genAssert( l_startRet, __FUNCTION__, 
				                 "Invalid when clause in call <"
								 + l_callRefLabel + ">" );
			}
			else
			{
				l_when = new dataManip::Always;
				l_when->setFieldNavigator( a_fieldNavigator );
				l_when->setLabel( l_callRefLabel );
			}
			bool l_enableStop = true;
			dataManip::Command* l_command = new dataManip::Call( m_depth );
			l_command->setFieldNavigator( a_fieldNavigator );
			l_command->setPluginManager( m_pluginManager );
			l_command->setLabel( l_callRefLabel );
			base::genAssert( l_command->startConfiguration( &l_callTag ),
           			         __FUNCTION__, "Invalid call <" 
							 + l_callRefLabel + ">" );
			unsigned int l_seq = l_callTag.sequence( );
			a_dataManip.addCommand( l_seq, l_command, l_when, l_enableStop );
			
			//snprintf( l_logMessage, sizeof l_logMessage, "%s CALL %s - END", MSG_DATAMANIPCONFIG_0001, l_callRefLabel.c_str() );
			//m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
		}

		return true;
	}
	bool DataManipConfig::load( dataManip::DataManip& a_dataManip, 
	                            const configBase::Tag& a_tag )
	{
		base::genAssertPtr( m_pluginManager, __FUNCTION__,
		                    "PluginManager not defined" );
		m_logger = logger::LoggerGen::getInstance( );
		
		configBase::Property l_propLabel = a_tag.findPropertyNotRequired( "label" );
		std::string l_dataManipLabel = l_propLabel.isValid( ) ? l_propLabel.value( ) : a_tag.name( );
		a_dataManip.setLabel( l_dataManipLabel );
		char l_logMessage[1024];
		//snprintf( l_logMessage, sizeof l_logMessage, "%sDatamanip %s - START", MSG_DATAMANIPCONFIG_0001, l_dataManipLabel.c_str() );
		//m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
				
		fieldSet::FieldNavigator l_fieldNavigator = m_fieldNavigator;
		logger::LoggerGen::getInstance( )->init( );
		configBase::TagList l_fieldSetReferenceTag;
		configBase::TagList l_commandsTag;
		configBase::TagList l_switchesTag;
		configBase::TagList l_conditionalBlocksTag;
		configBase::TagList l_callTag;
		configBase::TagList l_declareTag;
		a_tag.findTagNotRequired( "declare", l_declareTag );
		a_tag.findTagNotRequired( "fieldSetReference", l_fieldSetReferenceTag );
		a_tag.findTagNotRequired( "command", l_commandsTag );
		a_tag.findTagNotRequired( "switch", l_switchesTag );
		a_tag.findTagNotRequired( "conditional-block", l_conditionalBlocksTag );
		a_tag.findTagNotRequired( "call", l_callTag );
		
		fieldSet::Field& l_parent = a_dataManip.localFields( );
		
		for ( unsigned int l_declareInd = 0; 
		      l_declareInd < l_declareTag.size( ); ++l_declareInd )
		{
			std::string l_label = l_declareTag[l_declareInd].findProperty( "label" ).value( );
		
			fieldSet::FieldSet l_newLocal;
			l_newLocal.setLabel( l_label );
			configBase::TagList l_fields;
			l_declareTag[l_declareInd].findTagNotRequired( "field", l_fields );
			for ( unsigned int l_fieldsInd = 0; l_fieldsInd < l_fields.size( ); ++l_fieldsInd )
			{
				std::string l_newFieldLabel = l_fields[l_fieldsInd].findProperty( "label" ).value( );
				
				const configBase::Property& l_propFieldValue = l_fields[l_fieldsInd].findPropertyNotRequired( "value" );
				std::string l_newFieldValue = l_propFieldValue.isValid( ) ? l_propFieldValue.value( ) : "";
				
				const configBase::Property& l_propFieldMask = l_fields[l_fieldsInd].findPropertyNotRequired( "mask" );
				std::string l_newFieldMask = l_propFieldMask.isValid( ) ? l_propFieldMask.value( ) : "";
				
				fieldSet::Field l_newField( l_newFieldLabel.c_str( ) );
				l_newField.inputDefault( l_newFieldValue );
				l_newField.setMask( l_newFieldMask );
				l_newField.clearData( );
				l_newLocal.addField( l_newField );
			}
			l_parent.addField( l_newLocal );
			bool l_addNavRet =
			l_fieldNavigator.addField( l_label, 
			                           l_parent.find( l_label ).ptr( ) );
			base::genAssert( l_addNavRet, __FUNCTION__, 
			                 "Invalid path in declare <" + l_label + ">" );
		}
		for ( unsigned int l_refInd = 0;
              l_refInd < l_fieldSetReferenceTag.size( ); ++l_refInd )
		{
			std::string l_reference = 
			l_fieldSetReferenceTag[l_refInd].findProperty( 
			"reference" ).value( );
			std::string l_alias = 
			l_fieldSetReferenceTag[l_refInd].findProperty( "alias" ).value( );
			fieldSet::Field& l_fieldRef = 
			l_fieldNavigator.navigate( l_reference );
			bool l_addNavRet = 
			l_fieldNavigator.addField( l_alias, l_fieldRef.ptr( ) );
			base::genAssert( l_addNavRet, __FUNCTION__, 
			                 "Invalid path in fieldSetReference <" 
							 + l_reference + ">" );
		}
		a_dataManip.setFieldNavigator( l_fieldNavigator );
		//////////////// COMMANDS
		if ( !loadCommands( a_dataManip, l_commandsTag, l_fieldNavigator ) )
		{
			return false;
		}
		//////////////// SWITCHES
		if ( !loadSwitches( a_dataManip, l_switchesTag, l_fieldNavigator ) )
		{
			return false;
		}
		//////////////// BLOCKS
		if ( !loadBlocks( a_dataManip, l_conditionalBlocksTag,
		                  l_fieldNavigator ) )
		{
			return false;
		}
		//////////////// CALLS
		if ( !loadCalls( a_dataManip, l_callTag, l_fieldNavigator ) )
		{
			return false;
		}
		
		//snprintf( l_logMessage, sizeof l_logMessage, "%sDatamanip %s - END", MSG_DATAMANIPCONFIG_0001, l_dataManipLabel.c_str() );
		//m_logger->print( logger::LEVEL_DEBUG, l_logMessage );
		return true;
	}
	DataManipConfig& DataManipConfig::setPluginManager( 
	    const pluginManager::PluginManager* a_pluginManager )
	{
		m_pluginManager = a_pluginManager;
		return *this;
	}
	DataManipConfig& DataManipConfig::setFieldNavigator( 
	    const fieldSet::FieldNavigator& a_fieldNavigator )
	{
		m_fieldNavigator = a_fieldNavigator;
		return *this;
	}
}//namespace configLoader

