/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "configBase/TagList.hpp"
#include "configLoader/FieldSetConfig.hpp"

namespace configLoader
{
	FieldSetConfig::FieldSetConfig( )
	{
	}
	FieldSetConfig::~FieldSetConfig( )
	{
	}
	bool FieldSetConfig::load( fieldSet::FieldSet& a_fieldSet, 
	                           const configBase::Tag& a_tag )
	{
		std::string l_label = a_tag.findProperty( "label" ).value( );
		a_fieldSet.setLabel( l_label );
		configBase::TagList l_tagFields;
		a_tag.findTag( "field", l_tagFields );
		for ( unsigned int l_i = 0; l_i < l_tagFields.size( ); ++l_i )
		{
			std::string l_fieldLabel = 
			l_tagFields[l_i].findProperty( "label" ).value( );
			configBase::TagList l_tag;
			l_tagFields[l_i].findTag( "type", l_tag );
			std::string l_type = 
			l_tag.front( ).findProperty( "value" ).value( );
			if ( l_type == "composite" )
			{
				fieldSet::FieldSet l_newSubFieldSet;
				this->load( l_newSubFieldSet, l_tagFields[l_i] );
				a_fieldSet.addField( l_newSubFieldSet );
			}
			else
			{
				fieldSet::Field l_newField( l_fieldLabel.c_str( ) );
				if ( !this->loadField( l_newField, l_tagFields[l_i] ) )
				{
					return false;
				}
				a_fieldSet.addField( l_newField );
			}
		}
		return true;
	}
	bool FieldSetConfig::loadField( fieldSet::Field& a_field, 
	                                const configBase::Tag& a_tag )
	{
		configBase::TagList l_tag;
		a_tag.findTag( "mask", l_tag );
		std::string l_mask = l_tag.front( ).findProperty( "value" ).value( );
		a_tag.findTag( "securityMask", l_tag );
		std::string l_securityMask = 
		l_tag.front( ).findProperty( "value" ).value( );
		a_tag.findTag( "isOn", l_tag );
		std::string l_isOn = l_tag.front( ).findProperty( "value" ).value( );
		a_tag.findTag( "isSecure", l_tag );
		std::string l_isSecure = 
		l_tag.front( ).findProperty( "value" ).value( );
		a_field.setMask( l_mask );
		a_field.setSecurityMask( l_securityMask );
		a_field.setSecure( l_isSecure == "true" );
		if ( l_isOn == "true" )
		{
			a_field.turnOn( );
		}
		else
		{
			a_field.turnOff( );
		}
		return true;
	}
}//namespace configLoader
