/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "configBase/TagList.hpp"
#include "configLoader/PluginManagerConfig.hpp"

namespace configLoader
{
	PluginManagerConfig::PluginManagerConfig( )
	{
	}
	PluginManagerConfig::~PluginManagerConfig( )
	{
	}
	const std::string& PluginManagerConfig::errorMessage( ) const
	{
		return m_errorMessage;
	}
	bool PluginManagerConfig::load( pluginManager::PluginManager& 
	                                a_pluginManager, 
									const configBase::Tag& a_tag )
	{
		configBase::TagList l_tagPlugins;
		a_tag.findTag( "plugin", l_tagPlugins );
		m_errorMessage = "no error";
		for ( unsigned int l_i = 0; l_i < l_tagPlugins.size( ); l_i++ )
		{
			std::string l_pluginLabel = 
			l_tagPlugins[l_i].findProperty( "label" ).value( );
			std::string l_pluginLibrary = 
			l_tagPlugins[l_i].findProperty( "libraryReferenceLabel" ).value( );
			std::string l_libraryFuncCreatName = 
			l_tagPlugins[l_i].findProperty( "creatorFunctionName" ).value( );
			if ( !a_pluginManager.addPluginInterface( l_pluginLabel, 
			                                          l_pluginLibrary, 
													  l_libraryFuncCreatName ) )
			{
				m_errorMessage =
				"Duplicated label <" +
				l_pluginLabel +
				"> while including plugin at lib <" + l_pluginLibrary +
				"> with creator <" + l_libraryFuncCreatName + ">";
				return false;
			}
		}
		return true;
	}
}//namespace configLoader

