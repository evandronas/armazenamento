/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ ------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior,
/                     Versao Inicial
/                     2012, 13 de agosto, t689687, Felipe Bruno da Silva Bezerra
/                     Corrigindo padr�o para 80 caracteres por linha
/ ------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "configLoader/LibrarianConfig.hpp"
#include "pluginManager/Librarian.hpp"

namespace configLoader
{
	LibrarianConfig::LibrarianConfig( )
	{
	}
	LibrarianConfig::~LibrarianConfig( )
	{
	}
	const std::string& LibrarianConfig::errorMessage( ) const
	{
		return m_errorMessage;
	}
	bool LibrarianConfig::load( const configBase::Tag& a_tag )
	{
		pluginManager::Librarian* l_librarian = 
		pluginManager::Librarian::getInstance( );
		configBase::TagList l_tagLibraries;
		a_tag.findTag( "library", l_tagLibraries );
		m_errorMessage = "no error";
		for ( unsigned int l_i = 0; l_i < l_tagLibraries.size( ); l_i++ )
		{
			std::string l_libraryLabel = 
			l_tagLibraries[l_i].findProperty( "label" ).value( );
			std::string l_libraryPath = 
			l_tagLibraries[l_i].findProperty( "path" ).value( );
			std::string l_libraryFileName = 
			l_tagLibraries[l_i].findProperty( "fileName" ).value( );
			if ( !l_librarian->addLibrary( l_libraryLabel, 
			                               l_libraryPath, l_libraryFileName ) )
			{
				m_errorMessage =
				"Duplicated label <" +
				l_libraryLabel +
				"> while including library <" + l_libraryPath + "/" 
				+ l_libraryFileName + ">";
				return false;
			}
		}
		return true;
	}
}//namespace configLoader

