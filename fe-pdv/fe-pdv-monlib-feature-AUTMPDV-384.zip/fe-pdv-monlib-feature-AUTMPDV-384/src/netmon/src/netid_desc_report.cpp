/*
 *     This source defines function 'netid_desc_report' that generates data 
 *     about transactions. 
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  22/05/2012  Initial version. (ID_18916)
 *	696248	04/09/2012	Altera��o na forma de obten��o do valor para a
 *                      variavel 'general_timestamp'.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

/* Includes da aplicacao */

#include <netmon.h>
 
void netid_desc_report(struct mon_param monitor_param)
{

	time_t now;
	struct tm  ts;
	char report[255 + 1];						/* montagem da linha do report */
	char report_timestamp[15 + 1];				/* AAAAMMDD;HHMMSS */
	char local_report_timestamp[15 + 1];		/* AAAAMMDD_HHMMSS */
	char hour_reportpath[255 + 1];
	char hour_report_filename[29 + 1];
	char front_end[4 + 1];						/* Site em execucao. */
	FILE * hrF;									/* Ponteiro para arquivo. */
	int count = 0;								/* Contador local. */

	memset(report, '\0', sizeof(report));
	memset(report_timestamp, '\0', sizeof(report_timestamp));
	memset(local_report_timestamp, '\0', sizeof(local_report_timestamp));
	memset(hour_reportpath, '\0', sizeof(hour_reportpath));
	memset(hour_report_filename, '\0', sizeof(hour_report_filename));
	memset(front_end, '\0', sizeof(front_end));	

	/* Obtem FE */
	sprintf(front_end, "%s", getenv("SITE"));

	/* time stamp */
	now=time(NULL);
	ts = *localtime(&now);
	strftime(local_report_timestamp, sizeof(local_report_timestamp), "%Y%m%d_%H%M%S", &ts);
	strftime(report_timestamp, sizeof(report_timestamp), "%Y%m%d;%H%M%S", &ts);

	/* Monta nome/caminho do arquivo. */
	sprintf(hour_report_filename, "%s_NetIdDesc.txt", local_report_timestamp);
	sprintf(hour_reportpath,"%s/%s/%s", monitor_param.path_report, front_end, hour_report_filename);

	/* Carga de estrutura de Networkid's*/
	ODebug("Iniciando carga da tabela de redes.\n");
	if ( network_table_create(net_table_list, front_end, &net_reg_count) != DBME_EOF )
	{
		ODebug("Erro de execucao da funcao network_table_create. Nao sera poss�vel monitorar redes.\n");
		strcpy(net_table_list[net_reg_count].network_id, "BD_ERR");
		strcpy(net_table_list[net_reg_count].network_name, "BD_ERR");
	}
	else
	{
		ODebug("Foram obtidos %d registro(s) de rede para o FE %s.\n", net_reg_count + 1, front_end);	
		ODebug("Carga da tabela de redes realizada com sucesso.\n");
	}

	/* Geracao/insercao de arquivo horario. */
	if((hrF = fopen(hour_reportpath,"a")) == NULL)
	{
		syslg("M-DES: Erro na geracao ou inclusao de dados no relatorio de inicializacao.\n");	
		ODebug("M-DES: Erro na geracao ou inclusao de dados no relatorio de inicializacao.\n");
	}
	else
	{
		/* La�o de escrita */
		for (count = 0; count <= net_reg_count; count ++)
		{
			/* Monta registro */
			sprintf(report, "%s;%s;%s\n", report_timestamp,
										  net_table_list[count].network_id,
										  net_table_list[count].network_name);
			
			fprintf(hrF, report);
		}
		
		/* Fechamento dos arquivos utilizados. */
		fclose(hrF);
	}
	
	return;
}
