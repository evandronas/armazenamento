static char ver[]="netmon 1.0 22Mai2012";

/*  Nome do programa : Networkid Monitor
 *  Executavel gerado : netmon
 */

/*
 *  This program executes as a deamon. It have this functions:
 *     - Generates networkid's monitoration files getting data from 
 *       Shared Memory. (ID_18916)
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  22/05/2012  Versao inicial cfe ID_18916, RF2, RF7 e RF8.
 *	696248	05/09/2012	Incluida a  funcao 'obtem_timestamp'.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */
 
/* Includes da aplicacao */
#include <netmon.h>

/* Globais */
int sleep_time  = DEFAULT_SLEEP_TIME;
struct mon_param lista_param_monitoracao;

/* Definicao para evitar duplicidade */
int reg_count_shm;
int reg_count_vrt;
int net_reg_count;
struct shm_data shm_data_table[MAX_REG_DATA];
struct shm_data shm_data_table_vertice[MAX_REG_DATA];
struct net_table net_table_list[MAX_BIN_LOCAL];
char errmsg[256];

/* Prototipos */
void init_param();

int main(int argc, char *argv[])
{
	char debfile[80];
	int init_ret = 1;						/* Verifica��o de conex�o com a SHM. */
											/*  = 1 - Conectado com sucesso.     */
											/* != 1 - Falha na conex�o.          */
	
	net_reg_count = 0;                      /* Inicializacao contador registros shcbin */
	reg_count_shm = 0;                      /* Inicializacao contador registros shm - msg */
	reg_count_vrt = 0;                      /* Inicializacao contador registros shm - vertice */

	char ver_dsc[]="netid_desc_report 1.0 22Mai2012";
	char ver_rcn[]="netid_rc_cnt_report 1.0 22Mai2012";
	char ver_cnt[]="netid_cnt_report 1.0 22Mai2012";
	char ver_utl[]="util 1.0 22Mai2012";
	
	memset(&net_table_list, '\0', sizeof(struct net_table) * MAX_BIN);
	memset(&shm_data_table, '\0', sizeof(struct shm_data) * MAX_REG_DATA);
	memset(&shm_data_table_vertice, '\0', sizeof(struct shm_data) * MAX_REG_DATA_VRT);
	memset(&lista_param_monitoracao, '\0', sizeof(struct mon_param));
	memset(errmsg, '\0', sizeof(errmsg));
	
	syslg_setargv0(argv[0]);
	syslg("%s\n", ver);
		
    if (daemon_init() < 0)
    {
        syslg("Erro na inicializacao do modulo.\n");
        exit (1);
    }
	
	catch_all_signals(prog_exit);
	
    sprintf(debfile, "%s.debug",  argv[0]);
    debug_on(debfile);

	ODebug("===========================================\n");
	ODebug("%s\n",ver);
	ODebug("===========================================\n");
	ODebug("%s\n",ver_dsc);
	ODebug("%s\n",ver_rcn);
	ODebug("%s\n",ver_cnt);
	ODebug("%s\n",ver_utl);
	ODebug("===========================================\n");
	ODebug("Number of parameters: %d\n", argc);
	
	/* Carga de parametros. */
	init_param();
	
	/* Inicializa estrutura de estatisticas. */
	
	syslg("N-MON: net_mon - INICIO\n");
	ODebug("===========================================\n");
	ODebug("Processamento - INICIO\n");	
	ODebug("===========================================\n");

	/* Chamada �nica, apenas no in�cio da monitora��o */
	netid_desc_report(lista_param_monitoracao);
	
	/* Laco principal */
	for (;;)
	{
    	/* Conecta a monitora��o � SHM. */
		if( init_ret && NETC_init( errmsg ) != NETC_RET_OK )
		{
			syslg("%s", errmsg);
			ODebug( "Erro na inicializadao da libNETC\n" );
		}
		else
		{
			init_ret = 0;
			mon_system_health();
		}

		/* Dorme */
		sleep(sleep_time);
	}

	syslg("N-MON: net_mon - FIM\n");
	ODebug("===========================================\n");
	ODebug("Processamento - FIM\n");	
	ODebug("===========================================\n");	
	
	prog_exit(0);
}

/**********************************************************
 * void init_param()                                  *
 * Obtem os parametros de configuracao do programa. Caso  *
 * nao sejam localizados tanto o arquivo de configuracao  *
 * qto os parametros, serao utilizados os valores DEFAULT *
 * das variaveis 'basicas' do programa.                   *
 **********************************************************/
void init_param()
{
	
	/* Carga de valores padrao da monitoracao. */
	char cfgpath[64];
	char aux_path_report[255];
	FILE * testFile;			/* Ponteiro para testar arquivo .cfg */
	int testFlag = 0;			/* Flag de teste do arq .cfg		 */
								/* 0 - Falha						 */
								/* 1 - Sucesso						 */
	
	lista_param_monitoracao.day_report = 0;
	sprintf(lista_param_monitoracao.path_report, "%s", "/home/SW/sw_web/mon_flex/");
	
	memset(cfgpath, 0, sizeof(cfgpath));
        sprintf(cfgpath,"%s/cfg/netmon.cfg", getenv("FE_ROOT"));
	
	ODebug("===========================================\n");
	ODebug("INICIO DA CARGA DE CONFIGURACOES.\n");
	ODebug("===========================================\n");	
	syslg("N-MON: Inicio da carga de configuracoes.\n");

	/* Busca os parametros para funcionamento do programa.*/
	/* Visto que o resultado para encontrar/nao encontrar o arquivo ".cfg" */
	/* e o mesmo na utilizacao da funcao cf_openfile, o tratamento abaixo  */
	/* se faz necessario.                                                  */
	testFile = fopen(cfgpath, "r");
	if (testFile != NULL)
	{
		testFlag = 1;
		fclose(testFile);
	}
	else
	{
		testFlag = 0;
	}

	if (testFlag == 0)
	{
	/* Visto que nao foi localizado netmon.cfg, o programa utilizar� os valores padr�o.*/
		
		ODebug("Arquivo de configuracao 'netmon.cfg' nao encontrado. Utilizara valores padrao:\n");
		syslg("N-MON: Arquivo de configuracao 'netmon.cfg' nao encontrado. Utilizara valores padrao:\n");
		
		ODebug("net_mon.sleep_time:            [%d]\n", sleep_time);
		syslg("N-MON: net_mon.sleep_time:            [%d]\n", sleep_time);
		
		ODebug("net_mon.report_path:           [%s]\n", lista_param_monitoracao.path_report);
		syslg("N-MON: net_mon.report_path:           [%s]\n", lista_param_monitoracao.path_report);
		
		ODebug("===========================================\n");
		ODebug("FIM DA CARGA DE CONFIGURACOES.\n");		
		ODebug("===========================================\n");

		/* Nada mais a setar.*/
		return;
	}
	else
	{
		cf_openfile( cfgpath );
		ODebug("Localizado netmon.cfg. Buscando parametros.\n");
		syslg("N-MON: Localizado netmon.cfg. Buscando parametros.\n");
	}	
	
	/* Localizado monFlex.cfg */
	/* Obtendo sleep_time */
	if (cf_locatenum("net_mon.sleep_time", &sleep_time) < 0) 
	{
		ODebug("Parametro 'net_mon.sleep_time' nao encontrado. Utilizando valor padrao.\n");
		syslg("N-MON: Parametro 'net_mon.sleep_time' nao encontrado. Utilizando valor padrao.\n");

		ODebug("net_mon.sleep_time:            [%d]\n", sleep_time);
		syslg("N-MON: net_mon.sleep_time:            [%d]\n", sleep_time);
	}
	else
	{
		ODebug("net_mon.sleep_time:            [%d]\n", sleep_time);
		syslg("N-MON: net_mon.sleep_time:            [%d]\n", sleep_time);
	}

	/* Obtendo report_path */
	if (cf_locate("net_mon.report_path", aux_path_report) > 0)
	{
		memset(&lista_param_monitoracao.path_report, '\0', sizeof(lista_param_monitoracao.path_report));
		sprintf (lista_param_monitoracao.path_report, "%s/%s", getenv("HOME"), aux_path_report);
		
		ODebug("net_mon.report_path:           [%s]\n", lista_param_monitoracao.path_report);
		syslg("N-MON: net_mon.report_path:           [%s]\n", lista_param_monitoracao.path_report);
	}
	else
	{
		ODebug("Nenhuma ocorrencia do parametro 'net_mon.report_path' encontrada. Sera utilizado o valor padrao '%s'.\n", lista_param_monitoracao.path_report);
		syslg("N-MON: Nenhuma ocorrencia do parametro 'net_mon.report_path' encontrada. Sera utilizado o valor padrao '%s'.\n", lista_param_monitoracao.path_report);
		
		ODebug("net_mon.report_path:           [%s]\n", lista_param_monitoracao.path_report);
		syslg("N-MON: net_mon.report_path:           [%s]\n", lista_param_monitoracao.path_report);
	}
		
	ODebug("===========================================\n");
	ODebug("FIM DA CARGA DE CONFIGURACOES.\n");		
	ODebug("===========================================\n");
	
	cf_close();
	
	return;
}

/**********************************************************
 * void mon_system_health()                           *
 * Agrupa as funcoes de monitoracao.                      *
 **********************************************************/
void mon_system_health()
{
	/* Carga de dados */
	shm_data_create();
	obtem_timestamp();
	netid_cnt_report(lista_param_monitoracao);
	netid_rc_cnt_report(lista_param_monitoracao);
}
