//static char ver[]="Util 1.0 05Out2011";

/*  Nome do programa : Funcoes �teis
 *  Executavel gerado : netmon
 */

/*
 *  Contem funcoes genericas para o sistem netmon.
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  05/10/2011  Versao inicial cfe ID18916.
 *	696248	05/09/2012	Incluida a  funcao 'obtem_timestamp'.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

/* Includes da aplicacao */
#include <netmon.h>

static const char *INDEX_NAME = "shcbin_ix";
 
/**********************************************************
 * void prog_exit(int n)                                  *
 * Trata saida do programa.                               *
 **********************************************************/
void prog_exit(int n)
{

    if(n == 0 || n == SIGTERM)
    {
        syslg("N-MON: Saida Normal # %d.\n", n);
        ODebug("Saida Normal # %d.\n", n);
    }  
    else
    {   
        syslg("N-MON: Saida com sinal %d\n", n);
        ODebug("Saida com sinal %d\n", n);
    }  
    
    ODebugOff();

    exit(n);
}

/**********************************************************
 * int daemon_init()                                  *
 * Possibilita que o programa rode como um deamon.        *
 **********************************************************/
int daemon_init()
{
    pid_t  pid;

    if ((pid = fork()) < 0)
        return(-1);
    else if (pid != 0)
        exit(0);

    /* child continues */
    setsid();       /* becames session leader */
    chdir("/");     /* change working directory */
    umask(0);       /* clear our file mode creating mask */

    return(0);
}

/**********************************************************
 * int get_network_fd(int *fd, const char *index)         *
 * Conecta a tabela indica pelo 'index' e retorna o 'fd'  *
 * obtido.                                                *
 **********************************************************/
int get_network_fd(int *fd, const char *index)
{
	if ((*fd = ist_dbm_open(index, 0)) < 0)
	{
		syslg("N-MON: Erro na abertura da conexao com o indice '%s'. dbm_errno [%d].\n", index, dbm_errno);
		ODebug("Erro na abertura da conexao com o indice '%s'. dbm_errno [%d].\n", index, dbm_errno);
		return (dbm_errno);
	}
	else
	{
		syslg("N-MON: Conexao estabelecida com o indice '%s' com fd '%d'.\n", index, *fd);
		ODebug("Conexao estabelecida com o indice '%s' fd '%d'.\n", index, *fd);
		return 0;	
	}
}

/**********************************************************
 * int network_table_create(struct net_table *NetworksTable, char *front_end, int *reg_count)
 * Obtem registros da shcbin, popula o ponteiro e retorna *
 * a quantidade de registros obtida.                      *
 **********************************************************/
int network_table_create(struct net_table *NetworksTable, char *front_end, int *reg_count)
{
    int dbmfd_network = 0;
    int count = 0;
    //char select_stat[26];
    struct shcbindb networkTable_db;
	
    memset(&networkTable_db, '\0', sizeof(struct shcbindb));

    /* Inicializa DBM.*/
    dbm_init();

    /*if(dbm_init() != 0)
    {
	ODebug("N�o foi poss�vel inicializar o dbm.\n");
	return (-1);
    }*/

    /* Conecta ao banco.*/
    if (get_network_fd(&dbmfd_network, INDEX_NAME) != 0)
    {
       return (-1);
    }
	
    ODebug("Obtendo dados da tabela shcbin para o FE %s.\n", front_end);

    if (dbm_selectfd_nolock(dbmfd_network, "") < 0)
    {
        syslg("N-MON: Erro na execucao do select.\n");
	ODebug("Erro na execucao do select.\n");
        return (-1);
    }

	/* Obtem os registros e carrega o ponteiro.*/	
	ODebug("Fazendo o fetch do cursor.\n");

	for (count = 0; count < MAX_BIN_LOCAL; count++)
	{
		if( dbm_fetchfd(dbmfd_network, (char *)&networkTable_db) != 0)
		{
			if( dbm_errno == DBME_NOTFOUND ) /* 111 */
			{
				ODebug("Nao encontrou registros.\n");
				*reg_count = 0;
				return (DBME_NOTFOUND);
			}
			else if ( dbm_errno == DBME_EOF )
			{
				ODebug("Fim dos registros.\n");
				ist_dbm_close(INDEX_NAME, 0, dbmfd_network);
				ODebug("Conexao encerrada.\n");
				*reg_count = count-1;
				return DBME_EOF;
			}
			else
			{
				ODebug("Foi detectado o erro dbm_errno [%d].\n", dbm_errno);
				*reg_count = 0;
				return (dbm_errno);
			}
		}
		else
		{
			/*Atribui dados ao ponteiro e anda uma posi��o.*/
			strcpy(NetworksTable->network_id, networkTable_db.networkid);
			strcpy(NetworksTable->network_name, networkTable_db.bankname);
		
			NetworksTable++;
		}
	}
        return DBME_EOF;
}

/**********************************************************
 * void shm_data_create()                                 *
 * Obtem, via libNETC, registros da SHM, popula estrutura *
 * global e retorna quantidade de registros obtida.       *
 **********************************************************/
void shm_data_create()
{
	/* Carga de dados da SHM */
	memset(errmsg, '\0', sizeof(errmsg));
	//if ( NETC_read_data(shm_data_table, &reg_count_shm, errmsg) < 0)
	if ( NETC_read_data(shm_data_table, &reg_count_shm) < 0)
	{
		//syslg("%s", errmsg);
		syslg("Erro de execucao da funcao shm_get_data. Dados indispon�veis para monitoracao de Networikd.\n");
		ODebug("Erro de execucao da funcao shm_get_data. Dados indispon�veis para monitoracao de Networikd.\n");
	}
	//if ( NETC_read_data_vertice(shm_data_table_vertice, &reg_count_vrt, errmsg) != NETC_RET_OK )
	if ( NETC_read_data_vertice(shm_data_table_vertice, &reg_count_vrt) != NETC_RET_OK )
	{
		//syslg("%s", errmsg);
		syslg("Erro de execucao da funcao shm_get_data_vertice. Dados indispon�veis para monitoracao de Networikd.\n");
		ODebug("Erro de execucao da funcao shm_get_data_vertice. Dados indispon�veis para monitoracao de Networikd.\n");
	}
}

/**********************************************************
 * int obtem_timestamp()                                  *
 * Obtem o valor do arquivo /tmp/timestamp.txt, valida e  *
 * escreve em 'general_timestamp'.                        *
 * Caso arquivo ou valor invalido, utiliza horario local. *
 **********************************************************/
int obtem_timestamp()
{
	
	FILE * timestamp_F;								/* Ponteiro para arquivo de timestamp. */
	char timestamp_filepath[255];
	time_t now;
	struct tm  ts;
	
	/* Timestamp file */
	memset(timestamp_filepath, '\0', sizeof(timestamp_filepath));
	sprintf(timestamp_filepath, "%s%s%s", "/tmp/timestamp_", getenv("SITE"), ".txt");
	
	/* Leitura de arquivo de timestamp. */
	if((timestamp_F = fopen(timestamp_filepath,"r")) == NULL)
	{
		syslg("M-FLX: Erro na abertura de arquivo de timestamp. Ser� utilizado o ultimo valor.\n");	
		ODebug("M-FLX: Erro na abertura de arquivo de timestamp. Ser� utilizado o ultimo valor.\n");
	}
	else
	{
		if (fread(general_timestamp, 1, 15, timestamp_F) != 15)
		{
			syslg("M-FLX: Erro na leitura do arquiv de timestamp. Ser� utilizado o ultimo valor.\n");
			ODebug("M-FLX: Erro na leitura do arquiv de timestamp. Ser� utilizado o ultimo valor.\n");
		}
		else
		{
			fclose(timestamp_F);
			return 0;
		}
		fclose(timestamp_F);
	}
	
	/* time stamp */
	now=time(NULL);
	ts = *localtime(&now);
	strftime(general_timestamp, sizeof(general_timestamp), "%Y%m%d_%H%M%S", &ts);
	return -1;
}
