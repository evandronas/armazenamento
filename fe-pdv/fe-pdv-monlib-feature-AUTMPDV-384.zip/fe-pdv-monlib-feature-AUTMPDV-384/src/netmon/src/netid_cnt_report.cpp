/*
 *     This source defines fuction 'netid_cnt_report' that generates data 
 *     about transactions. 
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  22/05/2012  Vers�o inicial cfe. ID_18916, RF7.
 *	696248	04/09/2012	Altera��o na forma de obten��o do valor para a
 *                      variavel 'general_timestamp'.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

/* Includes da aplicacao */

#include <netmon.h>

/* Definicao para evitar duplicidade */
char general_timestamp[16];

void netid_cnt_report(struct mon_param monitor_param)
{

	/******************************************************************
	 * A vari�vel 'hour_report_filename' assume o seguinte formato:   *
	 *                                                                *
	 * AAAAMMDD_HH_NetIdCnt.txt       -> Relatorio horario de volume  *
	 *                                   de trns.                     *
	 ******************************************************************/
	
	time_t now;
	struct tm  ts;
	char report[255];						/* montagem da linha do report */
	char report_timestamp[16];				/* AAAAMMDD;HHMMSS */
	char hour_reportpath[255];
	char hour_report_filename[30];
	int count = 0;							/* Contador local. */

	FILE * hrF;								/* Ponteiro para arquivo horario. */

	memset(report, '\0', sizeof(report));
	memset(report_timestamp, '\0', sizeof(report_timestamp));
	memset(hour_reportpath, '\0', sizeof(hour_reportpath));
	memset(hour_report_filename, '\0', sizeof(hour_report_filename));
	
	/* Monta linha do relatorio.*/

	/* time stamp */
	now=time(NULL);
	ts = *localtime(&now);
	strftime(report_timestamp, sizeof(report_timestamp), "%Y%m%d;%H%M%S", &ts);

	/* Monta nome/caminho do arquivo. */
	sprintf(hour_report_filename, "%s_NetIdCnt.txt", general_timestamp);
	sprintf(hour_reportpath,"%s/%s/%s", monitor_param.path_report, getenv("SITE"), hour_report_filename);

	/* Geracao/insercao de arquivo horario. */
	if((hrF = fopen(hour_reportpath,"a")) == NULL)
	{
		syslg("M-CNT: Erro na geracao ou inclusao de dados no relatorio horario.\n");	
		ODebug("M-CNT: Erro na geracao ou inclusao de dados no relatorio horario.\n");
	}
	
	for (count = 0; count < reg_count_vrt; count ++)
	{
		/* monta registro */
		sprintf(report, "%s;%s;%s;%ld;%ld;%ld;%ld\n", report_timestamp,
											   shm_data_table_vertice[count].issuer,
											   shm_data_table_vertice[count].acquirer,
											   shm_data_table_vertice[count].qtdeReqRec,
											   shm_data_table_vertice[count].qtdeReqEnv,
											   shm_data_table_vertice[count].qtdeRespRec,
											   shm_data_table_vertice[count].qtdeRespEnv
												);

			fprintf(hrF, report);

	}
	
	/* Fechamento dos arquivos utilizados. */
	fclose(hrF);
	
	return;
}
