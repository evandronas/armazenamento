/*  Nome do programa : netmon.h
 *  Executavel gerado : netmon
 */

/*
 *  Contem definicoes do sistema.
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  22/05/2012  Versao inicial cfe ID_18916, RF2, RF7 e RF8.
 *	696248	05/09/2012	Inclusao da declaracao da funcao 'obtem_timestamp'.
 *                      A variavel 'general_timestamp' tornou-se global.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

#ifndef NETMON_HPP
#define NETMON_HPP

/* Includes do produto*/
#include <syslg.h>
#include <debug.h>
#include <shc.h>
#include <libNETC.h>
 
/* Includes do sistema operacional*/
 
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/msg.h>

/* Funcoes Genericas - util.c */
int is_mailbox_up(void);
void prog_exit(int n);
int daemon_init(void);
int network_table_create(struct net_table *NetworksTable, char *front_end, int *reg_count);
int is_mailbox_up(void);
void shm_data_create(void);
int obtem_timestamp();

/* Funcoes de Monitoracao */
void mon_system_health(void);

void netid_desc_report(struct mon_param);
void netid_cnt_report(struct mon_param);
void netid_rc_cnt_report(struct mon_param);

/* Estruturas */
struct mon_param
{
	int day_report;										/* flag para ativacao do relatorio diario. */
	char path_report[255];								/* raiz do relatorio. */
};

struct net_table{
	char network_id[10 + 1];							/* Network id da rede. */
	char network_name[22 + 1];							/* Network name da rede. */
};

/* Vers�o das funcoes de monitoracao */
//static char ver_dsc[]="netid_desc_report 1.0 22Mai2012";
extern char ver_dsc;
//static char ver_rcn[]="netid_rc_cnt_report 1.0 22Mai2012";
extern char ver_rcn;
//static char ver_cnt[]="netid_cnt_report 1.0 22Mai2012";
extern char ver_cnt;
//static char ver_utl[]="util 1.0 22Mai2012";
extern char ver_utl;


/* Valores padrao do sistema */
#define DEFAULT_SLEEP_TIME                3
#define MAX_REG_DATA				  70000				/* Qtde. maxima de registros comportados no array - msg. */
#define MAX_REG_DATA_VRT              10000				/* Qtde. maxima de registros comportados no array - vertice. */
#define MAX_BIN_LOCAL					350				/* Qtde. maxima de registros da shcbin.*/

/* Variaveis globais*/
extern int reg_count_shm;			             /* Contador de registros da SHM. */
extern int reg_count_vrt;				     /* Contador de registros da SHM. */
extern int net_reg_count;				     /* Contador de registros de rede (shcbin). */
extern struct shm_data shm_data_table[MAX_REG_DATA];	     /* Estrutura utilizada para armazenar registros da SHM - msg. */
extern struct shm_data shm_data_table_vertice[MAX_REG_DATA]; /* Estrutura utilizada para armazenar registros da SHM - vertice. */
extern struct net_table net_table_list[MAX_BIN_LOCAL];       /* Estrutura utilizada para armazenar registros da shcbin */
extern char errmsg[256];			             /* Mensagens de erro provenientes da libNETC. */
extern char general_timestamp[16];                           /* AAAAMMDD_HHMMSS*/

#endif

