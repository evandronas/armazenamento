//static char ver[]="ShmManager 1.0 30Mai2012";

/*
 *  - ShmManager - Gerenciador de Memoria Compartilhada
 *
 *  - Descricao: Disponibiliza rotinas de gerenciamento dos contadores da
 *              monitoracao
 *
 *  Who     When        Why
 *  ========================================================================
 *  686469  30/05/2012  Versao inicial. (ID_16872)
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */

#include "libNETC.h"
#include "ShmManager.h"
#include "time.h"


/*
 * Nome: get_network_fd
 * Descricao: Conecta a tabela indica pelo 'index'
 * Parametros: referencia para o descritor da tabela, 
 *		indice da tabela
 * Retorno: 0 se sucesso, dbm_errno, caso contrario
 */
int get_network_fd(int *fd, const char *index)
{
	if ((*fd = ist_dbm_open(index, 0)) < 0)
	{
		syslg("SHM-M: Erro na abertura da conexao com o indice '%s'. dbm_errno [%d].\n", index, dbm_errno);
		ODebug("Erro na abertura da conexao com o indice '%s'. dbm_errno [%d].\n", index, dbm_errno);
                return (dbm_errno);
        }
        else
        {
		syslg("SHM-M: Conexao estabelecida com o indice '%s' com fd '%d'.\n", index, *fd);
                ODebug("Conexao estabelecida com o indice '%s' fd '%d'.\n", index, *fd);
                return 0;
        }
}

/*
 * Nome: network_table_create
 * Descricao: Obtem registros da shcbin
 * Parametros: referencia para a tabela de networkids, Front-End
 *		referencia para a quantidade de registros
 * Retorno: 0 se sucesso, < 0 caso contrario
 */
int network_table_create(struct shm_net_table *NetworksTable, char *front_end, int *reg_count)
{
	int dbmfd_network = 0;
	int count = 0;
	struct shcbindb networkTable_db;

        memset(&networkTable_db, '\0', sizeof(struct shcbindb));

        /* Inicializa DBM.*/
	dbm_init();

        /* Conecta ao banco.*/
    	if (get_network_fd(&dbmfd_network, INDEX_NAME) != 0)
        	return (-1);

        ODebug("Obtendo dados da tabela shcbin para o FE %s.\n", front_end);

	if (dbm_selectfd_nolock(dbmfd_network, "") < 0)
	{
        	syslg("SHM-M: Erro na execucao do select.\n");
                ODebug("Erro na execucao do select.\n");
	        return (-1);
	}

        /* Obtem os registros e carrega o ponteiro.*/
        for (count = 0; count < MAX_BIN; count++)
        {
                if( dbm_fetchfd(dbmfd_network, (char *)&networkTable_db) != 0)
                {
                        if( dbm_errno == DBME_NOTFOUND ) /* 111 */
                        {
                                ODebug("Nao encontrou registros.\n");
                                *reg_count = 0;
                                return (DBME_NOTFOUND);
                        }
                        else if ( dbm_errno == DBME_EOF )
                        {
                                ist_dbm_close(INDEX_NAME, 0, dbmfd_network);
                                ODebug("Conexao encerrada.\n");
                                *reg_count = count-1;
                                return DBME_EOF;
                        }
                        else
                        {
                                ODebug("Foi detectado o erro dbm_errno [%d].\n", dbm_errno);
                                *reg_count = 0;
                                return (dbm_errno);
                        }
                }
                else
                {
                        /*Atribui dados ao ponteiro e anda uma posi��o.*/
                        strcpy(NetworksTable->network_id, networkTable_db.networkid);

			if( !strlen(NetworksTable->network_id) )
				return -1;

                        NetworksTable++;
                }
        }

	if( *reg_count <= 0 )
	{
		ODebug("Nenhum registro encontrado\n");
		return -1;
	}

	return 0; 
}

/*
 * Nome: init
 * Descricao: Inicializa as configuracoes para a memoria
 * Parametros: Tabela de configuracao, Front-End
 * Retorno: 0 se sucesso, < 0 caso contrario
 */
//int init( stCONFIG_TABLE* cfgTable, char* cFrontEnd )
int init( stCONFIG_TABLE* cfgTable )
{
	ODebug("Lendo configuracoes...\n");

	char buf[2048] = {0};
	//int qtdeNetworkids = 0;
	//int qtdeMtyPcodes = 0;
	//int i = 0;

	char arqCfg[40] = {0};
	sprintf(arqCfg,"%s/cfg/shm_manager.cfg", getenv("FE_ROOT"));

        /* O dbm 'esquece' de fechar o cf_openfile */
        cf_close();


        /* Recupera a lista dos msgtypes/pcodes do FE */
        if( cf_openfile( arqCfg ) < 0 )
        {
                ODebug("Nao foi possivel abrir o arquivo [%s]\n", arqCfg);
                syslg("SHM-M: Nao foi possivel abrir o arquivo [%s]\n", arqCfg);
                return -1;
        }
        else
        {
                if( cf_locate("shm_manager.level_debug", buf) > 0 )
                {
			char level[20] = {0};
			sscanf( buf, "%s", level);
			if( !strcmp(level, "NONE") ) cfgTable->levelDebug = NETC_DEBUG_NONE;
			else if( !strcmp(level, "FATAL") ) cfgTable->levelDebug = NETC_DEBUG_FATAL;
			else if( !strcmp(level, "INFO") ) cfgTable->levelDebug = NETC_DEBUG_INFO;
			else cfgTable->levelDebug = NETC_DEBUG_FATAL;

                        ODebug("LEVEL_DEBUG: %s\n", level );
		}
		else
                {
                        ODebug("Parametro 'shm_manager.level_debug' nao localizado\n");
                        syslg("SHM-M: Parametro 'shm_manager.level_debug' nao localizado\n");
                        return -1;
                }
    	}

    	cf_close();


#if 0
	/* Recupera a lista dos networkids do FE */
	if( network_table_create( cfgTable->networkids, cFrontEnd, &qtdeNetworkids) < 0 )
	{
		ODebug("Erro na carga da shcbin\n");
		syslg("SHM-M: Erro na carga da shcbin\n");
		return -1;
	}

	cfgTable->qtdeNetworkids = qtdeNetworkids;

	for( i = 0; i < qtdeNetworkids; i++ )
		ODebug("NETWORKID[%s]\n", cfgTable->networkids[i].network_id);

	/* O dbm 'esquece' de fechar o cf_openfile */
	cf_close();

		
	/* Recupera a lista dos msgtypes/pcodes do FE */
	if( cf_openfile( arqCfg ) < 0 )
	{
		ODebug("Nao foi possivel abrir o arquivo [%s]\n", arqCfg);
		syslg("SHM-M: Nao foi possivel abrir o arquivo [%s]\n", arqCfg);
		return -1;
	}
	else
	{
		if( cf_locate("shm_manager.mty_pcode", buf) > 0 )
        	{
            		i = 0;
            		qtdeMtyPcodes = 0;
            		do{
                    		sscanf( buf, "%4d %6ld", &cfgTable->msgtypes[ i ], &cfgTable->pcodes[ i ] );

                		if( cfgTable->msgtypes[ i ] || cfgTable->pcodes[ i ] )
                		{
                        		ODebug("MSGTYPE[%04d], PCODE[%06ld]\n", cfgTable->msgtypes[i], cfgTable->pcodes[i]);
                    			qtdeMtyPcodes++;
                    			i++;
                		}
                		else
                		{
                    			ODebug("Parametro 'shm_manager.mty_pcode' nao configurado corretamente\n");
                    			syslg("SHM-M: Parametro 'shm_manager.mty_pcode' nao configurado corretamente\n");
                    			return -1;
                		}
            		}while( qtdeMtyPcodes <= MAX_MSGTYPE_PCODE && cf_nextparm("shm_manager.mty_pcode", buf) > 0 );

            	cfgTable->qtdePcodesMtys = qtdeMtyPcodes;
        	}
        	else
        	{
            		ODebug("Parametro 'shm_manager.mty_pcode' nao localizado\n");
            		syslg("SHM-M: Parametro 'shm_manager.mty_pcode' nao localizado\n");
            		return -1;
        	}
    }

    cf_close();

#endif
	ODebug("Leitura das configuracoes finalizada!\n");

	return 0;
} 

/*
 * Nome: NETC_shm_show
 * Descricao: Mostra o conteudo da SHM
 * Parametros: Ponteiro para a estrutura na SHM
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
int show( char* msgErro )
{
        /* Regra */

        struct shm_data tbl[400];
        memset( &tbl, '\0', 400 * sizeof( struct shm_data ) );

        int count;
	int i;
        //if( NETC_read_data( tbl, &count, msgErro ) != NETC_RET_OK )
        if( NETC_read_data( tbl, &count ) != NETC_RET_OK )
	{
		ODebug( msgErro );
		syslg( msgErro );
		return -1;
	}

	for( i = 0; i < count; i++ ) 
	{

	ODebug("\nISSUER\t\t|ACQUIRER\t|MSGTYPE\t|PCODE\t|QTDE_REQ_REC\t|QTDE_REQ_ENV\t|QTDE_RESP_REC\t|QTDE_RESP_ENV\n%010s\t|%010s\t|%04d\t\t|%06ld\t|%ld\t\t|%ld\t\t|%ld\t\t|%ld\n", tbl[i].issuer, tbl[i].acquirer, tbl[i].msgtype, tbl[i].pcode, tbl[i].qtdeReqRec, tbl[i].qtdeReqEnv, tbl[i].qtdeRespRec, tbl[i].qtdeRespEnv );

	/*
	ODebug("%010s\t|%010s\t|%04d\t|%06ld\t|%ld\t|%ld\t|%ld\t|%ld\n", tbl[i].issuer, tbl[i].acquirer, tbl[i].msgtype, tbl[i].pcode, tbl[i].qtdeReqRec, tbl[i].qtdeReqEnv, tbl[i].qtdeRespRec, tbl[i].qtdeRespEnv );

	*/
	
	ODebug("\n");

	}

#if 0

        int iRetCode = NETC_RET_OK;
        register int i, j, k;

        printf("ID  |ISSUER\t|ACQUIRER\t|QTDE_REC_REC\t|QTDE_REC_ENV\t|QTDE_RESP_REC\t|QTDE_RESP_ENV\n");
        printf("-----------------------------------------------------------------------------------------------\n");
        for( i = 0; i < pNetC->qtdeNetworkids; i++ )
        {
                if( strlen(pNetC->networkids[i].acquirer) )
                {
                printf("%03d |%010s\t|%010s\t|%ld\t\t|%ld\t\t|%ld\t\t|%ld\n", i,
                                pNetC->networkids[i].issuer, pNetC->networkids[i].acquirer,
                                pNetC->networkids[i].contadores[QTDE_REQ_REC], pNetC->networkids[i].contadores[QTDE_REQ_ENV],

                                pNetC->networkids[i].contadores[QTDE_RESP_REC], pNetC->networkids[i].contadores[QTDE_RESP_ENV
]);
                }
        }
        printf("\n");

        printf("ISSUER\t\t|ACQUIRER\t|PCODE\t\t|MSGTYPE\t|RETCODES\n");
        printf("------------------------------------------------------------------------------------------------------------- -----\n");

        int max = pNetC->networkids[ 0 ].qtdeMtyPcode;
        for( i = 0; i < pNetC->qtdeNetworkids; i++ )
        {
                if( strlen(pNetC->networkids[i].acquirer) )
                {
        for( j = 0; j < max; j++ )
        {
                printf("%010s\t|%010s\t|%06ld\t\t|%04d\t\t|", pNetC->networkids[i].issuer, pNetC->networkids[i].acquirer,
                                        pNetC->networkids[i].mty_pcode[j].pcode, pNetC->networkids[i].mty_pcode[j].msgtype );
                        for( k = 0; k < MAX_RETCODES; k++ )
                {
                                int retcode = pNetC->networkids[i].mty_pcode[j].retcodes[k].retcode;
                                long qtde = pNetC->networkids[i].mty_pcode[j].retcodes[k].qtde;
                                if( retcode )
                                {
                                        printf("%02d,", retcode);
                                        printf("%.ld ", qtde);
                                }
                        }
                printf("\n");
        }
        printf("\n");
        }
        }

#endif
        return 1;
}

/*
 * Nome: execute
 * Descricao: Execucao principal das operacoes
 * Parametros: Operacao
 * Retorno: 1
 */
int execute( char operation )
{
	int iRet = 1;
	stCONFIG_TABLE cfgTbl[MAX_BIN];
	memset( &cfgTbl, '\0', sizeof( stCONFIG_TABLE ) * MAX_BIN );

	char msgErro[256];

	switch( operation )
	{
		case 'c':
			ODebug("Criando memoria compartilhada...\n");

			/* Inicializa as configuracoes */
			//if( init( cfgTbl, getenv("SITE") ) < 0 )break;
			if( init( cfgTbl ) < 0 )break;

			cfgTbl->qtdeNetworkids = MAX_NETWORKIDS;
			cfgTbl->qtdePcodesMtys = MAX_MSGTYPE_PCODE;



			/* Cria a memoria compartilhada a partir da tabela de configuracoes */
			if( NETC_create( cfgTbl, msgErro ) != NETC_RET_OK )
			{
				ODebug( msgErro );
				syslg( msgErro );
			}

			ODebug("Memoria compartilhada criada!\n");
			break;
		case 'l':
			ODebug("Limpando memoria compartilhada...\n");

			if( NETC_init( msgErro ) != NETC_RET_OK )
			{
				ODebug( msgErro );
				syslg( msgErro );
			}
			else if( NETC_clear( msgErro ) != NETC_RET_OK )
			{
				ODebug( msgErro );
				syslg( msgErro );
			}

			ODebug("Memoria compartilhada limpa!\n");
			break;
		case 'd':
			ODebug("Removendo memoria compartilhada...\n");

			if( NETC_init( msgErro ) != NETC_RET_OK )
			{
				ODebug( msgErro );
				syslg( msgErro );
			}
			else if( NETC_remove( msgErro ) != NETC_RET_OK )
			{
				ODebug( msgErro );
				syslg( msgErro );
			}

			ODebug("Memoria compartilhada removida!\n");
			break;
		case 'i':

			if( NETC_init( msgErro ) != NETC_RET_OK )
			{
				ODebug( msgErro );
				syslg( msgErro );
			}
			else
			{
				//if( NETC_show( msgErro ) != NETC_RET_OK )
				if( NETC_show( ) != NETC_RET_OK )
				{
					ODebug( msgErro );
					syslg( msgErro );
				}

				if( show( msgErro ) != NETC_RET_OK )
				{
					ODebug( msgErro );
					syslg( msgErro );
				}
			}

			break;
		case 'a':
			if( NETC_init( msgErro ) != NETC_RET_OK )
			{
				ODebug( msgErro );
				syslg( msgErro );
				break;
			}
				
				int ret = 0;
				char vertice[20];
				char msgtype[20];
				char pcode[20];
				char retcode[20];
				char netid[20];
				char acqid[20];

				printf("Vertice: ");
				fgets( vertice, sizeof(vertice), stdin );

				printf("ISSUER: ");
				fgets( netid, sizeof(netid), stdin );

				printf("ACQ: ");
				fgets( acqid, sizeof(acqid), stdin );

				switch( atoi( vertice ) )				
				{
					case QTDE_REQ_REC:
					case QTDE_REQ_ENV:
					case QTDE_RESP_REC:
					case QTDE_RESP_ENV:
						ret = NETC_increment( atoi( vertice ), netid, acqid, 0, 0, 0, msgErro );
						break;
					case NETC_INDEF:
				printf("MSGTYPE: ");
				fgets( msgtype, sizeof(msgtype), stdin );

				printf("PCODE: ");
				fgets( pcode, sizeof(pcode), stdin );

				printf("RETCODE: ");
				fgets( retcode, sizeof(retcode), stdin );
						ret = NETC_increment( NETC_INDEF, netid, acqid, atoi(msgtype), atoi(pcode), atoi(retcode), msgErro );
					
				}

				if( ret != NETC_RET_OK ) 
				{
					ODebug( msgErro );
					syslg( msgErro );
				}
			break;
	}

	return iRet;
}

int main( int argc, char *argv[] )
{
	char procName [10 + 1];
	memset(procName, '\0', sizeof(procName));

	snprintf (procName, sizeof(procName), "ShmManager"); 

	syslg_setargv0(procName);

	assert( strlen(argv[1]) == 2 );

	char debfile[80];
	sprintf(debfile, "%s.debug",  argv[0]);
	debug_on(debfile);

	ODebug("===========================================\n");
	ODebug("ShmManager - INICIO \n");
	ODebug("Number of parameters %d \n", argc);
	ODebug("===========================================\n");

	/* Executa o processamento */
	execute( (argv[1])[1] );

        ODebug("===========================================\n");
        ODebug("ShmManager - FIM \n");
        ODebug("===========================================\n");

	return 0;	
}
