/*
 *  Contem definicoes do sistema.
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  05/10/2011  Versao inicial. (ID_16872)
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */


#ifndef _SHM_MANAGER_H
#define _SHM_MANAGER_H

/* Includes do produto*/
#include <oasis.h>
#include <syslg.h>
#include <mb.h>
#include <mem.h>
#include <util.h>
#include <debug.h>
#include <ports.h>
#include <shc.h>

#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/msg.h>

int network_table_create(struct shm_net_table *NetworksTable, char *front_end, int *reg_count);

static const char *INDEX_NAME = "shcbin_ix";


#endif /* _SHM_MANAGER_H */

