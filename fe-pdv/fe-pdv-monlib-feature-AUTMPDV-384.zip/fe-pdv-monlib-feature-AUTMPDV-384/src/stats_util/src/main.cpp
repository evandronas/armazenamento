/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -----------------------------------------------------------------------------
/ Sigla: 
/ Descri��o: Modulo de interface entre o plugin Stats e o NETC
/ Conte�do:
/ Autor: t689066, Alexandre Guimaraes
/ Data de Cria��o: 2012, 21 de setembro
/ Hist�rico Mudan�as: 2012, 21 de setembro, t689066, Alexandre Guimaraes, 
/                                                                Versao Inicial
/ -----------------------------------------------------------------------------
*/

#include <stdio.h>
#include <libNETC.h>
#include <debug.h>
#include <ist_otrace.h>
#include <ist_argv0.h>
#include <iostream>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

int main (int argc, char** argv)
{
    int l_return = 0;      
    int l_param = 0;
    bool l_cmdEnd = false;
    bool l_quit = false;
    char * l_pch;    
    int l_bufferPos = 0;
    char l_buffer[512];
    char l_byte;
    int l_vertice = 0;
    char l_issuer[11] = {0};
    char l_acquirer[11] = {0};
    int l_msgtype = 0;
    long l_pcode = 0;
    int l_retcode = 0;    
    char l_msgErro[ NETC_MAX_BUFFER ] = {0};
    char l_msgLog[ NETC_MAX_BUFFER + 64 ] = {0};
    argv0 = argv[0];
    OTraceOn( argv0 );
	
	int flags = fcntl( 0, F_GETFL, 0 );
	fcntl( 0, F_SETFL, flags | O_NONBLOCK );
#ifndef NONETC
    l_return = NETC_init( l_msgErro );
    if( l_return != NETC_RET_OK )
    {
        sprintf( l_msgLog, 
                 "%s:[%d:%s]\n", 
                 "Error under shm connect", 
                 l_return, 
                 l_msgErro );
        OTraceError( l_msgLog );
        return l_return;
    }
#endif
	size_t freaddRet = 0;
    while ( !l_quit )
    {
        l_bufferPos = 0;
        l_cmdEnd = false;
        memset( l_buffer, 0, sizeof l_buffer );

		pid_t l_parent = getppid( );
		if ( l_parent == 1 )
		{
			OTraceFatal( "Killing chield process." );
			exit( 0 );
		}
		
        while ( !l_cmdEnd ) 
        {
			for ( ; ; )
			{
				l_byte = getc( stdin );
				l_parent = getppid( );
				if ( l_parent == 1 )
				{
					OTraceFatal( "Killing chield process." );
					exit( 0 );
				}
				if ( errno == EAGAIN && l_byte == EOF )
				{
					errno = 0;
					usleep( 50000 );
				}
				else
				{
					break;
				}
			}
			
			if ( l_byte == EOF )
			{
				return 0;
			}
            if ( l_byte == '\n' )
            {
                l_buffer[ l_bufferPos ] = '\0'; 
                l_cmdEnd = true;                
            }        
            else
            {
                l_buffer[ l_bufferPos ] = l_byte;          
            }   
            ++l_bufferPos;             
        }
		
        if( ( l_quit = ( ( strcmp( l_buffer, "q" ) == 0 )  && 
                                            ( l_bufferPos == 2 ) ) ) == false )
        {
            l_param = 0;
            l_pch = strtok ( l_buffer ,"|" );
            while( l_pch != NULL )
            {
                switch ( l_param ) 
                {
                    case 0:
                        if (strcmp(l_pch, "QTDE_REQ_REC") == 0)
                        {
                            l_vertice = QTDE_REQ_REC;
                        }
                        else if (strcmp(l_pch, "QTDE_REQ_ENV") == 0)
                        {
                            l_vertice = QTDE_REQ_ENV;
                        }
                        else if (strcmp(l_pch, "QTDE_RESP_REC") == 0)
                        {
                            l_vertice = QTDE_RESP_REC;
                        }
                        else if (strcmp(l_pch, "QTDE_RESP_ENV") == 0)
                        {
                            l_vertice = QTDE_RESP_ENV;
                        }
                        else if (strcmp(l_pch, "NETC_INDEF") == 0)
                        {
                            l_vertice = NETC_INDEF;
                        }
                        else
                        {
                            l_vertice = 0;
                            sprintf( l_msgLog, 
                                     "%s:[%s]\n", 
                                     "Invalid l_vertice", 
                                     l_pch );
                            OTraceDebug( l_msgLog );    
                        }
                        break;
                    case 1:
                        sprintf( l_issuer, "%10s", l_pch );                        
                        break;
                    case 2:                    
                        sprintf( l_acquirer, "%10s", l_pch );                        
                        break;
                    case 3:
                        l_msgtype = atoi( l_pch );                      
                        break;
                    case 4:
                        l_pcode = atol( l_pch );
                        break;
                    case 5:
                        l_retcode = atoi( l_pch );
                        break;
                    default:                        
                        sprintf( l_msgLog, 
                                 "%s\n", 
                                 "Too many tokens in received pipe data" );
                        OTraceDebug( l_msgLog );
                        break;
                }
                l_pch = strtok ( NULL, "|" );
                ++l_param;
            }
#ifndef NONETC                
            l_return = NETC_increment( l_vertice,
                                       l_issuer, 
                                       l_acquirer, 
                                       l_msgtype, 
                                       l_pcode, 
                                       l_retcode, 
                                       l_msgErro );
            if( l_return != NETC_RET_OK )
            {
                sprintf( l_msgLog, 
                         "%s:[%d:%s]\n", 
                         "Error at NETC_increment", 
                         l_return, 
                         l_msgErro );
                OTraceError( l_msgLog );
                return l_return;
            } 
#endif                
            sprintf( l_msgLog, 
                     "%s:[v%d][i%s][a%s][m%d][p%d][r%d]\n", 
                     "NETC_increment", 
                     l_vertice,
                     l_issuer,
                     l_acquirer,
                     l_msgtype, 
                     l_pcode, 
                     l_retcode );
            OTraceDebug( l_msgLog );        
        }
    }
    return l_return;
}

