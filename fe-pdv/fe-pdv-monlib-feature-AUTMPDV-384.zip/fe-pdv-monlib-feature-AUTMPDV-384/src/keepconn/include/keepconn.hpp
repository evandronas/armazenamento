/*
Copyright [2020] Rede S.A.
*************************************************************
Nome     : keepconn.hxx
Descrição: Headers e definicoes gerais
Autor    : Joao Paulo F. Costa
Data     : 13/11/2020
Empresa  : Rede
*********************** MODIFICACOES ************************
*/

/* Includes SO - Inicio */
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
/* Includes SO - Fim    */

/* Includes Produto - Inicio */
#include <syslg.h>
#include <debug.h>
#include <mb.h>
#include <security.h>
#include <ist_cfg.h>
#include <ist_catsig.h>
#include <ports.h>
/* Includes Produto - Fim    */

/* Estrutura de Configuracao - Inicio */
struct configTable
{
	int  sleepTime;                           /* Tempo de 'espera' entre ciclos de envio da mensagem de teste.                */
	int  debugFlag;                           /* Flag para Ativacao/Desativacao de debugs. 0 (default) Desligado, 1 - Ligado. */
	int  logFlag;                             /* Flag para Ativacao/Desativacao de logs. 0 (default) Desligado, 1 - Ligado.   */
	int  appMailBoxId;                        /* ID do Mailbox da APP.                                                        */
	int  portCount;                           /* Quantidade de portas 'Security' (obtida do istparam.cfg)                     */
	int  searchKeys;                          /* Quantidade de Chaves lidas do Arquivo de Configuracao.                       */
	char name              [16 + 1];          /* Nome da task.                                                                */
	char debugFile         [32 + 1];          /* Nome do arquivo de debug.                                                    */
	char appVer            [32 + 1];          /* Versao Aplicacao.                                                            */  
	char cfgVer            [32 + 1];          /* Versao Leitor de Configuracao.                                               */  
	char utlVer            [32 + 1];          /* Versao Utilidades.                                                           */
	char appMailBox        [MB_MAX_NAME + 1]; /* Nome do Mailbox da APP.                                                      */
	char currentFrontEnd   [ 4 + 1];          /* Front-end processador. CRT/CRTO/CRTM/DBT/DBTO/DBTM/HST/PDV/POS/WEB.          */
	char secPortNamePrefix [16 + 1];          /* Prefixo do nome das portas do 'security'.                                    */

};
/* Estrutura de Configuracao - Fim */

/* Variaveis Globais obrigatorias */
extern struct configTable appConfigTable;

/* Prototipos diversos - Inicio */
void initApp(void);                                                                             /* keepconn_util.cxx   */
void obtemConfig(void);                                                                         /* keepconn_config.cxx */
void functionInOut(const void *, const void *);                                                 /* keepconn_util.cxx   */
void dumpAppVer(void);                                                                          /* keepconn_util.cxx   */
void progExit(int);                                                                             /* keepconn_util.cxx   */
void initRequisitosAPP(void);                                                                   /* keepconn_util.cxx   */
void dumpConfig(void);                                                                          /* keepconn_util.cxx   */
void appProcess(void);                                                                          /* keepconn_util.cxx   */
void commandNONP(int);                                                                          /* keepconn_NONP.cxx   */
void commandNCND(int);                                                                          /* keepconn_NCND.cxx   */
int  obtemQtdePortasSecurity(int *);                                                            /* keepconn_util.cxx   */
void obtemValorParametroConfig(const char *, void *, void *, int , int , struct paramTable **); /* keepconn_util.cpp   */
int  portCheckStatus(const char *, char *);                                                     /* keepconn_util.cxx   */
int  portCheckStatusXt(const char *, char *);                                                   /* keepconn_util.cxx   */
int  isMailboxUp();
/* Prototipos diversos - Fim */

/* Valores Default - Configuracao */
static char DEFAULT_CONFIG_FILE[]         = "keepconn.cfg";
static int  DEFAULT_SLEEP_TIME            = 300;
static int  DEFAULT_DEBUG_FLAG            = 0;
static int  DEFAULT_LOG_FLAG              = 0;
static char DEFAULT_APP_MAILBOX[]         = "keepconnMailBox";
static char DEFAULT_SEC_PORTNAME_PREFIX[] = "security";
static char DEFAULT_PARAM_NAME[]          = "port.name";
static char ISTPARAM_CFG[]                = "istparam.cfg";

/* Outros valores */
#define TIPO_INTEIRO          1
#define TIPO_STRING           2
#define TIPO_INTEIRO_ARRAY    3
#define TIPO_STRING_ARRAY     4
#define COMPRIMENTO_PARAMETRO 12
#define PORT_STOPPED          1
#define PORT_CONNECTED        2
#define PORT_DISCONNECTED     4
#define NO_PORTS_FOUND        101
#define UNABLE_CREATE_APPMB   102

struct paramTable
{
	char appSearchKey [COMPRIMENTO_PARAMETRO];
};

/* Estruturas HSM */

/* HSM Status */
/* NO - Solicitacao - Inicio */
struct hsmSendNO
{
   char header[ 4 ];
   char commandCode[ 2 ];
   char modeFlag[ 2 ];
};
/* NO - Fim */

/* NP - Resposta - Inicio */
/* Mode '00' */
struct hsmRecvNP
{
	char header[ 4 ];
	char responseCode[ 2 ];
	char errorCode[ 2 ];
	char buffSize;
	char etherType;
	char sockNumber[2];
	char firmNumber[9];
	char reserved1;
	char reserved2[4];
};
/* NP - Fim */

/* HSM Perform Diagnostics */
/* NC - Solicitacao - Inicio */
struct hsmSendNC
{
   char header[ 4 ];
   char commandCode[ 2 ];
};
/* NO - Fim */

/* ND - Resposta - Inicio */
struct hsmRecvND
{
	char header[ 4 ];
	char responseCode[ 2 ];
	char errorCode[ 2 ];
	char lmkCheck [ 16 ];
	char firmNumber[9];
};
/* NP - Fim */
