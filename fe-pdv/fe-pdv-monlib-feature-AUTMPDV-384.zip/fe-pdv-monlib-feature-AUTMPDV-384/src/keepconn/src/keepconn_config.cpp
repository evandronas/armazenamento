/*
Copyright [2020] Rede S.A.
*************************************************************
Nome     : keepconn_config.c
Descricao: Obtem as configuracoes da aplicacao
Autor    : Joao Paulo F. Costa
Data     : 13/11/20
Empresa  : Rede
*********************** MODIFICACOES ************************
*/

/* Includes Aplicacao - Inicio */
#include <keepconn.hpp>
/* Includes Aplicacao - Fim    */

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 08/02/18
Nome            : obtemConfig
Descrição       : Obtem as configuracoes da aplicacao.
Parâmetros      : Nao ha.
Retornos        : Nao ha.
Modificacao     : NA
*************************************************************
*/ 
void obtemConfig(void)
{

	functionInOut("obtemConfig","Inicio");

	char fullPathConfFile [128 + 1];
	FILE *configFile = NULL;  /* Ponteiro para o arquivo de configuracao.           */
	int usaArquivoConfig = 1; /* Flag indicadora de uso de arquivo de configuracao. */
	                          /* 0: Nao usa. 1 - Usa */

	/* Modelo de Path 'SW77' */
	memset(fullPathConfFile, '\0', sizeof(fullPathConfFile));
	sprintf(fullPathConfFile,"%s/cfg/%s", getenv("FE_ROOT"), DEFAULT_CONFIG_FILE);
	
	/* Valida existencia do arquivo e se possui permissao de leitura */
	if((configFile = fopen(fullPathConfFile, "r")) == NULL)
	{
		ODebug("Arquivo de configuracao '%s' nao localizado. Serao utilizados os valores padrao.\n", fullPathConfFile);
		syslg("Arquivo de configuracao '%s' nao localizado. Serao utilizados os valores padrao.\n", fullPathConfFile);
		usaArquivoConfig = 0;
	}
	else
	{
		/* Caso exista, abre o arquivo para leitura dos parametros de configuracao utilizando API do produto */
		ODebug("Arquivo de configuracao '%s' encontrado. Realizando leitura.\n", fullPathConfFile);
		syslg("Arquivo de configuracao '%s' encontrado. Realizando leitura.\n", fullPathConfFile);
		cf_openfile(fullPathConfFile);
		/* Desaloca ponteiro utilizado para teste de arquivo. */
		fclose(configFile);
	}
	
	/* Obtendo SleepTime      */
	obtemValorParametroConfig("sleepTime"        , &appConfigTable.sleepTime        , &DEFAULT_SLEEP_TIME         , TIPO_INTEIRO, usaArquivoConfig, NULL);
	
	/* Obtendo debugFlag      */
	obtemValorParametroConfig("debugFlag"        , &appConfigTable.debugFlag        , &DEFAULT_DEBUG_FLAG         , TIPO_INTEIRO, usaArquivoConfig, NULL);

	/* Obtendo logFlag        */                                                    
	obtemValorParametroConfig("logFlag"          , &appConfigTable.logFlag          , &DEFAULT_LOG_FLAG           , TIPO_INTEIRO, usaArquivoConfig, NULL);
	
	/* Obtendo MailBox da APP */                                                    
	obtemValorParametroConfig("appMailBox"       , &appConfigTable.appMailBox       , &DEFAULT_APP_MAILBOX        , TIPO_STRING , usaArquivoConfig, NULL);
	
	/* Obtendo MailBox da APP */                                                    
	obtemValorParametroConfig("secPortNamePrefix", &appConfigTable.secPortNamePrefix, &DEFAULT_SEC_PORTNAME_PREFIX, TIPO_STRING , usaArquivoConfig, NULL);
	
	/* Fecha o arquivo utilizando a API do produto */
	if (usaArquivoConfig)
	{
		cf_close();
	}
	
	functionInOut("obtemConfig","Fim");
	
	/* Nada mais a setar.*/
	return;
}

