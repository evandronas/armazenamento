/*
Copyright [2020] Rede S.A.
*************************************************************
Nome     : keepconn_NCND.cxx
Descricao: Envio NC e tratamento da resposta ND
Autor    : Joao Paulo F. Costa
Data     : 20/11/2020
Empresa  : Rede
*********************** MODIFICACOES ************************
*/

/* Includes Aplicacao - Inicio */
#include <keepconn.hpp>
/* Includes Aplicacao - Fim    */

void commandNCND(int portCount)
{
	struct hsmSendNC sendNC;
	struct hsmRecvND recvND;
	char portName [ 16 + 1 ]; 
	char portStatusDescription [ 16 + 1 ];
	
	memset(&sendNC, '\0', sizeof(sendNC));
	memset(&recvND, '\0', sizeof(recvND));
	memset(&portName             , '\0', sizeof(portName));
	memset(&portStatusDescription, '\0', sizeof(portStatusDescription));	
	
   	/* Monta comando 'NC' */
	memcpy(sendNC.header     , "0001", sizeof(sendNC.header));
	memcpy(sendNC.commandCode, "NC"  , sizeof(sendNC.commandCode));

	/* Envia solicitacao e trata resposta */
	for (int sendCount = 1; sendCount <= portCount; sendCount++)
	{
		sprintf(portName, "%s%d", appConfigTable.secPortNamePrefix, sendCount);
		//if (portCheckStatus(portName, portStatusDescription) == PORT_CONNECTED)
		if (portCheckStatusXt(portName, portStatusDescription) == PORT_CONNECTED)
		{
			ODebug("Enviando comando 'NC' para '%s'\n", portName);
			syslg("Enviando comando 'NC' para '%s'\n", portName);
			security_direct((char *)&sendNC, sizeof(sendNC), (char *)&recvND, sizeof(recvND));
			ODebug("Resposta '%d/%d' (NC/ND):[%s]\n", sendCount, portCount, recvND.errorCode);
			syslg("Resposta '%d/%d' (NC/ND):[%s]\n", sendCount, portCount, recvND.errorCode);
		}
		else
		{
			ODebug("O status da porta '%s' eh '%s'. Nao sera enviado comando.\n", portName, portStatusDescription);
		}
	}
	return;
}
