/*
Copyright [2020] Rede S.A.
*************************************************************
Nome     : keepconn_NONP.cxx
Descricao: Envio NO e tratamento da resposta NP
Autor    : Joao Paulo F. Costa
Data     : 17/11/2020
Empresa  : Rede
*********************** MODIFICACOES ************************
*/

/* Includes Aplicacao - Inicio */
#include <keepconn.hpp>
/* Includes Aplicacao - Fim    */

void commandNONP(int portCount)
{
	struct hsmSendNO sendNO;
	struct hsmRecvNP recvNP;
	char portName [ 16 + 1 ]; 
	char portStatusDescription [ 16 + 1 ];
	
	memset(&sendNO               , '\0', sizeof(sendNO));
	memset(&recvNP               , '\0', sizeof(recvNP));
	memset(&portName             , '\0', sizeof(portName));
	memset(&portStatusDescription, '\0', sizeof(portStatusDescription));
	
    /* Monta comando 'NO' */
	memcpy(sendNO.header     , "0001", sizeof(sendNO.header));
	memcpy(sendNO.commandCode, "NO"  , sizeof(sendNO.commandCode));
	memcpy(sendNO.modeFlag   , "00"  , sizeof(sendNO.modeFlag));

	/* Envia solicitacao e trata resposta */
	for (int sendCount = 1; sendCount <= portCount; sendCount++)
	{
		sprintf(portName, "%s%d", appConfigTable.secPortNamePrefix, sendCount);
		//sprintf(portName, "%s", "route_HST_436");
		//if (portCheckStatus(portName, portStatusDescription) == PORT_CONNECTED)
		if (portCheckStatusXt(portName, portStatusDescription) == PORT_CONNECTED)
		{
			ODebug("Enviando comando 'NO' para '%s'\n", portName);
			syslg("Enviando comando 'NO' para '%s'\n", portName);
			security_direct((char *)&sendNO, sizeof(sendNO), (char *)&recvNP, sizeof(recvNP));
			ODebug("Resposta '%d/%d' (NO/NP):[%s]\n", sendCount, portCount, recvNP.errorCode);
			syslg("Resposta '%d/%d' (NO/NP):[%s]\n", sendCount, portCount, recvNP.errorCode);
		}
		else
		{
			ODebug("O status da porta '%s' eh '%s'. Nao sera enviado comando.\n", portName, portStatusDescription);
		}
	}
	return;
}
