/*
Copyright [2020] Rede S.A.
*************************************************************
Nome     : keepconn.cxx
Descricao: Mantem conexao com HSMs abertas
Autor    : Joao Paulo F. Costa
Data     : 13/11/2020
Empresa  : Rede
*********************** MODIFICACOES ************************
*/

/* Includes Aplicacao - Inicio */
#include <keepconn.hpp>
/* Includes Aplicacao - Fim    */
struct configTable appConfigTable;

int main(int argc, char *argv[])
{
	memset(&appConfigTable, '\0', sizeof(appConfigTable));
	
	/* Parametrizacoes Iniciais - Inicio */
	sprintf(appConfigTable.name, "%s", argv[0]);
	sprintf(appConfigTable.appVer, "%s", "keepconn 1.0 13Nov2020"      );
	sprintf(appConfigTable.cfgVer, "%s", "keepconnConfig 1.0 13Nov2020");
	sprintf(appConfigTable.utlVer, "%s", "keepconnUtil 1.0 13Nov2020"  );
	/* Parametrizacoes Iniciais - Fim */

	initApp();
	
	functionInOut("keepconn","Inicio");
	
	appProcess();
	
	functionInOut("keepconn","Fim");
	
}
