/*
Copyright [2020] Rede S.A.
*************************************************************
Nome     : keepconn_util.cxx
Descricao: Utilidades do app
Autor    : Joao Paulo F. Costa
Data     : 13/11/2020
Empresa  : Rede
*********************** MODIFICACOES ************************
*/

/* Includes Aplicacao - Inicio */
#include <keepconn.hpp>
/* Includes Aplicacao - Fim    */

int isMailboxUp()
{
	if (mb_test() < 0)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}


/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 24/11/20
Nome            : portCheckStatusXt
Descricao       : Verifica o status da porta consultando a
                  mbtab.
Parametros      : const char *, char *
Retornos        : int
Modificacao     : N/A
*************************************************************
*/
int portCheckStatusXt(const char *portName, char *portStatusDesc)
{
	
	int portId     = 0;
	int portStatus = 0;
	char localPortName[MB_MAX_NAME + 1];
	struct mbsysport mbPortGeneral;
	
	portStatus = PORT_DISCONNECTED;
	sprintf(portStatusDesc, "%s", "DISCONNECTED");
	
	memset(&localPortName, '\0', sizeof(localPortName));
	memset(&mbPortGeneral, '\0', sizeof(mbPortGeneral));
	
	for (int portIndex = 0; portIndex < mb->nboxes; portIndex++)
	{
		portId = portIndex;
		sprintf(localPortName,"%s",mbMailBoxName(portIndex));
		if (mbIsPort(portIndex))
		{
			mb_getport(mbtab[portIndex].name, &mbPortGeneral);
			portId = mbPortGeneral.port.mbid;
			sprintf(localPortName, "%s", mbPortGeneral.name);
			if (!strncmp(localPortName, portName, strlen(portName)))
			{
				if (mbPortGeneral.port.flags & MB_PORT_CONNECTED)
				{
					portStatus = PORT_CONNECTED;
					sprintf(portStatusDesc, "%s", "CONNECTED");
					return portStatus;
				}
				else
				{
					portStatus = PORT_DISCONNECTED;
					sprintf(portStatusDesc, "%s", "DISCONNECTED");
					return portStatus;
				}
			}
		}
	}
	
	return portStatus;
}
/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 23/11/20
Nome            : portCheckStatus
Descricao       : Verifica o status da porta.
Parametros      : const char *, char *
Retornos        : int
Modificacao     : N/A
*************************************************************
*/
int portCheckStatus(const char *portName, char *portStatusDesc)
{

	int portId     = 0;
	int portStatus = 0;

	if((portId = mb_locateport(portName)) >= 0)
	//if((portId = mb_locateport("route_HST_436")) >= 0)
	{
		if(mbPortStopped(portId))
		{
			portStatus = PORT_STOPPED;
			sprintf(portStatusDesc, "%s", "STOPPED");
		}
		else
		{
			if(mbPortIsConnected(portId))
			{
				portStatus = PORT_CONNECTED;
				sprintf(portStatusDesc, "%s", "CONNECTED");
			}
			else
			{
				portStatus = PORT_DISCONNECTED;
				sprintf(portStatusDesc, "%s", "DISCONNECTED");
			}	
		}
	}
	else
	{
		portStatus = PORT_DISCONNECTED;
		sprintf(portStatusDesc, "%s", "DISCONNECTED");
	}

	return portStatus;
}

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 18/11/20
Nome            : obtemQtdePortasSecurity
Descricao       : Obtem, do istparam.cfg do FE, a qtde de portas
                  'security' para determinar a qtde de envios.
Parametros      : int *
Retornos        : int
Modificacao     : N/A
*************************************************************
*/
int obtemQtdePortasSecurity(int *qtdePortas)
{

	functionInOut("obtemQtdePortasSecurity","Inicio");
	
	char fullPathConfFile [128 + 1];
	char auxiliarData [ 255 + 1];
	char paramData [32 + 1];
	int localPortCount = 0;
	int statusBusca = 0;
	
	memset(fullPathConfFile, '\0', sizeof(fullPathConfFile));
	memset(auxiliarData    , '\0', sizeof(auxiliarData));
	memset(paramData    , '\0', sizeof(paramData));
	
	sprintf(fullPathConfFile,"%s/cfg/%s", getenv("OSITE_ROOT"), ISTPARAM_CFG);
	cf_open(fullPathConfFile);

	while(cf_nextparm(DEFAULT_PARAM_NAME, auxiliarData) > 0)
	{
		sscanf(auxiliarData, "%s", paramData);
		if (!strncmp(paramData, appConfigTable.secPortNamePrefix, strlen(appConfigTable.secPortNamePrefix)))
		{
			localPortCount++;
		}
		memset(paramData    , '\0', sizeof(paramData));
		memset(auxiliarData    , '\0', sizeof(auxiliarData));
	}

	if (localPortCount == 0)
	{
		cf_close();
		functionInOut("obtemQtdePortasSecurity","Fim");
		return statusBusca;
	}
	else
	{
		statusBusca = 1;
		*qtdePortas = localPortCount;
		cf_close();
		functionInOut("obtemQtdePortasSecurity","Fim");
	
		return statusBusca;
	}
}
/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 17/11/20
Nome            : appProcess
Descricao       : Processamento de messagens
Parametros      : Nao ha.
Retornos        : void
Modificacao     : N/A
*************************************************************
*/
void appProcess(void)
{
	functionInOut("appProcess","Inicio");
	
	for (;;) 
	{
		commandNONP(appConfigTable.portCount);
		sleep(appConfigTable.sleepTime);
	}
	
	functionInOut("appProcess","Fim");
	
	return;
}

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 13/11/20
Nome            : initRequisitosAPP
Descricao       : Incializacoes Diversas
Parametros      : Nao ha.
Retornos        : Nao ha.
Modificacao     : N/A
*************************************************************
*/
void initRequisitosAPP(void)
{
	functionInOut("initRequisitosAPP","Inicio");
	
	/* Criacao MB da APP - Inicio */
	if ((appConfigTable.appMailBoxId = mb_createmailbox(appConfigTable.appMailBox, 0, 0)) < 0) 
	{
		ODebug("Nao foi possivel localizar ou criar o mailbox [%s]\n", appConfigTable.appMailBox);
		syslg("Nao foi possivel localizar ou criar o mailbox [%s]\n", appConfigTable.appMailBox);
		functionInOut("initRequisitosAPP","Fim");
		progExit(UNABLE_CREATE_APPMB);
	}
	mbSetMailboxOptions(appConfigTable.appMailBoxId, MB_TAB_ALLOW_CMDS);
	mbSetMailboxOptions(appConfigTable.appMailBoxId, MB_TAB_APPL_TRACE);
	/* Criacao MB da APP - Fim */
	
	functionInOut("initRequisitosAPP","Fim");

	return;
}

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 13/11/20
Nome            : dumpConfig
Descricao       : Conforme parametrizacao, faz ou nao o debug/ 
                  log dos valores configurados para a app.
Parametros      : Nao ha.
Retornos        : Nao ha.
*************************************************************
*/ 
void dumpConfig(void)
{
	if (appConfigTable.debugFlag)
	{
		ODebug("%s.name        :[%s]\n", appConfigTable.name, appConfigTable.name);
		ODebug("%s.appMailBox  :[%s]\n", appConfigTable.name, appConfigTable.appMailBox);
		ODebug("%s.appMailBoxId:[%d]\n", appConfigTable.name, appConfigTable.appMailBoxId);		
		ODebug("%s.appVer      :[%s]\n", appConfigTable.name, appConfigTable.appVer);
		ODebug("%s.cfgVer      :[%s]\n", appConfigTable.name, appConfigTable.cfgVer);
		ODebug("%s.utlVer      :[%s]\n", appConfigTable.name, appConfigTable.utlVer);
		ODebug("%s.debugFlag   :[%d]\n", appConfigTable.name, appConfigTable.debugFlag);
		ODebug("%s.debugFile   :[%s]\n", appConfigTable.name, appConfigTable.debugFile);
		ODebug("%s.logFlag     :[%d]\n", appConfigTable.name, appConfigTable.logFlag);
		ODebug("%s.currentFE   :[%s]\n", appConfigTable.name, appConfigTable.currentFrontEnd);
		ODebug("%s.sleepTime   :[%d]\n", appConfigTable.name, appConfigTable.sleepTime);
		ODebug("%s.portCount   :[%d]\n", appConfigTable.name, appConfigTable.portCount);
		ODebug("%s.searchKeys  :[%d]\n", appConfigTable.name, appConfigTable.searchKeys);
	}
	
	if (appConfigTable.logFlag)
	{
		syslg("%s.name        :[%s]\n", appConfigTable.name, appConfigTable.name);
		syslg("%s.appMailBox  :[%s]\n", appConfigTable.name, appConfigTable.appMailBox);
		syslg("%s.appMailBoxId:[%d]\n", appConfigTable.name, appConfigTable.appMailBoxId);		
		syslg("%s.appVer      :[%s]\n", appConfigTable.name, appConfigTable.appVer);
		syslg("%s.cfgVer      :[%s]\n", appConfigTable.name, appConfigTable.cfgVer);
		syslg("%s.utlVer      :[%s]\n", appConfigTable.name, appConfigTable.utlVer);
		syslg("%s.debugFlag   :[%d]\n", appConfigTable.name, appConfigTable.debugFlag);
		syslg("%s.debugFile   :[%s]\n", appConfigTable.name, appConfigTable.debugFile);
		syslg("%s.logFlag     :[%d]\n", appConfigTable.name, appConfigTable.logFlag);
		syslg("%s.currentFE   :[%s]\n", appConfigTable.name, appConfigTable.currentFrontEnd);
		syslg("%s.sleepTime   :[%d]\n", appConfigTable.name, appConfigTable.sleepTime);
		syslg("%s.portCount   :[%d]\n", appConfigTable.name, appConfigTable.portCount);
		syslg("%s.searchKeys  :[%d]\n", appConfigTable.name, appConfigTable.searchKeys);
	}	
	return;
}

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 13/11/20
Nome            : obtemValorParametroConfig
Descricao       : Obtem valores dos parametros de configuração.
                  Caso não seja encontrado, atribui valor default.
Parametros      : char (entrada),
                  void (saida),
				  void (entrada),
				  int (entrada),
				  int (entrada),
				  struct paramTable ** (saida)
Retornos        : N/A
*************************************************************
*/
void obtemValorParametroConfig(const char *nomeParametro, void *campoDestino, void *valorDefault, int tipoParametro, int usaArquivoConfig, struct paramTable **configuracaoExterna)
{

	int *campoDestinoLocal  = NULL;
	char nomeParametroBusca [ 32 + 1 ];
	
	int    quantidadeRegistros = 0;
	int    contadorLocal       = 0;
	char   valorTemporario    [ 11 + 1 ];
	struct paramTable *chaveConfiguracaoLocal = NULL;
	
	memset (valorTemporario, '\0', sizeof(valorTemporario));
	
	memset (nomeParametroBusca, '\0', sizeof(nomeParametroBusca));
	sprintf(nomeParametroBusca, "%s.%s", appConfigTable.name, nomeParametro);
	
	switch (tipoParametro)
	{
		case TIPO_INTEIRO:
		
			campoDestinoLocal = (int *)campoDestino;
			
			/* Valida se deve ser utilizado o arquivo de configuracao, senao, seta o valor default informado. */
			if (usaArquivoConfig)
			{
				if (cf_locatenum((const char*)nomeParametroBusca, campoDestinoLocal) < 0) 
				{
					ODebug("Parametro '%s' nao encontrado. Utilizando valor padrao.\n", nomeParametroBusca);
					syslg("Parametro '%s' nao encontrado. Utilizando valor padrao.\n", nomeParametroBusca);
					memcpy (campoDestinoLocal, valorDefault, sizeof(valorDefault));
				}
			}
			else
			{
				memcpy (campoDestinoLocal, valorDefault, sizeof(valorDefault));
			}
			
			break;
			
		case TIPO_STRING:
			
			/* Valida se deve ser utilizado o arquivo de configuracao, senao, seta o valor default informado. */
			if (usaArquivoConfig)
			{
				if (cf_locate((const char *)nomeParametroBusca, (char *)campoDestino) <= 0) 
				{
					ODebug("Parametro '%s' nao encontrado. Utilizando valor padrao.\n", nomeParametroBusca);
					syslg("Parametro '%s' nao encontrado. Utilizando valor padrao.\n", nomeParametroBusca);
					memcpy (campoDestino, valorDefault, strlen((const char *)valorDefault));
				}
			}
			else
			{
				memcpy (campoDestino, valorDefault, strlen((const char *)valorDefault));
			}
			
			break;
		
		case TIPO_STRING_ARRAY:
			
			/* Valida se deve ser utilizado o arquivo de configuracao, senao, seta o valor default informado. */
			if (usaArquivoConfig)
			{
				/* Se o parametro informado foi encontrado, determina a quantidade de regristros */
				if (cf_locate((const char *)nomeParametroBusca, valorTemporario) >= 0)
				{
					cf_rewind();
					while (cf_nextparm((const char *)nomeParametroBusca, valorTemporario) != 0)
					{
						quantidadeRegistros ++;
					}
				}
				else
				{
					/* Caso nao encontre o parametro */
				}
				appConfigTable.searchKeys = quantidadeRegistros;
				/* Se existir algum registro, aloca memoria */
				/* Obs.: Nao deve ser alterado o nome da struct paramTable */
				if (quantidadeRegistros > 0)
				{
					chaveConfiguracaoLocal = (struct paramTable *) malloc (quantidadeRegistros * sizeof(struct paramTable));
					memset(chaveConfiguracaoLocal, '\0', quantidadeRegistros * sizeof(struct paramTable));
					cf_rewind();
					memset (valorTemporario, '\0', sizeof(valorTemporario));
					while (cf_nextparm((const char *)nomeParametroBusca, valorTemporario) != 0)
					{
						/* Como fazer para indicar qual campo deve ser alimentado nesta estrutura, bem como seu tamanho para copia?*/
						sprintf(chaveConfiguracaoLocal[contadorLocal].appSearchKey, "%s", valorTemporario);
						contadorLocal ++;
					}
					*configuracaoExterna = chaveConfiguracaoLocal;
				}
				else
				{
					/* Caso nao encontre o parametro. Talvez nao exista necessidade deste tratamento visto que se nao encontrar deve sair mais acima */
				}
			}
		
			break;
		
		default:
			break;
	}
	
	return;
}

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 13/11/20
Nome            : progExit
Descricao       : Trata sinais da aplicacao
Parametros      : int.
Retornos        : N/A
Modificacao     : N/A
*************************************************************
*/
void progExit(int appSignal)
{

    if(appSignal == 0 || appSignal == SIGTERM)
    {
        syslg("Saida Normal # %d.\n", appSignal);
        ODebug("Saida Normal # %d.\n", appSignal);
    }  
    else
    {
        syslg("Saida devido a sinal # %d.\n", appSignal);
        ODebug("Saida devido a sinal # %d.\n", appSignal);
    }
	
	/* Desalocando recursos */
	delete_private_mbox();
	ODebugOff();
    exit(appSignal);
}

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 13/11/20
Nome            : dumpAppVer
Descricao       : Conforme parametrizacao, faz ou nao o debug 
                  da versao dos fontes da app.
Parametros      : Nao ha.
Retornos        : Nao ha.
Modificacao     : N/A
*************************************************************
*/ 
void dumpAppVer(void)
{
	if (appConfigTable.debugFlag)
	{
		ODebug("App.ver: [%s]\n", appConfigTable.appVer);
		ODebug("Cfg.ver: [%s]\n", appConfigTable.cfgVer);
		ODebug("Utl.ver: [%s]\n", appConfigTable.utlVer);
	}
	
	if (appConfigTable.logFlag)
	{
		syslg("App.ver: [%s]\n", appConfigTable.appVer);
		syslg("Cfg.ver: [%s]\n", appConfigTable.cfgVer);
		syslg("Utl.ver: [%s]\n", appConfigTable.utlVer);
	}
	return;
}

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 13/11/20
Nome            : functionInOut
Descricao       : Conforme parametrizacao, faz ou nao o debug/
				  log de entrada/saida de uma funcao
Parametros      : void *, void * (entradas)
Retornos        : N/A
Modificacao     : N/A
*************************************************************
*/
void functionInOut(const void *mensagemLog, const void *localFunc)
{
	if (appConfigTable.debugFlag)
	{
		ODebug("-------------------------------------------\n");
		ODebug("%s - %s.\n", (char *)mensagemLog, (char *)localFunc);
		ODebug("-------------------------------------------\n");
	}
	
	if (appConfigTable.logFlag)
	{
		syslg("-------------------------------------------\n");
		syslg("%s - %s.\n", (char *)mensagemLog, (char *)localFunc);
		syslg("-------------------------------------------\n");
	}
	return;
}

/*
*************************************************************
Autor e Empresa : Joao Paulo F. Costa - Rede
Data            : 13/11/20
Nome            : initApp
Descricao       : Executa funcoes iniciais necessarias para
                  funcionamento da aplicacao
Parametros      : N/A
Retornos        : void
Modificacao     : N/A
*************************************************************
*/
void initApp()
{

	sprintf(appConfigTable.debugFile, "%s.debug", appConfigTable.name);

	catch_all_signals(progExit);
    
	debug_on(appConfigTable.debugFile);

	syslg_setargv0(appConfigTable.name);

	obtemConfig();
	
	if (obtemQtdePortasSecurity(&appConfigTable.portCount) == 0)
	{
		ODebug("Configuracao para porta '%s'* nao localizada em '%s'. Processamento sera finalizado.", appConfigTable.secPortNamePrefix, ISTPARAM_CFG);
		syslg("Configuracao para porta '%s'* nao localizada em '%s'. Processamento sera finalizado.", appConfigTable.secPortNamePrefix, ISTPARAM_CFG);
		progExit(NO_PORTS_FOUND);
	}
	
	functionInOut("initApp","Inicio");

	dumpAppVer();
	
	if (isMailboxUp())
	{
		mb_init(); 
	}
	else
	{
		ODebug("FE nao esta ativo. Saindo...\n");
		syslg("FE nao esta ativo. Saindo...\n");
		functionInOut("initApp","Fim");
		progExit(3);
	}

	initRequisitosAPP();
	
	dumpConfig();
	
	functionInOut("initApp","Fim");
	
	return;
}
