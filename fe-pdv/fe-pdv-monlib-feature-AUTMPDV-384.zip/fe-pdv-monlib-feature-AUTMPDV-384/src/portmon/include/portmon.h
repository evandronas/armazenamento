/* Copyright 2017 Rede S.A.
Autor : William Ribeiro Balduino
Empresa : Rede
*/
/*
 *  - Portmon - Monitoracao de Portas e NetworkIds
 *
 *  - Descricao: Monitora a(s) conexao(oes) de rede das portas em relacao
 *              ao status dos Networkids
 *
 *  Who     When        Why
 *  ========================================================================
 *  686469  25/09/2012  Versao inicial.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */
 
/*
*************************************************************
Autor    : William Ribeiro Balduino
Data     : 02/01/2017
Empresa  : Rede
Descricao: 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas
ID       : 181.389, AM186.489
*************************************************************
Autor    : William Ribeiro Balduino
Data     : 27/03/2019
Empresa  : Rede
Descri��o: Ajuste Portmon Institui��o Down para Visa
ID       : 0883_ONL - SW75 - Corre��o Portmon - Visa 
AM       : AM244.764
*************************************************************
*/

#ifndef _PORTMON_H
#define _PORTMON_H

/* Includes do produto*/


#include "portmon_util.h"

/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - INICIO */
/*#define MAX_PORTS	         50*/
#define MAX_PORTS	        100
/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - Fim */
#define MAX_ROUTES	        500
#define MAX_ROUTE_NAME	     50
#define DEFAULT_SLEEP_TIME	 60

typedef struct
{
	int enabled;
        char routeName[MAX_ROUTE_NAME];
        char networkid[11];

	int portStatus;
	int binStatus;

	struct shcpkg* pkg;
	
}stRoute;

typedef struct
{
	int id;
	int allPortStatus;
	int allBinStatus;
	int qtdePorts;
	stRoute routes[MAX_ROUTES];
}stRGroup;

class CPortmon
{
	public:
		CPortmon();
		virtual ~CPortmon();

		virtual int execute();
		virtual int init();
		virtual int addRoute( int, char*, char* );
		virtual int updatePortStatus( stRoute* );
		virtual int updateBinStatus( stRoute* );
		virtual int executeRules( stRGroup* );

		inline int get_sleep_time();
		inline void set_sleep_time( const int );
		
		/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - INICIO */
		inline int  ObtemQuantidadeMaximaPortas();
		inline void SetaQuantidadeMaximaPortas( const int );
		/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - Fim */

	protected:

	private:
		CPortmonUtil m_cObjUtil;
		stRGroup m_stRGroup[ MAX_ROUTES ];
		int m_iSleepTime;
		int m_iQtdeRoutes;
		/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - INICIO */
		int quantidadeMaximaPortas;
		/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - Fim */
		virtual int allRoutesRules( stRGroup* );
		virtual int securityRules( stRGroup* );
		virtual int cupRules( stRGroup* );
		/* 0883_ONL - SW75 - Corre��o Portmon - Visa - WRB - INICIO */
		virtual int visaRules( stRGroup* );                         
		/* 0883_ONL - SW75 - Corre��o Portmon - Visa - WRB - FIM */
};

/*
 * Nome: get_sleep_time
 * Descricao: Execucao principal das operacoes
 * Parametros:
 * Retorno: 1
 */
inline int CPortmon::get_sleep_time()
{
        return m_iSleepTime;
}

/*
 * Nome: set_sleep_time
 * Descricao: Execucao principal das operacoes
 * Parametros:
 * Retorno: 1
 */
inline void CPortmon::set_sleep_time( const int time )
{
        m_iSleepTime = time;
}

/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - INICIO */
/// ObtemQuantidadeMaximaPortas
/// Retorna a quantidade maxima de portas
/// EF/ET: nao ha
/// Historico: [14/02/2017] - Criacao do metodo
/// quantidadeMaximaPortas: Quantidade maxima de portas configurada
inline int CPortmon::ObtemQuantidadeMaximaPortas()
{
        return quantidadeMaximaPortas;
}

/// SetaQuantidadeMaximaPortas
/// Seta a quantidade maxima de portas
/// EF/ET: nao ha
/// Historico: [14/02/2017] - Criacao do metodo
inline void CPortmon::SetaQuantidadeMaximaPortas( const int quantidadePortas )
{
        quantidadeMaximaPortas = quantidadePortas;
}
/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - Fim */

#endif /* _PORTMON_H */

