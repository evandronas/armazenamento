/*
 *  - Portmon - Monitoracao de Portas e NetworkIds
 *
 *  - Descricao: Fornece ferramentas ao modulo
 *
 *
 *  Who     When        Why
 *  ========================================================================
 *  686469  25/09/2012  Versao inicial.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */
/*
*************************************************************
Autor    : William Ribeiro Balduino
Data     : 11/07/2017
Empresa  : Rede
Descri��o: Inclusao da trativa do fluxo para quando as postas estiverem com o status STOPPED
ID       : 0680_SW - Desfazimentos sem resposta POS
AM       : 202.497
*************************************************************
*/

#ifndef _PORTMON_UTIL_H
#define _PORTMON_UTIL_H

/* Includes do produto*/
#include <oasis.h>
#include <syslg.h>
#include <mb.h>
#include <mem.h>
#include <util.h>
#include <debug.h>
#include <ports.h>
#include <shc.h>

#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/msg.h>

#define UP 		1
#define DOWN 		0
#define CONNECTED 	1
#define DISCONNECTED 	0

/* 0680_SW - Ajuste portmon - gerencia security - WRB -  INICIO */
#define STOPPED  2
/* 0680_SW - Ajuste portmon - gerencia security - WRB -  FIM */


class CPortmonUtil
{
	public:
		CPortmonUtil();
		virtual ~CPortmonUtil();

		int get_network_fd( int*, char* );
		int network_table_create( struct shm_net_table* NetworksTable, char* front_end, int* reg_count );

		int IsConnected( char* );

		void setBinStatus( char*, int );
		int getBinStatus( char* );

	protected:

	private:

};

#endif /* _PORTMON_UTIL_H */

