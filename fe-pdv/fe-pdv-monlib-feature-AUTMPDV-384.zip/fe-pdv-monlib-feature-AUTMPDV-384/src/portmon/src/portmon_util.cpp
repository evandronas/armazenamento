/*
 *  - Portmon - Monitoracao de Portas e NetworkIds
 *
 *  - Descricao: Fornece ferramentas ao modulo
 *
 *
 *  Who     When        Why
 *  ========================================================================
 *  686469  25/09/2012  Versao inicial.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */
/*
*************************************************************
Autor    : William Ribeiro Balduino
Data     : 11/07/2017
Empresa  : Rede
Descri��o: Inclusao da trativa do fluxo para quando as postas estiverem com o status STOPPED
ID       : 0680_SW - Desfazimentos sem resposta POS
AM       : 202.497
*************************************************************
*/

#include "portmon_util.h"

/*
 * Nome: CPortmonUtil
 * Descricao: Construtor padrao
 * Parametros: 
 * Retorno: 
 */
CPortmonUtil::CPortmonUtil()
{

}

/*
 * Nome: ~CPortmonUtil
 * Descricao: Destrutor padrao
 * Parametros:
 * Retorno:
 */
CPortmonUtil::~CPortmonUtil()
{

}


/*
 * Nome: IsConnected
 * Descricao: Verifica se uma porta esta conectada
 * Parametros: Porta
 * Retorno: CONNECTED, se conectada, DISCONNECTED, 
 *	   caso contrario
 */
int CPortmonUtil::IsConnected( char* portName )
{
	int iPortId = DISCONNECTED;
	
    if( (iPortId = mb_locateport( portName )) >= 0 )
    {
		/* 0680_SW - Ajuste portmon - gerencia security - WRB -  INICIO*/
		if(mbPortStopped( iPortId ))
		{
				iPortId = STOPPED;
		}
		/* 0680_SW - Ajuste portmon - gerencia security - WRB -  FIM*/
		else
		{
			if( mbPortIsConnected( iPortId ) )
			{
				iPortId = CONNECTED; 
			}	
			else
			{
				iPortId = DISCONNECTED;
			}	
		}
	}
	else
	{
		iPortId = DISCONNECTED;
	}	

	return iPortId;
}

/*
 * Nome: getBinStatus
 * Descricao: Verifica o status do Networkid na shcbin
 * Parametros: Networkid
 * Retorno: UP se up, DOWN caso contrario
 */
int CPortmonUtil::getBinStatus( char* networkid )
{

	int iRet = DOWN;
	struct shcpkg* pkg;
	
        if( shc_locate_bin( &pkg, networkid ) != -1 )
		iRet = shc_isdown( pkg ) ? DOWN : UP;

	return iRet;
}

/*
 * Nome: setBinStatus
 * Descricao: Marca o networkid conforme acao
 * Parametros: Networkid, acao( set UP / set DOWN )
 * Retorno: 
 */
void CPortmonUtil::setBinStatus( char* networkid, int action )
{
        struct shcpkg* pkg;

        if( shc_locate_bin( &pkg, networkid ) != -1 )
	{
		switch( action )
		{
			case UP:
				pkg->bin.flags &= ~SH_DOWN;
				break;
			case DOWN:
				pkg->bin.flags |= SH_DOWN;
				break;
			default:
				;
		}		
	}
}

