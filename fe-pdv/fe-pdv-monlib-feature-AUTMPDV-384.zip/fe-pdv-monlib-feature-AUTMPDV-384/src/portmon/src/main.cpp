static char ver[]="Portmon 2.0 25Set2012";

/*
 *  - Portmon - Monitoracao de Portas e NetworkIds
 *
 *  - Descricao: Monitora a(s) conexao(oes) de rede das portas em relacao
 *              ao status dos Networkids
 *
 *  Who     When        Why
 *  ========================================================================
 *  686469  25/09/2012  Versao inicial.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */

#include <portmon.h>

/*
 * Nome: main
 * Descricao: Funcao principal, constroi o arquivo de log e
 *		inicializa os objetos
 * Parametros:
 * Retorno:
 */
int main( int argc, char *argv[] )
{
	syslg_setargv0( argv[0] );

	int iRet = 0;
	char debfile[80];
	sprintf(debfile, "%s.debug",  argv[0]);
	debug_on(debfile);

	ODebug("===========================================\n");
	ODebug("Portmon - V2.0 - %s\n", ver);
	ODebug("===========================================\n");
	ODebug("Number of parameters: %d\n", argc);

	/* Conecta-se aos recursos do IST/Switch */
	mb_init();
	shc_init();

	CPortmon* l_cObjPortmon;

	try
	{
		/* Executa o processamento */
		l_cObjPortmon = new CPortmon;

		if( l_cObjPortmon->init() < 0 )
			return -1;


		while( 1 )
		{	
			if( l_cObjPortmon->execute() < 0 )
				return -1;

			sleep( l_cObjPortmon->get_sleep_time() );
		}

		delete l_cObjPortmon;
	}
	catch( ... )
	{
        	ODebug("Erro desconhecido no Portmon\n");
        	syslg("PRT-M: Erro desconhecido no Portmon\n");
		if( l_cObjPortmon ) delete l_cObjPortmon;
		iRet = -1;
	}

        ODebug("===========================================\n");
        ODebug("Portmon - FIM \n");
        ODebug("===========================================\n");

	return iRet;	
}
