/* Copyright 2015 Rede
Autor : Mauro Thiago da Silva
Empresa : Rede
*/

/*
 *  - Portmon - Monitoracao de Portas e NetworkIds
 *
 *  - Descricao: Monitora a(s) conexao(oes) de rede das portas em relacao
 *		ao status dos Networkids
 *
 *  Who     When        Why
 *  ========================================================================
 *  686469  25/09/2012  Versao inicial. 
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */
/*
*********************** MODIFICACOES ************************
Autor    : Mauro Thiago da Silva
Data     : 18/09/2015
Empresa  : Rede
Descri��o: Tratamento de multiplas portas security.
AM       : AM145.023
ID       : 89.349
*************************************************************
Autor    : William Ribeiro Balduino
Data     : 12/08/2016
Empresa  : Rede
Descri��o: 0620_SW - Ajuste tratamento individual portas security
AM       : AM163326
ID       : 89.349 
*************************************************************
Autor    : William Ribeiro Balduino
Data     : 02/01/2017
Empresa  : Rede
Descricao: 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas
ID       : 181.389, AM186.489
*************************************************************
Autor    : William Ribeiro Balduino
Data     : 11/07/2017
Empresa  : Rede
Descri��o: Inclusao da trativa do fluxo para quando as postas estiverem com o status STOPPED
ID       : 0680_SW - Desfazimentos sem resposta POS
AM       : 202.497
*************************************************************
Autor    : William Ribeiro Balduino
Data     : 27/03/2019
Empresa  : Rede
Descri��o: Ajuste Portmon Institui��o Down para Visa
ID       : 0883_ONL - SW75 - Corre��o Portmon - Visa 
AM       : AM244.764
*************************************************************
*/

#include <portmon.h>

/*
 * Nome: CPortmon
 * Descricao: Construtor padrao, inicializa os membros principais
 * Parametros: 
 * Retorno:
 */
CPortmon::CPortmon()
{
	for( int i = 0; i < MAX_ROUTES; i++ )
	{
		memset( &m_stRGroup[ i ], 0, sizeof( stRGroup ) ); 
		m_stRGroup[ i ].id = -1;
		m_stRGroup[ i ].qtdePorts = 0;
		m_stRGroup[ i ].allPortStatus = 0;
		m_stRGroup[ i ].allBinStatus = 0;
	}

	m_iSleepTime = DEFAULT_SLEEP_TIME;
	m_iQtdeRoutes = 0;

	/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - INICIO */
	quantidadeMaximaPortas  = MAX_PORTS;
	/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - FIM */
}

/*
 * Nome: ~CPortmon
 * Descricao: Destrutor padrao
 * Parametros:
 * Retorno: 
 */
CPortmon::~CPortmon()
{

}

/*
 * Nome: init
 * Descricao: Inicializa as configuracoes das rotas
 * Parametros: 
 * Retorno: 0 se sucesso, < 0 caso contrario
 */
int CPortmon::init()
{
	ODebug("Lendo configuracoes...\n");

	char buf[2048] = {0};

        int iRet = -1;

        char arqCfg[1024] = {0};
	sprintf(arqCfg,"%s/cfg/portmon.cfg", getenv("FE_ROOT") );

        /* Recupera a lista dos msgtypes/pcodes do FE */
        if( (iRet = cf_openfile(arqCfg)) < 0 )
        {
                ODebug("Nao foi possivel abrir o arquivo [%s]\n", arqCfg);
                syslg("PRT-M: Nao foi possivel abrir o arquivo [%s]\n", arqCfg);
                return -1;
        }

        /* Localiza o parametro de tempo de espera */
        if( cf_locate("portmon.sleep_time", buf) > 0 )
        {
		int iTime;
		sscanf( buf, "%d", &iTime );
		ODebug("SLEEP_TIME[%d] secs\n", iTime );

		set_sleep_time( iTime );
        }
        else
        {
                ODebug("Nao foi possivel localizar o parametro 'portmon.sleep_time'\n");
                syslg("PRT-M: Nao foi possivel localizar o parametro 'portmon.sleep_time'\n");
		cf_close();
                return -1;
        }
		
		/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - INICIO */
		/* Localiza o parametro de Qtde MAX de Portas */
		char bufferParametro[2048] = {0};
		int qtdeMaximaPortasConfigurada = 0;				
        if( cf_locate("portmon.max_ports", bufferParametro) > 0 )
        {
			ODebug("portmon.max_ports [%s] \n", bufferParametro);
			 syslg("portmon.max_ports [%s] \n", bufferParametro);
			
			sscanf( bufferParametro, "%d", &qtdeMaximaPortasConfigurada );
			ODebug("MAX_PORTS[%d] \n", qtdeMaximaPortasConfigurada );
			 syslg("MAX_PORTS[%d] \n", qtdeMaximaPortasConfigurada );
	
			SetaQuantidadeMaximaPortas( qtdeMaximaPortasConfigurada );
        }
        else
        {
			SetaQuantidadeMaximaPortas( MAX_PORTS );
			ODebug("Nao foi possivel localizar o parametro 'portmon.max_ports'\n");
			 syslg("Nao foi possivel localizar o parametro 'portmon.max_ports'\n");
			 
			ODebug("Setando valor Default de [%d] portas \n", MAX_PORTS);
			syslg("Setando valor Default de [%d] portas \n", MAX_PORTS);
        }
		/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - Fim */

	cf_rewind();

	
	
	/* Localiza o parametro de configuracao das rotas */
        if( cf_locate("portmon.port", buf) > 0 )
        {
		do
		{
			char groupId[3] = {0};
			char route[45] = {0};
			char networkid[11] = {0};
			sscanf( buf, "%s\t%s\t%s", groupId, route, networkid );
                	ODebug("GROUP_ID[%02s] - ROUTE[%s] - NETWORKID[%010s]\n", groupId, route, networkid );

			/* Adiciona rota lida do arquivo */
			if( !addRoute( atoi(groupId), route, networkid ) )
			{
                		ODebug( "N�mero maximo de rotas excedido!!!\n" );
                		syslg( "N�mero maximo de rotas excedido!!!\n" );
				iRet = -1;
			}

		}while( cf_nextparm("portmon.port", buf) > 0 );
    	}
	else
	{
                ODebug("Nao foi possivel localizar o parametro 'portmon.port'\n");
                syslg("PRT-M: Nao foi possivel localizar o parametro 'portmon.port'\n");
    		cf_close();
		return -1;
	}

    	cf_close();


	/* Calcula a quantidade de grupos adicionados */
	stRGroup *gAux = &m_stRGroup[ 0 ];
	for( int i = 0; i < MAX_ROUTES; gAux++, i++ )
		m_iQtdeRoutes +=  gAux->id != -1 ? 1 : 0;


	ODebug("Leitura das configuracoes finalizada!\n");

	return 0;
} 

/*
 * Nome: addRoute
 * Descricao: Adiciona uma rota a lista de rotas
 * Parametros: Id do grupo, nome da porta, networkid
 * Retorno: 1 se sucesso, < 0 caso contratio
 */
int CPortmon::addRoute( int groupId, char* routeName, char* networkid )
{
	/* Pre-condicoes */
	assert( groupId >= 0 && groupId < MAX_ROUTES );


	/* Regra */
        int iRet = 1;
	stRGroup *gAux = &m_stRGroup[ groupId ];

	if( gAux == NULL )
	{
		ODebug("Lista de grupos indisponivel!\n");
		return -1;
	}


	/* Busca por um indice disponivel */
	int idx;
	/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - INICIO */
	int qtdeMaximaPortasObtida = 0;
        qtdeMaximaPortasObtida = ObtemQuantidadeMaximaPortas();
	ODebug("Numero de portas [%d] \n", qtdeMaximaPortasObtida);
	//for( idx = 0; gAux && gAux->routes[idx].enabled && idx < MAX_PORTS; idx++ );
	for( idx = 0; gAux && gAux->routes[idx].enabled && idx < qtdeMaximaPortasObtida; idx++ );
	/* 0649_SW - Acerto parametrizacao portmon - Quantidade/Ordem de portas - WRB - Fim */
	
	/* Inclui a rota no noh disponivel */
	gAux->id = groupId;
	strcpy( gAux->routes[idx].routeName, routeName );
	strcpy( gAux->routes[idx].networkid, networkid );
	gAux->qtdePorts++;
	gAux->routes[idx].enabled = 1;

        return iRet;
}

/*
 * Nome: updatePortStatus
 * Descricao: Atualiza o status da porta
 * Parametros: Porta
 * Retorno: 1
 */
int CPortmon::updatePortStatus( stRoute* route )
{

	/* Pre-condicoes */
	assert( route );


	/* Regra */
	int portStatus = 0;

	portStatus = m_cObjUtil.IsConnected( route->routeName );
	route->portStatus = portStatus;

	/* 0680_SW - Ajuste portmon - gerencia security - WRB -  INICIO*/

	/*ODebug("PORT[%s] is [%s]\n", route->routeName, route->portStatus ? "CONNECTED" : "DISCONNECTED" );*/

	if (route->portStatus == DISCONNECTED) 
	{
		ODebug("PORT[%s] is [%s]\n", route->routeName, "DISCONNECTED" );
	}
	else if (route->portStatus == CONNECTED) {
		
		ODebug("PORT[%s] is [%s]\n", route->routeName, "CONNECTED" );
	}
	else if (route->portStatus == STOPPED) {
		
		ODebug("PORT[%s] is [%s]\n", route->routeName, "STOPPED" );
	} 
	else
	{
		ODebug("PORT[%s] is [%s]\n", route->routeName, "STATUS NAO DEFINIDO" );
	}
	/* 0680_SW - Ajuste portmon - gerencia security - WRB -  FIM*/

    return portStatus;
}

/*
 * Nome: updateBinStatus
 * Descricao: Atualiza o status do networkid
 * Parametros: Porta
 * Retorno: 1
 */
int CPortmon::updateBinStatus( stRoute* route )
{

	/* Pre-condicoes */
	assert( route );

	/* Regra */
        int binStatus = 0;

        binStatus = m_cObjUtil.getBinStatus( route->networkid );
        route->binStatus = binStatus;

	ODebug("NETWORKID[%010s] is [%s]\n", route->networkid, binStatus ? "UP" : "DOWN" );

        return binStatus;
}

/*
 * Nome: execute
 * Descricao: Execucao principal das operacoes
 * Parametros: 
 * Retorno: 1
 */
int CPortmon::execute()
{
	/* Regra */
	int iRet = 1;

	stRGroup *gAux = &m_stRGroup[ 0 ];

	ODebug("======================================\n");
	for( int i = 0; i <= m_iQtdeRoutes; gAux++, i++ )
	{
		if( gAux->qtdePorts > 0 )
			ODebug("UPDATING STATUS FOR GROUP[%04d]...\n", gAux->id );

		for( int j = 0; gAux->routes[j].enabled && j < gAux->qtdePorts; j++ )
		{

			gAux->allPortStatus += updatePortStatus( &gAux->routes[j] );
			gAux->allBinStatus += updateBinStatus( &gAux->routes[j] );
		}

		if( gAux->qtdePorts > 0 ) executeRules( gAux );

		gAux->allPortStatus = gAux->allBinStatus = 0;
	}

	return iRet;
}

/*
 * Nome: executeRules
 * Descricao: Executa as regras para o grupo de rotas
 * Parametros: Grupo de rotas
 * Retorno: 1
 */
int CPortmon::executeRules( stRGroup* group )
{

	/* Pre-condicoes */
	assert( group );


	/* Regra */
        int iRet = 1;

	ODebug("APPLYING RULES FOR GROUP[%04d]...\n", group->id );

	/* 0503_SW - Acerto configuracao portmon 7.5 / Tratamento multiplos 'security' - Inicio - MTS */
	/* Adicionado tratamento para multiplos securitys. */
	if( !strncmp( group->routes[ 0 ].routeName, "security", 8 ) )
	{
		iRet = securityRules( group );
	}
	else if( !strcmp( group->routes[ 0 ].networkid, "2002202066" ) )
	{
		iRet = cupRules( group );
	}
	/* 0883_ONL - SW75 - Corre��o Portmon - Visa - WRB - INICIO */
	else if ( !strcmp( group->routes[ 0 ].networkid, "5000006207" ) || 
	          !strcmp( group->routes[ 0 ].networkid, "5100006207" ) || 
			  !strcmp( group->routes[ 0 ].networkid, "5200006207" ) || 
			  !strcmp( group->routes[ 0 ].networkid, "5300006207" ) )
	{
		iRet = visaRules( group );
	}		  
	/* 0883_ONL - SW75 - Corre��o Portmon - Visa - WRB - FIM */
	else
	{
		iRet = allRoutesRules( group );	
	}
	ODebug("======================================\n");
	/* 0503_SW - Acerto configuracao portmon 7.5 / Tratamento multiplos 'security' - Fim - MTS */

    return iRet;
}


/*
 *  ========================================================================
 *	Regras de Nogocio especificas
 *  ========================================================================
 *
 */


/*
 * Nome: allRoutesRules
 * Descricao: Execucao principal das operacoes
 * Parametros: Grupo de rotas
 * Retorno: 1
 */
int CPortmon::allRoutesRules( stRGroup* group )
{
	/* Pre-condicoes */
	assert( group );


	/* Regra */	
        int iRet = 1;

	/* Se todas as portas estiverem desconectadas, marca o networkid para DOWN */
        if(group->allPortStatus == DISCONNECTED)
        {
                if( m_cObjUtil.getBinStatus( group->routes[ 0 ].networkid ) == UP )
                {
                        ODebug("The ISSUER[%s] has been set to DOWN\n", group->routes[ 0 ].networkid );
                        m_cObjUtil.setBinStatus( group->routes[ 0 ].networkid, DOWN );
                        group->routes[ 0 ].binStatus = DOWN;
                }
        }
	/* Se ao menos uma porta estiver conectada, marca o bin para UP */
        else if( group->allPortStatus >= CONNECTED )
        {
                if( m_cObjUtil.getBinStatus( group->routes[ 0 ].networkid ) == DOWN )
                {
                        ODebug("The ISSUER[%s] has been set to UP\n", group->routes[ 0 ].networkid );
                        m_cObjUtil.setBinStatus( group->routes[ 0 ].networkid, UP );
                        group->routes[ 0 ].binStatus = UP;
                }
        }

	return iRet;
}

/* 0883_ONL - SW75 - Corre��o Portmon - Visa - WRB - INICIO */
/*
 * Nome: visaRules
 * Descricao: Execucao principal das operacoes
 * Parametros: Grupo de rotas
 * Retorno: 1
 */
int CPortmon::visaRules( stRGroup* group )
{
        /* Pre-condicoes */
        assert( group );


        /* Regra */
        int iRet = 1;

		/* Se todas as portas estiverem desconectadas, marca o networkid para DOWN */
        if (group->allPortStatus == DISCONNECTED || group->allPortStatus == STOPPED)
        {
                if( m_cObjUtil.getBinStatus( group->routes[ 0 ].networkid ) == UP )
                {
                        ODebug("The ISSUER[%s] has been set to DOWN\n", group->routes[ 0 ].networkid );
                        m_cObjUtil.setBinStatus( group->routes[ 0 ].networkid, DOWN );
                        group->routes[ 0 ].binStatus = DOWN;
                }
        }
		/* Se ao menos uma porta estiver conectada e o BIN estiver DOWN, envia sigon(0800) para a CUP */
        else if( group->allPortStatus >= CONNECTED )
        {
			if( m_cObjUtil.getBinStatus( group->routes[ 0 ].networkid ) == DOWN )
			{
               ODebug("The ISSUER[%s] has been set to UP\n", group->routes[ 0 ].networkid );
               m_cObjUtil.setBinStatus( group->routes[ 0 ].networkid, UP );
               group->routes[ 0 ].binStatus = UP;
			}
        }

        return iRet;
}
/* 0883_ONL - SW75 - Corre��o Portmon - Visa - WRB - FIM */

/*
 * Nome: cupRules
 * Descricao: Execucao principal das operacoes
 * Parametros: Grupo de rotas
 * Retorno: 1
 */
int CPortmon::cupRules( stRGroup* group )
{
        /* Pre-condicoes */
        assert( group );


        /* Regra */
        int iRet = 1;

	/* Se todas as portas estiverem desconectadas, marca o networkid para DOWN */
        if(group->allPortStatus == DISCONNECTED)
        {
                if( m_cObjUtil.getBinStatus( group->routes[ 0 ].networkid ) == UP )
                {
                        ODebug("The ISSUER[%s] has been set to DOWN\n", group->routes[ 0 ].networkid );
                        m_cObjUtil.setBinStatus( group->routes[ 0 ].networkid, DOWN );
                        group->routes[ 0 ].binStatus = DOWN;
                }
        }
	/* Se ao menos uma porta estiver conectada e o BIN estiver DOWN, envia sigon(0800) para a CUP */
        else if( group->allPortStatus >= CONNECTED )
        {
			if( m_cObjUtil.getBinStatus( group->routes[ 0 ].networkid ) == DOWN )
			{
				ODebug("Sending signon-start to networkid [%010s]\n", group->routes[ 0 ].networkid ); 
				system("shccmd send signon-start to 05 2002202066  > /dev/null");
			}
        }

        return iRet;
}

/*
 * Nome: securityRules
 * Descricao: Execucao principal das operacoes
 * Parametros: Grupo de rotas
 * Retorno: 1
 */
int CPortmon::securityRules( stRGroup* group )
{
	/* Pre-condicoes */
	assert( group );

	/* Regra */
	int iRet = 1;
	
	OCString cmdStr;
	
	/* 0503_SW - Acerto configuracao portmon 7.5 / Tratamento multiplos 'security' - Inicio - MTS */
	/* Se todas as portas estiverem desconectadas, reconecta uma por uma. */
    if( group->allPortStatus == DISCONNECTED )
    {
		for( int j = 0; group->routes[j].enabled && j < group->qtdePorts; j++ )
		{

			ODebug("Reconnecting [%s]...\n", group->routes[ j ].routeName );
			
			cmdStr = OCString("mbportcmd stop ") + OCString( group->routes[ j ].routeName ) + OCString(" > /dev/null \n");
			/* ODebug( "mbportcmd stop %s > /dev/null \n", group->routes[ j ].routeName ); */
			system( cmdStr );
			
			cmdStr = OCString("mbportcmd start ") + OCString( group->routes[ j ].routeName ) + OCString(" > /dev/null \n");
			/* ODebug( "mbportcmd start %s > /dev/null \n", group->routes[ j ].routeName ); */
			system( cmdStr );
			
		}    
	}
	/* 0503_SW - Acerto configuracao portmon 7.5 / Tratamento multiplos 'security' - Inicio - MTS */
	/* 0620_SW - Ajuste tratamento individual portas "security" - WRB -  INICIO */
	else
	{	
		for( int k = 0; group->routes[k].enabled && k < group->qtdePorts; k++ )
		{
			/* 0680_SW - Ajuste portmon - gerencia security - WRB -  INICIO*/
			if ( group->routes[k].portStatus != STOPPED )
			{
			/* 0680_SW - Ajuste portmon - gerencia security - WRB -  FIM*/
				if( !group->routes[k].portStatus )
				{
					ODebug("Reconnecting [%s]...\n", group->routes[k].routeName );
					
					cmdStr = OCString("mbportcmd stop ") + OCString( group->routes[k].routeName ) + OCString(" > /dev/null \n");
					system( cmdStr );
					syslg(cmdStr);
					sleep( 1 );
					cmdStr = OCString("mbportcmd start ") + OCString( group->routes[k].routeName ) + OCString(" > /dev/null \n");
					system( cmdStr );
					syslg(cmdStr);
				}
			}
		}
	}
	/* 0620_SW - Ajuste tratamento individual portas "security" - WRB -  FIM */

    return iRet;
}
