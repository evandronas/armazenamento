static char ver[]="ScanQueue 0.0.2 27Abr2021";

/*  Nome do programa : Scan Queue
 *  Executavel gerado : scQueue
 */

/*
 *  This program executes as a task. It have this functions:
 *     - Verify a queue load and clean it if a limit was reached;
 *     - Generate a 'killfile' to be used by SHSWKILLPROC.sh to kill a task 
 *       that limit of enqueue occurrences is reached. 
 *     - Execute a stop/start in a port that that limit of enqueue occurrences 
         is reached. 
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  18/05/2011  Change cfg file from 'istparam.cfg' to 'scQueue.cfg'
 *  696248  10/06/2011  Port to 7.5
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */


/* Includes do produto*/
 
#include <oasis.h>
#include <syslg.h>
#include <mb.h>
#include <shc.h>                                          /* Adicionado para 7.5 */

/* Includes do sistema operacional*/
 
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/msg.h>


/* ID_22849 - SWLOGGER - INI */
#include <LibSWLogger.hpp>

using namespace SWLOGGER;
using namespace std;
/* ID_22849 - SWLOGGER - FIM */	

/* Definicoes incluidas - AWS - Inicio */
#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif
/* Definicoes incluidas - AWS - Fim */

/* Definicoes do sistema */
#define TASK_NAME_LEN            30
#define PORTS_NAME_LEN           30
#define MAX_TASKS               100
#define MAX_PORTS               100
#define QTDE_EXCLUDED_MBOX        1

/* Valores padrao do sistema */
/* Valores para limpeza das filas */
#define DEFAULT_SLEEP_TIME                3
#define DEFAULT_MIN_QUEUE_SIZE			 15
#define DEFAULT_MAX_QUEUE_SIZE          100

/* Valores para tratamento de tasks/portas */
#define DEFAULT_TIME_INTERVAL           600               /* 10 minutos, 60 segundos.*/
#define DEFAULT_MAX_OCCURRENCES           3
#define DEFAULT_EXECUTE_KILL_TASKS    FALSE
#define DEFAULT_EXECUTE_STR_STP_PORTS FALSE

/* Globais */
/* Tasks eleitas */
struct elegible_tasks
{
	char name [TASK_NAME_LEN+1];    					  /* nome da task.*/
	char queue [MB_MAX_NAME+1];     					  /* nome da fila associada a task. */
	int occurrences;                                      /* qtde de enfileiramentos da task dentro do intervalo 
	                                                         de tempo 'time_interval'*/
	time_t last_occurrence;          					  /* data da ultima ocorrencia de enfileiramento.*/
	time_t first_occurrence;         					  /* data da primeira ocorrencia de enfileiramento. 
	                                                         valor de trabalho.*/
};

/* Mailboxes excluidos */
struct excluded_mbox
{
	char mailbox [MB_MAX_NAME+1];     					  /* nome do mailbox. */
};

/* Portas eleitas */
struct elegible_ports
{
	char name [PORTS_NAME_LEN+1];    					  /* nome da porta.*/
	int occurrences;		                    		  /* qtde de enfileiramentos da porta dentro do intervalo 
	                                                         de tempo 'time_interval'*/
	time_t last_occurrence;        		    			  /* data da ultima ocorrencia de enfileiramento.*/
	time_t first_occurrence;       			    		  /* data da primeira ocorrencia de enfileiramento. 
	                                                         valor de trabalho.*/
};

const char *excluded_mbox_default_list[] = {	     			  /* lista padrao de mailboxes excluidos.*/
	"SystemRequest"
	};

struct elegible_tasks elegible_task_list[MAX_TASKS + 1];  /* lista de tasks elegiveis.*/
struct excluded_mbox excluded_mbox_list[MAX_TASKS + 1];   /* lista de mailboxes excluidos.*/
struct elegible_ports elegible_port_list[MAX_PORTS + 1];  /* lista de portas elegiveis.*/
int sleep_time            = DEFAULT_SLEEP_TIME;           /* intervalo de tempo para nova verificacao da fila.*/
int min_Queue_size		  = DEFAULT_MIN_QUEUE_SIZE;		  /* tamanho minimo da fila.*/
int max_Queue_size        = DEFAULT_MAX_QUEUE_SIZE;       /* tamanho maximo da fila.*/
int max_occurrences       = DEFAULT_MAX_OCCURRENCES;      /* quantidade maxima de ocorrencias de enfileiramento
                                                             em um intervalo de tempo 'time_interval'.*/
int time_interval         = DEFAULT_TIME_INTERVAL;        /* intervalo de tempo considerado para 'alerta' de 
                                                             ocorrencias de enfileiramento.*/
int execute_kill_tasks    = DEFAULT_EXECUTE_KILL_TASKS;   /* gera ou nao arquivo para matar tasks cuja ocorrencia de
                                                             enfileiramento foi superior a 'max_occurrences'.*/
int execute_str_stp_ports = DEFAULT_EXECUTE_STR_STP_PORTS;/* realiza start/stop em portas cuja ocorrencia de 
                                                             enfileiramento foi superior a 'max_occurrences'.*/
int qtde_excluded_mbox_default = QTDE_EXCLUDED_MBOX;	  /* quantidade de mailboxes padrao excluiveis. */
int tasks_index           = 0;                            /* quantidade de tasks carregadas do cfg. */
int excluded_mbox_index   = 0;							  /* quantidade de mailboxes excluidos carregadas do cfg. */
int ports_index           = 0;                            /* quantidade de portas carregadas do cfg. */

/* Prototipos */
void init_param(void);
int is_mailbox_up(void);
void scan_Queue(void);
void is_elegible_task(int Queue_Id, int task_queue_size);
void is_elegible_port(int Queue_Id);
void prog_exit(int n);
int is_mbox_exists(char *mailbox);
int is_mbox_excluded(char *mailbox);
int check_queue_balance(int Queue_Id);

/* Funcoes importadas do fonte 'gen.c' 7.1 */

long GetQueueSize();
int shc_initsys();

/**********************************************************
 * int main(int argc, char *argv[])                       *
 * Inicio do processamento.                               *
 **********************************************************/
int main(int argc, char *argv[])
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "main", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */
	
	char debfile[80];

	syslg_setargv0(argv[0]);
	
	catch_all_signals(prog_exit);

    	sprintf(debfile, "%s.debug",  argv[0]);
    	debug_on(debfile);

	ODebug("===========================================\n");
	ODebug("%s\n",ver);
	ODebug("Number of arguments: %d\n", argc);
	ODebug("===========================================\n");
	
	init_param();

	if (is_mailbox_up())
	{
		scan_Queue();
	}
	else
	{
		syslg("S-QUE: Mailbox inativo.\n");
		ODebug("Mailbox inativo.\n");
	}
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "main", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */
	
	prog_exit(0);
}

/**********************************************************
 * void init_param(void)                                  *
 * Obtem os parametros de configuracao do programa. Caso  *
 * nao sejam localizados tanto o istparam.cfg qto os      *
 * parametros serao utilizados os valores DEFAULT para as *
 * variaveis 'basicas' do programa.                       *
 **********************************************************/
void init_param(void)
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "init_param", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */
	
	char aux_tasks[255];
	char aux_excluded_mbox[255];
	char aux_port[255];
	char task_name[TASK_NAME_LEN+1];
	char queue_name[MB_MAX_NAME+1];
	int count_excluded_mbox = 0;
	int param_time;
	int mbox_exists = 0;
    	char cfgpath[64];

    	memset(cfgpath, 0, sizeof(cfgpath));
	sprintf(cfgpath,"%s/cfg/scQueue.cfg", getenv("FE_ROOT"));
	
	/* Carga da lista padrao de tasks excluidas. Ela ocorre independente de existir ou nao configuracao.*/
	ODebug("===========================================\n");
	ODebug("INICIO DA CARGA DE CONFIGURACOES. Site [%s]\n", getenv("SITE"));
	ODebug("===========================================\n");	
	syslg("S-QUE: Inicio da carga de configuracoes.\n");

	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "S-QUE: Inicio da carga de configuracoes" ) );
	/* ID_22849 - SWLOGGER - FIM */
	
	ODebug("Carregando lista padrao de mailboxes excluidos.\n");
	syslg("S-QUE: Carregando lista padrao de mailboxes excluidos.\n");
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "S-QUE: Carregando lista padrao de mailboxes excluidos" ) );
	/* ID_22849 - SWLOGGER - FIM */	
	
	for (count_excluded_mbox = 0; count_excluded_mbox < qtde_excluded_mbox_default; count_excluded_mbox ++)
	{
		/* Atribuindo os valores padr�o. */
		strcpy(excluded_mbox_list[excluded_mbox_index].mailbox, excluded_mbox_default_list[count_excluded_mbox]);
		ODebug("scan_Queue.excluded_mbox:         [%s]\n", excluded_mbox_list[excluded_mbox_index].mailbox);
		syslg("S-QUE: scan_Queue.excluded_mbox:         [%s]\n", excluded_mbox_list[excluded_mbox_index].mailbox);
		
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: scan_Queue.excluded_mbox:         [%s]\n", excluded_mbox_list[excluded_mbox_index].mailbox);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */	
	
		++excluded_mbox_index;
	}
		
	ODebug("Buscando scQueue.cfg\n");
	syslg("S-QUE: Buscando scQueue.cfg\n");	
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "S-QUE: Carregando lista padrao de mailboxes excluidos" ) );
	/* ID_22849 - SWLOGGER - FIM */	
	
	/* Busca os parametros para funcionamento do programa.*/

	if ((cf_openfile(cfgpath)) < 0)
	{
		/* Visto que nao foi localizado scQueue.cfg, o programa opere somente sua funcao basica, ou seja,
           limpeza de filas.*/
		
		ODebug("Arquivo de configuracao 'scQueue.cfg' nao encontrado. Utilizara valores padrao:\n");
		syslg("S-QUE: Arquivo de configuracao 'scQueue.cfg' nao encontrado. Utilizara valores padrao:\n");
		/* ID_22849 - SWLOGGER - INI */
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "S-QUE: Arquivo de configuracao 'scQueue.cfg' nao encontrado. Utilizara valores padrao:" ) );
		/* ID_22849 - SWLOGGER - FIM */		
		
		ODebug("scan_Queue.sleep_time:            [%d]\n", sleep_time);
		syslg("S-QUE: scan_Queue.sleep_time:            [%d]\n", sleep_time);
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: scan_Queue.sleep_time:            [%d]\n", sleep_time);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */			
		
		ODebug("scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		syslg("S-QUE: scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.sleep_time:            [%d]\n", sleep_time);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */					
		
		ODebug("scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		syslg("S-QUE: scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */		
		
		ODebug("scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		syslg("S-QUE: scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */		
		
		ODebug("scan_Queue.time_interval:         [%d]\n", time_interval);
		syslg("S-QUE: scan_Queue.time_interval:         [%d]\n", time_interval);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.time_interval:         [%d]\n", time_interval);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */		
		
		ODebug("scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
		syslg("S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */		
		
		ODebug("scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		syslg("S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */		
		
		ODebug("===========================================\n");
		ODebug("FIM DA CARGA DE CONFIGURACOES.\n");		
		ODebug("===========================================\n");

		/* Nada mais a setar.*/
		return;
	}
	else
	{
		ODebug("Localizado scQueue.cfg. Buscando parametros.\n");
		syslg("S-QUE: Localizado scQueue.cfg. Buscando parametros.\n");
		/* ID_22849 - SWLOGGER - INI */
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "S-QUE: Localizado scQueue.cfg. Buscando parametros" ) );
		/* ID_22849 - SWLOGGER - FIM */			
	}
	
	/* Localizado istparam.cfg */
	/* Obtendo sleep_time */
	if (cf_locatenum("scan_Queue.sleep_time", &sleep_time) < 0) 
	{
		ODebug("Parametro 'scan_Queue.sleep_time' nao encontrado. Utilizando valor padrao.\n");
		syslg("S-QUE: Parametro 'scan_Queue.sleep_time' nao encontrado. Utilizando valor padrao.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Parametro 'scan_Queue.sleep_time' nao encontrado. Utilizando valor padrao.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */					

		ODebug("scan_Queue.sleep_time:            [%d]\n", sleep_time);
		syslg("S-QUE: scan_Queue.sleep_time:            [%d]\n", sleep_time);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.sleep_time:            [%d]\n", sleep_time);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */			
	}
	else
	{
		ODebug("scan_Queue.sleep_time:            [%d]\n", sleep_time);
		syslg("S-QUE: scan_Queue.sleep_time:            [%d]\n", sleep_time);
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: scan_Queue.sleep_time:            [%d]\n", sleep_time);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */					
	}

	/* Obtendo min_Queue_size */
	if (cf_locatenum("scan_Queue.min_Queue_size", &min_Queue_size) < 0) 
	{
		ODebug("Parametro 'scan_Queue.min_Queue_size' nao encontrado. Utilizando valor padrao.\n");
		syslg("S-QUE: Parametro 'scan_Queue.min_Queue_size' nao encontrado. Utilizando valor padrao.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Parametro 'scan_Queue.min_Queue_size' nao encontrado. Utilizando valor padrao.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */				

		ODebug("scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		syslg("S-QUE: scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */	

	}
	else
	{
		ODebug("scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		syslg("S-QUE: scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */				
	}

	/* Obtendo max_Queue_size */
	if (cf_locatenum("scan_Queue.max_Queue_size", &max_Queue_size) < 0) 
	{
		ODebug("Parametro 'scan_Queue.max_Queue_size' nao encontrado. Utilizando valor padrao.\n");
		syslg("S-QUE: Parametro 'scan_Queue.max_Queue_size' nao encontrado. Utilizando valor padrao.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Parametro 'scan_Queue.max_Queue_size' nao encontrado. Utilizando valor padrao.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */				
		
		ODebug("scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		syslg("S-QUE: scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
	}
	else
	{
		ODebug("scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		syslg("S-QUE: scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */					
	}
	
	/* Caso a o valor 'min_Queue_size' seja superior ao 'max_Queue_size'.*/
	if (max_Queue_size < min_Queue_size)
	{
		ODebug("Valor do parametro 'max_Queue_size' inferior ao parametro 'min_Queue_size'. Igualando.\n");
		syslg("S-QUE: Valor do parametro 'max_Queue_size' inferior ao parametro 'min_Queue_size'. Igualando.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Valor do parametro 'max_Queue_size' inferior ao parametro 'min_Queue_size'. Igualando.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */				
		
		min_Queue_size = max_Queue_size;

		ODebug("scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		syslg("S-QUE: scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.min_Queue_size:        [%d]\n", min_Queue_size);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
		
		ODebug("scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		syslg("S-QUE: scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.max_Queue_size:        [%d]\n", max_Queue_size);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
	}

	/* Obtendo max_occurrences */
	if (cf_locatenum("scan_Queue.max_occurrences", &max_occurrences) < 0) 
	{
		ODebug("Parametro 'scan_Queue.max_occurrences' nao encontrado. Utilizando valor padrao.\n");
		syslg("S-QUE: Parametro 'scan_Queue.max_occurrences' nao encontrado. Utilizando valor padrao.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Parametro 'scan_Queue.max_occurrences' nao encontrado. Utilizando valor padrao.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */				

		ODebug("scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		syslg("S-QUE: scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */					
	}
	else
	{
		ODebug("scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		syslg("S-QUE: scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: scan_Queue.max_occurrences:       [%d]\n", max_occurrences);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */			
	}

	/* Obtendo time_interval */	
	if (cf_locatenum("scan_Queue.time_interval", &param_time) < 0) 
	{
		ODebug("Parametro 'scan_Queue.time_interval' nao encontrado. Utilizando valor padrao.\n");
		syslg("S-QUE: Parametro 'scan_Queue.time_interval' nao encontrado. Utilizando valor padrao.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Parametro 'scan_Queue.time_interval' nao encontrado. Utilizando valor padrao.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */			

		ODebug("scan_Queue.time_interval:         [%d]\n", time_interval);
		syslg("S-QUE: scan_Queue.time_interval:         [%d]\n", time_interval);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.time_interval:         [%d]\n", time_interval);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
	}	
	else
	{
		/* O tempo e dado em minutos entao a conversao e necessaria.*/
		time_interval = param_time * 60;
		ODebug("scan_Queue.time_interval:         [%d]\n", time_interval);
		syslg("S-QUE: scan_Queue.time_interval:         [%d]\n", time_interval);
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: scan_Queue.time_interval:         [%d]\n", time_interval);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */				
	}

	/* Obtendo execute_kill_tasks */
	if (cf_locatenum("scan_Queue.execute_kill_tasks", &execute_kill_tasks) < 0) 
	{
		ODebug("Parametro 'scan_Queue.execute_kill_tasks' nao encontrado. Utilizando valor padrao.\n");
		syslg("S-QUE: Parametro 'scan_Queue.execute_kill_tasks' nao encontrado. Utilizando valor padrao.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Parametro 'scan_Queue.execute_kill_tasks' nao encontrado. Utilizando valor padrao.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */				

		ODebug("scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
		syslg("S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */				
	}
	else
	{
		/* Tratamento caso o valor do parametro 'execute_kill_tasks' esteja fora do dominio '0' e '1'.*/
		if (execute_kill_tasks == 0 || execute_kill_tasks == 1)
		{
			ODebug("scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
			syslg("S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
			/* ID_22849 - SWLOGGER - INI */
			char msg[256] = {0};
			sprintf( msg, "S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
			/* ID_22849 - SWLOGGER - FIM */					
		}
		else
		{
			ODebug("Valor do parametro 'scan_Queue.execute_kill_tasks' fora do dom�nio (%d). Utilizando valor padrao.\n", 
			        execute_kill_tasks);
			syslg("S-QUE: Valor do parametro 'scan_Queue.execute_kill_tasks' fora do dom�nio (%d). Utilizando valor padrao.\n", 
			        execute_kill_tasks);
			/* ID_22849 - SWLOGGER - INI */
			char msg[256] = {0};
			sprintf( msg, "S-QUE: Valor do parametro 'scan_Queue.execute_kill_tasks' fora do dom�nio (%d). Utilizando valor padrao.\n", 
			        execute_kill_tasks);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
			/* ID_22849 - SWLOGGER - FIM */							

			execute_kill_tasks = DEFAULT_EXECUTE_KILL_TASKS;
			ODebug("scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
			syslg("S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
			/* ID_22849 - SWLOGGER - INI */
			sprintf( msg, "S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
			/* ID_22849 - SWLOGGER - FIM */				
		}
	}

	/* Obtendo execute_str_stp_ports */
	if (cf_locatenum("scan_Queue.execute_str_stp_ports", &execute_str_stp_ports) < 0) 
	{
		ODebug("Parametro 'scan_Queue.execute_str_stp_ports' nao encontrado. Utilizando valor padrao.\n");
		syslg("S-QUE: Parametro 'scan_Queue.execute_str_stp_ports' nao encontrado. Utilizando valor padrao.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Parametro 'scan_Queue.execute_str_stp_ports' nao encontrado. Utilizando valor padrao.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
		/* ID_22849 - SWLOGGER - FIM */				

		ODebug("scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		syslg("S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
	}
	else
	{
		/* Tratamento caso o valor do parametro 'execute_str_stp_ports' esteja fora do dominio '0' e '1'.*/
		if (execute_str_stp_ports == 0 || execute_str_stp_ports == 1)
		{
			ODebug("scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
			syslg("S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
			/* ID_22849 - SWLOGGER - INI */
			char msg[256] = {0};
			sprintf( msg, "S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
			/* ID_22849 - SWLOGGER - FIM */				
		}
		else
		{
			ODebug("Valor do parametro 'scan_Queue.execute_str_stp_ports' fora do dom�nio (%d). Utilizando valor padrao.\n", 
			        execute_str_stp_ports);
			syslg("S-QUE: Valor do parametro 'scan_Queue.execute_str_stp_ports' fora do dom�nio (%d). Utilizando valor padrao.\n", 
			        execute_str_stp_ports);
			/* ID_22849 - SWLOGGER - INI */
			char msg[256] = {0};
			sprintf( msg, "S-QUE: Valor do parametro 'scan_Queue.execute_str_stp_ports' fora do dom�nio (%d). Utilizando valor padrao.\n", 
			        execute_str_stp_ports);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
			/* ID_22849 - SWLOGGER - FIM */							

			execute_str_stp_ports = DEFAULT_EXECUTE_STR_STP_PORTS;
			ODebug("scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
			syslg("S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
			/* ID_22849 - SWLOGGER - INI */
			sprintf( msg, "S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
			/* ID_22849 - SWLOGGER - FIM */				
		}
	}
	
	/* Obtem e preenche lista de tasks elegiveis.*/	
	cf_rewind();
	
	if (cf_locate("scan_Queue.elegible_task", aux_tasks) > 0)
	{
		do {
			if (tasks_index <= MAX_TASKS)
			{
				/* Quebrando parametro lido.*/
				if (sscanf (aux_tasks, "%s %s", task_name, queue_name) == 2)
				{
					strcpy(elegible_task_list[tasks_index].name, task_name);
					strcpy(elegible_task_list[tasks_index].queue, queue_name);
					ODebug("scan_Queue.elegible_task:         [%s - %s]\n", 
					       elegible_task_list[tasks_index].name, elegible_task_list[tasks_index].queue);
					syslg("S-QUE: scan_Queue.elegible_task:         [%s - %s]\n", 
					       elegible_task_list[tasks_index].name, elegible_task_list[tasks_index].queue);
					/* ID_22849 - SWLOGGER - INI */
					char msg[256] = {0};
					sprintf( msg, "S-QUE: scan_Queue.elegible_task:         [%s - %s]\n", 
					       elegible_task_list[tasks_index].name, elegible_task_list[tasks_index].queue);
					executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );
					/* ID_22849 - SWLOGGER - FIM */								   
					++tasks_index;
				}
				else
				{
					ODebug("Formatacao incorreta do parametro 'elegible_task'. Buscando proxima ocorrencia.\n");
				}
			}
			else
			{
				ODebug("Quantidade maxima de tasks alcancada. Finalizando leitura ...\n");
				return;
			}
			
		} while (cf_nextparm("scan_Queue.elegible_task", aux_tasks) > 0);
	}
	else
	{
		/* Nao foi localizada nenhuma task para matar, entao a execucao da funcao 'is_elegible_task' nao sera 
		   realizada.*/
		ODebug("Nenhuma ocorrencia do parametro 'scan_Queue.elegible_task' encontrada. Desligando execucao da funcao 'is_elegible_task'.\n");
		syslg("S-QUE: Nenhuma ocorrencia do parametro 'scan_Queue.elegible_task' encontrada. Desligando execucao da funcao 'is_elegible_task'.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Nenhuma ocorrencia do parametro 'scan_Queue.elegible_task' encontrada. Desligando execucao da funcao 'is_elegible_task'.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */	
					
		execute_kill_tasks    = DEFAULT_EXECUTE_KILL_TASKS;
		ODebug("scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
		syslg("S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);		
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.execute_kill_tasks:    [%d]\n", execute_kill_tasks);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
	}

	/* Obtem e preenche lista de mailboxes excluidos.*/	
	cf_rewind();
	
	if (cf_locate("scan_Queue.excluded_mbox", aux_excluded_mbox) > 0)
	{
		do {
			if (excluded_mbox_index <= MAX_TASKS)
			{
				/* Verifica se o mailbox excluido ja esta na memoria. Caso ja esteja, nao a inclui
				   novamente.*/
				   
				mbox_exists = is_mbox_exists(aux_excluded_mbox);
				if (mbox_exists)
				{
					ODebug("O mailbox '%s' ja foi carregado, buscando o proximo.\n", aux_excluded_mbox);
					syslg("S-QUE: O mailbox '%s' ja foi carregado, buscando o proximo.\n", aux_excluded_mbox);
					/* ID_22849 - SWLOGGER - INI */
					char msg[256] = {0};
					sprintf( msg, "S-QUE: O mailbox '%s' ja foi carregado, buscando o proximo.\n", aux_excluded_mbox);
					executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
					/* ID_22849 - SWLOGGER - FIM */						
					mbox_exists = 0;
				}
				else
				{
					strcpy(excluded_mbox_list[excluded_mbox_index].mailbox, aux_excluded_mbox);
					ODebug("scan_Queue.excluded_mbox:         [%s]\n", excluded_mbox_list[excluded_mbox_index].mailbox);
					syslg("S-QUE: scan_Queue.excluded_mbox:         [%s]\n", excluded_mbox_list[excluded_mbox_index].mailbox);
					/* ID_22849 - SWLOGGER - INI */
					char msg[256] = {0};
					sprintf( msg, "S-QUE: scan_Queue.excluded_mbox:         [%s]\n", excluded_mbox_list[excluded_mbox_index].mailbox);
					executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
					/* ID_22849 - SWLOGGER - FIM */		
					
					++excluded_mbox_index;
					mbox_exists = 0;
				}
			}
			else
			{
				ODebug("Quantidade maxima de mailboxes alcancada. Finalizando leitura ...\n");
				return;
			}
			
		} while (cf_nextparm("scan_Queue.excluded_mbox", aux_excluded_mbox) > 0);
	}
	else
	{
		/* Nao foi localizada nenhum mailbox excluivel, entao serao utilizadas as tasks DEFAULT.*/
		ODebug("Nenhuma ocorrencia do parametro 'scan_Queue.excluded_mbox' encontrada no arquivo de configuracao. Ser� utilizada apenas a lista padrao.\n");
		syslg("S-QUE: Nenhuma ocorrencia do parametro 'scan_Queue.excluded_mbox' encontrada no arquivo de configuracao. Ser� utilizada apenas a lista padrao.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Nenhuma ocorrencia do parametro 'scan_Queue.excluded_mbox' encontrada no arquivo de configuracao. Ser� utilizada apenas a lista padrao.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
	}
	
	/* Obtem e preenche lista de portas elegiveis.*/	
	cf_rewind();
	
	if (cf_locate("scan_Queue.elegible_port", aux_port) > 0)
	{
		do {
			if (ports_index <= MAX_PORTS)
			{
				strcpy(elegible_port_list[ports_index].name, aux_port);
				ODebug("scan_Queue.elegible_port:         [%s]\n", elegible_port_list[ports_index].name);
				syslg("S-QUE: scan_Queue.elegible_port:         [%s]\n", elegible_port_list[ports_index].name);
				/* ID_22849 - SWLOGGER - INI */
				char msg[256] = {0};
				sprintf( msg, "S-QUE: scan_Queue.elegible_port:         [%s]\n", elegible_port_list[ports_index].name);
				executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
				/* ID_22849 - SWLOGGER - FIM */					
				++ports_index;
			}
			else
			{
				ODebug("Quantidade maxima de portas alcancada. Finalizando leitura ...\n");
				syslg("S-QUE: Quantidade maxima de portas alcancada. Finalizando leitura ...\n");
				/* ID_22849 - SWLOGGER - INI */
				char msg[256] = {0};
				sprintf( msg, "S-QUE: Quantidade maxima de portas alcancada. Finalizando leitura ...\n");
				executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
				/* ID_22849 - SWLOGGER - FIM */						
				return;
			}
		} while (cf_nextparm("scan_Queue.elegible_port", aux_port) > 0);
	}
	else
	{
		/* Nao foi localizada nenhuma porta para start/stop, entao a execucao da funcao 'is_elegible_port' nao sera 
		   realizada.*/
		ODebug("Nenhuma ocorrencia do parametro 'scan_Queue.elegible_port' encontrada. Desligando execucao da funcao 'is_elegible_port'.\n");
		syslg("S-QUE: Nenhuma ocorrencia do parametro 'scan_Queue.elegible_port' encontrada. Desligando execucao da funcao 'is_elegible_port'.\n");
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Nenhuma ocorrencia do parametro 'scan_Queue.elegible_port' encontrada. Desligando execucao da funcao 'is_elegible_port'.\n");
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */		
				
		execute_str_stp_ports = DEFAULT_EXECUTE_STR_STP_PORTS;
		ODebug("scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		syslg("S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: scan_Queue.execute_str_stp_ports: [%d]\n", execute_str_stp_ports);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
	}	

	ODebug("===========================================\n");
	ODebug("FIM DA CARGA DE CONFIGURACOES.\n");		
	ODebug("===========================================\n");
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "init_param", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */	
	return;
}

/**********************************************************
 * int is_mailbox_up(void)                                *
 * Inicializacao de mail boxes para o sistema.            *
 **********************************************************/
int is_mailbox_up(void)
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_mailbox_up", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */	
	
	static int init_done = 0;
	
	if (mb_test() < 0) 
	{
		ODebug("Teste de mailbox falhou!\n");
		syslg("Teste de mailbox falhou!\n");	
		/* ID_22849 - SWLOGGER - INI */
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "Teste de mailbox falhou!" ) );		
		/* ID_22849 - SWLOGGER - FIM */		
		
		if (init_done)
		{
			ODebug("O status do IST mudou para DOWN!\n");
			syslg("O status do IST mudou para DOWN!\n");
			/* ID_22849 - SWLOGGER - INI */
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "O status do IST mudou para DOWN!" ) );		
			/* ID_22849 - SWLOGGER - FIM */				
			mb_release_resources();
		}
		else
		{
			ODebug("O stauts do IST eh DOWN!\n");
			syslg("O stauts do IST eh DOWN!\n");
			/* ID_22849 - SWLOGGER - INI */
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "O stauts do IST eh DOWN!" ) );		
			/* ID_22849 - SWLOGGER - FIM */				
			init_done = 0;
		}
	}
	else 
	{
		ODebug("Teste de mailbox com sucesso!\n");
		syslg("Teste de mailbox com sucesso!\n");
		/* ID_22849 - SWLOGGER - INI */
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "Teste de mailbox com sucesso!" ) );		
		/* ID_22849 - SWLOGGER - FIM */			
		if (!init_done) 
		{
			sleep(40);		/* to ensure mb is up */
			if (mb_initsys() == 0) 
			{
				if (shc_initsys() < 0)
				{
					ODebug("shc_initsys falhou!\n");
					syslg("shc_initsys falhou!\n");
					/* ID_22849 - SWLOGGER - INI */
					executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "shc_initsys falhou!" ) );		
					/* ID_22849 - SWLOGGER - FIM */						
					mb_release_resources();
				}
				else 
				{
					ODebug("O stauts do IST eh UP!\n");
					syslg("O stauts do IST eh UP!\n");
					/* ID_22849 - SWLOGGER - INI */
					executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "O stauts do IST eh UP!" ) );		
					/* ID_22849 - SWLOGGER - FIM */						
					init_done = 1;
				}
			}
			else
			{
				ODebug("mb_initsys falhou!\n");
				syslg("mb_initsys falhou!\n");
				/* ID_22849 - SWLOGGER - INI */
				executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "mb_initsys falhou!" ) );		
				/* ID_22849 - SWLOGGER - FIM */					
				init_done = 0;
			}	
		}
	}

	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_mailbox_up", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */		
	return (init_done);
}

/**********************************************************
 * void scan_Queue(void)                                  *
 * Varre as filas para afim de determinar se elas precisam*
 * ser limpas. Chama as funcoes 'is_elegible_tasks' e     *
 * 'is_elegible_port' que determinam se e necessario      *
 * processamento adicional para a fila tratada. Chama     *
 * tambem as funcoes 'is_mbox_excluded' e                 *
 * 'check_queue_balance' com a finalidade de verificar se *
 * deve ser tomada acao sobre a fila tratada.             *
 **********************************************************/
void scan_Queue(void)
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "scan_Queue", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */	
	
	char IsMbAtt=FALSE;
	char wakeUPfile[255];
	int processing_queue_size = 0;
	FILE *wkF;
	char mbAtt[3];
	time_t now;
	struct tm  ts;
	char DataHora[20];
	char command[255];
	int ret;

	ODebug("scan_Queue - INICIO\n");
	syslg("S-QUE: scan_Queue - INICIO\n");
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) LogInitialization( "SCQUEUE","S-QUE: scan_Queue - INICIO" ) );		
	/* ID_22849 - SWLOGGER - FIM */			
	ODebug("===========================================\n");
	
	sprintf(wakeUPfile,"%s/sys/mommb_enfileirado_%s.log",
			getenv("OLOGDIR"),getenv("SITE"));
	
	if ((wkF = fopen(wakeUPfile,"a")) == NULL)
	{
		ODebug("Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",wakeUPfile);
		syslg("S-QUE: Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",wakeUPfile);
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",wakeUPfile);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */				
	}
	else
	{
		ODebug("Arquivo %s criado/aberto com sucesso.\n",wakeUPfile);
		syslg("S-QUE: Arquivo %s criado/aberto com sucesso.\n",wakeUPfile);
		/* ID_22849 - SWLOGGER - INI */
		char msg[256] = {0};
		sprintf( msg, "S-QUE: Arquivo %s criado/aberto com sucesso.\n",wakeUPfile);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */					
	}
	
	for (;;)
	{
		now=time(NULL);
		ts = *localtime(&now);
		strftime(DataHora, sizeof(DataHora), "%Y/%m/%d %H:%M:%S", &ts);

		/* Cria/abre arquivo de monitoramento.*/
		if ((wkF = fopen(wakeUPfile,"a")) == NULL)
		{
			ODebug("Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",wakeUPfile);
			syslg("S-QUE: Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",wakeUPfile);
			/* ID_22849 - SWLOGGER - INI */
			char msg[256] = {0};
			sprintf( msg, "S-QUE: Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",wakeUPfile);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
			/* ID_22849 - SWLOGGER - FIM */				
		}
		else
		{
			IsMbAtt=mb_isattach();
			/* Verifica se a qtde minima para processamento foi atingida.*/
			if (IsMbAtt && (GetQueueSize() >= min_Queue_size))
			{
				int mbIdIdx=0;
				int msgCount=0;
				fprintf(wkF,"%s %-5.5s %-3.3s %-30.30s %-6.6s\n",
					DataHora,"MB_ID","ATT","MB_NAME","CURDPT");
				for (;mbIdIdx<mb->nboxes;mbIdIdx++)
				{
					if (mbGetNode(mbIdIdx) != -1 && (mbMailBoxMessages(mbIdIdx) >= min_Queue_size))
					{
						msgCount+=mbMailBoxMessages(mbIdIdx);
						strcpy(mbAtt,"   ");
						if (mbIsPort(mbIdIdx))
							 strcpy(mbAtt,"P  ");
						else 
							if (mbtab[mbIdIdx].flags & MB_TAB_OUTBOUND) 
							strcpy(mbAtt,"*  ");
						
						/* Cria linha para arquivo de monitoramento.*/
						fprintf(wkF,"%s %5d %-3s %-30.30s %6d\n",
								DataHora,mbIdIdx,mbAtt,mbMailBoxName(mbIdIdx), mbMailBoxMessages(mbIdIdx));							
						
						/* Executa acoes necessarias: limpeza, kill_task, start/stop portas.*/
						if (mbMailBoxMessages(mbIdIdx) >= max_Queue_size)
						{
							ODebug("Tamanho da fila %-22.22s:[%d]\n", mbMailBoxName(mbIdIdx), 
							       mbMailBoxMessages(mbIdIdx));
							syslg("S-QUE: %s Tamanho da fila %s:[%d]\n", DataHora, mbMailBoxName(mbIdIdx), 
							       mbMailBoxMessages(mbIdIdx));
							/* ID_22849 - SWLOGGER - INI */
							char msg[256] = {0};
							sprintf( msg, "S-QUE: %s Tamanho da fila %s:[%d]\n", DataHora, mbMailBoxName(mbIdIdx), 
							       mbMailBoxMessages(mbIdIdx));
							executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
							/* ID_22849 - SWLOGGER - FIM */										   

							processing_queue_size = mbMailBoxMessages(mbIdIdx);
								   
							/*Limpa fila com chamada ao sistema caso a task/porta nao seja excluida e
							  nao esteja balanceada. (+-1)*/
							if (is_mbox_excluded(mbMailBoxName(mbIdIdx)))
							{
								ODebug("Nao e possivel limpar o mbox '%s' pois ele esta na lista de exclusao.\n",	mbMailBoxName(mbIdIdx));
								syslg("S-QUE: Nao e possivel limpar o mbox '%s' pois ele esta na lista de exclusao.\n", mbMailBoxName(mbIdIdx));
								/* ID_22849 - SWLOGGER - INI */
								char msg[256] = {0};
								sprintf( msg, "S-QUE: Nao e possivel limpar o mbox '%s' pois ele esta na lista de exclusao.\n", mbMailBoxName(mbIdIdx));
								executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
								/* ID_22849 - SWLOGGER - FIM */										
							}
							else
							{
								if (check_queue_balance(mbIdIdx))
								{
									ODebug("A fila '%s' esta balanceada. Nao e necessario limpar.\n", mbMailBoxName(mbIdIdx));
									syslg("S-QUE: A fila '%s' esta balanceada. Nao e necessario limpar.\n",	mbMailBoxName(mbIdIdx));
									/* ID_22849 - SWLOGGER - INI */
									char msg[256] = {0};
									sprintf( msg, "S-QUE: A fila '%s' esta balanceada. Nao e necessario limpar.\n",	mbMailBoxName(mbIdIdx));
									executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
									/* ID_22849 - SWLOGGER - FIM */										
								}
								else
								{
									ODebug("Limpando fila %s.\n",	mbMailBoxName(mbIdIdx));
									syslg("S-QUE: %s Limpando fila %s.\n",	DataHora, mbMailBoxName(mbIdIdx));
									/* ID_22849 - SWLOGGER - INI */
									char msg[256] = {0};
									sprintf( msg, "S-QUE: %s Limpando fila %s.\n",	DataHora, mbMailBoxName(mbIdIdx));
									executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
									/* ID_22849 - SWLOGGER - FIM */									

									sprintf(command, "mbcmd clear queue %d >> %s/sys/mommb_enfileirado_%s.log", 
											mbIdIdx, getenv("OLOGDIR"),getenv("SITE"));
									if ((ret = system (command)) < 0)
									{
										ODebug("Nao foi possivel executar o comando %s, devido a erro %d. Processamento seguira normalmente.\n", 
												command, ret);
										syslg("S-QUE: Nao foi possivel executar o comando %s, devido a erro %d. Processamento seguira normalmente.\n", 
												command, ret);
										/* ID_22849 - SWLOGGER - INI */
										char msg[256] = {0};
										sprintf( msg, "S-QUE: Nao foi possivel executar o comando %s, devido a erro %d. Processamento seguira normalmente.\n", 
												command, ret);
										executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
										/* ID_22849 - SWLOGGER - FIM */													
									}
									
									/* Verifica se a fila tratada � elegivel (porta/task)*/
									if(mbIsPort(mbIdIdx) && execute_str_stp_ports)
									{
										/* Verifica porta.*/
										is_elegible_port(mbIdIdx);
									}
									else if (execute_kill_tasks)
									{
										/* Verifica task.*/
										is_elegible_task(mbIdIdx, processing_queue_size);
									}
								}
							}
						}
					}
				}
			fprintf(wkF,"%s Quantidade de mensagens neste front end %d.\n", DataHora,msgCount);
			}
			fclose(wkF);
		}
		sleep(sleep_time);
	}
	ODebug("===========================================\n");
	ODebug("scan_Queue - FIM\n");
	syslg("S-QUE: scan_Queue - FIM\n");
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", "S-QUE: scan_Queue - FIM" ) );		
	/* ID_22849 - SWLOGGER - FIM */			
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "scan_Queue", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */		
	return;	
}

/**********************************************************
 * void is_elegible_task(int Queue_Id, int task_queue_size)*
 * Verifica se a task associada a fila processada deve ser*
 * reiniciada atraves de geracao de arquivo para posterior*
 * processamento por script.                              *
 **********************************************************/
void is_elegible_task(int Queue_Id, int task_queue_size)
{	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_elegible_task", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */		
	
	time_t occurrence_now;
	char task_queue_Name[MB_MAX_NAME+1];
	int search_task_index = 0;
	int sizeof_elegible_queue = 0;
	int queue_occurrences = 0;
	int search_mbtab = 0;
	char killfile[255];
	int task_queue_elegible = FALSE;
	FILE *kfl;
	
	occurrence_now = time(NULL);
	
	strcpy (task_queue_Name, mbtab[Queue_Id].name);
	ODebug("Verificando se a fila %s e elegivel.\n", task_queue_Name);
	syslg("S-QUE: Verificando se a fila %s e elegivel.\n", task_queue_Name);
	/* ID_22849 - SWLOGGER - INI */
	char msg[256] = {0};
	sprintf( msg, "S-QUE: Verificando se a fila %s e elegivel.\n", task_queue_Name);
	executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
	/* ID_22849 - SWLOGGER - FIM */			
	
	/* Busca na memoria todas as tasks q utilizam aquela fila.*/
	
	for (search_task_index = 0;search_task_index<tasks_index;search_task_index++)
	{
		if (strcmp(elegible_task_list[search_task_index].queue, task_queue_Name) == 0)
		{
			/* A task e elegivel.*/
			ODebug("Task %s e elegivel. Procedendo a verificacao de variaveis.\n", 
			        elegible_task_list[search_task_index].name);
			syslg("S-QUE: Task %s e elegivel. Procedendo a verificacao de variaveis.\n", 
			        elegible_task_list[search_task_index].name);
			/* ID_22849 - SWLOGGER - INI */
			sprintf( msg, "S-QUE: Task %s e elegivel. Procedendo a verificacao de variaveis.\n", 
			        elegible_task_list[search_task_index].name);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
			/* ID_22849 - SWLOGGER - FIM */								
			task_queue_elegible = TRUE;

			/* Verifica se existe mais de uma ocorrencia da mesma fila. Caso exista e a somatoria seja ZERO,
			   nao sera gerado arquivo para matar a task. */
			ODebug("Calculando tamanho total das filas %s.\n", task_queue_Name);
			syslg("S-QUE: Calculando tamanho total das filas %s.\n", task_queue_Name);
			/* ID_22849 - SWLOGGER - INI */
			sprintf( msg, "S-QUE: Calculando tamanho total das filas %s.\n", task_queue_Name);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
			/* ID_22849 - SWLOGGER - FIM */					

			sizeof_elegible_queue = task_queue_size;		
			for (search_mbtab = 0;search_mbtab<mb->nboxes;search_mbtab++)
			{
				if (strcmp(mbtab[search_mbtab].name, task_queue_Name) 
				    && search_mbtab != Queue_Id)
				{
					sizeof_elegible_queue = sizeof_elegible_queue + mbMailBoxMessages(Queue_Id);
					++queue_occurrences;
				}
			}

			ODebug("Tamanho total das filas %s [%d].\n", task_queue_Name, sizeof_elegible_queue);
			syslg("S-QUE: Tamanho total das filas %s [%d].\n", task_queue_Name, sizeof_elegible_queue);
			/* ID_22849 - SWLOGGER - INI */
			sprintf( msg, "S-QUE: Tamanho total das filas %s [%d].\n", task_queue_Name, sizeof_elegible_queue);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
			/* ID_22849 - SWLOGGER - FIM */					
			ODebug("Quantidade de ocorrencias da fila %s [%d].\n", task_queue_Name, queue_occurrences);
			syslg("S-QUE: Quantidade de ocorrencias da fila %s [%d].\n", task_queue_Name, queue_occurrences);
			/* ID_22849 - SWLOGGER - INI */
			sprintf( msg, "S-QUE: Quantidade de ocorrencias da fila %s [%d].\n", task_queue_Name, queue_occurrences);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
			/* ID_22849 - SWLOGGER - FIM */					
			
			if (sizeof_elegible_queue == 0)
			{
				ODebug("Tamanho total das filas %s's e zero. Nao sera gerado arquivo para matar Task %s.\n", 
						task_queue_Name, elegible_task_list[search_task_index].name);
				syslg("S-QUE: Tamanho total das filas %s's e zero. Nao sera gerado arquivo para matar Task %s.\n", 
						task_queue_Name, elegible_task_list[search_task_index].name);
				/* ID_22849 - SWLOGGER - INI */
				sprintf( msg, "S-QUE: Tamanho total das filas %s's e zero. Nao sera gerado arquivo para matar Task %s.\n", 
						task_queue_Name, elegible_task_list[search_task_index].name);
				executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
				/* ID_22849 - SWLOGGER - FIM */									
				return;
			}
			
			/* Verifica intervalo de ocorrencia de enfileiramento.*/
			if (occurrence_now > elegible_task_list[search_task_index].first_occurrence + time_interval)
			{
				/* Ocorrencia atual FORA do intervalo. Atualiza contadores e data.*/
				ODebug("Fila task %s FORA do intervalo de tempo.\n", elegible_task_list[search_task_index].name);
				syslg("S-QUE: Fila task %s FORA do intervalo de tempo.\n", elegible_task_list[search_task_index].name);
				/* ID_22849 - SWLOGGER - INI */
				sprintf( msg, "S-QUE: Fila task %s FORA do intervalo de tempo.\n", elegible_task_list[search_task_index].name);
				executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
				/* ID_22849 - SWLOGGER - FIM */						
				elegible_task_list[search_task_index].first_occurrence = occurrence_now;
				elegible_task_list[search_task_index].last_occurrence = occurrence_now;
				elegible_task_list[search_task_index].occurrences = 1;
			}
			else
			{
				/* Ocorrencia atual DENTRO do intervalo. Atualiza contadores e data.*/
				ODebug("Fila da task %s DENTRO do intervalo de tempo. Verificando ocorrencias.\n", 
				        elegible_task_list[search_task_index].name);
				syslg("S-QUE: Fila da task %s DENTRO do intervalo de tempo. Verificando ocorrencias.\n", 
				        elegible_task_list[search_task_index].name);						
				/* ID_22849 - SWLOGGER - INI */
				sprintf( msg, "S-QUE: Fila da task %s DENTRO do intervalo de tempo. Verificando ocorrencias.\n", 
				        elegible_task_list[search_task_index].name);
				executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
				/* ID_22849 - SWLOGGER - FIM */					
				
				elegible_task_list[search_task_index].last_occurrence = occurrence_now;
			        ++elegible_task_list[search_task_index].occurrences;
				if (elegible_task_list[search_task_index].occurrences >= max_occurrences)
				{
					/* Fila da task alcancou limite de ocorrencias. Gera arquivo para matar task*/
					ODebug("Fila da task %s atingiu limite de ocorrencias. Gerando arquivo para matar task.\n", 
					        elegible_task_list[search_task_index].name);
					syslg("S-QUE: Fila da task %s atingiu limite de ocorrencias. Gerando arquivo para matar task.\n", 
					        elegible_task_list[search_task_index].name);
					/* ID_22849 - SWLOGGER - INI */
					sprintf( msg, "S-QUE: Fila da task %s atingiu limite de ocorrencias. Gerando arquivo para matar task.\n", 
					        elegible_task_list[search_task_index].name);
					executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
					/* ID_22849 - SWLOGGER - FIM */									

					sprintf(killfile,"%s/sys/killfile_%s_%s.txt",	
							getenv("OLOGDIR"),elegible_task_list[search_task_index].name, getenv("SITE"));
					if ((kfl = fopen(killfile,"r")) == NULL)
					{
						/* Arquivo nao existe. Cria.*/
						ODebug("Arquivo para matar a task %s nao existe. Criando.\n", 
						        elegible_task_list[search_task_index].name);
						syslg("S-QUE: Arquivo para matar a task %s nao existe. Criando.\n", 
								elegible_task_list[search_task_index].name);
						/* ID_22849 - SWLOGGER - INI */
						sprintf( msg, "S-QUE: Arquivo para matar a task %s nao existe. Criando.\n", 
								elegible_task_list[search_task_index].name);
						executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
						/* ID_22849 - SWLOGGER - FIM */								
						
						if ((kfl = fopen(killfile,"a")) == NULL)
						{
							ODebug("Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",
									killfile);
							syslg("S-QUE: Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",
								   killfile);
							/* ID_22849 - SWLOGGER - INI */
							sprintf( msg, "S-QUE: Warning - problemas ao criar/abrir arquivo %s. Processamento seguira normalmente.\n",
								   killfile);
							executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
							/* ID_22849 - SWLOGGER - FIM */									   
							return;
						}
						else
						{
							fprintf(kfl,"%s", elegible_task_list[search_task_index].name);
					
							/* Zera contadores e reinicia a data.*/
							ODebug("Arquivo %s gerado. Zerando contadores da fila da task %s.\n", 
									killfile, elegible_task_list[search_task_index].name);
							syslg("S-QUE: Arquivo %s gerado. Zerando contadores da fila da task %s.\n", 
								   killfile, elegible_task_list[search_task_index].name);
							/* ID_22849 - SWLOGGER - INI */
							sprintf( msg, "S-QUE: Arquivo %s gerado. Zerando contadores da fila da task %s.\n", 
								   killfile, elegible_task_list[search_task_index].name);
							executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
							/* ID_22849 - SWLOGGER - FIM */									   
							elegible_task_list[search_task_index].first_occurrence = 0;
							elegible_task_list[search_task_index].occurrences = 0;
							fclose(kfl);
						}
					}
					else
					{
						/* Arquivo ja existe. Processo segue normalmente.*/
						ODebug("Arquivo para matar a task %s ja existe. Processamento seguira normalmente.\n", 
						        elegible_task_list[search_task_index].name);
						syslg("S-QUE: Arquivo para matar a task %s ja existe. Processamento seguira normalmente.\n", 
								elegible_task_list[search_task_index].name);
						/* ID_22849 - SWLOGGER - INI */
						sprintf( msg, "S-QUE: Arquivo para matar a task %s ja existe. Processamento seguira normalmente.\n", 
								elegible_task_list[search_task_index].name);
						executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
						/* ID_22849 - SWLOGGER - FIM */											
						fclose(kfl);
						return;
					}
				}
			}
		}
	}
	if(task_queue_elegible == FALSE)
	{
		ODebug("Nao existe task eleita para a fila %s.\n", task_queue_Name);
		syslg("S-QUE: Nao existe task eleita para a fila %s.\n", task_queue_Name);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: Nao existe task eleita para a fila %s.\n", task_queue_Name);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */			
	}
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_elegible_task", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */			
	return;
}

/**********************************************************
 * void is_elegible_port(int Queue_Id)                    *
 * Verifica se a porta associada a fila processada deve   *
 * sofrer start/stop.                                     *
 **********************************************************/
void is_elegible_port(int Queue_Id)
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_elegible_port", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */	
	
	time_t occurrence_now;
	char port_queue_Name[MB_MAX_NAME+1];
	int search_port_index = 0;
	char command[255];	
	int port_queue_elegible = FALSE;

	occurrence_now = time(NULL);

	strcpy (port_queue_Name, mbtab[Queue_Id].name);
	ODebug("Verificando se a fila %s e elegivel.\n", port_queue_Name);
	syslg("S-QUE: Verificando se a fila %s e elegivel.\n", port_queue_Name);
	/* ID_22849 - SWLOGGER - INI */
	char msg[256] = {0};
	sprintf( msg, "S-QUE: Verificando se a fila %s e elegivel.\n", port_queue_Name);
	executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
	/* ID_22849 - SWLOGGER - FIM */			
	
	/* Busca na memoria todas as portas com o nome informado.*/
	
	for (search_port_index = 0;search_port_index<ports_index;search_port_index++)
	{
		if (strcmp(elegible_port_list[search_port_index].name, port_queue_Name) == 0)
		{
			/* A porta e elegivel.*/
			ODebug("Porta %s e elegivel. Procedendo a verificacao de variaveis.\n", 
			        elegible_port_list[search_port_index].name);
			syslg("S-QUE: Porta %s e elegivel. Procedendo a verificacao de variaveis.\n", 
				elegible_port_list[search_port_index].name);
			/* ID_22849 - SWLOGGER - INI */
			sprintf( msg, "S-QUE: Porta %s e elegivel. Procedendo a verificacao de variaveis.\n", 
				elegible_port_list[search_port_index].name);
			executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
			/* ID_22849 - SWLOGGER - FIM */					
			port_queue_elegible = TRUE;

			/* Verifica intervalo de ocorrencia de enfileiramento.*/
			if (occurrence_now > elegible_port_list[search_port_index].first_occurrence + time_interval)
			{
				/* Ocorrencia atual FORA do intervalo. Atualiza contadores e data.*/
				ODebug("Fila da porta %s FORA do intervalo de tempo.\n", elegible_port_list[search_port_index].name);
				syslg("S-QUE: Fila da porta %s FORA do intervalo de tempo.\n", elegible_port_list[search_port_index].name);
				/* ID_22849 - SWLOGGER - INI */
				sprintf( msg, "S-QUE: Fila da porta %s FORA do intervalo de tempo.\n", elegible_port_list[search_port_index].name);
				executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
				/* ID_22849 - SWLOGGER - FIM */					
				elegible_port_list[search_port_index].first_occurrence = occurrence_now;
				elegible_port_list[search_port_index].last_occurrence = occurrence_now;
				elegible_port_list[search_port_index].occurrences = 1;
			}
			else
			{
				/* Ocorrencia atual DENTRO do intervalo. Atualiza contadores e data.*/
				ODebug("Fila da porta %s DENTRO do intervalo de tempo. Verificando ocorrencias.\n", 
				        elegible_port_list[search_port_index].name);
				syslg("S-QUE: Fila da porta %s DENTRO do intervalo de tempo. Verificando ocorrencias.\n", 
				        elegible_port_list[search_port_index].name);
				/* ID_22849 - SWLOGGER - INI */
				sprintf( msg, "S-QUE: Fila da porta %s DENTRO do intervalo de tempo. Verificando ocorrencias.\n", 
				        elegible_port_list[search_port_index].name);
				executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
				/* ID_22849 - SWLOGGER - FIM */							
				elegible_port_list[search_port_index].last_occurrence = occurrence_now;
				++elegible_port_list[search_port_index].occurrences;

				if (elegible_port_list[search_port_index].occurrences >= max_occurrences)
				{
					/* Fila da porta alcancou limite de ocorrencias. Executa stop/start na porta.*/
					ODebug("Fila da porta %s atingiu limite de ocorrencias. Executando 'stop/start' na porta.\n", 
					       elegible_port_list[search_port_index].name);
					syslg("S-QUE: Fila da porta %s atingiu limite de ocorrencias. Executando 'stop/start' na porta.\n", 
					       elegible_port_list[search_port_index].name);
					/* ID_22849 - SWLOGGER - INI */
					sprintf( msg, "S-QUE: Fila da porta %s atingiu limite de ocorrencias. Executando 'stop/start' na porta.\n", 
					       elegible_port_list[search_port_index].name);
					executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
					/* ID_22849 - SWLOGGER - FIM */		
				
					/* Caso nao seja possivel executar os comandos, retorna normalmente ao tratamento das filas.*/
					sprintf(command, "mbportcmd stop %s >> %s/sys/mommb_enfileirado_%s.log", 
					                  elegible_port_list[search_port_index].name, getenv("OLOGDIR"),getenv("SITE"));
					if (system (command) < 0)
					{
						ODebug("Nao foi possivel realizar 'STOP' na porta %s. Processamento seguira normalmente.\n", 
						        elegible_port_list[search_port_index].name);
						syslg("S-QUE: Nao foi possivel realizar 'STOP' na porta %s. Processamento seguira normalmente.\n", 
						        elegible_port_list[search_port_index].name);
						/* ID_22849 - SWLOGGER - INI */
						sprintf( msg, "S-QUE: Nao foi possivel realizar 'STOP' na porta %s. Processamento seguira normalmente.\n", 
						        elegible_port_list[search_port_index].name);
						executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
						/* ID_22849 - SWLOGGER - FIM */									
						return;
					}
					
					sprintf(command, "mbportcmd start %s >> %s/sys/mommb_enfileirado_%s.log", 
					                  elegible_port_list[search_port_index].name, getenv("OLOGDIR"),getenv("SITE"));
					if (system (command) < 0)
					{
						ODebug("Nao foi possivel realizar 'START' na porta %s. Processamento seguira normalmente.\n", 
						        elegible_port_list[search_port_index].name);
						syslg("S-QUE: Nao foi possivel realizar 'START' na porta %s. Processamento seguira normalmente.\n", 
						       elegible_port_list[search_port_index].name);
						/* ID_22849 - SWLOGGER - INI */
						sprintf( msg, "S-QUE: Nao foi possivel realizar 'START' na porta %s. Processamento seguira normalmente.\n", 
						       elegible_port_list[search_port_index].name);
						executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
						/* ID_22849 - SWLOGGER - FIM */										   
						return;
					}
					
					/* Zera contadores e reinicia a data.*/
					ODebug("Executado start/stop com sucesso na porta %s. Zerando contadores da fila da porta.\n", 
							elegible_port_list[search_port_index].name);
					syslg("S-QUE: Executado start/stop com sucesso na porta %s. Zerando contadores da fila da porta.\n", 
							elegible_port_list[search_port_index].name);
					/* ID_22849 - SWLOGGER - INI */
					sprintf( msg, "S-QUE: Executado start/stop com sucesso na porta %s. Zerando contadores da fila da porta.\n", 
							elegible_port_list[search_port_index].name);
					executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
					/* ID_22849 - SWLOGGER - FIM */									
					elegible_port_list[search_port_index].first_occurrence = 0;
					elegible_port_list[search_port_index].occurrences = 0;	
				}
			}
		}
	}
	if(port_queue_elegible == FALSE)
	{
		ODebug("A fila da porta %s nao e elegivel.\n", elegible_port_list[search_port_index].name);
		syslg("S-QUE: A fila da porta %s nao e elegivel.\n", elegible_port_list[search_port_index].name);
		/* ID_22849 - SWLOGGER - INI */
		sprintf( msg, "S-QUE: A fila da porta %s nao e elegivel.\n", elegible_port_list[search_port_index].name);
		executeLogger (  new (nothrow) LogInitialization( "SCQUEUE", OCString(msg) ) );		
		/* ID_22849 - SWLOGGER - FIM */				
	}

	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_elegible_port", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */		
	return;
}

/**********************************************************
 * int is_mbox_exists(char *mailbox)                      *
 * Verifica se o mailbox ja esta carregado na memoria.    *
 *                                                        *
 * Parametros:                                            *
 * mailbox: Nome do mailbox a ser pesquisado.             *
 *                                                        *
 * Retornos:                                              *
 * FALSE (0): Nao esta carregada na memoria.              *
 * TRUE  (1): Ja esta carregada na memoria.               *
 **********************************************************/
int is_mbox_exists(char *mailbox)
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_mbox_exists", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */		
	
	int mbox_find_count = 0;
	
	for(; mbox_find_count < excluded_mbox_index; mbox_find_count++)
	{
		if (!(strcmp(excluded_mbox_list[mbox_find_count].mailbox, mailbox)))
			{
					/* Encontrou mailbox */
					return TRUE;
			}
	}
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_mbox_exists", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */			
	/* Caso nao encontre o mailbox */
	return FALSE;
}

/**********************************************************
 * int is_mbox_excluded(char *mailbox)                    *
 * Verifica se o mailbox esta na lista de excluidas.      *
 *                                                        *
 * Parametros:                                            *
 * mailbox: Nome do mailbox a ser pesquisada.             *
 *                                                        *
 * Retornos:                                              *
 * FALSE (0): Nao esta esta na lista de exclusao.         *
 * TRUE  (1): Esta na lista de exclusao.                  *
 **********************************************************/
int is_mbox_excluded(char *mailbox)
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_mbox_excluded", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */		
	
	int mbox_find_count = 0;
	
	for(; mbox_find_count < excluded_mbox_index; mbox_find_count++)
	{
		if (!strcmp(excluded_mbox_list[mbox_find_count].mailbox, mailbox))
			{
					/* Encontrou o mailbox. */
					return TRUE;
			}
	}
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "is_mbox_excluded", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */			
	/* Caso nao encontre o mailbox. */
	return FALSE;
}

/**********************************************************
 * int check_queue_balance(int Queue_Id)                  *
 * Verifica se as filas de Inbound e Outbound tem o mesmo *
 * tamanho.                                               *
 *                                                        *
 * Parametros:                                            *
 * queue: Nome da fila a ser pesquisada.                  *
 *                                                        *
 * Retornos:                                              *
 * FALSE (0): As filas tem tamanho diferente.             *
 * TRUE  (1): As filas tem o mesmo tamanho.               *
 **********************************************************/
int check_queue_balance(int Queue_Id)
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "check_queue_balance", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */		
	
	char inBound_Queue [MB_MAX_NAME+1];
	int inBound_Queue_depth = 0;
	int mbIdIdx = 0;
		
	strcpy(inBound_Queue, mbMailBoxName(Queue_Id));
	inBound_Queue_depth = mbMailBoxMessages(Queue_Id);
		
	for (;mbIdIdx<mb->nboxes;mbIdIdx++)
	{
		if(!(strcmp(inBound_Queue, mbMailBoxName(mbIdIdx))) &&
		   (Queue_Id != mbIdIdx) && 
		   (inBound_Queue_depth == mbMailBoxMessages(mbIdIdx)) &&
		   (mbtab[mbIdIdx].flags & MB_TAB_OUTBOUND))
		{
			/* Caso seja localizada uma fila com o mesmo nome mas com 
			   ID diferente que tenha o mesmo tamanho e que seja de 
			   OUTBOUND.*/
			return TRUE;
		}
	}

	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "check_queue_balance", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */			
	return FALSE;
}

/**********************************************************
 * void prog_exit(int n)                                  *
 * Trata saida do programa.                               *
 **********************************************************/
void prog_exit(int n)
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "prog_exit", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */		
	

    if(n == 0 || n == SIGTERM)
    {
        syslg("S-QUE: Normal Exit # %d.\n", n);
        ODebug("Normal Exit # %d.\n", n);
    }  
    else
    {   
        syslg("S-QUE: Exit Due to Signal %d\n", n);
        ODebug("Exit Due to Signal %d\n", n);
    }  
    
    ODebugOff();

#if 0
    if (n > 1)
        kill((short)getpid(), n);
#endif
       
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "SCQUEUE", "prog_exit", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */			   
    exit(n);
}

/**********************************************************
 * long GetQueueSize()                                    *
 *                                                        *
 **********************************************************/
long GetQueueSize()
{
    int index = 0;
    long queueSize = 0;

    for (index = 0; index < mbNumberOfMailBoxes(); index ++)
    {
        queueSize += mbMailBoxMessages(index);
    }
    return ( queueSize );
}

