//static char ver[]="libNETC 1.0 30Mai2012";

/*
 *  - libNETC - Biblioteca de contadores monitoracao
 *
 *  - Descricao: Disponibiliza rotinas de gerenciamento dos contadores da
 *		monitoracao
 *
 *  Who     When        Why
 *  ========================================================================
 *  686469  30/05/2012  Versao inicial. (ID_16872)
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */


#include <libNETC.h>

stNETC_SHM* pNETC;

/*
 * Nome: NETC_create
 * Descricao: Cria a area de memoria compartilhada por FE
 * Parametros: Tabela de configuracao, Buffer para 
 *		mensagem de erro
 * Retorno: NETC_shm_create
 */
int NETC_create( stCONFIG_TABLE* config, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( config );

	/* Regra */
	return NETC_shm_create( NETC_get_mbregionid(), &pNETC, config, msgErro );
}

/*
 * Nome: NETC_remove
 * Descricao: Remove a area de memoria compartilhada por FE
 * Parametros: Buffer para mensagem de erro
 * Retorno: NETC_shm_remove
 */
int NETC_remove( char* msgErro )
{
	/* Pre-condicoes */

	/* Regra */
	return NETC_shm_remove( pNETC, msgErro );
}

/*
 * Nome: NETC_clear
 * Descricao: Limpa a area de memoria compartilhada por FE
 * Parametros: Buffer para mensagem de erro
 * Retorno: NETC_shm_clear
 */
int NETC_clear( char* msgErro )
{
	/* Pre-condicoes */

	/* Regra */
	return NETC_shm_clear( pNETC, msgErro );
}

/*
 * Nome: NETC_show
 * Descricao: Exibe o conteudo da area de memoria compartilhada por FE
 * Parametros: Buffer para mensagem de erro
 * Retorno: NETC_shm_show
 */
//int NETC_show( char* msgErro )
int NETC_show( )
{
	/* Pre-condicoes */

	/* Regra */
	//return NETC_shm_show( pNETC, msgErro );
	return NETC_shm_show( pNETC );
}

/*
 * Nome: NETC_init
 * Descricao: Conecta-se o processo a memoria compartilhada do FE
 * Parametros: Buffer para mensagem de erro
 * Retorno: NETC_shm_init
 */
int NETC_init( char* msgErro )
{
	/* Pre-condicoes */

	/* Regra */
	return NETC_shm_init( NETC_get_mbregionid(), &pNETC, msgErro );
}

/*
 * Nome: NETC_increment
 * Descricao: Incrementa o contador na area de memoria compartilhada
 * Parametros: Contador, Campos da mensagem ( issuer, acquirer,
 *				msgtype, pcode, retcode ), Buffer para mensagem de erro
 * Retorno: NETC_shm_inc
 */
int NETC_increment( const int iVertice, char* issuer, char* acquirer,
					int msgtype, long pcode, int retcode, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( issuer );
	lib_assert( acquirer );
	lib_assert( retcode < 100 );

	/* Regra */
	return NETC_shm_inc( pNETC, iVertice, issuer, acquirer, msgtype, pcode, retcode, msgErro );
}

/*
 * Nome: NETC_read_data
 * Descricao: Devolve a estrutura com a consolidacao dos contadores
 * Parametros: struct shm_data *DataTable, int *reg_count
 * Retorno: 0 se sucesso, menor que 0 caso contrario
 */
//int NETC_read_data( struct shm_data *DataTable, int *reg_count, char* msgErro )
int NETC_read_data( struct shm_data *DataTable, int *reg_count )
{
    int iRetCode = NETC_RET_OK;
    register int i, k, l, count = 0;

    for( i = 0; i < getQtdeReg( pNETC ); i++ )
    {
        for( k = 0; k < getQtdePcodeMty( pNETC ); k++ )
        {
            for( l = 0; l < MAX_RETCODES; l++ )
            {
                if( pNETC->data[i].mty_pcode[k].retcodes[l].qtde )
                {
                    strcpy( DataTable[count].issuer, pNETC->data[i].issuer );
                    strcpy( DataTable[count].acquirer, pNETC->data[i].acquirer );
                    DataTable[count].msgtype = pNETC->data[i].mty_pcode[k].msgtype;
                    DataTable[count].pcode = pNETC->data[i].mty_pcode[k].pcode;
                    DataTable[count].retcode = pNETC->data[i].mty_pcode[k].retcodes[l].retcode;
                    DataTable[count].qtderetcode = pNETC->data[i].mty_pcode[k].retcodes[l].qtde;
                    DataTable[count].qtdeReqRec = pNETC->data[i].contadores[QTDE_REQ_REC];
                    DataTable[count].qtdeReqEnv = pNETC->data[i].contadores[QTDE_REQ_ENV];
                    DataTable[count].qtdeRespRec = pNETC->data[i].contadores[QTDE_RESP_REC];
                    DataTable[count].qtdeRespEnv = pNETC->data[i].contadores[QTDE_RESP_ENV];
                    count++;
                }
            }
        }
    }

    *reg_count = count;
    return iRetCode;
    return 1;

}


/*
 * Nome: NETC_read_data_vertice
 * Descricao: Devolve a estrutura com a consolidacao dos contadores
 * Parametros: struct shm_data *DataTable, int *reg_count
 * Retorno: 0 se sucesso, menor que 0 caso contrario
 */
//int NETC_read_data_vertice( struct shm_data *DataTable, int *reg_count, char* msgErro )
int NETC_read_data_vertice( struct shm_data *DataTable, int *reg_count )
{

    int iRetCode = NETC_RET_OK;
    register int i, count = 0;

    for( i = 0; i < getQtdeReg( pNETC ); i++ )
    {

        if( pNETC->data[i].contadores[QTDE_REQ_REC] || pNETC->data[i].contadores[QTDE_REQ_ENV] ||
            pNETC->data[i].contadores[QTDE_RESP_REC] || pNETC->data[i].contadores[QTDE_RESP_ENV] )
        {
            strcpy( DataTable[count].issuer, pNETC->data[i].issuer );
            strcpy( DataTable[count].acquirer, pNETC->data[i].acquirer );
            DataTable[count].qtdeReqRec = pNETC->data[i].contadores[QTDE_REQ_REC];
            DataTable[count].qtdeReqEnv = pNETC->data[i].contadores[QTDE_REQ_ENV];
            DataTable[count].qtdeRespRec = pNETC->data[i].contadores[QTDE_RESP_REC];
            DataTable[count].qtdeRespEnv = pNETC->data[i].contadores[QTDE_RESP_ENV];
            count++;
        }
    }

    *reg_count = count;
    return iRetCode;
    return 1;
}

