//static char ver[]="libNETC 1.0 22Set2020";

/*
 *  - libNETC - Biblioteca de contadores monitoracao
 *
 *  - Descricao: Rotinas privadas da biblioteca
 *
 *  Who     When        Why
 *  ========================================================================
 *  686469  30/05/2012  Versao inicial. (ID_16872)
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *
 */


#include <libNETC.h>
#include <stdarg.h>

struct sembuf stLock[1] = {0, -1, 0};
struct sembuf stUnlock[1] = {0, 1, 0};
int netcDebug;

/*
 * Nome: NETC_shm_init
 * Descricao: Conecta-se a area de memoria compartilhada
 * Parametros: ISTMBREGIONID, Ponteiro para ponteiro da estrutura na SHM
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
int NETC_shm_init( int iRegion, stNETC_SHM **pNetC, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( iRegion >= 0 );
	
	/* Regra */
	
	int iRetCode = NETC_RET_OK;
	int iShm_id = 0;
	key_t kKey = 0;
	stNETC_SHM *pTable;

	/* Obtem a chave a partir da regiao de memoria do FE */
	kKey = NETC_get_key( iRegion );

	/* Verifica se a memoria existe */
	iShm_id = shmget( kKey, 0, 0666 );

	if( iShm_id != -1 )
	{
		/* Memoria compartilhada ja existe. Obtem endereco do ponteiro */
		if ( (pTable = (stNETC_SHM *) shmat(iShm_id, NULL, 0) ) == (void *) -1 )
		{
			/* Erro ao obter ponteiro para a memoria compartilhada */			
			NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SHM_AT, NETC_MSG_SHM_AT );
			iRetCode = NETC_RET_SHM_AT;
		}
	}
	else
	{
		/* Memoria compartilhada nao existe */
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SHM_GET, NETC_MSG_SHM_GET );		
		iRetCode = NETC_RET_SHM_GET;
	}

	/* Atribui o endereco da estrutura da SHM ao ponteiro da funcao */
	if( iRetCode == NETC_RET_OK ) *pNetC = pTable;

	/* Pos-condicoes */
	lib_assert( *pNetC );

	return iRetCode;
}

/*
 * Nome: NETC_shm_create
 * Descricao: Cria a estrutura dos contadores da monitoracao na SHM
 * Parametros: ISTMBREGIONID, Ponteiro para ponteiro da estrutura na SHM, 
 *				Tabela de configuracao
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
int NETC_shm_create( int iRegion, stNETC_SHM **pNetC, stCONFIG_TABLE* config, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( iRegion >= 0 );
	lib_assert( config );
	
	/* Regra */
	
	int iRetCode = NETC_RET_OK;
	int iShm_id = 0;
	int iShm_size = 0;
	key_t kKey = 0;
	stNETC_SHM *pTable;

	iShm_size = sizeof( stNETC_SHM );

	/* Configura o Nivel de Debug */
	netcDebug = config->levelDebug;

	/* Obtem a chave a partir da regiao de memoria do FE */
	kKey = NETC_get_key( iRegion );

	/* Verifica se a memoria existe */
	iShm_id = shmget(kKey, iShm_size, 0666);
	
	if( iShm_id != -1 ) 
	{
		/* Memoria compartilhada ja existe. Obtem endereco do ponteiro */
		if ( (pTable = (stNETC_SHM *) shmat(iShm_id, NULL, 0)) == (void *) -1 ) 
		{
			/* Erro ao obter ponteiro para a memoria compartilhada */			
			NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SHM_AT, NETC_MSG_SHM_AT );
			iRetCode = NETC_RET_SHM_AT;
		}
		else
                {
                        /* J� existe */
                        NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s [%u]'\n", NETC_RET_SHM_CREATED, NETC_MSG_SHM_CREATED, iShm_id );
                        iRetCode = NETC_RET_SHM_CREATED;
                }

	}
	else /* Memoria compartilhada nao existe. Cria nova area de memoria */
	{
		/* Cria area memoria */
		iShm_id = shmget( kKey, iShm_size, 0666 | IPC_CREAT );        
	
		if( iShm_id != -1 ) 
		{
			/* Memoria compartilhada foi criada. Obtem endereco do ponteiro */
			if ( (pTable = (stNETC_SHM *) shmat(iShm_id, NULL, 0)) == (void *) -1 ) 
			{
				/* Erro ao obter ponteiro para a memoria compartilhada */			
				NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SHM_AT, NETC_MSG_SHM_AT );
				iRetCode = NETC_RET_SHM_AT;
			}
			else
			{
				memset( pTable, 0, sizeof( stNETC_SHM ) );

				/* Atribui o id da SHM ao ponteiro */
				pTable->shm_id = iShm_id;

				/* Faz a carga inicial a partir da tabela de configuracao */	
				//NETC_shm_insert( pTable, config, msgErro );
				NETC_shm_insert( pTable, config );

				/* Cria semaforo para acesso a memoria compartilhada */
				if ( (pTable->sem_id = NETC_sem_create( kKey, msgErro )) < 0 ) 
				{
					/* Erro ao tentar criar semaforo */
					NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_CREATE, NETC_MSG_SEM_CREATE );
					iRetCode = NETC_RET_SEM_CREATE;
				}	
			}
		}
		else
		{
			/* Memoria compartilhada nao foi criada */
			NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SHM_CREATE, NETC_MSG_SHM_CREATE );
			iRetCode = NETC_RET_SHM_CREATE;
		}
	}

	/* Atribui o endereco da estrutura da SHM ao ponteiro da funcao */
	if( iRetCode == NETC_RET_OK ) *pNetC = pTable;

	/* Pos-condicoes */
	lib_assert( pNetC && *pNetC );
	
	return iRetCode;
}

/*
 * Nome: NETC_shm_remove
 * Descricao: Desaloca o espaco reservado em SHM para os contadores
 * Parametros: Ponteiro para a estrutura na SHM
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
int NETC_shm_remove( stNETC_SHM *pNetC, char* msgErro ) 
{
	/* Pre-condicoes */
	lib_assert( pNetC );
	
	/* Regra */
	
	int iRetCode = NETC_RET_OK;
	
	if( shmctl(pNetC->shm_id, IPC_RMID, 0) < 0 )
	{
		/* Erro ao remover id da SHM */
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SHM_REMOVE, NETC_MSG_SHM_REMOVE );
		iRetCode = NETC_RET_SHM_REMOVE;		
	}

	if( semctl(pNetC->sem_id, 0, IPC_RMID) < 0 )
	{
		/* Erro ao remover id da SHM */
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_REMOVE, NETC_MSG_SEM_REMOVE );
		iRetCode = NETC_RET_SEM_REMOVE;
	}

	/* Pos-condicoes */
	lib_assert( pNetC );
	
	return iRetCode;
}

/*
 * Nome: NETC_shm_clear
 * Descricao: Limpa os contadores na SHM
 * Parametros: Ponteiro para a estrutura na SHM
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
int NETC_shm_clear( stNETC_SHM *pNetC, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( pNetC /* && flag */);
	
	/* Regra */
	
	int iRetCode = NETC_RET_OK;
	register int i, k, l;
	
	/* Solicita bloqueio para atualizar memoria */
	if ( NETC_sem_lock(pNetC->sem_id) < 0 )
	{
		/* Erro ao obter o bloqueio */
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_LOCK, NETC_MSG_SEM_LOCK );
		iRetCode = NETC_RET_SEM_LOCK;
	}

	/* Limpa os contadores */
	setQtdeReg( pNetC, 0 );

	for( i = 0; i < getQtdeBins( pNetC ); i++ )
	{
		pNetC->data[i].contadores[QTDE_REQ_REC] = 0;
		pNetC->data[i].contadores[QTDE_REQ_ENV] = 0;
		pNetC->data[i].contadores[QTDE_RESP_REC]= 0;
		pNetC->data[i].contadores[QTDE_RESP_ENV]= 0;

		strcpy( pNetC->data[i].issuer, NETC_DEFAULT_NETID );
		strcpy( pNetC->data[i].acquirer, NETC_DEFAULT_NETID );

		for( k = 0; k < getQtdePcodeMty( pNetC ); k++ )
		{
			pNetC->data[i].mty_pcode[k].msgtype = 0;
			pNetC->data[i].mty_pcode[k].pcode = 0;

			for( l = 0; l < MAX_RETCODES; l++ )
			{
				pNetC->data[i].mty_pcode[k].retcodes[l].retcode = 0;
				pNetC->data[i].mty_pcode[k].retcodes[l].qtde = 0;
			}
		}
	}

	/* Solicita desbloqueio do semafaro */
	if ( NETC_sem_unlock(pNetC->sem_id) < 0 )
	{
		/* Erro ao obter o desbloqueio */
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_UNLOCK, NETC_MSG_SEM_UNLOCK );
		iRetCode = NETC_RET_SEM_UNLOCK;
	}
	
	/* Pos-condicoes */
	lib_assert( pNetC /* && flag */);
	
	return iRetCode;
}

/*
 * Nome: NETC_shm_show
 * Descricao: Mostra o conteudo da SHM
 * Parametros: Ponteiro para a estrutura na SHM
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
//int NETC_shm_show( const stNETC_SHM *pNetC, char* msgErro )
int NETC_shm_show( const stNETC_SHM *pNetC )
{
	/* Pre-condicoes */
	lib_assert( pNetC );
	
	/* Regra */
	
	int iRetCode = NETC_RET_OK;
	register int i, k, l;

	printf("ID  |ISSUER\t|ACQUIRER\t|QTDE_REC_REC\t|QTDE_REC_ENV\t|QTDE_RESP_REC\t|QTDE_RESP_ENV\n");
	printf("-----------------------------------------------------------------------------------------------\n");
	for( i = 0; i < getQtdeBins( pNetC ); i++ )
	{
		if( pNetC->data[i].contadores[QTDE_REQ_REC] ||
			pNetC->data[i].contadores[QTDE_REQ_ENV] || 
			pNetC->data[i].contadores[QTDE_RESP_REC] || 
			pNetC->data[i].contadores[QTDE_RESP_ENV] )
		{
		printf("%03d |%10s\t|%10s\t|%ld\t\t|%ld\t\t|%ld\t\t|%ld\n", i,
				pNetC->data[i].issuer, pNetC->data[i].acquirer, 
				pNetC->data[i].contadores[QTDE_REQ_REC], pNetC->data[i].contadores[QTDE_REQ_ENV], 
				pNetC->data[i].contadores[QTDE_RESP_REC], pNetC->data[i].contadores[QTDE_RESP_ENV]);
		} 
	}
	printf("\n");

	printf("ISSUER\t\t|ACQUIRER\t|PCODE\t\t|MSGTYPE\t|RETCODES\n");
	printf("------------------------------------------------------------------------------------------------------------------\n");


	int nroRet;			
	typedef struct
	{
		int ret;
		long qtde;
	}stRetcode;	

	stRetcode retVec[ MAX_RETCODES ];
	memset( retVec, '\0', sizeof( stRetcode ) * MAX_RETCODES );

	for( i = 0; i < getQtdeBins( pNetC ); i++ )
	{
    			for( k = 0; k < getQtdePcodeMty( pNetC ); k++ )
    			{
				nroRet = 0;
				for( l = 0; l < MAX_RETCODES; l++ )
        			{
					int retcode = pNetC->data[i].mty_pcode[k].retcodes[l].retcode;
					long qtde = pNetC->data[i].mty_pcode[k].retcodes[l].qtde;

					retVec[l].ret = 0;
					retVec[l].qtde = 0;

					if( qtde )
					{
						retVec[retcode].ret = retcode;	
						retVec[retcode].qtde = qtde;	
						nroRet++;
					}
				}

				if( nroRet )
				{
					printf("%10s\t|%10s\t|%06ld\t\t|%04d\t\t|", pNetC->data[i].issuer, pNetC->data[i].acquirer, pNetC->data[i].mty_pcode[k].pcode, pNetC->data[i].mty_pcode[k].msgtype );


					for( l = 0; l < MAX_RETCODES; l++ )
					{
					if( retVec[l].qtde )
					{
					printf("%02d,", retVec[l].ret);
					printf("%.ld ", retVec[l].qtde);
					}
					}

    					printf("\n");
				}
    			}
	}

	/* Pos-condicoes */
	lib_assert( pNetC );
	
	return iRetCode;
}

/*
 * Nome: NETC_shm_insert
 * Descricao: Carrega os dados iniciais da tabela de configuracao
 *			na memoria
 * Parametros: Ponteiro para a estrutura na SHM, Tabela de configuracao
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
//int NETC_shm_insert( stNETC_SHM *pNetC, stCONFIG_TABLE* config, char* msgErro )
int NETC_shm_insert( stNETC_SHM *pNetC, stCONFIG_TABLE* config )
{
	/* Pre-condicoes */
	lib_assert( pNetC );
	lib_assert( config );
	lib_assert( config->qtdeNetworkids <= MAX_NETWORKID );
	lib_assert( config->qtdePcodesMtys <= MAX_MSGTYPE_PCODE );
	
	/* Regra */
	
	int iRetCode = NETC_RET_OK;
	register int i, k;

	memcpy( &pNetC->m_cfg, config, sizeof( stCONFIG_TABLE ) );

	/* Configura o numero de networkids/msgtypes/pcodes */

	setQtdeReg( pNetC, 0 );
	setQtdeBins( pNetC, config->qtdeNetworkids );
	setQtdePcodeMty( pNetC, config->qtdePcodesMtys );

        for( i = 0; i < getQtdeBins( pNetC ); i++ )
        {
        	/* Carrega a lista de Networkids */
		strcpy(pNetC->data[i].issuer, NETC_DEFAULT_NETID);
		strcpy(pNetC->data[i].acquirer, NETC_DEFAULT_NETID);

		for( k = 0; k < getQtdePcodeMty( pNetC ); k++ )
		{
                	/* Carrega a lista de Msgtypes/Pcodes */
                	pNetC->data[i].mty_pcode[k].pcode = 0;
                	pNetC->data[i].mty_pcode[k].msgtype = 0; 
                }
        }

	/* Pos-condicoes */
	lib_assert( pNetC );

	return iRetCode;
}


/*
 * Nome: adicionaVertice
 * Descricao: Incrementa os contadores da monitoracao
 * Parametros: Ponteiro para a estrutura na SHM, Contador, 
 *				Estrutura da mensagem
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
int adicionaVertice( stNETC_SHM *pNetC, int idx, int iVertice, stMSG msg, char* msgErro )
{

	int iRetCode = NETC_RET_OK;

	if( !strcmp(pNetC->data[idx].issuer, NETC_DEFAULT_NETID) )
	{
		if( addReg( pNetC, msgErro ) != NETC_RET_OK )
			iRetCode = NETC_RET_NOK;
	}

	strcpy( pNetC->data[idx].issuer, msg.issuer );
	strcpy( pNetC->data[idx].acquirer, msg.acquirer );

	++(pNetC->data[idx].contadores[iVertice]);

	return iRetCode;
}

/*
 * Nome: adicionaMensagem
 * Descricao: Incrementa os contadores da monitoracao
 * Parametros: Ponteiro para a estrutura na SHM, Contador,
 *                              Estrutura da mensagem
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
int adicionaMensagem( stNETC_SHM *pNetC, int idx, int mp_idx, stMSG msg, char* msgErro )
{
	int iRetCode = NETC_RET_OK;

	if( msg.retcode >= 100 )
	{
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: 'Retcode invalido[%04d]'\n", NETC_RET_NOK, msg.retcode );
		iRetCode = NETC_RET_NOK;
	}
	else
	{
		if( !strcmp(pNetC->data[idx].issuer, NETC_DEFAULT_NETID) )
		{
			int ret;
			if( (ret = addReg( pNetC, msgErro )) != NETC_RET_OK )
				return ret;
		}


		/* Atribui o Issuer */
		strcpy( pNetC->data[idx].issuer, msg.issuer );

		/* Atribui o Acquirer */
		strcpy( pNetC->data[idx].acquirer, msg.acquirer );

		/* Atribui o Msgtype */
		pNetC->data[idx].mty_pcode[mp_idx].msgtype = msg.msgtype;

		/* Atribui o Pcode */
		pNetC->data[idx].mty_pcode[mp_idx].pcode = msg.pcode;

		/* Atribui o Retcode */
		pNetC->data[idx].mty_pcode[mp_idx].retcodes[msg.retcode].retcode = msg.retcode;

		/* Incrementa a quantidade de Retcode */
		++(pNetC->data[idx].mty_pcode[mp_idx].retcodes[msg.retcode].qtde);
	}

	return iRetCode;
}


/*
 * Nome: NETC_shm_inc_vertice
 * Descricao: Incrementa os contadores da monitoracao
 * Parametros: Ponteiro para a estrutura na SHM, Contador, 
 *				Estrutura da mensagem
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
int NETC_shm_inc_vertice( stNETC_SHM *pNetC, int iVertice, stMSG msg, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( pNetC );

        /* Regra */

        int iRetCode = NETC_RET_OK;

        /* Solicita bloqueio para atualizar memoria */
        if ( NETC_sem_lock(pNetC->sem_id) < 0 )
        {
                /* Erro ao obter o bloqueio */
                NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_LOCK, NETC_MSG_SEM_LOCK );
                iRetCode = NETC_RET_SEM_LOCK;
        }

    	/* Atualiza memoria */

        /* Busca o Issuer/Acquirer na lista, ou retorna uma posicao disponivel */
        int idx = findIndex( pNetC, msg );

	iRetCode = idx == -1 ? NETC_RET_NOK : NETC_RET_OK;

        if( iRetCode == NETC_RET_OK )
	{
		iRetCode = adicionaVertice( pNetC, idx, iVertice, msg, msgErro );
	}

	if( iRetCode != NETC_RET_OK )
	{
                NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: 'Nao foi possivel inserir o vertice:' [i%10s/a%10s/v%01d]\n", 
				NETC_RET_NOK, msg.issuer, msg.acquirer, iVertice );
                iRetCode = NETC_RET_NOK;
        }

	/* Valida se a quantidade de registro nao chegou ao fim */
	if( getQtdeReg( pNetC ) >= MAX_NETWORKIDS )
       	{
       		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_MAX_REG, NETC_MSG_MAX_REG );
       		iRetCode = NETC_RET_MAX_REG;
       	}
	

        /* Solicita desbloqueio do semafaro */
        if ( NETC_sem_unlock(pNetC->sem_id) < 0 )
        {
                /* Erro ao obter o desbloqueio */
                NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_UNLOCK, NETC_MSG_SEM_UNLOCK );
                iRetCode = NETC_RET_SEM_UNLOCK;
        }

        /* Pos-condicoes */
        lib_assert( pNetC );

        return iRetCode;
}

/*
 * Nome: NETC_shm_inc_msg
 * Descricao: Incrementa os contadores da monitoracao
 * Parametros: Ponteiro para a estrutura na SHM, Contador, 
 *				Estrutura da mensagem
 * Retorno: NETC_RET_OK se sucesso, diferente de NETC_RET_OK caso contrario
 */
//int NETC_shm_inc_msg( stNETC_SHM *pNetC, int iVertice, stMSG msg, char* msgErro )
int NETC_shm_inc_msg( stNETC_SHM *pNetC, stMSG msg, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( pNetC );
	
	/* Regra */
	
	int iRetCode = NETC_RET_OK;

	/* Solicita bloqueio para atualizar memoria */
	if ( NETC_sem_lock(pNetC->sem_id) < 0 )
	{
		/* Erro ao obter o bloqueio */
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_LOCK, NETC_MSG_SEM_LOCK );
		iRetCode = NETC_RET_SEM_LOCK;
	}

	/* Atualiza Memoria */

        /* Busca o Issuer/Acquirer na lista, ou retorna uma posicao disponivel */
	int idx = findIndex( pNetC, msg );

	iRetCode = idx == -1 ? NETC_RET_NOK : NETC_RET_OK;

        if( iRetCode == NETC_RET_OK )
        {
        	/* Busca o Msgtype/Pcode na lista, ou retorna uma posicao disponivel */
		int mp_idx = findMtyPcode( pNetC, idx, msg.msgtype, msg.pcode );

       		if( mp_idx != -1 )
                       	iRetCode = adicionaMensagem( pNetC, idx, mp_idx, msg, msgErro );
	}

	if( iRetCode != NETC_RET_OK )
        {
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: 'Nao foi possivel inserir a mensagem:' [i%10s/a%10s/m%04d/p%06ld/r%02d]\n"			, NETC_RET_NOK, msg.issuer, msg.acquirer, msg.msgtype, msg.pcode, msg.retcode );
                iRetCode = NETC_RET_NOK;
        }
	
        /* Valida se a quantidade de registro nao chegou ao fim */
        if( getQtdeReg( pNetC ) >= MAX_NETWORKIDS )
        {
                NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_MAX_REG, NETC_MSG_MAX_REG );
                iRetCode = NETC_RET_MAX_REG;
        }


	/* Solicita desbloqueio do semafaro */
	if ( NETC_sem_unlock(pNetC->sem_id) < 0 )
	{
		/* Erro ao obter o desbloqueio */
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_UNLOCK, NETC_MSG_SEM_UNLOCK );
		iRetCode = NETC_RET_SEM_UNLOCK;
	}
	
	/* Pos-condicoes */
	lib_assert( pNetC );
	
	return iRetCode;
}

/*
 * Nome: NETC_shm_inc
 * Descricao: Solicita o incremento de um contador / mensagem
 * Parametros: Ponteiro para a estrutura na SHM, Contador, 
 *				Estrutura da mensagem
 * Retorno: NETC_shm_increment
 */
int NETC_shm_inc( stNETC_SHM *pNetC, int iVertice, char* issuer, char* acquirer,
                    int msgtype, long pcode, int retcode, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( pNetC );
	
	/* Regra */
	
	stMSG shcmsg;
	strcpy( shcmsg.issuer, issuer );
	strcpy( shcmsg.acquirer, acquirer );
	shcmsg.msgtype = msgtype;
	shcmsg.pcode = pcode;
	shcmsg.retcode = retcode;
	
	/* Para contagem de mensagem nao existe Vertice */
	if( iVertice == NETC_INDEF ) 
		//return NETC_shm_inc_msg( pNetC, iVertice, shcmsg, msgErro );
		return NETC_shm_inc_msg( pNetC, shcmsg, msgErro );
	else
		return NETC_shm_inc_vertice( pNetC, iVertice, shcmsg, msgErro );
}

/*
 * Nome: NETC_get_key
 * Descricao: Cria a chave a partir da regiao de memora de FE
 * Parametros: ISTMBREGION
 * Retorno: Chave formatada
 */
key_t NETC_get_key( int iRegion )
{
	/* Pre-condicoes */
	lib_assert( iRegion >= 0 );
	
	/* Regra */
	
	register key_t kKey = 0;
	register int iFe_region = 0;

	kKey = IPC_KEY_LIBNETC_SHM;
	iFe_region = iRegion % 256;

	kKey += iFe_region << 8;
	kKey += iFe_region << 16;
	kKey += iFe_region << 24;
	
	/* Pos-condicoes */
	lib_assert( (int)kKey );	

	return kKey;
}

/*
 * Nome: NETC_sem_create
 * Descricao: Cria um semaforo a partir da chave
 * Parametros: Chave
 * Retorno: Id do semaforo criado se sucesso, 
 *			diferente de NETC_RET_OK caso contrario
 */
int NETC_sem_create( int iSem_key, char* msgErro )
{
	/* Pre-condicoes */
	lib_assert( iSem_key >= 0 );
	
	/* Regra */
	
	int iSem_id = 0;
	int isem_val = 0;


	/* Verifica se o semaforo existe */
	iSem_id = semget(iSem_key, 1, 0666);

	if( iSem_id == -1 ) 
	{
		/* Semaforo nao existe. Criar */
		iSem_id = semget(iSem_key, 1, 0666 | IPC_CREAT);

		if( iSem_id == -1 )
		{
			/* Erro ao criar semaforo */
			NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_SEM_CREATE, NETC_MSG_SEM_CREATE );
			iSem_id = NETC_RET_SEM_CREATE;
		}
		else
		{
			/* Inicializa semaforo com valor 1 */
			isem_val = 1;
			semctl( iSem_id, 0, SETVAL, isem_val );
		}
	}

	/* Pos-condicoes */
	lib_assert( iSem_id );	
	
	return iSem_id;
}

/*
 * Nome: NETC_sem_lock
 * Descricao: Solicita bloqueio a um semaforo
 * Parametros: Id do semaforo
 * Retorno: semop
 */
//static int NETC_sem_lock( int iSem_id )
int NETC_sem_lock( int iSem_id )
{
	/* Pre-condicoes */
	lib_assert( iSem_id >= 0 );
	
	/* Regra */
	return semop(iSem_id, stLock, 1 );
}

/*
 * Nome: NETC_sem_unlock
 * Descricao: Solicita desbloqueio a um semaforo
 * Parametros: Id do semaforo
 * Retorno: semop
 */
//static int NETC_sem_unlock( int iSem_id )
int NETC_sem_unlock( int iSem_id )
{
	/* Pre-condicoes */
	lib_assert( iSem_id >= 0 );
	
	/* Regra */
	return semop(iSem_id, stUnlock, 1 );
}

/*
 * Nome: NETC_get_mbregionid
 * Descricao: Recupera a regiao de memoria configurada para o FE
 * Parametros: Front End 
 * Retorno: ISTMBREGION
 */
int NETC_get_mbregionid()
{
	/* Pre-condicoes */
	lib_assert( cFrontEnd );
	
	/* Regra */
	int iFe_region = -1;

	iFe_region = atoi( getenv("ISTMBREGION") );

	return iFe_region;
}

int getQtdeBins( const stNETC_SHM* p )
{
        return p->m_cfg.qtdeNetworkids;
}

void setQtdeBins( stNETC_SHM* p, int qtde )
{
	if( qtde <= MAX_NETWORKIDS )
        	p->m_cfg.qtdeNetworkids = qtde;
	else
	{
		p->m_cfg.qtdeNetworkids = 0;
	}
}

int getQtdePcodeMty( const stNETC_SHM* p )
{
        return p->m_cfg.qtdePcodesMtys;
}

void setQtdePcodeMty( stNETC_SHM* p, int qtde )
{
        p->m_cfg.qtdePcodesMtys = qtde;
}

int getQtdeReg( const stNETC_SHM* p )
{
        return p->qtdeReg;
}

void setQtdeReg( stNETC_SHM* p, int qtde )
{
        p->qtdeReg = qtde;
}

int addReg( stNETC_SHM* p, char* msgErro )
{
	int iRetCode = NETC_RET_OK;

	if( p->qtdeReg < MAX_NETWORKIDS )
	{
        	p->qtdeReg++;
	}
	else
	{
		NETC_LOG( netcDebug, L_FATAL, msgErro, "L-NETC-[%02d]: '%s'\n", NETC_RET_MAX_REG, NETC_MSG_MAX_REG );		
		iRetCode = NETC_RET_MAX_REG;
	}

	return iRetCode;
}

int findIss( stNETC_SHM* p, char* iss )
{
        register int iss_idx = 0;
	int found = 0;

	do
	{
       		if( !strcmp(p->data[iss_idx].issuer, iss) || !strcmp(p->data[iss_idx].issuer, NETC_DEFAULT_NETID) )
               		found = 1;
		else
               		iss_idx++;
	}while( !found && (iss_idx < getQtdeBins( p )) );

	if( !found  )
		return -1;

        return iss_idx;
}

int findAcq( stNETC_SHM* p, int iss_idx, char* acq )
{
        register int acq_idx = 0;
	int found = 0;    

	char iss[11] = {0};
	strcpy( iss, p->data[iss_idx].issuer);


	do
	{
		if( (!strcmp(p->data[acq_idx].issuer, iss) || !strcmp(p->data[acq_idx].issuer, NETC_DEFAULT_NETID)) && 
	  	    (!strcmp(p->data[acq_idx].acquirer, acq) || !strcmp(p->data[acq_idx].acquirer, NETC_DEFAULT_NETID)) )
			found = 1;
		else
			acq_idx++;
	}while( !found && (acq_idx < getQtdeBins( p )) );

	if( !found  )
		return -1;

        return acq_idx;
}

int findMtyPcode( stNETC_SHM* p, int idx, int msgtype, long pcode )
{
        register int mp_idx = 0;
        int found = 0;

	do
	{
		if( (p->data[idx].mty_pcode[mp_idx].msgtype == msgtype || 
	 	     p->data[idx].mty_pcode[mp_idx].msgtype == 0) &&
		    (p->data[idx].mty_pcode[mp_idx].pcode == pcode || 
		     p->data[idx].mty_pcode[mp_idx].pcode == 0) )
			found = 1;
		else
			mp_idx++;

	}while( !found && (mp_idx < getQtdePcodeMty( p )) );

	if( !found  )
		return -1;

        return mp_idx;
}


int findIndex( stNETC_SHM* p, stMSG msg )
{
	register int idx = -1;

	idx = findIss( p, msg.issuer );

        /* Busca o Acquirer na lista, ou retorna uma posicao disponivel */
	if( idx != -1 )
	{
		idx = findAcq( p, idx, msg.acquirer );
	}

	return idx;
}

