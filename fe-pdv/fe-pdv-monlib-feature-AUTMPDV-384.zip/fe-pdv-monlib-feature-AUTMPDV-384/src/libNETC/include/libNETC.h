#ifndef _LIBNETC_UTIL_H
#define _LIBNETC_UTIL_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
//#include <sys/mode.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

/* Desenvolvimento */
/*
#include <assert.h>
#define lib_assert(x) 		assert(x)
*/

#define lib_assert(x)

/* Config Definitions */
#define MAX_BIN                         300
#define MAX_MSGTYPES                    200
#define MAX_PCODES                      200

/* SHM Definitions */
#define MAX_NETWORKIDS 			MAX_BIN * 4
#define MAX_MSGTYPE_PCODE 		100 
#define MAX_RETCODES 			100 
#define MAX_CONTADORES 			6 
#define NETC_MAX_BUFFER 		256
#define NETC_DEFAULT_NETID		"0000000000" 
#define NETC_NOCOUNT                    0

/* Return Codes */
#define NETC_RET_OK			    1
#define NETC_RET_NOK                        2
#define NETC_RET_SHM_AT                     3
#define NETC_RET_SHM_GET                    4
#define NETC_RET_SHM_CREATE                 5
#define NETC_RET_SHM_CREATED                6
#define NETC_RET_SHM_REMOVE                 7
#define NETC_RET_SEM_CREATE                 8
#define NETC_RET_SEM_REMOVE                 9
#define NETC_RET_SEM_LOCK                   10
#define NETC_RET_SEM_UNLOCK                 11
#define NETC_RET_MAX_REG                    12
#define NETC_RET_ADD_VERTICE                13
#define NETC_RET_ADD_MSG                    14

/* Msg Erros */
#define NETC_MSG_SHM_AT                     "Erro ao obter ponteiro para a memoria compartilhada"
#define NETC_MSG_SHM_GET                    "Memoria compartilhada nao existe"
#define NETC_MSG_SHM_CREATE                 "Erro ao criar memoria compartilhada"
#define NETC_MSG_SHM_CREATED                "Memoria Compartilhada ja esta criada"
#define NETC_MSG_SHM_REMOVE                 "Erro ao remover id da SHM"
#define NETC_MSG_SEM_CREATE                 "Erro ao tentar criar semaforo"
#define NETC_MSG_SEM_REMOVE                 "Erro ao remover id da SEM"
#define NETC_MSG_SEM_LOCK                   "Erro ao obter o bloqueio"
#define NETC_MSG_SEM_UNLOCK                 "Erro ao obter o desbloqueio"
#define NETC_MSG_ADD_VERTICE                "Nao foi possivel adicionar/atualizar o vertice"
#define NETC_MSG_ADD_MSG                    "Nao foi possivel adicionar/atualizar a mensagem"
#define NETC_MSG_MAX_REG                    "Quantidade maxima de registros excedida"



/* Estrutura para leitura */
struct shm_net_table
{
	char network_id[ 11 ];                            /* Network id da rede. */
};

/* Estrutura de Configuracao */
typedef struct
{
	struct shm_net_table networkids[ MAX_BIN ];
	int levelDebug;
	int qtdeNetworkids;

	int msgtypes[ MAX_MSGTYPES ];
	long pcodes[ MAX_PCODES ];
	int qtdePcodesMtys;
}stCONFIG_TABLE;

/* Estrutura de Return Codes */
typedef struct
{
	int retcode;
	long qtde;
}stRETCODE;

/* Estrutura de Pcode / Msgtypes */
typedef struct
{
	int msgtype;
	long pcode;
	stRETCODE retcodes[ MAX_RETCODES ];
}stMSGTYPE_PCODE;


/* Estrutura dos Dados da Monitoracao */
typedef struct
{
        char issuer[11];
        char acquirer[11];
	unsigned long contadores[ MAX_CONTADORES ];

	stMSGTYPE_PCODE mty_pcode[ MAX_MSGTYPE_PCODE ];
}stDATA;


/* Estrutura de Principal dos contadores da monitoracao */
typedef struct
{
	int sem_id;
	int shm_id;
	stCONFIG_TABLE m_cfg;

	stDATA data[ MAX_NETWORKIDS ];
	int qtdeReg;
}stNETC_SHM;

/* Contadores dos formatadores(vertices) */
enum eVertices 
{
	QTDE_REQ_REC = 1,	/* Quantidade de Requests Recebidos */	
	QTDE_REQ_ENV,		/* Quantidade de Responses Enviados */	
	QTDE_RESP_REC,		/* Quantidade de Requests Recebidos */	
	QTDE_RESP_ENV, 		/* Quantidade de Responses Enviados */	
	NETC_INDEF		/* Sem incremento */	
};


/* Estrutura de entrada da mensagem */
typedef struct
{
	char issuer[11];
	char acquirer[11];
	int msgtype;
	long pcode;
	int retcode;
}stMSG;

/* Estrutura de saida da mensagem */
struct shm_data
{
        unsigned long qtdeTxn;      	/* Quantidade de Transacoes */
        unsigned long qtdeReqRec;   	/* Quantidade de Requests Recebidos */
        unsigned long qtdeReqEnv;   	/* Quantidade de Responses Enviados */
        unsigned long qtdeRespRec;  	/* Quantidade de Requests Recebidos */
        unsigned long qtdeRespEnv;  	/* Quantidade de Responses Enviados */

	char issuer[11];
	char acquirer[11];
	int msgtype;
	long pcode;
	int retcode;
	int qtderetcode;
};


/* IPC KEY */
#define IPC_KEY_LIBNETC_SHM 		0x5354564D

/* Debug */
enum NETC_DEBUG { NETC_DEBUG_NONE, NETC_DEBUG_FATAL, NETC_DEBUG_LOG, NETC_DEBUG_INFO };
enum LEVELS { L_NONE, L_FATAL, L_LOG, L_INFO };

#define IS_PRINTABLE_LEVEL( deb, ret ) ( \
		(((deb) == NETC_DEBUG_FATAL && (ret) != L_FATAL) || ((deb) == NETC_DEBUG_NONE)) ? 0 : 1 \
		)

#define NETC_LOG( deb, ret, ... ) \
	if( IS_PRINTABLE_LEVEL( (deb), (ret) ) ) \
		sprintf(__VA_ARGS__) 


/* Prototipos */
int NETC_sem_create( int iSem_key, char* msgErro );
//static int NETC_sem_lock( int iSem_id );
int NETC_sem_lock( int iSem_id );
//static int NETC_sem_unlock( int iSem_id );
int NETC_sem_unlock( int iSem_id );
key_t NETC_get_key( int iRegion );
int NETC_shm_init( int iRegion, stNETC_SHM **pNetC, char* msgErro );
int NETC_shm_create( int iRegion, stNETC_SHM **pNetC, stCONFIG_TABLE* config, char* msgErro );
int NETC_shm_remove( stNETC_SHM *pNetC, char* msgErro );
int NETC_shm_clear( stNETC_SHM *pNetC, char* msgErro );
//int NETC_shm_insert( stNETC_SHM *pNetC, stCONFIG_TABLE* config, char* msgErro );
int NETC_shm_insert( stNETC_SHM *pNetC, stCONFIG_TABLE* config );
int NETC_shm_inc( stNETC_SHM *pNetC, int iVertice, char* issuer, char* acquirer, 
				int msgtype, long pcode, int retcode, char* msgErro );
//int NETC_shm_show( const stNETC_SHM *pNetC, char* msgErro );
int NETC_shm_show( const stNETC_SHM *pNetC );
int NETC_get_mbregionid();

/* Wrappers */
int NETC_init( char* msgErro );
int NETC_increment( const int iVertice, char* issuer, char* acquirer,
                    int msgtype, long pcode, int retcode, char* msgErro );
//int NETC_read_data( struct shm_data* Datatable, int *reg_count, char* msgErro );
int NETC_read_data( struct shm_data* Datatable, int *reg_count );
//int NETC_read_data_vertice( struct shm_data* Datatable, int *reg_count, char* msgErro );
int NETC_read_data_vertice( struct shm_data* Datatable, int *reg_count );
int NETC_create( stCONFIG_TABLE* config, char* msgErro );
int NETC_clear( char* msgErro );
int NETC_remove( char* msgErro );
//int NETC_show( char* msgErro );
int NETC_show( );

/* Util */
int getQtdeBins( const stNETC_SHM* pNetC );
void setQtdeBins( stNETC_SHM* pNetC, int qtde );
int getQtdePcodeMty( const stNETC_SHM* pNetC );
void setQtdePcodeMty( stNETC_SHM* pNetC, int qtde );
int getQtdeReg( const stNETC_SHM* pNetC );
void setQtdeReg( stNETC_SHM* pNetC, int qtde );
int addReg( stNETC_SHM* pNetC, char* msgErro );
int findIss( stNETC_SHM* p, char* iss );
int findAcq( stNETC_SHM* p, int iss_idx, char* acq );
int findMtyPcode( stNETC_SHM* p, int idx, int msgtype, long pcode );
int findIndex( stNETC_SHM* p, stMSG msg );

#endif /* _LIBNETC_UTIL_H */

