/*  Nome do programa : monflex.h
 *  Executavel gerado : monFlex
 */

/*
 *  Contem definicoes do sistema.
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  05/10/2011  Versao inicial. (ID_16872)
 *  696248	22/05/2012	Altera��o conforme ID_18916, RF1.
 *	696248	07/08/2012	Altera��o conforme ID_19931, RF1.
 *	696248	05/09/2012	Inclusao da declaracao da funcao 'obtem_timestamp'.
 *                      A variavel 'general_timestamp' tornou-se global.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

/* Includes do produto*/

#include <oasis.h>
#include <syslg.h>
#include <mb.h>
#include <mem.h>
#include <util.h>
#include <debug.h>
#include <ports.h>
#include <shc.h>

/* Includes do sistema operacional*/
 
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/msg.h>

/* Funcoes Genericas */
int is_mailbox_up();
void prog_exit(int n);
int daemon_init(void);
long GetQueueSize();
int network_table_create(struct net_table *NetworksTable, char *front_end, int *reg_count);
int obtem_timestamp();

/* Funcoes de Monitoracao */
void mon_system_health();
void mon_port_report(struct mon_param);
void mon_trx_report(struct mon_param);
/*
 * Futura vers�o de monitora��o do sistema.
 * void mon_system_report(lista_param_monitoracao);
 */
void mon_networkid_report(struct mon_param);

/* Estruturas */
struct mon_param
{
	int day_report;										/* flag para ativacao do relatorio diario. */
	char path_report[255];								/* raiz do relatorio. */
};

struct net_table{
	char network_id[10 + 1];							/* Network id da rede. */
	char network_name[22 + 1];							/* Network name da rede. */
	char network_status[5 + 1];							/* Status da rede. */
};

/* Vers�o das funcoes de monitoracao */
extern char ver_trx;
extern char ver_net;
extern char ver_prt;
extern char ver_utl;
/*
 * Futura vers�o de monitora��o do sistema.
 * static char ver_sys[]="mon_system_report 1.0 05Out2011";
 */


/* Valores padrao do sistema */
#define DEFAULT_SLEEP_TIME                3
#define MAX_BIN							350

/* Variaveis globais*/
extern int net_reg_count;										/* Contador de regsitros de rede (shcbin) */
extern struct net_table net_table_list[MAX_BIN];				/* Estrutura utilizada para armazenar registros da shcbin tratados. */
extern char general_timestamp[16];								/* AAAAMMDD_HHMMSS*/
