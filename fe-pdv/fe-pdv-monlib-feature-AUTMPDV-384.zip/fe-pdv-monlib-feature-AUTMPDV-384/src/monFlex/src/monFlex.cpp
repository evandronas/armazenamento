static char ver[]="MonFlex 1.0 05Out2011";

/*  Nome do programa : Monitor Flex
 *  Executavel gerado : monFlex
 */

/*
 *  This program executes as a deamon. It have this functions:
 *     - Generates (mon_system_health) monitoration files getting data from 
 *       Shared Memory. (ID_16872)
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  05/10/2011  Versao inicial. (ID_16872)
 *	696248	05/09/2012	Incluida a  funcao 'obtem_timestamp'.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */
 
/* Includes da aplicacao */

#include <monflex.h>

/* Globais */
int sleep_time  = DEFAULT_SLEEP_TIME;
struct mon_param lista_param_monitoracao;

/* Prototipos */
void init_param();

int main(int argc, char *argv[])
{
	char debfile[80];
	//int ret;
	//int statistics_ret = 1;
	//int day_report = 0;
	char ver_net[]="mon_networkid_report 2.0 08Ago2012_ID19931RF1";
	char ver_prt[]="mon_port_report 2.0 08Ago2012_ID19931RF1";
	char ver_trx[]="mon_trx_report 2.1 08Ago2012_ID19931RF1";
	char ver_utl[]="Util 1.0 05Out2011";

	net_reg_count = 0;
	
	memset(&net_table_list, '\0', sizeof(struct net_table) * MAX_BIN);
	memset(&lista_param_monitoracao, '\0', sizeof(struct mon_param));

	syslg_setargv0(argv[0]);
	syslg("%s\n", ver);
	
    if (daemon_init() < 0)
    {
        syslg("Erro na inicializacao do modulo.\n");
        exit (1);
    }

	catch_all_signals(prog_exit);
	
    sprintf(debfile, "%s.debug",  argv[0]);
    debug_on(debfile);

	ODebug("===========================================\n");
	ODebug("%s\n",ver);
	ODebug("===========================================\n");
	ODebug("%s\n",ver_trx);
	ODebug("%s\n",ver_net);
	ODebug("%s\n",ver_prt);
	ODebug("%s\n",ver_utl);
	ODebug("===========================================\n");
	ODebug("Number of parameters: %d\n", argc);
	/*
	 * Futura vers�o de monitora��o do sistema.
	 * ODebug("%s\n",ver_sys);
	 */	

	/* Carga de parametros. */
	init_param();
	
	/* Inicializa estrutura de estatisticas. */
	
	syslg("M-FLX: mon_Flex - INICIO\n");
	ODebug("===========================================\n");	
	ODebug("Processamento - INICIO\n");	
	ODebug("===========================================\n");

	/* Laco principal */
	for (;;)
	{
   	    mon_system_health();
		
            /* Dorme */
            sleep(sleep_time);
	}

	syslg("M-FLX: mon_Flex - FIM\n");
	ODebug("===========================================\n");	
	ODebug("Processamento - FIM\n");	
	ODebug("===========================================\n");	
	
	prog_exit(0);
}

/**********************************************************
 * void init_param()                                      *
 * Obtem os parametros de configuracao do programa. Caso  *
 * nao sejam localizados tanto o arquivo de configuracao  *
 * qto os parametros, serao utilizados os valores DEFAULT *
 * das variaveis 'basicas' do programa.                   *
 **********************************************************/
void init_param()
{
	
    char cfgpath[64];
	char aux_path_report[255];
	FILE * testFile;			/* Ponteiro para testar arquivo .cfg */
	int testFlag = 0;			/* Flag de teste do arq .cfg		 */
								/* 0 - Falha						 */
								/* 1 - Sucesso						 */
	
	lista_param_monitoracao.day_report = 0;
		
    	memset(cfgpath, 0, sizeof(cfgpath));
    	sprintf(cfgpath,"%s/cfg/monFlex.cfg", getenv("FE_ROOT"));
    	
	sprintf(lista_param_monitoracao.path_report, "%s", "${HOME}/sw_web/mon_flex/");
	
	ODebug("===========================================\n");
	ODebug("INICIO DA CARGA DE CONFIGURACOES.\n");
	ODebug("===========================================\n");
	syslg("M-FLX: Inicio da carga de configuracoes.\n");

	/* Busca os parametros para funcionamento do programa.*/
	/* Visto que o resultado para encontrar/nao encontrar o arquivo ".cfg" */
	/* e o mesmo na utilizacao da funcao cf_openfile, o tratamento abaixo  */
	/* se faz necessario.                                                  */
	testFile = fopen(cfgpath, "r");
	if (testFile != NULL)
	{
		testFlag = 1;
		fclose(testFile);
	}
	else
	{
		testFlag = 0;
	}

	if (testFlag == 0)
	{
	/* Visto que nao foi localizado monFlex.cfg, o programa utilizar� os valores padr�o.*/
		
		ODebug("Arquivo de configuracao 'monFlex.cfg' nao encontrado. Utilizara valores padrao:\n");
		syslg("M-FLX: Arquivo de configuracao 'monFlex.cfg' nao encontrado. Utilizara valores padrao:\n");
		
		ODebug("mon_Flex.sleep_time:            [%d]\n", sleep_time);
		syslg("M-FLX: mon_Flex.sleep_time:            [%d]\n", sleep_time);
		
		ODebug("mon_Flex.report_path:           [%s]\n", lista_param_monitoracao.path_report);
		syslg("M-FLX: mon_Flex.report_path:           [%s]\n", lista_param_monitoracao.path_report);
		
		ODebug("===========================================\n");
		ODebug("FIM DA CARGA DE CONFIGURACOES.\n");		
		ODebug("===========================================\n");

		/* Nada mais a setar.*/
		return;
	}
	else
	{
		cf_openfile( cfgpath );
		ODebug("Localizado monFlex.cfg. Buscando parametros.\n");
		syslg("M-FLX: Localizado monFlex.cfg. Buscando parametros.\n");
	}
	
	/* Localizado monFlex.cfg */
	/* Obtendo sleep_time */
	if (cf_locatenum("mon_Flex.sleep_time", &sleep_time) < 0) 
	{
		ODebug("Parametro 'mon_Flex.sleep_time' nao encontrado. Utilizando valor padrao.\n");
		syslg("M-FLX: Parametro 'mon_Flex.sleep_time' nao encontrado. Utilizando valor padrao.\n");

		ODebug("mon_Flex.sleep_time:            [%d]\n", sleep_time);
		syslg("M-FLX: mon_Flex.sleep_time:            [%d]\n", sleep_time);
	}
	else
	{
		ODebug("mon_Flex.sleep_time:            [%d]\n", sleep_time);
		syslg("M-FLX: mon_Flex.sleep_time:            [%d]\n", sleep_time);
	}

	/* Obtendo report_path */
	if (cf_locate("mon_Flex.report_path", aux_path_report) > 0)
	{
		sprintf (lista_param_monitoracao.path_report, "%s/%s", getenv("HOME"), aux_path_report);
		
		ODebug("mon_Flex.report_path:           [%s]\n", lista_param_monitoracao.path_report);
		syslg("M-FLX: mon_Flex.report_path:           [%s]\n", lista_param_monitoracao.path_report);
	}
	else
	{
		ODebug("Nenhuma ocorrencia do parametro 'mon_Flex.report_path' encontrada. Sera utilizado o valor padrao '%s'.\n", lista_param_monitoracao.path_report);
		syslg("M-FLX: Nenhuma ocorrencia do parametro 'mon_Flex.report_path' encontrada. Sera utilizado o valor padrao '%s'.\n", lista_param_monitoracao.path_report);
		
		ODebug("mon_Flex.report_path:           [%s]\n", lista_param_monitoracao.path_report);
		syslg("M-FLX: mon_Flex.report_path:           [%s]\n", lista_param_monitoracao.path_report);
	}
		
	ODebug("===========================================\n");
	ODebug("FIM DA CARGA DE CONFIGURACOES.\n");		
	ODebug("===========================================\n");

	cf_close();
	
	return;
}

/**********************************************************
 * void mon_system_health()                               *
 * Agrupa as funcoes de monitoracao.                      *
 **********************************************************/
void mon_system_health()
{
	
	obtem_timestamp();
	mon_networkid_report(lista_param_monitoracao);
	mon_port_report(lista_param_monitoracao);
	mon_trx_report(lista_param_monitoracao);
	/*
	 * Futura vers�o de monitora��o do sistema.
	 * mon_system_report(lista_param_monitoracao);
	 */
}
