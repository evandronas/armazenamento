//static char ver[]="mon_networkid_report 1.0 06Set2011";

/*
 *     This source defines function 'mon_networkid_report' that generates data 
 *     about transactions. 
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  06/09/2011  Initial version. (ID_16872)
 *	696248	07/08/2012	Altera��o conforme ID_19931, RF1.
 *	696248	04/09/2012	Altera��o na forma de obten��o do valor para a
 *                      variavel 'general_timestamp'.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

/* Includes da aplicacao */

#include <monflex.h>

int net_reg_count;
struct net_table net_table_list[MAX_BIN];

void mon_networkid_report(struct mon_param monitor_param)
{
	
	/******************************************************************
	 * As variaveis 'hour_report_filename' e 'day_report_filename'    *
	 * podem assumir os seguintes formatos:                           *
	 *                                                                *
	 * AAAAMMDD_FLEX_NETWORKID.txt        -> Rel. diario de networks  *
	 * AAAAMMDD_HHMMSS_FLEX_NETWORKID.txt -> Rel. horario de networks *
	 ******************************************************************/	
	
	time_t now;
	struct tm  ts;
	char report[255];						/* montagem da linha do report */
	char report_timestamp[16];				/* AAAAMMDD;HHMMSS */
	char date_timestamp[9];					/* AAAAMMDD */
	char hour_reportpath[255];
	char day_reportpath[255];
	char hour_report_filename[35];
	char day_report_filename[30];
	FILE * hrF;								/* Ponteiro para arquivo horario. */
	FILE * dyF;								/* Ponteiro para arquivo diario. */

	memset(report, '\0', sizeof(report));
	memset(report_timestamp, '\0', sizeof(report_timestamp));
	memset(date_timestamp, '\0', sizeof(date_timestamp));
	memset(hour_reportpath, '\0', sizeof(hour_reportpath));
	memset(day_reportpath, '\0', sizeof(day_reportpath));
	memset(hour_report_filename, '\0', sizeof(hour_report_filename));
	memset(day_report_filename, '\0', sizeof(day_report_filename));

	/* Especifico desta funcao. */
	int system_status = 0;					/* Flag indicativa de status do sistema: 1 - UP, 0 - DOWN.*/
	int count = 0;							/* Contador local para geracao de registros no relatorio */
	int bd_err = 0;							/* Flag indicativa de erro na leitura do banco. *
											 * 0 - Erro na carga dos dados do banco         *
											 * 1 - Carga realizada com sucesso.             */
	
	char front_end[3];						/* Definicao do FE */	
	struct shcpkg *pkg;
	static int shcbin_load = 0;				/* 0 - Tabela nao carregada*
											 * 1 - Tabela ja carregada */

	memset(front_end, '\0', sizeof(front_end));
	sprintf(front_end, "%s", getenv("SITE"));

	/* Verifica se a shcbin ja esta carregada senao, carrrega. */
	if ( shcbin_load == 0 )
	{
		ODebug("Iniciando carga da tabela de redes.\n");
		if ( network_table_create(net_table_list, front_end, &net_reg_count) != DBME_EOF )
		{
			ODebug("Erro de execucao da funcao network_table_create. Nao sera poss�vel monitorar redes.\n");
			bd_err = 1;
			strcpy(net_table_list[net_reg_count].network_id, "BD_ERR");
			strcpy(net_table_list[net_reg_count].network_name, "BD_ERR");
			strcpy(net_table_list[net_reg_count].network_status, "BD_ERR");
			
		}
		else
		{
			ODebug("Foram obtidos %d registro(s) de rede para o FE %s.\n", net_reg_count + 1, front_end);	
			ODebug("Carga da tabela de redes realizada com sucesso.\n");
		}
		shcbin_load = 1;
	}
	
	/* Verifica o status do sistema nesta iteracao. */
	if (is_mailbox_up())
	{
		system_status = 1;
	}
	else
    {
	   system_status = 0;
    }
		
	/* time stamp */
	now=time(NULL);
	ts = *localtime(&now);
	strftime(report_timestamp, sizeof(report_timestamp), "%Y%m%d;%H%M%S", &ts);
	strftime(date_timestamp, sizeof(date_timestamp), "%Y%m%d", &ts);
	
	/* Monta nome/caminho do arquivo. */
	sprintf(hour_report_filename, "%s_FLEX_NETWORKID.txt", general_timestamp);
	sprintf(day_report_filename, "%s_FLEX_NETWORKID.txt", date_timestamp);
	sprintf(hour_reportpath,"%s/%s/%s", monitor_param.path_report, getenv("SITE"), hour_report_filename);
	sprintf(day_reportpath,"%s/%s/%s",  monitor_param.path_report, getenv("SITE"), day_report_filename);
	
	/* Abertura/append de arquivo horario. */
	if((hrF = fopen(hour_reportpath,"a")) == NULL)
	{
		syslg("M-NET: Erro na geracao ou inclusao de dados no relatorio horario.\n");	
		ODebug("M-NET: Erro na geracao ou inclusao de dados no relatorio horario.\n");
	}

	/* Abertura/append de arquivo diario. */
	/***************************************************************************
	 * Foi pedido que a execucao abaixo fosse removida, mas para facilitar     *
	 * caso seja solicitada novamente, vai ser s� mudar o valor da vari�vel    *
	 * global 'day_report' de '0' para '1'                                     *
	 ***************************************************************************/	
	if (monitor_param.day_report)
	{	
		if((dyF = fopen(day_reportpath,"a")) == NULL)
		{
			syslg("M-NET: Erro na geracao ou inclusao de dados no relatorio diario.\n");	
			ODebug("M-NET: Erro na geracao ou inclusao de dados no relatorio diario.\n");
		}
	}

	/* Monta linha do relatorio.*/
	for (count = 0; count <= net_reg_count; count ++)
	{
		/****************************************************************************
		 * Caso nao tenha ocorrido qualquer problema na recuperacao de dados do BD. *
		 ****************************************************************************/
		if(!bd_err)
		{		
			/*************************************************************************************
			 * - Caso ocorra erro para localizar (shc_locate_bin < 0) a rede informada na        *
			 * iteracao, esta sera tratada como 'DOWN', OU                                       *
			 * - Caso o mailbox esteja inativo (system_status == 0) a rede informada na iteracao *
			 * sera tratada como 'DOWN'.                                                         *
			 *************************************************************************************/
			if ((shc_locate_bin(&pkg, net_table_list[count].network_id) < 0) || system_status == 0)
			{
				strcpy(net_table_list[count].network_status, "DOWN");
			}
			/*************************************************************************************
			 * - Caso a rede tenha sido localizada (shc_locate_bin >= 0) e o mailbox esteja ativo*
			 * (system_status == 1), ser� verificado se a rede esta ativa ou nao.                *
			 *************************************************************************************/
			else
			{
				/* ODebug("&pkg [%x]\n", &pkg); */
				if (shc_isdown(pkg))
				{
					/* ODebug("net [%s] sts 'DOWN'. pkg [%x]'1. pkg [%x]'2 \n", net_table_list->network_id, pkg->bin.flags, pkg->bin.flags & SH_DOWN); */
					strcpy(net_table_list[count].network_status, "\0");
					strcpy(net_table_list[count].network_status, "DOWN");
				}
				else
				{
					/* ODebug("net [%s] sts 'UP'. pkg [%x]'1. pkg [%x]'2 \n", net_table_list->network_id, pkg->bin.flags, pkg->bin.flags & SH_DOWN); */
					strcpy(net_table_list[count].network_status, "\0");
					strcpy(net_table_list[count].network_status, "UP  ");
				}
			}
		}
		
		/* monta registro */
		sprintf(report, "%s;%s;%s\n", report_timestamp,
										 net_table_list[count].network_id,
										 net_table_list[count].network_status);
		fprintf(hrF, report);
		
		/***************************************************************************
		 * Foi pedido que a execucao abaixo fosse removida, mas para facilitar     *
		 * caso seja solicitada novamente, vai ser s� mudar o valor da vari�vel    *
		 * global 'day_report' de '0' para '1'                                     *
		 ***************************************************************************/	
		if (monitor_param.day_report)
		{
			fprintf(dyF, report);
		}
	}

	/* Fechamento dos arquivos utilizados. */
	fclose(hrF);	
	/***************************************************************************
	 * Foi pedido que a execucao abaixo fosse removida, mas para facilitar     *
	 * caso seja solicitada novamente, vai ser s� mudar o valor da vari�vel    *
	 * global 'day_report' de '0' para '1'                                     *
	 ***************************************************************************/	
	if (monitor_param.day_report)
	{
		fclose(dyF);
	}
	
	return;
}
