//static char ver[]="Util 1.0 05Out2011";

/*  Nome do programa : Funcoes �teis
 *  Executavel gerado : monFlex
 */

/*
 *  Contem funcoes genericas para o sistem monFlex.
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  05/10/2011  Versao inicial.
 *	696248	05/09/2012	Incluida a  funcao 'obtem_timestamp'.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

/* Includes da aplicacao */
#include <monflex.h>

static const char *INDEX_NAME = "shcbin_ix";
 
/**********************************************************
 * int is_mailbox_up()                                    *
 * Inicializacao de mail boxes para o sistema.            *
 **********************************************************/
int is_mailbox_up()
{
	static int init_done = 0;
	static int conectada = 0; 				/* 0 - nao conectada; 1 - conectada */

	/******************************************************
	 * Verifica se o mailbox do FE est� ativo;            *
	 * < 0: inativo                                       *
	 * = 0: ativo                                         *
	 ******************************************************/
	if (mb_test() < 0)
	{
		if (init_done)
		{
			/* Mailbox estava ativo na execucao anterior mas foi modificado para inativo. */
			syslg("IST status has changed to DOWN!\n");
			mb_release_resources();
		}
		else
		{
			/* Mailbox ja estava inativo na execucao anterior. */
			syslg("IST status is DOWN!\n");
		}
		init_done = 0;
		conectada = 0;
	}
	else 
	{
		if (!init_done)
		{
			if (!conectada)
			{
				/******************************************************
				 * Conecta a aplicao ao kernel do IST. So deve ser    *
				 * chamada novamente caso a tentativa anterior nao    *
				 * tenha sucesso.                                     *
				 * < 0: kernel inativo                                *
				 * = 0: kernel ativo                                  *
				 ******************************************************/
				syslg("Tentando conectar a aplicao ao IST/SW.\n");
				if (mb_initsys() == 0)
				{
					syslg("Aplicao conectada ao IST/SW.\n");
					conectada = 1;
					if (shc_initsys() < 0)
					{
						syslg("shc_initsys erro.\n");
						mb_release_resources();
					}
					else 
					{
						syslg("shc_initsys sucesso.\n");
						syslg("IST status has changed to UP!\n");
						init_done = 1;
					}
					/*init_done = 1;*/
				}
				else
				{
					syslg("Nao foi possivel conectar a aplicao ao IST/SW.\n");
					init_done = 0;
				}
			}
			else
			{
				syslg("Aplicacao ja conectada ao IST/SW.\n");
				if (shc_initsys() < 0)
				{
					syslg("shc_initsys erro.\n");
					mb_release_resources();
				}
				else 
				{
					syslg("shc_initsys sucesso.\n");
					syslg("IST status has changed to UP!\n");
					init_done = 1;
				}
				/*init_done = 1;*/
			}
		}
	}

	return (init_done);
}

/**********************************************************
 * void prog_exit(int n)                                  *
 * Trata saida do programa.                               *
 **********************************************************/
void prog_exit(int n)
{

    if(n == 0 || n == SIGTERM)
    {
        syslg("M-FLX: Normal Exit # %d.\n", n);
        ODebug("Normal Exit # %d.\n", n);
    }  
    else
    {   
        syslg("M-FLX: Exit Due to Signal %d\n", n);
        ODebug("Exit Due to Signal %d\n", n);
    }  
    
    ODebugOff();

#if 0
    if (n > 1)
        kill((short)getpid(), n);
#endif
       
    exit(n);
}

/**********************************************************
 * int daemon_init()                                      *
 * Possibilita que o programa rode como um deamon.        *
 **********************************************************/
int daemon_init()
{
    pid_t  pid;

    if ((pid = fork()) < 0)
        return(-1);
    else if (pid != 0)
        exit(0);

    /* child continues */
    setsid();       /* becames session leader */
    chdir("/");     /* change working directory */
    umask(0);       /* clear our file mode creating mask */

    return(0);
}

/**********************************************************
 * int get_network_fd(int *fd, const char *index)         *
 * Conecta a tabela indica pelo 'index' e retorna o 'fd'  *
 * obtido.                                                *
 **********************************************************/
int get_network_fd(int *fd, const char *index)
{
	if ((*fd = ist_dbm_open(index, 0)) < 0)
	{
		syslg("M-FLX: Erro na abertura da conexao com o indice '%s'. dbm_errno [%d].\n", index, dbm_errno);
		ODebug("Erro na abertura da conexao com o indice '%s'. dbm_errno [%d].\n", index, dbm_errno);
		return (dbm_errno);
	}
	else
	{
		syslg("M-FLX: Conexao estabelecida com o indice '%s' com fd '%d'.\n", index, *fd);
		ODebug("Conexao estabelecida com o indice '%s' fd '%d'.\n", index, *fd);
		return 0;	
	}
}

/**********************************************************
 * int network_table_create(struct net_table *NetworksTable, char *front_end, int *reg_count)
 * Obtem registros da shcbin, popula o ponteiro e retorna *
 * a quantidade de registros obtida.                      *
 **********************************************************/
int network_table_create(struct net_table *NetworksTable, char *front_end, int *reg_count)
{
    int dbmfd_network = 0;
	int count = 0;
	//char select_stat[26];
	struct shcbindb networkTable_db;
	
	memset(&networkTable_db, '\0', sizeof(struct shcbindb));

	/* Inicializa DBM.*/
	dbm_init();

	/*if(dbm_init() != 0)
	{
		ODebug("N�o foi poss�vel inicializar o dbm.\n");
		return (-1);
	}*/
	/* Conecta ao banco.*/
    if (get_network_fd(&dbmfd_network, INDEX_NAME) != 0)
	{
        return (-1);
	}
	
	ODebug("Obtendo dados da tabela shcbin para o FE %s.\n", front_end);

    if (dbm_selectfd_nolock(dbmfd_network, "") < 0)
    {
        syslg("M-FLX: Erro na execucao do select.\n");
		ODebug("Erro na execucao do select.\n");
        return (-1);
    }

	/* Obtem os registros e carrega o ponteiro.*/	
	ODebug("Fazendo o fetch do cursor.\n");

	for (count = 0; count < MAX_BIN; count++)
	{
		if( dbm_fetchfd(dbmfd_network, (char *)&networkTable_db) != 0)
		{
			if( dbm_errno == DBME_NOTFOUND ) /* 111 */
			{
				ODebug("Nao encontrou registros.\n");
				*reg_count = 0;
				return (DBME_NOTFOUND);
			}
			else if ( dbm_errno == DBME_EOF )
			{
				ODebug("Fim dos registros.\n");
				ist_dbm_close(INDEX_NAME, 0, dbmfd_network);
				ODebug("Conexao encerrada.\n");
				*reg_count = count-1;
				return DBME_EOF;
			}
			else
			{
				ODebug("Foi detectado o erro dbm_errno [%d].\n", dbm_errno);
				*reg_count = 0;
				return (dbm_errno);
			}
		}
		else
		{
			/*Atribui dados ao ponteiro e anda uma posi��o.*/
			strcpy(NetworksTable->network_id, networkTable_db.networkid);
			strcpy(NetworksTable->network_name, networkTable_db.bankname);
		
			NetworksTable++;
		}
	}
	return 0;
}

/************************************************************
 *    long GetQueueSize()                                   *
 *                                                          *
 ***********************************************************/
long GetQueueSize()
{
    int index = 0;
    long queueSize = 0;

    for (index = 0; index < mbNumberOfMailBoxes(); index ++)
    {
        queueSize += mbMailBoxMessages(index);
    }
    return ( queueSize );
}

/**********************************************************
 * int obtem_timestamp()                                  *
 * Obtem o valor do arquivo /tmp/timestamp.txt, valida e  *
 * escreve em 'general_timestamp'.                        *
 * Caso arquivo ou valor invalido, utiliza horario local. *
 **********************************************************/
int obtem_timestamp()
{
	
	FILE * timestamp_F;								/* Ponteiro para arquivo de timestamp. */
	char timestamp_filepath[255];
	time_t now;
	struct tm  ts;
	
	/* Timestamp file */
	memset(timestamp_filepath, '\0', sizeof(timestamp_filepath));
	sprintf(timestamp_filepath, "%s%s%s", "/tmp/timestamp_", getenv("SITE"), ".txt");
	
	/* Leitura de arquivo de timestamp. */
	if((timestamp_F = fopen(timestamp_filepath,"r")) == NULL)
	{
		syslg("M-FLX: Erro na abertura de arquivo de timestamp. Ser� utilizado o ultimo valor.\n");	
		ODebug("M-FLX: Erro na abertura de arquivo de timestamp. Ser� utilizado o ultimo valor.\n");
	}
	else
	{
		if (fread(general_timestamp, 1, 15, timestamp_F) != 15)
		{
			syslg("M-FLX: Erro na leitura do arquiv de timestamp. Ser� utilizado o ultimo valor.\n");
			ODebug("M-FLX: Erro na leitura do arquiv de timestamp. Ser� utilizado o ultimo valor.\n");
                        fclose(timestamp_F);
		}
		else
		{
			fclose(timestamp_F);
			return 0;
		}
	}
	
	/* time stamp */
	now=time(NULL);
	ts = *localtime(&now);
	strftime(general_timestamp, sizeof(general_timestamp), "%Y%m%d_%H%M%S", &ts);
	return -1;
}
