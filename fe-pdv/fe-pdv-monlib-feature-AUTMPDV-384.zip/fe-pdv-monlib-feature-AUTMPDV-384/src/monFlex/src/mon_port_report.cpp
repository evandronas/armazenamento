/*
 *     This source defines function 'mon_port_report' that generates data 
 *     about switch ports. 
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  06/09/2011  Initial version. (ID_16872)
 *	696248	07/08/2012	Altera��o conforme ID_19931, RF1.
 *	696248	04/09/2012	Altera��o na forma de obten��o do valor para a
 *                      variavel 'general_timestamp'.
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

/* Includes da aplicacao */

#include <monflex.h>

char general_timestamp[16];                             /* AAAAMMDD_HH */

void mon_port_report(struct mon_param monitor_param)
{

	/******************************************************************
	 * As variaveis 'hour_report_filename' e 'day_report_filename'    *
	 * podem assumir os seguintes formatos:                           *
	 *                                                                *
	 * AAAAMMDD_FLEX_PORTAS.txt       -> Relatorio diario de portas   *
	 * AAAAMMDD_HHMMSS_FLEX_PORTAS.txt-> Relatorio horario de portas  *
	 ******************************************************************/
	
	time_t now;
	struct tm  ts;
	char report[255];						/* montagem da linha do report */
	char report_timestamp[16];				/* AAAAMMDD;HHMMSS */
	char date_timestamp[9];					/* AAAAMMDD */
	char hour_reportpath[255];
	char day_reportpath[255];
	char hour_report_filename[35];
	char day_report_filename[30];
	FILE * hrF;								/* Ponteiro para arquivo horario. */
	FILE * dyF;								/* Ponteiro para arquivo diario. */

	memset(report, '\0', sizeof(report));
	memset(report_timestamp, '\0', sizeof(report_timestamp));
	memset(date_timestamp, '\0', sizeof(date_timestamp));
	memset(hour_reportpath, '\0', sizeof(hour_reportpath));
	memset(day_reportpath, '\0', sizeof(day_reportpath));
	memset(hour_report_filename, '\0', sizeof(hour_report_filename));
	memset(day_report_filename, '\0', sizeof(day_report_filename));
	
	/* Especifico desta funcao. */
	int mon_port_index = 0;
	//int qtde_msg = 0;
	//int max_qtde_msg = 0;
	int system_status = 0;					/* Flag indicativa de status do sistema: 1 - UP, 0 - DOWN.*/
	
	struct mbsysport mbport_general;
	
    /* Variaveis qdo IST_UP (system_status = 1) - Variaveis qdo IST_DOWN (system_status = 0) */
	int port_mbid = 0;                            int disabled_port_mbid = 0;
	char port_type;                               char disabled_port_type='D';
	char port_inout;                              char disabled_port_inout='D';
	char port_name[MB_MAX_NAME + 1];              char disabled_port_name[MB_MAX_NAME + 1];
	char port_status[22];	                      char disabled_port_status[22];
	char port_address[100];                       char disabled_port_address[100];
    /* obtida da struct */                        int disabled_num_messages = 0;
    /* obtida da struct */                        int disabled_max_msg_depth = 0;

    /* Variaveis qdo IST_UP (system_status = 1)      - Variaveis qdo IST_DOWN (system_status = 0) */
	memset(&port_type, '\0', sizeof(port_type));        /* inicializada anteriormente */
	memset(&port_inout, '\0', sizeof(port_inout));      /* inicializada anteriormente */
	memset(&port_name, '\0', sizeof(port_name));       memset(&disabled_port_name, '\0', sizeof(disabled_port_name));
	memset(&port_status, '\0', sizeof(port_status));   memset(&disabled_port_status, '\0', sizeof(disabled_port_status));
	memset(&port_address, '\0', sizeof(port_address)); memset(&disabled_port_address, '\0', sizeof(disabled_port_address));

	memset(&mbport_general, '\0', sizeof(mbport_general));
	
	/* Verifica o status do sistema nesta iteracao. */
	if (is_mailbox_up())
	{
		system_status = 1;
	}
	else
	{
		system_status = 0;
	}
	
	/* Monta linha do relatorio.*/
	
	/* time stamp */
	now=time(NULL);
	ts = *localtime(&now);
	strftime(report_timestamp, sizeof(report_timestamp), "%Y%m%d;%H%M%S", &ts);
	strftime(date_timestamp, sizeof(date_timestamp), "%Y%m%d", &ts);
	
	/* Monta nome/caminho do arquivo. */
	sprintf(hour_report_filename, "%s_FLEX_PORTAS.txt", general_timestamp);
	sprintf(day_report_filename, "%s_FLEX_PORTAS.txt", date_timestamp);
	sprintf(hour_reportpath,"%s/%s/%s", monitor_param.path_report, getenv("SITE"), hour_report_filename);
	sprintf(day_reportpath,"%s/%s/%s",  monitor_param.path_report, getenv("SITE"), day_report_filename);
	
	/* Abertura/append de arquivo horario. */
	if((hrF = fopen(hour_reportpath,"a")) == NULL)
	{
		syslg("M-PRT: Erro na geracao ou inclusao de dados no relatorio horario.\n");
		ODebug("M-PRT: Erro na geracao ou inclusao de dados no relatorio horario.\n");
	}

	/* Abertura/append de arquivo diario. */
	/***************************************************************************
	 * Foi pedido que a execucao abaixo fosse removida, mas para facilitar     *
	 * caso seja solicitada novamente, vai ser s� mudar o valor da vari�vel    *
	 * global 'day_report' de '0' para '1'                                     *
	 ***************************************************************************/
	if (monitor_param.day_report)
	{
		if((dyF = fopen(day_reportpath,"a")) == NULL)
		{
			syslg("M-PRT: Erro na geracao ou inclusao de dados no relatorio diario.\n");	
			ODebug("M-PRT: Erro na geracao ou inclusao de dados no relatorio diario.\n");
		}
	}

	/* Verifica se o mailbox est� ativo. Caso esteja, procede normalmente com a gera��o dos */
	/* dados. Se n�o estiver, imprime apenas um registro no relat�rio, informando que o     */
	/* sistema esta inativo (IST_DOWN) */
	if (system_status == 1)
	{
		for (; mon_port_index<mb->nboxes; mon_port_index++)
		{
			port_mbid=mon_port_index;
			port_type='M';
			if (mbtab[mon_port_index].flags & MB_TAB_OUTBOUND)
				port_inout='O';
			else
				port_inout='I';
			sprintf(port_name,"%s",mbMailBoxName(mon_port_index));
			sprintf(port_status,"%s","CONNECTED");
			sprintf(port_address,"%s","MAILBOX");
			
			if (mbIsPort(mon_port_index))
			{
				mb_getport(mbtab[mon_port_index].name, &mbport_general);
				
				port_mbid=mbport_general.port.mbid;
				port_type='P';
				sprintf(port_name,"%s",mbport_general.name);
				
				strncpy(port_address,mbport_general.port.address.a.address,sizeof(port_address));

				/* Tratamento de flags para determinar o status da porta. */
				
				if (mbport_general.port.flags & MB_PORT_CONNECTED)
				{
					sprintf(port_status, "%s", "CONNECTED");
				}
				/***************************************************************************
				 * Para o caso do 'localhost'. Ele tem tr�s flags: ACTIVE_LISTEN, NODE e   *
				 * CURRENTNODE. Sera apresentado no relatorio somente 'CURRENTNODE'.       *
				 ***************************************************************************/
				else if ((mbport_general.port.flags & MB_PORT_ACTIVE_LISTEN) 
					  && (mbport_general.port.flags & MB_PORT_CURRENTNODE))
				{
					sprintf(port_status, "%s", "CURRENTNODE");
				}
				/***************************************************************************
				 * Portas 'stopadas' ficam com as duas flags ACTIVE_LISTEN/PASSIVE_LISTEN e*
				 * PORT_STOPPED. Sera apresentado no relatorio somente 'STOPPED'.          *
				 ***************************************************************************/
				else if (((mbport_general.port.flags & MB_PORT_ACTIVE_LISTEN) 
						   || (mbport_general.port.flags & MB_PORT_ACTIVE_LISTEN))
						 && (mbport_general.port.flags & MB_PORT_STOPPED))
				{
					sprintf(port_status, "%s", "STOPPED");
				}
				/***************************************************************************
				 * Mas uma porta 'stopada' tb pode ter somente a flag PORT_STOPPED.        *
				 * Sera apresentado no relatorio somente 'STOPPED'.                        *
				 ***************************************************************************/
				else if (mbport_general.port.flags & MB_PORT_STOPPED)
				{
					sprintf(port_status, "%s", "STOPPED");
				}
				/***************************************************************************
				 * Uma porta com as duas flags ACTIVE_LISTEN e PASSIVE_LISTEN sera         *
				 * apresentada no relatorio como 'ACCEPTCALL'.                             *
				 ***************************************************************************/
				else if ((mbport_general.port.flags & MB_PORT_ACTIVE_LISTEN) 
					  && (mbport_general.port.flags & MB_PORT_PASSIVE_LISTEN))
				{
					sprintf(port_status, "%s", "ACCEPTCALL");
				}
				/***************************************************************************
				 * Para o caso de uma porta estar somente como ACTIVE_LISTEN               *
				 * apresentada no relatorio como 'ACTIVE_LISTEN'.                          *
				 ***************************************************************************/
				else if (mbport_general.port.flags & MB_PORT_ACTIVE_LISTEN) 
				{
					sprintf(port_status, "%s", "ACTIVE_LISTEN");
				}
				/***************************************************************************
				 * Para o caso de uma porta estar somente como PASSIVE_LISTEN              *
				 * apresentada no relatorio como 'PASSIVE_LISTEN'.                         *
				 ***************************************************************************/
				else if (mbport_general.port.flags & MB_PORT_PASSIVE_LISTEN)
				{
					sprintf(port_status, "%s", "PASSIVE_LISTEN");
				}
				/***************************************************************************
				 * Para o caso de uma porta nao estar conseguindo se conectar PORT_BUSY.   *
				 * apresentada no relatorio como 'ATTEMPTING_CONNECTION'.                  *
				 ***************************************************************************/
				else if (mbport_general.port.flags & MB_PORT_BUSY)
				{
					sprintf(port_status, "%s", "ATTEMPTING_CONNECTION");
				}
				/***************************************************************************
				 * O caso abaixo existe pois em algumas situacoes o IST nao atribui valor  *
				 * algum a flag e foi verificado que ele simplesmente considera como       *
				 * 'ATTEMPTING_CONNECTION'.                                                *
				 ***************************************************************************/
				else
				{
					sprintf(port_status, "%s", "ATTEMPTING_CONNECTION");
				}
			}
			if (strlen(port_name))
			{
				/* monta registro - IST Ativo */
				sprintf(report, "%s;%d;%c;%c;%s;%s;%s;%d;%d\n", report_timestamp,
														  port_mbid,
														  port_type,
														  port_inout,
														  port_name,
														  port_status,
														  port_address,
														  mbtab[mon_port_index].num_messages,
														  mbtab[mon_port_index].max_msg_depth);
				fprintf(hrF, report);
				
				/***************************************************************************
				 * Foi pedido que a execucao abaixo fosse removida, mas para facilitar     *
				 * caso seja solicitada novamente, vai ser s� mudar o valor da vari�vel    *
				 * global 'day_report' de '0' para '1'                                     *
				 ***************************************************************************/
				if (monitor_param.day_report)
				{
					fprintf(dyF, report);
				}
			}
			/* Para garantir que nada sobre da porta anterior. */
			memset(&mbport_general, '\0', sizeof(mbport_general));
			
		}
	}
	else
	{
	
		/* monta registro - IST Inativo */
		sprintf(disabled_port_name, "%s", "IST_DOWN");
		sprintf(disabled_port_status, "%s", "IST_DOWN");
		sprintf(disabled_port_address, "%s", "IST_DOWN");
		
		sprintf(report, "%s;%d;%c;%c;%s;%s;%s;%d;%d\n", report_timestamp,
												  disabled_port_mbid,
												  disabled_port_type,
												  disabled_port_inout,
												  disabled_port_name,
												  disabled_port_status,
												  disabled_port_address,
												  disabled_num_messages,
												  disabled_max_msg_depth);

		fprintf(hrF, report);
		
		/***************************************************************************
		 * Foi pedido que a execucao abaixo fosse removida, mas para facilitar     *
		 * caso seja solicitada novamente, vai ser s� mudar o valor da vari�vel    *
		 * global 'day_report' de '0' para '1'                                     *
		 ***************************************************************************/
		if (monitor_param.day_report)
		{
			fprintf(dyF, report);
		}

	}

	/* Fechamento dos arquivos utilizados. */
	fclose(hrF);

	/***************************************************************************
	 * Foi pedido que a execucao abaixo fosse removida, mas para facilitar     *
	 * caso seja solicitada novamente, vai ser s� mudar o valor da vari�vel    *
	 * global 'day_report' de '0' para '1'                                     *
	 ***************************************************************************/
	if (monitor_param.day_report)
	{
		fclose(dyF);
	}
	
	return;

}
