/*
 *     This source defines fuction 'mon_system_report' that generates data 
 *     about transactions. 
 *
 *  Who     When        Why
 *  ========================================================================
 *  696248  06/09/2011  Initial version. (ID_16872)
 *
 *  AP/AM / BIP         Autor   Data        Descri��o
 *  ========================================================================
 *  
 */

/* Includes da aplicacao */

#include <monflex.h>

void mon_system_report(struct mon_param monitor_param)
{

	/******************************************************************
	 * As variaveis 'hour_report_filename' e 'day_report_filename'    *
	 * podem assumir os seguintes formatos:                           *
	 *                                                                *
	 * AAAAMMDD_FLEX_BUFF.txt         -> Relatorio diario do sistema  *
	 * AAAAMMDD_HH_FLEX_BUFF.txt      -> Relatorio horario do sistema *
	 ******************************************************************/

	time_t now;
	struct tm  ts;
	char report[255];						/* montagem da linha do report */
	char report_timestamp[16];				/* AAAAMMDD;HHMMSS */
	//char general_timestamp[12];				/* AAAAMMDD_HH */
	char date_timestamp[9];					/* AAAAMMDD */
	char hour_reportpath[255];
	char day_reportpath[255];
	char hour_report_filename[30];
	char day_report_filename[30];
	FILE * hrF;								/* Ponteiro para arquivo horario. */
	FILE * dyF;								/* Ponteiro para arquivo diario. */

	memset(report, '\0', sizeof(report));
	memset(report_timestamp, '\0', sizeof(report_timestamp));
	memset(general_timestamp, '\0', sizeof(general_timestamp));
	memset(date_timestamp, '\0', sizeof(date_timestamp));
	memset(hour_reportpath, '\0', sizeof(hour_reportpath));
	memset(day_reportpath, '\0', sizeof(day_reportpath));
	memset(hour_report_filename, '\0', sizeof(hour_report_filename));
	memset(day_report_filename, '\0', sizeof(day_report_filename));	 
	 
	int mon_boxes_index =0;
	int total_mboxes = 0;
	int used_mboxes = 0;
	int total_ports = 0;
	int used_ports = 0;
	int free_buffers = 0;
	int used_buffers = 0;
	int dropped_msgs = 0;
	//int events = 0;
	
	/* Obtem total, conforme configurado no istparam.cfg */
	total_mboxes = mb->nboxes;
	total_ports = mb->nports;
	
	/* time stamp */
	now=time(NULL);
	ts = *localtime(&now);
	strftime(report_timestamp, sizeof(report_timestamp), "%Y%m%d;%H%M%S", &ts);
	strftime(general_timestamp, sizeof(general_timestamp), "%Y%m%d_%H", &ts);
	strftime(date_timestamp, sizeof(date_timestamp), "%Y%m%d", &ts);
	
	/* Monta nome/caminho do arquivo. */
	sprintf(hour_report_filename, "%s_FLEX_BUFF.txt", general_timestamp);
	sprintf(day_report_filename, "%s_FLEX_BUFF.txt", date_timestamp);
	sprintf(hour_reportpath,"%s/%s/%s", monitor_param.path_report, getenv("SITE"), hour_report_filename);
	sprintf(day_reportpath,"%s/%s/%s",  monitor_param.path_report, getenv("SITE"), day_report_filename);

	/* Obtem dados.*/
	
	/*tm_initialise_event_queue();*/

	mem_countusage(mbbuf, &free_buffers, &used_buffers);	
	
	for (; mon_boxes_index<mb->nboxes; mon_boxes_index++)
	{
		if (mbIsPort(mon_boxes_index))
		{
			if(mbtab[mon_boxes_index].flags & MB_PORT_INUSE)
			{
				used_ports++;
			}
		}
		else
		{
			if((mbtab[mon_boxes_index].flags & MB_TAB_INUSE))
			   /*&& mbValid(mon_boxes_index)
			   && !(mbtab[mon_boxes_index].flags & MB_TAB_LOCAL)
			   && !(mbtab[mon_boxes_index].flags & MB_TAB_ALIAS)
			   && !(mbtab[mon_boxes_index].flags & MB_TAB_ADDR_NOMAP))*/
			{
				used_mboxes++;
			}			
		}
		dropped_msgs = dropped_msgs + mbtab[mon_boxes_index].dropped_msg;
	}
	
	/* monta registro */
	sprintf(report, "%s;%d;%d;%d;%d;%d;%d;%d;%d;%d\n", report_timestamp,
												used_mboxes,
												total_mboxes - used_mboxes,
												used_ports,
												total_ports - used_ports,
												free_buffers,
												used_buffers,
												0,
												mb->numevtchains,
												dropped_msgs);
	
	/* Geracao/insercao de arquivo horario. */
	if((hrF = fopen(hour_reportpath,"a")) == NULL)
	{
		syslg("M-SYS: Erro na geracao ou inclusao de dados no relatorio horario.\n");	
		ODebug("M-SYS: Erro na geracao ou inclusao de dados no relatorio horario.\n");
	}
	else
	{
		fprintf(hrF, report);
		fclose(hrF);
	}

	/* Geracao/insercao de arquivo diario. */	
	/***************************************************************************
	 * Foi pedido que a execucao abaixo fosse removida, mas para facilitar     *
	 * caso seja solicitada novamente, vai ser s� mudar o valor da vari�vel    *
	 * global 'day_report' de '0' para '1'                                     *
	 ***************************************************************************/	
	if (monitor_param.day_report)
	{
		if((dyF = fopen(day_reportpath,"a")) == NULL)
		{
			syslg("M-SYS: Erro na geracao ou inclusao de dados no relatorio diario.\n");	
			ODebug("M-SYS: Erro na geracao ou inclusao de dados no relatorio diario.\n");
		}
		else
		{
			fprintf(dyF, report);
			fclose(dyF);
		}
	}	
	
	return;
}
