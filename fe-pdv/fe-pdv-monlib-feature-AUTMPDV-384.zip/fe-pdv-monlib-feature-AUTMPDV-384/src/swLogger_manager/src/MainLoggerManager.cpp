/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LoggerManager.hpp"

using namespace SWLOGGER;

enum Operation
{
	OperationCreation,
	OperationRemove,
	OperationChangeLevel,
	OperationListLevel,
	OperationResetLevel
};

Operation option;

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : usage
Descri��o : Exibe os parametros de utilizacao do binario
Par�metros : Nenhum
Retornos : Nenhum
Modifica��o : [Resumo da modifica��o (data, autor/ID def�brica, descri��o]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
void usage()
{
	printf( "Usage(): \n" );
	printf( "swLogger_manager <command> [ \"-c\" : Create | \"-d\" : Remove | \"-a\" : Change Level | \"-l\" :List Level ]\n" );
}

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : setConditions
Descri��o : Verifica as opcoes passadas na linha de comando
Par�metros : argc - Numero de parametros
Par�metros : argv - Ponteiro para ponteiro dos parametros
Retornos : 0 = OK. Diferente de zero = Erro.
Modifica��o : [Resumo da modifica��o (data, autor/ID def�brica, descri��o]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
int setConditions( int argc, char* argv[] )
{	
	if( argc < 2 )
		return -1;
	else if( !strncmp(argv[1], "-c", 2) )
		option = OperationCreation;
	else if( !strncmp(argv[1], "-d", 2) )
		option = OperationRemove;
	else if( !strncmp(argv[1], "-a", 2) )
		option = OperationChangeLevel;
	else if( !strncmp(argv[1], "-l", 2) )
		option = OperationListLevel;		
	else if( !strncmp(argv[1], "-r", 2) )
		option = OperationResetLevel;				
	else
		return -1;	
			 
	return 0;
}

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : main
Descri��o : Funcao principal
Par�metros : argc - Numero de parametros
Par�metros : argv - Ponteiro para ponteiro dos parametros
Retornos : 0 = OK. Diferente de zero = Erro.
Modifica��o : [Resumo da modifica��o (data, autor/ID def�brica, descri��o]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
int main( int argc, char* argv[] )
{
	
	char appName [8+1];
	memset(appName, '\0', sizeof(appName));

	snprintf(appName, 9, "SWLogger");

	syslg_setargv0(appName);

	// criar arquivo de debug
    char debugFile[80];
    sprintf(debugFile, "swlogger.debug" );
    debug_on(debugFile);

	// Avalia parametros de entrada
	if( setConditions( argc, argv ) < 0 )
	{
		usage();
		return 1;
	}

	ODebug("=====================================\n");
	ODebug("SWLogger Manager - V1.0\n");
	ODebug("=====================================\n");

	LoggerManager* localLoggerManager = new LoggerManager();
	
	try
	{
		switch( option )
		{
			case OperationCreation:
				if ( localLoggerManager->CriaMemoria() >= 0 )
				{
					ODebug("SHM criada com sucesso!!!\n");
					printf("SHM criada com sucesso!!!\n");

					if ( localLoggerManager->CarregaConfiguracoes() >= 0 )
					{
						showAllLevels();
					}
				}
				break;

			case OperationRemove:
				localLoggerManager->ConectaMemoria();
				if ( localLoggerManager->RemoveMemoria() >= 0 )
				{
					ODebug("SHM removida com sucesso!!!\n");
					printf("SHM removida com sucesso!!!\n");
				}
				break;

			case OperationChangeLevel:
				{
					char behaviorName[1024] = {0};
					int level;

					printf("Nome do comportamento [ NOME | ALL ]: ");
					scanf("%s", behaviorName );		
					
					printf("Nivel [ 0 - OPER | 1 - DEBUG ]: ");
					scanf("%d", &level);	
					
					ODebug("Alterando comportamento [%s] para nivel [%s]\n", behaviorName,
							(level ? "DEBUG" : "OPER"));
					printf("Alterando comportamento [%s] para nivel [%s]\n", behaviorName,
							(level ? "DEBUG" : "OPER"));
				
					localLoggerManager->ConectaMemoria();

					if ( !strncmp(behaviorName, "ALL", 3) )
					{
						changeAllLoggerLevels( level );
					}
					else
					{
						localLoggerManager->MudaNivelDebug( (const char*)behaviorName, level );
					}
					break;
				}

			case OperationListLevel:
				ODebug("Exibindo todos os niveis de logs!!!\n");
				printf("Exibindo todos os niveis de logs!!!\n");
				localLoggerManager->ConectaMemoria();
				showAllLevels();		
				break;

			case OperationResetLevel:
				ODebug("Carregando todos os niveis de logs do arquivo de configuracao!!!\n");
				printf("Carregando todos os niveis de logs do arquivo de configuracao!!!\n");
				localLoggerManager->ConectaMemoria();
				if ( localLoggerManager->CarregaConfiguracoes() >= 0 )
				{
					showAllLevels();
				}
				break;

			default:
				usage();
				break;
		}
	}
	catch( ... )
	{
		ODebug("Erro na execucao da requisicao\n");
	}

	delete[] localLoggerManager;

	ODebug("=====================================\n");

	return 0;
}
