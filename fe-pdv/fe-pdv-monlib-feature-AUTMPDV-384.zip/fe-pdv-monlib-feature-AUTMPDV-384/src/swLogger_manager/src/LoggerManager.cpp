/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LoggerManager.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LoggerManager::LoggerManager() 
	{
		for ( int index = 0; index < MAX_BEHAVIOR; index ++ )
		{
			memset( &levels[index], 0, sizeof( defaultLevelLog ) );
		}
	}

	LoggerManager::~LoggerManager()
	{
	}

	int LoggerManager::CriaMemoria()
	{
		int returnValue = -1;
		
		// Cria a area de memoria e inicializa a biblioteca
		returnValue = initialiseLogger();
		
		if ( returnValue < 0 )
		{
			ODebug("Erro na inicializacao da LibSWLogger\n");
		}
			
		return returnValue;
	}
	
	int LoggerManager::ConectaMemoria()
	{
		int returnValue = -1;
		
		// Conecta na area de memoria
		returnValue = connectToLogger();
		
		if ( returnValue < 0 )
		{
			ODebug("Erro ao conectar na LibSWLogger\n");
		}
			
		return returnValue;
	}
	
	int LoggerManager::RemoveMemoria()
	{
		int returnValue = -1;
		
		// Remove a area de memoria da biblioteca
		returnValue = removeLogger();
		
		if ( returnValue < 0 )
		{
			ODebug("Erro na remocao da area de memoria da LibSWLogger\n");
		}
			
		return returnValue;
	}	
	
	int LoggerManager::CarregaConfiguracoes()
	{
		int returnValue = 1;
		
		char parameterValue[256];
		char configurationFile[30] = {0};

		strcpy( configurationFile, uenv_constructfile("OSITE_ROOT", SWLOGGER_CONFIG ) );

        // O dbm 'esquece' de fechar o cf_openfile
        cf_close();

		ODebug("Lendo configuracoes do arquivo [%s]\n", configurationFile );
		printf("Lendo configuracoes do arquivo [%s]\n", configurationFile );
		
        // Abre arquivo de configuracao
        if ( cf_openfile( configurationFile ) < 0 )
        {
                ODebug( "Nao foi possivel abrir o arquivo [%s]\n", configurationFile );
                printf("SWL-M: Nao foi possivel abrir o arquivo [%s]\n", configurationFile );
				syslg("SWL-M: Nao foi possivel abrir o arquivo [%s]\n", configurationFile );
                return -1;
        }

		if ( cf_locate("behavior.name", parameterValue) > 0 )
		{
			int index = 0;
			do
            {
                char levelName[64] = {0};
                char levelValue[64] = {0};
				int localLevel = LevelOper;
                sscanf( parameterValue, "%s %s", levelName, levelValue );
				
				localLevel = !strcmp( levelValue, "OPER" ) ? LevelOper : LevelDebug;
				
				strcpy(levels[index].behaviorName, levelName);
				levels[index].levelStatus = localLevel;
				
				index++;
				
            } while( cf_nextparm("behavior.name", parameterValue) > 0 );
		}

    	cf_close();
		
		for ( int index = 0; index < MAX_BEHAVIOR && strlen( levels[index].behaviorName ) > 0; index++ )
		{
			ODebug("Alterando o nivel de log para o comportamento [%s]:[%s]\n", levels[index].behaviorName, 
															levels[index].levelStatus ? "DEBUG" : "OPER" );
			MudaNivelDebug( levels[index].behaviorName, levels[index].levelStatus );
		}
			
		return returnValue;
	}	
	
	int LoggerManager::MudaNivelDebug( const char* nomeComportamento, int newLevel )
	{
		int returnValue = -1;
		
		// Altera nivel de debug
		returnValue = changeLoggerLevel( nomeComportamento, newLevel );
		
		if ( returnValue < 0 )
		{
			ODebug("Erro ao alterar nivel de debug da LibSWLogger\n");
		}
			
		return returnValue;
	}		
}
