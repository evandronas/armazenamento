/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#ifndef _LOGGERMANAGER_HPP_
#define _LOGGERMANAGER_HPP_

#include <stdio.h>
#include <stdlib.h>
#include <LibSWLogger.hpp>

// Includes do produto
#include <oasis.h>

#define SWLOGGER_CONFIG "cfg/swlogger.cfg"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	enum TypeLevel
	{
		LevelOper = 0,
		LevelDebug = 1
	};
	
	/// LoggerManager
	/// Gerencia a biblioteca SWLOGGER
	/// EF/ET : ET1
	/// Historico: [Data] � [Autor] - ET - Descricao
	/// 18/11/2013 � Igor - ET1 - Criacao da versao inicial
	class LoggerManager 
	{
		private:
			defaultLevelLog levels[MAX_BEHAVIOR];	// Nivel dos tipos de logs

		public:
			/// LoggerManager
			/// Construtor padrao da classe
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			LoggerManager();

			/// ~LogCallBack
			/// Destrutor padrao da classe
			/// EF/ET : ET14
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET14 - Criacao da versao inicial
			~LoggerManager();
	
			/// CriaMemoria
			/// Cria a area de memoria e inicializa a biblioteca
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			int CriaMemoria();

			/// CriaMemoria
			/// Conecta na area de memoria da biblioteca
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			int ConectaMemoria();

			/// RemoveMemoria
			/// Remove area de memoria da biblioteca
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			int RemoveMemoria();

			/// CarregaConfiguracoes
			/// Carrega os comportamento configurados para a memoria
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			int CarregaConfiguracoes();

			/// MudaNivelDebug
			/// Altera nivel de debug
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// nomeComportamento: Ponteiro para a string com o nome do modulo
			/// newLevel: Novo nivel
			int MudaNivelDebug( const char* nomeComportamento, int newLevel );
	};
}
#endif /* _LOGGERMANAGER_HPP_ */
