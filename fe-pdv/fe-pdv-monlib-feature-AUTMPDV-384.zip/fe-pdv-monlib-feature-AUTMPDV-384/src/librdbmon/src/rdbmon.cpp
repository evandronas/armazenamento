#include <stdio.h>
#include <syslg.h>
#include <ist_cfg.h>
#include <debug.h>
#include <ist_otrace.h>
#include <libgen.h>
#include <ist_argv0.h>
#include <ctime>
#include <vector>
#include <sstream>
#include <mb.h>

#include "mondb/ShmMonDb.hpp"
#define FUNCTION_SUCCESS       0
#define FUNCTION_ERROR        -1

#define DEFAULT_SLEEP_TIME              10
#define DEFAULT_LOCAL_TRIGGER           2
#define DEFAULT_REMOTE_TRIGGER          2
#define DEFAULT_LOCAL_TRIGGER_SUMMARY   4
#define DEFAULT_REMOTE_TRIGGER_SUMMARY  4
#define DEFAULT_ITERATIONS              5
#define ALIVE_MSG                       "rdbmon alive"
#define HOSTVAR                         "_SERVER_ALIAS"

//#define SysLgTrace( format, ... ) syslg(format,__VA_ARGS__); OTraceFatal(format,__VA_ARGS__);

int LoadParameters();

static ShmMonDb * shm = ShmMonDb::getInstance();
int sleepTime = DEFAULT_SLEEP_TIME;
int toLocalTrigger = DEFAULT_LOCAL_TRIGGER;
int toRemoteTrigger = DEFAULT_REMOTE_TRIGGER;
int toLocalSummaryTrigger = DEFAULT_LOCAL_TRIGGER_SUMMARY;
int toRemoteSummaryTrigger = DEFAULT_REMOTE_TRIGGER_SUMMARY;
int toIterations = DEFAULT_ITERATIONS;
char cmdContingecy[200] = {0};
char debugLevel[200] = {0};
char hostAlias[20] = {0};

/// SysLgTrace
/// Imprime Msg no SysLg e Debug, de acordo com o Debug Level
/// AM 258.810
/// Histórico: 30.10.2019 
int SysLgTrace(int logLevel, const char * formato, ... )
{
    char buffer[256] = {0};
	//int level = 0;
	
	va_list args;
	
	va_start (args, formato);
	vsnprintf (buffer,sizeof(buffer)-1,formato, args);
    syslg(buffer);

	if ( logLevel == OTRACE_FATAL )
		OTraceFatal(buffer);
	if ( logLevel == OTRACE_ERROR )
		OTraceError(buffer);
	if ( logLevel == OTRACE_WARNING )
		OTraceWarning(buffer);
	if ( logLevel == OTRACE_INFO )
		OTraceInfo(buffer);
	if ( logLevel == OTRACE_DUMP )
		OTraceDump(buffer);
	if ( logLevel == OTRACE_DEBUG )
		OTraceDebug(buffer);

	return FUNCTION_SUCCESS;
}

/// LoadParameters
/// Carrega parametros do ISTPARAM
/// AM 258.810
/// Histórico: 30.10.2019 
int LoadParameters()
{
	cf_open("istparam.cfg");
	if( cf_locatenum( "rdbmon.sleeptime", &sleepTime ) < 0 )
	{
		SysLgTrace(OTRACE_FATAL, "rdbmon.sleeptime not found in ISTPARAM, using default value [%d]\n", sleepTime);
	}
	
	if( cf_locatenum( "rdbmon.localtrigger", &toLocalTrigger ) < 0 )
	{
		SysLgTrace(OTRACE_FATAL, "rdbmon.localtrigger not found in ISTPARAM, using default value [%d]\n", toLocalTrigger);
	}
	if( cf_locatenum( "rdbmon.remotetrigger", &toRemoteTrigger ) < 0 )
	{
		SysLgTrace(OTRACE_FATAL, "rdbmon.remotetrigger not found in ISTPARAM, using default value [%d]\n", toRemoteTrigger);
	}
	if( cf_locatenum( "rdbmon.remotesummarytrigger", &toRemoteSummaryTrigger ) < 0 )
	{
		SysLgTrace(OTRACE_FATAL, "rdbmon.remotesummarytrigger not found in ISTPARAM, using default value [%d]\n", toRemoteSummaryTrigger);
	}
	if( cf_locatenum( "rdbmon.localsummarytrigger", &toLocalSummaryTrigger ) < 0 )
	{
		SysLgTrace(OTRACE_FATAL, "rdbmon.localsummarytrigger not found in ISTPARAM, using default value [%d]\n", toLocalSummaryTrigger);
	}
	if( cf_locatenum( "rdbmon.iterations", (int *)&toIterations ) < 0 )
	{
		SysLgTrace(OTRACE_FATAL, "rdbmon.iterations not found in ISTPARAM, using default value [%d]\n", toIterations);
	}	
	cf_locate( "rdbmon.cmd", (char *)cmdContingecy );
	if( !cmdContingecy[0] )
	{
		SysLgTrace(OTRACE_FATAL, "rdbmon.cmd not found in ISTPARAM, cannot continue\n");
		return(FUNCTION_ERROR);
	}
	
	cf_locate( "rdbmon.otracelevel", (char *)debugLevel );
	if( !debugLevel[0] )
	{
		SysLgTrace(OTRACE_FATAL, "rdbmon.otracelevel not found in ISTPARAM, using INFO\n");
		ist_otrace_set_level( OTRACE_INFO );
	}
	
	if ( !strcmp(debugLevel, "DEBUG") )
		ist_otrace_set_level( OTRACE_DEBUG );
	else if ( !strcmp(debugLevel, "INFO") )
		ist_otrace_set_level( OTRACE_INFO );
	else if ( !strcmp(debugLevel, "WARNING") )
		ist_otrace_set_level( OTRACE_WARNING );				
	else if ( !strcmp(debugLevel, "ERROR") )
		ist_otrace_set_level( OTRACE_ERROR );				
	else if ( !strcmp(debugLevel, "FATAL") )
		ist_otrace_set_level( OTRACE_FATAL );
		
	if( getenv( HOSTVAR ) != NULL )
		strncpy( hostAlias, getenv( HOSTVAR ),sizeof(hostAlias)-1);
	
	SysLgTrace(OTRACE_INFO, "rdbmon.sleeptime [%d]\n", sleepTime );
	SysLgTrace(OTRACE_INFO, "rdbmon.localtrigger [%d]\n", toLocalTrigger );
	SysLgTrace(OTRACE_INFO, "rdbmon.remotetrigger [%d]\n", toRemoteTrigger );
	SysLgTrace(OTRACE_INFO, "rdbmon.localsummarytrigger [%d]\n", toLocalSummaryTrigger );
	SysLgTrace(OTRACE_INFO, "rdbmon.remotesummarytrigger [%d]\n", toRemoteSummaryTrigger );
	SysLgTrace(OTRACE_INFO, "rdbmon.iterations [%d]\n", toIterations );
	SysLgTrace(OTRACE_INFO, "rdbmon.cmd [%s]\n", cmdContingecy );
	SysLgTrace(OTRACE_INFO, "rdbmon.otracelevel [%s]\n", debugLevel );
	SysLgTrace(OTRACE_INFO, "host [%s]\n", hostAlias );
	
	if ( sleepTime <= 0 || toLocalTrigger < 0 || toRemoteTrigger < 0 || 
		 toLocalSummaryTrigger < 0 || toRemoteSummaryTrigger < 0 || toIterations < 0 ) 
	{
		SysLgTrace(OTRACE_FATAL, "Negative values not allowed. Verify ISTPARAM\n");
		return(FUNCTION_ERROR);
	}
	
	return (FUNCTION_SUCCESS);
}

/// GetSummarySamples
/// Soma a quantidade de Ocorrencias
/// AM 258.810
/// Histórico: 30.10.2019 
int GetSummarySamples( const char *sampleName, std::vector<int> lista )
{
	int soma=0;
	std::ostringstream s;
		
	for (std::vector<int>::iterator it = lista.begin() ; it != lista.end(); ++it) {
		s <<  " " << *it;
		soma += *it;
	}
	OTraceDebug("%s, somando %s :%s = %d\n", ALIVE_MSG, sampleName, s.str().c_str(), soma);

	return soma;
}

/// GetQueueSize
/// Soma a quantidade de Ocorrencias
/// AM 258.810
/// Histórico: 30.10.2019 
int GetQueueSize()
{
	int index = 0;
	int queueSize = 0;
	
	for (index = 0; index < mbNumberOfMailBoxes(); index ++)
	{
		queueSize += mbMailBoxMessages(index);
	}
	return ( queueSize );
}		

/************************************************************************************************************
* Name        : main
* Description : Main Function
* Parameters  : argc e *argv[]
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int main(int argc, char *argv[])
{
	char* shmVar = getenv (PRODUCT_SHM_VAR);
	char *progName = NULL;
	int respCode = 0;
	int shmId = 0;
	int toLocal = 0;
	int toRemoto = 0;
	int lastToLocal = 0;
	int lastToRemoto = 0;
	std::string lastTime;
	std::string currentTime;
	std::vector<int> samplesLocal;
	std::vector<int> samplesRemoto;
	int totalRemoto = 0;
	int totalLocal = 0;
	//int queueSize = 0;

	progName = basename( argv[0] );

	argv0 = progName;
	
	OTraceOn( progName );

	mb_init();
	
	if( shm->Init() )
	{
		SysLgTrace(OTRACE_FATAL, "Error on Initialization\n");
		exit(1);
	}

	SysLgTrace(OTRACE_INFO, "Compiled at %s %s\n", progName, __DATE__,__TIME__);
	SysLgTrace(OTRACE_INFO, "Number or parameters: %d\n", argc);
	if( LoadParameters() != FUNCTION_SUCCESS)
	{
		SysLgTrace(OTRACE_FATAL, "Configuration Error\n");
		exit(1);
	}
	
	SysLgTrace(OTRACE_INFO, "%s using Region : [%s]\n", progName, shmVar);
	lastToLocal = shm->GetLocalTimeout(0);
	lastToRemoto = shm->GetRemoteTimeout(0);
	lastTime = shm->GetFormattedTimestamp(time(NULL));
	
	for(;;)
	{
		currentTime = shm->GetFormattedTimestamp(time(NULL));

		shmId = shm->GetShmId();
		
		if( shmId < 0 )
		{
			respCode = shm->CreateSharedMemory();
			SysLgTrace(OTRACE_INFO,"Creating SHM - %d\n", respCode );
			if( respCode < 0 ) {
				SysLgTrace(OTRACE_FATAL,"Error: Creating SharedMemory [%d]. %s restarting\n", respCode, progName );
				break;
			}
			toLocal = 0;
			toRemoto = 0;
		} else {
			/* Virada do Dia */
			if( currentTime.substr(0,10) != lastTime.substr(0,10)) {
				SysLgTrace(OTRACE_INFO,"New Day\n");
				samplesLocal.clear();
				samplesRemoto.clear();
				lastToRemoto = 0;
				lastToLocal = 0;
				respCode = shm->InitCounters();
				SysLgTrace(OTRACE_INFO,"InitCounters. RC [%d]\n", respCode );
				// Forca a Leitura dos Parâmetros no inicio do Dia
				if( LoadParameters() != FUNCTION_SUCCESS)
				{
					SysLgTrace(OTRACE_FATAL,"Configuration Error\n");
					exit(1);
				}
			}
			
			toLocal = shm->GetLocalTimeout(0);
			toRemoto = shm->GetRemoteTimeout(0);
			
			// Inclui novo item
			samplesLocal.push_back( ( toLocal - lastToLocal ) );
			samplesRemoto.push_back( ( toRemoto - lastToRemoto ) );
			
			// Remove item anterior
			//if ( samplesLocal.size() > toIterations )
			if ( samplesLocal.size() > (unsigned int ) toIterations )
				samplesLocal.erase(samplesLocal.begin());
			//if ( samplesRemoto.size() > toIterations )
			if ( samplesRemoto.size() > (unsigned int ) toIterations )
				samplesRemoto.erase(samplesRemoto.begin());
				
			totalLocal  = GetSummarySamples("Local", samplesLocal);
			totalRemoto = GetSummarySamples("Remoto", samplesRemoto);
			
			OTraceDebug("%s, Local=%d, Remoto=%d, sum.Local=%d, sum.Remoto=%d, queue=%d\n", ALIVE_MSG, toLocal, toRemoto, totalLocal, totalRemoto, GetQueueSize() );
			if( toLocal != lastToLocal || toRemoto != lastToRemoto )
				SysLgTrace(OTRACE_FATAL, "%-3.3s Changed => Local=%d, Remoto=%d, sum.Local=%d, sum.Remoto=%d, queue=%d\n", hostAlias, toLocal, toRemoto, totalLocal, totalRemoto, GetQueueSize() );
			
			if ( toLocal < 0 || toRemoto < 0 ) {
				/* Ops something stranger, its time to FormatMemory */
				SysLgTrace(OTRACE_FATAL,"Error: Not expected values [%d:%d]. Resetting values\n", toLocal, toRemoto );
				respCode = shm->InitCounters();
				SysLgTrace(OTRACE_INFO,"InitCounters. RC [%d]\n", respCode );
			}
			if(( toLocal - lastToLocal ) >=  toLocalTrigger )
			{
				SysLgTrace(OTRACE_FATAL,"%-3.3s Too many Errors on Local DB - %d in %d seconds. Threshold %d.\n", hostAlias, ( toLocal - lastToLocal ), sleepTime, toLocalTrigger );
			}
			if(( toRemoto - lastToRemoto ) >= toRemoteTrigger )
			{
				respCode = system((const char *)cmdContingecy);
				SysLgTrace(OTRACE_FATAL, "%-3.3s Contingency ATIVATION - %d in %d seconds. Threshold %d. RC[%d]\n", hostAlias, ( toRemoto - lastToRemoto ), sleepTime, toRemoteTrigger, respCode);
			}
			if( totalLocal >=  toLocalSummaryTrigger && toIterations > 0)
			{
				SysLgTrace(OTRACE_FATAL, "%-3.3s Too many Errors on Local DB in last %d samples. Total %d. Threshold %d.\n", hostAlias, toIterations, totalLocal, toLocalSummaryTrigger );
			}
			if( totalRemoto >= toRemoteSummaryTrigger && toIterations > 0 )
			{
				respCode = system((const char *)cmdContingecy);
				SysLgTrace(OTRACE_FATAL, "%-3.3s Contingency ATIVATION - total of %d Timeout in last %d samples. Threshold %d. RC[%d]\n", hostAlias, totalRemoto, toIterations, toRemoteSummaryTrigger, respCode );
			}			
		}
		lastToLocal = toLocal;
		lastToRemoto = toRemoto;
		lastTime = shm->GetFormattedTimestamp(time(NULL));
		sleep(sleepTime);
	}
	sleep(sleepTime);
	exit(0);
}
