/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descricao: Tratamento de Shared Memory de Problemas de BD
/ Autor: Renato de Camargo
/ Data de Alteracao : 15/10/2019
/ -------------------------------------------------------------------------------------------------
*/
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <signal.h>
#include <errno.h>
#include <string>
#include <libgen.h>

#include "mondb/ShmMonDb.hpp"

#define MODULE_VERSION     "r1.0.0"
#define MODULE_NAME        "rmoncmd"
#define SetCmdParam( command, pfunction ) if(!strcmp(functionParameter,command)) function = pfunction;
#define PARAM_ERROR        -1
#define PARAM_INDEF        -2
#define PARAM_SUCCESS       0
#define FUNCTION_ERROR     -1
#define FUNCTION_SUCCESS    0

enum {
	/* Stop Start */
	NONE_FUNCTION = 0,
	CREATE_FUNCTION,
	DROP_FUNCTION,
	INFO_FUNCTION,
	KEY_FUNCTION,
	DUMP_FUNCTION,
	DUMPMON_FUNCTION,
    LIST_FUNCTION,
	MON_FUNCTION,
	INIT_FUNCTION
};

static ShmMonDb * shm = ShmMonDb::getInstance();
static int function = NONE_FUNCTION;
char *functionParameter = NULL;

/************************************************************************************************************
* Name        : Usage
* Description : See usage of program
* Parameters  : ProgramName (argv[0])
* Return      : 1
*************************************************************************************************************/
int Usage( char *programName )
{
	fprintf(stdout,"Usage : %s [options]\n", programName );
	fprintf(stdout,"Current Options for %s are :\n", programName );
	fprintf(stdout,"-create     => Create Shared Memory\n");
	fprintf(stdout,"-drop       => Drop Shared Memory\n");
	fprintf(stdout,"-viewinfo   => Show Information about Shared Memory Headers\n");
	fprintf(stdout,"-viewkey    => Show Information Shared Memory Key\n");
    fprintf(stdout,"-dump       => Show all Information Shared Memory for troubleshooting\n");
	fprintf(stdout,"-dumpe      => Show all Information about Elements\n");
    fprintf(stdout,"-list       => Show counters\n");
	fprintf(stdout,"-init       => Init Counters\n");
	exit(1);
}

/************************************************************************************************************
* Name        : ParseOptions
* Description : Execute the Parse of Command Line Options
* Parameters  : argc,  *argv[]
* Return      : PARAM_SUCCESS - Ok or PARAM_ERROR or PARAM_INDEF - Parse Error
*************************************************************************************************************/
int ParseOptions( int argc, char *argv[] )
{
	int optionParsed;

	opterr = 0;

	if( argc == 1 ) return PARAM_INDEF;

	while ( (optionParsed = getopt(argc, argv, "d:l:c:v:i:")) != -1 )
	{
		switch ( optionParsed )
		{
			case 'd':
        		if( optarg == NULL ) return PARAM_ERROR;
				functionParameter = optarg;
				SetCmdParam( "rop", DROP_FUNCTION)
                SetCmdParam( "ump", DUMP_FUNCTION)
				SetCmdParam( "umpe", DUMPMON_FUNCTION)
				if( function == NONE_FUNCTION ) return(PARAM_ERROR);
        		break;

			case 'l':
            	if( optarg == NULL ) return PARAM_ERROR;
				functionParameter = optarg;
				SetCmdParam( "ist", LIST_FUNCTION);
				if( function == NONE_FUNCTION ) return(PARAM_ERROR);
				break;
            
            case 'c':
          	    if( optarg == NULL ) return PARAM_ERROR;
				functionParameter = optarg;
				SetCmdParam( "reate", CREATE_FUNCTION);
				if( function == NONE_FUNCTION ) return(PARAM_ERROR);				
				break;

			case 'v':
				if( optarg == NULL ) return PARAM_ERROR;
				functionParameter = optarg;
				SetCmdParam( "iewkey", KEY_FUNCTION);
				SetCmdParam( "iewinfo", INFO_FUNCTION);
				if( function == NONE_FUNCTION ) return(PARAM_ERROR);
				break;
				
			case 'i':
				if( optarg == NULL ) return PARAM_ERROR;
				functionParameter = optarg;
				SetCmdParam( "nit", INIT_FUNCTION);
				if( function == NONE_FUNCTION ) return(PARAM_ERROR);
				break;				
				
			case '?':
				return(PARAM_INDEF);
		}
	}

	if(( function != CREATE_FUNCTION &&
		 function != DROP_FUNCTION   && 
		 function != INFO_FUNCTION   &&
		 function != KEY_FUNCTION    &&
		 function != DUMP_FUNCTION   && 
		 function != LIST_FUNCTION   &&
		 function != DUMPMON_FUNCTION && 
		 function != INIT_FUNCTION ))
		return PARAM_INDEF;

	return(PARAM_SUCCESS);
}

/************************************************************************************************************
* Name        : ShmInit
* Description : Release all resource allocated
* Parameters  : None
* Return      : FUNCTION_SUCCESS - Ok or FUNCTION_ERROR - Error
*************************************************************************************************************/
int ShmInit()
{
    int responseCode = shm->InitCounters();

    if( responseCode < 0 ) {
        fprintf(stdout,"Error %d\n", responseCode );
        return FUNCTION_ERROR;
    }

    return (FUNCTION_SUCCESS);
}

/************************************************************************************************************
* Name        : ShmDrop
* Description : Release all resource allocated
* Parameters  : None
* Return      : FUNCTION_SUCCESS - Ok or FUNCTION_ERROR - Error
*************************************************************************************************************/
int ShmDrop()
{
    int responseCode = shm->DropSharedMemory();

    if( responseCode < 0 ) {
        fprintf(stdout,"Error %d\n", responseCode );
        return FUNCTION_ERROR;
    }

    return (FUNCTION_SUCCESS);
}

/************************************************************************************************************
* Name        : ShmViewKey
* Description : View Keys
* Parameters  : None
* Return      : FUNCTION_SUCCESS - Ok or FUNCTION_ERROR - Error
*************************************************************************************************************/
int ShmViewKey()
{
    int shmId = shm->GetShmId();

    if( shmId < 0 ) {
        fprintf(stdout,"Error %d\n", shmId );
        return FUNCTION_ERROR;
    }
    fprintf(stdout,"Shared Memory Key : [0x%x]\n", shm->GetMainKey());
    
    return (FUNCTION_SUCCESS);
}

/************************************************************************************************************
* Name        : ShmCreate
* Description : Create Shared Memory
* Parameters  : None
* Return      : FUNCTION_SUCCESS - Ok or FUNCTION_ERROR - Error
*************************************************************************************************************/
int ShmCreate()
{
    int responseCode = shm->CreateSharedMemory();

    if( responseCode < 0 ) {
        fprintf(stdout,"Error %d\n", responseCode );
        return FUNCTION_ERROR;
    }

    return (FUNCTION_SUCCESS);
}

/************************************************************************************************************
* Name        : ShmDump
* Description : Dump all Memory Information
* Parameters  : None
* Return      : FUNCTION_SUCCESS - Ok or FUNCTION_ERROR - Error
*************************************************************************************************************/
int ShmDump()
{
    int responseCode = shm->DumpSharedMemory();

    if( responseCode < 0 ) {
        fprintf(stdout,"Error %d\n", responseCode );
        return FUNCTION_ERROR;
    }

    return (FUNCTION_SUCCESS);  
}

/************************************************************************************************************
* Name        : ShmDump
* Description : Dump all Memory Information
* Parameters  : None
* Return      : FUNCTION_SUCCESS - Ok or FUNCTION_ERROR - Error
*************************************************************************************************************/
int ShmDumpElements()
{
    int responseCode = shm->DumpElements();

    if( responseCode < 0 ) {
        fprintf(stdout,"Error %d\n", responseCode );
        return FUNCTION_ERROR;
    }

    return (FUNCTION_SUCCESS);  
}

/************************************************************************************************************
* Name        : ShmInfo
* Description : Dump all Memory Information
* Parameters  : None
* Return      : FUNCTION_SUCCESS - Ok or FUNCTION_ERROR - Error
*************************************************************************************************************/
int ShmInfo()
{
    int responseCode = shm->ShowHeaders();

    if( responseCode < 0 ) {
        fprintf(stdout,"Error %d\n", responseCode );
        return FUNCTION_ERROR;
    }

    return (FUNCTION_SUCCESS);    
}

/************************************************************************************************************
* Name        : ShmList
* Description : Dump all Memory Information
* Parameters  : None
* Return      : FUNCTION_SUCCESS - Ok or FUNCTION_ERROR - Error
*************************************************************************************************************/
int ShmList()
{
    int responseCode = shm->ShowElements();

    if( responseCode < 0 ) {
        fprintf(stdout,"Error %d\n", responseCode );
        return FUNCTION_ERROR;
    }

    return (FUNCTION_SUCCESS);  
}


/************************************************************************************************************
* Name        : main
* Description : Main Function 
* Parameters  : argc e *argv[]
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int main(int argc, char *argv[])
{
	char* shmid;
	//char* cfgName;
	char *progName;
	int respCode;

	fprintf(stderr,"%s %s compiled at %s %s\n=======================================================================\n", MODULE_NAME,MODULE_VERSION,__DATE__,__TIME__);
	progName = basename( argv[0] );

	if( ParseOptions( argc, argv ) != PARAM_SUCCESS)
		return Usage(progName);

	shmid = getenv (PRODUCT_SHM_VAR);

	if (shmid == NULL) {
		fprintf(stderr,"Variable %s not setted\n", PRODUCT_SHM_VAR );
		exit(1);
	}

    shm->Init();    
    fprintf(stdout,"Current Region : [%s]\n", shmid);
	switch ( function )
	{
		case CREATE_FUNCTION :
			respCode = ShmCreate();
			break;

		case KEY_FUNCTION :
			respCode = ShmViewKey();
			break;            
			
		case DROP_FUNCTION :
			respCode = ShmDrop();
			break;

   		case DUMP_FUNCTION :
            respCode = ShmDump();
            break;

   		case DUMPMON_FUNCTION :
            respCode = ShmDumpElements();
            break;			

   		case INFO_FUNCTION :
            respCode = ShmInfo();
            break;

        case LIST_FUNCTION :
            respCode = ShmList();
            break;
			
        case INIT_FUNCTION :
            respCode = ShmInit();
            break;			

		default :
			return Usage(progName);
			break;
    }

	if ( respCode == FUNCTION_SUCCESS)
		fprintf(stdout,"Command succesfully executed\n");

	exit(respCode);
}
