/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _LOGDUMP_HPP_
#define _LOGDUMP_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// LogDump
	/// Grava logs do dump da mensagem
	/// EF/ET : ET22
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET22 - Criacao da versao inicial
	class LogDump : public IBehavior
	{
		private:
			const char*  dumpMessage;	// Buffer da mensagem

		public:
			/// LogDump
			/// Construtor padrao da classe
			/// EF/ET : ET22
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET22 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterMessage: Buffer da mensagem de log
			LogDump( const char *parameterName = "swlogger", const char *parameterMessage = "" );
			
			/// ~LogDump
			/// Destrutor padrao da classe
			/// EF/ET : ET22
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET22 - Criacao da versao inicial
			~LogDump();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET22
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET22 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET22
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET22 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _LOGDUMP_HPP_ */
