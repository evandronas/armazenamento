/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYEXCEPTIONSHM_HPP_
#define _DENYEXCEPTIONSHM_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyExceptionShm
	/// Grava logs de negativa por excecoes de memoria compartilhada
	/// EF/ET : ET17
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET17 - Criacao da versao inicial
	class DenyExceptionShm : public IBehavior
	{
		private:
			const char* fileName;				// Nome do arquivo		
			int sharedIdentification;	// Identificacao da memoria compartilhada	
			int lineCode;				// Linha do arquivo
			const char* condition;			// Descricao da condicao	

		public:
			/// DenyExceptionShm
			/// Construtor padrao da classe
			/// EF/ET : ET17
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET17 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterFile: Nome do arquivo
			/// parameterShared: Identificacao da memoria compartilhada
			/// parameterLine: Linha do arquivo
			/// parameterCondition: Descricao da condicao	
			DenyExceptionShm( const char *parameterName = "swlogger", const char *parameterFile = "", 
							const int parameterShared = 0, const int parameterLine = 0, 
							const char *parameterCondition = "" );

			/// ~DenyExceptionShm
			/// Destrutor padrao da classe
			/// EF/ET : ET17
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET17 - Criacao da versao inicial
			~DenyExceptionShm();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET17
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET17 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET17
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET17 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYEXCEPTIONSHM_HPP_ */
