/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#ifndef _LIBRARYLOGGER_HPP_
#define _LIBRARYLOGGER_HPP_

#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <new>

#include "LevelLog.hpp"
#include "SharedUtil.hpp"
#include "IBehavior.hpp"

#define MAX_BEHAVIOR 	100
#define IPC_KEY             0x5354761D

/* 
 * Comportamentos 
 */
#include "Configuration.hpp"
#include "GenericFunction.hpp"
#include "Trace.hpp"
#include "DenyMailBox.hpp"
#include "ShutDown.hpp"
#include "DenyFormat.hpp"
#include "DenyProcess.hpp"
#include "DenyException.hpp"
#include "LogDeveloper.hpp"
#include "DenyCheckBin.hpp"
#include "LogChanges.hpp"
#include "DenyMarkDown.hpp"
#include "DenyDrop.hpp"
#include "LogCallBack.hpp"
#include "DenyCheck.hpp"
#include "DenySaf.hpp"
#include "DenyExceptionShm.hpp"
#include "LogResourceStatus.hpp"
#include "LogInitialization.hpp"
#include "LogProcessing.hpp"
#include "LogCommand.hpp"
#include "LogDump.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// LibraryLogger
	/// Gerencia as requisicoes de log
	/// EF/ET : ET1
	/// Historico: [Data] � [Autor] - ET - Descricao
	/// 18/11/2013 � Igor - ET1 - Criacao da versao inicial
	class LibraryLogger 
	{
		private:
			int sharedIdentification;				// Identificador da memoria compartilhada
			int semaphoreIdentification;			// Identificador do semaforo
			defaultLevelLog levels[MAX_BEHAVIOR];	// Nivel dos tipos de logs
			static LibraryLogger* libraryLoggerInstance;	// Instancia da classe

		protected:
			/// GetMailboxRegion
			/// Obtem o valor da regiao do Front End (ISTMBREGION)
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			static int GetMailboxRegion();

		public:
		
			/// LibraryLogger
			/// Construtor padrao da classe
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			LibraryLogger();

			/// ~Configuration
			/// Destrutor padrao da classe
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			~LibraryLogger();
		
			/// GetInstance
			/// Metodo singleton
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			static LibraryLogger* GetInstance();

			/// new
			/// Operador NEW - Cria a memoria compartilhada para a classe objeto do SWLOGGER
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// localSeed: tamanho do objeto usado como semente
			void* operator new( size_t localSeed) throw( std::bad_alloc );

			/// delete
			/// Operador DELETE - Remove a memoria compartilhada para a classe objeto do SWLOGGER
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// localSeed: tamanho do objeto usado como semente
			void operator delete( void *localPointer );

			/// LoadBehaviors
			/// Carrega os comportamento configurados para a memoria compartilhada
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			void LoadBehaviors();

			/// ExecuteLibraryLogger
			/// Factoring para as funcoes de execucao dos comportamentos
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// behavior: Ponteiro para o objetodo comportamento
			int ExecuteLibraryLogger( SWLOGGER::IBehavior* behavior );
			
			/// ChangeBehaviorLevel
			/// Altera o nivel de log de um comportamento
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// name: Nome do comportamento
			/// level: Novo nivel
			void ChangeBehaviorLevel( char* name, int level );
		
			/// SetFullLevel
			/// Altera o nivel de log de todos os comportamentos
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// level: Novo nivel
			void SetFullLevel( int level );

			/// GetBahaviorLevel
			/// Recupera o nivel atual de log de um comportamento
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// name: Nome do comportamento
			int GetBahaviorLevel( char* name );

			/// PrintLevels
			/// Exibe todos os niveis em memoria
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			void PrintLevels();
	
 			/// GetSharedMemoryIdentification
			/// Retorna o identificador da memoria compartilhada
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			int GetSharedMemoryIdentification();

			/// SetSharedMemoryIdentification
			/// Atribui o identificador da memoria compartilhada
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// parameterShared: Novo identificador da memoria compartilhada
			void SetSharedMemoryIdentification( int parameterShared );

  			/// GetSharedMemoryIdentification
			/// Retorna o identificador do semaforo
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			int GetSemaphoreIdentification();

			/// GetBahaviorLevel
			/// Retorna o identificador do semaforo
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// parameterSemaphore: Novo identificador da memoria compartilhada
			void SetSemaphoreIdentification( int parameterSemaphore );
	};

}

#endif /* _LIBRARYLOGGER_HPP_ */
