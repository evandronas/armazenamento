/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#ifndef _LEVELLOG_HPP_
#define _LEVELLOG_HPP_

#define MAX_BEHAVIOR_NAME 20

typedef struct
{
	char behaviorName[MAX_BEHAVIOR_NAME];
	int levelStatus;
}  defaultLevelLog;

#endif /* _LEVELLOG_HPP_ */
