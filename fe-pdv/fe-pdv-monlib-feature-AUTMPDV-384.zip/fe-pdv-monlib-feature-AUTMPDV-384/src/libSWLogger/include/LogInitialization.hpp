/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _LOGINITIALIZATION_HPP_
#define _LOGINITIALIZATION_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// LogInitialization
	/// Grava logs de inicializacao dos modulos
	/// EF/ET : ET16
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET16 - Criacao da versao inicial
	class LogInitialization : public IBehavior
	{
		private:
			const char*  message;	// Mensagem de inicializacao

		public:
			/// LogInitialization
			/// Construtor padrao da classe
			/// EF/ET : ET16
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET16 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterMessage: Mensagem de inicializacao
			LogInitialization( const char *parameterName = "swlogger", const char *parameterMessage = "" );
			
			/// ~LogInitialization
			/// Destrutor padrao da classe
			/// EF/ET : ET16
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET16 - Criacao da versao inicial
			~LogInitialization();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET16
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET16 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET16
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET16 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _LOGINITIALIZATION_HPP_ */
