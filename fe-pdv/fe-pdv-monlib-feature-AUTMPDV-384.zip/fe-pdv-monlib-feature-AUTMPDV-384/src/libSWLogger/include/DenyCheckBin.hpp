/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYCHECKBIN_HPP_
#define _DENYCHECKBIN_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyCheckBin
	/// Grava logs de negativa de validacao de bin
	/// EF/ET : ET10
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET10 - Criacao da versao inicial
	class DenyCheckBin : public IBehavior
	{
		private:
			const char*  binNumber;	// BIN		
			const char*  validation;	// Validacao

		public:
			/// DenyCheckBin
			/// Construtor padrao da classe
			/// EF/ET : ET10
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET10 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterBin: Numero do bin
			/// parameterValidation: Condicao da validacao
			DenyCheckBin( const char *parameterName = "swlogger", const char *parameterBin = "", 
						const char *parameterValidation = "" );
			
			/// ~DenyCheckBin
			/// Destrutor padrao da classe
			/// EF/ET : ET10
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET10 - Criacao da versao inicial
			~DenyCheckBin();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET10
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET10 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET10
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET10 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYCHECKBIN_HPP_ */
