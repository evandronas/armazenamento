/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _LOGRESOURCESTATUS_HPP_
#define _LOGRESOURCESTATUS_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// LogResourceStatus
	/// Grava logs de status dos modulos adicionais
	/// EF/ET : ET18
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET18 - Criacao da versao inicial
	class LogResourceStatus : public IBehavior
	{
		private:
			const char* resourceName;		// Recurso/modulo		
			const char* resourceStatus;	// Status do recurso

		public:
			/// LogResourceStatus
			/// Construtor padrao da classe
			/// EF/ET : ET18
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET18 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterResource: Nome do recurso/modulo
			/// parameterStatus: Status
			LogResourceStatus( const char *parameterName = "swlogger", const char *parameterResource = "", 
								const char *parameterStatus = "" );
			
			/// ~LogResourceStatus
			/// Destrutor padrao da classe
			/// EF/ET : ET18
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET18 - Criacao da versao inicial
			~LogResourceStatus();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET18
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET18 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET18
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET18 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _LOGRESOURCESTATUS_HPP_ */
