/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _LOGDEVELOPER_HPP_
#define _LOGDEVELOPER_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// LogDeveloper
	/// Grava logs do desenvolvedor
	/// EF/ET : ET9
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET9 - Criacao da versao inicial
	class LogDeveloper : public IBehavior
	{
		private:
			const char* message;	// Mensagem	

		public:
			/// LogDeveloper
			/// Construtor padrao da classe
			/// EF/ET : ET9
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET9 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterMessage: Mensagem do desenvolvedor
			LogDeveloper( const char *parameterName = "swlogger", const char* parameterMessage = "" );
			
			/// ~LogDeveloper
			/// Destrutor padrao da classe
			/// EF/ET : ET9
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET9 - Criacao da versao inicial
			~LogDeveloper();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET9
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET9 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET9
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET9 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _LOGDEVELOPER_HPP_ */
