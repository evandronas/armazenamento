/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#ifndef _LIBSWLOGGER_HPP_
#define _LIBSWLOGGER_HPP_

#include "LibraryLogger.hpp"

using namespace SWLOGGER;

//LibraryLogger *globalLibraryLogger = NULL;

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : initialiseLogger
Descrição : Funcao de interface para a inicializacao do modulo SWLOGGER
Parâmetros : Nenhum
Retornos : valor 1 = OK. Valor menor que zero = Erro.
Modificação : [Resumo da modificação (data, autor/ID defábrica, descrição]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
int initialiseLogger();

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : connectToLogger
Descrição : Funcao de interface para a inicializacao do modulo SWLOGGER
Parâmetros : Nenhum
Retornos : valor 1 = OK. Valor menor que zero = Erro.
Modificação : [Resumo da modificação (data, autor/ID defábrica, descrição]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
int connectToLogger();

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : removeLogger
Descrição : Funcao de interface para a delecao do modulo SWLOGGER
Parâmetros : Nenhum
Retornos : valor 1 = OK. Valor menor que zero = Erro.
Modificação : [Resumo da modificação (data, autor/ID defábrica, descrição]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
int removeLogger();

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : changeLoggerLevel
Descrição : Funcao de interface para a alteracao do nivel de log de um comportamento
Parâmetros : Nome do comportamento
Parâmetros : Nivel de log
Retornos : valor 1 = OK
Modificação : [Resumo da modificação (data, autor/ID defábrica, descrição]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
int changeLoggerLevel( const char* nomeComportamento, int novoNivel );

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : changeAllLoggerLevels
Descrição : Funcao de interface para a alteracao do nivel de log de todos os comportamentos
Parâmetros : Nivel de log
Retornos : valor 1 = OK
Modificação : [Resumo da modificação (data, autor/ID defábrica, descrição]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
int changeAllLoggerLevels( int novoNivel );

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : showAllLevels
Descrição : Exibe nivel de log de todos os comportamentos
Parâmetros : Nenhum
Retornos : Nenhum
Modificação : [Resumo da modificação (data, autor/ID defábrica, descrição]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
void showAllLevels();

/*
*************************************************************
Autor/Empresa : Igor/Resource
Data : 19/11/2013
Nome : executeLogger
Descrição : Funcao de interface para a execucao de um comportamento
Parâmetros : Ponteiro para o comportamento
Retornos : Nenhum
Modificação : [Resumo da modificação (data, autor/ID defábrica, descrição]
Criacao da versao inicial (19/11/2013, Igor/ID_22849, Logs no SW 7.5 CRTM
*************************************************************
*/
void executeLogger( SWLOGGER::IBehavior* behavior );

#endif /* _LIBSWLOGGER_HPP_ */
