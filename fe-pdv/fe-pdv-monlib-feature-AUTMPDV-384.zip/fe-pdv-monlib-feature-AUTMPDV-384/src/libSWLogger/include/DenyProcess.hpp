/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYPROCESS_HPP_
#define _DENYPROCESS_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyProcess
	/// Grava logs de negativa por erros no processamento
	/// EF/ET : ET7
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET7 - Criacao da versao inicial
	class DenyProcess : public IBehavior
	{
		private:
			const char* errorCondition;	// Descricao do erro

		public:
			/// DenyProcess
			/// Construtor padrao da classe
			/// EF/ET : ET7
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET7 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterConditional: Condicao da negativa
			DenyProcess( const char *parameterName = "swlogger", const char* parameterConditional = "" );
			
			/// ~DenyProcess
			/// Destrutor padrao da classe
			/// EF/ET : ET7
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET7 - Criacao da versao inicial
			~DenyProcess();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET7
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET7 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET7
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET7 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYPROCESS_HPP_ */
