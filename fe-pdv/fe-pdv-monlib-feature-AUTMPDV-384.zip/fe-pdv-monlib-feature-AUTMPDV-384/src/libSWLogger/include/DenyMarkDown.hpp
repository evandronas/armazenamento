/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYMARKDOWN_HPP_
#define _DENYMARKDOWN_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyMarkDown
	/// Grava logs de negativa por BIN Down
	/// EF/ET : ET12
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET12 - Criacao da versao inicial
	class DenyMarkDown : public IBehavior
	{
		private:
			const char*  networkCode;	// Codigo da rede (netowrkid)		
			const char*  reason;		// Motivo da negativa

		public:
			/// DenyMarkDown
			/// Construtor padrao da classe
			/// EF/ET : ET12
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET12 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterNetwork: Codigo da rede
			/// parameterReason: Motivo da negativa
			DenyMarkDown( const char *parameterName = "swlogger", const char* parameterNetwork = "", 
						const char* parameterReason = "" );
			
			/// ~DenyMarkDown
			/// Destrutor padrao da classe
			/// EF/ET : ET12
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET12 - Criacao da versao inicial
			~DenyMarkDown();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET12
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET12 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET12
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET12 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYMARKDOWN_HPP_ */
