/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#ifndef _GENERICFUNCTION_HPP_
#define _GENERICFUNCTION_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// Configuration
	/// Grava logs entrada/saida de funcoes
	/// EF/ET : ET1
	/// Historico: [Data] � [Autor] - ET - Descricao
	/// 18/11/2013 � Igor - ET1 - Criacao da versao inicial
	class GenericFunction : public IBehavior
	{
		private:
			const char* functionName;		// Nome da fun��o
			const char* functionPoint;	// Ponto na fun��o ( I - Entrada / O - Saida )

		public:
			/// GenericFunction
			/// Construtor padrao da classe
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterFunction: Nome da funcao
			/// parameterPoint: Ponto na funcao ( I - Entrada / O - Saida )
			GenericFunction( const char *parameterName = "swlogger", const char *parameterFunction = "", 
							const char *parameterPoint = "" );
			
			/// ~GenericFunction
			/// Destrutor padrao da classe
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			~GenericFunction();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
            const char* GetName();		
	};
}

#endif /* _GENERICFUNCTION_HPP_ */
