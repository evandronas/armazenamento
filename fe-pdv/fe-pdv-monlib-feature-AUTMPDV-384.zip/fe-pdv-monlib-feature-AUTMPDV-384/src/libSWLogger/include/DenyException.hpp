/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYEXCEPTION_HPP_
#define _DENYEXCEPTION_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyException
	/// Grava logs de negativa por excecoes de sistema
	/// EF/ET : ET8
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET8 - Criacao da versao inicial
	class DenyException : public IBehavior
	{
		private:
			const char*  fileName;			// Nome do arquivo		
			int lineCode;				// Linha do arquivo
			const char*  errorConditional;	// Descricao da condicao

		public:
			/// DenyException
			/// Construtor padrao da classe
			/// EF/ET : ET8
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET8 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterFile: Condicao da negativa
			/// parameterLine: Condicao da negativa
			/// parameterConditional: Condicao da negativa
			DenyException( const char *parameterName = "swlogger", const char *parameterFile = "", 
						const int parameterLine = 0, const char *parameterConditional = "" );
			
			/// ~DenyException
			/// Destrutor padrao da classe
			/// EF/ET : ET8
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET8 - Criacao da versao inicial
			~DenyException();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET8
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET8 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET8
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET8 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYEXCEPTION_HPP_ */
