/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYMAILBOX_HPP_
#define _DENYMAILBOX_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyMailBox
	/// Grava logs de falha por recurso de mailbox
	/// EF/ET : ET4
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET4 - Criacao da versao inicial
	class DenyMailBox : public IBehavior
	{
		private:
			int mailboxIdentification;	// Numero do mailbox
			long bufferSize;			// Tamanho do buffer 

		public:
			/// DenyMailBox
			/// Construtor padrao da classe
			/// EF/ET : ET4
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET4 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterMailBox: Identificador do Mailbox (MbId)
			/// parameterSize: Tamanho do buffer sendo escrito/lido
			DenyMailBox( const char *parameterName = "swlogger", const int parameterMailBox = 0, 
						const long parameterSize = 0 );
			
			/// ~DenyMailBox
			/// Destrutor padrao da classe
			/// EF/ET : ET4
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET4 - Criacao da versao inicial
			~DenyMailBox();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET4
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET4 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET4
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET4 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYMAILBOX_HPP_ */
