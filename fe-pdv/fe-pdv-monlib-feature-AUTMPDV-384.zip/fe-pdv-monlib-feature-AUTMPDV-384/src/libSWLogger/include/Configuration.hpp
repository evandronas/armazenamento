/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#ifndef _CONFIGURATION_HPP_
#define _CONFIGURATION_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// Configuration
	/// Grava logs de configuracao
	/// EF/ET : ET3
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET3 - Criacao da versao inicial
	class Configuration : public IBehavior
	{
		private:
			const char* fileName;		// Nome do arquivo de cfg
			const char* attributeConfiguration;	// Nome do atributo de cfg

		public:
			/// Configuration
			/// Construtor padrao da classe
			/// EF/ET : ET3
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET3 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterFile: Nome do arquivo de cfg
			/// parameterAttribute: Nome do atributo de cfg
			Configuration( const char *parameterName = "swlogger", const char* parameterFile = "", const char* parameterAttribute = "" );
			
			/// ~Configuration
			/// Destrutor padrao da classe
			/// EF/ET : ET3
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET3 - Criacao da versao inicial
			~Configuration();
			
			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET3
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET3 - Criacao da versao inicial
			void WriteLog();	

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET3
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET3 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _CONFIGURATION_HPP_ */

