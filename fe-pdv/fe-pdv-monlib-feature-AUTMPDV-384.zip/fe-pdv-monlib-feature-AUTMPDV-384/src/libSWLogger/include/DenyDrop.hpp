/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYDROP_HPP_
#define _DENYDROP_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyDrop
	/// Grava logs de drop por regra de negocio
	/// EF/ET : ET13
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET13 - Criacao da versao inicial
	class DenyDrop : public IBehavior
	{
		private:
			const char*  reason;	// Motivo da negativa

		public:
			/// DenyDrop
			/// Construtor padrao da classe
			/// EF/ET : ET13
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET13 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterReason: Motivo da negativa
			DenyDrop( const char *parameterName = "swlogger", const char *parameterReason = "" ); 
			
			/// ~DenyDrop
			/// Destrutor padrao da classe
			/// EF/ET : ET13
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET13 - Criacao da versao inicial
			~DenyDrop();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET13
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET13 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET13
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET13 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYDROP_HPP_ */
