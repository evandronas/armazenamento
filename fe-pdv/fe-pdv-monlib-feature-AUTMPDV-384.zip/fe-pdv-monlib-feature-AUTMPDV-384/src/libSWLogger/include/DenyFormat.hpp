/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYFORMAT_HPP_
#define _DENYFORMAT_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyFormat
	/// Grava logs de negativa por erro de formato
	/// EF/ET : ET6
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET6 - Criacao da versao inicial
	class DenyFormat : public IBehavior
	{
		private:
			const char* currentFormat;	// Formato atual
			const char* rightFormat;		// Formato correto

		public:
			/// DenyFormat
			/// Construtor padrao da classe
			/// EF/ET : ET6
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET6 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterCurrent: Identificador do Mailbox (MbId)
			/// parameterFormat: Tamanho do buffer sendo escrito/lido
			DenyFormat( const char *parameterName = "swlogger", const char* parameterCurrent = "", const char* parameterFormat = "" );
			
			/// ~DenyFormat
			/// Destrutor padrao da classe
			/// EF/ET : ET6
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET6 - Criacao da versao inicial
			~DenyFormat();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET6
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET6 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET6
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET6 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYFORMAT_HPP_ */
