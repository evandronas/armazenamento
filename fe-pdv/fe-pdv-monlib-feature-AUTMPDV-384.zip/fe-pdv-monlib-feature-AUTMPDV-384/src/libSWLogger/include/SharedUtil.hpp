/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

/* ----------------------------------------------------------------------------------
 * Sistema..: IST/SWITCH 7.5
 * Aplica��o: SWLOGGER
 * Classe...: SharedUtil
 * Descri��o: Gerencia a shared memory
 * Autor....: Resource IT Solutions
 * Vers�o...: 1.00
 * Data.....: 20/05/2013
 *
 * Historico de versoes
 * ---------------------------------------------------------------------
 * |Versao | Autor					| Data		| Descricao			   |
 * ---------------------------------------------------------------------
 * |1.00   | Resource IT Solutions	| 20/05/2013| Primeira versao	   |
 * ---------------------------------------------------------------------
 * ----------------------------------------------------------------------------------
 */

#ifndef _SHAREDUTIL_HPP_
#define _SHAREDUTIL_HPP_

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <cstring>

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// SharedUtil
	/// Gerencia a memoria compartilhada (shared memory)
	/// EF/ET : ET1
	/// Historico: [Data] � [Autor] - ET - Descricao
	/// 18/11/2013 � Igor - ET1 - Criacao da versao inicial
	template< class SharedTable >
	class SharedUtil
	{
		private:
			SharedTable *pointerClass;	// ponteiro para o objeto a ser inserido na SHM
			key_t interProcessKey;		// Chave para o IPC
			int seed;					// Semente para composicao da chave

		protected:
			/// SharedUtil
			/// Retorna a chave composta para a SHM
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// parameterRegion: Regiao do FrontEnd para criacao da memoria (MBREGIONID)
			key_t GetKey( int parameterRegion );
			
 			/// SharedUtil
			/// Cria um semaforo para controle de acesso a SHM
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// controlKey: Chave para o semaforo
			int SemaphoreCreate( int controlKey );

		public:
			/// SharedUtil
			/// Construtor padrao da classe
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// parameterKey: Chave para IPC de sistema
			/// parameterSeed: Semente para composicao da chave
			SharedUtil( key_t parameterKey, int parameterSeed = 0 ) 
				: interProcessKey( parameterKey ), seed( parameterSeed )
			{
			}

			/// ~SharedUtil
			/// Destrutor padrao da classe
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			~SharedUtil()
			{
			}

			/// CreateSharedMemory
			/// Cria a memoria compartilhada
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// sharedIdentification: Identificador para a memoria compartilhada
			int CreateSharedMemory( int sharedIdentification );

			/// RemoveSharedMemory
			/// Remove a memoria compartilhada
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// pointer: Ponteiro para o objeto a ser removido da memoria compartilhada
			int RemoveSharedMemory( SharedTable* pointer );
			
			/* 
			 * Descricao....: Retorna o ponteiro para a memoria criada.
			 * Parametros...: 
			 * Excecao: Nenhuma.
			 * Pre-condicoes: 
			 * Pos-condicoes: Nenhuma.
			 */						
			/// GetSharedMemory
			/// Retorna o ponteiro para a memoria criada
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			void* GetSharedMemory();
	};

	template< class SharedTable >
	inline key_t SharedUtil< SharedTable >::GetKey( int parameterRegion )
	{
		register key_t localKey = 0;
		register int frontEndRegion = 0;

		localKey = interProcessKey;
		frontEndRegion = parameterRegion % 256;

		localKey += frontEndRegion << 8;
		localKey += frontEndRegion << 16;
		localKey += frontEndRegion << 24;

		return localKey;
	}

	template< class SharedTable >
	inline int SharedUtil< SharedTable >::SemaphoreCreate( int controlKey )
	{
		int localSemaphoreId = 0;
		int localSemaphoreValue = 0;

		// Verifica se o semaforo existe
		localSemaphoreId = semget(controlKey, 1, 0666);

		if ( localSemaphoreId == -1 )
		{
			// Semaforo nao existe. Criar
			localSemaphoreId = semget(controlKey, 1, 0666 | IPC_CREAT);

			if ( localSemaphoreId == -1 )
			{
				// Erro ao criar semaforo
				printf("ERRO AO CRIAR SEMAFORO\n");
				localSemaphoreId = -1;
			}
			else
			{
				// Inicializa semaforo com valor 1
				localSemaphoreValue = 1;
				semctl( localSemaphoreId, 0, SETVAL, localSemaphoreValue );
			}
		}

		return localSemaphoreId;
	}

	template< class SharedTable >
	inline int SharedUtil< SharedTable >::CreateSharedMemory( int parameterRegion )
	{
		int returnCode = 0;
		int sharedIdentification = 0;
		int sharedSize = 0;
		key_t localKey = 0;

		SharedTable *pointerClassAux;
		sharedSize = sizeof( SharedTable );

		// Obtem a chave a partir da regiao de memoria do FE
		localKey = GetKey( parameterRegion );

		// Verifica se a memoria existe
		sharedIdentification = shmget(localKey, sharedSize, 0666);

		if ( sharedIdentification != -1 )
		{
			// Memoria compartilhada ja existe. Obtem endereco do ponteiro
			if ( (pointerClassAux = (SharedTable*) shmat(sharedIdentification, NULL, 0)) == (void *) -1 )
			{
				// Erro ao obter ponteiro para a memoria compartilhada
				printf("ERRO AO OBTER PONTEIRO PARA A MEMORIA COMPARTILHADA\n");
				returnCode = -1;
			}
			else
			{
				// Ja existe
				returnCode = 1;
			}
		}
		else // Memoria compartilhada nao existe. Cria nova area de memoria
		{
			// Cria area memoria */
			sharedIdentification = shmget( localKey, sharedSize, 0666 | IPC_CREAT );

			if ( sharedIdentification != -1 )
			{
				// Memoria compartilhada foi criada. Obtem endereco do ponteiro
				if ( (pointerClassAux = (SharedTable *) shmat(sharedIdentification, NULL, 0)) == (void *) -1 )
				{
					// Erro ao obter ponteiro para a memoria compartilhada
					printf("ERRO AO OBTER PONTEIRO PARA A MEMORIA COMPARTILHADA\n");
					returnCode = -1;
				}
				else
				{
					memset( pointerClassAux, 0, sizeof( SharedTable ) );

					// Atribui o id da SHM ao ponteiro
					pointerClassAux->SetSharedMemoryIdentification( sharedIdentification );

					// Cria semaforo para acesso a memoria compartilhada
					int semId = SemaphoreCreate( localKey );
					pointerClassAux->SetSemaphoreIdentification( semId );
					if ( semId < 0 )
					{
						// Erro ao tentar criar semaforo
						printf("ERRO AO TENTAR CRIAR SEMAFORO\n");
						returnCode = -1;
					}
					returnCode = 1;
				}
			}
			else
			{
				// Memoria compartilhada nao foi criada
				printf("MEMORIA COMPARTILHADA NAO FOI CRIADA\n");
				returnCode = -1;
			}
		}

		// Atribui o endereco da estrutura da SHM ao ponteiro da funcao
		if ( returnCode == 1 )
		{
			pointerClass = pointerClassAux;
		}

		return returnCode;
	}

	template< class SharedTable >
	inline int SharedUtil< SharedTable >::RemoveSharedMemory( SharedTable* pointer )
	{
		int returnCode = 0;

		if ( pointer == NULL || pointer->GetSharedMemoryIdentification() < 0 )
		{
			printf("ID SHM NAO EXISTE!!!\n");
			return -1;
		}
		
		if ( shmctl(pointer->GetSharedMemoryIdentification(), IPC_RMID, 0) < 0 )
		{
			// Erro ao remover id da SHM
			printf("ERRO AO REMOVER ID DA SHM\n");
			returnCode = -1;
		}
		
		if ( semctl(pointer->GetSemaphoreIdentification(), 0, IPC_RMID) < 0 )
		{
			// Erro ao remover id da SHM
			printf("ERRO AO REMOVER SEMAFORO\n");
			returnCode = -1;
		}

		return returnCode;
	}

	template< class SharedTable >
	inline void* SharedUtil< SharedTable >::GetSharedMemory()
	{
		return (void*)pointerClass;
	}
}

#endif /* _SHAREDUTIL_HPP_ */

