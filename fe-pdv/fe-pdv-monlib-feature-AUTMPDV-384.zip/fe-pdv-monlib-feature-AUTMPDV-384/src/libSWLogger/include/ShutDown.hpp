/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _SHUTDOWN_HPP_
#define _SHUTDOWN_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// ShutDown
	/// Grava logs de saida dos programas
	/// EF/ET : ET5
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET5 - Criacao da versao inicial
	class ShutDown : public IBehavior
	{
		private:
			int signalNumber;	// Numero do sinal de saida do modulo

		public:
			/// ShutDown
			/// Construtor padrao da classe
			/// EF/ET : ET5
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET5 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterSignal: Numero do sinal de saida do modulo
			ShutDown( const char *parameterName = "swlogger", const int parameterSignal = 0 );
			
			/// ~ShutDown
			/// Destrutor padrao da classe
			/// EF/ET : ET5
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET5 - Criacao da versao inicial
			~ShutDown();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET5
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET5 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET5
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET5 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _SHUTDOWN_HPP_ */
