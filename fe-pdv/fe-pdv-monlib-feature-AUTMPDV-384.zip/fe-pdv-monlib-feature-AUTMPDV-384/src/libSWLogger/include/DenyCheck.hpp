/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYCHECK_HPP_
#define _DENYCHECK_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenyCheck
	/// Grava logs de negativa por regras de negocio
	/// EF/ET : ET15
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET15 - Criacao da versao inicial
	class DenyCheck : public IBehavior
	{
		private:
			const char*  conditional;	// Condicao da negativa		

		public:
			/// DenyCheck
			/// Construtor padrao da classe
			/// EF/ET : ET15
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET15 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterConditional: Condicao da negativa
			DenyCheck( const char *parameterName = "swlogger", const char *parameterConditional = "" );
			
			/// ~DenyCheck
			/// Destrutor padrao da classe
			/// EF/ET : ET15
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET15 - Criacao da versao inicial
			~DenyCheck();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET15
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET15 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET15
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET15 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYCHECK_HPP_ */
