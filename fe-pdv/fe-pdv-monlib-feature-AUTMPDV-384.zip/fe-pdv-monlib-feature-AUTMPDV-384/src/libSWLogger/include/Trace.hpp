/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#ifndef _TRACE_HPP_
#define _TRACE_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// Trace
	/// Grava logs de rastreabilidade da transacao
	/// EF/ET : ET2
	/// Historico: [Data] � [Autor] - ET - Descricao
	/// 18/11/2013 � Igor - ET2 - Criacao da versao inicial
	class Trace : public IBehavior
	{
		private:
			int messageType;			// Tipo da mensagem da transacao
			long processCode;			// Codigo de processamento
			const char* sequenceNumber;		// Numero sequencial unico
			const char* terminalCode;			// Codigo do terminal
			long terminalSequence;		// Sequencial do terminal
			const char* cardNumber;			// Numero do cartao
			char  maskCardNumber[19+1];	// Numero do cartao mascarado
			const char* reasonCode;			// Codigo de motivo de negativa

		private:
			/// MaskCard
			/// Mascara o numero do cartao para exibica no arquivo de log
			/// EF/ET : ET2
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET2 - Criacao da versao inicial
			/// parameterCard: Numero do cartao a ser mascarado
            void MaskCard( char* parameterCard );

		public:
			/// Trace
			/// Construtor padrao da classe
			/// EF/ET : ET2
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET2 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterType: Tipo da mensagem da transacao
			/// parameterCode: Codigo de processamento
			/// parameterSequence: Numero sequencial unico
			/// parameterTerminal: Codigo do terminal
			/// parameterStan: Sequencial do terminal
			/// parameterCard: Numero do cartao
			/// parameterReason: Codigo de motivo de negativa
			Trace( const char *parameterName = "swlogger", int parameterType = 0, long parameterCode = 0,
					const char* parameterSequence = "", const char* parameterTerminal = "", long parameterStan = 0,
					const char* parameterCard = "", const char* parameterReason = "" );

			/// ~Trace
			/// Destrutor padrao da classe
			/// EF/ET : ET2
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET2 - Criacao da versao inicial
			~Trace();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET2
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET2 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET2
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET2 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _TRACE_HPP_ */
