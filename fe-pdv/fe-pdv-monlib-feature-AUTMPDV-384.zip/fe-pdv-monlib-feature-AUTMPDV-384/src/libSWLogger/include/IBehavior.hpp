/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#ifndef _IBEHAVIOR_HPP_
#define _IBEHAVIOR_HPP_

#include <assert.h>
#include <stdio.h>
#include <cstring>
#include <syslg.h>

#define MAX_MODULE_NAME 10

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// IBehavior
	/// Classe de interface para os comportamentos de log
	/// EF/ET : ET1
	/// Historico: [Data] � [Autor] - ET - Descricao
	/// 18/11/2013 � Igor - ET1 - Criacao da versao inicial
	class IBehavior
	{
		private:
			char moduleName[ MAX_MODULE_NAME ]; 		// Nome do modulo corrente

		public:
			/// ~IBehavior
			/// Destrutor padrao da classe
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			virtual ~IBehavior() {};
			
			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			virtual void WriteLog() = 0;		

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			virtual const char* GetName() = 0;	
		
			/// GetModuleName
			/// Retorna o nome do modulo corrente
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			virtual const char* GetModuleName();

			/// SetModuleName
			/// Atribui o nome do modulo corrente
			/// EF/ET : ET1
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET1 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			virtual void SetModuleName( const char* parameterName );
	};
}

#endif /* _IBEHAVIOR_HPP_ */
