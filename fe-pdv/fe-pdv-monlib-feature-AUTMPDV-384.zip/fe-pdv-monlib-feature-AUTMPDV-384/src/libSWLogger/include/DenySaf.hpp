/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/
 
#ifndef _DENYSAF_HPP_
#define _DENYSAF_HPP_

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	/// DenySaf
	/// Grava logs de negativa por SAF
	/// EF/ET : ET16
	/// Historico: [Data] – [Autor] - ET - Descricao
	/// 18/11/2013 – Igor - ET16 - Criacao da versao inicial
	class DenySaf : public IBehavior
	{
		private:
			const char*  networkCode;	// Codigo da rede
			const char*  conditional;	// Condicao da negativa

		public:
			/// DenySaf
			/// Construtor padrao da classe
			/// EF/ET : ET16
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET16 - Criacao da versao inicial
			/// parameterName: Ponteiro para a string com o nome do modulo
			/// parameterNetwork: Codigo da rede
			/// parameterConditional: Condicao da validacao
			DenySaf( const char *parameterName = "swlogger", const char *parameterNetwork = "", 
					const char *parameterConditional = "" );
			
			/// ~DenySaf
			/// Destrutor padrao da classe
			/// EF/ET : ET16
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET16 - Criacao da versao inicial
			~DenySaf();

			/// WriteLog
			/// Funcao principal de gravacao dos comportamentos
			/// EF/ET : ET16
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET16 - Criacao da versao inicial
			void WriteLog();

			/// GetName
			/// Retorna o nome do comportamento
			/// EF/ET : ET16
			/// Historico: [Data] - ET - Descricao
			/// 18/11/2013 - ET16 - Criacao da versao inicial
            const char* GetName();
	};
}

#endif /* _DENYSAF_HPP_ */
