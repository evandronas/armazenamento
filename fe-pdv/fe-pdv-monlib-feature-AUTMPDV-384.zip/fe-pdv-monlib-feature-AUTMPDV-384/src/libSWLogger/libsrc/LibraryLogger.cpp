/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LibraryLogger.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LibraryLogger *LibraryLogger::libraryLoggerInstance = NULL;

	int LibraryLogger::GetMailboxRegion()
	{
		int frontEndRegion = -1;

		frontEndRegion = atoi( getenv("ISTMBREGION") );

		return frontEndRegion;
	}

	LibraryLogger::LibraryLogger()
	{
	}

	LibraryLogger::~LibraryLogger()
	{
	}

	LibraryLogger* LibraryLogger::GetInstance()
	{
		return  ( libraryLoggerInstance == NULL ? (libraryLoggerInstance = new LibraryLogger()) : libraryLoggerInstance );
	}

	void* LibraryLogger::operator new(size_t localSeed) throw(std::bad_alloc)
	{
		SharedUtil< LibraryLogger > localShared( IPC_KEY, localSeed );

		// Cria objeto na memoria compartilhada
		if ( localShared.CreateSharedMemory( GetMailboxRegion() ) < 0 )
			throw std::bad_alloc();

		// obtem ponteiro da memoria
		void* returnPointer = (void*)localShared.GetSharedMemory();

		// retorna dados
		return returnPointer;
	}

	void LibraryLogger::operator delete(void *localPointer) 
	{
		if ( localPointer != NULL )
		{
			// remove objeto memoria compartilhada
			SharedUtil< LibraryLogger > localShared( IPC_KEY );
			localShared.RemoveSharedMemory( (LibraryLogger*)localPointer );
			localPointer = NULL;
		}
	}

	void LibraryLogger::LoadBehaviors()
	{
		int index = 0;
		strcpy( levels[ index++ ].behaviorName, "GENERICFUNCTION" );
		strcpy( levels[ index++ ].behaviorName, "TRACE" );  
		strcpy( levels[ index++ ].behaviorName, "CFG" );     
		strcpy( levels[ index++ ].behaviorName, "DENYMB" );		
		strcpy( levels[ index++ ].behaviorName, "SHUTDOWN" );
		strcpy( levels[ index++ ].behaviorName, "DENYFORMAT" );       
		strcpy( levels[ index++ ].behaviorName, "DENYPROCESS" );      
		strcpy( levels[ index++ ].behaviorName, "DENYEXCEPTION" );    
		strcpy( levels[ index++ ].behaviorName, "LOGDEVELOPER" );
		strcpy( levels[ index++ ].behaviorName, "DENYCHECKBIN" );     
		strcpy( levels[ index++ ].behaviorName, "LOGTXNCHANGES" );    
		strcpy( levels[ index++ ].behaviorName, "DENYMARKDOWN" );     
		strcpy( levels[ index++ ].behaviorName, "DENYDROP" );         
		strcpy( levels[ index++ ].behaviorName, "LOGCALLBACK" );      
		strcpy( levels[ index++ ].behaviorName, "DENYCHECK" );        
		strcpy( levels[ index++ ].behaviorName, "DENYSAF" );          
		strcpy( levels[ index++ ].behaviorName, "DENYEXCEPTIONSHM" ); 
		strcpy( levels[ index++ ].behaviorName, "LOGRESOURCESTATUS" );
		strcpy( levels[ index++ ].behaviorName, "LOGINITIALIZATION" );
		strcpy( levels[ index++ ].behaviorName, "LOGPROCESSING" );    
		strcpy( levels[ index++ ].behaviorName, "LOGCOMMAND" );       
		strcpy( levels[ index++ ].behaviorName, "LOGTXNDUMP" );       
	}

	int LibraryLogger::ExecuteLibraryLogger( IBehavior* behavior )
	{
		if ( behavior != NULL )
		{
			if ( GetBahaviorLevel( (char*)behavior->GetName() ) )
			{
				behavior->WriteLog();
			}
			delete behavior;
			return 0;
		}
		return -1;
	}

	void LibraryLogger::ChangeBehaviorLevel( char* name, int level )
	{
		for ( int index = 0; index < MAX_BEHAVIOR; index++ )	
		{
			if ( !strcmp( levels[index].behaviorName, name ) )
			{
				levels[index].levelStatus = level;
			}
		}
	}

	void LibraryLogger::SetFullLevel( int level )
	{
		for ( int index = 0; index < MAX_BEHAVIOR; index++ )	
		{			
			levels[index].levelStatus = level;
		}
	}

	int LibraryLogger::GetBahaviorLevel( char* name )
	{
		for ( int index = 0; index < MAX_BEHAVIOR; index++ )
		{
			if ( !strcmp( levels[index].behaviorName, name ) )
			{
				return levels[index].levelStatus;
			}
		}

		return 0;
	}

	void LibraryLogger::PrintLevels()
	{
		for( int index = 0; index < MAX_BEHAVIOR && strlen(levels[index].behaviorName); index++ )
		{
			printf("COMPORTAMENTO - [%s], LEVEL - [%s]\n", 
					levels[index].behaviorName, 
					levels[index].levelStatus ? "DEBUG" : "OPER" );
		}
	}
	
	int LibraryLogger::GetSharedMemoryIdentification()
	{
		return sharedIdentification;
	}

	void LibraryLogger::SetSharedMemoryIdentification( int parameterShared )
	{
		sharedIdentification = parameterShared;
	}

	int LibraryLogger::GetSemaphoreIdentification()
	{
		return semaphoreIdentification;
	}

	void LibraryLogger::SetSemaphoreIdentification( int parameterSemaphore )
	{
		semaphoreIdentification = parameterSemaphore;
	}
}
