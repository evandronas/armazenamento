/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "Trace.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	Trace::Trace(const char *parameterName, int parameterType, long parameterCode,
				const char* parameterSequence, const char* parameterTerminal, long parameterStan,
				const char* parameterCard, const char* parameterReason ) 
				: messageType(parameterType), processCode(parameterCode), sequenceNumber(parameterSequence), 
				terminalCode(parameterTerminal), terminalSequence(parameterStan), cardNumber(parameterCard), 
				reasonCode(parameterReason)
	{
		// Atribui nome do modulo
		SetModuleName( parameterName );
		
		// Mascara numero do cartao
		memset( maskCardNumber, 0, sizeof(maskCardNumber) );
		strcpy( maskCardNumber, cardNumber );
		MaskCard( maskCardNumber );
	}
	
	Trace::~Trace()
	{ 
	}
	
	void Trace::MaskCard( char* parameterCard )
	{
		char *positionDigit = NULL;

		// Procura por numeros no cartao
		positionDigit = strpbrk(parameterCard, "123456789");
		if ( (positionDigit == NULL) || (strlen(parameterCard) < 10) )
		{
			// Pan invalido
			return;
		}

		// Procura por numero diferente de '0' (ou diferente de espaco)
		positionDigit = parameterCard;
		while ( *positionDigit == ' ' || *positionDigit == '0' )
		{
			++positionDigit;
		}

		// Mantem somente os 6 primeiros numeros (bin)
		positionDigit += 6;
		*positionDigit = '*';	// Inclui uma mascara inicial

		// Procura do final para o inicio
		positionDigit = &parameterCard[19];
		while ( *positionDigit == ' ' || *positionDigit == '\0' )
		{
			--positionDigit;
		}

		/* mantem os 4 utltimos digitos */
		positionDigit -= 4;
		*positionDigit = '*';
		--positionDigit;

		while ( *positionDigit != '*' )
		{
			*positionDigit = '*';
			--positionDigit;
		}
	}
	
	const char* Trace::GetName()
	{
		return (const char*)"TRACE";
	}	

    inline void Trace::WriteLog()
    {	
		syslg("SWL-%s-[m%04d/p%06ld/nsu%9s/term%s/t%06ld/pan%19s/sw%03s]\n", GetModuleName(), 
														messageType, processCode, sequenceNumber, 
														terminalCode, terminalSequence, 
														maskCardNumber, reasonCode );
	}
}
