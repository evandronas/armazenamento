/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LogDeveloper.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LogDeveloper::LogDeveloper( const char *parameterName, const char* parameterMessage ) 
				: message( parameterMessage )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	LogDeveloper::~LogDeveloper()
	{ 
	}

	const char* LogDeveloper::GetName()
	{
		return (const char*)"LOGDEVELOPER";
	}	

	inline void LogDeveloper::WriteLog()
	{		
		syslg( message );
	}
}
