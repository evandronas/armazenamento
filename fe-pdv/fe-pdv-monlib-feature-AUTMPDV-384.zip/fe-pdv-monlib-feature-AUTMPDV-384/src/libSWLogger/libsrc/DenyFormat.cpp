/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyFormat.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenyFormat::DenyFormat( const char *parameterName, const char* parameterCurrent, const char* parameterFormat ) 
				: currentFormat( parameterCurrent ), rightFormat( parameterFormat )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyFormat::~DenyFormat()
	{ 
	}

	const char* DenyFormat::GetName()
	{
		return (const char*)"DENYFORMAT";
	}	

	inline void DenyFormat::WriteLog()
	{		
		syslg("SWL-%s-Current format [%s] but expected format is [%s]\n", 
				GetModuleName(), currentFormat, rightFormat );
	}
}
