/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LogProcessing.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LogProcessing::LogProcessing( const char *parameterName, const char *parameterMessage ) 
				: message( parameterMessage )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	LogProcessing::~LogProcessing()
	{ 
	}

	const char* LogProcessing::GetName()
	{
		return (const char*)"LOGPROCESSING";
	}	

	inline void LogProcessing::WriteLog()
	{		
		syslg("SWL-%s-[%s]\n", GetModuleName(), message );
	}
}
