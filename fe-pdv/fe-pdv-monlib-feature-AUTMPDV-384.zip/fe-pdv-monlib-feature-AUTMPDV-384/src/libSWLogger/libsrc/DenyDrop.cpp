/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyDrop.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenyDrop::DenyDrop( const char *parameterName, const char *parameterReason ) 
				: reason( parameterReason )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyDrop::~DenyDrop()
	{ 
	}

	const char* DenyDrop::GetName()
	{
		return (const char*)"DENYDROP";
	}	

	inline void DenyDrop::WriteLog()
	{		
		syslg("SWL-%s-This message is been dropped because [%s]\n", GetModuleName(), reason );
	}
}
