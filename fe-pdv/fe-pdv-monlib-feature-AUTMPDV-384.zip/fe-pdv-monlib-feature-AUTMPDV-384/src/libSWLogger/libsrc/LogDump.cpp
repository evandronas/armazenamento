/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LogDump.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LogDump::LogDump( const char *parameterName, const char *parameterMessage ) 
				: dumpMessage( parameterMessage )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	LogDump::~LogDump()
	{ 
	}

	const char* LogDump::GetName()
	{
		return (const char*)"LOGTXNDUMP";
	}	

	inline void LogDump::WriteLog()
	{		
		syslg("SWL-%s-DUMP MESSAGE [%s]\n", GetModuleName(), dumpMessage );
	}
}
