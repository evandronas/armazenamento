/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "GenericFunction.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	GenericFunction::GenericFunction( const char *parameterName, const char *parameterFunction, const char *parameterPoint )
									: functionName(parameterFunction), functionPoint(parameterPoint)
	{
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}

	GenericFunction::~GenericFunction()
	{ 
	}

	const char* GenericFunction::GetName()
	{
		return (const char*)"GENERICFUNCTION";
	}				

	inline void GenericFunction::WriteLog()
    {	
		syslg("SWL-%s-[%s-%s]\n", GetModuleName(), functionPoint, functionName );
	}
}
