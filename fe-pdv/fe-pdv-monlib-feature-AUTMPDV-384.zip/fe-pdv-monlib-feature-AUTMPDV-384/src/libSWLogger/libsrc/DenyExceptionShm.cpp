/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyExceptionShm.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenyExceptionShm::DenyExceptionShm( const char *parameterName, const char *parameterFile, 
						const int parameterShared, const int parameterLine, 
						const char *parameterCondition ) 
						: fileName( parameterFile ), sharedIdentification( parameterShared ), 
						lineCode( parameterLine ), condition( parameterCondition )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyExceptionShm::~DenyExceptionShm()
	{ 
	}

	const char* DenyExceptionShm::GetName()
	{
		return (const char*)"DENYEXCEPTIONSHM";
	}	

	inline void DenyExceptionShm::WriteLog()
	{		
		syslg("SWL-%s-EXCECAO [%s] para a SHM ID [%d], ARQUIVO[%s] LINHA[%d]\n", 
				GetModuleName(), condition, sharedIdentification, fileName, lineCode );
	}
}
