/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LogInitialization.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LogInitialization::LogInitialization( const char *parameterName, const char *parameterMessage ) 
				: message( parameterMessage )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	LogInitialization::~LogInitialization()
	{ 
	}

	const char* LogInitialization::GetName()
	{
		return (const char*)"LOGINITIALIZATION";
	}	

	inline void LogInitialization::WriteLog()
	{		
		syslg("SWL-%s-[%s]\n", GetModuleName(), message );
	}
}
