/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyCheck.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenyCheck::DenyCheck( const char *parameterName, const char *parameterConditional ) 
				: conditional( parameterConditional )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyCheck::~DenyCheck()
	{ 
	}

	const char* DenyCheck::GetName()
	{
		return (const char*)"DENYCHECK";
	}	

	inline void DenyCheck::WriteLog()
	{		
		syslg("SWL-%s-This message is been denied because of rule [%s]\n", GetModuleName(), conditional );
	}
}
