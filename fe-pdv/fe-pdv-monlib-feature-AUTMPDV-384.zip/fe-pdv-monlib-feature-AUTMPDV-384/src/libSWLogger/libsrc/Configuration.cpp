/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "Configuration.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	Configuration::Configuration( const char *parameterName, const char* parameterFile, const char* parameterAttribute ) 
		: fileName( parameterFile ), attributeConfiguration( parameterAttribute )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}

	Configuration::~Configuration()
	{ 
	}

	const char* Configuration::GetName()
	{
		return (const char*)"CFG";
	}	

	inline void Configuration::WriteLog()
	{		
		syslg("SWL-%s-FILE[%s] ATTRIBUTE[%s]\n", GetModuleName(), fileName, attributeConfiguration );
	}
}
