/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyMailBox.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{

	DenyMailBox::DenyMailBox( const char *parameterName, const int parameterMailBox, 
			const long parameterSize ) 
			: mailboxIdentification( parameterMailBox ), bufferSize( parameterSize )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyMailBox::~DenyMailBox()
	{ 
	}

	const char* DenyMailBox::GetName()
	{
		return (const char*)"DENYMB";
	}	

	inline void DenyMailBox::WriteLog()
	{		
		syslg("SWL-%s-MAILBOXID[%d] TAM_BUFFER[%ld]\n", GetModuleName(), mailboxIdentification, bufferSize );
	}
}
