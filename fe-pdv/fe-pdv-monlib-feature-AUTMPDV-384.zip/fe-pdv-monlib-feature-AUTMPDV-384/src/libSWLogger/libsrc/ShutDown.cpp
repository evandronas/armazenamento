/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "ShutDown.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	ShutDown::ShutDown( const char *parameterName, const int parameterSignal ) 
				: signalNumber( parameterSignal )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	ShutDown::~ShutDown()
	{ 
	}

	const char* ShutDown::GetName()
	{
		return (const char*)"SHUTDOWN";
	}	

	inline void ShutDown::WriteLog()
	{		
		syslg("SWL-%s-SIGNAL EXIT[%d]\n", GetModuleName(), signalNumber );
	}
}
