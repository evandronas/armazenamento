/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include <LibSWLogger.hpp>

using namespace SWLOGGER;
using namespace std;

static LibraryLogger *globalLibraryLogger = NULL;

int initialiseLogger()
{
	try
	{
		globalLibraryLogger = LibraryLogger::GetInstance();
		globalLibraryLogger->LoadBehaviors();
	}
	catch( ... )
	{
		printf("ERRO AO INICIALIZAR A SHM DO SWLOGGER\n");
		return -1;
	}
	return 1;
}

int connectToLogger()
{
	try
	{
		globalLibraryLogger = LibraryLogger::GetInstance();
	}
	catch( ... )
	{
		printf("ERRO AO CONECTAR NA SHM DO SWLOGGER\n");
		return -1;
	}
	return 1;
}

int removeLogger()
{
    try
    {
		delete globalLibraryLogger;
		globalLibraryLogger = NULL;
    }
	catch( ... )
	{
		printf("ERRO AO REMOVER O OBJETO DO SWLOGGER\n");
		return -1;
	}
	return 1;
}

int changeLoggerLevel( const char* nomeComportamento, int novoNivel ) 
{
	if ( globalLibraryLogger != NULL )
	{
		globalLibraryLogger->ChangeBehaviorLevel( (char*)nomeComportamento, novoNivel );  
	}
	return 1;
}

int changeAllLoggerLevels( int novoNivel ) 
{
	if ( globalLibraryLogger != NULL )
	{
		globalLibraryLogger->SetFullLevel( novoNivel );  
	}
	return 1;
}

void showAllLevels()
{
	if ( globalLibraryLogger != NULL )
	{
		globalLibraryLogger->PrintLevels();
	}
}

void executeLogger( IBehavior* behavior )
{
	try
	{
		// Valida allocacao da classe
		if ( behavior == NULL )
		{
			syslg("SWL-Out of memory!!!\n");
			throw bad_alloc();
		}
		else
		{
			connectToLogger();
			if ( globalLibraryLogger != NULL )
			{
				globalLibraryLogger->ExecuteLibraryLogger( behavior );
			}
		}
	}
	catch ( bad_alloc &receivedExcecption )
	{
		syslg("SWL-BAD_ALLOC-%s\n", receivedExcecption.what());
	}
	catch ( exception &receivedExcecption )
	{
		syslg("SWL-EXC-%s\n", receivedExcecption.what());
	}
	catch ( ... )
	{
		syslg("SWL-GENERAL EXCEPTION\n");
	}
}
