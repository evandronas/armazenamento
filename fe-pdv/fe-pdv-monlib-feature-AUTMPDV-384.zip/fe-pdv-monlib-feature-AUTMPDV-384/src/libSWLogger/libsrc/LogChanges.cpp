/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LogChanges.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LogChanges::LogChanges( const char *parameterName, const char *parameterField, 
					const char *parameterOldValue, const char *parameterNewValue ) 
					: fieldName( parameterField ), oldValue( parameterOldValue ), 
					  newValue( parameterNewValue )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	LogChanges::~LogChanges()
	{ 
	}

	const char* LogChanges::GetName()
	{
		return (const char*)"LOGTXNCHANGES";
	}	

	inline void LogChanges::WriteLog()
	{		
		syslg("SWL-%s-Campo [%s] - Antes[%s], Depois[%s]\n", GetModuleName(), fieldName, oldValue, newValue );
	}
}
