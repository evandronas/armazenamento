/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "IBehavior.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	const char* IBehavior::GetModuleName()
	{
		return (const char*)moduleName;
	}

	void IBehavior::SetModuleName( const char* parameterName )
	{
		// Limpa atributo da classe e preenche com valor informado
		memset( moduleName, 0, sizeof( moduleName ) );
		strncpy( moduleName, parameterName, MAX_MODULE_NAME - 1 );
	}	
}
