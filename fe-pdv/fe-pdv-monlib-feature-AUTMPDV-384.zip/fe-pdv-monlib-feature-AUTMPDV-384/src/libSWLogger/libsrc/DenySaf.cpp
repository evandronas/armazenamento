/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenySaf.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenySaf::DenySaf( const char *parameterName, const char *parameterNetwork, 
				const char *parameterConditional ) 
				: networkCode( parameterNetwork ), conditional( parameterConditional )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenySaf::~DenySaf()
	{ 
	}

	const char* DenySaf::GetName()
	{
		return (const char*)"DENYSAF";
	}	

	inline void DenySaf::WriteLog()
	{		
		syslg("SWL-%s-This network id [%s] is goint to SAF because [%s]\n", GetModuleName(), networkCode, conditional );
	}
}
