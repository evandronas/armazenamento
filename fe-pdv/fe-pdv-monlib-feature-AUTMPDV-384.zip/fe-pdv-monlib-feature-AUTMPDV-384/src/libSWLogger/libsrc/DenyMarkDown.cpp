/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyMarkDown.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenyMarkDown::DenyMarkDown( const char *parameterName, const char* parameterNetwork, 
				const char* parameterReason ) 
				: networkCode( parameterNetwork ), reason( parameterReason )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyMarkDown::~DenyMarkDown()
	{ 
	}

	const char* DenyMarkDown::GetName()
	{
		return (const char*)"DENYMARKDOWN";
	}	

	inline void DenyMarkDown::WriteLog()
	{		
		syslg("SWL-%s-The networkid id [%s] was marked down because [%s]\n", GetModuleName(), networkCode, reason );
	}
}
