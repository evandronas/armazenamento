/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LogCallBack.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LogCallBack::LogCallBack( const char *parameterName, const char *parameterCallback ) 
				: callbackName( parameterCallback )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	LogCallBack::~LogCallBack()
	{ 
	}

	const char* LogCallBack::GetName()
	{
		return (const char*)"LOGCALLBACK";
	}	

	inline void LogCallBack::WriteLog()
	{		
		syslg("SWL-%s-Registrando callback [%s]\n", GetModuleName(), callbackName );
	}
}
