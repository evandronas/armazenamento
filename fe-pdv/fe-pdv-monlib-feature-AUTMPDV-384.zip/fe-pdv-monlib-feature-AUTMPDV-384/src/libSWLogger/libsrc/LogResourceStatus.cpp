/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LogResourceStatus.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LogResourceStatus::LogResourceStatus( const char *parameterName, const char *parameterResource, 
				const char *parameterStatus ) 
				: resourceName( parameterResource ), resourceStatus( parameterStatus )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	LogResourceStatus::~LogResourceStatus()
	{ 
	}

	const char* LogResourceStatus::GetName()
	{
		return (const char*)"LOGRESOURCESTATUS";
	}	

	inline void LogResourceStatus::WriteLog()
	{		
		syslg("SWL-%s-[%s] - %s\n", GetModuleName(), resourceName, resourceStatus );
	}
}
