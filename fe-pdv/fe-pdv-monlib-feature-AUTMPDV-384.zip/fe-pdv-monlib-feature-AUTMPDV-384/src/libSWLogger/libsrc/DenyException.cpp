/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyException.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenyException::DenyException( const char *parameterName, const char *parameterFile, 
					const int parameterLine, const char *parameterConditional ) 
				: fileName( parameterFile ), lineCode( parameterLine ), errorConditional( parameterConditional )

	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyException::~DenyException()
	{ 
	}

	const char* DenyException::GetName()
	{
		return (const char*)"DENYEXCEPTION";
	}	

	inline void DenyException::WriteLog()
	{		
		syslg("SWL-%s-EXCECAO [%s], ARQUIVO[%s] LINHA[%d]\n", GetModuleName(), errorConditional, fileName, lineCode );
	}
}
