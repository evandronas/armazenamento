/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "LogCommand.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	LogCommand::LogCommand( const char *parameterName, const char *parameterCommand ) 
				: command( parameterCommand )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	LogCommand::~LogCommand()
	{ 
	}

	const char* LogCommand::GetName()
	{
		return (const char*)"LOGCOMMAND";
	}	

	inline void LogCommand::WriteLog()
	{		
		syslg("SWL-%s-Comando [%s]\n", GetModuleName(), command );
	}
}
