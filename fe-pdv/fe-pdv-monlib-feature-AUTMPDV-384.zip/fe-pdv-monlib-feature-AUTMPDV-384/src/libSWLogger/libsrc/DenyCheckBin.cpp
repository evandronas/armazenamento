/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyCheckBin.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenyCheckBin::DenyCheckBin( const char *parameterName, const char *parameterBin, 
				const char *parameterValidation ) 
				: binNumber( parameterBin ), validation( parameterValidation )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyCheckBin::~DenyCheckBin()
	{ 
	}

	const char* DenyCheckBin::GetName()
	{
		return (const char*)"DENYCHECKBIN";
	}	

	inline void DenyCheckBin::WriteLog()
	{		
		syslg("SWL-%s-This message is been denied because the bin [%s] [%s]\n", GetModuleName(), binNumber, validation );
	}
}
