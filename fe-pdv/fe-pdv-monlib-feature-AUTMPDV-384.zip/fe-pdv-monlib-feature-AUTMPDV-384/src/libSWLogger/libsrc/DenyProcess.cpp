/* Copyright 2013 REDE
Autor : Igor
Empresa : Resource
*/

#include "DenyProcess.hpp"

/*
 * Namespace SWLOGGER
 */
namespace SWLOGGER
{
	DenyProcess::DenyProcess( const char *parameterName, const char* parameterConditional ) 
				: errorCondition( parameterConditional )
	{ 
		// Atribui nome do modulo
		SetModuleName( parameterName );
	}
			
	DenyProcess::~DenyProcess()
	{ 
	}

	const char* DenyProcess::GetName()
	{
		return (const char*)"DENYPROCESS";
	}	

	inline void DenyProcess::WriteLog()
	{		
		syslg("SWL-%s-This message is been denied because [%s]\n", GetModuleName(), errorCondition );
	}
}
