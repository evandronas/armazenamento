#!/usr/bin/bash

set -x

{
# AWS Variables
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep region| awk '{print $3}'|sed  's/"//g'|sed 's/,//g')
AMBIENTE=$(/usr/local/bin/aws ssm get-parameter --name "ambiente" --region $REGION --output text | awk '{ print $7 }')

# RPM Variables
RPM_PREFIX_DIR="/opt/rpm/SW7/autorizador/aplicacao/online/libs/fe-pdv-monlib"

# Install directories
TARGET_DIR="/home/SW/PDV"
RPM_DIR="$RPM_PREFIX_DIR/dist/*"

# Permissions
SW_GROUP="Sistemas"

# Log
LOGFILE="/tmp/online_libs_fepdv-monlib-after-install.log"

echo "[rpm] [$AMBIENTE] - Installing fe-pdv-monlib"

mkdir -p $TARGET_DIR;
cp -Rvf $RPM_DIR $TARGET_DIR

chown -R swoper_appl_${AMBIENTE}:${SW_GROUP} $TARGET_DIR/*
chmod 775 $TARGET_DIR/*

echo "[rpm] The package has been installed"

set +x
} > /tmp/online_libs_fepdv-monlib-after-install.log 2>&1

echo "[rpm] A log has been created: ${LOGFILE}"

exit 0;
