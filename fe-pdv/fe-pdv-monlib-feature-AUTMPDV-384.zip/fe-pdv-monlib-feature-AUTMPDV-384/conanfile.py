from conans import ConanFile, tools
import os

class ResolveDependency(ConanFile):
    settings = "os", "compiler", "build_type", "arch"
    description = "Monitor library for usage in online repos"
    url = "http://gitlab.prd.useredecloud/SW7/autorizador/aplicacao/online/libs/fe-pdv-monlib"
    license = "None"
    author = "RT Autorizador"
    topics = ("sw7", "online", "lib")

    REQ_FEPDVLIB = "sw7-autorizador-aplicacao-online-libs-fe-pdv-lib/" + os.getenv("req_fepdvlib") + "@SW7/rede"
    requires = REQ_FEPDVLIB

    def imports(self):
        self.copy("*", dst="include", src="include")
        self.copy("*", dst="lib", src="lib")

    def package(self):
        self.copy("*", src="./dist/lib", dst="lib")
        self.copy("*", src="./dist/include", dst="include")

    def package_info(self):
        self.cpp_info.libs = tools.collect_libs(self)
