#!/usr/bin/bash

set -x
{
# RPM Variables
RPM_PREFIX_DIR="/opt/rpm/SW7/autorizador/aplicacao/online/fe-pdv"

# Install directories
TARGET_DIR="/home/SW/PDV"
RPM_DIR="$RPM_PREFIX_DIR/dist"

# Log
LOGFILE="/tmp/online_fepdv-before-remove.log"

cd $RPM_DIR
for file in $(find . -type f -print); do
    rm -vf $TARGET_DIR/${file:2}
done;
cd -

echo "[rpm] The package has been uninstalled"

} > /tmp/online_fepdv-before-remove.log 2>&1
set +x

echo "[rpm] A log has been created: ${LOGFILE}"

exit 0;
