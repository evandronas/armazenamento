/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Teller
/ Data de Cria��o: 2012, 10 de setembro
/ Hist�rico Mudan�as: 2012, 10 de setembro, t689064, Raphael Teller, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

#pragma once

#include <ctime>
#include <string>

struct TpsData
{
	unsigned long frontEndCounter;
	unsigned long blockIncrement;
	unsigned long timeInterval;
	unsigned long currentTps;
};

class DaemonTPS
{
public:

	DaemonTPS();
	virtual ~DaemonTPS();

	bool init();
	void finish();
	void execute();
	
	unsigned long getCurrentTps();
	void dumpShmValues();
	
private:

	int m_semid;
	int m_shmid;
	
	unsigned long m_tpsCounter;
	unsigned long m_timeInterval;

	time_t m_lastTime;
	time_t m_currentTime;

	TpsData* m_tpsData;

	std::string m_semaphore;
};

