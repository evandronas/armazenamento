#include "DaemonTPS.hpp"
#include <ist_argv0.h>

int main(int argc, char *argv[])
{
	argv0 = argv[0];
	
	DaemonTPS l_daemonTPS;
	
	bool ret = l_daemonTPS.init();
	if ( !ret )
		return -1;

	l_daemonTPS.execute(); // for(;;)

	return -1;
}
