#include "DaemonTPS.hpp"
#include <ist_argv0.h>
#include <iostream>
#include <cstring>

int main(int argc, char *argv[])
{
	argv0 = argv[0];

	DaemonTPS l_daemonTPS;
	
	l_daemonTPS.init();
	
	std::cout << "CurrentTPS: " << l_daemonTPS.getCurrentTps() << std::endl;
	
	if ( argc > 1 && !strcmp( "dump", argv[1] ) )
		l_daemonTPS.dumpShmValues();
	
	return 0;
}
