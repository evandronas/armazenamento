/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Teller
/ Data de Cria��o: 2012, 10 de setembro
/ Hist�rico Mudan�as: 2012, 10 de setembro, t689064, Raphael Teller, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/

#pragma once
#include <cstring>
#include <ist_ipc.h>
#include <ctime>
#include <unistd.h>
#include "base/GenException.hpp"
#include "DaemonTPS.hpp"
#include "configBase/ConfigBase.hpp"
#include "logger/Level.hpp"
#include "logger/DebugWriter.hpp"
#include <iostream>
#include <sstream>

DaemonTPS::DaemonTPS()
{
	m_semid = -1;
	m_shmid = -1;
	m_lastTime = 0;
	m_currentTime = 0;
	m_tpsCounter = 0;
	m_timeInterval = 0;
	m_tpsData = 0;
	m_semaphore = "";
}

DaemonTPS::~DaemonTPS()
{
	if( m_tpsData )
	{
		sh_detach( reinterpret_cast<char *>(m_tpsData) );
		m_tpsData = 0;
	}
}

bool DaemonTPS::init()
{
	logger::DebugWriter::getInstance()->open();

	if ( configBase::ConfigBase::getInstance()->findFirst( "blindagem.semaphore_name", m_semaphore ) )
	{
		if ( (m_semid = sem_create(m_semaphore.c_str(), 1)) == -1 )
		{
			if ( (m_semid = sem_connect(m_semaphore.c_str(), 1)) == -1 )
			{
				std::string l_errorMsg( "DaemonTPS::init(): Erro ao criar/conectar semaforo do TPS" );
				logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, l_errorMsg.c_str() );
				return false;
			}
		}
	}
	else
	{
		std::string l_errorMsg( "DaemonTPS::init(): Parametro: 'blindagem.semaphore_name' nao configurado." );
		logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, l_errorMsg.c_str() );
		return false;
	}
	
	sem_acquire(m_semid);

	if ( (m_shmid = sh_getmem(m_semaphore.c_str(), 0, 0)) == -1 )
	{
		if ( (m_shmid = sh_getmem(m_semaphore.c_str(), sizeof(TpsData), 1)) == -1 )
		{
			if ( (m_shmid = sh_getmem(m_semaphore.c_str(), 0, 0)) == -1 )
			{
				sem_release(m_semid);
				std::string l_errorMsg( "DaemonTPS::init(): Erro ao criar shared memory" );
				logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, l_errorMsg.c_str() );
				return false;
			}
		}

		if ( (m_tpsData = (TpsData*) sh_attach(m_shmid)) == 0 )
		{
			sem_release(m_semid);
			std::string l_errorMsg( "DaemonTPS::init(): Erro no attach da shared memory criada" );
			logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, l_errorMsg.c_str() );
			return false;
		}
		
		memset((char*)m_tpsData, 0, sizeof(TpsData));
		m_tpsData->frontEndCounter = 0;
		m_tpsData->blockIncrement = 1;
		m_tpsData->timeInterval = 1;
		m_tpsData->currentTps = 0;
	}
	else
	{
		if ( (m_tpsData = (TpsData*) sh_attach(m_shmid)) == 0 )
		{
			sem_release(m_semid);
			std::string l_errorMsg( "DaemonTPS::init(): Erro no attach da shared memory existente" );
			logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, l_errorMsg.c_str() );
			return false;
		}
		
		m_tpsCounter = m_tpsData->frontEndCounter;
		m_timeInterval = m_tpsData->timeInterval;		
	}
	
	sem_release(m_semid);
	
	return true;
}

void DaemonTPS::finish()
{
	if( m_tpsData )
	{
		sh_detach( reinterpret_cast<char *>(m_tpsData) );
		m_tpsData = 0;
	}
}

void DaemonTPS::dumpShmValues()
{
	unsigned long l_frontEndCounter, l_blockIncrement, l_timeInterval, l_currentTps;
	
	sem_acquire(m_semid);
	l_frontEndCounter = m_tpsData->frontEndCounter;
	l_blockIncrement = m_tpsData->blockIncrement;
	l_timeInterval = m_tpsData->timeInterval;
	l_currentTps = m_tpsData->currentTps;	
	sem_release(m_semid);
	
	std::ostringstream s;
	s << std::endl;
	s << "Shared Memory TPS - Current Values" << std::endl;
	s << "frontEndCounter: " << l_frontEndCounter << std::endl;
	s << "blockIncrement: " << l_blockIncrement << std::endl;
	s << "timeInterval: " << l_timeInterval << std::endl;
	s << "currentTps: " << l_currentTps << std::endl;
	logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, s.str().c_str() );
}

unsigned long DaemonTPS::getCurrentTps()
{
	if( m_tpsData )
		return m_tpsData->currentTps;

	return 0;
}

void DaemonTPS::execute()
{
	m_lastTime = time( NULL );	
	
	while( true )
	{
		m_currentTime = time( NULL );
		if ( m_currentTime >= m_lastTime + m_timeInterval )
		{
			sem_acquire(m_semid);
			m_tpsData->currentTps = ( m_tpsData->frontEndCounter - m_tpsCounter ) / m_tpsData->timeInterval; // update currTps;
			m_tpsCounter = m_tpsData->frontEndCounter; // update last counter with current one.
			m_timeInterval = m_tpsData->timeInterval; // update last time interval with current one.
			sem_release(m_semid);

			m_lastTime = m_currentTime; // update last timer with current one.
		}
		
		sleep( 1 );
	}
}
