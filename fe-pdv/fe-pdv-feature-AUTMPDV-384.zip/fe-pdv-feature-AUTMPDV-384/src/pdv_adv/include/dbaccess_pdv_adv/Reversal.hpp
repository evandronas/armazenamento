#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_pdv_adv
{
	class Reversal : public dbaccess::table
	{
	public:
		Reversal();
		~Reversal();
        void setWhereClause( const std::string& a_whereClause );
        void setTableName( const std::string& a_tableName );
		void bind_columns();	
		void clear_fields();	        
        unsigned long get_COD_PCM_ISO() const;
        const std::string& get_COD_POS_ENTR_MODO() const;
        oasis_dec_t get_VAL_TRAN_DLR() const;
        oasis_dec_t get_VAL_TRAN() const;
        const std::string& get_TRANDATE() const;
        const std::string& get_TRANTIME() const;
        oasis_dec_t get_NUM_STAN() const;
        const std::string& get_LOCALDATE() const;
        const std::string& get_LOCALTIME() const;
        unsigned long get_NUM_SEQ_UNC() const;
        unsigned long get_NUM_ESTB() const;
        unsigned long get_COD_MSG_ISO() const;
        const std::string& get_ORIGDATE() const;
        const std::string& get_ORIGTIME() const;
        const std::string& get_NUM_CAR() const;
		unsigned long get_TIP_TRAN() const;
		const std::string& get_COD_MOED() const;
        unsigned long get_COD_EMSR() const;
        unsigned long get_COD_CMPM_TRAN() const;
        const std::string& get_COD_TERM() const;
        const std::string& GetNetworkId() const;
        const std::string& GetStatusTransacao() const;
        const std::string& GetVersaoAplicativo() const;
        unsigned long GetDataMovimento() const;
        
	private:
        unsigned long m_COD_PCM_ISO;
        std::string	m_COD_POS_ENTR_MODO;
        oasis_dec_t	m_VAL_TRAN_DLR;
        oasis_dec_t	m_VAL_TRAN;
        std::string	m_TRANDATE;
        std::string	m_TRANTIME;
        oasis_dec_t	m_NUM_STAN;
        std::string	m_LOCALDATE;
        std::string	m_LOCALTIME;
        unsigned long m_NUM_SEQ_UNC;
        unsigned long m_NUM_ESTB;
        unsigned long m_COD_MSG_ISO;
        std::string m_ORIGDATE;
        std::string	m_ORIGTIME;
        std::string	m_NUM_CAR;
		unsigned long m_TIP_TRAN;
		std::string	m_COD_MOED;
        unsigned long m_COD_EMSR;
        unsigned long m_COD_CMPM_TRAN;
        std::string	m_COD_TERM;
        std::string networkId;
        std::string statusTransacao;
        std::string versaoAplicativo;
        unsigned long dataMovimento;
				
		int m_COD_PCM_ISO_pos;
		int m_COD_POS_ENTR_MODO_pos;
		int m_VAL_TRAN_DLR_pos;
		int m_VAL_TRAN_pos;
		int m_TRANDATE_pos;
		int m_TRANTIME_pos;
		int m_NUM_STAN_pos;
		int m_LOCALDATE_pos;
		int m_LOCALTIME_pos;
		int m_NUM_SEQ_UNC_pos;
		int m_NUM_ESTB_pos;
		int m_COD_MSG_ISO_pos;
		int m_ORIGDATE_pos;
		int m_ORIGTIME_pos;        		
        int m_NUM_CAR_pos;  
		int m_TIP_TRAN_pos;
		int m_COD_MOED_pos;  
        int m_COD_EMSR_pos;
        int m_COD_CMPM_TRAN_pos;  
    int m_COD_TERM_pos;
        int networkIdPos;
        int statusTransacaoPos;
        int versaoAplicativoPos;
        int dataMovimentoPos;
	};
} //namespace dbaccess_pdv_adv

