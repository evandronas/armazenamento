#include "dbaccess_pdv_adv/Reversal.hpp"

namespace dbaccess_pdv_adv
{
	Reversal::Reversal()
	{
		query_fields = "TB30.COD_PCM_ISO,"                                  \
                       "TB30.COD_POS_ENTR_MODO,"                            \
                       "TB30.VAL_TRAN_DLR,"                                 \ 
                       "TB30.VAL_TRAN,"                                     \   
                       "to_char(TB30.DTH_GMT,'YYYYMMDD') as TRANDATE,"      \
                       "to_char(TB30.DTH_GMT,'HH24MISS') as TRANTIME,"      \
                       "TB30.NUM_STAN,"                                     \
                       "to_char(sysdate,'YYYYMMDD') as LOCALDATE,"          \
                       "to_char(sysdate,'HH24MISS') as LOCALTIME,"          \
                       "TB30.NUM_SEQ_UNC,"                                  \
                       "TB30.NUM_ESTB,"                                     \
                       "TB30.COD_MSG_ISO,"                                  \
                       "to_char(TB30.DTH_INI_TRAN,'YYYYMMDD') as ORIGDATE," \
                       "to_char(TB30.DTH_INI_TRAN,'HH24MISS') as ORIGTIME," \
                       "TB30.NUM_CAR, TB30.TIP_TRAN,"                       \
                       "TB30.COD_MOED, TB30.COD_EMSR,"                      \
                       "TB30.COD_CMPM_TRAN,"                                \
                       "TB30.COD_TERM, TB30.IND_STTU_TRAN,"                 \
                       "TB30.COD_NTWK_ID_ACQR_ORGL,"	                    \
                       "TB121.COD_VERS_SFTW,"                               \
                       "TB30.DAT_MOV_TRAN";
					   
		m_COD_PCM_ISO_pos = 1;
		m_COD_POS_ENTR_MODO_pos = 2;
		m_VAL_TRAN_DLR_pos = 3;
		m_VAL_TRAN_pos = 4;
		m_TRANDATE_pos = 5;
		m_TRANTIME_pos = 6;
		m_NUM_STAN_pos = 7;
		m_LOCALDATE_pos = 8;
		m_LOCALTIME_pos = 9;
		m_NUM_SEQ_UNC_pos = 10;
		m_NUM_ESTB_pos = 11;
		m_COD_MSG_ISO_pos = 12;
		m_ORIGDATE_pos = 13;
		m_ORIGTIME_pos = 14;        
        m_NUM_CAR_pos = 15;       
		m_TIP_TRAN_pos = 16;
		m_COD_MOED_pos = 17;     
        m_COD_EMSR_pos = 18;
        m_COD_CMPM_TRAN_pos = 19;
        m_COD_TERM_pos = 20;
        statusTransacaoPos = 21;
        networkIdPos = 22;
        versaoAplicativoPos = 23;
        dataMovimentoPos = 24;
		
        dbm_chartodec( &m_VAL_TRAN_DLR, "0.00", 2 );
        dbm_chartodec( &m_VAL_TRAN, "0.00", 2 );
		m_TRANDATE = " ";
		m_TRANTIME = " ";
		dbm_longtodec( &m_NUM_STAN, 0 );
		m_LOCALDATE = " ";
		m_LOCALTIME = " ";
		m_NUM_SEQ_UNC = 0;
		m_NUM_ESTB = 0;
		m_COD_MSG_ISO = 0;
		m_ORIGDATE = " ";
		m_ORIGTIME = " ";    
        m_NUM_CAR = " ";  
		m_TIP_TRAN = 0;
        m_COD_MOED = " ";  
        m_COD_EMSR = 0;
        m_COD_CMPM_TRAN = 0;
        m_COD_TERM = " ";  
        networkId = " ";
        statusTransacao = " ";
        versaoAplicativo = " ";
        dataMovimento = 0;
		
        table_name = "TBSW0030 TB30, TBSW0121 TB121";
		where_condition = "";        
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	Reversal::~Reversal()
	{
	}
    void Reversal::setTableName( const std::string& a_tableName )
    {
        table_name = a_tableName;
    }
    void Reversal::setWhereClause( const std::string& a_whereClause )
    {
        where_condition = a_whereClause;
    }
	void Reversal::bind_columns()
	{
		bind( m_COD_PCM_ISO_pos, m_COD_PCM_ISO );
		bind( m_COD_POS_ENTR_MODO_pos, m_COD_POS_ENTR_MODO );
		bind( m_VAL_TRAN_DLR_pos, m_VAL_TRAN_DLR );
		bind( m_VAL_TRAN_pos, m_VAL_TRAN);
		bind( m_TRANDATE_pos, m_TRANDATE );
		bind( m_TRANTIME_pos, m_TRANTIME );
		bind( m_NUM_STAN_pos, m_NUM_STAN );
		bind( m_LOCALDATE_pos, m_LOCALDATE );
		bind( m_LOCALTIME_pos, m_LOCALTIME );
		bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
		bind( m_NUM_ESTB_pos, m_NUM_ESTB );
		bind( m_COD_MSG_ISO_pos, m_COD_MSG_ISO );
		bind( m_ORIGDATE_pos, m_ORIGDATE );
		bind( m_ORIGTIME_pos, m_ORIGTIME );
        bind( m_NUM_CAR_pos, m_NUM_CAR );
		bind( m_TIP_TRAN_pos, m_TIP_TRAN );
        bind( m_COD_MOED_pos, m_COD_MOED );
        bind( m_COD_EMSR_pos, m_COD_EMSR );        
        bind( m_COD_CMPM_TRAN_pos, m_COD_CMPM_TRAN );
        bind( m_COD_TERM_pos, m_COD_TERM);
        bind( networkIdPos, networkId);
        bind( statusTransacaoPos, statusTransacao);
        bind( versaoAplicativoPos, versaoAplicativo);
        bind( dataMovimentoPos, dataMovimento);
	}
  	unsigned long Reversal::get_COD_PCM_ISO() const
	{
		return m_COD_PCM_ISO;
	}
	const std::string& Reversal::get_COD_POS_ENTR_MODO() const
	{
		return m_COD_POS_ENTR_MODO;
	}
	oasis_dec_t Reversal::get_VAL_TRAN_DLR() const
	{
		return m_VAL_TRAN_DLR;
	}
	oasis_dec_t Reversal::get_VAL_TRAN() const
	{
		return m_VAL_TRAN;
	}
	const std::string& Reversal::get_TRANDATE() const
	{
		return m_TRANDATE;
	}
	const std::string& Reversal::get_TRANTIME() const
	{
		return m_TRANTIME;
	}
    oasis_dec_t Reversal::get_NUM_STAN() const
	{
		return m_NUM_STAN;
	}    
    const std::string& Reversal::get_LOCALDATE() const
	{
		return m_LOCALDATE;
	}
	const std::string& Reversal::get_LOCALTIME() const
	{
		return m_LOCALTIME;
	}
    unsigned long Reversal::get_NUM_SEQ_UNC() const
    {
    return m_NUM_SEQ_UNC;
    }
	unsigned long Reversal::get_NUM_ESTB() const
	{
		return m_NUM_ESTB;
	}    
	unsigned long Reversal::get_COD_MSG_ISO() const
	{
		return m_COD_MSG_ISO;
	}    
	const std::string& Reversal::get_ORIGDATE() const
	{
		return m_ORIGDATE;
	}
	const std::string& Reversal::get_ORIGTIME() const
	{
		return m_ORIGTIME;
	}    
    const std::string& Reversal::get_NUM_CAR() const
	{
		return m_NUM_CAR;
	}    
    unsigned long Reversal::get_TIP_TRAN() const
	{
		return m_TIP_TRAN;
	}
    const std::string& Reversal::get_COD_MOED() const
	{
		return m_COD_MOED;
	}  	
    unsigned long Reversal::get_COD_EMSR() const
	{
		return m_COD_EMSR;
	}
    unsigned long Reversal::get_COD_CMPM_TRAN() const
    {
        return m_COD_CMPM_TRAN;
    }
  const std::string& Reversal::get_COD_TERM() const
	{
		return m_COD_TERM;
	}  
    const std::string& Reversal::GetNetworkId() const
    {
        return networkId;
    }
    const std::string& Reversal::GetStatusTransacao() const
    {
        return statusTransacao;
    }
    const std::string& Reversal::GetVersaoAplicativo() const
    {
        return versaoAplicativo;
    }
    unsigned long Reversal::GetDataMovimento() const
    {
        return dataMovimento;
    }
	
// inicializa campos
 void Reversal::clear_fields(  )
 {
     dbm_chartodec( &m_VAL_TRAN_DLR, "0.00", 2 );
     dbm_chartodec( &m_VAL_TRAN, "0.00", 2 );
	   m_TRANDATE = " ";
	   m_TRANTIME = " ";
	   dbm_longtodec( &m_NUM_STAN, 0 );
	   m_LOCALDATE = " ";
	   m_LOCALTIME = " ";
	   m_NUM_SEQ_UNC = 0;
	   m_NUM_ESTB = 0;
	   m_COD_MSG_ISO = 0;
	   m_ORIGDATE = " ";
	   m_ORIGTIME = " ";    
     m_NUM_CAR = " ";  
	   m_TIP_TRAN = 0;
     m_COD_MOED = " ";  
     m_COD_EMSR = 0;
     m_COD_CMPM_TRAN = 0;
     m_COD_TERM = " ";  
        networkId = " ";
        statusTransacao = " ";
        versaoAplicativo = " ";
        dataMovimento = 0;
 }	   
    
    
} //namespace dbaccess_pdv_adv


