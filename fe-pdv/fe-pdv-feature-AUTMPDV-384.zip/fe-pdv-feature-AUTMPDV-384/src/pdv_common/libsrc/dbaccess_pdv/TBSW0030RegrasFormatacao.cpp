#include<dbaccess_pdv/TBSW0030RegrasFormatacao.hpp>
#include <AcqUtils.hpp>

namespace dbaccess_pdv
{

TBSW0030RegrasFormatacao::TBSW0030RegrasFormatacao( )
{
}

TBSW0030RegrasFormatacao::~TBSW0030RegrasFormatacao( )
{
}

void TBSW0030RegrasFormatacao::insert_NUM_RD_ORG( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    int l_netcodex = 0;
    l_netcodex = (int) strtol( tbsw0030_params.netcodex.c_str( ), NULL, 16 );
    tbsw0030.set_NUM_RD_ORG( l_netcodex );
}

void TBSW0030RegrasFormatacao::insert_TIP_TRAN_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 || tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 ||
        tbsw0030_params.msg_category.compare( "CONF_PREAUT" )  == 0 || tbsw0030_params.msg_category.compare( "CONFIRMACAO" ) == 0 )
    {
        tbsw0030.set_TIP_TRAN_ORGL( tbsw0030_params.orig_transcode );
    }
}

void TBSW0030RegrasFormatacao::insert_VAL_TX( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    oasis_dec_t l_dect;
    
    if( tbsw0030_params.msg_name.compare( "VEND_IATA_AVISTA" )      == 0 || tbsw0030_params.msg_name.compare( "VEND_IATA_PARC_CJURO" ) == 0 ||
        tbsw0030_params.msg_name.compare( "VEND_IATA_PARC_SJURO" )  == 0 )
    {
        dbm_chartodec( &l_dect, tbsw0030_params.common_vl_txa.c_str( ), 0 );
        tbsw0030.set_VAL_TX( l_dect );
    }
    else if ( tbsw0030_params.ind_da_rlcd_iata.compare("S") == 0 ) 
    {
        dbm_chartodec( &l_dect, tbsw0030_params.common_vl_txa.c_str( ), 0 );
        tbsw0030.set_VAL_TX( l_dect );
    }
    else
    {
        dbm_chartodec( &l_dect, "0", 0 );
        tbsw0030.set_VAL_TX( l_dect );
    }
}

void TBSW0030RegrasFormatacao::insert_COD_SERV_CORP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
	if ( 0 < tbsw0030_params.cod_serv_corp )
	{
		tbsw0030.set_COD_SERV_CORP( tbsw0030_params.cod_serv_corp );
	}
}

void TBSW0030RegrasFormatacao::insert_COD_DSPO_NFC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( ( tbsw0030_params.is_nfc.compare ( "TRUE" ) == 0 )  &&
        ( ( tbsw0030_params.iss_name.compare ( "MASTERCARD" ) == 0 ) || 
          ( tbsw0030_params.iss_name.compare ( "MAESTRO" ) == 0 ) || 
          ( tbsw0030_params.iss_name.compare ( "VISA_CREDITO" ) == 0 ) || 
          ( tbsw0030_params.iss_name.compare ( "VISA_ELECTRON" ) == 0 ) ) &&
        ( ( tbsw0030_params.msg_name.compare( "VEND_DBT_AVISTA" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "VEND_DBT_DIST_AVISTA" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "VEND_DBT_RECARGA" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "CONF_VEND_DBT_RECARGA" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "VEND_CRT" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "VEND_CRT_RECARGA" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "CONF_VEND_CRT_RECARGA" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "VEND_CRT_PARC_CJURO" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "SIMU_CREDIARIO" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "CONTRA_CRED" ) == 0 ) || 
          ( tbsw0030_params.msg_name.compare( "CREDIARIO_SIMUL" ) == 0 ) ||
          ( tbsw0030_params.msg_name.compare( "CREDIARIO_VENDA" ) == 0 ) ) )
    {
        tbsw0030.set_COD_DSPO_NFC( tbsw0030_params.form_factor );
    }
}

void TBSW0030RegrasFormatacao::update_VAL_TX( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
}

void TBSW0030RegrasFormatacao::update_NUM_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    std::string authnum("");

    TBSW0030RegrasFormatacaoBase::update_NUM_AUT( tbsw0030, tbsw0030_params );
    if ( tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        authnum = tbsw0030_params.orig_authnum;
        authnum.erase( 0, 1 ); // Na Confirmacao de Pre-Autorizacao do PDV, vem o numero de autorizacao da original com seis posicoes,
                               // mas no banco de dados so devem ser gravadas as primeiras cinco (como na pre-autorizacao original)
        tbsw0030.set_NUM_AUT( authnum );
    }
}

void TBSW0030RegrasFormatacao::insert_IND_DA_RLCD_IATA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.msg_name.compare("VEND_IATA_AVISTA") == 0 || 
         tbsw0030_params.msg_name.compare("VEND_IATA_PARC_SJURO") == 0 ||
         tbsw0030_params.msg_name.compare("VEND_IATA_PARC_CJURO") == 0 )
    {
        tbsw0030.set_IND_DA_RLCD_IATA( std::string( "S" ) );
    }
    else if ( tbsw0030_params.ind_da_rlcd_iata.compare("S") == 0 ) 
    {
        tbsw0030.set_IND_DA_RLCD_IATA( std::string( "S" ) );
    }
    else
    {
        tbsw0030.set_IND_DA_RLCD_IATA( std::string( "N" ) );
    }
}

void TBSW0030RegrasFormatacao::update_DTH_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare( "SONDA" ) == 0 )
    {
        unsigned long date, hour;
        GetNow( &date, &hour );

        tbsw0030.set_DTH_STTU_TRAN( AcqUtils::dateTime( date, hour ) );
    }
    else
    {
        TBSW0030RegrasFormatacaoBase::update_DTH_STTU_TRAN( tbsw0030, tbsw0030_params );
    }
    
}

void TBSW0030RegrasFormatacao::GetNow( unsigned long *day, unsigned long *hour )
{
    time_t now = time( 0 );
    struct tm *agora = localtime( &now );

    *day = ( 1900 + agora->tm_year ) * 10000 + ( 1 + agora->tm_mon ) * 100 + agora->tm_mday;
    *hour = agora->tm_hour * 10000 + agora->tm_min * 100 + agora->tm_sec;
}

} //dbaccess_pdv
