#include <dbaccess_pdv/TBSW0032RegrasFormatacao.hpp>
#include <cstring>

namespace dbaccess_pdv
{
    TBSW0032RegrasFormatacao::TBSW0032RegrasFormatacao( )
    {
    }

    TBSW0032RegrasFormatacao::~TBSW0032RegrasFormatacao( )
    {
    }
    
    void TBSW0032RegrasFormatacao::insert_VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
    {
        if ( strlen( params.cash_back.c_str( ) ) )
        {
            oasis_dec_t l_dect;
            dbm_chartodec( &l_dect, params.cash_back.c_str( ) , 2 );
            tbsw0032.set_VAL_SQUE( l_dect );
        }
    }
}
