#include "dbaccess_pdv/SalesTablesJoint.hpp"

namespace dbaccess_pdv
{
    SalesTablesJoint::SalesTablesJoint()
    {
		query_fields = " TB45.NUM_RV, TB45.NUM_PDV, TB45.IND_NUM_QBRA, TB45.DAT_RV, "
					   "TB45.COD_BNDR, TB45.NOM_BNDR, TB45.COD_PROD, TB45.NOM_PROD, "
					   "TB45.QTD_CV, TB45.VAL_TOTL_LQDO, TB45.VAL_TOTL_DSCT, "
					   "TB45.VAL_TOTL_GRJT, TB45.VAL_TOTL_PAGO, TB45.DAT_CRE_RV, " 
					   "TB45.VAL_SIT_RVS, TB45.DTH_INI, TB45.DTH_FIM, TB45.QTD_PRCL, "
					   "TB45.VAL_ENTR, TB45.VAL_TX_SERV_RVS, TB45.VAL_FLAG_QBRA, " 
					   "TB45.COD_TCNL, TB45.COD_TERM, TB45.NUM_STAN, TB45.COD_CMPM_TRAN, "
					   "TB45.VAL_SQUE, TB45.VAL_PRES_BRTO, TB45.VAL_RMNR_RCD, " 
					   "TB45.VAL_IOF, TB45.VAL_CPMF, TB45.VAL_TAC, TB45.TIP_IOF, " 
					   "TB46.NUM_PRCL, TB46.VAL_PRCL, TB46.DAT_PRCL ";

		table_name = "TBSW0045 TB45, TBSW0046 TB46";
		
		m_NUM_RV_pos = 1;
		m_NUM_PDV_pos = 2;
		m_IND_NUM_QBRA_pos = 3;
		m_DAT_RV_pos = 4;
		m_COD_BNDR_pos = 5;
		m_NOM_BNDR_pos = 6;
		m_COD_PROD_pos = 7;
		m_NOM_PROD_pos = 8;
		m_QTD_CV_pos = 9;
		m_VAL_TOTL_LQDO_pos = 10;
		m_VAL_TOTL_DSCT_pos = 11;
		m_VAL_TOTL_GRJT_pos = 12;
		m_VAL_TOTL_PAGO_pos = 13;
		m_DAT_CRE_RV_pos = 14;
		m_VAL_SIT_RVS_pos = 15;
		m_DTH_INI_pos = 16;
		m_DTH_FIM_pos = 17;
		m_QTD_PRCL_pos = 18;
		m_VAL_ENTR_pos = 19;
		m_VAL_TX_SERV_RVS_pos = 20;
		m_VAL_FLAG_QBRA_pos = 21;
		m_COD_TCNL_pos = 22;
		m_COD_TERM_pos = 23;
		m_NUM_STAN_pos = 24;
		m_COD_CMPM_TRAN_pos = 25;
		m_VAL_SQUE_pos = 26;
		m_VAL_PRES_BRTO_pos = 27;
		m_VAL_RMNR_RCD_pos = 28;
		m_VAL_IOF_pos = 29;
		m_VAL_CPMF_pos = 30;
		m_VAL_TAC_pos = 31;
		m_TIP_IOF_pos = 32;
		m_NUM_PRCL_pos = 33;
		m_VAL_PRCL_pos = 34;
		m_DAT_PRCL_pos = 35;

		dbm_longtodec( &m_NUM_RV, 0 );
		m_NUM_PDV = 0;
		m_IND_NUM_QBRA = 0;
		m_DAT_RV = 0;
		m_COD_BNDR = 0;
		m_NOM_BNDR = " ";
		m_COD_PROD = 0;
		m_NOM_PROD = " ";
		dbm_longtodec( &m_QTD_CV, 0 );
		dbm_chartodec( &m_VAL_TOTL_LQDO, "0.00", 2 );
		dbm_chartodec( &m_VAL_TOTL_DSCT, "0.00", 2 );
		dbm_chartodec( &m_VAL_TOTL_GRJT, "0.00", 2 );
		dbm_chartodec( &m_VAL_TOTL_PAGO, "0.00", 2 );
		m_DAT_CRE_RV = 0;
		m_VAL_SIT_RVS = 0;
		m_DTH_INI = 0;
		m_DTH_FIM = 0;
		m_QTD_PRCL = 0;
		dbm_chartodec( &m_VAL_ENTR, "0.00", 2 );
		dbm_chartodec( &m_VAL_TX_SERV_RVS, "0.00", 2 );
		m_VAL_FLAG_QBRA = "";
		m_COD_TCNL = "";
		m_COD_TERM = " ";
		m_NUM_STAN = 0;
		m_COD_CMPM_TRAN = 0;
		dbm_chartodec( &m_VAL_SQUE, "0.00", 2 );
		dbm_chartodec( &m_VAL_PRES_BRTO, "0.00", 2 );
		dbm_chartodec( &m_VAL_RMNR_RCD, "0.00", 2 );
		dbm_chartodec( &m_VAL_IOF, "0.00", 2 );
		dbm_chartodec( &m_VAL_CPMF, "0.00", 2 );
		dbm_chartodec( &m_VAL_TAC, "0.00", 2 );
		m_TIP_IOF = "";
		dbm_longtodec( &m_NUM_RV, 0 );
		m_IND_NUM_QBRA = 0;
		m_NUM_PRCL = 0;
		dbm_chartodec( &m_VAL_PRCL, "0.00", 2 );
		m_DAT_PRCL = 0;
		m_NUM_PDV = 0;
		
		where_condition = "";

                update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
	
    SalesTablesJoint::SalesTablesJoint( const std::string& whereClause ) 
    {
		query_fields = " TB45.NUM_RV, TB45.NUM_PDV, TB45.IND_NUM_QBRA, TB45.DAT_RV, "
					   "TB45.COD_BNDR, TB45.NOM_BNDR, TB45.COD_PROD, TB45.NOM_PROD, "
					   "TB45.QTD_CV, TB45.VAL_TOTL_LQDO, TB45.VAL_TOTL_DSCT, "
					   "TB45.VAL_TOTL_GRJT, TB45.VAL_TOTL_PAGO, TB45.DAT_CRE_RV, " 
					   "TB45.VAL_SIT_RVS, TB45.DTH_INI, DTH_FIM, TB45.QTD_PRCL, "
					   "TB45.VAL_ENTR, TB45.VAL_TX_SERV_RVS, TB45.VAL_FLAG_QBRA, " 
					   "TB45.COD_TCNL, TB45.COD_TERM, TB45.NUM_STAN, TB45.COD_CMPM_TRAN, "
					   "TB45.VAL_SQUE, TB45.VAL_PRES_BRTO, TB45.VAL_RMNR_RCD, " 
					   "TB45.VAL_IOF, TB45.VAL_CPMF, TB45.VAL_TAC, TB45.TIP_IOF, " 
					   "TB46.NUM_PRCL, TB46.VAL_PRCL, TB46.DAT_PRCL ";

		table_name = "TBSW0045 TB45, TBSW0046 TB46";

		where_condition = whereClause;
	
		//where_condition="TB45.NUM_PDV=52248 AND TB45.COD_TCNL='H' AND TB45.VAL_SIT_RVS=100 AND TB45.IND_NUM_QBRA=1 AND TB45.NUM_PDV=TB46.NUM_PDV AND TB45.IND_NUM_QBRA=TB46.IND_NUM_QBRA AND TB45.NUM_RV=TB46.NUM_RV";
	
		m_NUM_RV_pos = 1;
		m_NUM_PDV_pos = 2;
		m_IND_NUM_QBRA_pos = 3;
		m_DAT_RV_pos = 4;
		m_COD_BNDR_pos = 5;
		m_NOM_BNDR_pos = 6;
		m_COD_PROD_pos = 7;
		m_NOM_PROD_pos = 8;
		m_QTD_CV_pos = 9;
		m_VAL_TOTL_LQDO_pos = 10;
		m_VAL_TOTL_DSCT_pos = 11;
		m_VAL_TOTL_GRJT_pos = 12;
		m_VAL_TOTL_PAGO_pos = 13;
		m_DAT_CRE_RV_pos = 14;
		m_VAL_SIT_RVS_pos = 15;
		m_DTH_INI_pos = 16;
		m_DTH_FIM_pos = 17;
		m_QTD_PRCL_pos = 18;
		m_VAL_ENTR_pos = 19;
		m_VAL_TX_SERV_RVS_pos = 20;
		m_VAL_FLAG_QBRA_pos = 21;
		m_COD_TCNL_pos = 22;
		m_COD_TERM_pos = 23;
		m_NUM_STAN_pos = 24;
		m_COD_CMPM_TRAN_pos = 25;
		m_VAL_SQUE_pos = 26;
		m_VAL_PRES_BRTO_pos = 27;
		m_VAL_RMNR_RCD_pos = 28;
		m_VAL_IOF_pos = 29;
		m_VAL_CPMF_pos = 30;
		m_VAL_TAC_pos = 31;
		m_TIP_IOF_pos = 32;
		m_NUM_PRCL_pos = 33;
		m_VAL_PRCL_pos = 34;
		m_DAT_PRCL_pos = 35;

		dbm_longtodec( &m_NUM_RV, 0 );
		m_NUM_PDV = 0;
		m_IND_NUM_QBRA = 0;
		m_DAT_RV = 0;
		m_COD_BNDR = 0;
		m_NOM_BNDR = " ";
		m_COD_PROD = 0;
		m_NOM_PROD = " ";
		dbm_longtodec( &m_QTD_CV, 0 );
		dbm_chartodec( &m_VAL_TOTL_LQDO, "0.00", 2 );
		dbm_chartodec( &m_VAL_TOTL_DSCT, "0.00", 2 );
		dbm_chartodec( &m_VAL_TOTL_GRJT, "0.00", 2 );
		dbm_chartodec( &m_VAL_TOTL_PAGO, "0.00", 2 );
		m_DAT_CRE_RV = 0;
		m_VAL_SIT_RVS = 0;
		m_DTH_INI = 0;
		m_DTH_FIM = 0;
		m_QTD_PRCL = 0;
		dbm_chartodec( &m_VAL_ENTR, "0.00", 2 );
		dbm_chartodec( &m_VAL_TX_SERV_RVS, "0.00", 2 );
		m_VAL_FLAG_QBRA = "";
		m_COD_TCNL = "";
		m_COD_TERM = " ";
		m_NUM_STAN = 0;
		m_COD_CMPM_TRAN = 0;
		dbm_chartodec( &m_VAL_SQUE, "0.00", 2 );
		dbm_chartodec( &m_VAL_PRES_BRTO, "0.00", 2 );
		dbm_chartodec( &m_VAL_RMNR_RCD, "0.00", 2 );
		dbm_chartodec( &m_VAL_IOF, "0.00", 2 );
		dbm_chartodec( &m_VAL_CPMF, "0.00", 2 );
		dbm_chartodec( &m_VAL_TAC, "0.00", 2 );
		m_TIP_IOF = "";
		dbm_longtodec( &m_NUM_RV, 0 );
		m_IND_NUM_QBRA = 0;
		m_NUM_PRCL = 0;
		dbm_chartodec( &m_VAL_PRCL, "0.00", 2 );
		m_DAT_PRCL = 0;
		m_NUM_PDV = 0;

                update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

    SalesTablesJoint::~SalesTablesJoint()
    {
    }
	
    void SalesTablesJoint::bind_columns()
    {
		//TBSW45
		bind( m_NUM_RV_pos, m_NUM_RV );
		bind( m_NUM_PDV_pos, m_NUM_PDV );
		bind( m_IND_NUM_QBRA_pos, m_IND_NUM_QBRA );
		bind( m_DAT_RV_pos, &m_DAT_RV );
		bind( m_COD_BNDR_pos, m_COD_BNDR );
		bind( m_NOM_BNDR_pos, m_NOM_BNDR );
		bind( m_COD_PROD_pos, m_COD_PROD );
		bind( m_NOM_PROD_pos, m_NOM_PROD );
		bind( m_QTD_CV_pos, m_QTD_CV );
		bind( m_VAL_TOTL_LQDO_pos, m_VAL_TOTL_LQDO );
		bind( m_VAL_TOTL_DSCT_pos, m_VAL_TOTL_DSCT );
		bind( m_VAL_TOTL_GRJT_pos, m_VAL_TOTL_GRJT );
		bind( m_VAL_TOTL_PAGO_pos, m_VAL_TOTL_PAGO );
		bind( m_DAT_CRE_RV_pos, &m_DAT_CRE_RV );
		bind( m_VAL_SIT_RVS_pos, m_VAL_SIT_RVS );
		bind( m_DTH_INI_pos, &m_DTH_INI );
		bind( m_DTH_FIM_pos, &m_DTH_FIM );
		bind( m_QTD_PRCL_pos, m_QTD_PRCL );
		bind( m_VAL_ENTR_pos, m_VAL_ENTR );
		bind( m_VAL_TX_SERV_RVS_pos, m_VAL_TX_SERV_RVS );
		bind( m_VAL_FLAG_QBRA_pos, m_VAL_FLAG_QBRA );
		bind( m_COD_TCNL_pos, m_COD_TCNL );
		bind( m_COD_TERM_pos, m_COD_TERM );
		bind( m_NUM_STAN_pos, m_NUM_STAN );
		bind( m_COD_CMPM_TRAN_pos, m_COD_CMPM_TRAN );
		bind( m_VAL_SQUE_pos, m_VAL_SQUE );
		bind( m_VAL_PRES_BRTO_pos, m_VAL_PRES_BRTO );
		bind( m_VAL_RMNR_RCD_pos, m_VAL_RMNR_RCD );
		bind( m_VAL_IOF_pos, m_VAL_IOF );
		bind( m_VAL_CPMF_pos, m_VAL_CPMF );
		bind( m_VAL_TAC_pos, m_VAL_TAC );
		bind( m_TIP_IOF_pos, m_TIP_IOF );
		//TBSW46
		bind( m_NUM_PRCL_pos, m_NUM_PRCL );
		bind( m_VAL_PRCL_pos, m_VAL_PRCL );
		bind( m_DAT_PRCL_pos, &m_DAT_PRCL );
    }

    void SalesTablesJoint::set_NUM_RV( oasis_dec_t a_NUM_RV )
    {
        dbm_deccopy( &m_NUM_RV, &a_NUM_RV );
    }
    void SalesTablesJoint::set_NUM_PDV( unsigned long a_NUM_PDV )
    {
        m_NUM_PDV = a_NUM_PDV;
    }
    void SalesTablesJoint::set_IND_NUM_QBRA( unsigned long a_IND_NUM_QBRA )
    {
        m_IND_NUM_QBRA = a_IND_NUM_QBRA;
    }
    void SalesTablesJoint::set_DAT_RV( dbm_datetime_t a_DAT_RV )
    {
        m_DAT_RV = a_DAT_RV;
    }
    void SalesTablesJoint::set_COD_BNDR( unsigned long a_COD_BNDR )
    {
        m_COD_BNDR = a_COD_BNDR;
    }
    void SalesTablesJoint::set_NOM_BNDR( const std::string& a_NOM_BNDR )
    {
        m_NOM_BNDR = a_NOM_BNDR;
    }
    void SalesTablesJoint::set_COD_PROD( long a_COD_PROD )
    {
        m_COD_PROD = a_COD_PROD;
    }
    void SalesTablesJoint::set_NOM_PROD( const std::string& a_NOM_PROD )
    {
        m_NOM_PROD = a_NOM_PROD;
    }
    void SalesTablesJoint::set_QTD_CV( oasis_dec_t a_QTD_CV )
    {
        dbm_deccopy( &m_QTD_CV, &a_QTD_CV );
    }
    void SalesTablesJoint::set_VAL_TOTL_LQDO( oasis_dec_t a_VAL_TOTL_LQDO )
    {
        dbm_deccopy( &m_VAL_TOTL_LQDO, &a_VAL_TOTL_LQDO );
    }
    void SalesTablesJoint::set_VAL_TOTL_DSCT( oasis_dec_t a_VAL_TOTL_DSCT )
    {
        dbm_deccopy( &m_VAL_TOTL_DSCT, &a_VAL_TOTL_DSCT );
    }
    void SalesTablesJoint::set_VAL_TOTL_GRJT( oasis_dec_t a_VAL_TOTL_GRJT )
    {
        dbm_deccopy( &m_VAL_TOTL_GRJT, &a_VAL_TOTL_GRJT );
    }
    void SalesTablesJoint::set_VAL_TOTL_PAGO( oasis_dec_t a_VAL_TOTL_PAGO )
    {
        dbm_deccopy( &m_VAL_TOTL_PAGO, &a_VAL_TOTL_PAGO );
    }
    void SalesTablesJoint::set_DAT_CRE_RV( dbm_datetime_t a_DAT_CRE_RV )
    {
        m_DAT_CRE_RV = a_DAT_CRE_RV;
    }
    void SalesTablesJoint::set_VAL_SIT_RVS( unsigned long a_VAL_SIT_RVS )
    {
        m_VAL_SIT_RVS = a_VAL_SIT_RVS;
    }
    void SalesTablesJoint::set_DTH_INI( dbm_datetime_t a_DTH_INI )
    {
        m_DTH_INI = a_DTH_INI;
    }
    void SalesTablesJoint::set_DTH_FIM( dbm_datetime_t a_DTH_FIM )
    {
        m_DTH_FIM = a_DTH_FIM;
    }
    void SalesTablesJoint::set_QTD_PRCL( unsigned long a_QTD_PRCL )
    {
        m_QTD_PRCL = a_QTD_PRCL;
    }
    void SalesTablesJoint::set_VAL_ENTR( oasis_dec_t a_VAL_ENTR )
    {
        dbm_deccopy( &m_VAL_ENTR, &a_VAL_ENTR );
    }
    void SalesTablesJoint::set_VAL_TX_SERV_RVS( oasis_dec_t a_VAL_TX_SERV_RVS )
    {
        dbm_deccopy( &m_VAL_TX_SERV_RVS, &a_VAL_TX_SERV_RVS );
    }
    void SalesTablesJoint::set_VAL_FLAG_QBRA( const std::string& a_VAL_FLAG_QBRA )
    {
        m_VAL_FLAG_QBRA = a_VAL_FLAG_QBRA;
    }
    void SalesTablesJoint::set_COD_TCNL( const std::string& a_COD_TCNL )
    {
        m_COD_TCNL = a_COD_TCNL;
    }
    void SalesTablesJoint::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void SalesTablesJoint::set_NUM_STAN( unsigned long a_NUM_STAN )
    {
        m_NUM_STAN = a_NUM_STAN;
    }
    void SalesTablesJoint::set_COD_CMPM_TRAN( unsigned long a_COD_CMPM_TRAN )
    {
        m_COD_CMPM_TRAN = a_COD_CMPM_TRAN;
    }
    void SalesTablesJoint::set_VAL_SQUE( oasis_dec_t a_VAL_SQUE )
    {
        dbm_deccopy( &m_VAL_SQUE, &a_VAL_SQUE );
    }
    void SalesTablesJoint::set_VAL_PRES_BRTO( oasis_dec_t a_VAL_PRES_BRTO )
    {
        dbm_deccopy( &m_VAL_PRES_BRTO, &a_VAL_PRES_BRTO );
    }
    void SalesTablesJoint::set_VAL_RMNR_RCD( oasis_dec_t a_VAL_RMNR_RCD )
    {
        dbm_deccopy( &m_VAL_RMNR_RCD, &a_VAL_RMNR_RCD );
    }
    void SalesTablesJoint::set_VAL_IOF( oasis_dec_t a_VAL_IOF )
    {
        dbm_deccopy( &m_VAL_IOF, &a_VAL_IOF );
    }
    void SalesTablesJoint::set_VAL_CPMF( oasis_dec_t a_VAL_CPMF )
    {
        dbm_deccopy( &m_VAL_CPMF, &a_VAL_CPMF );
    }
    void SalesTablesJoint::set_VAL_TAC( oasis_dec_t a_VAL_TAC )
    {
        dbm_deccopy( &m_VAL_TAC, &a_VAL_TAC );
    }
    void SalesTablesJoint::set_TIP_IOF( const std::string& a_TIP_IOF )
    {
        m_TIP_IOF = a_TIP_IOF;
    }
    void SalesTablesJoint::set_NUM_PRCL( long a_NUM_PRCL )
    {
        m_NUM_PRCL = a_NUM_PRCL;
    }
    void SalesTablesJoint::set_VAL_PRCL( oasis_dec_t a_VAL_PRCL )
    {
        dbm_deccopy( &m_VAL_PRCL, &a_VAL_PRCL );
    }
    void SalesTablesJoint::set_DAT_PRCL( dbm_datetime_t a_DAT_PRCL )
    {
        m_DAT_PRCL = a_DAT_PRCL;
    }

    oasis_dec_t SalesTablesJoint::get_NUM_RV() const
    {
        return m_NUM_RV;
    }
    unsigned long SalesTablesJoint::get_NUM_PDV() const
    {
        return m_NUM_PDV;
    }
    unsigned long SalesTablesJoint::get_IND_NUM_QBRA() const
    {
        return m_IND_NUM_QBRA;
    }
    dbm_datetime_t SalesTablesJoint::get_DAT_RV() const
    {
        return m_DAT_RV;
    }
    unsigned long SalesTablesJoint::get_COD_BNDR() const
    {
        return m_COD_BNDR;
    }
    const std::string& SalesTablesJoint::get_NOM_BNDR() const
    {
        return m_NOM_BNDR;
    }
    long SalesTablesJoint::get_COD_PROD() const
    {
        return m_COD_PROD;
    }
    const std::string& SalesTablesJoint::get_NOM_PROD() const
    {
        return m_NOM_PROD;
    }
    oasis_dec_t SalesTablesJoint::get_QTD_CV() const
    {
        return m_QTD_CV;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_TOTL_LQDO() const
    {
        return m_VAL_TOTL_LQDO;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_TOTL_DSCT() const
    {
        return m_VAL_TOTL_DSCT;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_TOTL_GRJT() const
    {
        return m_VAL_TOTL_GRJT;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_TOTL_PAGO() const
    {
        return m_VAL_TOTL_PAGO;
    }
    dbm_datetime_t SalesTablesJoint::get_DAT_CRE_RV() const
    {
        return m_DAT_CRE_RV;
    }
    unsigned long SalesTablesJoint::get_VAL_SIT_RVS() const
    {
        return m_VAL_SIT_RVS;
    }
    dbm_datetime_t SalesTablesJoint::get_DTH_INI() const
    {
        return m_DTH_INI;
    }
    dbm_datetime_t SalesTablesJoint::get_DTH_FIM() const
    {
        return m_DTH_FIM;
    }
    unsigned long SalesTablesJoint::get_QTD_PRCL() const
    {
        return m_QTD_PRCL;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_ENTR() const
    {
        return m_VAL_ENTR;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_TX_SERV_RVS() const
    {
        return m_VAL_TX_SERV_RVS;
    }
    const std::string& SalesTablesJoint::get_VAL_FLAG_QBRA() const
    {
        return m_VAL_FLAG_QBRA;
    }
    const std::string& SalesTablesJoint::get_COD_TCNL() const
    {
        return m_COD_TCNL;
    }
    const std::string& SalesTablesJoint::get_COD_TERM() const
    {
        return m_COD_TERM;
    }
    unsigned long SalesTablesJoint::get_NUM_STAN() const
    {
        return m_NUM_STAN;
    }
    unsigned long SalesTablesJoint::get_COD_CMPM_TRAN() const
    {
        return m_COD_CMPM_TRAN;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_SQUE() const
    {
        return m_VAL_SQUE;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_PRES_BRTO() const
    {
        return m_VAL_PRES_BRTO;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_RMNR_RCD() const
    {
        return m_VAL_RMNR_RCD;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_IOF() const
    {
        return m_VAL_IOF;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_CPMF() const
    {
        return m_VAL_CPMF;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_TAC() const
    {
        return m_VAL_TAC;
    }
    const std::string& SalesTablesJoint::get_TIP_IOF() const
    {
        return m_TIP_IOF;
    }
    long SalesTablesJoint::get_NUM_PRCL() const
    {
        return m_NUM_PRCL;
    }
    oasis_dec_t SalesTablesJoint::get_VAL_PRCL() const
    {
        return m_VAL_PRCL;
    }
    dbm_datetime_t SalesTablesJoint::get_DAT_PRCL() const
    {
        return m_DAT_PRCL;
    }

} //namespace dbaccess_pdv

