#include <dbaccess_pdv/TBSW0157RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    TBSW0157RegrasFormatacao::TBSW0157RegrasFormatacao( )
    {
    }
    
    TBSW0157RegrasFormatacao::~TBSW0157RegrasFormatacao( )
    {
    }
}