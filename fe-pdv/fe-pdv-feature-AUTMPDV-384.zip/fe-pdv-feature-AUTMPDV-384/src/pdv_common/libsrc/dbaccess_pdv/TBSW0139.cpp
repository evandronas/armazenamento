/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0139>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0139>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, CKen>
/ Data de Cria��o: <Thu Apr 18 11:14:17 2013>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/
#pragma once
#include "dbaccess_pdv/TBSW0139.hpp"

namespace dbaccess_pdv
{
    TBSW0139::TBSW0139()
    {
        where_condition = "";
        initialize( );
	    update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0139::TBSW0139( const std::string& str )
    {
        where_condition = str;
        initialize( );
	    update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0139::~TBSW0139()
    {
    }

    void TBSW0139::initialize( )
    {
        query_fields = "COD_TERM, DAT_MOV_TRAN, COD_PNPD_PDV, TIP_CIP, NUM_PDV, NUM_VERS_SRVD_PDV, NUM_VERS_CLIT, NUM_VERS_APLV_RCD, NUM_VERS_SFTW_BBLT_PNPD, NUM_VERS_ESPF_BBLT_PNPD, COD_FBRC_PDV, NOM_SITE_ACQR_ORGL, NOM_HOST_ACQR_ORGL, NOM_FE_ACQR_ORGL, NOM_SITE_ISSR, NOM_HOST_ISSR, NOM_FE_ISSR, NOM_SITE_ACQR_ATLZ, NOM_HOST_ACQR_ATLZ, NOM_FE_ACQR_ATLZ, TIP_GRU_TERM";
        
        table_name = "TBSW0139";
        
        m_COD_TERM_pos = 1;
        m_DAT_MOV_TRAN_pos = 2;
        m_COD_PNPD_PDV_pos = 3;
        m_TIP_CIP_pos = 4;
        m_NUM_PDV_pos = 5;
        m_NUM_VERS_SRVD_PDV_pos = 6;
        m_NUM_VERS_CLIT_pos = 7;
        m_NUM_VERS_APLV_RCD_pos = 8;
        m_NUM_VERS_SFTW_BBLT_PNPD_pos = 9;
        m_NUM_VERS_ESPF_BBLT_PNPD_pos = 10;
        m_COD_FBRC_PDV_pos = 11;
		m_NOM_SITE_ACQR_ORGL_pos = 12;
		m_NOM_HOST_ACQR_ORGL_pos = 13;
		m_NOM_FE_ACQR_ORGL_pos = 14;
		m_NOM_SITE_ISSR_pos = 15;
		m_NOM_HOST_ISSR_pos = 16;
		m_NOM_FE_ISSR_pos = 17;
		m_NOM_SITE_ACQR_ATLZ_pos = 18;
		m_NOM_HOST_ACQR_ATLZ_pos = 19;
		m_NOM_FE_ACQR_ATLZ_pos = 20;
		m_TIP_GRU_TERM_pos = 21;

        m_NUM_PDV = 0;
        m_TIP_CIP = " ";    // NOT NULL string
        m_COD_TERM = " ";   // NOT NULL string
        m_DAT_MOV_TRAN = 0;
        m_COD_FBRC_PDV = "";
        m_COD_PNPD_PDV = "";
        m_NUM_VERS_CLIT = "";
        m_NUM_VERS_SRVD_PDV = "";
        m_NUM_VERS_APLV_RCD = "";
        m_NUM_VERS_SFTW_BBLT_PNPD = "";
        m_NUM_VERS_ESPF_BBLT_PNPD = "";
		m_NOM_SITE_ACQR_ORGL = " "; // NOT NULL 
		m_NOM_HOST_ACQR_ORGL = " "; // NOT NULL 
		m_NOM_FE_ACQR_ORGL = ""; // NOT NULL 
		m_NOM_SITE_ISSR = "";
		m_NOM_HOST_ISSR = "";
		m_NOM_FE_ISSR = "";
		m_NOM_SITE_ACQR_ATLZ = "";
		m_NOM_HOST_ACQR_ATLZ = "";
		m_NOM_FE_ACQR_ATLZ = "";
		m_TIP_GRU_TERM = " "; // NOT NULL 
		
        m_COD_PNPD_PDV_ind_null = DBM_NULL_DATA;
        m_NUM_PDV_ind_null = DBM_NULL_DATA;
        m_NUM_VERS_SRVD_PDV_ind_null = DBM_NULL_DATA;
        m_NUM_VERS_CLIT_ind_null = DBM_NULL_DATA;
        m_NUM_VERS_APLV_RCD_ind_null = DBM_NULL_DATA;
        m_NUM_VERS_SFTW_BBLT_PNPD_ind_null = DBM_NULL_DATA;
        m_NUM_VERS_ESPF_BBLT_PNPD_ind_null = DBM_NULL_DATA;
        m_COD_FBRC_PDV_ind_null = DBM_NULL_DATA;
        m_TIP_GRU_TERM_ind_null = DBM_NULL_DATA;
    }
    
    const std::string& TBSW0139::get_COD_TERM() const
    {
        return m_COD_TERM;
    }
    unsigned long TBSW0139::get_DAT_MOV_TRAN() const
    {
        return m_DAT_MOV_TRAN;
    }
    const std::string& TBSW0139::get_COD_PNPD_PDV() const
    {
        return m_COD_PNPD_PDV;
    }
    const std::string& TBSW0139::get_TIP_CIP() const
    {
        return m_TIP_CIP;
    }
    unsigned long TBSW0139::get_NUM_PDV() const
    {
        return m_NUM_PDV;
    }
    const std::string& TBSW0139::get_NUM_VERS_SRVD_PDV() const
    {
        return m_NUM_VERS_SRVD_PDV;
    }
    const std::string& TBSW0139::get_NUM_VERS_CLIT() const
    {
        return m_NUM_VERS_CLIT;
    }
    const std::string& TBSW0139::get_NUM_VERS_APLV_RCD() const
    {
        return m_NUM_VERS_APLV_RCD;
    }
    const std::string& TBSW0139::get_NUM_VERS_SFTW_BBLT_PNPD() const
    {
        return m_NUM_VERS_SFTW_BBLT_PNPD;
    }
    const std::string& TBSW0139::get_NUM_VERS_ESPF_BBLT_PNPD() const
    {
        return m_NUM_VERS_ESPF_BBLT_PNPD;
    }
    const std::string& TBSW0139::get_COD_FBRC_PDV() const
    {
        return m_COD_FBRC_PDV;
    }
	const std::string& TBSW0139::get_NOM_SITE_ACQR_ORGL() const
    {
        return m_NOM_SITE_ACQR_ORGL;
    }
    const std::string& TBSW0139::get_NOM_HOST_ACQR_ORGL() const
    {
        return m_NOM_HOST_ACQR_ORGL;
    }
    const std::string& TBSW0139::get_NOM_FE_ACQR_ORGL() const
    {
        return m_NOM_FE_ACQR_ORGL;
    }
    const std::string& TBSW0139::get_NOM_SITE_ISSR() const
    {
        return m_NOM_SITE_ISSR;
    }
    const std::string& TBSW0139::get_NOM_HOST_ISSR() const
    {
        return m_NOM_HOST_ISSR;
    }
    const std::string& TBSW0139::get_NOM_FE_ISSR() const
    {
        return m_NOM_FE_ISSR;
    }
    const std::string& TBSW0139::get_NOM_SITE_ACQR_ATLZ() const
    {
        return m_NOM_SITE_ACQR_ATLZ;
    }
    const std::string& TBSW0139::get_NOM_HOST_ACQR_ATLZ() const
    {
        return m_NOM_HOST_ACQR_ATLZ;
    }
    const std::string& TBSW0139::get_NOM_FE_ACQR_ATLZ() const
    {
        return m_NOM_FE_ACQR_ATLZ;
    }
    const std::string& TBSW0139::get_TIP_GRU_TERM() const
    {
        return m_TIP_GRU_TERM;
    }


    void  TBSW0139::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void  TBSW0139::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void  TBSW0139::set_COD_PNPD_PDV( const std::string& a_COD_PNPD_PDV )
    {
        m_COD_PNPD_PDV = a_COD_PNPD_PDV;
    }
    void  TBSW0139::set_TIP_CIP( const std::string& a_TIP_CIP )
    {
        m_TIP_CIP = a_TIP_CIP;
    }
    void  TBSW0139::set_NUM_PDV( unsigned long a_NUM_PDV )
    {
        m_NUM_PDV = a_NUM_PDV;
        m_NUM_PDV_ind_null = 0;
    }
    void  TBSW0139::set_NUM_VERS_SRVD_PDV( const std::string& a_NUM_VERS_SRVD_PDV )
    {
        m_NUM_VERS_SRVD_PDV = a_NUM_VERS_SRVD_PDV;
    }
    void  TBSW0139::set_NUM_VERS_CLIT( const std::string& a_NUM_VERS_CLIT )
    {
        m_NUM_VERS_CLIT = a_NUM_VERS_CLIT;
    }
    void  TBSW0139::set_NUM_VERS_APLV_RCD( const std::string& a_NUM_VERS_APLV_RCD )
    {
        m_NUM_VERS_APLV_RCD = a_NUM_VERS_APLV_RCD;
    }
    void  TBSW0139::set_NUM_VERS_SFTW_BBLT_PNPD( const std::string& a_NUM_VERS_SFTW_BBLT_PNPD )
    {
        m_NUM_VERS_SFTW_BBLT_PNPD = a_NUM_VERS_SFTW_BBLT_PNPD;
    }
    void  TBSW0139::set_NUM_VERS_ESPF_BBLT_PNPD( const std::string& a_NUM_VERS_ESPF_BBLT_PNPD )
    {
        m_NUM_VERS_ESPF_BBLT_PNPD = a_NUM_VERS_ESPF_BBLT_PNPD;
    }
    void  TBSW0139::set_COD_FBRC_PDV( const std::string& a_COD_FBRC_PDV )
    {
        m_COD_FBRC_PDV = a_COD_FBRC_PDV;
    }
	void  TBSW0139::set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL )
    {
        m_NOM_SITE_ACQR_ORGL = a_NOM_SITE_ACQR_ORGL;
    }
    void  TBSW0139::set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL )
    {
        m_NOM_HOST_ACQR_ORGL = a_NOM_HOST_ACQR_ORGL;
    }
    void  TBSW0139::set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL )
    {
        m_NOM_FE_ACQR_ORGL = a_NOM_FE_ACQR_ORGL;
    }
    void  TBSW0139::set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR )
    {
        m_NOM_SITE_ISSR = a_NOM_SITE_ISSR;
    }
    void  TBSW0139::set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR )
    {
        m_NOM_HOST_ISSR = a_NOM_HOST_ISSR;
    }
    void  TBSW0139::set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR )
    {
        m_NOM_FE_ISSR = a_NOM_FE_ISSR;
    }
    void  TBSW0139::set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ )
    {
        m_NOM_SITE_ACQR_ATLZ = a_NOM_SITE_ACQR_ATLZ;
    }
    void  TBSW0139::set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ )
    {
        m_NOM_HOST_ACQR_ATLZ = a_NOM_HOST_ACQR_ATLZ;
    }
    void  TBSW0139::set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ )
    {
        m_NOM_FE_ACQR_ATLZ = a_NOM_FE_ACQR_ATLZ;
    }
    void  TBSW0139::set_TIP_GRU_TERM( const std::string& a_TIP_GRU_TERM )
    {
        m_TIP_GRU_TERM = a_TIP_GRU_TERM;
    }


    void TBSW0139::bind_columns()
    {
        bind( m_NUM_PDV_pos, m_NUM_PDV, &m_NUM_PDV_ind_null );
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_COD_PNPD_PDV_pos, m_COD_PNPD_PDV );
        bind( m_TIP_CIP_pos, m_TIP_CIP );
        bind( m_NUM_VERS_SRVD_PDV_pos, m_NUM_VERS_SRVD_PDV );
        bind( m_NUM_VERS_CLIT_pos, m_NUM_VERS_CLIT );
        bind( m_NUM_VERS_APLV_RCD_pos, m_NUM_VERS_APLV_RCD );
        bind( m_NUM_VERS_SFTW_BBLT_PNPD_pos, m_NUM_VERS_SFTW_BBLT_PNPD );
        bind( m_NUM_VERS_ESPF_BBLT_PNPD_pos, m_NUM_VERS_ESPF_BBLT_PNPD );
        bind( m_COD_FBRC_PDV_pos, m_COD_FBRC_PDV );
		bind( m_NOM_SITE_ACQR_ORGL_pos, m_NOM_SITE_ACQR_ORGL );
        bind( m_NOM_HOST_ACQR_ORGL_pos, m_NOM_HOST_ACQR_ORGL );
        bind( m_NOM_FE_ACQR_ORGL_pos, m_NOM_FE_ACQR_ORGL );
        bind( m_NOM_SITE_ISSR_pos, m_NOM_SITE_ISSR );
        bind( m_NOM_HOST_ISSR_pos, m_NOM_HOST_ISSR );
        bind( m_NOM_FE_ISSR_pos, m_NOM_FE_ISSR );
        bind( m_NOM_SITE_ACQR_ATLZ_pos, m_NOM_SITE_ACQR_ATLZ );
        bind( m_NOM_HOST_ACQR_ATLZ_pos, m_NOM_HOST_ACQR_ATLZ );
        bind( m_NOM_FE_ACQR_ATLZ_pos, m_NOM_FE_ACQR_ATLZ );
        bind( m_TIP_GRU_TERM_pos, m_TIP_GRU_TERM );
    }
    
    void TBSW0139::let_COD_PNPD_PDV_as_is()   
	{
		m_COD_PNPD_PDV_ind_null = is_null(m_COD_PNPD_PDV) ? DBM_NULL_DATA : 0;    
	}

    void TBSW0139::let_NUM_PDV_as_is()   
	{
		m_NUM_PDV_ind_null = is_null(m_NUM_PDV) ? DBM_NULL_DATA : 0;    
	}

    void TBSW0139::let_NUM_VERS_SRVD_PDV_as_is()   
	{
		m_NUM_VERS_SRVD_PDV_ind_null = is_null(m_NUM_VERS_SRVD_PDV) ? DBM_NULL_DATA : 0;    
	}

    void TBSW0139::let_NUM_VERS_CLIT_as_is()   
	{
		m_NUM_VERS_CLIT_ind_null = is_null(m_NUM_VERS_CLIT) ? DBM_NULL_DATA : 0;    
	}

    void TBSW0139::let_NUM_VERS_APLV_RCD_as_is()   
	{
		m_NUM_VERS_APLV_RCD_ind_null = is_null(m_NUM_VERS_APLV_RCD) ? DBM_NULL_DATA : 0;    
	}

    void TBSW0139::let_NUM_VERS_SFTW_BBLT_PNPD_as_is()   
	{
		m_NUM_VERS_SFTW_BBLT_PNPD_ind_null = is_null(m_NUM_VERS_SFTW_BBLT_PNPD) ? DBM_NULL_DATA : 0;    
	}

    void TBSW0139::let_NUM_VERS_ESPF_BBLT_PNPD_as_is()   
	{
		m_NUM_VERS_ESPF_BBLT_PNPD_ind_null = is_null(m_NUM_VERS_ESPF_BBLT_PNPD) ? DBM_NULL_DATA : 0;    
	}

    void TBSW0139::let_COD_FBRC_PDV_as_is()   
	{
		m_COD_FBRC_PDV_ind_null = is_null(m_COD_FBRC_PDV) ? DBM_NULL_DATA : 0;    
	}

    void TBSW0139::let_TIP_GRU_TERM_as_is()   
	{
		m_TIP_GRU_TERM_ind_null = is_null(m_TIP_GRU_TERM) ? DBM_NULL_DATA : 0;    
	}

}//namespace dbaccess_pdv


