#include "dbaccess_pdv/RoutingVoucherTablesJoint.hpp"

namespace dbaccess_pdv
{
    RoutingVoucherTablesJoint::RoutingVoucherTablesJoint()
    {
        query_fields =
            " TB_ROTA.COD_STTU_REG, TB_ROTA.NUM_RTDR, TB_ROTA.COD_SBPD, TB_ROTA.COD_EMSR, TB_ROTA.NOM_EMSR, "
            "TB_ROTA.COD_TRAN_GE, TB_ROTA.NOM_PROD_CPOM, TB_ROTA.TXT_RDPE_CPOM, TB_ROTA.COD_USR_ATLZ_REG, "
            "TB_ROTA.DAT_ATLZ_REG, TB_ROTA.DAT_ATVC_VOCH, TB_ROTA.NTWKID, TB_ROTA.NUM_BIN, "
            "TB_EMSR.COD_ISSR_SW, TB_EMSR.NOM_EMSR_SW, TB_EMSR.COD_EMSR_SW, TB_EMSR.COD_BNDR, TB_EMSR.COD_FE_EMSR "
        ;
        table_name = "TBSW0113 TB_ROTA, TBSW2011 TB_EMSR";
        where_condition = " TB_EMSR.COD_ISSR_SW = 56 ";

        m_COD_STTU_REG_pos = 1;
        m_NUM_RTDR_pos = 2;
        m_COD_SBPD_pos = 3;
        m_COD_EMSR_pos = 4;
        m_NOM_EMSR_pos = 5;
        m_COD_TRAN_GE_pos = 6;
        m_NOM_PROD_CPOM_pos = 7;
        m_TXT_RDPE_CPOM_pos = 8;
        m_COD_USR_ATLZ_REG_pos = 9;
        m_DAT_ATLZ_REG_pos = 10;
        m_DAT_ATVC_VOCH_pos = 11;
        m_NTWKID_pos = 12;
        m_NUM_BIN_pos = 13;
        m_COD_ISSR_SW_pos = 14;
        m_NOM_EMSR_SW_pos = 15;
        m_COD_EMSR_SW_pos = 16;
        m_COD_BNDR_pos = 17;
        m_COD_FE_EMSR_pos = 18;

        // TBSW0113
        m_COD_STTU_REG = " ";
        m_NUM_RTDR = 0;
        m_COD_SBPD = 0;
        m_COD_EMSR = 0;
        m_NOM_EMSR = " ";
        m_COD_TRAN_GE = 0;
        m_NOM_PROD_CPOM = " ";
        m_TXT_RDPE_CPOM = "";
        m_COD_USR_ATLZ_REG = " ";
        m_DAT_ATLZ_REG = 0;
        m_DAT_ATVC_VOCH = 0;
        m_NTWKID = "";
        m_NUM_BIN = 0;
        // TBSW2011
        m_COD_ISSR_SW = 0;
        m_NOM_EMSR_SW = "";
        m_COD_EMSR_SW = 0;
        m_COD_BNDR = 0;
        m_COD_FE_EMSR = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    RoutingVoucherTablesJoint::RoutingVoucherTablesJoint( const std::string &str )
    {
        query_fields =
            " TB_ROTA.COD_STTU_REG, TB_ROTA.NUM_RTDR, TB_ROTA.COD_SBPD, TB_ROTA.COD_EMSR, TB_ROTA.NOM_EMSR, "
            "TB_ROTA.COD_TRAN_GE, TB_ROTA.NOM_PROD_CPOM, TB_ROTA.TXT_RDPE_CPOM, TB_ROTA.COD_USR_ATLZ_REG, "
            "TB_ROTA.DAT_ATLZ_REG, TB_ROTA.DAT_ATVC_VOCH, TB_ROTA.NTWKID, TB_ROTA.NUM_BIN, "
            "TB_EMSR.COD_ISSR_SW, TB_EMSR.NOM_EMSR_SW, TB_EMSR.COD_EMSR_SW, TB_EMSR.COD_BNDR, TB_EMSR.COD_FE_EMSR "
        ;
        table_name = "TBSW0113 TB_ROTA, TBSW2011 TB_EMSR";
        where_condition = str;

        m_COD_STTU_REG_pos = 1;
        m_NUM_RTDR_pos = 2;
        m_COD_SBPD_pos = 3;
        m_COD_EMSR_pos = 4;
        m_NOM_EMSR_pos = 5;
        m_COD_TRAN_GE_pos = 6;
        m_NOM_PROD_CPOM_pos = 7;
        m_TXT_RDPE_CPOM_pos = 8;
        m_COD_USR_ATLZ_REG_pos = 9;
        m_DAT_ATLZ_REG_pos = 10;
        m_DAT_ATVC_VOCH_pos = 11;
        m_NTWKID_pos = 12;
        m_NUM_BIN_pos = 13;
        m_COD_ISSR_SW_pos = 14;
        m_NOM_EMSR_SW_pos = 15;
        m_COD_EMSR_SW_pos = 16;
        m_COD_BNDR_pos = 17;
        m_COD_FE_EMSR_pos = 18;

        // TBSW0113
        m_COD_STTU_REG = " ";
        m_NUM_RTDR = 0;
        m_COD_SBPD = 0;
        m_COD_EMSR = 0;
        m_NOM_EMSR = " ";
        m_COD_TRAN_GE = 0;
        m_NOM_PROD_CPOM = " ";
        m_TXT_RDPE_CPOM = "";
        m_COD_USR_ATLZ_REG = " ";
        m_DAT_ATLZ_REG = 0;
        m_DAT_ATVC_VOCH = 0;
        m_NTWKID = "";
        m_NUM_BIN = 0;
        // TBSW2011
        m_COD_ISSR_SW = 0;
        m_NOM_EMSR_SW = "";
        m_COD_EMSR_SW = 0;
        m_COD_BNDR = 0;
        m_COD_FE_EMSR = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    RoutingVoucherTablesJoint::~RoutingVoucherTablesJoint()
    {
    }

    const std::string& RoutingVoucherTablesJoint::get_COD_STTU_REG() const
    {
        return m_COD_STTU_REG;
    }
    unsigned long RoutingVoucherTablesJoint::get_NUM_RTDR() const
    {
        return m_NUM_RTDR;
    }
    unsigned long RoutingVoucherTablesJoint::get_COD_SBPD() const
    {
        return m_COD_SBPD;
    }
    unsigned long RoutingVoucherTablesJoint::get_COD_EMSR() const
    {
        return m_COD_EMSR;
    }
    const std::string& RoutingVoucherTablesJoint::get_NOM_EMSR() const
    {
        return m_NOM_EMSR;
    }
    unsigned long RoutingVoucherTablesJoint::get_COD_TRAN_GE() const
    {
        return m_COD_TRAN_GE;
    }
    const std::string& RoutingVoucherTablesJoint::get_NOM_PROD_CPOM() const
    {
        return m_NOM_PROD_CPOM;
    }
    const std::string& RoutingVoucherTablesJoint::get_TXT_RDPE_CPOM() const
    {
        return m_TXT_RDPE_CPOM;
    }
    const std::string& RoutingVoucherTablesJoint::get_COD_USR_ATLZ_REG() const
    {
        return m_COD_USR_ATLZ_REG;
    }
    dbm_datetime_t RoutingVoucherTablesJoint::get_DAT_ATLZ_REG() const
    {
        return m_DAT_ATLZ_REG;
    }
    dbm_datetime_t RoutingVoucherTablesJoint::get_DAT_ATVC_VOCH() const
    {
        return m_DAT_ATVC_VOCH;
    }
    const std::string& RoutingVoucherTablesJoint::get_NTWKID() const
    {
        return m_NTWKID;
    }
    unsigned long RoutingVoucherTablesJoint::get_NUM_BIN() const
    {
        return m_NUM_BIN;
    }

    unsigned long RoutingVoucherTablesJoint::get_COD_ISSR_SW() const
    {
        return m_COD_ISSR_SW;
    }
    const std::string& RoutingVoucherTablesJoint::get_NOM_EMSR_SW( ) const
    {
        return m_NOM_EMSR_SW;
    }
    long RoutingVoucherTablesJoint::get_COD_EMSR_SW( ) const
    {
        return m_COD_EMSR_SW;
    }
    long RoutingVoucherTablesJoint::get_COD_BNDR( ) const
    {
        return m_COD_BNDR;
    }
    long RoutingVoucherTablesJoint::get_COD_FE_EMSR( ) const
    {
        return m_COD_FE_EMSR;
    }

    void RoutingVoucherTablesJoint::bind_columns( )
    {
        bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
        bind( m_NUM_RTDR_pos, m_NUM_RTDR );
        bind( m_COD_SBPD_pos, m_COD_SBPD );
        bind( m_COD_EMSR_pos, m_COD_EMSR );
        bind( m_NOM_EMSR_pos, m_NOM_EMSR );
        bind( m_COD_TRAN_GE_pos, m_COD_TRAN_GE );
        bind( m_NOM_PROD_CPOM_pos, m_NOM_PROD_CPOM );
        bind( m_TXT_RDPE_CPOM_pos, m_TXT_RDPE_CPOM );
        bind( m_COD_USR_ATLZ_REG_pos, m_COD_USR_ATLZ_REG );
        bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
        bind( m_DAT_ATVC_VOCH_pos, &m_DAT_ATVC_VOCH );
        bind( m_NTWKID_pos, m_NTWKID );
        bind( m_NUM_BIN_pos, m_NUM_BIN );
        bind( m_COD_ISSR_SW_pos, m_COD_ISSR_SW );
        bind( m_NOM_EMSR_SW_pos, m_NOM_EMSR_SW );
        bind( m_COD_EMSR_SW_pos, m_COD_EMSR_SW );
        bind( m_COD_BNDR_pos, m_COD_BNDR );
        bind( m_COD_FE_EMSR_pos, m_COD_FE_EMSR );
    }
}//namespace dbaccess_pdv
