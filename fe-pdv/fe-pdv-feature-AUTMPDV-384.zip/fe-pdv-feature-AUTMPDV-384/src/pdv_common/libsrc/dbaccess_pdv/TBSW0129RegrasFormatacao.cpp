#include <dbaccess_pdv/TBSW0129RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    TBSW0129RegrasFormatacao::TBSW0129RegrasFormatacao( )
    {
    }

    TBSW0129RegrasFormatacao::~TBSW0129RegrasFormatacao( )
    {
    }
}