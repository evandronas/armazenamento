#include <dbaccess_pdv/TBSW0121RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    TBSW0121RegrasFormatacao::TBSW0121RegrasFormatacao( )
    {
    }

    TBSW0121RegrasFormatacao::~TBSW0121RegrasFormatacao( )
    {
    }

    void TBSW0121RegrasFormatacao::insert_COD_MODL_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
    {
        tbsw0121.set_COD_MODL_PNPD( std::string( " " ) );
    }
    
    void TBSW0121RegrasFormatacao::insert_COD_VERS_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params )
    {
        if( params.cod_vers_sftw.size( ) != 0 )
        {
            tbsw0121.set_COD_VERS_CHCK_PDV( params.cod_vers_sftw.substr( 0, 9 ) );
        }
        else
        {
            tbsw0121.set_COD_VERS_CHCK_PDV( std::string( " " ) );
            WARNING_EMPTY_STRING;
        }
    }
}