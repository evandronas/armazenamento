#include<dbaccess_pdv/TBSW0034RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
	TBSW0034RegrasFormatacao::TBSW0034RegrasFormatacao( )
	{
	}

	TBSW0034RegrasFormatacao::~TBSW0034RegrasFormatacao( )
	{
	}
}
