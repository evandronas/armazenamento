#include "dbaccess_pdv/RoutingTablesJoint.hpp"

namespace dbaccess_pdv
{
	RoutingTablesJoint::RoutingTablesJoint()
	{
		query_fields = 
			" TB_ROTA.COD_ROTA, TB_ROTA.NUM_BIN_CAR_INI, TB_ROTA.NUM_BIN_CAR_FIM, "
			"TB_ROTA.COD_ISSR_SW, TB_ROTA.COD_TIP_TRAN, TB_ROTA.IND_PRRD, TB_ROTA.NETWORK_ID, "
			"TB_ROTA.NOM_HOST_ACQR, TB_ROTA.NOM_FE_ACQR, "
			"TB_EMSR.NOM_EMSR_SW, TB_EMSR.COD_EMSR_SW, TB_EMSR.COD_BNDR, TB_EMSR.COD_FE_EMSR, TB_ROTA.NETWORK_ID_VAN "
		;
		table_name = "TBSW2010 TB_ROTA, TBSW2011 TB_EMSR";
		where_condition = " TB_ROTA.COD_ISSR_SW=TB_EMSR.COD_ISSR_SW ";

		m_COD_ROTA_pos = 1;
		m_NUM_BIN_CAR_INI_pos = 2;
		m_NUM_BIN_CAR_FIM_pos = 3;
		m_COD_ISSR_SW_pos = 4;
		m_COD_TIP_TRAN_pos = 5;
		m_IND_PRRD_pos = 6;
		m_NETWORK_ID_pos = 7;
		m_NOM_HOST_ACQR_pos = 8;
		m_NOM_FE_ACQR_pos = 9;
		m_NOM_EMSR_SW_pos = 10;
		m_COD_EMSR_SW_pos = 11;
		m_COD_BNDR_pos = 12;
		m_COD_FE_EMSR_pos = 13;
		m_NETWORK_ID_VAN_pos = 14;
		
		m_COD_ROTA = 0;
		m_NUM_BIN_CAR_INI = "";
		m_NUM_BIN_CAR_FIM = "";
		m_COD_ISSR_SW = 0;
		m_COD_TIP_TRAN = "";
		m_IND_PRRD = 0;
		m_NETWORK_ID = "";
		m_NOM_HOST_ACQR = "";
		m_NOM_FE_ACQR = "";
		m_NOM_EMSR_SW = "";
		m_COD_EMSR_SW = 0;
		m_COD_BNDR = 0;
		m_COD_FE_EMSR = 0;
		m_NETWORK_ID_VAN = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	RoutingTablesJoint::RoutingTablesJoint( const std::string &str )
	{
		query_fields = 
			" TB_ROTA.COD_ROTA, TB_ROTA.NUM_BIN_CAR_INI, TB_ROTA.NUM_BIN_CAR_FIM, "
			"TB_ROTA.COD_ISSR_SW, TB_ROTA.COD_TIP_TRAN, TB_ROTA.IND_PRRD, TB_ROTA.NETWORK_ID, "
			"TB_ROTA.NOM_HOST_ACQR, TB_ROTA.NOM_FE_ACQR, "
			"TB_EMSR.NOM_EMSR_SW, TB_EMSR.COD_EMSR_SW, TB_EMSR.COD_BNDR, TB_EMSR.COD_FE_EMSR, TB_ROTA.NETWORK_ID_VAN  "
		;
		
		table_name = "TBSW2010 TB_ROTA, TBSW2011 TB_EMSR";
		where_condition = " TB_ROTA.COD_ISSR_SW=TB_EMSR.COD_ISSR_SW AND ( " + str + " )";

		m_COD_ROTA_pos = 1;
		m_NUM_BIN_CAR_INI_pos = 2;
		m_NUM_BIN_CAR_FIM_pos = 3;
		m_COD_ISSR_SW_pos = 4;
		m_COD_TIP_TRAN_pos = 5;
		m_IND_PRRD_pos = 6;
		m_NETWORK_ID_pos = 7;
		m_NOM_HOST_ACQR_pos = 8;
		m_NOM_FE_ACQR_pos = 9;
		m_NOM_EMSR_SW_pos = 10;
		m_COD_EMSR_SW_pos = 11;
		m_COD_BNDR_pos = 12;
		m_COD_FE_EMSR_pos = 13;
		m_NETWORK_ID_VAN_pos = 14;

		m_COD_ROTA = 0;
		m_NUM_BIN_CAR_INI = "";
		m_NUM_BIN_CAR_FIM = "";
		m_COD_ISSR_SW = 0;
		m_COD_TIP_TRAN = "";
		m_IND_PRRD = 0;
		m_NETWORK_ID = "";
		m_NOM_HOST_ACQR = "";
		m_NOM_FE_ACQR = "";
		m_NOM_EMSR_SW = "";
		m_COD_EMSR_SW = 0;
		m_COD_BNDR = 0;
		m_COD_FE_EMSR = 0;
		m_NETWORK_ID_VAN = "";

		update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	RoutingTablesJoint::~RoutingTablesJoint()
	{
	}
	const std::string& RoutingTablesJoint::getNOM_EMSR_SW( ) const
	{
		return m_NOM_EMSR_SW;
	}
	long RoutingTablesJoint::getCOD_EMSR_SW( ) const
	{
		return m_COD_EMSR_SW;
	}
	long RoutingTablesJoint::getCOD_BNDR( ) const
	{
		return m_COD_BNDR;
	}
	long RoutingTablesJoint::getCOD_FE_EMSR( ) const
	{
		return m_COD_FE_EMSR;
	}
	const std::string& RoutingTablesJoint::getNETWORK_ID( ) const
	{
		return m_NETWORK_ID;
	}
    const std::string& RoutingTablesJoint::getNETWORK_ID_VAN( ) const
    {
        return m_NETWORK_ID_VAN;
    }
	const std::string& RoutingTablesJoint::getNOM_HOST_ACQR( ) const
	{
		return m_NOM_HOST_ACQR;
	}
	const std::string& RoutingTablesJoint::getNOM_FE_ACQR( ) const
	{
		return m_NOM_FE_ACQR;
	}

	long RoutingTablesJoint::getCOD_ROTA( ) const {
		return m_COD_ROTA;
	}	
	const std::string& RoutingTablesJoint::getNUM_BIN_CAR_INI( ) const {
		return m_NUM_BIN_CAR_INI;
	}
	const std::string& RoutingTablesJoint::getNUM_BIN_CAR_FIM( ) const {
		return m_NUM_BIN_CAR_FIM;
	}
	long RoutingTablesJoint::getCOD_ISSR_SW( ) const {
		return m_COD_ISSR_SW;
	}
	const std::string& RoutingTablesJoint::getCOD_TIP_TRAN( ) const {
		return m_COD_TIP_TRAN;
	}
	long RoutingTablesJoint::getIND_PRRD( ) const {
		return m_IND_PRRD;
	}
	
	void RoutingTablesJoint::bind_columns( )
	{		
		bind( m_COD_ROTA_pos, m_COD_ROTA );
		bind( m_NUM_BIN_CAR_INI_pos, m_NUM_BIN_CAR_INI );
		bind( m_NUM_BIN_CAR_FIM_pos, m_NUM_BIN_CAR_FIM );
		bind( m_COD_ISSR_SW_pos, m_COD_ISSR_SW );
		bind( m_COD_TIP_TRAN_pos, m_COD_TIP_TRAN );
		bind( m_IND_PRRD_pos, m_IND_PRRD );
		bind( m_NETWORK_ID_pos, m_NETWORK_ID );
		bind( m_NOM_HOST_ACQR_pos, m_NOM_HOST_ACQR );
		bind( m_NOM_FE_ACQR_pos, m_NOM_FE_ACQR );
		bind( m_NOM_EMSR_SW_pos, m_NOM_EMSR_SW );
		bind( m_COD_EMSR_SW_pos, m_COD_EMSR_SW );
		bind( m_COD_BNDR_pos, m_COD_BNDR );
		bind( m_COD_FE_EMSR_pos, m_COD_FE_EMSR );
		bind( m_NETWORK_ID_VAN_pos, m_NETWORK_ID_VAN );
	}
}//namespace dbaccess_pdv
