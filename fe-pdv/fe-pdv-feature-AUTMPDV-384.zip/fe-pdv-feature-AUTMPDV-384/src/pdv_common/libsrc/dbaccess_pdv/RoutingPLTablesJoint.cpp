#include "dbaccess_pdv/RoutingPLTablesJoint.hpp"

namespace dbaccess_pdv
{
	RoutingPLTablesJoint::RoutingPLTablesJoint()
	{
		query_fields = 
            " TB_ROTA.NUM_PDV, TB_ROTA.NUM_BIN_INI, TB_ROTA.NUM_BIN_FIM, TB_ROTA.COD_EMSR, TB_ROTA.COD_STTU_TRAN, "
            "TB_ROTA.DAT_ATLZ_REG, TB_ROTA.COD_USR_ATLZ_REG, TB_ROTA.IND_STTU_REG, TB_EMSR.COD_ISSR_SW, "
            "TB_EMSR.NOM_EMSR_SW, TB_EMSR.COD_EMSR_SW, TB_EMSR.COD_BNDR, TB_EMSR.COD_FE_EMSR, "
            "TB_ISSR.COD_ROTA_PRVT_LBEL, TB_ISSR.NETWORK_ID, TB_ISSR.NOM_FE_ACQR, TB_ISSR.NOM_HOST_ACQR "
		;
		table_name = "TBSW0044 TB_ROTA, TBSW2011 TB_EMSR, TBSW2013 TB_ISSR";
		where_condition = " TB_ROTA.COD_EMSR = TB_EMSR.COD_ISSR_SW AND "
                          " TB_EMSR.COD_ISSR_SW = TB_ISSR.COD_ISSR_SW";
        
        // TBSW0044
        m_NUM_PDV_pos = 1;
        m_NUM_BIN_INI_pos = 2;
        m_NUM_BIN_FIM_pos = 3;
        m_COD_EMSR_pos = 4;
        m_COD_STTU_TRAN_pos = 5;
        m_DAT_ATLZ_REG_pos = 6;
        m_COD_USR_ATLZ_REG_pos = 7;
        m_IND_STTU_REG_pos = 8;
        // TBSW2011
        m_COD_ISSR_SW_pos = 9;
        m_NOM_EMSR_SW_pos = 10;
        m_COD_EMSR_SW_pos = 11;
        m_COD_BNDR_pos = 12;
        m_COD_FE_EMSR_pos = 13;
        // TBSW2013
        m_COD_ROTA_PRVT_LBEL_pos = 14;
        m_NETWORK_ID_pos = 15;
        m_NOM_FE_ACQR_pos = 16;
        m_NOM_HOST_ACQR_pos = 17;

        // TBSW0044
        m_NUM_PDV = 0;
        dbm_longtodec( &m_NUM_BIN_INI, 0 );
        dbm_longtodec( &m_NUM_BIN_FIM, 0 );
        m_COD_EMSR = 0;
        m_COD_STTU_TRAN = " ";
        m_DAT_ATLZ_REG = 0;
        m_COD_USR_ATLZ_REG = " ";
        m_IND_STTU_REG = " ";
        // TBSW2011
        m_COD_ISSR_SW = 0;
        m_NOM_EMSR_SW = " ";
        m_COD_EMSR_SW = 0;
        m_COD_BNDR = 0;
        m_COD_FE_EMSR = 0;
        // TBSW2013
        m_COD_ROTA_PRVT_LBEL = 0;
        m_NETWORK_ID = " ";
        m_NOM_FE_ACQR = " ";
        m_NOM_HOST_ACQR = " ";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	RoutingPLTablesJoint::RoutingPLTablesJoint( const std::string &str )
	{
		query_fields = 
            " TB_ROTA.NUM_PDV, TB_ROTA.NUM_BIN_INI, TB_ROTA.NUM_BIN_FIM, TB_ROTA.COD_EMSR, TB_ROTA.COD_STTU_TRAN, "
            "TB_ROTA.DAT_ATLZ_REG, TB_ROTA.COD_USR_ATLZ_REG, TB_ROTA.IND_STTU_REG, TB_EMSR.COD_ISSR_SW, "
            "TB_EMSR.NOM_EMSR_SW, TB_EMSR.COD_EMSR_SW, TB_EMSR.COD_BNDR, TB_EMSR.COD_FE_EMSR, "
            "TB_ISSR.COD_ROTA_PRVT_LBEL, TB_ISSR.NETWORK_ID, TB_ISSR.NOM_FE_ACQR, TB_ISSR.NOM_HOST_ACQR "
		;
		table_name = "TBSW0044 TB_ROTA, TBSW2011 TB_EMSR, TBSW2013 TB_ISSR";
		where_condition = " TB_ROTA.COD_EMSR = TB_EMSR.COD_ISSR_SW AND "
                          " TB_EMSR.COD_ISSR_SW = TB_ISSR.COD_ISSR_SW AND ( " + str + " )";

        // TBSW0044
        m_NUM_PDV_pos = 1;
        m_NUM_BIN_INI_pos = 2;
        m_NUM_BIN_FIM_pos = 3;
        m_COD_EMSR_pos = 4;
        m_COD_STTU_TRAN_pos = 5;
        m_DAT_ATLZ_REG_pos = 6;
        m_COD_USR_ATLZ_REG_pos = 7;
        m_IND_STTU_REG_pos = 8;
        // TBSW2011
        m_COD_ISSR_SW_pos = 9;
        m_NOM_EMSR_SW_pos = 10;
        m_COD_EMSR_SW_pos = 11;
        m_COD_BNDR_pos = 12;
        m_COD_FE_EMSR_pos = 13;
        // TBSW2013
        m_COD_ROTA_PRVT_LBEL_pos = 14;
        m_NETWORK_ID_pos = 15;
        m_NOM_FE_ACQR_pos = 16;
        m_NOM_HOST_ACQR_pos = 17;

        // TBSW0044
        m_NUM_PDV = 0;
        dbm_longtodec( &m_NUM_BIN_INI, 0 );
        dbm_longtodec( &m_NUM_BIN_FIM, 0 );
        m_COD_EMSR = 0;
        m_COD_STTU_TRAN = " ";
        m_DAT_ATLZ_REG = 0;
        m_COD_USR_ATLZ_REG = " ";
        m_IND_STTU_REG = " ";
        // TBSW2011
        m_COD_ISSR_SW = 0;
        m_NOM_EMSR_SW = " ";
        m_COD_EMSR_SW = 0;
        m_COD_BNDR = 0;
        m_COD_FE_EMSR = 0;
        // TBSW2013
        m_COD_ROTA_PRVT_LBEL = 0;
        m_NETWORK_ID = " ";
        m_NOM_FE_ACQR = " ";
        m_NOM_HOST_ACQR = " ";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	RoutingPLTablesJoint::~RoutingPLTablesJoint()
	{
	}

    // TBSW0044
    unsigned long RoutingPLTablesJoint::get_NUM_PDV() const
    {
        return m_NUM_PDV;
    }
    oasis_dec_t RoutingPLTablesJoint::get_NUM_BIN_INI() const
    {
        return m_NUM_BIN_INI;
    }
    oasis_dec_t RoutingPLTablesJoint::get_NUM_BIN_FIM() const
    {
        return m_NUM_BIN_FIM;
    }
    unsigned long RoutingPLTablesJoint::get_COD_EMSR() const
    {
        return m_COD_EMSR;
    }
    const std::string& RoutingPLTablesJoint::get_COD_STTU_TRAN() const
    {
        return m_COD_STTU_TRAN;
    }
    dbm_datetime_t RoutingPLTablesJoint::get_DAT_ATLZ_REG() const
    {
        return m_DAT_ATLZ_REG;
    }
    const std::string& RoutingPLTablesJoint::get_COD_USR_ATLZ_REG() const
    {
        return m_COD_USR_ATLZ_REG;
    }
    const std::string& RoutingPLTablesJoint::get_IND_STTU_REG() const
    {
        return m_IND_STTU_REG;
    }
    // TBSW2011
    unsigned long RoutingPLTablesJoint::get_COD_ISSR_SW() const
    {
        return m_COD_ISSR_SW;
    }
    const std::string& RoutingPLTablesJoint::get_NOM_EMSR_SW() const
    {
        return m_NOM_EMSR_SW;
    }
    unsigned long RoutingPLTablesJoint::get_COD_EMSR_SW() const
    {
        return m_COD_EMSR_SW;
    }
    unsigned long RoutingPLTablesJoint::get_COD_BNDR() const
    {
        return m_COD_BNDR;
    }
    unsigned long RoutingPLTablesJoint::get_COD_FE_EMSR() const
    {
        return m_COD_FE_EMSR;
    }
    // TBSW2013
    unsigned long RoutingPLTablesJoint::get_COD_ROTA_PRVT_LBEL() const
    {
        return m_COD_ROTA_PRVT_LBEL;
    }
    const std::string& RoutingPLTablesJoint::get_NETWORK_ID() const
    {
        return m_NETWORK_ID;
    }
    const std::string& RoutingPLTablesJoint::get_NOM_FE_ACQR() const
    {
        return m_NOM_FE_ACQR;
    }
    const std::string& RoutingPLTablesJoint::get_NOM_HOST_ACQR() const
    {
        return m_NOM_HOST_ACQR;
    }

   
	void RoutingPLTablesJoint::bind_columns( )
	{		
        // TBSW0044
        bind( m_NUM_PDV_pos, m_NUM_PDV );
        bind( m_NUM_BIN_INI_pos, m_NUM_BIN_INI );
        bind( m_NUM_BIN_FIM_pos, m_NUM_BIN_FIM );
        bind( m_COD_EMSR_pos, m_COD_EMSR );
        bind( m_COD_STTU_TRAN_pos, m_COD_STTU_TRAN );
        bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
        bind( m_COD_USR_ATLZ_REG_pos, m_COD_USR_ATLZ_REG );
        bind( m_IND_STTU_REG_pos, m_IND_STTU_REG );
        // TBSW2011
        bind( m_COD_ISSR_SW_pos, m_COD_ISSR_SW );
        bind( m_NOM_EMSR_SW_pos, m_NOM_EMSR_SW );
        bind( m_COD_EMSR_SW_pos, m_COD_EMSR_SW );
        bind( m_COD_BNDR_pos, m_COD_BNDR );
        bind( m_COD_FE_EMSR_pos, m_COD_FE_EMSR );
        // TBSW2013
        bind( m_COD_ROTA_PRVT_LBEL_pos, m_COD_ROTA_PRVT_LBEL );
        bind( m_COD_ISSR_SW_pos, m_COD_ISSR_SW );
        bind( m_NETWORK_ID_pos, m_NETWORK_ID );
        bind( m_NOM_FE_ACQR_pos, m_NOM_FE_ACQR );
        bind( m_NOM_HOST_ACQR_pos, m_NOM_HOST_ACQR );
	}
}//namespace dbaccess_pdv
