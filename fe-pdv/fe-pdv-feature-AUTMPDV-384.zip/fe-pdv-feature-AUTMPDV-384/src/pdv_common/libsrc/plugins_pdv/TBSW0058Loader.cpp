/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0058Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0058Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, CKen>
/ Data de Cria��o: <Thu Oct 18 19:28:59 2012>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ 2013, 26 de Marco, t698224, Raphael Gomes/ t694450, Lauro Sanches, Tratamento de contigencia
/ <22.09.2013, FEPOS, t694449, Fernando Ramires, Merge do PDV para o POS>
/ <11.11.2013, FEPOS, t694449, Fernando Ramires, GAP3 Adicionado campo novo>
/ ---------------------------------------------------------------------------

Copyright 2018 REDE
*********************** MODIFICA??ES ************************
Autor     : Gustavo Silva Franco
Data      : 25/07/2019
Empresa   : Rede
Descri??o : Adaptando comportamento de pr? de acordo com o do POS 7.5, pois o do PDV estava incompleto
ID        : EAK 1649
*************************************************************
Autor     : Renato de Camargo
Data      : 12/09/2019
Empresa   : Rede
Descri??o : Acerto na querie de Estorno de Confirmacao de Pre
ID        : EAK 1762
*************************************************************
*/



#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0058.hpp"
#include "plugins_pdv/TBSW0058Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
//TODOSW75 #include "dualHandler.hpp"

// Release Bandeiras PDV - Abril 2019
using namespace std;

namespace plugins_pdv
{
    base::Identificable* createTBSW0058Loader( )
    {
        TBSW0058Loader* l_new = new TBSW0058Loader;
        return( l_new );
    }
    
    bool TBSW0058Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
        
        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );
        
        return( true );
    }
    
    TBSW0058Loader::TBSW0058Loader( )
    {
    }
    
    TBSW0058Loader::~TBSW0058Loader( )
    {
    }
    
    bool TBSW0058Loader::init( )
    {
        std::string tb_components[ ] = 
        {
            "RESULT", 
            "DAT_MOV_TRAN", 
            "NUM_SEQ_UNC", 
            "TIP_TRAN", 
            "NUM_MOT_RSPS", 
            "NUM_ESTB", 
            "COD_TERM", 
            "NUM_RD_ORG", 
            "COD_POS_ENTR_MODO", 
            "COD_EMSR", 
            "VAL_TRAN", 
            "COD_RAM_ATVD", 
            "NUM_CAR", 
            "NUM_AUT", 
            "VAL_COT_DLR", 
            "DAT_VLD_CAR", 
            "COD_TRK_CAR", 
            "COD_MOED", 
            "COD_PAIS_CAR", 
            "COD_SERV_SNHA", 
            "IND_RD_ORG", 
            "COD_MOT_AUT", 
            "DAT_PAUZ", 
            "COD_GRU_ESTB", 
            "COD_MTZ_ESTB", 
            "DTH_INI_TRAN", 
            "DTH_STTU_TRAN", 
            "DTH_GMT", 
            "NUM_STAN", 
            "VAL_EFTV_CPTR", 
            "QTD_PRCL_CNFR", 
            "IND_RD_CPTR", 
            "COD_CNDC_CPTR", 
            "DAT_CNFR_PAUZ", 
            "VAL_TRAN_DLR", 
            "DAT_CAN_PAUZ", 
            "DAT_VLD_PAUZ", 
            "NOM_PORT_CAR", 
            "COD_MSG_ISO", 
            "COD_PCM_ISO", 
            "NOM_SITE_ACQR_ORGL", 
            "NOM_HOST_ACQR_ORGL", 
            "NOM_FE_ACQR_ORGL", 
            "NOM_SITE_ISSR", 
            "NOM_HOST_ISSR", 
            "NOM_FE_ISSR", 
            "NOM_SITE_ACQR_ATLZ", 
            "NOM_HOST_ACQR_ATLZ", 
            "NOM_FE_ACQR_ATLZ", 
            "COD_MOT_ISO_EMSR", 
            "COD_TERM_CNFR", 
            "DAT_MOV_TRAN_CNFR", 
            "DTH_CNFR", 
            "IND_RD_ORG_ESTR", 
            "IND_STTU_TRAN", 
            "NUM_EMSR", 
            "NUM_ESTB_CNFR", 
            "NUM_ESTB_ESTR", 
            "NUM_ID_CAR", 
            "NUM_SEQ_UNC_CNFR", 
            "NUM_STAN_ORGL", 
            "COD_BNDR", 
            "IND_EMSR_MTC",
            "NUM_AVSO_AUT",
            "TXT_DA_ADIC_EMSR",
            "NOM_FNTS_PDV",
            "COD_PGM_AUT",
            "IND_NVL_SGRA_KMRC",
            "COD_UCAF",
            "COD_AUT_EMSR_CNVT",
            "COD_AUT_EMSR",
            "NTWK_ID_ACQR_ATLZ",
            "NTWK_ID_ACQR_ORGL",
            "NTWK_ID_ROUTE_ATLZ",
            "NTWK_ID_ROUTE_ORGL",
            "NTWK_ID_ISSR_ATLZ",
            "NTWK_ID_ISSR_ORGL",
            "COD_CTAH_VOCH",
            "COD_TIP_PROD_CAR",
            "NUM_REF_TRAN",
            "COD_CPCD_TERM",
            "IND_TRAN_TKN",
            "COD_ORG_APRV",
            "COD_PROD_MTC", 
            "COD_RGAO_MTC"
            // Release Bandeiras PDV - Abril 2019 - INICIO
            ,"COD_PORT_PRES_VLDC_BNDR"
            ,"COD_CPCD_TERM_VLDC_BNDR"
            , "ID_REF_BNDR"
            // Release Bandeiras PDV - Abril 2019 - FIM
        };
        for ( unsigned int i = 0; i < LAST_TB_FIELD; i++ )
        {
            m_targetField[ i ] = this->navigate( m_targetFieldPath + "." + tb_components[ i ] );
            if ( !m_targetField[ i ] )
            {
                std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return( false );
            }
        }
     
        std::string source_components[ ] =
        {
            "local_date",
            "local_time",
            "refnum",
            "msgtype",
            "pan",
            "acq_currency_code",
            "authnum",
            "amount",
            "termloc",
            "origdate",
            "origtime",
            "origtrace",
            "trandate",
            "trantime",
            "origrefnum",
            "orig_authnum",
            "orig_pan",
            "is_3a_perna",
			"cod_mtz_estb",
			"is_desf_conf",
			"transcode",
			"num_seq_unc_pauz",
			"dat_mov_tran_pauz",
			"msg_name",
            "install_num",
            "versao_aplicativo",
            "cod_term"
        };

        for ( unsigned int i = 0; i < LAST_SOURCE_FIELD; i++ )
        {
            m_sourceField[ i ] = this->navigate( m_sourceFieldPath + "." + source_components[ i ] );
            if ( !m_sourceField[ i ] )
            {
                std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + "." + source_components[ i ] + ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return( false );
            }
        }
        
        return( true );
    }
    
    void TBSW0058Loader::finish( )
    {
    }
    
    int TBSW0058Loader::execute( bool& a_stop )
    {
        std::ostringstream l_whereClause;
      
        try
        {            
            unsigned long l_local_date;
            unsigned long l_local_time;
            unsigned long l_refnum;
            unsigned long l_msgtype;
            unsigned long l_origdate;
            unsigned long l_origtime;
            unsigned long l_trandate;
            unsigned long l_trantime;
            unsigned long l_valid_pre_auz;
            unsigned long l_origrefnum;
            unsigned long l_origtrace;
            unsigned long l_termloc;
            unsigned long l_cod_mtz_estb;
            unsigned long l_transcode;
			unsigned long l_num_seq_unc_pauz;
            char l_szDtHrAux[ 128 ];
            std::string cod_term;
            std::string l_pan;
            std::string l_origpan;
            std::string l_amount;
            std::string l_currency;
            std::string l_authnum;
            std::string l_origauthnum;
            std::string l_is_3a_perna;
			std::string l_is_desf_conf;
            std::string l_install_num;
            std::string l_versao_aplicativo;
            std::string l_msg_name;
            oasis_dec_t l_dec_amount;
            dbm_datetime_t l_dth_vld_pauz_unix;
            dbm_datetime_t l_dth_cnfr_pauz_unix;
            dbm_datetime_t l_dth_can_pauz_unix;
            
            fieldSet::fsextr( l_local_date,     m_sourceField[ LOCAL_DATE ] );
            fieldSet::fsextr( l_local_time,     m_sourceField[ LOCAL_TIME ] );
            fieldSet::fsextr( l_origrefnum,     m_sourceField[ REFNUM ] );
            fieldSet::fsextr( l_msgtype,        m_sourceField[ MSGTYPE ] );
            fieldSet::fsextr( l_pan,            m_sourceField[ PAN ] );
            fieldSet::fsextr( l_currency,       m_sourceField[ ACQ_CURRENCY_CODE ] );
            fieldSet::fsextr( l_authnum,        m_sourceField[ AUTHNUM ] );
            fieldSet::fsextr( l_amount,         m_sourceField[ AMOUNT ] );
            dbm_chartodec( &l_dec_amount,       l_amount.c_str( ), 0 );
            fieldSet::fsextr( l_termloc,        m_sourceField[ TERMLOC ] );
            fieldSet::fsextr( l_origdate,       m_sourceField[ ORIGDATE ] );
            fieldSet::fsextr( l_origtime,       m_sourceField[ ORIGTIME ] );
            fieldSet::fsextr( l_origtrace,      m_sourceField[ ORIGTRACE ] );
            fieldSet::fsextr( l_trandate,       m_sourceField[ TRANDATE ] );
            fieldSet::fsextr( l_trantime,       m_sourceField[ TRANTIME ] );
            fieldSet::fsextr( l_origrefnum,     m_sourceField[ ORIGREFNUM ] );
            fieldSet::fsextr( l_origauthnum,    m_sourceField[ ORIG_AUTHNUM ] );
            fieldSet::fsextr( l_origpan,        m_sourceField[ ORIG_PAN ] );
            fieldSet::fsextr( l_is_3a_perna,    m_sourceField[ IS_3A_PERNA ] );
            fieldSet::fsextr( l_cod_mtz_estb,   m_sourceField[ COD_MTZ ] );
			fieldSet::fsextr( l_is_desf_conf,    m_sourceField[ IS_DESF_CONF ] );
            fieldSet::fsextr( l_transcode,       m_sourceField[ TRANSCODE ] );
            fieldSet::fsextr( l_msg_name,       m_sourceField[ MSG_NAME ] );
            fieldSet::fsextr( l_install_num,       m_sourceField[ INSTALL_NUM ] );
            fieldSet::fsextr( l_versao_aplicativo,       m_sourceField[ VERSAO_APLICATIVO ] );    
            fieldSet::fsextr( l_num_seq_unc_pauz, m_sourceField[ NUM_SEQ_UNC_PAUZ ] );
            fieldSet::fsextr( cod_term,         m_sourceField[ COD_TERMN ] );

            if ( !l_is_3a_perna.compare( "Y" ))
            {
                l_whereClause << "DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
            }
            else
            {
                size_t l_pos = l_origpan.find_first_of("=DF^");                
                if( l_pos != std::string::npos )
                {
                    l_origpan.erase( l_pos, std::string::npos );
                }
                switch ( l_msgtype )
                {
                    case 120 :                        
                        l_whereClause << " NUM_CAR = '" << l_origpan << "'" <<
                                         " AND NUM_AUT = '" << l_origauthnum << "'" <<
                                         " AND VAL_TRAN <= " << l_amount <<
                                         " AND TO_CHAR(DAT_PAUZ,'YYYYMMDD') = '" << l_origdate << "'";
                        
                        break;
                    case 220 :
                        if ( l_origdate > 0 && l_origrefnum > 0 )
                        {
                            l_whereClause << " DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
                        }
                        else
                        {
                            if( l_install_num.empty() )
                            {
                                l_install_num = "0";
                            }
                            
                            l_whereClause << " IND_STTU_TRAN = '0' AND NUM_CAR = '" << l_origpan << "'" <<
                                            " AND DAT_VLD_PAUZ > LOCALTIMESTAMP AND VAL_TRAN >= " << l_amount;
                                            
                                            
                            // Workaround - PVS da LOCALIZA devem aceitar confirmar parcelada , mesmo a original sendo avista
                            if ( l_versao_aplicativo >= "601" && l_cod_mtz_estb != 9565060 && l_cod_mtz_estb != 610126644 && l_termloc != 9565060 && l_termloc != 610126644  )
                            {
                                l_whereClause << " AND QTD_PRCL_CNFR = " << l_install_num;                  
                            }
                            
                            // Adicionanto Cl?usula de Estabelecimento e Matriz
                            if (l_cod_mtz_estb == 0 )
                            {
                                // Caso N?O Exista Matriz
                                l_whereClause << " AND ( NUM_ESTB = " << l_termloc <<
                                                        " OR COD_MTZ_ESTB = " << l_termloc <<  " ) ";
                            }
                            else
                            {
                                // Caso Exista Matriz
                                l_whereClause << " AND ( NUM_ESTB = " << l_termloc << " OR NUM_ESTB = " << l_cod_mtz_estb <<
                                                        " OR COD_MTZ_ESTB = " << l_termloc <<
                                                        " OR ( COD_MTZ_ESTB != 0 AND COD_MTZ_ESTB = " << l_cod_mtz_estb << " ) ) ";
                            }

                            l_whereClause << " ORDER BY ABS( 1 - " << ::atof( l_amount.c_str() ) << "/VAL_TRAN ), DAT_MOV_TRAN ";
                        }
                        break;

                    case 400 :
                            // Neste caso, se esta aqui eh porque ja achou a confirmacao, e ja tem o nsu e data da pre-auth
                            if ( l_msg_name == "EST_CONF_PREAUT_GEN" ||  l_msg_name == "EST_CONF_PREAUT" ||  l_msg_name == "EST_CONF_PREAUT_PARC_SJURO" )
                            {
                                l_whereClause << " DAT_MOV_TRAN = " << l_origdate 
                                << " AND NUM_SEQ_UNC = " << l_num_seq_unc_pauz;
                            }
                            else 
                            {
                                l_whereClause << "IND_STTU_TRAN IN ('0', '4', '9', 'A') AND NUM_CAR = '" << l_origpan << "'" 
                                              << " AND DAT_VLD_PAUZ > LOCALTIMESTAMP " 
                                              << " AND VAL_TRAN >= " << l_amount;

                                // Usando dados do DE90 se estiverem presentes
                                if ( l_origdate > 0 )
                                {
                                    l_whereClause << " AND DAT_MOV_TRAN = " << l_origdate;
                                }

                                if ( l_origtrace > 0 )
                                {
                                    l_whereClause << " AND NUM_STAN = " << l_origtrace ;
                                }
                                
                                // Adicionanto Clausula de Estabelecimento e Matriz
                                if (l_cod_mtz_estb == 0 )
                                {
                                    // Caso Nao Exista Matriz
                                    l_whereClause << " AND ( NUM_ESTB = " << l_termloc <<
                                                            " OR COD_MTZ_ESTB = " << l_termloc <<  " ) ";
                                }   
                                else
                                {
                                    // Caso Exista Matriz
                                    l_whereClause << " AND ( NUM_ESTB = " << l_termloc << " OR NUM_ESTB = " << l_cod_mtz_estb <<
                                                            " OR COD_MTZ_ESTB = " << l_termloc <<
                                                            " OR ( COD_MTZ_ESTB != 0 AND COD_MTZ_ESTB = " << l_cod_mtz_estb << " ) ) ";
                                }

                                l_whereClause << " ORDER BY ABS( 1 - " << ::atof( l_amount.c_str() ) << "/VAL_TRAN ), DAT_MOV_TRAN ";
                            }

                            break;
                            
                    case 420 :
                        // Neste caso, se esta aqui eh porque ja achou a confirmacao, e ja tem o nsu e data da pre-auth
						if ( l_msg_name == "DESF_CONF_PREAUT_GEN" )
						{
                            l_whereClause << " DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
						}
						else
						{
							l_whereClause << " DAT_MOV_TRAN=" << l_origdate
										  << " AND COD_TERM='" << cod_term << "'"
										  << " AND NUM_STAN = " << l_origtrace
                                          << " AND IND_STTU_TRAN IN ('0', '9', 'A')";
                        }
                        break;
                    default:
                        this->setResult( "EMPTY QUERY" );
                        fieldSet::fscopy( m_targetField[ 0 ], this->getResult( ) );
                        a_stop = false;
                        return( 0 );
                        break;
                }
            }

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0058 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );
            dbaccess_common::TBSW0058 l_TBSW0058( l_whereClause.str( ) );
            
            l_TBSW0058.prepare( );
            l_TBSW0058.execute( );
            //TODOSW75 
            /***
            dbaccess_common::DualHandler l_dualHand( &l_TBSW0058 );
            int ret = l_dualHand.fetch( );
            ***/
            int ret = l_TBSW0058.fetch( );
            if ( !ret )
            {
                // TRATAMENTO PARA TRAVA104 - INICIO
                // Quando a pre-aut original nao foi encontrada, eh necessario verificar se o motivo
                // eh a "Data de Validade da Pre-Autorizacao", para depois poder nega-la na TRAVA104
                if ( ( l_msgtype == 220 ) &&
                     ( l_origdate <= 0 || l_origrefnum <= 0 ) )
                {
                    std::ostringstream l_whereClause_TRAP104;                                        
                    
                    if( l_install_num.empty() )
                    {
                        l_install_num = "0";
                    }
                    
                    // Workaround - PVS da LOCALIZA devem aceitar confirmar parcelada , mesmo a original sendo avista
                    if(l_versao_aplicativo>="601" && l_cod_mtz_estb != 9565060 && l_cod_mtz_estb != 610126644 && l_termloc != 9565060 && l_termloc != 610126644 )
                    {
                        l_whereClause_TRAP104 << " IND_STTU_TRAN = '0' AND NUM_CAR = '" << l_origpan << "'" <<
                                         " AND VAL_TRAN >= " << l_amount << 
                                         " AND ( NUM_ESTB = " << l_termloc << " OR NUM_ESTB = " << l_cod_mtz_estb <<
                                               " OR COD_MTZ_ESTB = " << l_termloc << 
                                               " OR ( COD_MTZ_ESTB != 0 AND COD_MTZ_ESTB = " << l_cod_mtz_estb << " ) " <<
                                         " ) AND QTD_PRCL_CNFR = " << l_install_num << 
                                         " ORDER BY ABS( 1 - " << ::atof( l_amount.c_str() ) << "/VAL_TRAN ), DAT_MOV_TRAN ";
                    }
                    else
                    {                    
                        l_whereClause_TRAP104 << " IND_STTU_TRAN = '0' AND NUM_CAR = '" << l_origpan << "'" <<
                                           " AND VAL_TRAN >= " << l_amount << 
                                           " AND ( NUM_ESTB = " << l_termloc << " OR NUM_ESTB = " << l_cod_mtz_estb <<
                                                 " OR COD_MTZ_ESTB = " << l_termloc << 
                                                 " OR ( COD_MTZ_ESTB != 0 AND COD_MTZ_ESTB = " << l_cod_mtz_estb << " ) " <<
                                           " ) ORDER BY ABS( 1 - " << ::atof( l_amount.c_str() ) << "/VAL_TRAN ), DAT_MOV_TRAN ";
                    }

                    logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0058 II ==========" );
                    logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause_TRAP104.str( ).c_str( ) );
                    dbaccess_common::TBSW0058 l_TBSW0058_TRAP104( l_whereClause_TRAP104.str( ) );
                    
                    l_TBSW0058_TRAP104.prepare( );
                    l_TBSW0058_TRAP104.execute( );
                    //TODOSW75 
                    /***
                    dbaccess_common::DualHandler l_dualHand_TRAP104( &l_TBSW0058_TRAP104 );
                    int ret_TRAP104 = l_dualHand_TRAP104.fetch( );
                    ***/
                    int ret_TRAP104 = l_TBSW0058_TRAP104.fetch( );
                    if ( !ret_TRAP104 )
                    {
                        this->setResult( "NO ROWS" );
                    }
                    else
                    {
                        this->setResult( "PRE_AUT_VENCIDA" );
                    }
                }
                // 2016/05/25 - TRATAMENTO PARA TRAVA085 - FIM
                // ID_231728 - Mascaramento do numero do cartao no cupom da PreAuth - INICIO
                else if ( ( l_msgtype == 220 ) &&
                     ( l_origdate > 0 && l_origrefnum > 0 ) )
                {
                    std::ostringstream whereClauseTrap104Orig;                                        

                    whereClauseTrap104Orig << " DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;

                    if( l_install_num.empty() )
                    {
                        l_install_num = "0";
                    }

                    // Workaround - PVS da LOCALIZA devem aceitar confirmar parcelada , mesmo a original sendo avista
                    if( l_versao_aplicativo.compare("601") >= 0 && l_cod_mtz_estb != 9565060 && l_cod_mtz_estb != 610126644 && l_termloc != 9565060 && l_termloc != 610126644  )
                    {
                        whereClauseTrap104Orig << "AND IND_STTU_TRAN = '0' AND NUM_CAR = '" << l_origpan << "'" <<
                            " AND VAL_TRAN >= " << l_amount << 
                            " AND ( NUM_ESTB = " << l_termloc << " OR NUM_ESTB = " << l_cod_mtz_estb <<
                            " OR COD_MTZ_ESTB = " << l_termloc << 
                            " OR ( COD_MTZ_ESTB != 0 AND COD_MTZ_ESTB = " << l_cod_mtz_estb << " ) " <<
                            " ) AND QTD_PRCL_CNFR = " << l_install_num << 
                            " ORDER BY ABS( 1 - " << ::atof( l_amount.c_str() ) << "/VAL_TRAN ), DAT_MOV_TRAN ";
                    }
                    else
                    {                    
                        whereClauseTrap104Orig << "AND IND_STTU_TRAN = '0' AND NUM_CAR = '" << l_origpan << "'" <<
                            " AND VAL_TRAN >= " << l_amount << 
                            " AND ( NUM_ESTB = " << l_termloc << " OR NUM_ESTB = " << l_cod_mtz_estb <<
                            " OR COD_MTZ_ESTB = " << l_termloc << 
                            " OR ( COD_MTZ_ESTB != 0 AND COD_MTZ_ESTB = " << l_cod_mtz_estb << " ) " <<
                            " ) ORDER BY ABS( 1 - " << ::atof( l_amount.c_str() ) << "/VAL_TRAN ), DAT_MOV_TRAN ";
                    }

                    logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0058 III ==========" );
                    logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, whereClauseTrap104Orig.str( ).c_str( ) );
                    dbaccess_common::TBSW0058 tbsw0058Trap104( whereClauseTrap104Orig.str( ) );
                    
                    tbsw0058Trap104.prepare( );
                    tbsw0058Trap104.execute( );
                    //TODOSW75 
                    /***
                    dbaccess_common::DualHandler dualHandleTrap104( &tbsw0058Trap104 );
                    int returnTrap104 = dualHandleTrap104.fetch( );
                    ***/
                    int returnTrap104 = tbsw0058Trap104.fetch( );
                    if ( !returnTrap104 )
                    {
                        this->setResult( "NO ROWS" );
                    }
                    else
                    {
                        this->setResult( "PRE_AUT_VENCIDA" );
                    }
                } // ID_231728 - Mascaramento do numero do cartao no cupom da PreAuth - FIM
				else {
                    this->setResult( "NO ROWS" );
				}
            }
            else
            {
                this->setResult( "OK" );
                
                char l_bufferTemp[ 64 ];
                oasis_dec_t l_dec_temp;
                
                fieldSet::fscopy( m_targetField[ DAT_MOV_TRAN ], l_TBSW0058.get_DAT_MOV_TRAN( ) );
                fieldSet::fscopy( m_targetField[ NUM_SEQ_UNC ], l_TBSW0058.get_NUM_SEQ_UNC( ) );                
                fieldSet::fscopy( m_targetField[ TIP_TRAN ], l_TBSW0058.get_TIP_TRAN( ) );
                fieldSet::fscopy( m_targetField[ NUM_MOT_RSPS ], l_TBSW0058.get_NUM_MOT_RSPS( ) );
                fieldSet::fscopy( m_targetField[ NUM_ESTB ], l_TBSW0058.get_NUM_ESTB( ) );
                fieldSet::fscopy( m_targetField[ COD_TERM ], l_TBSW0058.get_COD_TERM( ) );
                fieldSet::fscopy( m_targetField[ NUM_RD_ORG ], l_TBSW0058.get_NUM_RD_ORG( ) );
                fieldSet::fscopy( m_targetField[ COD_POS_ENTR_MODO ], l_TBSW0058.get_COD_POS_ENTR_MODO( ) );
                fieldSet::fscopy( m_targetField[ COD_EMSR ], l_TBSW0058.get_COD_EMSR( ) );
                
                l_dec_temp = l_TBSW0058.get_VAL_TRAN( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar( &l_dec_temp, l_bufferTemp );
                fieldSet::fscopy( m_targetField[ VAL_TRAN ], std::string( l_bufferTemp ) );
                
                fieldSet::fscopy( m_targetField[ COD_RAM_ATVD ], l_TBSW0058.get_COD_RAM_ATVD( ) );
                fieldSet::fscopy( m_targetField[ NUM_CAR ], l_TBSW0058.get_NUM_CAR( ) );
                fieldSet::fscopy( m_targetField[ NUM_AUT ], l_TBSW0058.get_NUM_AUT( ) );
                
                l_dec_temp = l_TBSW0058.get_VAL_COT_DLR( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar( &l_dec_temp, l_bufferTemp );
                fieldSet::fscopy( m_targetField[ VAL_COT_DLR ], std::string( l_bufferTemp ) );
                
                fieldSet::fscopy( m_targetField[ DAT_VLD_CAR ], l_TBSW0058.get_DAT_VLD_CAR( ).date );
                fieldSet::fscopy( m_targetField[ COD_TRK_CAR ], l_TBSW0058.get_COD_TRK_CAR( ) );
                fieldSet::fscopy( m_targetField[ COD_MOED ], l_TBSW0058.get_COD_MOED( ) );
                fieldSet::fscopy( m_targetField[ COD_PAIS_CAR ], l_TBSW0058.get_COD_PAIS_CAR( ) );
                fieldSet::fscopy( m_targetField[ COD_SERV_SNHA ], l_TBSW0058.get_COD_SERV_SNHA( ) );
                fieldSet::fscopy( m_targetField[ IND_RD_ORG ], l_TBSW0058.get_IND_RD_ORG( ) );
                fieldSet::fscopy( m_targetField[ COD_MOT_AUT ], l_TBSW0058.get_COD_MOT_AUT( ) );
                fieldSet::fscopy( m_targetField[ DAT_PAUZ ], l_TBSW0058.get_DAT_PAUZ( ) );
                fieldSet::fscopy( m_targetField[ COD_GRU_ESTB ], l_TBSW0058.get_COD_GRU_ESTB( ) );
                fieldSet::fscopy( m_targetField[ COD_MTZ_ESTB ], l_TBSW0058.get_COD_MTZ_ESTB( ) );
                
                fieldSet::fscopy( m_targetField[ DTH_INI_TRAN ], l_TBSW0058.get_DTH_INI_TRAN( ) );
                fieldSet::fscopy( m_targetField[ DTH_STTU_TRAN ], l_TBSW0058.get_DTH_STTU_TRAN( ) );
                fieldSet::fscopy( m_targetField[ DTH_GMT ], l_TBSW0058.get_DTH_GMT( ) );
                fieldSet::fscopy( m_targetField[ NUM_STAN ], l_TBSW0058.get_NUM_STAN( ) );
                
                l_dec_temp = l_TBSW0058.get_VAL_EFTV_CPTR( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar( &l_dec_temp, l_bufferTemp );
                fieldSet::fscopy( m_targetField[ VAL_EFTV_CPTR ], std::string( l_bufferTemp ) );
                
                fieldSet::fscopy( m_targetField[ QTD_PRCL_CNFR ], l_TBSW0058.get_QTD_PRCL_CNFR( ) );
                fieldSet::fscopy( m_targetField[ IND_RD_CPTR ], l_TBSW0058.get_IND_RD_CPTR( ) );
                fieldSet::fscopy( m_targetField[ COD_CNDC_CPTR ], l_TBSW0058.get_COD_CNDC_CPTR( ) );
                fieldSet::fscopy( m_targetField[ DAT_CNFR_PAUZ ], l_TBSW0058.get_DAT_CNFR_PAUZ( ) );
                
                l_dec_temp = l_TBSW0058.get_VAL_TRAN_DLR( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar( &l_dec_temp, l_bufferTemp );
                fieldSet::fscopy( m_targetField[ VAL_TRAN_DLR ], std::string( l_bufferTemp ) );
                
                fieldSet::fscopy( m_targetField[ DAT_CAN_PAUZ ], l_TBSW0058.get_DAT_CAN_PAUZ( ) );
                fieldSet::fscopy( m_targetField[ DAT_VLD_PAUZ ], l_TBSW0058.get_DAT_VLD_PAUZ( ) );
                fieldSet::fscopy( m_targetField[ NOM_PORT_CAR ], l_TBSW0058.get_NOM_PORT_CAR( ) );
                fieldSet::fscopy( m_targetField[ COD_MSG_ISO ], l_TBSW0058.get_COD_MSG_ISO( ) );
                fieldSet::fscopy( m_targetField[ COD_PCM_ISO ], l_TBSW0058.get_COD_PCM_ISO( ) );
                fieldSet::fscopy( m_targetField[ NOM_SITE_ACQR_ORGL ], l_TBSW0058.get_NOM_SITE_ACQR_ORGL( ) );
                fieldSet::fscopy( m_targetField[ NOM_HOST_ACQR_ORGL ], l_TBSW0058.get_NOM_HOST_ACQR_ORGL( ) );
                fieldSet::fscopy( m_targetField[ NOM_FE_ACQR_ORGL ], l_TBSW0058.get_NOM_FE_ACQR_ORGL( ) );
                fieldSet::fscopy( m_targetField[ NOM_SITE_ISSR ], l_TBSW0058.get_NOM_SITE_ISSR( ) );
                fieldSet::fscopy( m_targetField[ NOM_HOST_ISSR ], l_TBSW0058.get_NOM_HOST_ISSR( ) );
                fieldSet::fscopy( m_targetField[ NOM_FE_ISSR ], l_TBSW0058.get_NOM_FE_ISSR( ) );
                fieldSet::fscopy( m_targetField[ NOM_SITE_ACQR_ATLZ ], l_TBSW0058.get_NOM_SITE_ACQR_ATLZ( ) );
                fieldSet::fscopy( m_targetField[ NOM_HOST_ACQR_ATLZ ], l_TBSW0058.get_NOM_HOST_ACQR_ATLZ( ) );
                fieldSet::fscopy( m_targetField[ NOM_FE_ACQR_ATLZ ], l_TBSW0058.get_NOM_FE_ACQR_ATLZ( ) );
                fieldSet::fscopy( m_targetField[ COD_MOT_ISO_EMSR ], l_TBSW0058.get_COD_MOT_ISO_EMSR( ) );
                fieldSet::fscopy( m_targetField[ COD_TERM_CNFR ], l_TBSW0058.get_COD_TERM_CNFR( ) );
                fieldSet::fscopy( m_targetField[ DAT_MOV_TRAN_CNFR ], l_TBSW0058.get_DAT_MOV_TRAN_CNFR( ) );
                fieldSet::fscopy( m_targetField[ DTH_CNFR ], l_TBSW0058.get_DTH_CNFR( ) );
                fieldSet::fscopy( m_targetField[ IND_RD_ORG_ESTR ], l_TBSW0058.get_IND_RD_ORG_ESTR( ) );
                fieldSet::fscopy( m_targetField[ IND_STTU_TRAN ], l_TBSW0058.get_IND_STTU_TRAN( ) );
                fieldSet::fscopy( m_targetField[ NUM_EMSR ], l_TBSW0058.get_NUM_EMSR( ) );
                fieldSet::fscopy( m_targetField[ NUM_ESTB_CNFR ], l_TBSW0058.get_NUM_ESTB_CNFR( ) );
                fieldSet::fscopy( m_targetField[ NUM_ESTB_ESTR ], l_TBSW0058.get_NUM_ESTB_ESTR( ) );
                
                l_dec_temp = l_TBSW0058.get_NUM_ID_CAR( ); 
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar( &l_dec_temp, l_bufferTemp );
                fieldSet::fscopy( m_targetField[ NUM_ID_CAR ], std::string( l_bufferTemp ) ); 
                
                fieldSet::fscopy( m_targetField[ NUM_SEQ_UNC_CNFR ], l_TBSW0058.get_NUM_SEQ_UNC_CNFR( ) ); 
                fieldSet::fscopy( m_targetField[ NUM_STAN_ORGL ], l_TBSW0058.get_NUM_STAN_ORGL( ) );
                
                fieldSet::fscopy( m_targetField[ COD_BNDR ], l_TBSW0058.get_COD_BNDR( ) );
                fieldSet::fscopy( m_targetField[ IND_EMSR_MTC ], l_TBSW0058.get_IND_EMSR_MTC( ) );
                fieldSet::fscopy( m_targetField[ NUM_AVSO_AUT ], l_TBSW0058.get_NUM_AVSO_AUT( ) );
                fieldSet::fscopy( m_targetField[ TXT_DA_ADIC_EMSR ], l_TBSW0058.get_TXT_DA_ADIC_EMSR( ) );
                fieldSet::fscopy( m_targetField[ NOM_FNTS_PDV ], l_TBSW0058.get_NOM_FNTS_PDV( ) );
                fieldSet::fscopy( m_targetField[ COD_PGM_AUT ], l_TBSW0058.get_COD_PGM_AUT( ) );
                fieldSet::fscopy( m_targetField[ IND_NVL_SGRA_KMRC ], l_TBSW0058.get_IND_NVL_SGRA_KMRC( ) );
                fieldSet::fscopy( m_targetField[ COD_UCAF ], l_TBSW0058.get_COD_UCAF( ) );
                fieldSet::fscopy( m_targetField[ COD_AUT_EMSR_CNVT ], l_TBSW0058.get_COD_AUT_EMSR_CNVT( ) );
                fieldSet::fscopy( m_targetField[ COD_AUT_EMSR ], l_TBSW0058.get_COD_AUT_EMSR( ) );
                fieldSet::fscopy( m_targetField[ NTWK_ID_ACQR_ATLZ ], l_TBSW0058.get_NTWK_ID_ACQR_ATLZ( ) );
                fieldSet::fscopy( m_targetField[ NTWK_ID_ACQR_ORGL ], l_TBSW0058.get_NTWK_ID_ACQR_ORGL( ) );
                fieldSet::fscopy( m_targetField[ NTWK_ID_ROUTE_ATLZ ], l_TBSW0058.get_NTWK_ID_ROUTE_ATLZ( ) );
                fieldSet::fscopy( m_targetField[ NTWK_ID_ROUTE_ORGL ], l_TBSW0058.get_NTWK_ID_ROUTE_ORGL( ) );
                fieldSet::fscopy( m_targetField[ NTWK_ID_ISSR_ATLZ ], l_TBSW0058.get_NTWK_ID_ISSR_ATLZ( ) );
                fieldSet::fscopy( m_targetField[ NTWK_ID_ISSR_ORGL ], l_TBSW0058.get_NTWK_ID_ISSR_ORGL( ) );
                fieldSet::fscopy( m_targetField[ COD_CTAH_VOCH ], l_TBSW0058.get_COD_CTAH_VOCH( ) );
                fieldSet::fscopy( m_targetField[ COD_TIP_PROD_CAR ], l_TBSW0058.get_COD_TIP_PROD_CAR( ) );
                fieldSet::fscopy( m_targetField[ NUM_REF_TRAN ], l_TBSW0058.get_NUM_REF_TRAN( ) );
                fieldSet::fscopy( m_targetField[ COD_CPCD_TERM ], l_TBSW0058.get_COD_CPCD_TERM( ) );
                fieldSet::fscopy( m_targetField[ IND_TRAN_TKN ], l_TBSW0058.get_IND_TRAN_TKN( ) );
                fieldSet::fscopy( m_targetField[ COD_ORG_APRV ], l_TBSW0058.GetCodOrgAprv( ) );
                fieldSet::fscopy( m_targetField[ COD_PROD_MTC ], l_TBSW0058.GetCodigoProdutoMastercard( ) );
                fieldSet::fscopy( m_targetField[ COD_RGAO_MTC ], l_TBSW0058.GetCodigoRegiaoMastercard( ) );
                
                // Release Bandeiras PDV - Abril 2019 - INICIO
                fieldSet::fscopy( m_targetField[ COD_PORT_PRES_VLDC_BNDR ], l_TBSW0058.GetIndicadorPresencaPortador( ) );
                fieldSet::fscopy( m_targetField[ COD_CPCD_TERM_VLDC_BNDR ], l_TBSW0058.GetIndicadorTecnologiaTerminal( ) );
                // Release Bandeiras PDV - Abril 2019 - FIM
                fieldSet::fscopy( m_targetField[ ID_REF_BNDR ], l_TBSW0058.GetIdentificadorReferenciaBandeira( ) );
            }
        }
        catch ( base::GenException e )
        {
            this->setResult( "ERROR" );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0058Loader <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            this->setResult( "ERROR" );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0058Loader <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        
        fieldSet::fscopy( m_targetField[ 0 ], getResult( ) );
        a_stop = false;
        return( 0 );
    }
    
    std::string TBSW0058Loader::getResult( )
    {
        return( m_result );
    }
    
    TBSW0058Loader& TBSW0058Loader::setResult( const std::string& a_result )
    {
        m_result = a_result;
        return( *this );
    }
    TBSW0058Loader& TBSW0058Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    TBSW0058Loader& TBSW0058Loader::setSourceFieldPath( const std::string& a_path )
    {
          m_sourceFieldPath = a_path;
          return( *this );
    }
    dataManip::Command* TBSW0058Loader::clone( ) const
    {
        return( new TBSW0058Loader( *this ) );
    }
} //namespace plugins_pdv


