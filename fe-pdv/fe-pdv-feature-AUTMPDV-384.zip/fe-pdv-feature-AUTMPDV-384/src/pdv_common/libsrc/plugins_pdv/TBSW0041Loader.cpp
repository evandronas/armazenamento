/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0041.hpp"
#include "plugins_pdv/TBSW0041Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
	base::Identificable* createTBSW0041Loader( )
	{
		TBSW0041Loader* l_new = new TBSW0041Loader;
		return l_new;
	}
	bool TBSW0041Loader::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "sourceFieldPath", l_tagList );
		std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "targetFieldPath", l_tagList );
		std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setSourceFieldPath( l_sourcePath );
		this->setTargetFieldPath( l_targetPath );
		return true;
	}
	TBSW0041Loader::TBSW0041Loader( )
	{
	}
	TBSW0041Loader::~TBSW0041Loader( )
	{
	}
	bool TBSW0041Loader::init( )
	{
		std::string tb_components[]
		=
		{
			"RESULT", "NUM_PDV", "COD_BNDR", "QTD_MXO_PRCL", "COD_STTU_REG", "DAT_ATLZ_REG", "COD_BCO_CMPS", "COD_AGE", "NUM_CTA_BNCR", "DAT_INI_COB_ANT", "DAT_INI_COB_ATU", "TIP_COB_TRAN_ANT", "TIP_COB_TRAN_ATU", "VAL_COB_TRAN_ANT", "VAL_COB_TRAN_ATU", "COD_TRAN", "IND_PERM_TRAN_DGTD_EMSR", "IND_MODL_CPTR"
		};
		for ( unsigned int i = 0; i < TB_FIELDS_SIZE; i++ )
		{
			m_targetField[i]
			= this->navigate( m_targetFieldPath + "." + tb_components[i] );
			if ( !m_targetField[i] )
			{
				std::string l_errorMsg( "Field not found <" + m_targetFieldPath + "." + tb_components[i]
				+ ">" );
				this->enableError( true );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		std::string source_components[]
		=
		{
			"shc_msg.termloc", "segments.common.cod_trans", "segments.common.cod_bndr"
		};
		for ( unsigned int i = 0; i < LAST_SOURCE_FIELD; i++ )
		{
			m_sourceField[i]
			= this->navigate( m_sourceFieldPath + "." + source_components[i] );
			if ( !m_sourceField[i] )
			{
				std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + "." + source_components[i]
				+ ">" );
				this->enableError( true );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		return true;
	}
	void TBSW0041Loader::finish( )
	{
	}
	int TBSW0041Loader::execute( bool& a_stop )
	{
		try
		{
			std::ostringstream l_whereClause;
			long l_num_pdv = 0;
			long l_cod_trans = 0;
			long l_cod_bndr = 0;
			fieldSet::fsextr( l_num_pdv, m_sourceField[TERMLOC] );
			fieldSet::fsextr( l_cod_trans, m_sourceField[COD_TRANS] );
			fieldSet::fsextr( l_cod_bndr, m_sourceField[BNDR] );
			l_whereClause << "NUM_PDV = " << l_num_pdv
						  << " AND COD_TRAN = " << l_cod_trans
						  << " AND COD_BNDR = " << l_cod_bndr;
						  
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0041 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );						  
						  
			dbaccess_common::TBSW0041 l_table0041( l_whereClause.str( ) );
			l_table0041.prepare( );
			l_table0041.execute( );
			int ret = l_table0041.fetch( );
			if ( !ret )
			{
				setResult( "NO ROWS" );
			}
			else
			{
				oasis_dec_t l_decTmp;
				char l_valCobTranAnt[64];
				char l_valCobTranAtu[64];
				setResult( "OK" );
				memset( l_valCobTranAnt, 0, sizeof( l_valCobTranAnt ) );
				memset( l_valCobTranAtu, 0, sizeof( l_valCobTranAtu ) );
				l_decTmp = l_table0041.getVAL_COB_TRAN_ANT( );
				dbm_dectochar( &l_decTmp, l_valCobTranAnt );
				l_decTmp = l_table0041.getVAL_COB_TRAN_ATU( );
				dbm_dectochar( &l_decTmp, l_valCobTranAtu );
				// enum tableFields
				fieldSet::fscopy( m_targetField[NUM_PDV], l_table0041.getNUM_PDV( ) );
				fieldSet::fscopy( m_targetField[COD_BNDR], l_table0041.getCOD_BNDR( ) );
				fieldSet::fscopy( m_targetField[QTD_MXO_PRCL], l_table0041.getQTD_MXO_PRCL( ) );
				fieldSet::fscopy( m_targetField[COD_STTU_REG], l_table0041.getCOD_STTU_REG( ) );
				fieldSet::fscopy( m_targetField[DAT_ATLZ_REG], l_table0041.getDAT_ATLZ_REG( ) );
				fieldSet::fscopy( m_targetField[COD_BCO_CMPS], l_table0041.getCOD_BCO_CMPS( ) );
				fieldSet::fscopy( m_targetField[COD_AGE], l_table0041.getCOD_AGE( ) );
				fieldSet::fscopy( m_targetField[NUM_CTA_BNCR], l_table0041.getNUM_CTA_BNCR( ) );
				fieldSet::fscopy( m_targetField[DAT_INI_COB_ANT], l_table0041.getDAT_INI_COB_ANT( ) );
				fieldSet::fscopy( m_targetField[DAT_INI_COB_ATU], l_table0041.getDAT_INI_COB_ATU( ) );
				fieldSet::fscopy( m_targetField[TIP_COB_TRAN_ANT], l_table0041.getTIP_COB_TRAN_ANT( ) );
				fieldSet::fscopy( m_targetField[TIP_COB_TRAN_ATU], l_table0041.getTIP_COB_TRAN_ATU( ) );
				fieldSet::fscopy( m_targetField[VAL_COB_TRAN_ANT], std::string( l_valCobTranAnt ) );
				fieldSet::fscopy( m_targetField[VAL_COB_TRAN_ATU], std::string( l_valCobTranAtu ) );
				fieldSet::fscopy( m_targetField[COD_TRAN], l_table0041.getCOD_TRAN( ) );
				fieldSet::fscopy( m_targetField[IND_PERM_TRAN_DGTD_EMSR], l_table0041.getIND_PERM_TRAN_DGTD_EMSR( ) );
				fieldSet::fscopy( m_targetField[IND_MODL_CPTR], l_table0041.getIND_MODL_CPTR( ) );
			}
		}
		catch( base::GenException e )
		{
			setResult( "ERROR" );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0041 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0041[" + l_what + "]";
		}
		fieldSet::fscopy( m_targetField[RESULT], getResult( ) );
		a_stop = false;
		return 0;
	}
	TBSW0041Loader& TBSW0041Loader::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	TBSW0041Loader& TBSW0041Loader::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	TBSW0041Loader& TBSW0041Loader::setResult( const std::string& a_result )
	{
		m_result = a_result;
		return *this;
	}
	std::string TBSW0041Loader::getResult( )
	{
		return m_result;
	}
	dataManip::Command* TBSW0041Loader::clone( ) const
	{
		return new TBSW0041Loader( *this );
	}
}//namespace plugins_pdv

