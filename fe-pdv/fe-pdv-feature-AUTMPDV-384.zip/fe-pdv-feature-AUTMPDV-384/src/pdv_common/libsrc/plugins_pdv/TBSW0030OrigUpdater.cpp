#pragma once

#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "defines.hpp"
//TODOSW75 #include "dualHandler.hpp"
#include "TBSW0030.hpp"
#include "plugins_pdv/TBSW0030OrigUpdater.hpp"
#include "dbaccess_pdv/TBSW0030RegrasFormatacao.hpp"

//TODOSW75 
/***
dbm_datetime_t f_datetime( long a_data, long a_time )
{
    struct tm l_dattim;
    char l_szdate[20], l_sztime[20];
    std::string l_date, l_time;
    memset( &l_dattim, 0, sizeof( l_dattim ) );
    sprintf( l_szdate, "%08d", a_data );
    sprintf( l_sztime, "%06d", a_time );
    l_date = l_szdate;
    l_time = l_sztime;
    l_dattim.tm_isdst = -1;
    l_dattim.tm_sec = atoi( l_time.substr( 4, 2 ).c_str( ) );
    l_dattim.tm_min = atoi( l_time.substr( 2, 2 ).c_str( ) );
    l_dattim.tm_hour = atoi( l_time.substr( 0, 2 ).c_str( ) );
    l_dattim.tm_mday = atoi( l_date.substr( 6, 2 ).c_str( ) );
    l_dattim.tm_mon = atoi( l_date.substr( 4, 2 ).c_str( ) ) - 1;
    l_dattim.tm_year = atoi( l_date.substr( 0, 4 ).c_str( ) ) - 1900;
    return( mktime( &l_dattim ) );
}
***/

namespace plugins_pdv
{
    base::Identificable* createTBSW0030OrigUpdater( )
    {
        TBSW0030OrigUpdater* l_new = new TBSW0030OrigUpdater;
        return( l_new );
    }

    TBSW0030OrigUpdater::TBSW0030OrigUpdater( )
    {
    }

    TBSW0030OrigUpdater::~TBSW0030OrigUpdater( )
    {
    }

    bool TBSW0030OrigUpdater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        return( true );
    }

    bool TBSW0030OrigUpdater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        
        m_cod_ntwk_id_rout_atlz = this->navigate( m_sourceFieldPath + ".shc_msg.receive_inst_id" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_orig_local_date = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_date" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_is_reversal = this->navigate( m_sourceFieldPath + ".segments.common.is_reversal" );
        m_is_void = this->navigate( m_sourceFieldPath + ".segments.common.is_void" );
        m_issuer = this->navigate( m_sourceFieldPath + ".shc_msg.issuer" );
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_msg_category = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        m_status_trn_orig = this->navigate( m_sourceFieldPath + ".segments.common.status_trn_orig" );
        m_msg_name = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        identificadorReferenciaBandeira = this->navigate( m_sourceFieldPath + ".segments.common.identificadorReferenciaBandeira" );

        return( true );
    }

    void TBSW0030OrigUpdater::finish( )
    {
    }

    int TBSW0030OrigUpdater::execute( bool& a_stop )
    {
        try
        {
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Updating Original in TBSW0030 =========" );
            std::ostringstream l_whereClause;
            unsigned long l_msgtype;
            unsigned long l_orig_local_date;
            unsigned long l_origrefnum;
            std::string l_status_trn_orig;

            fieldSet::fsextr( l_msgtype, m_msgtype );
            fieldSet::fsextr( l_origrefnum, m_origrefnum );
            fieldSet::fsextr( l_orig_local_date, m_orig_local_date );
            fieldSet::fsextr( l_status_trn_orig, m_status_trn_orig );


            switch ( l_msgtype )
            {
                case 112 : // Padronizacao Crediario PDV
                case 212 :
                case 232 :
                case 410 :
                case 430 :
                // t689049@FIS - 25/01/2017 - Update para as ADM
                case 9072 : // CONF_RES_VEND
                case 9102 : // CONF_TROCA_SENHA_VCH_CHIP ( 9092 -> 9102 )
                case 9310 : // Revers�o de Transa��o Aprovada por Saldo Dispon�vel . Voucher
                    l_whereClause << " DAT_MOV_TRAN = " << l_orig_local_date
                                  << " AND NUM_SEQ_UNC = " << l_origrefnum;
                    break;
                default:
                    char l_szAux[50];
                    sprintf( l_szAux, " MSGTYPE : [%ld] - INVALIDO ", l_msgtype );
                    logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_szAux );
                    fieldSet::fscopy( m_result, "ERROR", 5 );
                    a_stop = false;
                    return 0;
                    break;
            }


            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0030 Original Update ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );

            dbaccess_common::TBSW0030 tbsw0030( l_whereClause.str( ) );
            dbaccess_pdv::TBSW0030RegrasFormatacao regrasFmt;
            acq_common::tbsw0030_params st_tbsw0030 = { 0 };
            
            tbsw0030.prepare_for_update( );
            tbsw0030.execute( );

            //TODOSW75 
            /***
            dbaccess_common::DualHandler l_dualHand( &tbsw0030 );
            if ( l_dualHand.fetch( dbaccess::table::UPDATE ) )
            ***/
            if ( tbsw0030.fetch( ) )
            {
                tbsw0030.let_as_is( );
                
                fieldSet::fsextr( st_tbsw0030.issuer, m_issuer );
                fieldSet::fsextr( st_tbsw0030.receive_inst_id, m_cod_ntwk_id_rout_atlz );
                fieldSet::fsextr( st_tbsw0030.msgtype, m_msgtype );
                fieldSet::fsextr( st_tbsw0030.isVoid, m_is_void );
                fieldSet::fsextr( st_tbsw0030.isReversal, m_is_reversal );
                fieldSet::fsextr( st_tbsw0030.local_time, m_local_time );
                fieldSet::fsextr( st_tbsw0030.local_date, m_local_date );
                fieldSet::fsextr( st_tbsw0030.msg_category, m_msg_category );
                fieldSet::fsextr( st_tbsw0030.msg_name, m_msg_name );
                fieldSet::fsextr( st_tbsw0030.identificadorReferenciaBandeira, identificadorReferenciaBandeira );
                
                st_tbsw0030.cd_ems = tbsw0030.get_COD_EMSR( );
                st_tbsw0030.status = tbsw0030.get_IND_STTU_TRAN( );
                
                regrasFmt.COD_NTWK_ID_ISSR_ATLZ( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_NTWK_ID_ROUT_ATLZ( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_NTWK_ID_ACQR_ATLZ( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NOM_HOST_ACQR_ATLZ( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NOM_FE_ACQR_ATLZ( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NOM_SITE_ACQR_ATLZ( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.DTH_STTU_TRAN( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                tbsw0030.set_IND_STTU_TRAN( l_status_trn_orig );
                
                if( st_tbsw0030.msg_category == "DESFAZIMENTO" )
                {
                    if( tbsw0030.get_COD_MSG_ISO( ) != 400 && tbsw0030.get_COD_EMSR( ) != 15 && 
                        tbsw0030.get_TIP_TRAN() != 10 )
                    {
                        tbsw0030.set_IND_CPTRDO( std::string( "S" ) );
                    }
                }
                else if ( st_tbsw0030.msg_category == "ESTORNO" )
                { 
                    if( tbsw0030.get_COD_EMSR() != 15 && tbsw0030.get_TIP_TRAN() != 10 )
                    {
                        tbsw0030.set_IND_CPTRDO( std::string( "S" ) );
                    }
                }
                else if ( st_tbsw0030.msg_category == "CONFIRMACAO" )
                { 
                    // tbsw0030.set_IND_CPTRDO( std::string( "S" ) );
                    fieldSet::fsextr( st_tbsw0030.status, m_status_trn_orig );
                    regrasFmt.IND_CPTRDO( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                }
                else
                {
                    regrasFmt.IdentificadorReferenciaBandeira( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                }
                
                
                tbsw0030.update( );
                tbsw0030.commit( );
                fieldSet::fscopy( m_result, "OK", 2 );
            }
            else
            {
                logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ORIGINAL TRANSACTION NOT FOUND" );
                fieldSet::fscopy( m_result, "ERROR", 5 );
            }
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= RESULT - TBSW0030 Original Update ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, m_result.value().c_str( ) );
        }
        catch( base::GenException e )
        {
            std::string l_what( e.what( ) );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0030 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            std::string l_what( e.what( ) );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0030 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }

    TBSW0030OrigUpdater& TBSW0030OrigUpdater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0030OrigUpdater& TBSW0030OrigUpdater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    
    TBSW0030OrigUpdater& TBSW0030OrigUpdater::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }
    
    dataManip::Command* TBSW0030OrigUpdater::clone( ) const
    {
        return( new TBSW0030OrigUpdater( *this ) );
    }
}//namespace standardAcqPlugins

