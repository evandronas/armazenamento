#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0087.hpp"
#include "plugins_pdv/TBSW0087Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0087Loader( )
    {
        TBSW0087Loader* l_new = new TBSW0087Loader;
        return( l_new );
    }
    
    bool TBSW0087Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
        
        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );
        
        return( true );
    }
    TBSW0087Loader::TBSW0087Loader( )
    {
    }
    
    TBSW0087Loader::~TBSW0087Loader( )
    {
    }
    
    bool TBSW0087Loader::init( )
    {
        std::string tb_components[ ] =
        {
            "RESULT", "NUM_PRFX_CAR", "COD_SGL_PAI", "COD_STTU_REG", "DAT_ATLZ_REG"
        };
        for ( unsigned int i = 0; i < LAST_TB_FIELD; i++ )
        {
            m_targetField[ i ] = this->navigate( m_targetFieldPath + "." + tb_components[ i ] );
            if ( !m_targetField[ i ] )
            {
                std::string l_errorMsg( "Field not found <" + m_targetFieldPath + "." + tb_components[ i ] + ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return( false );
            }
        }
        
        std::string source_components[ ] =
        {
            "segments.common.bin"
        };
        for ( unsigned int i = 0; i < LAST_SOURCE_FIELD; i++ )
        {
            m_sourceField[ i ] = this->navigate( m_sourceFieldPath + "." + source_components[ i ] );
            if ( !m_sourceField[ i ] )
            {
                std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + "." + source_components[ i ] + ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return( false );
            }
        }
        
        return( true );
    }
    
    void TBSW0087Loader::finish( )
    {
    }
    
    int TBSW0087Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            std::string l_bin = 0;
            fieldSet::fsextr( l_bin, m_sourceField[ BIN ] );
            l_whereClause << "NUM_PRFX_CAR = '" << l_bin << "'";
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0087 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );
            
            dbaccess_common::TBSW0087 l_table0087( l_whereClause.str( ) );
            l_table0087.prepare( );
            l_table0087.execute( );
            int ret = l_table0087.fetch( );
            if ( !ret )
            {
                this->setResult( "NO ROWS" );
            }
            else
            {
                this->setResult( "OK" );
                fieldSet::fscopy( m_targetField[NUM_PRFX_CAR], l_table0087.getNUM_PRFX_CAR( ) );
                fieldSet::fscopy( m_targetField[COD_SGL_PAI], l_table0087.getCOD_SGL_PAI( ) );
                fieldSet::fscopy( m_targetField[COD_STTU_REG], l_table0087.getCOD_STTU_REG( ) );
                fieldSet::fscopy( m_targetField[DAT_ATLZ_REG], l_table0087.getDAT_ATLZ_REG( ) );
            }
        }
        catch( base::GenException e )
        {
            this->setResult( "ERROR" );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in tbsw0087 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0087[" + l_what + "]";
        }
        fieldSet::fscopy( m_targetField[ RESULT ], this->getResult( ) );
        a_stop = false;
        return( 0 );
    }
    
    TBSW0087Loader& TBSW0087Loader::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0087Loader& TBSW0087Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    
    TBSW0087Loader& TBSW0087Loader::setResult( const std::string& a_result )
    {
        m_result = a_result;
        return( *this );
    }
    
    std::string TBSW0087Loader::getResult( )
    {
        return( m_result );
    }
    
    dataManip::Command* TBSW0087Loader::clone( ) const
    {
        return( new TBSW0087Loader( *this ) );
    }
}//namespace plugins_pdv

