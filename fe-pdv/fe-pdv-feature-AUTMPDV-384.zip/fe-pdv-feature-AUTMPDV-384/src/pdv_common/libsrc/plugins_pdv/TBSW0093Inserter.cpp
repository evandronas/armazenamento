/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0093Inserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0093Inserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <698224, Raphael Gomes>        >
/ Data de Cria��o: <2013, 16 de Janeiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ <28.11.2013, FEPDV, t694449, Padronizacao de Erro>
/ <16.01.2014, FEPDV, t694449, BT54742>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0093.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0093Inserter.hpp"

#include "dbaccess_pdv/TBSW0093RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0093Inserter()
    {
        TBSW0093Inserter* l_new = new TBSW0093Inserter;
        return l_new;
    }

    TBSW0093Inserter::TBSW0093Inserter()
    {
    }

    TBSW0093Inserter::~TBSW0093Inserter()
    {
    }

    bool TBSW0093Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

        return true;
    }

    bool TBSW0093Inserter::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_az_reason_code = this->navigate( m_sourceFieldPath + ".segments.common.az_reason_code" );
        m_ext_network_code = this->navigate( m_sourceFieldPath + ".segments.common.ext_network_code" );

        // t694446@FIS_BEGIN - Data: 23/10/2013 - GAP3 - 1.1.4.5 - Remo��o da coluna
        //m_settlement_date = this->navigate( m_sourceFieldPath + ".shc_msg.settlement_date" );
        // t694446@FIS_END - Data: 23/10/2013 - GAP3 - 1.1.4.5 - Remo��o da coluna

        m_pb_reason_code = this->navigate( m_sourceFieldPath + ".segments.common.pb_reason_code" );
        m_bit63 = this->navigate( m_sourceFieldPath + ".segments.common.bit63" );
        m_transcode = this->navigate( m_sourceFieldPath + ".segments.common.transcode" );
        m_pcode = this->navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        m_pay_code = this->navigate( m_sourceFieldPath + ".segments.common.pay_code" );
        m_pos_entry_code = this->navigate( m_sourceFieldPath + ".shc_msg.pos_entry_code" );
        m_cd_ems = this->navigate( m_sourceFieldPath + ".segments.common.cd_ems" );
        
        m_cod_item		= this->navigate( m_sourceFieldPath + ".segments.private_label.cod_item" );
        // t719926 - Gaps - 19/07/2016 - Inicio
        m_msg_name = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        // t719926 - Gaps - 19/07/2016 - Fim

        return true;
    }

    void TBSW0093Inserter::finish()
    {
    }

    int TBSW0093Inserter::execute( bool& a_stop )
    {
        try
        {            
            dbaccess_pdv::TBSW0093RegrasFormatacao regrasFormatacao;
            dbaccess_common::TBSW0093 tbsw0093;
            acq_common::tbsw0093_params tbsw0093_params = { 0 };
            //*MMS* nao esquecer de preencher esta variavel no xml..
            //tbsw0093_params.tbsw0030_tip_vd             
            
            fieldSet::fsextr( tbsw0093_params.local_date, m_local_date );
            fieldSet::fsextr( tbsw0093_params.refnum,     m_refnum );
            fieldSet::fsextr( tbsw0093_params.common_transcode,     m_transcode );
            fieldSet::fsextr( tbsw0093_params.common_ext_network_code, m_ext_network_code );
            fieldSet::fsextr( tbsw0093_params.private_label_cod_item,  m_cod_item );
            fieldSet::fsextr( tbsw0093_params.pos_entry_code,          m_pos_entry_code );
            fieldSet::fsextr( tbsw0093_params.tbsw0030_tip_vd,         m_transcode );
            fieldSet::fsextr( tbsw0093_params.common_pb_reason_code,   m_pb_reason_code );
            // t719926 - Gaps - 19/07/2016 - Inicio
            fieldSet::fsextr( tbsw0093_params.msg_name,                m_msg_name );
            // t719926 - Gaps - 19/07/2016 - Fim

            // COD_MOT_RSPS_EXT               NOT NULL CHAR(3) 
            regrasFormatacao.COD_MOT_RSPS_EXT( tbsw0093, tbsw0093_params, acq_common::INSERT );
            
            // COD_OPER_CNFR                  NOT NULL CHAR(6)  
            regrasFormatacao.COD_OPER_CNFR( tbsw0093, tbsw0093_params, acq_common::INSERT );
            
            // COD_OPER_ESTR                  NOT NULL CHAR(7) 
            regrasFormatacao.COD_OPER_ESTR( tbsw0093, tbsw0093_params, acq_common::INSERT );
            
            // COD_ITEM                       NOT NULL CHAR(11) 
            regrasFormatacao.COD_ITEM( tbsw0093, tbsw0093_params, acq_common::INSERT ); 
            
            // TIP_MODO_TRAN                  NOT NULL CHAR(1)   
            regrasFormatacao.TIP_MODO_TRAN( tbsw0093, tbsw0093_params, acq_common::INSERT ); 
            
            // TIP_MSG                        NOT NULL CHAR(1)   
            regrasFormatacao.TIP_MSG( tbsw0093, tbsw0093_params, acq_common::INSERT ); 
            
            // TIP_VD_SAID                    NOT NULL CHAR(2)   
            regrasFormatacao.TIP_VD_SAID( tbsw0093, tbsw0093_params, acq_common::INSERT ); 
            
            // NUM_OPER_ETD                   NOT NULL NUMBER(12)
            regrasFormatacao.NUM_OPER_ETD( tbsw0093, tbsw0093_params, acq_common::INSERT ); 
            
            // NUM_RD_DEST                    NOT NULL NUMBER(7)
            regrasFormatacao.NUM_RD_DEST( tbsw0093, tbsw0093_params, acq_common::INSERT ); 
             
            // COD_MOT_ESTR_DEST              NOT NULL CHAR(2)  
            regrasFormatacao.COD_MOT_ESTR_DEST( tbsw0093, tbsw0093_params, acq_common::INSERT );
            
            // COD_MOT_RSPS_DEST              NOT NULL CHAR(2)   
            regrasFormatacao.COD_MOT_RSPS_DEST( tbsw0093, tbsw0093_params, acq_common::INSERT );
            
            // DAT_MOV_TRAN                   NOT NULL NUMBER(8) 
            regrasFormatacao.DAT_MOV_TRAN( tbsw0093, tbsw0093_params, acq_common::INSERT );
            
            // NUM_SEQ_UNC                    NOT NULL NUMBER(12)
            regrasFormatacao.NUM_SEQ_UNC( tbsw0093, tbsw0093_params, acq_common::INSERT );
            
            tbsw0093.insert( );
            tbsw0093.commit( );
            fieldSet::fscopy( m_result, "OK", 2 );
        }

        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Gen Exception in TBSW0093 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0093 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    TBSW0093Inserter& TBSW0093Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    TBSW0093Inserter& TBSW0093Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0093Inserter::clone() const
    {
        return new TBSW0093Inserter(*this);
    }

} //namespace plugins_pdv


