/*
*********************** MODIFICACOES ************************
Autor    : Daniel Nava
Data     : 22/10/2019
Empresa  : Leega
Descricao: Inclusao dos milisegundos na log
ID       : EAK-1854
*************************************************************
*/

#pragma once

#include <unistd.h>
#include <ctime>
#include <cstring>
#include <sys/timeb.h>
#include "base/GenException.hpp"
#include "logger/LoggerTrap.hpp"
#include "plugins_pdv/TraceTrap.hpp"
#include "configBase/TagList.hpp"

namespace plugins_pdv
{
    base::Identificable* createTraceTrap( )
    {
        TraceTrap* l_new = new TraceTrap;
        return l_new;
    }
    TraceTrap::TraceTrap( )
    {
        m_logger = 0;
    }
    TraceTrap::~TraceTrap( )
    {
    }
    bool TraceTrap::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        std::string l_source;
        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "TBSW0040" )
            {
                m_TBSW0040FieldPath = l_source;
            }
            else
            {
                m_sourceFieldPath = l_source;
            }
        }

        return true;
    }
    bool TraceTrap::init( )
    {
        m_pid = getpid();

        m_acq_name = navigate( m_sourceFieldPath + ".segments.common.acq_name" );
        m_msgType = navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_pcode = navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        m_posEntryCode = navigate( m_sourceFieldPath + ".shc_msg.pos_entry_code" );
        m_amount = navigate( m_sourceFieldPath + ".shc_msg.amount" );
        m_termloc = navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_terminal_pdv = navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        m_num_vers_clit = navigate( m_sourceFieldPath + ".segments.merchant.num_vers_clit" );
        m_DE47_56_num_cnpj = navigate( m_sourceFieldPath + ".segments.merchant.num_cnpj" );
        m_TBSW0040_num_cnpj = navigate( m_TBSW0040FieldPath + ".NUM_CNPJ" );

        m_logger = logger::LoggerTrap::getInstance( );
        m_logger->init( );

        return true;
    }
    void TraceTrap::finish( )
    {
    }

/// execute
/// Monta o texto da log
/// EF/ET: EAK-1854
/// Histórico: 22/10/2019
/// Alteracao para buscar a data e hora pela biblioteca sys/timeb para buscar os milissegundos
    int TraceTrap::execute( bool& a_stop )
    {
        base::genAssertPtr( m_logger, __FUNCTION__, "Logger not initialised" );

		timeb nowTimePoint;
        time_t l_rawtime;
        struct tm * l_timeinfo;
        char l_timeAscii[128];

        memset(l_timeAscii, 0, sizeof(l_timeAscii) );
		//time ( &l_rawtime );
		ftime(&nowTimePoint);
		l_rawtime =  nowTimePoint.time;
        l_timeinfo = localtime ( &l_rawtime );
		
		unsigned short milli = nowTimePoint.millitm;

        base::genAssertPtr( l_timeinfo, __FUNCTION__, "Invalid timeinfo" );

        snprintf(
            l_timeAscii,
            sizeof l_timeAscii,
            "%04d.%02d.%02d %02d:%02d:%02d.%03d",
            l_timeinfo->tm_year + 1900,
            l_timeinfo->tm_mon + 1,
            l_timeinfo->tm_mday,
            l_timeinfo->tm_hour,
            l_timeinfo->tm_min,
            l_timeinfo->tm_sec,
			milli
        );

        std::string l_amount;
        l_amount.assign( m_amount.value() );
        std::size_t l_pos = l_amount.find('.');
        if ( l_pos != std::string::npos )
        {
            l_amount.erase( l_pos, 1 );
        }
        l_amount.insert( 0, 12 - l_amount.length(), '0' );

        std::string l_num_vers_clit;
        if ( m_num_vers_clit.value().size() >= 5 )
            l_num_vers_clit = m_num_vers_clit.value().substr(0,5);
        else
            l_num_vers_clit = m_num_vers_clit.value();

        char l_buffer[256];
        snprintf( l_buffer, sizeof l_buffer, "%s %0.8d FEPDV %3.3s TRAP095 %0.4d %0.6d %0.3d %12.12s %9.9s %8.8s %5.5s DE47.56[%14.14s] TB40.NUM_CNPJ[%14.14s]\n",
            l_timeAscii,
            m_pid,
            m_acq_name.value().c_str(),
            atoi( m_msgType.value().c_str() ),
            atoi( m_pcode.value().c_str() ),
            atoi( m_posEntryCode.value().c_str() ),
            l_amount.c_str(),
            m_termloc.value().c_str(),
            m_terminal_pdv.value().c_str(),
            l_num_vers_clit.c_str(),
            m_DE47_56_num_cnpj.value().c_str(),
            m_TBSW0040_num_cnpj.value().c_str()
        );

        m_logger->print( logger::LEVEL_TRACE, l_buffer );

        a_stop = false;
        return 0;
    }
    dataManip::Command* TraceTrap::clone( ) const
    {
        return new TraceTrap(*this);
    }
}//namespace plugins_pdv
