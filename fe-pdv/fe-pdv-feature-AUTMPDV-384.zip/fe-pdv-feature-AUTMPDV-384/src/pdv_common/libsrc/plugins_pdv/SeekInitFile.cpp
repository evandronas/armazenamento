/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o:
/ Conte�do:
/ Autor: cr689068, Jos� Augusto T. Gavazza
/ Data de Cria��o: 2013, 05 de Fevereiro
/ Hist�rico Mudan�as: 2013, 05 de Fevereiro, cr689068, Jos� Augusto T. Gavazza, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "plugins_pdv/SeekInitFile.hpp"
#include <fstream>
#include <cstring>

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    SeekInitFile::SeekInitFile()
    {
    }
    SeekInitFile::~SeekInitFile()
    {
    }

    //--------------------------- GET ---------------------------
    const std::string& SeekInitFile::getCurrentInitInfoFileName() const
    {
        return m_currentInitInfoFileName;
    }
    
    int SeekInitFile::access(const std::string& a_filename)
    {
		int l_status = 0;
		
        std::ifstream l_file(a_filename.c_str());
		l_status = l_file.is_open();
		l_file.close();
		
        return l_status;
    }
    
    int SeekInitFile::seekFile(const std::string& a_ecrInitDir, const std::string& a_ecrInitDirTmp, const std::string& a_verid, const std::string& a_termid, const std::string& a_termloc)
    {
        // Cria nome do arquivo temporario deste terminal
        // formato:   ecrinitRRRRR_YYYYYYYY.dat
		char l_tmp[256];
		memset(l_tmp, 0, 256);
		char aux[500];
		
		
        sprintf ( l_tmp, "%s/ecrinit%.5s_%08s.dat", a_ecrInitDirTmp.c_str(), a_verid.c_str(), a_termid.c_str() );
		m_currentInitInfoFileName = l_tmp;
		
		memset(aux,0,sizeof(aux));
		sprintf ( aux, " \n *******    ARQUIVO 1 = %s   ******* \n ",  l_tmp);		
		logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, aux );
		
        // Verifica se o arquivo temporario do terminal ja existe
        if ( !access(m_currentInitInfoFileName) )
        {
		
			sprintf ( aux, " \n ******* !!!!  NAO ACHOU ARQUIVO 1 = %s   ******* \n ",  l_tmp);
		
            std::string l_ecrInitFile;

            // Verifica se existe arquivo especifico para o terminal
            sprintf (l_tmp, "%s/ecrinit%.5s_%09s_%08s.dat", a_ecrInitDir.c_str(), a_verid.c_str(), a_termloc.c_str(), a_termid.c_str());
			l_ecrInitFile = l_tmp;

			
			memset(aux,0,sizeof(aux));
			sprintf ( aux, "\n *******    ARQUIVO 2 = %s   ******* \n",  l_tmp);		
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, aux );			
			
			if ( !access(l_ecrInitFile) )
			{
			
				sprintf ( aux, " \n ******* !!!!  NAO ACHOU ARQUIVO 2 = %s   ******* \n ",  l_tmp);
			
				// Verifica se existe arquivo especifico para o estabelecimento
				sprintf (l_tmp, "%s/ecrinit%.5s_%09s_%08d.dat", a_ecrInitDir.c_str(), a_verid.c_str(), a_termloc.c_str(), 0);
				l_ecrInitFile = l_tmp;
            
			
				memset(aux,0,sizeof(aux));
				sprintf ( aux, "\n *******    ARQUIVO 3 = %s   ******* \n",  l_tmp);		
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, aux );					
			
				if ( !access(l_ecrInitFile) )
				{
				
					sprintf ( aux, " \n ******* !!!!  NAO ACHOU ARQUIVO 3 = %s   ******* \n ",  l_tmp);
				
					// Verifica se existe arquivo especifico para a vers�o
					sprintf (l_tmp, "%s/ecrinit%.5s_%09s_%08d.dat",a_ecrInitDir.c_str(), a_verid.c_str(), 0, 0);
					l_ecrInitFile = l_tmp;

					
					memset(aux,0,sizeof(aux));
					sprintf ( aux, "\n *******    ARQUIVO 4 = %s   ******* \n",  l_tmp);		
					logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, aux );					
					
					if ( !access(l_ecrInitFile ) )
					{
						sprintf ( aux, " \n ******* !!!!  NAO ACHOU ARQUIVO 4 = %s   ******* \n ",  l_tmp);
					
						//erro - nenhum arquivo encontrado
                        return (-1);
					}
				}
			}

			std::string l_cmd = "cp ";
			l_cmd.append(l_ecrInitFile);
			l_cmd.append(" ");
			l_cmd.append(m_currentInitInfoFileName);
			system (l_cmd.c_str());
		}
		return( 0 );
    }
    
}
