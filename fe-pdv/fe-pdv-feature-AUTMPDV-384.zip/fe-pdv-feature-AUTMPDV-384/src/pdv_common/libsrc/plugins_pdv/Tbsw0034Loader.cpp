/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "TBSW0034.hpp"
#include "plugins_pdv/Tbsw0034Loader.hpp"

namespace plugins_pdv
{
    base::Identificable* createTbsw0034Loader( )
    {
        Tbsw0034Loader* objetoLocal = new Tbsw0034Loader;
        return objetoLocal;
    }

    /// startConfiguration
    /// Prepara os parametros recebidos na chamada do plugin dentro do XML
    ///  sourceFieldPath: parametros para clausula WHERE 
    ///  targetFieldPath: parametros para receber as colunas resultantes do SELECT
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0034Loader::startConfiguration( const configBase::Tag* tagParametro )
    {
        configBase::TagList tagListLocal;

        tagParametro->findTag( "sourceFieldPath", tagListLocal );
        this->SetSourceFieldPath( tagListLocal.front().findProperty( "value" ).value() );
		
        tagParametro->findTag( "targetFieldPath", tagListLocal );
        this->SetTargetFieldPath( tagListLocal.front().findProperty( "value" ).value() );
        return true;
    }

    Tbsw0034Loader::Tbsw0034Loader( )
    {
    }

    Tbsw0034Loader::~Tbsw0034Loader( )
    {
    }

    /// init
    /// Prepara os parametros de entrada e saida
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0034Loader::init( )
    {
        /// Preparando as variaveis para receber as colunas do SELECT
        result                              = this->navigate( targetFieldPath + ".RESULT" );
        textoRelacionadoChip                = this->navigate( targetFieldPath + ".TXT_RLCD_CHIP" );
        textoInformacaoComplementarChip     = this->navigate( targetFieldPath + ".TXT_INFO_CMPM_CHIP" );
        textoResultadoAtualizacaoChip       = this->navigate( targetFieldPath + ".TXT_RSTD_ATLZ_CHIP" );
        indicadorNivelSegurancaKomerci      = this->navigate( targetFieldPath + ".IND_NVL_SGRA_KMRC" );
        dataMovimentoTransacao              = this->navigate( targetFieldPath + ".DAT_MOV_TRAN" );
        numeroSequencialUnico               = this->navigate( targetFieldPath + ".NUM_SEQ_UNC" );
        dataVendaChip                       = this->navigate( targetFieldPath + ".DAT_VD_CHIP" );
        codigoProgramaAutorizacao           = this->navigate( targetFieldPath + ".COD_PGM_AUT" );
        indicadorMetodoVerificacaoPortador  = this->navigate( targetFieldPath + ".IND_MTDO_VRFC_PORT" );
        indicadorPresencaSenha              = this->navigate( targetFieldPath + ".IND_PRSC_SNHA" );
        numeroSequencialCartaoValidacaoChip = this->navigate( targetFieldPath + ".NUM_SEQ_CAR_VLDC_CHIP" );
        nomePortadorCartao                  = this->navigate( targetFieldPath + ".NOM_PORT_CAR" );

        /// Preparando as variaveis para os parametros da clausula WHERE
        origDate = this->navigate( sourceFieldPath + ".shc_msg.origdate" );
        origRefnum = this->navigate( sourceFieldPath + ".segments.common.origrefnum" );

        return true;
    }

    void Tbsw0034Loader::finish( )
    {
    }

    /// execute
    /// Efetua o select da TBSW0034, passando no where a 
    ///  DATA e REFNUM da original
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    int Tbsw0034Loader::execute( bool& stopParametro )
    {
        try
        {
            std::ostringstream whereClauseLocal;
            unsigned long origDateLocal;
            unsigned long origRefnumLocal;

            /// Montando a clausula WHERE
            fieldSet::fsextr( origRefnumLocal, origRefnum );
            fieldSet::fsextr( origDateLocal, origDate );

            whereClauseLocal << "DAT_MOV_TRAN = " << origDateLocal << " AND NUM_SEQ_UNC = " << origRefnumLocal;

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0034 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, whereClauseLocal.str().c_str() );

            dbaccess_common::TBSW0034 Tbsw0034Local( whereClauseLocal.str() );

            Tbsw0034Local.prepare();
            Tbsw0034Local.execute();

            int retornoLocal = Tbsw0034Local.fetch();
            if ( !retornoLocal )
            {
                /// Select não retornou registro
                fieldSet::fscopy( result, "NO ROWS", 7 );
            }
            else
            {
                /// Select retornou registo
                fieldSet::fscopy( result, "OK", 2 );

                fieldSet::fscopy( textoRelacionadoChip,                 Tbsw0034Local.get_TXT_RLCD_CHIP( ) );
                fieldSet::fscopy( textoInformacaoComplementarChip,      Tbsw0034Local.get_TXT_INFO_CMPM_CHIP( ) );
                fieldSet::fscopy( textoResultadoAtualizacaoChip,        Tbsw0034Local.get_TXT_RSTD_ATLZ_CHIP( ) );
                fieldSet::fscopy( indicadorNivelSegurancaKomerci,       Tbsw0034Local.get_IND_NVL_SGRA_KMRC( ) );
                fieldSet::fscopy( dataMovimentoTransacao,               Tbsw0034Local.get_DAT_MOV_TRAN( ) );
                fieldSet::fscopy( numeroSequencialUnico,                Tbsw0034Local.get_NUM_SEQ_UNC( ) );
                fieldSet::fscopy( dataVendaChip,                        Tbsw0034Local.get_DAT_VD_CHIP( ) );
                fieldSet::fscopy( codigoProgramaAutorizacao,            Tbsw0034Local.get_COD_PGM_AUT( ) );
                fieldSet::fscopy( indicadorMetodoVerificacaoPortador,   Tbsw0034Local.get_IND_MTDO_VRFC_PORT( ) );
                fieldSet::fscopy( indicadorPresencaSenha,               Tbsw0034Local.get_IND_PRSC_SNHA( ) );
                fieldSet::fscopy( numeroSequencialCartaoValidacaoChip,  Tbsw0034Local.get_NUM_SEQ_CAR_VLDC_CHIP( ) );
                fieldSet::fscopy( nomePortadorCartao,                   Tbsw0034Local.get_NOM_PORT_CAR( ) );

            }
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "Exception in TBSW0034 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "std::exception in TBSW0034 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }

        stopParametro = false;
        return 0;
    }

    /// SetTargetFieldPath
    /// Define Target FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0034Loader& Tbsw0034Loader::SetTargetFieldPath( const std::string& pathParametro )
    {
        targetFieldPath = pathParametro;
        return *this;
    }

    /// SetSourceFieldPath
    /// Define Source FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0034Loader& Tbsw0034Loader::SetSourceFieldPath( const std::string& pathParametro )
    {
        sourceFieldPath = pathParametro;
        return *this;
    }
	
    dataManip::Command* Tbsw0034Loader::clone( ) const
    {
        return new Tbsw0034Loader(*this);
    }
}//namespace plugins_pdv

