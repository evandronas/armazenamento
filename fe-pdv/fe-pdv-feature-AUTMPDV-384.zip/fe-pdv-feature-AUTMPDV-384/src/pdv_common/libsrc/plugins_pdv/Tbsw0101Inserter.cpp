/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/Tbsw0101Inserter.hpp"
#include "dbaccess_pdv/Tbsw0101RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTbsw0101Inserter( )
    {
        Tbsw0101Inserter* objetoLocal = new Tbsw0101Inserter;
        return( objetoLocal );
    }

    Tbsw0101Inserter::Tbsw0101Inserter( )
    {
    }

    Tbsw0101Inserter::~Tbsw0101Inserter( )
    {
    }

    /// startConfiguration
    /// Prepara os parametros recebidos na chamada do plugin dentro do XML
    ///  sourceFieldPath: parametros com os dados para insercao 
    ///  targetFieldPath: parametros para enviar o status da operacao
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0101Inserter::startConfiguration( const configBase::Tag* tagParametro )
    {
        configBase::TagList tagListLocal;

        tagParametro->findTag( "sourceFieldPath", tagListLocal );
        std::string sourceLocal = tagListLocal.front( ).findProperty( "value" ).value( );
        this->SetSourceFieldPath( sourceLocal );

        tagParametro->findTag( "targetFieldPath", tagListLocal );
        std::string targetLocal = tagListLocal.front( ).findProperty( "value" ).value( );
        this->SetTargetFieldPath( targetLocal );

        return( true );
    }

    /// init
    /// Prepara os parametros de entrada e saida
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0101Inserter::init( )
    {
        result = this->navigate( targetFieldPath + ".RESULT" );

        localDate               = this->navigate( sourceFieldPath + ".shc_msg.local_date" );
        refnum                  = this->navigate( sourceFieldPath + ".shc_msg.refnum" );
        tokenAssuranceLevel     = this->navigate( sourceFieldPath + ".segments.common.tokenAssuranceLevel" );
        paymentAccountReference = this->navigate( sourceFieldPath + ".segments.common.paymentAccountReference" );

        return( true );
    }

    void Tbsw0101Inserter::finish( )
    {
    }

    /// execute
    /// Efetua o insert na TBSW0101
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    int Tbsw0101Inserter::execute( bool& stopParametro )
    {
        try
        {

            dbaccess_common::TBSW0101 table0101Local;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0101" );
            dbaccess_pdv::Tbsw0101RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0101_params params = { 0 };

            fieldSet::fsextr( params.local_date, localDate );
            fieldSet::fsextr( params.refnum, refnum );
            fieldSet::fsextr( params.tokenAssuranceLevel, tokenAssuranceLevel );
            fieldSet::fsextr( params.paymentAccountReference, paymentAccountReference );

            regrasFmt.DAT_MOV_TRAN     ( table0101Local, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC      ( table0101Local, params, acq_common::INSERT );
            regrasFmt.COD_NVL_SGRA_TKN ( table0101Local, params, acq_common::INSERT );
            regrasFmt.COD_REF_CTA_PGMN ( table0101Local, params, acq_common::INSERT );

            table0101Local.insert( );
            table0101Local.commit( );

            fieldSet::fscopy( result, "OK", 2 );
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "Exception in TBSW0101 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "std::exception in TBSW0101 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }

        stopParametro = false;
        return( 0 );
    }

    /// SetSourceFieldPath
    /// Define Source FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0101Inserter& Tbsw0101Inserter::SetSourceFieldPath( const std::string& pathParametro )
    {
        sourceFieldPath = pathParametro;
        return( *this );
    }

    /// SetTargetFieldPath
    /// Define Target FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0101Inserter& Tbsw0101Inserter::SetTargetFieldPath( const std::string& pathParametro )
    {
        targetFieldPath = pathParametro;
        return( *this );
    }

    dataManip::Command* Tbsw0101Inserter::clone( ) const
    {
        return( new Tbsw0101Inserter( *this ) );
    }

} // namespace plugins_pdv
