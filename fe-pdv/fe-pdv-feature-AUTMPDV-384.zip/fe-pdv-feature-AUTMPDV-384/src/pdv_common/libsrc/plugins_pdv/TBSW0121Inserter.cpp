#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0121Inserter.hpp"
#include "dbaccess_pdv/TBSW0121RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0121Inserter( )
    {
        TBSW0121Inserter* l_new = new TBSW0121Inserter;
        return( l_new );
    }
    
    TBSW0121Inserter::TBSW0121Inserter( )
    {
    }
    
    TBSW0121Inserter::~TBSW0121Inserter( )
    {
    }
    
    bool TBSW0121Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        
        return( true );
    }

    bool TBSW0121Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =      this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =          this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_codver =          this->navigate( m_sourceFieldPath + ".segments.common.codver" );
        m_termid =          this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
        m_cod_vers_sftw =   this->navigate( m_sourceFieldPath + ".segments.merchant.cod_vers_sftw" );
        m_ecr_sftw_verid =  this->navigate( m_sourceFieldPath + ".segments.common.ecr_sftw_verid" );

        return( true );
    }

    void TBSW0121Inserter::finish( )
    {
    }

    int TBSW0121Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0121 l_table0121;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0121" );
            dbaccess_pdv::TBSW0121RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0121_params params = { 0 };

            fieldSet::fsextr( params.local_date,        m_local_date );
            fieldSet::fsextr( params.refnum,            m_refnum );
            fieldSet::fsextr( params.codver,            m_codver );
            fieldSet::fsextr( params.termid,            m_termid );
            fieldSet::fsextr( params.cod_vers_sftw,     m_cod_vers_sftw );
            fieldSet::fsextr( params.ecr_sftw_verid,    m_ecr_sftw_verid );

            regrasFmt.DAT_MOV_TRAN       ( l_table0121, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC        ( l_table0121, params, acq_common::INSERT );
            regrasFmt.NUM_SRE_PNPD       ( l_table0121, params, acq_common::INSERT );
            regrasFmt.COD_CHCK_PDV       ( l_table0121, params, acq_common::INSERT );
            regrasFmt.COD_MODL_PNPD      ( l_table0121, params, acq_common::INSERT );
            regrasFmt.COD_VERS_BBLT_PNPD ( l_table0121, params, acq_common::INSERT );
            regrasFmt.COD_VERS_CHCK_PDV  ( l_table0121, params, acq_common::INSERT );
            regrasFmt.COD_VERS_SRVD_PDV  ( l_table0121, params, acq_common::INSERT );
            regrasFmt.COD_VERS_SIS       ( l_table0121, params, acq_common::INSERT );
            regrasFmt.COD_VERS_SFTW      ( l_table0121, params, acq_common::INSERT );

            l_table0121.insert( );
            l_table0121.commit( );

            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "NOT INSERTED", 12 );
            std::string l_msg = "Exception in TBSW0121 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "NOT INSERTED", 12 );
            std::string l_msg = "std::exception in TBSW0121 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return( 0 );
    }

    TBSW0121Inserter& TBSW0121Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    TBSW0121Inserter& TBSW0121Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0121Inserter::clone( ) const
    {
        return( new TBSW0121Inserter( *this ) );
    }

}//namespace standardAcqPlugins
