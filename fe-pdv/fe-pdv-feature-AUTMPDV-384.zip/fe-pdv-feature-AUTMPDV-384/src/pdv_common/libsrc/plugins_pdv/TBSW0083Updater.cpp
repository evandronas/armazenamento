/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0083Updater>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0083Updater>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, cken> / <698224, Raphael Gomes>
/ Data de Cria��o: <Fri Oct 26 15:21:52 2012
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0083.hpp"
#include "plugins_pdv/TBSW0083Updater.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "dbaccess_pdv/TBSW0083RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0083Updater()
    {
        TBSW0083Updater* l_new = new TBSW0083Updater;
        return l_new;
    }

    bool TBSW0083Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0083Updater::TBSW0083Updater()
    {
    }

    TBSW0083Updater::~TBSW0083Updater()
    {
    }

    bool TBSW0083Updater::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );   
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" ); 
        m_orig_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.orig_local_date" );
        m_avs_respcode = this->navigate( m_sourceFieldPath + ".segments.credit.avs_respcode" );
        return true;
    }

    void TBSW0083Updater::finish()
    {
    }

    int TBSW0083Updater::execute( bool& a_stop )
    {
        try
        {
			std::ostringstream l_whereClause;
			unsigned long l_msgtype, l_local_date, l_orig_local_date, l_refnum, l_origrefnum;

			fieldSet::fsextr( l_local_date, m_local_date );
			fieldSet::fsextr( l_refnum, m_refnum );
			fieldSet::fsextr( l_msgtype, m_msgtype );                    
			fieldSet::fsextr( l_origrefnum, m_origrefnum );
			fieldSet::fsextr( l_orig_local_date, m_orig_local_date );
			
			switch ( l_msgtype )
			{
			  case 110 :
			  case 210 :
			  case 230 :
						l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
						break;

			  case 410 :
			  case 430 :
						l_whereClause << "DAT_MOV_TRAN = " << l_orig_local_date << " AND NUM_SEQ_UNC = " << l_origrefnum;
						break;
              default:
                        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " EMPTY QUERY" );
                        fieldSet::fscopy( m_result, "ERROR", 5 );
						a_stop = false;
						return 0;				  
						break;
			}   

			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0083 ==========" );
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
            
            dbaccess_pdv::TBSW0083RegrasFormatacao regrasFormatacao;
            dbaccess_common::TBSW0083 tbsw0083( l_whereClause.str() );
            acq_common::tbsw0083_params tbsw0083_params = { 0 };

            tbsw0083.prepare_for_update();
            tbsw0083.execute();
            int ret = tbsw0083.fetch();
    
            if( !ret )
            {
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " NOT UPDATED" );
                fieldSet::fscopy( m_result, "ERROR", 5 );
            }
            else
            {
                fieldSet::fsextr( tbsw0083_params.avs_respcode, m_avs_respcode );
                regrasFormatacao.COD_RSPS_AVS( tbsw0083, tbsw0083_params, acq_common::INSERT ); 
    
                tbsw0083.update();
                tbsw0083.commit();
                fieldSet::fscopy( m_result, "OK", 2 );
    
            }
        }

        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0083 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0083 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW0083Updater& TBSW0083Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0083Updater& TBSW0083Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0083Updater::clone() const
    {
        return new TBSW0083Updater(*this);
    }
}//namespace plugins_pdv

