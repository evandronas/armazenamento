/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0083Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0083Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, cken>
/ Data de Cria��o: <Fri Oct 26 15:21:52 2012
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0083.hpp"
#include "plugins_pdv/TBSW0083Loader.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0083Loader()
    {
        TBSW0083Loader* l_new = new TBSW0083Loader;
        return l_new;
    }

    bool TBSW0083Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0083Loader::TBSW0083Loader()
    {
    }

    TBSW0083Loader::~TBSW0083Loader()
    {
    }

    bool TBSW0083Loader::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
		m_COD_CEP_PORT = this->navigate( m_targetFieldPath + ".COD_CEP_PORT" );
		m_COD_CEP_CMPM_PORT = this->navigate( m_targetFieldPath + ".COD_CEP_CMPM_PORT" );
		m_TXT_ENDR_PORT = this->navigate( m_targetFieldPath + ".TXT_ENDR_PORT" );
		m_NUM_CPF_PORT = this->navigate( m_targetFieldPath + ".NUM_CPF_PORT" );
		m_DAT_MOV_TRAN = this->navigate( m_targetFieldPath + ".DAT_MOV_TRAN" );
		m_NUM_SEQ_UNC = this->navigate( m_targetFieldPath + ".NUM_SEQ_UNC" );
		m_COD_RSPS_AVS = this->navigate( m_targetFieldPath + ".COD_RSPS_AVS" );
		m_TXT_CMPM_ENDR_PORT = this->navigate( m_targetFieldPath + ".TXT_CMPM_ENDR_PORT" );
		
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date");
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum");
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );   
		m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );	
		m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );      

        return true;
    }

    void TBSW0083Loader::finish()
    {
    }

    int TBSW0083Loader::execute( bool& a_stop )
    {
        try
        {
			std::ostringstream l_whereClause;
			unsigned long l_msgtype, l_local_date, l_origdate, l_refnum, l_origrefnum;
			
			fieldSet::fsextr( l_local_date, m_local_date );
			fieldSet::fsextr( l_refnum, m_refnum );
			fieldSet::fsextr( l_msgtype, m_msgtype );                    
			fieldSet::fsextr( l_origrefnum, m_origrefnum );
			fieldSet::fsextr( l_origdate, m_origdate );
			
			switch ( l_msgtype )
			{
				case 100 :
				case 200 :
					l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
				  break;

				case 220 :
				case 400 :
				case 420 :
					l_whereClause << "DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
				  break;
				default:
					fieldSet::fscopy( m_result, "EMPTY QUERY", 11 );
					a_stop = false;
					return 0;			
				break;
			}

            dbaccess_common::TBSW0083 l_TBSW0083( l_whereClause.str() );

            l_TBSW0083.prepare();
            l_TBSW0083.execute();
            int ret = l_TBSW0083.fetch();

            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "OK", 2 );
                
                char l_bufferTemp[64];
                oasis_dec_t l_dec_temp;

                l_dec_temp = l_TBSW0083.get_NUM_SEQ_UNC( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_NUM_SEQ_UNC, std::string( l_bufferTemp ) );

                fieldSet::fscopy( m_NUM_CPF_PORT, l_TBSW0083.get_NUM_CPF_PORT( ) );
                fieldSet::fscopy( m_COD_CEP_PORT, l_TBSW0083.get_COD_CEP_PORT() );
                fieldSet::fscopy( m_COD_CEP_CMPM_PORT, l_TBSW0083.get_COD_CEP_CMPM_PORT() );
                fieldSet::fscopy( m_TXT_ENDR_PORT, l_TBSW0083.get_TXT_ENDR_PORT() );
                fieldSet::fscopy( m_DAT_MOV_TRAN, l_TBSW0083.get_DAT_MOV_TRAN() );
                fieldSet::fscopy( m_COD_RSPS_AVS, l_TBSW0083.get_COD_RSPS_AVS() );
                fieldSet::fscopy( m_TXT_CMPM_ENDR_PORT, l_TBSW0083.get_TXT_CMPM_ENDR_PORT() );
            }
        }
		catch( base::GenException e )
		{
			fieldSet::fscopy( m_result, "ERROR", 5 );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0083 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			fieldSet::fscopy( m_result, "ERROR", 5 );
			std::string l_what( e.what( ) );
			std::string l_msg = "std::exception in TBSW0083 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		
		a_stop = false;
        return 0;
    }

    TBSW0083Loader& TBSW0083Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0083Loader& TBSW0083Loader::setSourceFieldPath( const std::string& a_path )
    {
          m_sourceFieldPath = a_path;
          return *this;
    }

    dataManip::Command* TBSW0083Loader::clone() const
    {
        return new TBSW0083Loader(*this);
    }
}//namespace plugins_pdv

