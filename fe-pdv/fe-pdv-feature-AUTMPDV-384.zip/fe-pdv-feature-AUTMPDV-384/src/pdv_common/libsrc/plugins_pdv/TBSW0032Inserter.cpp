#pragma once
#include <cstdio>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0032.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0032Inserter.hpp"
#include "dbaccess_pdv/TBSW0032RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0032Inserter( )
    {
        TBSW0032Inserter* l_new = new TBSW0032Inserter;            
        return( l_new );
    }
    
    TBSW0032Inserter::TBSW0032Inserter( )
    {
    }
    
    TBSW0032Inserter::~TBSW0032Inserter( )
    {
    }
    
    bool TBSW0032Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value( );
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        
        return( true );
    }
    
    bool TBSW0032Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =              this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =                  this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_nu_bco_etb =              this->navigate( m_sourceFieldPath + ".segments.merchant.nu_bco_etb" );
        m_iss_name =                this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_bin =                     this->navigate( m_sourceFieldPath + ".segments.common.bin" );
        m_nu_age_etb =              this->navigate( m_sourceFieldPath + ".segments.merchant.nu_age_etb" );
        m_cd_cta_etb =              this->navigate( m_sourceFieldPath + ".segments.merchant.cd_cta_etb" );
        m_cash_back =               this->navigate( m_sourceFieldPath + ".shc_msg.cash_back" );
        m_cap_positive_conf =       this->navigate( m_sourceFieldPath + ".segments.debt.cap_positive_conf" );
        m_cap_data_positive_conf =  this->navigate( m_sourceFieldPath + ".segments.debt.cap_data_positive_conf" );
        m_amount =                  this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
        m_tip_cob_tran_mtc =        this->navigate( m_localFieldPath + ".tip_cob_tran_mtc" );
        m_mc_info_cod_rvda_prod =   this->navigate( m_sourceFieldPath + ".segments.debt.mc_info_cod_rvda_prod" );
		m_val_cob_tran =            this->navigate( m_localFieldPath  + ".val_cob_tran" );
		m_respcode = 				this->navigate( m_sourceFieldPath + ".shc_msg.respcode" );
        // t719926 - GAPS Revisao do MER - 13/07/2016 - Inicio
        m_msg_category =            this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        // t719926 - GAPS Revisao do MER - 13/07/2016 - Fim

        return( true );
    }
    
    void TBSW0032Inserter::finish( )
    {
    }
    
    int TBSW0032Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0032 table0032;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0032" );
            dbaccess_pdv::TBSW0032RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0032_params params = { 0 };

            fieldSet::fsextr( params.local_date,            m_local_date );
            fieldSet::fsextr( params.refnum,                m_refnum );
            fieldSet::fsextr( params.nu_bco_etb,            m_nu_bco_etb );
            fieldSet::fsextr( params.iss_name,              m_iss_name );
            fieldSet::fsextr( params.bin,                   m_bin );
            fieldSet::fsextr( params.nu_age_etb,            m_nu_age_etb );
            fieldSet::fsextr( params.cd_cta_etb,            m_cd_cta_etb );
            fieldSet::fsextr( params.cash_back,             m_cash_back );
            fieldSet::fsextr( params.cap_positive_conf,     m_cap_positive_conf );
            fieldSet::fsextr( params.cap_data_positive_conf,m_cap_data_positive_conf );
            fieldSet::fsextr( params.amount,                m_amount );
            fieldSet::fsextr( params.tip_cob_tran_mtc,      m_tip_cob_tran_mtc );
            fieldSet::fsextr( params.mc_info_cod_rvda_prod, m_mc_info_cod_rvda_prod );
			fieldSet::fsextr( params.val_cob_tran,          m_val_cob_tran );
			fieldSet::fsextr( params.respcode,              m_respcode );
            // t719926 - GAPS Revisao do MER - 13/07/2016 - Inicio
            fieldSet::fsextr( params.msg_category,          m_msg_category );
            // t719926 - GAPS Revisao do MER - 13/07/2016 - Fim

            regrasFmt.DAT_MOV_TRAN      ( table0032, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC       ( table0032, params, acq_common::INSERT );
            regrasFmt.NUM_BCO_ESTB      ( table0032, params, acq_common::INSERT );
            regrasFmt.NUM_BCO_DEB       ( table0032, params, acq_common::INSERT );
            regrasFmt.NUM_EMSR          ( table0032, params, acq_common::INSERT );
            regrasFmt.NUM_AGE_ESTB      ( table0032, params, acq_common::INSERT );
            regrasFmt.COD_CTA_ESTB      ( table0032, params, acq_common::INSERT );
            regrasFmt.COD_VD_BCO        ( table0032, params, acq_common::INSERT );
            regrasFmt.VAL_SQUE          ( table0032, params, acq_common::INSERT );
            regrasFmt.IND_CNFR_PSTV     ( table0032, params, acq_common::INSERT );
            regrasFmt.IND_IMPR_CPOM     ( table0032, params, acq_common::INSERT );
            regrasFmt.QTD_DIA_CRNC      ( table0032, params, acq_common::INSERT );
            regrasFmt.TIP_RPSS_VAL      ( table0032, params, acq_common::INSERT );
            regrasFmt.VAL_RPSS          ( table0032, params, acq_common::INSERT );

            table0032.insert( );
            table0032.commit( );
            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0032 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0032 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        
        a_stop = false;
        return( 0 );
    }
    
    TBSW0032Inserter& TBSW0032Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0032Inserter& TBSW0032Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    
    TBSW0032Inserter& TBSW0032Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }    
    
    dataManip::Command* TBSW0032Inserter::clone( ) const
    {
        return( new TBSW0032Inserter( *this ) );
    }
} //namespace standardAcqPlugins


