/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::PedidosPreAutorizacao>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::PedidosPreAutorizacao>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <694037, Fernando Amaral>
/ Data de Cria��o: <Tue Aug 14 18:57:32 2012
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ 2013, 26 de Marco, t698224, Raphael Gomes/ t694450, Lauro Sanches, Tratamento de contigencia
/ ---------------------------------------------------------------------------
*********************** MODIFICA��ES ************************
Autor     : Gustavo Silva Franco
Data      : 02/08/2019
Empresa   : Rede
Descri��o : Mudando tratamento de contagem de pr�-autorizacoes ja existentes por estabelecimento
ID        : EAK 1645
*************************************************************
*/

#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0058.hpp"
#include "plugins_pdv/PedidosPreAutorizacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createPedidosPreAutorizacao()
    {
        PedidosPreAutorizacao* l_new = new PedidosPreAutorizacao;
        return l_new;
    }

    bool PedidosPreAutorizacao::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            std::string l_source = l_tagList.at( i ).findProperty( "value" ).value();
            
            if ( l_source == "LOCAL" )
                this->setLocalFieldPath( l_source );
            else
                this->setSourceFieldPath( l_source );
        }        
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    PedidosPreAutorizacao::PedidosPreAutorizacao()
    {
    }

    PedidosPreAutorizacao::~PedidosPreAutorizacao()
    {
    }

    bool PedidosPreAutorizacao::init()
    {
        std::string tb_components[] = {"RESULT", "COUNT"};

        for( unsigned int i = 0; i < LAST_TB_FIELD; i++ )
        {
            m_targetField[i] = this->navigate( m_targetFieldPath + "." + tb_components[i] );

            if( !m_targetField[i] )
            {
                std::string l_errorMsg(
                   "Invalid field path <" + m_targetFieldPath + ">"
                );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
        }
        
        std::string source_components[]
        =
        {
            "segments.common.orig_pan", "shc_msg.termloc", "shc_msg.receive_inst_id"
        };
        
        for ( unsigned int i = 0; i < LAST_SOURCE_FIELD; i++ )
        {
            m_sourceField[i]
            = this->navigate( m_sourceFieldPath + "." + source_components[i] );
            if ( !m_sourceField[i] )
            {
                std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + "." + source_components[i]
                + ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
        }
        
        std::string local_components[]
        =
        {
            "cod_gru_estb", "cod_mtz_estb"
        };
        
        for ( unsigned int i = 0; i < LAST_LOCAL_FIELD; i++ )
        {
            m_localField[i]
            = this->navigate( m_localFieldPath + "." + local_components[i] );
            if ( !m_localField[i] )
            {
                std::string l_errorMsg( "Field not found <" + m_localFieldPath + "." + local_components[i]
                + ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
        }        

        return true;
    }

    void PedidosPreAutorizacao::finish()
    {
    }

    int PedidosPreAutorizacao::execute( bool& a_stop )
    {
        try
        {
            std::string l_orig_pan;
            long l_termloc, l_cod_mtz_estb;
            std::ostringstream l_whereClause;
            std::string l_cod_gru_estb;
            
            fieldSet::fsextr( l_orig_pan, m_sourceField[ORIGPAN] );    
            fieldSet::fsextr( l_termloc, m_sourceField[TERMLOC] );            
            fieldSet::fsextr( l_cod_gru_estb, m_localField[COD_GRU_ESTB] );
            fieldSet::fsextr( l_cod_mtz_estb, m_localField[COD_MTZ_ESTB] );

            // EAK - 1645 - Igualando as regras de busca do POS
            if ( atol(l_cod_gru_estb.c_str()) != 0 ) {
                l_whereClause << "IND_STTU_TRAN='0' AND NUM_CAR='" << l_orig_pan <<
                "' AND DAT_VLD_PAUZ > LOCALTIMESTAMP AND COD_GRU_ESTB=" << l_cod_gru_estb.c_str();
            }
            else if (l_cod_mtz_estb == 0 ) {
                l_whereClause << "IND_STTU_TRAN='0' AND NUM_CAR='" << l_orig_pan <<
                "' AND DAT_VLD_PAUZ > LOCALTIMESTAMP " <<
                " AND ( NUM_ESTB=" << l_termloc << " OR COD_MTZ_ESTB=" << l_termloc << " )";
            }
            else {
                l_whereClause << "IND_STTU_TRAN='0' AND NUM_CAR='" << l_orig_pan <<
                        "' AND DAT_VLD_PAUZ > LOCALTIMESTAMP AND ( NUM_ESTB=" << l_termloc << " OR NUM_ESTB=" << l_cod_mtz_estb <<
                " OR COD_MTZ_ESTB=" << l_termloc << 
                " OR ( COD_MTZ_ESTB != 0 AND COD_MTZ_ESTB = " << l_cod_mtz_estb << " ) " << " )";
            }
  
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where PedidosPreAutorizacao ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );            

            dbaccess_common::TBSW0058 l_table0058( l_whereClause.str( ) );
            l_table0058.prepare( );
            l_table0058.execute( );
            
			int ret = l_table0058.fetch( );
            if( !ret )
            {
                this->setResult( "NO ROWS" );
                fieldSet::fscopy( m_targetField[COUNT], 0 );
            }
            else
            {
				while( l_table0058.fetch( ) )
                    ret++;

                this->setResult( "OK" );
                fieldSet::fscopy( m_targetField[COUNT], ret );
            }
        }
        catch( base::GenException e )
        {
            this->setResult( "ERROR" );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in PedidosPreAutorizacao <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            this->setResult( "ERROR" );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in PedidosPreAutorizacao <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        fieldSet::fscopy( m_targetField[0], getResult() );
        a_stop = false;
        return 0;
    }

    std::string PedidosPreAutorizacao::getResult( )
    {
        return m_result;
    }

    PedidosPreAutorizacao& PedidosPreAutorizacao::setResult( const std::string& a_result )
    {
        m_result = a_result;
        return *this;
    }

    PedidosPreAutorizacao& PedidosPreAutorizacao::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    PedidosPreAutorizacao& PedidosPreAutorizacao::setSourceFieldPath( const std::string& a_path )
    {
          m_sourceFieldPath = a_path;
          return *this;
    }
    
    PedidosPreAutorizacao& PedidosPreAutorizacao::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }    

    dataManip::Command* PedidosPreAutorizacao::clone() const
    {
        return new PedidosPreAutorizacao(*this);
    }
}//namespace plugins_pdv

