#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW2020Loader.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW2020Loader( )
    {
        TBSW2020Loader* l_new = new TBSW2020Loader;
        return l_new;
    }
    bool TBSW2020Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
        this->setTargetFieldPath( l_targetPath );
        return true;
    }
    TBSW2020Loader::TBSW2020Loader( )
    {
    }
    TBSW2020Loader::~TBSW2020Loader( )
    {
    }
    bool TBSW2020Loader::init( )
    {
        m_targetField = this->navigate( m_targetFieldPath );
        if ( !m_targetField )
        {
            std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ">" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        return true;
    }
    void TBSW2020Loader::finish( )
    {
    }
    int TBSW2020Loader::execute( bool& a_stop )
    {
        try
        {
            char ascii_nsu[64];
            oasis_dec_t dec_nsu = l_nsu.currentNsu( );
            memset( ascii_nsu, 0, sizeof( ascii_nsu ) );
            dbm_dectochar_conv( &dec_nsu, ascii_nsu, 0 );
            this->setResult( "OK" );
            fieldSet::fscopy( m_targetField, std::string( ascii_nsu ) );
        }
        catch( base::GenException e )
        {
            this->setResult( "ERROR" );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW2020 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW2020[" + l_what + "]";
        }
        a_stop = false;
        return 0;
    }
    TBSW2020Loader& TBSW2020Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
    TBSW2020Loader& TBSW2020Loader::setResult( const std::string& a_result )
    {
        m_result = a_result;
        return *this;
    }
    std::string TBSW2020Loader::getResult( )
    {
        return m_result;
    }
    dataManip::Command* TBSW2020Loader::clone( ) const
    {
        return new TBSW2020Loader( *this );
    }
}//namespace plugins_pdv

