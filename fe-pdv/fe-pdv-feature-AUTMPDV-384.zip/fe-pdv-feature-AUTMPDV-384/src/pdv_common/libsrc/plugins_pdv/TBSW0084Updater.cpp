/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0084Updater>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0084Updater>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <MATRICULA, NOME>
/ Data de Cria��o: <Thu Apr 11 10:38:44 2013
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0084.hpp"
#include "plugins_pdv/TBSW0084Updater.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

dbm_datetime_t f_datetime( long a_data, long a_time )
{
    struct tm l_dattim;
    char l_szdate[20], l_sztime[20];
    std::string l_date, l_time;

    memset( &l_dattim, 0, sizeof( l_dattim ) );
    sprintf( l_szdate, "%08d", a_data );
    sprintf( l_sztime, "%06d", a_time );
    l_date = l_szdate;
    l_time = l_sztime;
    l_dattim.tm_sec = atoi( l_time.substr( 4, 2 ).c_str( ) );
    l_dattim.tm_min = atoi( l_time.substr( 2, 2 ).c_str( ) );
    l_dattim.tm_hour = atoi( l_time.substr( 0, 2 ).c_str( ) );
    l_dattim.tm_mday = atoi( l_date.substr( 6, 2 ).c_str( ) );
    l_dattim.tm_mon = atoi( l_date.substr( 4, 2 ).c_str( ) ) - 1;
    l_dattim.tm_year = atoi( l_date.substr( 0, 4 ).c_str( ) ) - 1900;
    l_dattim.tm_isdst = -1;

    return( mktime( &l_dattim ) );
}

namespace plugins_pdv
{

    base::Identificable* createTBSW0084Updater()
    {
        TBSW0084Updater* l_new = new TBSW0084Updater;
        return l_new;
    }

    bool TBSW0084Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_source = l_tagList.front().findProperty( "value" ).value();
        this->setSourceFieldPath( l_source );

        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0084Updater::TBSW0084Updater()
    {
    }

    TBSW0084Updater::~TBSW0084Updater()
    {
    }

    bool TBSW0084Updater::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_48salad_84 = this->navigate( m_sourceFieldPath + ".segments.adm.statistics" );
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_terminal_pdv = this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        m_trace = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
        m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_cod_pnpd_pdv = this->navigate( m_sourceFieldPath + ".segments.adm.id_pinpad");
        m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );        
        return true;
    }

    void TBSW0084Updater::finish()
    {
    }

    int TBSW0084Updater::execute( bool& a_stop )
    {
        try
        {
			std::ostringstream l_whereClause;
			unsigned long l_local_date, l_msgtype;
			std::string l_terminal_pdv, l_refnum, l_origrefnum;
            oasis_dec_t l_dect;

			fieldSet::fsextr( l_local_date, m_local_date );
			fieldSet::fsextr( l_terminal_pdv, m_terminal_pdv );
            fieldSet::fsextr( l_refnum, m_refnum );
            fieldSet::fsextr( l_msgtype, m_msgtype );
            fieldSet::fsextr( l_origrefnum, m_origrefnum );

			l_whereClause << "DAT_MOV_TRAN = " << l_local_date;
            if( strlen( l_refnum.c_str() ) > 0 && ( l_msgtype == 100 || l_msgtype == 200 ) ) 
            {
                l_whereClause << " AND NUM_SEQ_UNC = " << l_refnum;
            }
            else if ( strlen( l_origrefnum.c_str() ) > 0 )
            {
                l_whereClause << " AND NUM_SEQ_UNC = " << l_origrefnum;
            }                       
			if( strlen( l_terminal_pdv.c_str() ) > 0 ) 
            {
                l_whereClause << " AND COD_TERM = '" << l_terminal_pdv << "'";
            }

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0084 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
            dbaccess_common::TBSW0084 l_table0084( l_whereClause.str() );

            l_table0084.prepare_for_update();
            l_table0084.execute();
            int ret = l_table0084.fetch();

            if( !ret )
            {
                fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {
                unsigned long l_ulong;
                std::string l_string;
                oasis_dec_t l_dect;

                //DAT_MOV_TRAN
                fieldSet::fsextr( l_ulong, m_local_date );
                l_table0084.set_DAT_MOV_TRAN( l_ulong );

                //DTH_INI_TRAN
                fieldSet::fsextr( l_ulong, m_local_time );
                l_table0084.set_DTH_INI_TRAN( f_datetime( l_table0084.get_DAT_MOV_TRAN(), l_ulong ) );

                //COD_TERM
                fieldSet::fsextr( l_string, m_terminal_pdv );
                if ( strlen(l_string.c_str()) > 0 ) l_table0084.set_COD_TERM( l_string );

                //NUM_STAN
                fieldSet::fsextr( l_ulong, m_trace );
                dbm_inttodec( &l_dect, l_ulong );
                l_table0084.set_NUM_STAN( l_dect );

                //NUM_ESTB
                fieldSet::fsextr( l_ulong, m_termloc );
                l_table0084.set_NUM_ESTB( l_ulong );

                //COD_PNPD_PDV
                fieldSet::fsextr( l_string, m_cod_pnpd_pdv );
                l_table0084.set_COD_PNPD_PDV( l_string );

                // DE048SALAD_84
                fieldSet::fsextr( l_string, m_48salad_84 );
                if( strlen( l_string.c_str() ) == 246 )
                {
                    //NOM_FBRC_PNPD
                    l_table0084.set_NOM_FBRC_PNPD( l_string.substr( 0, 20 ) );
                    //NUM_SRE_PNPD
                    l_table0084.set_NUM_SRE_PNPD( l_string.substr( 20, 20 ) );
                    //COD_VERS_HDW_PNPD
                    l_table0084.set_COD_VERS_HDW_PNPD( l_string.substr( 40, 20 ) );
                    //COD_VERS_FRWR_PNPD
                    l_table0084.set_COD_VERS_FRWR_PNPD( l_string.substr( 60, 20 ) );
                    //COD_VERS_SFTW_PNPD
                    l_table0084.set_COD_VERS_SFTW_PNPD( l_string.substr( 80, 20 ) );
                    //NOM_FBRC_TEF
                    l_table0084.set_NOM_FBRC_TEF( l_string.substr( 100, 20 ) );
                    //COD_VERS_SFTW_TEF
                    l_table0084.set_COD_VERS_SFTW_TEF( l_string.substr( 120, 20 ) );
                    //NOM_FBRC_ATMC
                    l_table0084.set_NOM_FBRC_ATMC( l_string.substr( 140, 20 ) );
                    //COD_VERS_SFTW_ATMC
                    l_table0084.set_COD_VERS_SFTW_ATMC( l_string.substr( 160, 20 ) );

                    //QTD_LEIT_MAGN
                    l_table0084.set_QTD_LEIT_MAGN( strtol( l_string.substr( 180, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_ERR_LEIT_MAGN
                    l_table0084.set_QTD_ERR_LEIT_MAGN( strtol( l_string.substr( 183, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_SNHA_MAGN
                    l_table0084.set_QTD_SNHA_MAGN( strtol( l_string.substr( 186, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_ERR_SNHA_MAGN
                    l_table0084.set_QTD_ERR_SNHA_MAGN( strtol( l_string.substr( 189, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_SNHA_CHIP_ONLN
                    l_table0084.set_QTD_SNHA_CHIP_ONLN( strtol( l_string.substr( 192, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_ERR_SNHA_CHIP_ONLN
                    l_table0084.set_QTD_ERR_SNHA_CHIP_ONLN( strtol( l_string.substr( 195, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_SNHA_CHIP_OFLN
                    l_table0084.set_QTD_SNHA_CHIP_OFLN( strtol( l_string.substr( 198, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_ERR_SNHA_CHIP_OFLN
                    l_table0084.set_QTD_ERR_SNHA_CHIP_OFLN( strtol( l_string.substr( 201, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_BLQDS_CHIP
                    l_table0084.set_QTD_BLQD_CHIP( strtol( l_string.substr( 204, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_LEIT_CHIP
                    l_table0084.set_QTD_LEIT_CHIP( strtol( l_string.substr( 207, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_FALLBACK_CRE
                    l_table0084.set_QTD_FALLBACK_CRE( strtol( l_string.substr( 210, 3 ).c_str( ), NULL, 10 ) );
                    //QTD_FALLBACK_DEB
                    l_table0084.set_QTD_FALLBACK_DEB( strtol( l_string.substr( 213, 3 ).c_str( ), NULL, 10 ) );
                }
                l_table0084.update();
                l_table0084.commit();
                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0084 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0084 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;

    }

    TBSW0084Updater& TBSW0084Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0084Updater& TBSW0084Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW0084Updater& TBSW0084Updater::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0084Updater::clone() const
    {
        return new TBSW0084Updater(*this);
    }
}//namespace plugins_pdv

