/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: .
/ Data de Cria��o: .
/ Hist�rico Mudan�as: ., Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "plugins_pdv/RangePL.hpp"

namespace plugins_pdv
{
	RangePL::RangePL()
	{
	}
	RangePL::~RangePL()
	{
	}

	//--------------------------- GET ---------------------------
    // TBSW0044
    unsigned long RangePL::get_NUM_PDV() const
    {
        return m_NUM_PDV;
    }
    oasis_dec_t RangePL::get_NUM_BIN_INI() const
    {
        return m_NUM_BIN_INI;
    }
    oasis_dec_t RangePL::get_NUM_BIN_FIM() const
    {
        return m_NUM_BIN_FIM;
    }
    unsigned long RangePL::get_COD_EMSR() const
    {
        return m_COD_EMSR;
    }
    const std::string& RangePL::get_COD_STTU_TRAN() const
    {
        return m_COD_STTU_TRAN;
    }
    dbm_datetime_t RangePL::get_DAT_ATLZ_REG() const
    {
        return m_DAT_ATLZ_REG;
    }
    const std::string& RangePL::get_COD_USR_ATLZ_REG() const
    {
        return m_COD_USR_ATLZ_REG;
    }
    const std::string& RangePL::get_IND_STTU_REG() const
    {
        return m_IND_STTU_REG;
    }
    // TBSW2011
    unsigned long RangePL::get_COD_ISSR_SW() const
    {
        return m_COD_ISSR_SW;
    }
    const std::string& RangePL::get_NOM_EMSR_SW() const
    {
        return m_NOM_EMSR_SW;
    }
    unsigned long RangePL::get_COD_EMSR_SW() const
    {
        return m_COD_EMSR_SW;
    }
    unsigned long RangePL::get_COD_BNDR() const
    {
        return m_COD_BNDR;
    }
    unsigned long RangePL::get_COD_FE_EMSR() const
    {
        return m_COD_FE_EMSR;
    }
    // TBSW2013
    unsigned long RangePL::get_COD_ROTA_PRVT_LBEL() const
    {
        return m_COD_ROTA_PRVT_LBEL;
    }
    const std::string& RangePL::get_NETWORK_ID() const
    {
        return m_NETWORK_ID;
    }
    const std::string& RangePL::get_NOM_FE_ACQR() const
    {
        return m_NOM_FE_ACQR;
    }
    const std::string& RangePL::get_NOM_HOST_ACQR() const
    {
        return m_NOM_HOST_ACQR;
    }

    bool RangePL::getIS_VALID() const
    {
        return m_IS_VALID;
    }

	//--------------------------- SET ---------------------------
    // TBSW0044
    void RangePL::set_NUM_PDV( unsigned long a_NUM_PDV )
    {
        m_NUM_PDV = a_NUM_PDV;
    }
    void RangePL::set_NUM_BIN_INI( oasis_dec_t a_NUM_BIN_INI )
    {
        m_NUM_BIN_INI = a_NUM_BIN_INI;
    }
    void RangePL::set_NUM_BIN_FIM( oasis_dec_t a_NUM_BIN_FIM )
    {
        m_NUM_BIN_FIM  = a_NUM_BIN_FIM;
    }
    void RangePL::set_COD_EMSR( unsigned long a_COD_EMSR )
    {
        m_COD_EMSR = a_COD_EMSR;
    }
    void RangePL::set_COD_STTU_TRAN( const std::string& a_COD_STTU_TRAN )
    {
        m_COD_STTU_TRAN = a_COD_STTU_TRAN;
    }
    void RangePL::set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
    {
        m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    void RangePL::set_COD_USR_ATLZ_REG( const std::string& a_COD_USR_ATLZ_REG )
    {
        m_COD_USR_ATLZ_REG = a_COD_USR_ATLZ_REG;
    }
    void RangePL::set_IND_STTU_REG( const std::string& a_IND_STTU_REG )
    {
        m_IND_STTU_REG = a_IND_STTU_REG;
    }

    // TBSW2011
    void RangePL::set_COD_ISSR_SW( unsigned long a_COD_ISSR_SW )
    {
        m_COD_ISSR_SW = a_COD_ISSR_SW;
    }
    void RangePL::set_NOM_EMSR_SW( const std::string& a_NOM_EMSR_SW )
    {
        m_NOM_EMSR_SW = a_NOM_EMSR_SW;
    }
    void RangePL::set_COD_EMSR_SW( unsigned long a_COD_EMSR_SW )
    {
        m_COD_EMSR_SW = a_COD_EMSR_SW;
    }
    void RangePL::set_COD_BNDR( unsigned long a_COD_BNDR )
    {
        m_COD_BNDR = a_COD_BNDR;
    }
    void RangePL::set_COD_FE_EMSR( unsigned long a_COD_FE_EMSR )
    {
        m_COD_FE_EMSR = a_COD_FE_EMSR;
    }
    // TBSW2013
    void RangePL::set_COD_ROTA_PRVT_LBEL( unsigned long a_COD_ROTA_PRVT_LBEL )
    {
        m_COD_ROTA_PRVT_LBEL = a_COD_ROTA_PRVT_LBEL;
    }
    void RangePL::set_NETWORK_ID( const std::string& a_NETWORK_ID )
    {
        m_NETWORK_ID = a_NETWORK_ID;
    }
    void RangePL::set_NOM_FE_ACQR( const std::string& a_NOM_FE_ACQR )
    {
        m_NOM_FE_ACQR = a_NOM_FE_ACQR;
    }
    void RangePL::set_NOM_HOST_ACQR( const std::string& a_NOM_HOST_ACQR )
    {
        m_NOM_HOST_ACQR = a_NOM_HOST_ACQR;
    }

	void RangePL::setIS_VALID( bool a_boolean )
	{
		m_IS_VALID = a_boolean;
	}

}

