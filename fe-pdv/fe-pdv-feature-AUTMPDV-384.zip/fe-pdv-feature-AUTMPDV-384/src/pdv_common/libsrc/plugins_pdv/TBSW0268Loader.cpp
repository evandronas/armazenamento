/* Copyright 2020 Rede S.A.
Autor  : Breder
Empresa: Rede
*/

#include <cstring>
#include "plugins_pdv/TBSW0268Loader.hpp"
#include "TBSW0268.hpp"

namespace plugins_pdv
{
    // Campos de retorno da TBSW0268
    enum TableFields
    {
        Result,
        CodigoBinInferior,
        CodigoBinSuperior,
        CodigoEntryMode,
        CodigoProduto,
        CodigoSituacaoRegistro,
        DataInclusaoRegistro,
        LastTableField
    };

    // Campo chave da tabela
    enum SourceFields
    {
        NumeroCartao,
        EntryMode,
        CodProd,
        LastSourceField
    };

    base::Identificable* CreateTBSW0268Loader()
    {
        TBSW0268Loader* TBSW0268LocalLoader = new TBSW0268Loader;

        return TBSW0268LocalLoader;
    }

    TBSW0268Loader::TBSW0268Loader()
    {
    }

    TBSW0268Loader::TBSW0268Loader( const std::string& where )
    {
    }

    TBSW0268Loader::~TBSW0268Loader()
    {
    }

    bool TBSW0268Loader::init()
    {

        std::string components[] = {"RESULT", "COD_BIN_INFR", "COD_BIN_SUPR", "COD_POS_ENTR_MODO", "COD_PROD_BLQO",
		                       "COD_STTU_REG", "DAT_INCL_REG"};

        for( unsigned int i = 0; i < LastTableField; i++ )
        {
            targetField[i] = this->navigate( targetFieldPath + "." + components[i] );

            if( !targetField[i] )
            {
                std::string errorMessage = "Invalid field path <";
                errorMessage.append(targetFieldPath);
                errorMessage.append(">");

                this->enableError( true );

                this->setErrorMessage( errorMessage );

                return false;
            }
        }

        std::string sourceComponents[] = {"NUMERO_CARTAO" , "ENTRY_MODE", "COD_PROD"};

        for( unsigned int i = 0; i < LastSourceField; i++ )
        {
            sourceField[i] = this->navigate( sourceFieldPath + "." + sourceComponents[i] );

            if( !sourceField[i] )
            {
                std::string errorMessage = "Field not found <";
                errorMessage.append(sourceFieldPath);
                errorMessage.append(".");
                errorMessage.append(sourceComponents[i]);
                errorMessage.append(">");

                this->enableError( true );

                this->setErrorMessage( errorMessage );

                return false;
            }
        }

        return true;
    }

    void TBSW0268Loader::finish()
    {
    }

    int TBSW0268Loader::execute( bool& a_stop )
    {
        try
        {
            // Obtem o numero do cartao
            std::string numeroCartao = "";
            fieldSet::fsextr( numeroCartao, sourceField[NumeroCartao] );

            // Obtem o entry mode
            std::string entryMode = "";
            fieldSet::fsextr( entryMode, sourceField[EntryMode] );

            // Obtem o codigo do produto
            std::string codigoProduto = "";
            fieldSet::fsextr( codigoProduto, sourceField[CodProd] );

            // Monta a clausla where
            std::string whereClause = " '";
            // where bin
            whereClause.append(numeroCartao);
            whereClause.append("'");
            whereClause.append(" BETWEEN COD_BIN_INFR AND COD_BIN_SUPR ");
            // where status
            whereClause.append(" AND COD_STTU_REG = '1'");
            // where produto
            whereClause.append(" AND (COD_PROD_BLQO = '*' OR COD_PROD_BLQO = '");
            whereClause.append(codigoProduto);
            whereClause.append("')");
            // where entry mode
            whereClause.append(" AND ( COD_POS_ENTR_MODO = '");
            whereClause.append(entryMode);
            whereClause.append("' OR COD_POS_ENTR_MODO = '***' )");

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= WHERE CLAUSE TBSW0268 =========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, whereClause.c_str(), strlen(whereClause.c_str()) );

            // Obtem os dados da tabela TBSW0268
            dbaccess_common::TBSW0268 TBSW0268( whereClause );
            TBSW0268.prepare();
            TBSW0268.execute();

            int ret = TBSW0268.fetch();

            if( !ret ) // Nao encontrou registro
            {
                this->SetStatus( "NO ROWS" );
            }
            else // Encontrou registro
            {
                this->SetStatus( "1" );

                char bufferTemporario[64] = {0};

                // Obtem os dados do registro encontrado da TBSW0268
                fieldSet::fscopy( targetField[CodigoBinInferior],      TBSW0268.GetCodigoBinInferior() );
                fieldSet::fscopy( targetField[CodigoBinSuperior],      TBSW0268.GetCodigoBinSuperior() );
                fieldSet::fscopy( targetField[CodigoEntryMode],        TBSW0268.GetCodigoEntryMode() );
                fieldSet::fscopy( targetField[CodigoProduto],          TBSW0268.GetCodigoProduto() );
                fieldSet::fscopy( targetField[DataInclusaoRegistro],   TBSW0268.GetDataInclusaoRegistro() );
                fieldSet::fscopy( targetField[CodigoSituacaoRegistro], TBSW0268.GetCodigoSituacaoRegistro() );
            }
        }
        catch( base::GenException exception )
        {
            this->SetStatus( "2" );

            std::string whatMessage( exception.what() );

            std::string errorMessage = "Exception in TBSW0268 <";
            errorMessage.append(whatMessage);
            errorMessage.append(">");

            this->enableError( true );

            this->setErrorMessage( errorMessage );

        }

        fieldSet::fscopy( targetField[Result], GetStatus() );

        a_stop = false;
        return 0;
    }

    dataManip::Command* TBSW0268Loader::clone() const
    {
        return new TBSW0268Loader(*this);
    }

    std::string TBSW0268Loader::GetStatus()
    {
        return status;
    }

    TBSW0268Loader& TBSW0268Loader::SetStatus( const std::string& status )
    {
        this->status = status;
        return *this;
    }

    TBSW0268Loader& TBSW0268Loader::SetTargetFieldPath( const std::string& path )
    {
        targetFieldPath = path;
        return *this;
    }

    TBSW0268Loader& TBSW0268Loader::SetSourceFieldPath( const std::string& path )
    {
          sourceFieldPath = path;
          return *this;
    }

    bool TBSW0268Loader::startConfiguration( const configBase::Tag* tag )
    {
        configBase::TagList tagList;

        tag->findTag( "sourceFieldPath", tagList );
        std::string l_sourcePath = tagList.front().findProperty( "value" ).value();

        tag->findTag( "targetFieldPath", tagList );
        std::string l_targetPath = tagList.front().findProperty( "value" ).value();

        this->SetSourceFieldPath( l_sourcePath );

        this->SetTargetFieldPath( l_targetPath );

        return true;
    }
}
