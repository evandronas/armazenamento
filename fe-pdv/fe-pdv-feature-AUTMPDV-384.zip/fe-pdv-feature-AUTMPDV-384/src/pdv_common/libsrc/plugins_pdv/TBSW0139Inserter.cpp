#pragma once
#include <cstdio>
#include <ctime>
#include <cctype>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbaccess_pdv/TBSW0139RegrasFormatacao.hpp"
#include "plugins_pdv/TBSW0139Inserter.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{

    base::Identificable* createTBSW0139Inserter( )
    {
        TBSW0139Inserter* l_new = new TBSW0139Inserter;
        return l_new;
    }

    bool TBSW0139Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value( );
            if ( l_source == "LOCAL" )
                this->setLocalFieldPath( l_source );
            else
                this->setSourceFieldPath( l_source );
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return true;
    }

    TBSW0139Inserter::TBSW0139Inserter( )
    {
    }

    TBSW0139Inserter::~TBSW0139Inserter( )
    {
    }

    bool TBSW0139Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =                  this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_termid =                      this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        m_indCripto =                   this->navigate( m_sourceFieldPath + ".segments.merchant.indCripto" );
        m_termloc =                     this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_nom_site_issr =               this->navigate( m_sourceFieldPath + ".segments.common.nom_site_issr" );
        m_nom_host_issr =               this->navigate( m_sourceFieldPath + ".segments.common.nom_host_issr" );
        m_nom_fe_issr =                 this->navigate( m_sourceFieldPath + ".segments.common.nom_fe_issr" );
        m_termid_type =                 this->navigate( m_sourceFieldPath + ".segments.common.termid_type" );
        m_codver =                      this->navigate( m_sourceFieldPath + ".segments.common.codver" );
        m_cod_vers_sftw =               this->navigate( m_sourceFieldPath + ".segments.merchant.cod_vers_sftw" );                 
        m_num_vers_clit =               this->navigate( m_sourceFieldPath + ".segments.merchant.num_vers_clit" );
        m_num_vers_aplv_rcd =           this->navigate( m_sourceFieldPath + ".segments.merchant.num_vers_aplv_rcd" );
        m_versSotfwBiblCompartPinpad =  this->navigate( m_sourceFieldPath + ".segments.merchant.versSotfwBiblCompartPinpad" );
        m_versEspecBiblCompartPinpad =  this->navigate( m_sourceFieldPath + ".segments.merchant.versEspecBiblCompartPinpad" );
        m_ecr_fabr_id =                 this->navigate( m_sourceFieldPath + ".segments.common.ecr_fabr_id" );
        m_ecr_sftw_verid =              this->navigate( m_sourceFieldPath + ".segments.common.ecr_sftw_verid" );

        return true;
    }

    void TBSW0139Inserter::finish( )
    {
    }

    int TBSW0139Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0139 l_table0139;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0139" );
            dbaccess_pdv::TBSW0139RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0139_params params = { 0 };

            fieldSet::fsextr( params.local_date,                    m_local_date );
            fieldSet::fsextr( params.termid,                        m_termid );
            fieldSet::fsextr( params.indCripto,                     m_indCripto );
            fieldSet::fsextr( params.termloc,                       m_termloc );
            fieldSet::fsextr( params.nom_site_issr,                 m_nom_site_issr );
            fieldSet::fsextr( params.nom_host_issr,                 m_nom_host_issr );
            fieldSet::fsextr( params.nom_fe_issr,                   m_nom_fe_issr );
            fieldSet::fsextr( params.termid_type,                   m_termid_type );
            fieldSet::fsextr( params.codver,                        m_codver );
            fieldSet::fsextr( params.cod_vers_sftw,                 m_cod_vers_sftw );
            fieldSet::fsextr( params.num_vers_clit,                 m_num_vers_clit );
            fieldSet::fsextr( params.num_vers_aplv_rcd,             m_num_vers_aplv_rcd );
            fieldSet::fsextr( params.versSotfwBiblCompartPinpad,    m_versSotfwBiblCompartPinpad );
            fieldSet::fsextr( params.versEspecBiblCompartPinpad,    m_versEspecBiblCompartPinpad );
            fieldSet::fsextr( params.ecr_fabr_id,                   m_ecr_fabr_id );
            fieldSet::fsextr( params.ecr_sftw_verid,                m_ecr_sftw_verid );
            params.nom_site_acqr = std::string( getenv( "NOM_SITE_ACQR" ) );
            params.nom_host_acqr = std::string( getenv( "NOM_HOST_ACQR" ) );
            params.nom_fe_acqr =   std::string( getenv( "NOM_FE_ACQR" ) );

            regrasFmt.DAT_MOV_TRAN           ( l_table0139, params, acq_common::INSERT );
            regrasFmt.COD_TERM               ( l_table0139, params, acq_common::INSERT );
            regrasFmt.COD_PNPD_PDV           ( l_table0139, params, acq_common::INSERT );
            regrasFmt.TIP_CIP                ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NUM_PDV                ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NUM_VERS_SRVD_PDV      ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NUM_VERS_CLIT          ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NUM_VERS_APLV_RCD      ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NUM_VERS_SFTW_BBLT_PNPD( l_table0139, params, acq_common::INSERT );
            regrasFmt.NUM_VERS_ESPF_BBLT_PNPD( l_table0139, params, acq_common::INSERT );
            regrasFmt.COD_FBRC_PDV           ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NOM_SITE_ACQR_ORGL     ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NOM_HOST_ACQR_ORGL     ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NOM_FE_ACQR_ORGL       ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NOM_SITE_ISSR          ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NOM_HOST_ISSR          ( l_table0139, params, acq_common::INSERT );
            regrasFmt.NOM_FE_ISSR            ( l_table0139, params, acq_common::INSERT );
            regrasFmt.TIP_GRU_TERM           ( l_table0139, params, acq_common::INSERT );

            l_table0139.insert( );
            l_table0139.commit( );

            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0139 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0139 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW0139Inserter& TBSW0139Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
    TBSW0139Inserter& TBSW0139Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW0139Inserter& TBSW0139Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0139Inserter::clone( ) const
    {
        return new TBSW0139Inserter( *this );
    }

} // namespace plugins_pdv
