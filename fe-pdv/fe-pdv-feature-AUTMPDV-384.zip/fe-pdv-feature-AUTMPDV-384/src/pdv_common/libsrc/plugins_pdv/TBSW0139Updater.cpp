#include "plugins_pdv/TBSW0139Updater.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0139Updater( )
    {
        TBSW0139Updater* l_new = new TBSW0139Updater;
        return l_new;
    }

    bool TBSW0139Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );

        this->setSourceFieldPath( l_sourcePath );

        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0139Updater::TBSW0139Updater( )
    {
    }

    TBSW0139Updater::~TBSW0139Updater( )
    {
    }

    bool TBSW0139Updater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =      this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_termid =          this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        m_indCripto =       this->navigate( m_sourceFieldPath + ".segments.merchant.indCripto" );
        m_nom_site_issr =   this->navigate( m_sourceFieldPath + ".segments.common.nom_site_issr" );
        m_nom_host_issr =   this->navigate( m_sourceFieldPath + ".segments.common.nom_host_issr" );
        m_nom_fe_issr =     this->navigate( m_sourceFieldPath + ".segments.common.nom_fe_issr" );

        return true;
    }

    void TBSW0139Updater::finish( )
    {
    }

    int TBSW0139Updater::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream  l_whereClause;
            unsigned long   l_local_date = 0;
            std::string     l_termid( "" );

            fieldSet::fsextr( l_local_date,     m_local_date );
            fieldSet::fsextr( l_termid,         m_termid );

            l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND ";
            l_whereClause << "COD_TERM = '" << l_termid << "'";

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0139 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );

            dbaccess_common::TBSW0139 l_table0139( l_whereClause.str( ) );
            dbaccess_pdv::TBSW0139RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0139_params params = { 0 };

            l_table0139.prepare_for_update( );
            l_table0139.execute( );
            int ret = l_table0139.fetch( );

            if ( !ret )
            {
                fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {
                fieldSet::fsextr( params.indCripto,     m_indCripto );
                fieldSet::fsextr( params.nom_site_issr, m_nom_site_issr );
                fieldSet::fsextr( params.nom_host_issr, m_nom_host_issr );
                fieldSet::fsextr( params.nom_fe_issr,   m_nom_fe_issr );
                params.nom_site_acqr =  std::string( getenv( "NOM_SITE_ACQR" ) );
                params.nom_host_acqr =  std::string( getenv( "NOM_HOST_ACQR" ) );
                params.nom_fe_acqr =    std::string( getenv( "NOM_FE_ACQR" ) );

                regrasFmt.TIP_CIP               ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NUM_VERS_CLIT         ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NUM_VERS_APLV_RCD     ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NOM_SITE_ACQR_ORGL    ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NOM_HOST_ACQR_ORGL    ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NOM_FE_ACQR_ORGL      ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NOM_SITE_ISSR         ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NOM_HOST_ISSR         ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NOM_FE_ISSR           ( l_table0139, params, acq_common::UPDATE );

                l_table0139.update( );
                l_table0139.commit( );

                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0139 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0139 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW0139Updater& TBSW0139Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0139Updater& TBSW0139Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0139Updater::clone( ) const
    {
        return new TBSW0139Updater( *this );
    }

} // namespace plugins_pdv
