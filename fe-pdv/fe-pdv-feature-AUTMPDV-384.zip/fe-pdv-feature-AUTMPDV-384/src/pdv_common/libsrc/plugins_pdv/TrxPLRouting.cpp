#pragma once
#include <cstring>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <string>
#include "dbaccess_pdv/RoutingPLTablesJoint.hpp"
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TrxPLRouting.hpp"
#include "plugins_pdv/RangePL.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
	base::Identificable* createTrxPLRouting( )
	{
		TrxPLRouting* l_new = new TrxPLRouting;
		return l_new;
	}
	bool TrxPLRouting::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "targetFieldPath", l_tagList );
		m_targetFieldPath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "sourceFieldPath", l_tagList );
		m_sourceFieldPath = l_tagList.front( ).findProperty( "value" ).value( );
		
		return true;
	}
	TrxPLRouting::TrxPLRouting( )
	{
	}
	TrxPLRouting::~TrxPLRouting( )
	{
	}
	bool TrxPLRouting::init( )
	{
        m_result = this->navigate( m_targetFieldPath + ".result" );

        m_num_pdv = this->navigate( m_targetFieldPath + ".NUM_PDV" );
        m_num_bin_ini = this->navigate( m_targetFieldPath + ".NUM_BIN_INI" );
        m_num_bin_fim = this->navigate( m_targetFieldPath + ".NUM_BIN_FIM" );
        m_cod_emsr = this->navigate( m_targetFieldPath + ".COD_EMSR" );
        m_cod_sttu_tran = this->navigate( m_targetFieldPath + ".COD_STTU_TRAN" );
        m_dat_atlz_reg = this->navigate( m_targetFieldPath + ".DAT_ATLZ_REG" );
        m_cod_usr_atlz_reg = this->navigate( m_targetFieldPath + ".COD_USR_ATLZ_REG" );
        m_ind_sttu_reg = this->navigate( m_targetFieldPath + ".IND_STTU_REG" );

        m_cod_issr_sw = this->navigate( m_targetFieldPath + ".COD_ISSR_SW" );
        m_nom_emsr_sw = this->navigate( m_targetFieldPath + ".NOM_EMSR_SW" );
        m_cod_emsr_sw = this->navigate( m_targetFieldPath + ".COD_EMSR_SW" );
        m_cod_bndr = this->navigate( m_targetFieldPath + ".COD_BNDR" );
        m_cod_fe_emsr = this->navigate( m_targetFieldPath + ".COD_FE_EMSR" );

        m_cod_rota_prvt_lbel = this->navigate( m_targetFieldPath + ".COD_ROTA_PRVT_LBEL" );
        m_network_id = this->navigate( m_targetFieldPath + ".NETWORK_ID" );
        m_nom_fe_acqr = this->navigate( m_targetFieldPath + ".NOM_FE_ACQR" );
        m_nom_host_acqr = this->navigate( m_targetFieldPath + ".NOM_HOST_ACQR" );
        
        m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_pan = this->navigate( m_sourceFieldPath + ".shc_msg.pan" );       
 
		return true;

	}
	void TrxPLRouting::finish( )
	{
	}
	int TrxPLRouting::execute( bool& a_stop )
	{
		try
		{
            std::ostringstream l_whereClause;
            
            unsigned long l_termloc;
            fieldSet::fsextr( l_termloc, m_termloc );

            std::string l_pan;
            fieldSet::fsextr( l_pan, m_pan );

			l_whereClause << " TB_ROTA.NUM_PDV = " << l_termloc;
			l_whereClause << " AND ( " << l_pan;
            l_whereClause << " BETWEEN TB_ROTA.NUM_BIN_INI AND TB_ROTA.NUM_BIN_FIM )";
            l_whereClause << " AND TB_ROTA.IND_STTU_REG = 'A'";
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TrxPLRouting ==========" );
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
            
            dbaccess_pdv::RoutingPLTablesJoint l_Route( l_whereClause.str() );

            std::string aux = l_Route.getSelect();

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Select RoutingPLTablesJoint ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, aux.c_str() );

            l_Route.prepare();
            l_Route.execute();
            int ret = l_Route.fetch();
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                char l_bufferTemp[64];
                oasis_dec_t l_dec_temp;
                
                fieldSet::fscopy( m_result, "OK", 2 );

                fieldSet::fscopy( m_num_pdv, l_Route.get_NUM_PDV() );

                l_dec_temp = l_Route.get_NUM_BIN_INI( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_bin_ini, std::string( l_bufferTemp ) );

                l_dec_temp = l_Route.get_NUM_BIN_FIM( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_bin_fim, std::string( l_bufferTemp ) );

                fieldSet::fscopy( m_cod_emsr, l_Route.get_COD_EMSR() );
                fieldSet::fscopy( m_cod_sttu_tran, l_Route.get_COD_STTU_TRAN() );
                fieldSet::fscopy( m_dat_atlz_reg, l_Route.get_DAT_ATLZ_REG() );
                fieldSet::fscopy( m_cod_usr_atlz_reg, l_Route.get_COD_USR_ATLZ_REG() );
                fieldSet::fscopy( m_ind_sttu_reg, l_Route.get_IND_STTU_REG() );
                
                fieldSet::fscopy( m_cod_issr_sw, l_Route.get_COD_ISSR_SW( ) );
                fieldSet::fscopy( m_nom_emsr_sw, l_Route.get_NOM_EMSR_SW( ) );
                fieldSet::fscopy( m_cod_emsr_sw, l_Route.get_COD_EMSR_SW( ) );
                fieldSet::fscopy( m_cod_bndr, l_Route.get_COD_BNDR( ) );
                fieldSet::fscopy( m_cod_fe_emsr, l_Route.get_COD_FE_EMSR( ) );

                fieldSet::fscopy( m_cod_rota_prvt_lbel, l_Route.get_COD_ROTA_PRVT_LBEL( ) );
                fieldSet::fscopy( m_network_id, l_Route.get_NETWORK_ID( ) );
                fieldSet::fscopy( m_nom_fe_acqr, l_Route.get_NOM_FE_ACQR( ) );
                fieldSet::fscopy( m_nom_host_acqr, l_Route.get_NOM_HOST_ACQR( ) );

            }//else
        
        }//try    
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TrxPLRouting <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TrxPLRouting <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
		a_stop = false;
		return 0;
	}
	dataManip::Command* TrxPLRouting::clone( ) const
	{
		return new TrxPLRouting( *this );
	}
}//namespace plugins_pdv
