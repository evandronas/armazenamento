#pragma once
#include <sstream>
#include <ctime>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/GetTrack2ServiceCode.hpp"

namespace plugins_pdv
{
	base::Identificable* createGetTrack2ServiceCode( )
	{
		GetTrack2ServiceCode* l_new = new GetTrack2ServiceCode;
		return l_new;
	}
	GetTrack2ServiceCode::GetTrack2ServiceCode( )
	{
	}
	GetTrack2ServiceCode::~GetTrack2ServiceCode( )
	{
	}
	bool GetTrack2ServiceCode::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "sourceFieldPath", l_tagList );
		std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "targetFieldPath", l_tagList );
		std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setSourceFieldPath( l_sourcePath );
		this->setTargetFieldPath( l_targetPath );
		return true;
	}
	bool GetTrack2ServiceCode::init( )
	{
		m_sourceField = this->navigate( m_sourceFieldPath );
		m_targetField = this->navigate( m_targetFieldPath );
		if ( !m_sourceField )
		{
			std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		if ( !m_targetField )
		{
			std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		return true;
	}
	void GetTrack2ServiceCode::finish( )
	{
	}
	int GetTrack2ServiceCode::execute( bool& a_stop )
	{
		std::string l_track2;
		char track2Buf[100];
		char *s;
		char srv_cd[5];
		
		srv_cd[0] = 0;
		fieldSet::fsextr( l_track2, m_sourceField );
		std::strcpy(track2Buf, l_track2.c_str());
		if((s = strchr(track2Buf, '=')) || (s = strchr(track2Buf, 'D')))
		{
			if(strlen(s) -8 >= 0) { 
				strncpy(srv_cd, s + 5, 3);
				srv_cd[3] = 0;
			}
		}
		this->setTargetFieldPath(std::string(srv_cd));
		fieldSet::fscopy( m_targetField, m_targetFieldPath );
		a_stop = false;
		return 0;
	}
	GetTrack2ServiceCode& GetTrack2ServiceCode::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	GetTrack2ServiceCode& GetTrack2ServiceCode::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	dataManip::Command* GetTrack2ServiceCode::clone( ) const
	{
		return new GetTrack2ServiceCode( *this );
	}
}//namespace plugins_pdv

