#pragma once

#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>

#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "defines.hpp"
//TODOSW75 #include "dualHandler.hpp"
#include "TBSW0030.hpp"
#include "plugins_pdv/TBSW0030RevIssUpdater.hpp"
#include "dbaccess_pdv/TBSW0030RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0030RevIssUpdater( )
    {
        TBSW0030RevIssUpdater* l_new = new TBSW0030RevIssUpdater;
        return( l_new );
    }

    TBSW0030RevIssUpdater::TBSW0030RevIssUpdater( )
    {
    }

    TBSW0030RevIssUpdater::~TBSW0030RevIssUpdater( )
    {
    }

    bool TBSW0030RevIssUpdater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return( true );
    }

    bool TBSW0030RevIssUpdater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_issuer = this->navigate( m_sourceFieldPath + ".shc_msg.issuer" );
        m_nom_site_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_site_issr" );
        m_nom_fe_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_fe_issr" );
        m_nom_host_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_host_issr" );
        m_settlement_date = this->navigate( m_sourceFieldPath + ".shc_msg.settlement_date" );
        m_iss_name = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_mc_info_ica = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_ica" );
        categoriaMensagem = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        quemNegou      = this->navigate( m_sourceFieldPath + ".segments.common.quem_negou" );
        codigoAcquirer = this->navigate( m_sourceFieldPath + ".segments.credit.cod_istt_acqr" );
        codigoIssuer   = this->navigate( m_sourceFieldPath + ".segments.credit.cod_istt_frwd" );
        codigoOrigemRespostaAutorizacao = this->navigate( m_sourceFieldPath + ".segments.common.codigoOrigemRespostaAutorizacao" );


        return( true );
    }

    void TBSW0030RevIssUpdater::finish( )
    {
    }

    int TBSW0030RevIssUpdater::execute( bool& a_stop )
    {
        try
        {
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Updating in TBSW0030 =========" );
            std::ostringstream l_whereClause;
            unsigned long l_msgtype;
            unsigned long l_local_date;
            unsigned long l_refnum;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );
            fieldSet::fsextr( l_msgtype, m_msgtype );
          
            {
                switch ( l_msgtype )
                {
                    case 430 :
                        l_whereClause << " DAT_MOV_TRAN = " << l_local_date
                                      << " AND NUM_SEQ_UNC = " << l_refnum;
                        break;
                    default:
                        fieldSet::fscopy( m_result, "ERROR", 5 );
                        a_stop = false;
                        return 0;
                        break;
                }

            }

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0030 - UPDATE ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );
            
            dbaccess_common::TBSW0030 tbsw0030( l_whereClause.str( ) );
            dbaccess_pdv::TBSW0030RegrasFormatacao regrasFmt;
            acq_common::tbsw0030_params st_tbsw0030 = {0};

            tbsw0030.prepare_for_update( );
            tbsw0030.execute( );

            //TODOSW75 
            /***
            dbaccess_common::DualHandler l_dualHand( &tbsw0030 );
            if ( l_dualHand.fetch( dbaccess::table::UPDATE ) )
            ***/
            if ( tbsw0030.fetch( ) )
            {
                tbsw0030.let_as_is( );

                fieldSet::fsextr( st_tbsw0030.issuer, m_issuer );
                fieldSet::fsextr( st_tbsw0030.nom_site_issr, m_nom_site_issr );
                fieldSet::fsextr( st_tbsw0030.nom_fe_issr, m_nom_fe_issr );
                fieldSet::fsextr( st_tbsw0030.nom_host_issr, m_nom_host_issr );
                fieldSet::fsextr( st_tbsw0030.settlement_date, m_settlement_date );
                fieldSet::fsextr( st_tbsw0030.iss_name, m_iss_name );
                fieldSet::fsextr( st_tbsw0030.mc_info_ica, m_mc_info_ica );
                fieldSet::fsextr( st_tbsw0030.msg_category, categoriaMensagem );
                fieldSet::fsextr( st_tbsw0030.quem_negou, quemNegou );
                fieldSet::fsextr( st_tbsw0030.cod_istt_acqr, codigoAcquirer );
                fieldSet::fsextr( st_tbsw0030.cod_istt_frwd, codigoIssuer );
                fieldSet::fsextr( st_tbsw0030.codigoOrigemRespostaAutorizacao, codigoOrigemRespostaAutorizacao );

                regrasFmt.NOM_SITE_ISSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NOM_HOST_ISSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NOM_FE_ISSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_NTWK_ID_ISSR_ATLZ( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NUM_ID_CAR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_ISTT_ACQR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_ISTT_FRWD( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_ORG_APRV( tbsw0030, st_tbsw0030, acq_common::UPDATE );

                tbsw0030.update( );
                tbsw0030.commit( );
                fieldSet::fscopy( m_result, "OK", 2 );
            }
            else
            {
                fieldSet::fscopy( m_result, "ORIGINAL TRANSACTION NOT FOUND", 30 );
            }
        }
        catch( base::GenException e )
        {
            std::string l_what( e.what( ) );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0030 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            std::string l_what( e.what( ) );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0030 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }

    TBSW0030RevIssUpdater& TBSW0030RevIssUpdater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0030RevIssUpdater& TBSW0030RevIssUpdater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    TBSW0030RevIssUpdater& TBSW0030RevIssUpdater::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0030RevIssUpdater::clone( ) const
    {
        return( new TBSW0030RevIssUpdater( *this ) );
    }
}//namespace standardAcqPlugins

