/******************HISTORICO DE MUDANCAS***********************
/
/ *************************************************************
/ Autor    : Paulo Bueno
/ Data     : 05/09/2018
/ Empresa  : REDE
/ Descri��o: Mudanca do mapeamento do campo m_mc_info_cod_rvda_prod
		   : para o segmento correto
/ ID       : DP-2018-0029979 - IC de Debito
/ *************************************************************
*/

#pragma once
#include <cstdio>
#include <shcdef.h>
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0032.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0032Updater.hpp"
#include "dbaccess_pdv/TBSW0032RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <iostream>

namespace plugins_pdv
{
    base::Identificable* createTBSW0032Updater( )
    {
        TBSW0032Updater* l_new = new TBSW0032Updater;
        return( l_new );
    }

    TBSW0032Updater::TBSW0032Updater( )
    {
    }

    TBSW0032Updater::~TBSW0032Updater( )
    {
    }

    bool TBSW0032Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return( true );
    }

    bool TBSW0032Updater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =              this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =                  this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_msgtype =                 this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_origrefnum =              this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_orig_local_date =         this->navigate( m_sourceFieldPath + ".segments.common.orig_local_date" );
        m_iss_name =                this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_ind_car_mltp =            this->navigate( m_sourceFieldPath + ".segments.common.ind_car_mltp" );
        m_mc_info_prod_code =       this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_prod_code" );
        m_trxTaxa =                 this->navigate( m_sourceFieldPath + ".segments.debt.trxTaxa" );
        m_vlTrfTxaMtc =             this->navigate( m_sourceFieldPath + ".segments.debt.vlTrfTxaMtc" );
		/* DP-2018-0029979 - IC de Debito - INICIO */
        m_mc_info_cod_rvda_prod =   this->navigate( m_sourceFieldPath + ".segments.common.cod_rvda_prod_mtc" );
		/* DP-2018-0029979 - IC de Debito - FIM */
        m_amount =                  this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
        m_respcode =                this->navigate( m_sourceFieldPath + ".shc_msg.respcode" );
		m_status =                  this->navigate( m_sourceFieldPath + ".segments.common.status" );

        return( true );
    }

    void TBSW0032Updater::finish( )
    {
    }

    int TBSW0032Updater::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_msgtype;
            unsigned long l_local_date;
            unsigned long l_refnum;
            unsigned long l_orig_local_date;
            unsigned long l_origrefnum;
            unsigned long l_respcode;

            fieldSet::fsextr( l_msgtype,    m_msgtype );
            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum,     m_refnum );
            fieldSet::fsextr( l_orig_local_date, m_orig_local_date );
            fieldSet::fsextr( l_origrefnum, m_origrefnum );
            fieldSet::fsextr( l_respcode,   m_respcode );

            switch ( l_msgtype )
            {
                case 110 :
                case 210 :
                case 230 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
                    break;

                case 410 :
                case 430 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_orig_local_date << " AND NUM_SEQ_UNC = " << l_origrefnum;
                    break;

                default:

                    logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " EMPTY QUERY" );
                    fieldSet::fscopy( m_result, "ERROR", 5 );
                    a_stop = false;
                    return( 0 );
                    break;
            }

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0032 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );

            dbaccess_common::TBSW0032 table0032( l_whereClause.str( ) );
            dbaccess_pdv::TBSW0032RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0032_params params = { 0 };

            table0032.prepare_for_update( );
            table0032.execute( );
            int ret = table0032.fetch( );
            if ( !ret )
            {
                logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " NOT UPDATED" );
                fieldSet::fscopy( m_result, "ERROR", 5 );
            }
            else
            {
                table0032.let_as_is( );

                fieldSet::fsextr( params.iss_name,              m_iss_name );
                fieldSet::fsextr( params.ind_car_mltp,          m_ind_car_mltp );
                fieldSet::fsextr( params.mc_info_prod_code,     m_mc_info_prod_code );
                fieldSet::fsextr( params.trxTaxa,               m_trxTaxa );
                fieldSet::fsextr( params.vlTrfTxaMtc,           m_vlTrfTxaMtc );
                fieldSet::fsextr( params.mc_info_cod_rvda_prod, m_mc_info_cod_rvda_prod );
                fieldSet::fsextr( params.amount2,               m_amount );
				fieldSet::fsextr( params.amount,                m_amount );
				fieldSet::fsextr( params.status,                m_status );

                regrasFmt.VAL_RPSS          ( table0032, params, acq_common::UPDATE );
                regrasFmt.VAL_LQDC          ( table0032, params, acq_common::UPDATE );
                regrasFmt.NUM_BCO_DEB       ( table0032, params, acq_common::UPDATE );
                regrasFmt.IND_CAR_MLTP      ( table0032, params, acq_common::UPDATE );
                regrasFmt.COD_RVDA_PROD_MTC ( table0032, params, acq_common::UPDATE );

                table0032.update( );
                table0032.commit( );
                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0032 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception  e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0032 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }

    TBSW0032Updater& TBSW0032Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0032Updater& TBSW0032Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0032Updater::clone( ) const
    {
        return( new TBSW0032Updater( *this ) );
    }
} //namespace standardAcqPlugins


