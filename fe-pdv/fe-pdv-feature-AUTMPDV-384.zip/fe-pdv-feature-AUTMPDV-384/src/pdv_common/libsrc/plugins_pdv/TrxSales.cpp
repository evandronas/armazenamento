/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TRXSales>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TRXSales>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694449, Fernando Ramires>
/ Data de Criação: <Mon Apr 29 08:48:00 2013>
/ Historico Mudancas: 
/   27-07-13, TRX Sales, 694449, incluido e modificado tratamento para sem resumo
/   27-07-13, TRX Sales, 694449, inclusao das querys no logs
/   22-05-13, TRX Sales, 689066, adaptacao para o pdv
/   11-05-13, TRX Sales, 694449, Versao Inicial
/ 
/ ---------------------------------------------------------------------------

/* Copyright 2018 Rede S.A.
Autor : FIDELITY
Empresa : REDE

*********************** MODIFICACOES ************************
Autor    : Arthur Henrique 
Data     : 18/07/2018 
Empresa  : Rede 
Descrição: Correções de problemas de inspeção de código fonte 'Switch sem default'.
ID       : 227.478
************************************************************* 
Autor    : Daniel Nava 
Data     : 16/12/2019 
Empresa  : Rede 
Descrição: Retirada da atualizacao do status do resumo na consulta
ID       : EAK-1902
************************************************************* 
Autor    : Daniel Nava 
Data     : 17/12/2019 
Empresa  : Rede 
Descrição: Inclusao de "let as is" e ajustes no layout
ID       : EAK-1898
************************************************************* 
Autor    : Daniel Nava 
Data     : 28/02/2020
Empresa  : Rede 
Descrição: Ajustes no layout
ID       : EAK-2419
************************************************************* 
*/

#pragma once
#include <cstring>
#include "plugins_pdv/TrxSales.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTrxSales( )
    {
        TrxSales* l_new = new TrxSales;
        return( l_new );
    }

    bool TrxSales::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;  
        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
        this->setSourceFieldPath( l_sourcePath );
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
        this->setTargetFieldPath( l_targetPath );
        return( true );
    }

    TrxSales::TrxSales( )
    {        
    }

    TrxSales::~TrxSales( )
    {
    }

    dataManip::Command* TrxSales::clone( ) const
    {
        return( new TrxSales( *this ) );
    }
    
    bool TrxSales::init( )
    {            
        std::string l_errorMsg;
        m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );                     
        if ( !m_termloc )
        {
            l_errorMsg.assign( "Invalid m_termloc path <" + m_sourceFieldPath + ">.shc_msg.termloc" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }        
        m_termpdvid  = this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        if ( !m_termpdvid )
        {
            l_errorMsg.assign( "Invalid m_termpdvid path <" + m_sourceFieldPath + ">.segments.common.terminal_pdv" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_refnum  = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );                  
        if ( !m_refnum )
        {
            l_errorMsg.assign( "Invalid m_refnum path <" + m_sourceFieldPath + ">.shc_msg.refnum" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_merName  = this->navigate( m_sourceFieldPath + ".segments.merchant.mer_name" );    
        if ( !m_merName )
        {
            l_errorMsg.assign( "Invalid m_merName path <" + m_sourceFieldPath + ">.segments.merchant.mer_name" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_inTpoTcn = this->navigate( m_sourceFieldPath + ".segments.merchant.in_tpo_tcn" ); 
        if ( !m_inTpoTcn )
        {
            l_errorMsg.assign( "Invalid m_inTpoTcn path <" + m_sourceFieldPath + ">.segments.merchant.in_tpo_tcn" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_trace = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );                     
        if ( !m_trace )
        {
            l_errorMsg.assign( "Invalid m_trace path <" + m_sourceFieldPath + ">.shc_msg.trace" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_swmsgNuRv = this->navigate( m_targetFieldPath + ".SWMSG_NU_RV" );
        if ( !m_swmsgNuRv )
        {
            l_errorMsg.assign( "Invalid m_swmsgNuRv path <" + m_targetFieldPath + ">.SWMSG_NU_RV" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_swmsgDtRv = this->navigate( m_targetFieldPath + ".SWMSG_DT_RV" );
        if ( !m_swmsgDtRv )
        {
            l_errorMsg.assign( "Invalid m_swmsgDtRv path <" + m_targetFieldPath + ">.SWMSG_DT_RV" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_shcMsgAmount = this->navigate( m_targetFieldPath + ".SHC_MSG_AMOUNT" );
        if ( !m_shcMsgAmount )
        {
            l_errorMsg.assign( "Invalid m_shcMsgAmount path <" + m_targetFieldPath + ">.SHC_MSG_AMOUNT" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_shcMsgShiftNumber = this->navigate( m_targetFieldPath + ".SHC_MSG_SHIFT_NUMBER" );
        if ( !m_shcMsgShiftNumber )
        {
            l_errorMsg.assign( "Invalid m_shcMsgShiftNumber path <" + m_targetFieldPath + ">.SHC_MSG_SHIFT_NUMBER" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_shcMsgActualAmount = this->navigate( m_targetFieldPath + ".SHC_MSG_ACTUAL_AMOUNT" );
        if ( !m_shcMsgActualAmount )
        {
            l_errorMsg.assign( "Invalid m_shcMsgActualAmount path <" + m_targetFieldPath + ">.SHC_MSG_ACTUAL_AMOUNT" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_report = this->navigate( m_targetFieldPath + ".REPORT" );
        if ( !m_report )
        {
            l_errorMsg.assign( "Invalid m_report path <" + m_targetFieldPath + ">.REPORT" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_returnCode = this->navigate( m_targetFieldPath + ".RET" );
        if ( !m_returnCode )
        {
            l_errorMsg.assign( "Invalid m_returnCode path <" + m_targetFieldPath + ">.RET" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );        
        if ( !m_result )
        {
            l_errorMsg.assign( "Invalid m_result path <" + m_targetFieldPath + ">.RESULT" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }   
        return true;
    }
    
    void TrxSales::finish( )
    {
    }
    
    TrxSales& TrxSales::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    
    TrxSales& TrxSales::setSourceFieldPath( const std::string& a_path )
    {        
        m_sourceFieldPath = a_path;
        return( *this );
    }
    
    int TrxSales::execute( bool& a_stop )
    {    
        std::string l_sTermPdvId;
        long l_lNumPdv = 0;
        long l_lRefnum = 0;
        std::string l_sMerName;
        long l_lInTpoTcn = 0;
        long l_lTrace = 0;
        int l_iIsElegivelRAV = 0;
        fieldSet::fsextr( l_lNumPdv, m_termloc ); 
        fieldSet::fsextr( l_sTermPdvId, m_termpdvid ); 
        fieldSet::fsextr( l_lRefnum, m_refnum ); 
        fieldSet::fsextr( l_sMerName, m_merName ); 
        fieldSet::fsextr( l_lInTpoTcn, m_inTpoTcn );
        fieldSet::fsextr( l_lTrace, m_trace );        
        l_iIsElegivelRAV = getElegivelRAV( l_lNumPdv ); 
        if ( l_iIsElegivelRAV == -1 ) 
        {
            fieldSet::fscopy( m_returnCode, "-1", 2 );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            a_stop = false;
            return( 0 );
        }
        int l_iResultGetSalesSum = 0;
        l_iResultGetSalesSum = getSalesSumm( l_lNumPdv,
                                             l_sTermPdvId,
                                             l_lRefnum, 
                                             l_sMerName,
                                             l_lInTpoTcn,
                                             l_lTrace );
        switch ( l_iResultGetSalesSum )
        {
            case ( -1 ):
                fieldSet::fscopy( m_returnCode, "-1", 2 );
                fieldSet::fscopy( m_result, "ERROR", 5 );
                break;
            case ( 0 ):
                fieldSet::fscopy( m_returnCode, "0", 1 );
                fieldSet::fscopy( m_result, "OK", 2 );
                break;
            case ( 1 ):
                fieldSet::fscopy( m_returnCode, "1", 1 );
                fieldSet::fscopy( m_result, "OK", 2 );
                break;
            case ( 2 ):
                fieldSet::fscopy( m_returnCode, "2", 1 );
                fieldSet::fscopy( m_result, "OK", 2 );
                break;
            default:
            	//default
            	break;
        }
        a_stop = false;
        return( 0 );
    }
    
    void TrxSales::padSummary( struct summ_lines* a_stSlSummary ) 
    {
        char * l_linep = (char *)&a_stSlSummary->lc_line01;
        int l_currLine = 1;
        m_buff63[ 0 ] = '\0';
        //while( l_currLine <= 28 && 
        //       strlen( m_buff63 ) + strlen( l_linep ) < 640 )
        while( l_currLine <= 33 && 
               strlen( m_buff63 ) + strlen( l_linep ) < 760 )
        {
            strcat( m_buff63, l_linep );
            l_linep += sizeof( a_stSlSummary->lc_line01);
            l_currLine++;
        }
        strcat( m_buff63, '\0' );
    }
    
    void TrxSales::fmtPdvSalesSummaryCredidlrIata( const long a_clNumPdv,
                                                   const long a_clRefnum, 
                                                   const std::string& a_csTermPdvId, 
                                                   const std::string& a_csMerName, 
                                                   struct summ_lines* a_stSlSummary, 
                                                   dbaccess_pdv::SalesTablesJoint* a_salesSumm ) 
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== fmtPdvSalesSummaryCredidlrIata ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        memset( ( char* ) a_stSlSummary, 0, sizeof( struct summ_lines ) );
        sprintf( a_stSlSummary->lc_line01, "R%c@%s@%s@",
                 ( a_salesSumm->get_COD_PROD() == 5 ) ? 'D' : 'I',
                 ( a_salesSumm->get_COD_PROD() == 5 ) ? "US$" : "R$",
                 a_salesSumm->get_NOM_BNDR( ).c_str() );
        oasis_dec_t l_odtNumRvs = a_salesSumm->get_NUM_RV( );
        long l_lNumRv;
        l_lNumRv = dbm_dectolong( &l_odtNumRvs );
        std::stringstream l_ssNumRv;
        l_ssNumRv << l_lNumRv;
        std::stringstream l_ssRefnum;
        l_ssRefnum << a_clRefnum;        
        sprintf( a_stSlSummary->lc_line02, "%12s@%7d@", 
                 l_ssNumRv.str( ).c_str( ),
                 l_ssRefnum.str().c_str() );
        sprintf( a_stSlSummary->lc_line03, "%8s@%9ld@", 
                 a_csTermPdvId.c_str(),
                 a_clNumPdv );
        time_t l_ttDthRrv = a_salesSumm->get_DAT_RV( );
        struct tm* l_stmDthRv = localtime( &l_ttDthRrv );
        long l_lDthRvDay = l_stmDthRv->tm_mday;
        long l_lDthRvMon = ( l_stmDthRv->tm_mon + 1 );
        long l_lDthRvYear = ( l_stmDthRv->tm_year - 100 );
        time_t l_ttDthIni = a_salesSumm->get_DTH_INI( );
        struct tm* l_stmDthIni = localtime( &l_ttDthIni );
        long l_lDthIniHour = l_stmDthIni->tm_hour;
        long l_lDthIniMin = l_stmDthIni->tm_min;
        long l_lDthIniSec = l_stmDthIni->tm_sec;        
        //sprintf( a_stSlSummary->lc_line04, "%-22s@%02d%02d%02d@%02d%02d%02d@", 
        //         a_csMerName.substr(0,22).c_str(),
        //         l_lDthRvDay, l_lDthRvMon, l_lDthRvYear, 
        //         l_lDthIniHour, l_lDthIniMin, l_lDthIniSec);     
        sprintf( a_stSlSummary->lc_line04, "%-22s@", 
                 a_csMerName.substr(0,22).c_str() );     
        sprintf( a_stSlSummary->lc_line05, "%02d%02d%02d@", 
                 l_lDthRvDay, l_lDthRvMon, l_lDthRvYear );     
        sprintf( a_stSlSummary->lc_line06, "%02d%02d%02d@", 
                 l_lDthIniHour, l_lDthIniMin, l_lDthIniSec );     
        oasis_dec_t l_odtMoneyVendas = a_salesSumm->get_VAL_TOTL_PAGO( );
        char l_cAmount[ 14 ];
        dbm_dectochar( &l_odtMoneyVendas, l_cAmount );
        std::stringstream l_ssAmount;
        l_ssAmount << l_cAmount;
        fieldSet::fscopy( m_shcMsgAmount, l_ssAmount.str( ) );//dbm_deccopy(&shcmsg->amount, &a_salesSumm->val_totl_pago);        
        time_t l_ttDthPrcl = a_salesSumm->get_DAT_PRCL( );
        struct tm* l_stmDthPrcl = localtime( &l_ttDthPrcl );
        long l_lDthPrclDay = l_stmDthPrcl->tm_mday;
        long l_lDthPrclMon = ( l_stmDthPrcl->tm_mon + 1 );
        long l_lDthPrclYear = ( l_stmDthPrcl->tm_year - 100 );                 
        time_t l_ttDthFim = a_salesSumm->get_DTH_FIM( );
        struct tm* l_stmDthFim = localtime( &l_ttDthFim );
        long l_lDthFimHour = l_stmDthFim->tm_hour;
        long l_lDthFimMin = l_stmDthFim->tm_min;                 
        long l_lDthFimSec = l_stmDthFim->tm_sec;
        oasis_dec_t l_odtQtdCv = a_salesSumm->get_QTD_CV( );
        char l_cQtdCv[ 14 ];
        dbm_dectochar( &l_odtQtdCv, l_cQtdCv );
        oasis_dec_t l_odtTotlPago = a_salesSumm->get_VAL_TOTL_PAGO( );
        dbm_decnmul( &l_odtTotlPago, 100 );
        char l_cTotlPago[ 14 ];
        dbm_dectocharnd( &l_odtTotlPago, l_cTotlPago );
        //sprintf( a_stSlSummary->lc_line05, 
        sprintf( a_stSlSummary->lc_line07, 
                 "%02d%02d%02d@%02d%02d%02d@", 
                 l_lDthFimHour, l_lDthFimMin, l_lDthFimSec,
                 l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear );
        sprintf( a_stSlSummary->lc_line08, 
                 "%3d@%3s@%3s@%7s@", 
                 0, l_cQtdCv, l_cQtdCv, l_cTotlPago );
        if( a_salesSumm->get_COD_PROD() == 5 )
        {
            oasis_dec_t l_odtMoneyGorjt = a_salesSumm->get_VAL_TOTL_GRJT( ) ;
            char l_cMoneyGorjt[ 14 ];
            dbm_decnmul( &l_odtMoneyGorjt, 100 );
            dbm_dectocharnd( &l_odtMoneyGorjt, l_cMoneyGorjt );
            oasis_dec_t l_odtMoneyDsct = a_salesSumm->get_VAL_TOTL_DSCT( );
            dbm_decnmul( &l_odtMoneyDsct, 100 );
            char l_cMoneyDsct[ 14 ];
            dbm_dectocharnd( &l_odtMoneyDsct, l_cMoneyDsct );
            oasis_dec_t l_odtMoneyLqdo = a_salesSumm->get_VAL_TOTL_LQDO( );
            dbm_decnmul( &l_odtMoneyLqdo, 100 );
            char l_cMoneyLqdo[ 14 ];
            dbm_dectocharnd( &l_odtMoneyLqdo, l_cMoneyLqdo );
            //sprintf( a_stSlSummary->lc_line06, "%7s@%7s@%7s@", 
            //         l_cMoneyGorjt, l_cMoneyDsct, l_cMoneyLqdo );  
            sprintf( a_stSlSummary->lc_line09, "%7s@%7s@", 
                     l_cMoneyGorjt, l_cMoneyDsct );  
            sprintf( a_stSlSummary->lc_line10, "%7s@", 
                     l_cMoneyLqdo );  
        }
        else                                
        {
            oasis_dec_t l_odtMoneyEntr = a_salesSumm->get_VAL_ENTR( );
            char l_cMoneyEntr[ 14 ];
            dbm_decnmul( &l_odtMoneyEntr, 100 );
            dbm_dectocharnd( &l_odtMoneyEntr, l_cMoneyEntr );
            oasis_dec_t l_odtMoneyGorjt = a_salesSumm->get_VAL_TOTL_GRJT( );
            dbm_decnmul( &l_odtMoneyGorjt, 100 );
            char l_cMoneyGorjt[ 14 ];
            dbm_dectocharnd( &l_odtMoneyGorjt, l_cMoneyGorjt );
            oasis_dec_t l_odtMoneyDsct = a_salesSumm->get_VAL_TOTL_DSCT( );
            dbm_decnmul( &l_odtMoneyDsct, 100 );
            char l_cMoneyDsct[ 14 ];
            dbm_dectocharnd( &l_odtMoneyDsct, l_cMoneyDsct );
            oasis_dec_t l_odtMoneyLqdo = a_salesSumm->get_VAL_TOTL_LQDO( );
            dbm_decnmul( &l_odtMoneyLqdo, 100 );
            char l_cMoneyLqdo[ 14 ];
            dbm_dectocharnd( &l_odtMoneyLqdo, l_cMoneyLqdo );
            //sprintf( a_stSlSummary->lc_line06, "%7s@%7s@%7s@%7s@", 
            //         l_cMoneyEntr, l_cMoneyGorjt, l_cMoneyDsct, 
            //         l_cMoneyLqdo );  
            sprintf( a_stSlSummary->lc_line09, "%7s@%7s@", 
                     l_cMoneyEntr, l_cMoneyGorjt );  
            sprintf( a_stSlSummary->lc_line10, "%7s@%7s@", 
                     l_cMoneyDsct, l_cMoneyLqdo );  
        }
        fieldSet::fscopy( m_swmsgNuRv, l_ssNumRv.str( ) ); //Txn->swmsg.nu_rv = atoi(a_salesSumm.num_rvs);
        std::stringstream l_ssDtRv;
        l_ssDtRv << l_ttDthRrv;
        fieldSet::fscopy( m_swmsgDtRv, l_ssDtRv.str( ) ); //Txn->swmsg.dt_rv = a_salesSumm.dat_rvs;
        long l_lQtdCv = dbm_dectolong( &l_odtQtdCv );        
        std::stringstream l_ssQtdCv;
        l_ssQtdCv << l_lQtdCv;
        fieldSet::fscopy( m_shcMsgShiftNumber, l_ssQtdCv.str( ) ); //Txn->shc.msg.shift_number = a_salesSumm.qtd_cv;
        oasis_dec_t l_odtActualAmount = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cActualAmount[ 14 ];
        dbm_dectochar( &l_odtActualAmount, l_cActualAmount );
        std::stringstream l_ssActualAmount;
        l_ssActualAmount << l_cActualAmount;
        fieldSet::fscopy( m_shcMsgActualAmount, l_ssActualAmount.str( ) );  //dbm_deccopy(&Txn->shc.msg.amount5, &a_salesSumm.val_totl_lqdo);
        oasis_dec_t l_odtAmount = a_salesSumm->get_VAL_TOTL_PAGO( );
        fieldSet::fscopy( m_shcMsgAmount, l_ssAmount.str( ) ); // dbm_deccopy(&Txn->shc.msg.amount,  &a_salesSumm.val_totl_pago);         
    }
    
    void TrxSales::fmtPdvSalesSummaryPostDated( const long a_clRefnum, 
                                                const std::string& a_csTermPdvId, 
                                                const std::string& a_csMerName, 
                                                struct summ_lines* a_stSlSummary, 
                                                dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
                                                const int a_clMoreRecordsFlag ) 
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== fmtPdvSalesSummaryPostDated ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        memset( ( char* ) a_stSlSummary, ' ', sizeof( struct summ_lines ) );
        sprintf( a_stSlSummary->lc_line01, "F               REDE    @\0" );
        sprintf( a_stSlSummary->lc_line02, "%s@\0", a_salesSumm->get_NOM_BNDR( ).c_str() );
        sprintf( a_stSlSummary->lc_line03, "%s@\0", a_salesSumm->get_NOM_PROD( ).c_str() );
        sprintf( a_stSlSummary->lc_line04, "@\0" );
        oasis_dec_t l_odtNumRvs = a_salesSumm->get_NUM_RV( );
        long l_lNumRv;
        l_lNumRv = dbm_dectolong( &l_odtNumRvs );
        std::stringstream l_ssNumRv;
        l_ssNumRv << l_lNumRv;
        sprintf( a_stSlSummary->lc_line05, "RES.VENDA: %12s@\0", l_ssNumRv.str( ).c_str( ) );
        std::stringstream l_ssRefnum;
        l_ssRefnum << a_clRefnum;
        sprintf( a_stSlSummary->lc_line06, "COMPROV:   %12s@\0", l_ssRefnum.str().c_str() );        
        time_t l_ttCurrentTime = time( 0 );
        struct tm* l_stmCurrentDate = localtime( &l_ttCurrentTime );
        long l_lCurDateDay = l_stmCurrentDate->tm_mday;
        long l_lCurDateMon = ( l_stmCurrentDate->tm_mon + 1 );
        long l_lCurDateYear = ( l_stmCurrentDate->tm_year - 100 );
        long l_lCurDateHour = l_stmCurrentDate->tm_hour;
        long l_lCurDateMin = l_stmCurrentDate->tm_min;
        long l_lCurDateSec = l_stmCurrentDate->tm_sec;
        sprintf( a_stSlSummary->lc_line07, "DATA:  %02d/%02d/%02d      %02d.%02d@\0", 
                 l_lCurDateDay, l_lCurDateMon, l_lCurDateYear, 
                 l_lCurDateHour, l_lCurDateMin );
        //sprintf( a_stSlSummary->lc_line07, "DATA: %02d/%02d/%02d %02d:%02d:%02d@\0", 
        //         l_lCurDateDay, l_lCurDateMon, l_lCurDateYear, 
        //         l_lCurDateHour, l_lCurDateMin, l_lCurDateSec );
        std::stringstream l_ssNumPdv;
        l_ssNumPdv << a_salesSumm->get_NUM_PDV( );
        sprintf( a_stSlSummary->lc_line08, "ESTAB: %9s TERM: %8s@\0", 
                 l_ssNumPdv.str().c_str(), a_csTermPdvId.c_str() );
        //sprintf( a_stSlSummary->lc_line08, "ESTAB: %9s@\0", l_ssNumPdv.str().c_str() );
        //sprintf( a_stSlSummary->lc_line09, "TERM: %8s@\0", a_csTermPdvId.c_str() );
        //sprintf( a_stSlSummary->lc_line09, "%s@\0", a_csMerName.c_str() );
        sprintf( a_stSlSummary->lc_line09, "%s@\0", a_csMerName.c_str() );
        time_t l_ttDthRrv = a_salesSumm->get_DAT_RV( );
        struct tm* l_stmDthRv = localtime( &l_ttDthRrv );
        long l_lDthRvDay = l_stmDthRv->tm_mday;
        long l_lDthRvMon = ( l_stmDthRv->tm_mon + 1 );
        long l_lDthRvYear = ( l_stmDthRv->tm_year - 100 );
        time_t l_ttDthIni = a_salesSumm->get_DTH_INI( );
        struct tm* l_stmDthIni = localtime( &l_ttDthIni );
        long l_lDthIniHour = l_stmDthIni->tm_hour;
        long l_lDthIniMin = l_stmDthIni->tm_min;
        long l_lDthIniSec = l_stmDthIni->tm_sec;
        time_t l_ttDthFim = a_salesSumm->get_DTH_FIM( );
        struct tm* l_stmDthFim = localtime( &l_ttDthFim );
        long l_lDthFimHour = l_stmDthFim->tm_hour;
        long l_lDthFimMin = l_stmDthFim->tm_min;
        long l_lDthFimSec = l_stmDthFim->tm_sec;
        sprintf( a_stSlSummary->lc_line10, "RESUMO: %02d/%02d/%02d     %02d:%02d A %02d:%02d@\0",
                 l_lDthRvDay, l_lDthRvMon, l_lDthRvYear, 
                 l_lDthIniHour, l_lDthIniMin,
                 l_lDthFimHour, l_lDthFimMin );                         
        //sprintf( a_stSlSummary->lc_line10, "RESUMO: %02d/%02d/%02d@\0",
        //         l_lDthRvDay, l_lDthRvMon, l_lDthRvYear );                         
        //sprintf( a_stSlSummary->lc_line11, " %02d:%02d:%02d A %02d:%02d:%02d@\0",
        //         l_lDthIniHour, l_lDthIniMin, l_lDthIniSec,
        //         l_lDthFimHour, l_lDthFimMin, l_lDthFimSec );                         
        oasis_dec_t l_odtQtdCv = a_salesSumm->get_QTD_CV( );
        long l_lQtdCv;
        l_lQtdCv = dbm_dectolong( &l_odtQtdCv );
        //sprintf( a_stSlSummary->lc_line11, "QTDE CVS: %5d@\0", l_lQtdCv );
        sprintf( a_stSlSummary->lc_line11, "QTDE CVS: %5d@\0", l_lQtdCv );
        //sprintf( a_stSlSummary->lc_line12, "@\0" );
        sprintf( a_stSlSummary->lc_line12, "@\0" );
        oasis_dec_t l_odtMoneyVendas = a_salesSumm->get_VAL_TOTL_PAGO( );
        char l_cMoneyVendas[ 14 ];
        dbm_dectochar( &l_odtMoneyVendas, l_cMoneyVendas );
        //sprintf( a_stSlSummary->lc_line13, "VENDAS: %10s@\0", l_cMoneyVendas );
        sprintf( a_stSlSummary->lc_line13, "VENDAS: %10s@\0", l_cMoneyVendas );
        oasis_dec_t l_odtMoneyDescto = a_salesSumm->get_VAL_TOTL_DSCT( );
        char l_cMoneyDescto[ 14 ];
        dbm_dectochar( &l_odtMoneyDescto, l_cMoneyDescto );
        //sprintf( a_stSlSummary->lc_line14, "DESCTO : %10s@\0", l_cMoneyDescto );        
        sprintf( a_stSlSummary->lc_line14, "DESCTO : %10s@\0", l_cMoneyDescto );        
        oasis_dec_t l_odtMoneyLqdo = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cMoneyLqdo[ 14 ];
        dbm_dectochar( &l_odtMoneyLqdo, l_cMoneyLqdo );
        //sprintf( a_stSlSummary->lc_line15, "LIQUIDO: %10s@\0", l_cMoneyLqdo );
        sprintf( a_stSlSummary->lc_line15, "LIQUIDO: %10s@\0", l_cMoneyLqdo );
        *a_stSlSummary->lc_line16 = 0;
        *a_stSlSummary->lc_line17 = 0;
        *a_stSlSummary->lc_line18 = 0;
        *a_stSlSummary->lc_line19 = 0;
        *a_stSlSummary->lc_line20 = 0;
        *a_stSlSummary->lc_line21 = 0;
        *a_stSlSummary->lc_line22 = 0;
        *a_stSlSummary->lc_line23 = 0;
        *a_stSlSummary->lc_line24 = 0;
        *a_stSlSummary->lc_line25 = 0;
        *a_stSlSummary->lc_line26 = 0;
        *a_stSlSummary->lc_line27 = 0;
        *a_stSlSummary->lc_line28 = 0;           
        if ( a_clMoreRecordsFlag  ) 
        {
            //strcpy( a_stSlSummary->lc_line16, "HA MAIS RESUMOS       @\0" );
            strcpy( a_stSlSummary->lc_line16, "HA MAIS RESUMOS       @\0" );
        }            
        padSummary( a_stSlSummary );        
        fieldSet::fscopy( m_swmsgNuRv, l_ssNumRv.str( ) ); //Txn->swmsg.nu_rv = atoi(a_salesSumm.num_rvs);
        std::stringstream l_ssDtRv;
        l_ssDtRv << l_ttDthRrv;
        fieldSet::fscopy( m_swmsgDtRv, l_ssDtRv.str( ) ); //Txn->swmsg.dt_rv = a_salesSumm.dat_rvs;
        std::stringstream l_ssQtdCv;
        l_ssQtdCv << l_lQtdCv;
        fieldSet::fscopy( m_shcMsgShiftNumber, l_ssQtdCv.str( ) ); //Txn->shc.msg.shift_number = a_salesSumm.qtd_cv;
        oasis_dec_t l_odtActualAmount = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cActualAmount[ 14 ];
        dbm_dectochar( &l_odtActualAmount, l_cActualAmount );
        std::stringstream l_ssActualAmount;
        l_ssActualAmount << l_cActualAmount;
        fieldSet::fscopy( m_shcMsgActualAmount, l_ssActualAmount.str( ) );  //dbm_deccopy(&Txn->shc.msg.amount5, &a_salesSumm.val_totl_lqdo);
        oasis_dec_t l_odtAmount = a_salesSumm->get_VAL_TOTL_PAGO( );
        char l_cAmount[ 14 ];
        dbm_dectochar( &l_odtAmount, l_cAmount );
        std::stringstream l_ssAmount;
        l_ssAmount << l_cAmount;
        fieldSet::fscopy( m_shcMsgAmount, l_ssAmount.str( ) ); // dbm_deccopy(&Txn->shc.msg.amount,  &a_salesSumm.val_totl_pago);         
    }
        
    void TrxSales::fmtPdvSalesSummaryNoRow( const std::string& a_csTermPdvId,
                                            const long a_clNumPdv,
                                            struct summ_lines* a_stSlSummary ) 
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== fmtPdvSalesSummaryNoRow ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        memset( ( char* ) a_stSlSummary, 0 , sizeof( struct summ_lines ) ); 
        sprintf( a_stSlSummary->lc_line01, "F               REDE@@" );
        sprintf( a_stSlSummary->lc_line02, "NAO EXISTE RESUMO@" );
        time_t l_ttCurrentTime = time( 0 );
        struct tm* l_stmCurrentDate = localtime( &l_ttCurrentTime );
        long l_lCurDateDay = l_stmCurrentDate->tm_mday;
        long l_lCurDateMon = ( l_stmCurrentDate->tm_mon + 1 );
        long l_lCurDateYear = ( l_stmCurrentDate->tm_year - 100 );
        long l_lCurDateHour = l_stmCurrentDate->tm_hour;
        long l_lCurDateMin = l_stmCurrentDate->tm_min;
        long ll_curDate_sec = l_stmCurrentDate->tm_sec;
        sprintf( a_stSlSummary->lc_line03, 
                 "%02d.%02d.%02d - %02d:%02d:%02d @", 
                 l_lCurDateDay, l_lCurDateMon, l_lCurDateYear, 
                 l_lCurDateHour, l_lCurDateMin, ll_curDate_sec );        
        sprintf( a_stSlSummary->lc_line04, "ESTAB: %09ld TERM: %8s@\0",
                 a_clNumPdv, a_csTermPdvId.c_str( ) );                  
        //sprintf( a_stSlSummary->lc_line04, "ESTAB: %09ld@\0", a_clNumPdv );                  
        //sprintf( a_stSlSummary->lc_line05, "TERM: %8s@\0", a_csTermPdvId.c_str( ) );                  
        padSummary( a_stSlSummary );   
    }
    
    void TrxSales::fmtPdvSalesSummaryGeneral( const long a_clRefnum, 
                                              const std::string& a_csTermPdvId, 
                                              const std::string& a_csMerName, 
                                              struct summ_lines* a_stSlSummary, 
                                              dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
                                              const int a_clMoreRecordsFlag ) 
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== fmtPdvSalesSummaryGeneral ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        memset( ( char* ) a_stSlSummary, ' ', sizeof( struct summ_lines ) ); 
        sprintf( a_stSlSummary->lc_line01, "F                 REDE@\0" );
        sprintf( a_stSlSummary->lc_line02, "%-20s@\0", a_salesSumm->get_NOM_BNDR( ).c_str( ) );
        sprintf( a_stSlSummary->lc_line03, "%-20s@\0", a_salesSumm->get_NOM_PROD( ).c_str( ) );
        sprintf( a_stSlSummary->lc_line04, "@\0" );
        oasis_dec_t l_odtNumRvs = a_salesSumm->get_NUM_RV( );
        long l_lNumRv;
        l_lNumRv = dbm_dectolong( &l_odtNumRvs );
        std::stringstream l_ssNumRv;
        l_ssNumRv << l_lNumRv;
        sprintf( a_stSlSummary->lc_line05, "RES.VENDA: %012ld@\0", l_lNumRv );        
        std::stringstream l_ssRefnum;
        l_ssRefnum << a_clRefnum; 
        sprintf( a_stSlSummary->lc_line06, "COMPROV:   %012ld@\0", a_clRefnum );            
        time_t l_ttCurrentTime = time( 0 );
        struct tm* l_stmCurrentDate = localtime( &l_ttCurrentTime );
        long l_lCurDateDay = l_stmCurrentDate->tm_mday;
        long l_lCurDateMon = ( l_stmCurrentDate->tm_mon + 1 );
        long l_lCurDateYear = ( l_stmCurrentDate->tm_year - 100 );
        long l_lCurDateHour = l_stmCurrentDate->tm_hour;
        long l_lCurDateMin = l_stmCurrentDate->tm_min;
        long l_lCurDateSec = l_stmCurrentDate->tm_sec;
        sprintf( a_stSlSummary->lc_line07, 
                 "DATA:  %02d/%02d/%02d      %02d.%02d@\0", 
                 l_lCurDateDay, l_lCurDateMon, l_lCurDateYear, 
                 l_lCurDateHour, l_lCurDateMin );
                 //"DATA: %02d/%02d/%02d %02d:%02d:%02d@\0", 
                 //l_lCurDateDay, l_lCurDateMon, l_lCurDateYear, 
                 //l_lCurDateHour, l_lCurDateMin, l_lCurDateSec );
        std::stringstream l_ssNumPdv;
        l_ssNumPdv << a_salesSumm->get_NUM_PDV( );
        sprintf( a_stSlSummary->lc_line08, "ESTAB: %-9s     TERM: %8s@\0",
                 l_ssNumPdv.str( ).c_str( ), a_csTermPdvId.c_str( ) );
        //sprintf( a_stSlSummary->lc_line08, "ESTAB: %9s@\0",
        //         l_ssNumPdv.str( ).c_str( ) );
        //sprintf( a_stSlSummary->lc_line09, "TERM: %8s@\0",
        //         a_csTermPdvId.c_str( ) );
        //sprintf( a_stSlSummary->lc_line09, "%s@\0", a_csMerName.c_str( ) );
        sprintf( a_stSlSummary->lc_line09, "%-23s@\0", a_csMerName.substr(0,23).c_str( ) );
        time_t l_ttDthRrv = a_salesSumm->get_DAT_RV( );
        struct tm* l_stmDthRv = localtime( &l_ttDthRrv );
        long l_lDthRvDay = l_stmDthRv->tm_mday;
        long l_lDthRvMon = ( l_stmDthRv->tm_mon + 1 );
        long l_lDthRvYear = ( l_stmDthRv->tm_year - 100 );
        time_t l_ttDthIni = a_salesSumm->get_DTH_INI( );
        struct tm* l_stmDthIni = localtime( &l_ttDthIni );
        long l_lDthIniHour = l_stmDthIni->tm_hour;
        long l_lDthIniMin = l_stmDthIni->tm_min;
        long l_lDthIniSec = l_stmDthIni->tm_sec;
        time_t l_ttDthFim = a_salesSumm->get_DTH_FIM( );
        struct tm* l_stmDthFim = localtime( &l_ttDthFim );
        long l_lDthFimHour = l_stmDthFim->tm_hour;
        long l_lDthFimMin = l_stmDthFim->tm_min;
        long l_lDthFimSec = l_stmDthFim->tm_sec;
        sprintf( a_stSlSummary->lc_line10, "RESUMO: %02d/%02d/%02d     %02d:%02d A %02d:%02d@\0", 
                 l_lDthRvDay, l_lDthRvMon, l_lDthRvYear,
                 l_lDthIniHour, l_lDthIniMin, 
                 l_lDthFimHour, l_lDthFimMin );
        //sprintf( a_stSlSummary->lc_line10, "RESUMO: %02d/%02d/%02d@\0", 
        //         l_lDthRvDay, l_lDthRvMon, l_lDthRvYear );
        //sprintf( a_stSlSummary->lc_line11, " %02d:%02d:%02d A %02d:%02d:%02d@\0", 
        //         l_lDthIniHour, l_lDthIniMin, l_lDthIniSec,
        //         l_lDthFimHour, l_lDthFimMin, l_lDthFimSec );
        time_t l_ttDthCreRv = a_salesSumm->get_DAT_CRE_RV( );
        struct tm* l_stmDthCreRv = localtime( &l_ttDthCreRv );
        long l_lDthCreRvDay = l_stmDthCreRv->tm_mday;
        long l_lDthCreRvMon = ( l_stmDthCreRv->tm_mon + 1 );
        long l_lDthCreRvYear = ( l_stmDthCreRv->tm_year - 100 );
        //sprintf( a_stSlSummary->lc_line11, "DT CREDITO: %02d/%02d/%02d@\0", 
        sprintf( a_stSlSummary->lc_line11, "DT CREDITO: %02d/%02d/%02d@\0", 
                 l_lDthCreRvDay, l_lDthCreRvMon, l_lDthCreRvYear );
        oasis_dec_t l_odtQtdCv = a_salesSumm->get_QTD_CV( );
        long l_lQtdCv;
        l_lQtdCv = dbm_dectolong( &l_odtQtdCv );
        //sprintf( a_stSlSummary->lc_line12, "QTDE CVS: %5d@\0", l_lQtdCv );            
        sprintf( a_stSlSummary->lc_line12, "QTDE CVS: %5d@\0", l_lQtdCv );            
        //sprintf( a_stSlSummary->lc_line13, "@\0" );        
        sprintf( a_stSlSummary->lc_line13, "@\0" );        
        oasis_dec_t l_odtMoneyVendas = a_salesSumm->get_VAL_TOTL_PAGO( );
        char l_cMoneyVendas[ 14 ];
        dbm_dectochar( &l_odtMoneyVendas, l_cMoneyVendas );
		strcpy( l_cMoneyVendas, GetBrDecimalFormat( std::string( l_cMoneyVendas ) ).c_str() );
        //sprintf( a_stSlSummary->lc_line14, "VENDAS:  %10s@\0", l_cMoneyVendas );
        sprintf( a_stSlSummary->lc_line14, "VENDAS:  %10s@\0", l_cMoneyVendas );
        oasis_dec_t l_odtMoneyDescto = a_salesSumm->get_VAL_TOTL_DSCT( );
        char l_cMoneyDescto[ 14 ];
        dbm_dectochar( &l_odtMoneyDescto, l_cMoneyDescto );
		strcpy( l_cMoneyDescto, GetBrDecimalFormat( std::string( l_cMoneyDescto ) ).c_str() );
        //sprintf( a_stSlSummary->lc_line15, "DESCTO:  %10s@\0", l_cMoneyDescto );    
        sprintf( a_stSlSummary->lc_line15, "DESCTO:  %10s@\0", l_cMoneyDescto );    
        if (a_salesSumm->get_COD_PROD() == 7 && a_salesSumm->get_COD_CMPM_TRAN() == 3)
        {            
            oasis_dec_t l_odtMoneySque = a_salesSumm->get_VAL_SQUE( );
            char l_cMoneySque[ 14 ]; 
            dbm_dectochar( &l_odtMoneySque, l_cMoneySque );
			strcpy( l_cMoneySque, GetBrDecimalFormat( std::string( l_cMoneySque ) ).c_str() );
            //sprintf( a_stSlSummary->lc_line16, "SAQUE:   %10s@\0", l_cMoneySque );                
            sprintf( a_stSlSummary->lc_line16, "SAQUE:   %10s@\0", l_cMoneySque );                
        }
        else
        {
            oasis_dec_t l_odtMoneyGorjt = a_salesSumm->get_VAL_TOTL_GRJT( );
            char l_cMoneyGorjt[ 14 ];
            dbm_dectochar( &l_odtMoneyGorjt, l_cMoneyGorjt );
			strcpy( l_cMoneyGorjt, GetBrDecimalFormat( std::string( l_cMoneyGorjt ) ).c_str() );
            //sprintf( a_stSlSummary->lc_line16, "GORJETA: %10s@\0", l_cMoneyGorjt );            
            sprintf( a_stSlSummary->lc_line16, "GORJETA: %10s@\0", l_cMoneyGorjt );            
        }
        oasis_dec_t l_odtMoneyLqdo = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cMoneyLqdo[ 14 ];
        dbm_dectochar( &l_odtMoneyLqdo, l_cMoneyLqdo );
		strcpy( l_cMoneyLqdo, GetBrDecimalFormat( std::string( l_cMoneyLqdo ) ).c_str() );
        //sprintf( a_stSlSummary->lc_line17, "LIQUIDO: %10s@\0", l_cMoneyLqdo );        
        sprintf( a_stSlSummary->lc_line17, "LIQUIDO: %10s@\0", l_cMoneyLqdo );        
        *a_stSlSummary->lc_line18 = 0;
        *a_stSlSummary->lc_line19 = 0;
        *a_stSlSummary->lc_line20 = 0;
        *a_stSlSummary->lc_line21 = 0;
        *a_stSlSummary->lc_line22 = 0;
        *a_stSlSummary->lc_line23 = 0;
        *a_stSlSummary->lc_line24 = 0;
        *a_stSlSummary->lc_line25 = 0;
        *a_stSlSummary->lc_line26 = 0;
        *a_stSlSummary->lc_line27 = 0;
        *a_stSlSummary->lc_line28 = 0;           
        *a_stSlSummary->lc_line29 = 0;           
        *a_stSlSummary->lc_line30 = 0;           
        *a_stSlSummary->lc_line31 = 0;           
        *a_stSlSummary->lc_line32 = 0;           
        *a_stSlSummary->lc_line33 = 0;           
        if ( a_clMoreRecordsFlag  ) 
        {
            //strcpy( a_stSlSummary->lc_line18, "HA MAIS RESUMOS       @\0" );
            strcpy( a_stSlSummary->lc_line18, "HA MAIS RESUMOS       @\0" );
        }            
        padSummary( a_stSlSummary );        
        fieldSet::fscopy( m_swmsgNuRv, l_ssNumRv.str( ) ); //Txn->swmsg.nu_rv = atoi(a_salesSumm.num_rvs);
        std::stringstream l_ssDtRv;
        l_ssDtRv << l_ttDthRrv;
        fieldSet::fscopy( m_swmsgDtRv, l_ssDtRv.str( ) ); //Txn->swmsg.dt_rv = a_salesSumm.dat_rvs;
        std::stringstream l_ssQtdCv;
        l_ssQtdCv << l_lQtdCv;
        fieldSet::fscopy( m_shcMsgShiftNumber, l_ssQtdCv.str( ) ); //Txn->shc.msg.shift_number = a_salesSumm.qtd_cv;
        oasis_dec_t l_odtActualAmount = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cActualAmount[ 14 ];
        dbm_dectochar( &l_odtActualAmount, l_cActualAmount );
        std::stringstream l_ssActualAmount;
        l_ssActualAmount << l_cActualAmount;
        fieldSet::fscopy( m_shcMsgActualAmount, l_ssActualAmount.str( ) );  //dbm_deccopy(&Txn->shc.msg.amount5, &a_salesSumm.val_totl_lqdo);
        oasis_dec_t l_odtAmount = a_salesSumm->get_VAL_TOTL_PAGO( );
        char l_cAmount[ 14 ];
        dbm_dectochar( &l_odtAmount, l_cAmount );
        std::stringstream l_ssAmount;
        l_ssAmount << l_cAmount;
        fieldSet::fscopy( m_shcMsgAmount, l_ssAmount.str( ) ); // dbm_deccopy(&Txn->shc.msg.amount,  &a_salesSumm.val_totl_pago);     
    }

    void TrxSales::fmtPdvSalesSummaryParcelemais( const long a_clRefnum, 
                                                  const std::string& a_csTermPdvId, 
                                                  const std::string& a_csMerName, 
                                                  struct summ_lines* a_stSlSummary, 
                                                  dbaccess_pdv::SalesTablesJoint* a_salesSumm,
                                                  const int a_clMoreRecordsFlag )

    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== fmtPdvSalesSummaryParcelemais ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        memset( ( char* ) a_stSlSummary, ' ', sizeof( struct summ_lines ) );
        sprintf( a_stSlSummary->lc_line01, "F               REDE@\0");
        sprintf( a_stSlSummary->lc_line02, "%s@\0", a_salesSumm->get_NOM_BNDR( ).c_str( ));
        sprintf( a_stSlSummary->lc_line03, "%s@\0", a_salesSumm->get_NOM_PROD( ).c_str( ));      
        sprintf( a_stSlSummary->lc_line04, "@\0");
        oasis_dec_t l_odtNumRvs = a_salesSumm->get_NUM_RV( );
        long l_lNumRv;
        l_lNumRv = dbm_dectolong( &l_odtNumRvs );
        std::stringstream l_ssNumRv;
        l_ssNumRv << l_lNumRv;
        sprintf( a_stSlSummary->lc_line05, "RES.VENDA: %12s@\0", l_ssNumRv.str( ).c_str( ) );              
        std::stringstream l_ssRefnum;
        l_ssRefnum << a_clRefnum;
        sprintf( a_stSlSummary->lc_line06, "COMPROV:   %12s@\0", 
                 l_ssRefnum.str( ).c_str( ) ); 
        time_t l_ttCurrentTime = time( 0 );
        struct tm* l_stmCurrentDate = localtime( &l_ttCurrentTime );
        long l_lCurDateDay = l_stmCurrentDate->tm_mday;
        long l_lCurDateMon = ( l_stmCurrentDate->tm_mon + 1 );
        long l_lCurDateYear = ( l_stmCurrentDate->tm_year - 100 );
        long l_lCurDateHour = l_stmCurrentDate->tm_hour;
        long l_lCurDateMin = l_stmCurrentDate->tm_min;
        long l_lCurDateSec = l_stmCurrentDate->tm_sec;
        sprintf( a_stSlSummary->lc_line07, 
                 "DATA: %02d/%02d/%02d      %02d:%02d@\0",
                 l_lCurDateDay, l_lCurDateMon, l_lCurDateYear, 
                 l_lCurDateHour, l_lCurDateMin );
                 //"DATA: %02d/%02d/%02d %02d:%02d:%02d@\0",
                 //l_lCurDateDay, l_lCurDateMon, l_lCurDateYear, 
                 //l_lCurDateHour, l_lCurDateMin, l_lCurDateSec );
        std::stringstream l_ssNumPdv;
        l_ssNumPdv << a_salesSumm->get_NUM_PDV( );
        sprintf( a_stSlSummary->lc_line08, 
                 "ESTAB:%9s   TERM:%8s@\0", l_ssNumPdv.str( ).c_str( ), 
                 a_csTermPdvId.c_str( ) );
        //sprintf( a_stSlSummary->lc_line08, 
        //         "ESTAB:%9s@\0", l_ssNumPdv.str( ).c_str( ) );
        //sprintf( a_stSlSummary->lc_line09, 
        //         "TERM:%8s@\0", a_csTermPdvId.c_str( ) );
        //sprintf( a_stSlSummary->lc_line09, "%32s\0", 
        sprintf( a_stSlSummary->lc_line09, "%32s\0", 
                 a_csMerName.c_str( ) );
        time_t l_ttDthRrv = a_salesSumm->get_DAT_RV( );
        struct tm* l_stmDthRv = localtime( &l_ttDthRrv );
        long l_lDthRvDay = l_stmDthRv->tm_mday;
        long l_lDthRvMon = ( l_stmDthRv->tm_mon + 1 );
        long l_lDthRvYear = ( l_stmDthRv->tm_year - 100 );
        time_t l_ttDthIni = a_salesSumm->get_DTH_INI( );
        struct tm* l_stmDthIni = localtime( &l_ttDthIni );
        long l_lDthIniHour = l_stmDthIni->tm_hour;
        long l_lDthIniMin = l_stmDthIni->tm_min;
        long l_lDthIniSec = l_stmDthIni->tm_sec;
        time_t l_ttDthFim = a_salesSumm->get_DTH_FIM( );
        struct tm* l_stmDthFim = localtime( &l_ttDthFim );
        long l_lDthFimHour = l_stmDthFim->tm_hour;
        long l_lDthFimMin = l_stmDthFim->tm_min;
        long l_lDthFimSec = l_stmDthFim->tm_sec;
        sprintf( a_stSlSummary->lc_line10, 
                 "RESUMO:%02d/%02d/%02d   %02d:%02d A %02d:%02d@\0",
                 l_lDthRvDay, l_lDthRvMon, l_lDthRvYear,
                 l_lDthIniHour, l_lDthIniMin, 
                 l_lDthFimHour, l_lDthFimMin );
        //sprintf( a_stSlSummary->lc_line10, 
        //         "RESUMO:%02d/%02d/%02d@\0",
        //         l_lDthRvDay, l_lDthRvMon, l_lDthRvYear );                     
        //sprintf( a_stSlSummary->lc_line11, 
        //         " %02d:%02d:02%d A %02d:%02d:%02d@\0",
        //         l_lDthIniHour, l_lDthIniMin, l_lDthIniSec,
        //         l_lDthFimHour, l_lDthFimMin, l_lDthFimSec );                     
        time_t l_ttDthCreRv = a_salesSumm->get_DAT_CRE_RV( );
        struct tm* l_stmDthCreRv = localtime( &l_ttDthCreRv );                     
        long l_lDthCreRvDay = l_stmDthCreRv->tm_mday;
        long l_lDthCreRvMon = ( l_stmDthCreRv->tm_mon + 1 );
        long l_lDthCreRvYear = ( l_stmDthCreRv->tm_year - 100 );            
        //sprintf( a_stSlSummary->lc_line11, 
        sprintf( a_stSlSummary->lc_line11, 
                 "DT CREDITO: %02d/%02d/%02d@\0",
                 l_lDthCreRvDay, l_lDthCreRvMon, 
                 l_lDthCreRvYear );                     
        oasis_dec_t l_odtQtdCv = a_salesSumm->get_QTD_CV( );
        long l_lQtdCv;
        l_lQtdCv = dbm_dectolong( &l_odtQtdCv );
        //sprintf( a_stSlSummary->lc_line12, "QTDE CVS: %5d@\0", l_lQtdCv );
        //sprintf( a_stSlSummary->lc_line13, "@\0" );
        sprintf( a_stSlSummary->lc_line12, "QTDE CVS: %5d@\0", l_lQtdCv );
        sprintf( a_stSlSummary->lc_line13, "@\0" );
        oasis_dec_t l_odtMoneyVendas = a_salesSumm->get_VAL_TOTL_PAGO( );
        char l_cMoneyVendas[ 14 ];
        dbm_dectochar( &l_odtMoneyVendas, l_cMoneyVendas );
        //sprintf( a_stSlSummary->lc_line14, "VLR TOTAL VENDAS:  %10s@\0", 
        sprintf( a_stSlSummary->lc_line14, "VLR TOTAL VENDAS:@\0" );
        sprintf( a_stSlSummary->lc_line15, "%10s@\0", 
                 l_cMoneyVendas );
        oasis_dec_t lodt_money_iof = a_salesSumm->get_VAL_IOF( );
        char lc_money_iof[ 14 ];
        dbm_dectochar( &lodt_money_iof, lc_money_iof );
        //sprintf( a_stSlSummary->lc_line15, 
        sprintf( a_stSlSummary->lc_line16, "IOF RECOLHIDO:@\0" );
        sprintf( a_stSlSummary->lc_line17, "%10s %s@\0", lc_money_iof,
                !a_salesSumm->get_TIP_IOF().compare("L") ? "DA LOJA" : 
                                                        "NA PARCELA" );
        oasis_dec_t lodt_money_cpmf = a_salesSumm->get_VAL_CPMF( );
        char l_cMoneyCpmf[ 14 ];
        dbm_dectochar( &lodt_money_cpmf, l_cMoneyCpmf );
        //sprintf( a_stSlSummary->lc_line16, "CPMF RECOLHIDO:   %10s@\0", 
        sprintf( a_stSlSummary->lc_line18, "CPMF RECOLHIDO:@\0" ); 
        sprintf( a_stSlSummary->lc_line19, "%10s@\0", l_cMoneyCpmf );            
        oasis_dec_t l_odtMoneyLqdo = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cMoneyLqdo[ 14 ];
        dbm_dectochar( &l_odtMoneyLqdo, l_cMoneyLqdo );
        //sprintf( a_stSlSummary->lc_line17, "VLR LIQUIDO (VPL): %10s@\0", 
        sprintf( a_stSlSummary->lc_line20, "VLR LIQUIDO (VPL):@\0" );
        sprintf( a_stSlSummary->lc_line21, "%10s@\0", 
                 l_cMoneyLqdo );
        //*a_stSlSummary->lc_line18 = 0;
        //*a_stSlSummary->lc_line19 = 0;
        //*a_stSlSummary->lc_line20 = 0;
        //*a_stSlSummary->lc_line21 = 0;
        *a_stSlSummary->lc_line22 = 0;
        *a_stSlSummary->lc_line23 = 0;
        *a_stSlSummary->lc_line24 = 0;
        *a_stSlSummary->lc_line25 = 0;            
        *a_stSlSummary->lc_line26 = 0;
        *a_stSlSummary->lc_line27 = 0;
        *a_stSlSummary->lc_line28 = 0;
        *a_stSlSummary->lc_line29 = 0;           
        *a_stSlSummary->lc_line30 = 0;           
        *a_stSlSummary->lc_line31 = 0;           
        *a_stSlSummary->lc_line32 = 0;           
        *a_stSlSummary->lc_line33 = 0;           
        if ( a_clMoreRecordsFlag ) 
        {
            //strcpy( a_stSlSummary->lc_line18, "HA MAIS RESUMOS       @\0" );
            strcpy( a_stSlSummary->lc_line22, "HA MAIS RESUMOS       @\0" );
        }        
        padSummary( a_stSlSummary );        
        fieldSet::fscopy( m_swmsgNuRv, l_ssNumRv.str( ) ); //Txn->swmsg.nu_rv = atoi(a_salesSumm.num_rvs);
        std::stringstream l_ssDtRv;
        l_ssDtRv << l_ttDthRrv;
        fieldSet::fscopy( m_swmsgDtRv, l_ssDtRv.str( ) ); //Txn->swmsg.dt_rv = a_salesSumm.dat_rvs;
        std::stringstream l_ssQtdCv;
        l_ssQtdCv << l_lQtdCv;
        fieldSet::fscopy( m_shcMsgShiftNumber, l_ssQtdCv.str( ) ); //Txn->shc.msg.shift_number = a_salesSumm.qtd_cv;
        oasis_dec_t l_odtActualAmount = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cActualAmount[ 14 ];
        dbm_dectochar( &l_odtActualAmount, l_cActualAmount );
        std::stringstream l_ssActualAmount;
        l_ssActualAmount << l_cActualAmount;
        fieldSet::fscopy( m_shcMsgActualAmount, l_ssActualAmount.str( ) );  //dbm_deccopy(&Txn->shc.msg.amount5, &a_salesSumm.val_totl_lqdo);
        oasis_dec_t l_odtAmount = a_salesSumm->get_VAL_TOTL_PAGO( );
        char l_cAmount[ 14 ];
        dbm_dectochar( &l_odtAmount, l_cAmount );
        std::stringstream l_ssAmount;
        l_ssAmount << l_cAmount;
        fieldSet::fscopy( m_shcMsgAmount, l_ssAmount.str( ) ); // dbm_deccopy(&Txn->shc.msg.amount,  &a_salesSumm.val_totl_pago);        
    }
            
    void TrxSales::fmtPdvSalesSummaryInstallment( const long a_clRefnum, 
                                                        const std::string& a_csTermPdvId, 
                                                        const std::string& a_csMerName, 
                                                        struct summ_lines* a_stSlSummary, 
                                                        dbaccess_pdv::SalesTablesJoint* a_salesSumm ) 
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== fmtPdvSalesSummaryInstallment ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        memset( ( char* ) a_stSlSummary, ' ', sizeof( struct summ_lines ) );
        sprintf( a_stSlSummary->lc_line01, "F                 REDE@\0" );        
        sprintf( a_stSlSummary->lc_line02, "%-20s@\0", a_salesSumm->get_NOM_BNDR( ).c_str( ) );
        sprintf( a_stSlSummary->lc_line03, "%-20s@\0", a_salesSumm->get_NOM_PROD( ).c_str( ) );
        sprintf( a_stSlSummary->lc_line04, "@\0" );
        oasis_dec_t l_odtNumRvs = a_salesSumm->get_NUM_RV( );
        long l_lNumRv;
        l_lNumRv = dbm_dectolong( &l_odtNumRvs );
        std::stringstream l_ssNumRv;
        l_ssNumRv << l_lNumRv;
        char l_cNumRvs[ 14 ];
        strncpy( l_cNumRvs, l_ssNumRv.str( ).c_str( ), 12 );
        l_cNumRvs[ 12 ] = '\0';
        sprintf( a_stSlSummary->lc_line05, 
                 "RES.VENDA: %012ld@\0", 
                 l_lNumRv );
        std::stringstream l_ssRefnum;
        l_ssRefnum << a_clRefnum;
        char l_cLine6[ 12 ];
        strncpy( l_cLine6, l_ssRefnum.str( ).c_str( ), 11 );                 
        sprintf( a_stSlSummary->lc_line06, 
                 "COMPROV:   %012ld@\0", 
                 a_clRefnum );
        time_t l_ttCurrentTime = time( 0 );
        struct tm* l_stmCurrentDate = localtime( &l_ttCurrentTime );
        long l_lCurDateDay = l_stmCurrentDate->tm_mday;
        long l_lCurDateMon = ( l_stmCurrentDate->tm_mon + 1 );
        long l_lCurDateYear = ( l_stmCurrentDate->tm_year - 100 );
        long l_lCurDateHour = l_stmCurrentDate->tm_hour;
        long l_lCurDateMin = l_stmCurrentDate->tm_min;
        long l_lCurDateSec = l_stmCurrentDate->tm_sec;
        //sprintf( a_stSlSummary->lc_line07, "DATA: %02d/%02d/%02d %02d:%02d:%02d@\0", 
        sprintf( a_stSlSummary->lc_line07, "DATA:  %02d/%02d/%02d      %02d.%02d@\0", 
                 l_lCurDateDay, l_lCurDateMon, l_lCurDateYear, 
                 l_lCurDateHour, l_lCurDateMin );
        //         l_lCurDateHour, l_lCurDateMin, l_lCurDateSec );
        std::stringstream l_ssNumPdv;
        l_ssNumPdv << a_salesSumm->get_NUM_PDV( );
        sprintf( a_stSlSummary->lc_line08, 
                 "ESTAB: %-9s     TERM: %8.8s@\0", 
                 l_ssNumPdv.str( ).c_str( ),
                 a_csTermPdvId.substr(0,8).c_str( ) );
        //sprintf( a_stSlSummary->lc_line08, 
        //         "ESTAB: %9s     @\0", 
        //         l_ssNumPdv.str( ).c_str( ) );
        //sprintf( a_stSlSummary->lc_line09, 
        //         "TERM: %8.8s@\0", 
        //         a_csTermPdvId.substr(0,8).c_str( ) );
        //sprintf( a_stSlSummary->lc_line09, "%s@\0", 
        sprintf( a_stSlSummary->lc_line09, "%-23s@\0", 
                 a_csMerName.substr(0,23).c_str() );                 
        time_t l_ttDthCreRv = a_salesSumm->get_DAT_CRE_RV( );
        struct tm* l_stmDthCreRv = localtime( &l_ttDthCreRv );
        long l_lDthCreRvDay = l_stmDthCreRv->tm_mday;
        long l_lDthCreRvMon = ( l_stmDthCreRv->tm_mon + 1 );
        long l_lDthCreRvYear = ( l_stmDthCreRv->tm_year - 100 );
        time_t l_ttDthIni = a_salesSumm->get_DTH_INI( );
        struct tm* l_stmDthIni = localtime( &l_ttDthIni );
        long l_lDthIniHour = l_stmDthIni->tm_hour;
        long l_lDthIniMin = l_stmDthIni->tm_min;
        long l_lDthIniSec = l_stmDthIni->tm_sec;
        time_t l_ttDthFim = a_salesSumm->get_DTH_FIM( );
        struct tm* l_stmDthFim = localtime( &l_ttDthFim );
        long l_lDthFimHour = l_stmDthFim->tm_hour;
        long l_lDthFimMin = l_stmDthFim->tm_min;
        long l_lDthFimSec = l_stmDthFim->tm_sec;
        //sprintf( a_stSlSummary->lc_line10, 
        sprintf( a_stSlSummary->lc_line10, 
                 "RESUMO: %02d/%02d/%02d     %02d:%02d A %02d:%02d@\0",
                 l_lDthCreRvDay, l_lDthCreRvMon, l_lDthCreRvYear,
                 l_lDthIniHour, l_lDthIniMin, 
                 l_lDthFimHour, l_lDthFimMin );
        //sprintf( a_stSlSummary->lc_line10, 
        //         "DT RESUMO:  %02d/%02d/%02d@\0",
        //         l_lDthCreRvDay, l_lDthCreRvMon, l_lDthCreRvYear );
        //sprintf( a_stSlSummary->lc_line11, 
        //         " %02d:%02d:%02d A %02d:%02d:%02d@\0",
        //         l_lDthIniHour, l_lDthIniMin, l_lDthIniSec,
        //         l_lDthFimHour, l_lDthFimMin, l_lDthFimSec );        
        oasis_dec_t l_odtQtdCv = a_salesSumm->get_QTD_CV( );
        long l_lQtdCv;
        l_lQtdCv = dbm_dectolong( &l_odtQtdCv );
        //sprintf( a_stSlSummary->lc_line11, "QTDE CVS: %5d@\0", l_lQtdCv );
        sprintf( a_stSlSummary->lc_line11, "QTDE CVS: %5d@\0", l_lQtdCv );
                
        oasis_dec_t l_odtMoneyVendas = a_salesSumm->get_VAL_TOTL_PAGO( );
        char l_cAmount[ 14 ];
        dbm_dectochar( &l_odtMoneyVendas, l_cAmount );
        std::stringstream l_ssAmount;
        l_ssAmount << l_cAmount;            
        fieldSet::fscopy( m_shcMsgAmount, l_ssAmount.str( ) ); //dbm_deccopy(&shcmsg->amount, &a_salesSumm->val_totl_pago);
        oasis_dec_t l_odtMoneyDescto = a_salesSumm->get_VAL_TOTL_DSCT( );
        char lc_money_desc[ 14 ];
        dbm_dectochar( &l_odtMoneyDescto, lc_money_desc );
		strcpy( l_cAmount, GetBrDecimalFormat( std::string( l_cAmount ) ).c_str() );
		strcpy( lc_money_desc, GetBrDecimalFormat( std::string( lc_money_desc ) ).c_str() );
        sprintf( a_stSlSummary->lc_line12, 
                 "TOTAL:%10s  DESC:%10s@\0", 
				 l_cAmount, lc_money_desc );
        //sprintf( a_stSlSummary->lc_line12, 
        //         "TOTAL:%10s@\0", 
        //         l_cAmount );
        //sprintf( a_stSlSummary->lc_line13, 
        //         "DESC:%10s@\0", 
        //         lc_money_desc );
        oasis_dec_t l_odtMoneyGorjt = a_salesSumm->get_VAL_TOTL_GRJT( );
        oasis_dec_t l_odtMoneyGorjt2;
		dbm_deccopy(&l_odtMoneyGorjt, &l_odtMoneyGorjt2);
        char l_cMoneyGrjt[ 14 ];
        dbm_dectochar( &l_odtMoneyGorjt2, l_cMoneyGrjt );
        oasis_dec_t l_odtMoneyLqdo = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cMoneyLqdo[ 14 ];
        dbm_dectochar( &l_odtMoneyLqdo, l_cMoneyLqdo );
		strcpy( l_cMoneyGrjt, GetBrDecimalFormat( std::string( l_cMoneyGrjt ) ).c_str() );
		strcpy( l_cMoneyLqdo, GetBrDecimalFormat( std::string( l_cMoneyLqdo ) ).c_str() );
        sprintf( a_stSlSummary->lc_line13, 
                 "GORJ:  %10s  LIQ.TOT:%10s@\0", 
                 l_cMoneyGrjt, l_cMoneyLqdo );
        //sprintf( a_stSlSummary->lc_line14, 
        //         "GORJ:  %10s@\0", 
        //         l_cMoneyGrjt );
        //sprintf( a_stSlSummary->lc_line15, 
        //         "LIQ.TOT:%10s@\0", 
        //         l_cMoneyLqdo );
  
        oasis_dec_t l_odtMoneyPrcl = a_salesSumm->get_VAL_PRCL( );
        char l_cMoneyPrcl[ 14 ];
        dbm_dectochar( &l_odtMoneyPrcl, l_cMoneyPrcl );
        time_t l_ttDthPrcl = a_salesSumm->get_DAT_PRCL( );
        struct tm* l_stmDthPrcl = localtime( &l_ttDthPrcl );
        long l_lDthPrclDay = l_stmDthPrcl->tm_mday;
        long l_lDthPrclMon = ( l_stmDthPrcl->tm_mon + 1 );
        long l_lDthPrclYear = ( l_stmDthPrcl->tm_year - 100 );
		strcpy( l_cMoneyPrcl, GetBrDecimalFormat( std::string( l_cMoneyPrcl ) ).c_str() );
        sprintf( a_stSlSummary->lc_line14, 
                 "LIQ.1.PAR: %10s  EM  %02d/%02d/%02d@\0", 
				 l_cMoneyPrcl, l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear );
        //sprintf( a_stSlSummary->lc_line16, 
        //         "LIQ.1.PAR: %10s@\0", 
        //         l_cMoneyPrcl );      
        //sprintf( a_stSlSummary->lc_line17, 
        //         "EM  %02d/%02d/%02d@\0", 
        //         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear );      
        //sprintf( a_stSlSummary->lc_line15, "DEMAIS PGTOS@\0" );
        sprintf( a_stSlSummary->lc_line15, "DEMAIS PGTOS@\0" );
        //sprintf( a_stSlSummary->lc_line16, "DT CRED.    VL.LIQ.@\0" );
        sprintf( a_stSlSummary->lc_line16, "DT CRED.    VL.LIQ.@\0" );
        sprintf( a_stSlSummary->lc_line17, " @\0" );
        sprintf( a_stSlSummary->lc_line18, " @\0" );
        sprintf( a_stSlSummary->lc_line19, " @\0" );
        sprintf( a_stSlSummary->lc_line20, " @\0" );
        sprintf( a_stSlSummary->lc_line21, " @\0" );
        sprintf( a_stSlSummary->lc_line22, " @\0" );
        sprintf( a_stSlSummary->lc_line23, " @\0" );
        sprintf( a_stSlSummary->lc_line24, "\0" );
        sprintf( a_stSlSummary->lc_line25, "\0" );
        sprintf( a_stSlSummary->lc_line26, "\0" );
        sprintf( a_stSlSummary->lc_line27, "\0" );
        sprintf( a_stSlSummary->lc_line28, "\0" );
        sprintf( a_stSlSummary->lc_line29, "\0" );
        sprintf( a_stSlSummary->lc_line30, "\0" );
        sprintf( a_stSlSummary->lc_line31, "\0" );
        sprintf( a_stSlSummary->lc_line32, "\0" );
        sprintf( a_stSlSummary->lc_line33, "\0" );
        fieldSet::fscopy( m_swmsgNuRv, l_ssNumRv.str( ) ); //Txn->swmsg.nu_rv = atoi(a_salesSumm.num_rvs);
        time_t l_ttDthRrv = a_salesSumm->get_DAT_RV( );        
        std::stringstream l_ssDtRv;
        l_ssDtRv << l_ttDthRrv;
        fieldSet::fscopy( m_swmsgDtRv, l_ssDtRv.str( ) ); //Txn->swmsg.dt_rv = a_salesSumm.dat_rvs;
        std::stringstream l_ssQtdCv;
        l_ssQtdCv << l_lQtdCv;
        fieldSet::fscopy( m_shcMsgShiftNumber, l_ssQtdCv.str( ) ); //Txn->shc.msg.shift_number = a_salesSumm.qtd_cv;
        oasis_dec_t l_odtActualAmount = a_salesSumm->get_VAL_TOTL_LQDO( );
        char l_cActualAmount[ 14 ];
        dbm_dectochar( &l_odtActualAmount, l_cActualAmount );
        std::stringstream l_ssActualAmount;
        l_ssActualAmount << l_cActualAmount;
        fieldSet::fscopy( m_shcMsgActualAmount, l_ssActualAmount.str( ) );  //dbm_deccopy(&Txn->shc.msg.amount5, &a_salesSumm.val_totl_lqdo);
        fieldSet::fscopy( m_shcMsgAmount, l_ssAmount.str( ) ); // dbm_deccopy(&Txn->shc.msg.amount,  &a_salesSumm.val_totl_pago);         
    }    
    
    void TrxSales::doPdvLinesCredidlrIata( struct summ_lines* a_stSlSummary, 
                                               dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
                                               const int a_ciLinha ) 
    {
        static char * l_linep;
        static int  l_nparc;
        static int  l_currLine;
        char l_aux[15];

        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== doPdvLinesCredidlrIata ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        if( a_ciLinha == 1 || ( a_salesSumm->get_IND_NUM_QBRA( ) == 1 && 
                                a_ciLinha == 2 ) )
        {
            l_linep = (char *)&a_stSlSummary->lc_line07;
            time_t l_ttCurrentTime = time( 0 );
            struct tm* l_stmCurrentDate = localtime( &l_ttCurrentTime );
            long l_lCurDateYear = ( l_stmCurrentDate->tm_year + 1900 );            
            sprintf( l_linep, "%04d@", l_lCurDateYear );
            l_linep += sizeof( a_stSlSummary->lc_line07);
            l_nparc = 1;
            l_currLine = 8;
        }
        if( l_nparc > 3)
        {
            if( l_currLine == 28 ) 
            {
                sprintf( a_stSlSummary->lc_line28, 
                         "Existem outras parcelas!@\0" );    
                return;
            }
            l_linep += sizeof( a_stSlSummary->lc_line07);
            l_nparc = 1;
            l_currLine++;
        }
        oasis_dec_t l_odtMoneyPrcl = a_salesSumm->get_VAL_PRCL( );
        dbm_decnmul( &l_odtMoneyPrcl, 100 );
        char l_cMoneyPrcl[ 14 ];
        dbm_dectocharnd( &l_odtMoneyPrcl, l_cMoneyPrcl );
        time_t l_ttDthPrcl = a_salesSumm->get_DAT_PRCL( );
        struct tm* l_stmDthPrcl = localtime( &l_ttDthPrcl );
        long l_lDthPrclDay = l_stmDthPrcl->tm_mday;
        long l_lDthPrclMon = ( l_stmDthPrcl->tm_mon + 1 );
        sprintf( l_aux, "%02d%02d%7s@", l_lDthPrclDay, l_lDthPrclMon, 
                 l_cMoneyPrcl );
        sprintf( l_linep + ( ( l_nparc - 1) * strlen( l_aux ) ), 
                 "%s", l_aux );
        l_nparc++;
    }
    
    void TrxSales::doPdvLines( struct summ_lines* a_stSlSummary, 
                                 dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
                                 const int a_ciLinha ) 
    {
        oasis_dec_t l_odtMoneyPrcl = a_salesSumm->get_VAL_PRCL( );
        char l_cMoneyPrcl[ 14 ];
        dbm_dectochar( &l_odtMoneyPrcl, l_cMoneyPrcl );
        time_t l_ttDthPrcl = a_salesSumm->get_DAT_PRCL( );
        struct tm* l_stmDthPrcl = localtime( &l_ttDthPrcl );
        long l_lDthPrclDay = l_stmDthPrcl->tm_mday;
        long l_lDthPrclMon = ( l_stmDthPrcl->tm_mon + 1 );
        long l_lDthPrclYear = ( l_stmDthPrcl->tm_year - 100 );

        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== doPdvLines ==== - a_ciLinha = " << a_ciLinha;
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

		l_cMoneyPrcl[strcspn( l_cMoneyPrcl, "." )] = ',';
        switch ( a_ciLinha ) 
        {
            case ( 0 ): 
                sprintf( a_stSlSummary->lc_line17, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line21, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 1 ): 
                sprintf( a_stSlSummary->lc_line18, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line22, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 2 ): 
                sprintf( a_stSlSummary->lc_line19, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line23, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 3 ): 
                sprintf( a_stSlSummary->lc_line20, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line24, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 4 ): 
                sprintf( a_stSlSummary->lc_line21, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line25, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 5 ): 
                sprintf( a_stSlSummary->lc_line22, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line26, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 6 ): 
                sprintf( a_stSlSummary->lc_line23, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line27, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 7 ): 
                sprintf( a_stSlSummary->lc_line24, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line28, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 8 ): 
                sprintf( a_stSlSummary->lc_line25, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line29, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 9 ): 
                sprintf( a_stSlSummary->lc_line26, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line30, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 10 ): 
                sprintf( a_stSlSummary->lc_line27, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line31, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            case ( 11 ): 
                sprintf( a_stSlSummary->lc_line28, "%02d/%02d/%02d% 9s@\0",
                //sprintf( a_stSlSummary->lc_line32, "%02d/%02d/%02d% 9s@\0",
                         l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
                         l_cMoneyPrcl );
                break;
            //case ( 12 ): 
            //    sprintf( a_stSlSummary->lc_line28, "%02d/%02d/%02d% 9s@\0",
            //    //sprintf( a_stSlSummary->lc_line33, "%02d/%02d/%02d% 9s@\0",
            //             l_lDthPrclDay, l_lDthPrclMon, l_lDthPrclYear,
            //             l_cMoneyPrcl );
            //    break;
            default:
            	//default
            	break;
        }                 
    }    

    int TrxSales::fmtSalesSummaryQtdPrcl( const long a_clNumPdv,
                                          const long a_clRefnum, 
                                          const std::string& a_csTermPdvId, 
                                          const std::string& a_csMerName,
                                          dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
                                          const int a_ciMoreRecordsFlag ) 
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== fmtSalesSummaryQtdPrcl ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        try 
        {
            struct summ_lines a_stSlSummary;
            memset( &a_stSlSummary, 0, sizeof( struct summ_lines ) );
            long l_lIndNumQbra = a_salesSumm->get_IND_NUM_QBRA( );
            int l_iLinha = 0;
            int l_iFlagBody = 0;
            do
            {    
                if ( l_lIndNumQbra == 1 ) 
                {
                    if ( !l_iFlagBody ) 
                    {
                        if( a_salesSumm->get_COD_PROD() == 5    ||    
                            a_salesSumm->get_COD_PROD() == 6 )
                        {
                            fmtPdvSalesSummaryCredidlrIata( a_clNumPdv,
                                                            a_clRefnum,
                                                            a_csTermPdvId,
                                                            a_csMerName,
                                                            &a_stSlSummary,
                                                            a_salesSumm );
                        }
                        else
                        {
                            fmtPdvSalesSummaryInstallment( a_clRefnum, 
                                                           a_csTermPdvId, 
                                                           a_csMerName,
                                                           &a_stSlSummary,
                                                           a_salesSumm );
                        }
                        l_iFlagBody = 1;
                    }
                    else
                    {
                        if ( a_salesSumm->get_COD_PROD() != 5 &&
                             a_salesSumm->get_COD_PROD() != 6 )
                        {
                            doPdvLines( &a_stSlSummary, a_salesSumm, l_iLinha );
                        }
                        else
                        {
                            doPdvLinesCredidlrIata( &a_stSlSummary, a_salesSumm, l_iLinha );
                        }
                    }
                }
                else
                {
                    if ( !l_iFlagBody ) 
                    {
                        if( a_salesSumm->get_COD_PROD() == 5    ||    
                            a_salesSumm->get_COD_PROD() == 6 )
                        {
                            fmtPdvSalesSummaryCredidlrIata( a_clNumPdv,
                                                            a_clRefnum,
                                                            a_csTermPdvId,
                                                            a_csMerName,
                                                            &a_stSlSummary,
                                                            a_salesSumm );
                        }
                        else
                        {
                            fmtPdvSalesSummaryInstallment( a_clRefnum, 
                                                           a_csTermPdvId, 
                                                           a_csMerName,
                                                           &a_stSlSummary,
                                                           a_salesSumm );
                        }
                        l_iFlagBody = 1;
                    }
                    if ( a_salesSumm->get_COD_PROD() != 5 &&
                         a_salesSumm->get_COD_PROD() != 6 )
                    {
                        doPdvLines( &a_stSlSummary, a_salesSumm, l_iLinha );
                    }
                    else
                    {
                        doPdvLinesCredidlrIata( &a_stSlSummary, a_salesSumm, l_iLinha );
                    }
                }
                l_iLinha++;
             }
            while ( a_salesSumm->fetch( ) );
            std::string l_sValFlagQbra = a_salesSumm->get_VAL_FLAG_QBRA( );
            if ( a_ciMoreRecordsFlag )            
            {
                if( l_sValFlagQbra.compare("S") == 0 )
                {
                    sprintf( a_stSlSummary.lc_line29, "NOVO RV P/PROX.PGTOS@\0" );
                }
                else
                {
                    sprintf( a_stSlSummary.lc_line29, "HA MAIS RESUMOS       @\0" );
                }
            }
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, a_stSlSummary.lc_line29 );
            padSummary( &a_stSlSummary );
            return( 1 );
        }
        catch ( base::GenException e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::genexception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
        catch ( std::exception e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::exception in " +
                                    std::string(__FUNCTION__) + " <" +
                                    l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
    }
    

    int TrxSales::getElegivelRAV( const long a_clNumPdv ) 
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== getElegivelRAV ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        try
        {
            std::stringstream l_sWhereClause;
            l_sWhereClause << "NUM_PDV = " << a_clNumPdv;
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, 
                " ====[ TRXSALES_PLUGIN ]- Clausula Where -[ getElegivelRAV ]=== " );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_sWhereClause.str().c_str() );
            dbaccess_common::TBSW0051 l_tTBSW0051( l_sWhereClause.str( ) );
            l_tTBSW0051.prepare( );
            l_tTBSW0051.execute( );
            if ( ! l_tTBSW0051.fetch( ) )
            {    
                return( 0 );
            }
            std::string l_sCodSttuReg;
            l_sCodSttuReg = l_tTBSW0051.get_COD_STTU_REG( );        
            if ( l_sCodSttuReg.at( 0 ) == 'A' ) 
            {
                return( 1 );
            }
            else
            {
                return( 0 );
            }
        }
        catch ( base::GenException e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::genexception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
        catch ( std::exception e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::exception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
    }

    char TrxSales::getTerminalTechGroup( const long a_clInTpoTcn ) 
    {
        char l_cTechGroup;        
        switch ( a_clInTpoTcn ) 
        {
            case 7:
                l_cTechGroup = 'G';
                break;
            case 8:
                l_cTechGroup = 'P';
                break;
            case 27:
                l_cTechGroup = 'F';
                break;
            case 36:
                l_cTechGroup = '6';
                break;
            default:
                l_cTechGroup = 'H';
        }
        return( l_cTechGroup );
    }
    
    long TrxSales::getNumRV( const long a_clNumPdv, 
                             const char a_ccTechGroup )
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== getNumRV ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        try
        {
            std::stringstream l_sWhereClause;
            std::stringstream l_sWhereClauseLoader;
            l_sWhereClauseLoader << "NUM_PDV = '" << a_clNumPdv << "'" << " AND ";
            l_sWhereClauseLoader << "COD_TCNL = '" << a_ccTechGroup << "' AND ";
            l_sWhereClauseLoader << "VAL_SIT_RVS = 0";
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, 
                " ====[ TRXSALES_PLUGIN ]- Clausula Where -[ getNumRV ]=== " );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_sWhereClauseLoader.str().c_str() );
            dbaccess_common::TBSW0045 l_tTBSW0045Loader( l_sWhereClauseLoader.str( ) );
            l_tTBSW0045Loader.prepare( );
            l_tTBSW0045Loader.execute( );
            long l_lNumRV = 0;
            if ( ! l_tTBSW0045Loader.fetch( ) )
            {
                l_lNumRV = 0;
            }
            else
            {
                oasis_dec_t l_odtNumRv = l_tTBSW0045Loader.get_NUM_RV( );
                l_lNumRV = dbm_dectolong( &l_odtNumRv );
            }
            return( l_lNumRV );
        }
        catch ( base::GenException e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::genexception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
        catch ( std::exception e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::exception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
    }

    int TrxSales::getNumQBRA( const long a_clNumPdv, 
                              const char a_ccTechGroup )
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== getNumQBRA ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        try
        {
            std::stringstream l_sWhereClause;
            std::stringstream l_sWhereClauseLoader;
            l_sWhereClauseLoader << "NUM_PDV = '" << a_clNumPdv << "'" << " AND ";
            l_sWhereClauseLoader << "COD_TCNL = '" << a_ccTechGroup << "' AND ";
            l_sWhereClauseLoader << "VAL_SIT_RVS = 0";
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, 
                " ====[ TRXSALES_PLUGIN ]- Clausula Where -[ getNumQBRA ]=== " );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_sWhereClauseLoader.str().c_str() );
            dbaccess_common::TBSW0045 l_tTBSW0045Loader( l_sWhereClauseLoader.str( ) );
            l_tTBSW0045Loader.prepare( );
            l_tTBSW0045Loader.execute( );
            int l_iNumQBRA = 0;
            if ( ! l_tTBSW0045Loader.fetch( ) )
            {
                l_iNumQBRA = 0;
            }
            else
            {
                l_iNumQBRA = l_tTBSW0045Loader.get_IND_NUM_QBRA( );
            }
            return( l_iNumQBRA );
        }
        catch ( base::GenException e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::genexception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
        catch ( std::exception e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::exception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
    }
    
    int TrxSales::getMoreRecordsFlag( const long a_clNumPdv, 
                                      const char a_ccTechGroup,
                                      const long a_clNumRv,
                                      const int numQuebra )
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== getMoreRecordsFlag ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        try
        {
            std::stringstream l_sWhereClause;    
            l_sWhereClause << "NUM_PDV = " << a_clNumPdv << " AND ";
            l_sWhereClause << "COD_TCNL = '" << a_ccTechGroup << "' AND ";
            l_sWhereClause << "(NUM_RV <> " << a_clNumRv << " OR ";
			l_sWhereClause << "IND_NUM_QBRA <> " << numQuebra << ") AND ";
            l_sWhereClause << "VAL_SIT_RVS = 0";
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, 
                " ====[ TRXSALES_PLUGIN ]- Clausula Where -[ getMoreRecordsFlag ]=== " );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_sWhereClause.str().c_str() );
            dbaccess_common::TBSW0045 l_tTBSW0045Loader( l_sWhereClause.str( ) );
            l_tTBSW0045Loader.prepare( );
            l_tTBSW0045Loader.execute( );
            int li_moreRecords = 0;
            if ( ! l_tTBSW0045Loader.fetch( ) ) 
            {
                li_moreRecords = 0;
            }
            else
            {
                li_moreRecords = 1;
            }
            return( li_moreRecords );
        }
        catch ( base::GenException e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::genexception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
        catch ( std::exception e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::exception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
    }

/// prepareGetSalesSumm
/// Prepara dados do resumo de venda
/// EF/ET: EAK-1902
/// Histórico: [Data] - ET - Descrição
/// 16/12/2019 - EAK1902 - Retirada da atualização do status na consulta
/// [Data] - ET - Descrição
/// a_clNumRv: Numero do RV
/// a_ciNumQbra: Numero da quebra
/// a_clNumPdv: Numero do PV
/// a_csTermPdvId: ID do terminal
/// a_ccTechGroup: Grupo de tecnologia
/// a_clTrace: STAN da transacao
    int TrxSales::prepareGetSalesSumm( const long a_clNumRv,
                                       const int a_ciNumQbra,
                                       const long a_clNumPdv, 
                                       const std::string& a_csTermPdvId, 
                                       const char a_ccTechGroup,
                                       const long a_clTrace )
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== prepareGetSalesSumm ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        try
        {
            std::stringstream l_sWhereClauseUpdate;
            l_sWhereClauseUpdate << "NUM_RV = " << a_clNumRv << " AND ";
            l_sWhereClauseUpdate << "IND_NUM_QBRA = " << a_ciNumQbra << " AND ";
            l_sWhereClauseUpdate << "NUM_PDV = '" << a_clNumPdv << "'" << " AND ";
            l_sWhereClauseUpdate << "COD_TCNL = '" << a_ccTechGroup << "'";
            dbaccess_common::TBSW0045 l_tTBSW0045Updater( l_sWhereClauseUpdate.str( ) );
            l_tTBSW0045Updater.prepare_for_update( );
            l_tTBSW0045Updater.execute( );
            if ( l_tTBSW0045Updater.fetch( ) )
            {
                l_tTBSW0045Updater.let_QTD_CV_as_is();
                l_tTBSW0045Updater.let_VAL_TOTL_LQDO_as_is();
                l_tTBSW0045Updater.let_VAL_TOTL_DSCT_as_is();
                l_tTBSW0045Updater.set_COD_TERM( a_csTermPdvId );
                l_tTBSW0045Updater.set_NUM_STAN( a_clTrace );
                //l_tTBSW0045Updater.set_VAL_SIT_RVS( 1 );
                l_tTBSW0045Updater.update( );                
            }
            l_tTBSW0045Updater.commit( );
            return 0;
        }
        catch ( base::GenException e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::genexception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
        catch ( std::exception e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::exception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
    }
    
    int TrxSales::getSalesSumm( const long a_clNumPdv,
                                const std::string& a_csTermPdvId,
                                const long a_clRefnum,
                                const std::string& a_csMerName,
                                const long a_clInTpoTcn,
                                const long a_clTrace)
    {
        std::stringstream l_ss_AUX;
        l_ss_AUX << "==== getSalesSumm ====";
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ss_AUX.str().c_str() );

        try 
        {
            char l_cTechGroup;
            l_cTechGroup = getTerminalTechGroup( a_clInTpoTcn );    
            long l_lNumRv = 0;
            l_lNumRv = getNumRV( a_clNumPdv, l_cTechGroup );
            if ( l_lNumRv == -1 ) 
            {
                this->setErrorMessage( "l_lNumRv == -1" );
                this->enableError( true );
                return( -1 );
            }
            int l_iNumQbra = 0;
            l_iNumQbra = getNumQBRA( a_clNumPdv, l_cTechGroup );
            if ( l_iNumQbra == -1 ) 
            {
                this->setErrorMessage( "l_iNumQbra == -1" );
                this->enableError( true );
                return( -1 );
            }
            int l_iRetPrpGetSalSum = 0;
            l_iRetPrpGetSalSum = prepareGetSalesSumm( l_lNumRv,  
                                                      l_iNumQbra,
                                                      a_clNumPdv, 
                                                      a_csTermPdvId, 
                                                      l_cTechGroup,
                                                      a_clTrace );
            if ( l_iRetPrpGetSalSum == -1 )
            {
                this->setErrorMessage( "l_iRetPrpGetSalSum == -1" );
                this->enableError( true );
                return( -1 );
            }
            int l_lMoreRecordsFlag = 0;
            l_lMoreRecordsFlag = getMoreRecordsFlag( a_clNumPdv,
                                                     l_cTechGroup,
                                                     l_lNumRv,
                                                     l_iNumQbra );
            if ( l_lMoreRecordsFlag == -1 ) 
            {
                this->setErrorMessage( "l_lMoreRecordsFlag == -1" );
                this->enableError( true );
                return( -1 );
            }
            std::stringstream l_sWhereClause;
            l_sWhereClause << "TB45.NUM_PDV = " << a_clNumPdv << " AND ";
            l_sWhereClause << "TB45.COD_TCNL = '" << l_cTechGroup << "' AND ";
            l_sWhereClause << "TB45.NUM_RV = " << l_lNumRv << " AND ";
            l_sWhereClause << "TB45.IND_NUM_QBRA = " << l_iNumQbra << " AND ";
            l_sWhereClause << "TB46.NUM_PDV(+) = TB45.NUM_PDV AND ";
            l_sWhereClause << "TB46.NUM_RV(+) = TB45.NUM_RV AND ";
            l_sWhereClause << "TB46.IND_NUM_QBRA(+) = TB45.IND_NUM_QBRA" ;
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, 
                " ====[ TRXSALES_PLUGIN ]- Clausula Where -[ getSalesSumm ]=== " );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_sWhereClause.str().c_str() );
            dbaccess_pdv::SalesTablesJoint l_tTBSWSalesLoader( l_sWhereClause.str( ) );
            l_tTBSWSalesLoader.prepare( );
            l_tTBSWSalesLoader.execute( );
            if ( ! l_tTBSWSalesLoader.fetch( ) ) 
            {
                struct summ_lines a_stSlSummary;
                memset( &a_stSlSummary, 0, sizeof( struct summ_lines ) );                
                fmtPdvSalesSummaryNoRow( a_csTermPdvId,
                                         a_clNumPdv,
                                         &a_stSlSummary );
                std::stringstream l_ssReport;
                l_ssReport << m_buff63;
                fieldSet::fscopy( m_report, l_ssReport.str( ) );
                return( 0 );
            }
            else
            {
                long l_lCodBndr = l_tTBSWSalesLoader.get_COD_BNDR( );
                long l_lCodProd = l_tTBSWSalesLoader.get_COD_PROD( );
                long l_lQtdPprcl = l_tTBSWSalesLoader.get_QTD_PRCL( );
                time_t l_ttDthPrcl = l_tTBSWSalesLoader.get_DAT_PRCL( );
                long l_lDthPrcl = ( long ) l_ttDthPrcl;
                long l_lNumPrcl = l_tTBSWSalesLoader.get_NUM_PRCL( );
                if ( ( l_lCodBndr ==  3 ) && ( l_lCodProd == 50 ) ) 
                {
                    struct summ_lines a_stSlSummary;
                    memset( &a_stSlSummary, 0, sizeof( struct summ_lines ) );
                    fmtPdvSalesSummaryParcelemais( a_clRefnum, 
                                                   a_csTermPdvId, 
                                                   a_csMerName, 
                                                   &a_stSlSummary, 
                                                   &l_tTBSWSalesLoader,
                                                   l_lMoreRecordsFlag );
                    std::stringstream l_ssReport;
                    l_ssReport << m_buff63;
                    fieldSet::fscopy( m_report, l_ssReport.str( ) );                    
                    return( 1 );
                }
                else if ( ( l_lCodBndr == 8 ) && ( l_lCodProd == 8 ) ) 
                {
                    struct summ_lines a_stSlSummary;
                    memset( &a_stSlSummary, 0, sizeof( struct summ_lines ) );
                    fmtPdvSalesSummaryPostDated( a_clRefnum, 
                                                 a_csTermPdvId, 
                                                 a_csMerName, 
                                                 &a_stSlSummary, 
                                                 &l_tTBSWSalesLoader, 
                                                 l_lMoreRecordsFlag );                     
                    std::stringstream l_ssReport;
                    l_ssReport << m_buff63;
                    fieldSet::fscopy( m_report, l_ssReport.str( ) );
                    return( 1 );
                }                
                else if ( l_lQtdPprcl > 0 )
                {
                    if ( ( l_lDthPrcl == 0 ) && ( l_lNumPrcl == 0 ) ) 
                    {
			std::stringstream l_ssInfo;
			l_ssInfo << "Inconsistent data in tables: dth_prcl and num_prcl is zero when QTD_PRCL is greater than zero.";
                        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_ssInfo.str().c_str() );
                        struct summ_lines a_stSlSummary;
                        memset( &a_stSlSummary, 0, sizeof( struct summ_lines ) );                
                        fmtPdvSalesSummaryNoRow( a_csTermPdvId,
                                                 a_clNumPdv,
                                                 &a_stSlSummary );
                        std::stringstream l_ssReport;
                        l_ssReport << m_buff63;
                        fieldSet::fscopy( m_report, l_ssReport.str( ) );
                        return( 0 );
                    }
                    int l_iReturn = 0;
                    l_iReturn = fmtSalesSummaryQtdPrcl( a_clNumPdv,
                                                        a_clRefnum, 
                                                        a_csTermPdvId,
                                                        a_csMerName,
                                                        &l_tTBSWSalesLoader,
                                                        l_lMoreRecordsFlag );
                    std::stringstream l_ssReport;
                    l_ssReport << m_buff63;
                    fieldSet::fscopy( m_report, l_ssReport.str( ) );
                    return( l_iReturn );
                }
                else
                {                
                    struct summ_lines a_stSlSummary;
                    memset( &a_stSlSummary, 0, sizeof(struct summ_lines));
                    fmtPdvSalesSummaryGeneral( a_clRefnum, 
                                               a_csTermPdvId, 
                                               a_csMerName, 
                                               &a_stSlSummary, 
                                               &l_tTBSWSalesLoader,                                                       
                                               l_lMoreRecordsFlag);
                    std::stringstream l_ssReport;
                    l_ssReport << m_buff63;
                    fieldSet::fscopy( m_report, l_ssReport.str( ) );
                    return( 1 );
                }
            }
        }
        catch ( base::GenException e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::genexception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
        catch ( std::exception e )
        {
            std::string l_what( e.what( ) );
            this->setErrorMessage( "std::exception in " + 
                                   std::string(__FUNCTION__) + " <" +
                                   l_what + ">" );
            this->enableError( true );
            return( -1 );
        }
    }

/// GetBrDecimalFormat
/// Retorna valor no formato numerico de US para BR
/// EF/ET: EAK-2419
/// Histórico: 28/02/2020 - EAK-2419 - Versao inicial
/// [Data] - ET - Descrição
/// [Data] - ET - Descrição
/// usDecFormat: String com numero no formato US
	std::string TrxSales::GetBrDecimalFormat( std::string usDecFormat )
	{
		size_t decPosition = -1;
		int decimalDigits = 0;
		std::string brDecFormat;
		char strAux[256];
		
		// Busca ultimo '.' (deve haver apenas 1)
		decPosition = usDecFormat.find_last_of('.');
		
		// Se encontrou o '.', define a quantidade de casas decimais (se não encontrou mantem 0)
		if( decPosition != std::string::npos )
		{
			decimalDigits = usDecFormat.length() - decPosition - 1;
		}
		else
		{
			decPosition = usDecFormat.length();
		}
		
		// Verifica se tera separador de milhar
		if( decPosition > 3 )
		{
			int firstDot = decPosition % 3;
			
			brDecFormat = usDecFormat.substr( 0, firstDot );
			
			for( int thousSep = 0; thousSep < ( decPosition / 3 ); thousSep++)
			{
				brDecFormat.append(".");
				brDecFormat.append( usDecFormat.substr( firstDot + ( thousSep * 3 ), 3 ) );
			}
		}
		else
		{
			brDecFormat = usDecFormat.substr( 0, decPosition );
		}
		
		if( decimalDigits > 0 )
		{
			brDecFormat.append( "," );
			brDecFormat.append( usDecFormat.substr( decPosition + 1 ) );
		}

		return brDecFormat;
	}
    
}//namespace plugins_pdv
