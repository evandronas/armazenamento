/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0113Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0113Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: < 698224, Raphael Ferreira Gomes>
/ Data de Cria��o: <2013, 21 de Fevereiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0113.hpp"
#include "plugins_pdv/TBSW0113Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
  base::Identificable* createTBSW0113Loader()
  {
    TBSW0113Loader* l_new = new TBSW0113Loader;     
    return l_new;
  }

  TBSW0113Loader::TBSW0113Loader()
  {
  }

  TBSW0113Loader::~TBSW0113Loader()
  {
  }
  
  bool TBSW0113Loader::startConfiguration( const configBase::Tag* a_tag )
  {
    configBase::TagList l_tagList;

    a_tag->findTag( "sourceFieldPath", l_tagList );
    this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );
    
    a_tag->findTag( "targetFieldPath", l_tagList );
    this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

    return true;    
  }
  
  bool TBSW0113Loader::init()
  {
        m_result = this->navigate( m_targetFieldPath + ".result" );
        m_cod_sttu_reg = this->navigate( m_targetFieldPath + ".COD_STTU_REG" );    
        m_num_rtdr = this->navigate( m_targetFieldPath + ".NUM_RTDR" );        
        m_cod_sbpd = this->navigate( m_targetFieldPath + ".COD_SBPD" );        
        m_cod_emsr = this->navigate( m_targetFieldPath + ".COD_EMSR" );        
        m_nom_emsr = this->navigate( m_targetFieldPath + ".NOM_EMSR" );        
        m_cod_tran_ge = this->navigate( m_targetFieldPath + ".COD_TRAN_GE" );     
        m_nom_prod_cpom = this->navigate( m_targetFieldPath + ".NOM_PROD_CPOM" );   
        m_txt_rdpe_cpom = this->navigate( m_targetFieldPath + ".TXT_RDPE_CPOM" );   
        m_cod_usr_atlz_reg = this->navigate( m_targetFieldPath + ".COD_USR_ATLZ_REG" );
        m_dat_atlz_reg = this->navigate( m_targetFieldPath + ".DAT_ATLZ_REG" );    
        m_dat_atvc_voch = this->navigate( m_targetFieldPath + ".DAT_ATVC_VOCH" );   
        m_ntwkid = this->navigate( m_targetFieldPath + ".NTWKID" );          
        m_num_bin = this->navigate( m_targetFieldPath + ".NUM_BIN" );               
               
        m_bin = this->navigate( m_sourceFieldPath + ".segments.common.bin" );  
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" ); 
        m_track2 = this->navigate( m_sourceFieldPath + ".shc_msg.track2" );
		m_is_3a_perna = this->navigate( m_sourceFieldPath + ".segments.common.is_3a_perna" );
                          

    return true;
  }

  void TBSW0113Loader::finish()
  {
  }

  int TBSW0113Loader::execute( bool& a_stop )
  {
    try
    {
		  std::ostringstream l_whereClause;
		  unsigned long l_bin, l_msgtype;
		  std::string l_track2, l_is_3a_perna;
		  
		  fieldSet::fsextr( l_bin, m_bin );
		  fieldSet::fsextr( l_msgtype, m_msgtype );
		  fieldSet::fsextr( l_track2, m_track2 );
		  fieldSet::fsextr( l_is_3a_perna, m_is_3a_perna );
		  
			if ( !l_is_3a_perna.compare("Y") )
			{
				l_whereClause << "NUM_BIN = " << l_bin << " AND COD_STTU_REG = 'A' ";
				l_whereClause << " AND DAT_ATVC_VOCH <= SYSDATE ";
				// EAK-1591 - Retirada do Roteador da query, este plugin nao estava mais sendo usado, 
				// pois nem todos os voucher sao identificados pelo roteador
				// Utilizado por trava do Debito para saber se o BIN eh voucher
				// if( strlen( l_track2.c_str() ))
				// {
				// 	l_whereClause << " AND NUM_RTDR = " << l_track2.substr(31,2).c_str( );
				// }
			}
			else
			{		  
			  switch ( l_msgtype )
			  {
				  case 100 :
				  case 200 :
				  case 220 :
				  case 400 :
				  case 420 :
						l_whereClause << "NUM_BIN = " << l_bin << " AND COD_STTU_REG = 'A' ";
						l_whereClause << " AND DAT_ATVC_VOCH <= SYSDATE ";
						// EAK-1591 - Retirada do Roteador da query, este plugin nao estava mais sendo usado, 
						// pois nem todos os voucher sao identificados pelo roteador
						// Utilizado por trava do Debito para saber se o BIN eh voucher
						// if( strlen( l_track2.c_str() ) )
						// {
						// 	l_whereClause << " AND NUM_RTDR = " << l_track2.substr(31,2).c_str( );
						// }
						// TODO: Adicionar condicao para o outro campo da chave, NUM_RTDR
						break;
				  default:
						fieldSet::fscopy( m_result, "EMPTY QUERY", 11 );
						a_stop = false;
						return 0;     
						break;
				}
			}

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0113 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
            dbaccess_common::TBSW0113 l_TBSW0113( l_whereClause.str() );

            l_TBSW0113.prepare();
            l_TBSW0113.execute();
            int ret = l_TBSW0113.fetch();
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "OK", 2 );

                fieldSet::fscopy( m_cod_sttu_reg, l_TBSW0113.get_COD_STTU_REG( ) );          
                fieldSet::fscopy( m_num_rtdr, l_TBSW0113.get_NUM_RTDR( ) );                    
                fieldSet::fscopy( m_cod_sbpd, l_TBSW0113.get_COD_SBPD( ) );                    
                fieldSet::fscopy( m_cod_emsr, l_TBSW0113.get_COD_EMSR( ) );                    
                fieldSet::fscopy( m_nom_emsr, l_TBSW0113.get_NOM_EMSR( ) );                    
                fieldSet::fscopy( m_cod_tran_ge, l_TBSW0113.get_COD_TRAN_GE( ) );              
                fieldSet::fscopy( m_nom_prod_cpom, l_TBSW0113.get_NOM_PROD_CPOM( ) );          
                fieldSet::fscopy( m_txt_rdpe_cpom, l_TBSW0113.get_TXT_RDPE_CPOM( ) );          
                fieldSet::fscopy( m_cod_usr_atlz_reg, l_TBSW0113.get_COD_USR_ATLZ_REG( ) );    
                fieldSet::fscopy( m_dat_atlz_reg, l_TBSW0113.get_DAT_ATLZ_REG( ) );            
                fieldSet::fscopy( m_dat_atvc_voch, l_TBSW0113.get_DAT_ATVC_VOCH( ) );          
                fieldSet::fscopy( m_ntwkid, l_TBSW0113.get_NTWKID( ) );                        
                fieldSet::fscopy( m_num_bin, l_TBSW0113.get_NUM_BIN( ) );                        

            }//else
        
    }//try    
    catch( base::GenException e )
    {
      fieldSet::fscopy( m_result, "ERROR", 5 );
      std::string l_what( e.what( ) );
      std::string l_msg = "Exception in TBSW0113 <" + l_what + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }
    catch( std::exception  e )
    {
      fieldSet::fscopy( m_result, "ERROR", 5 );
      std::string l_what( e.what( ) );
      std::string l_msg = "std::exception in TBSW0113 <" + l_what + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }
    a_stop = false;
    return 0;
  }

  TBSW0113Loader& TBSW0113Loader::setSourceFieldPath( const std::string& a_path )
  {
    m_sourceFieldPath = a_path;
    return *this;
  }
  TBSW0113Loader& TBSW0113Loader::setTargetFieldPath( const std::string& a_path )
  {
    m_targetFieldPath = a_path;
    return *this;
  }
  
  dataManip::Command* TBSW0113Loader::clone() const
  {
    return new TBSW0113Loader(*this);
  }
}//namespace standardAcqPlugins
