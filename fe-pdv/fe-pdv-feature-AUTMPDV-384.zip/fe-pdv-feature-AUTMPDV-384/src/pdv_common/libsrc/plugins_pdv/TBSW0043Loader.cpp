/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0043Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0043Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>
/ Data de Cria��o: <Thu Nov 01 09:26:32 2012>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0043.hpp"
#include "plugins_pdv/TBSW0043Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0043Loader( )
    {
        TBSW0043Loader* l_new = new TBSW0043Loader;
        return l_new;
    }
    bool TBSW0043Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );
        return true;
    }
    TBSW0043Loader::TBSW0043Loader( )
    {
    }
    TBSW0043Loader::~TBSW0043Loader( )
    {
    }
    bool TBSW0043Loader::init( )
    {  
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        m_target_cod_term = this->navigate( m_targetFieldPath + ".COD_TERM");
        m_target_cod_sttu_reg = this->navigate( m_targetFieldPath + ".COD_STTU_REG");
        m_target_dat_atlz_reg = this->navigate( m_targetFieldPath + ".DAT_ATLZ_REG");
        m_target_cod_fun = this->navigate( m_targetFieldPath + ".COD_FUN");
        m_source_terminal_pdv = this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
        
        return true;
    }
    void TBSW0043Loader::finish( )
    {
    }
    int TBSW0043Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            std::string l_terminal_pdv;
            std::string l_cod_fun;            
            fieldSet::fsextr( l_terminal_pdv, m_source_terminal_pdv );
            fieldSet::fsextr( l_cod_fun, m_target_cod_fun );
            l_whereClause << "COD_TERM = '" << l_terminal_pdv << "'";
            l_whereClause << " AND COD_FUN = " << l_cod_fun;            
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0043 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );            
            dbaccess_common::TBSW0043 l_table0043( l_whereClause.str( ) );            
            l_table0043.prepare( );
            l_table0043.execute( );
            int ret = l_table0043.fetch( );
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "OK", 2 );
                fieldSet::fscopy( m_target_cod_term, l_table0043.get_COD_TERM( ) );
                fieldSet::fscopy( m_target_cod_sttu_reg, l_table0043.get_COD_STTU_REG( ) );
                fieldSet::fscopy( m_target_dat_atlz_reg, l_table0043.get_DAT_ATLZ_REG( ) );
            }
        }
        catch( base::GenException e )
		{
			fieldSet::fscopy( m_result, "ERROR", 5 );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0043 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			fieldSet::fscopy( m_result, "ERROR", 5 );
			std::string l_what( e.what( ) );
			std::string l_msg = "std::exception in TBSW0043 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
        a_stop = false;
        return 0;
    }
    TBSW0043Loader& TBSW0043Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
		return *this;
    }
    TBSW0043Loader& TBSW0043Loader::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
		return *this;
    }
    dataManip::Command* TBSW0043Loader::clone( ) const
    {
        return new TBSW0043Loader(*this);
    }
}//namespace plugins_pdv
