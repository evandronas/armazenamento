#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0136.hpp"
#include "plugins_pdv/TBSW0136Loader.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0136Loader()
    {
        TBSW0136Loader* l_new = new TBSW0136Loader;
        return l_new;
    }

    bool TBSW0136Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0136Loader::TBSW0136Loader()
    {
        m_tbsw0136_records.clear();
    }

    TBSW0136Loader::~TBSW0136Loader()
    {
    }

    bool TBSW0136Loader::init()
    {
        //utiliza o mesmo campo para obter o indice da chave e altera no mesmo campo com a chave recuperada
        m_idxTPK = this->navigate( m_sourceFieldPath + ".segments.merchant.termTPK" );
        if( !m_idxTPK )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ">" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        m_termTPK = this->navigate( m_targetFieldPath + ".segments.merchant.termTPK" );
        if( !m_termTPK )
        {
            std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ">" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        m_mac = this->navigate( m_targetFieldPath + ".shc_msg.mac" );
        if( !m_mac )
        {
            std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ">" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }        
        
        try
        {
            m_tbsw0136_records.clear();
            
            dbaccess_common::TBSW0136 l_TBSW0136;
            l_TBSW0136.prepare();
            l_TBSW0136.execute();
        
            while( l_TBSW0136.fetch() )
            {
                m_tbsw0136_records.insert(
                    std::pair<unsigned long, std::string>(
                        l_TBSW0136.get_ID_BDK(),
                        l_TBSW0136.get_COD_CRPA_CHAV_BDK()
                    )
                );
            }
        }
        catch( base::GenException e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0136Loader <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
            return true;
        }
        catch( std::exception  e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0136Loader <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
            return true;
        }        

        return true;
    }

    void TBSW0136Loader::finish()
    {
    }

    int TBSW0136Loader::execute( bool& a_stop )
    {
        try
        {
            unsigned long l_idx_chave = 0;
            std::map<unsigned long,std::string>::iterator it;
            
            fieldSet::fsextr( l_idx_chave, m_idxTPK );
            it = m_tbsw0136_records.find( l_idx_chave );
            
            if( it != m_tbsw0136_records.end() )
            {
                fieldSet::fscopy( m_termTPK, (*it).second );
                fieldSet::fscopy( m_mac, (*it).second );
            }
            else
            {
                std::ostringstream l_msg;
                l_msg << "Criptograma nao cadastrado para a chave<" << l_idx_chave << ">";
                this->enableWarning( true );
                this->setWarningMessage( l_msg.str().c_str() );
            }
        }
        catch( base::GenException e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0136Loader <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0136Loader <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    TBSW0136Loader& TBSW0136Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0136Loader& TBSW0136Loader::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0136Loader::clone() const
    {
        return new TBSW0136Loader(*this);
    }
}//namespace plugins_pdv

