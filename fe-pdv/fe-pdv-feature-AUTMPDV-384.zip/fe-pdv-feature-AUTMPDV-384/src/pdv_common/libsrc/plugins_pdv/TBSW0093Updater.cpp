/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0093Updater>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0093Updater>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <698224, Raphael Gomes>
/ Data de Cria��o: <Fri Oct 26 15:21:52 2012>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0093.hpp"
#include "plugins_pdv/TBSW0093Updater.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "dbaccess_pdv/TBSW0093RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0093Updater()
    {
        TBSW0093Updater* l_new = new TBSW0093Updater;
        return l_new;
    }

    bool TBSW0093Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0093Updater::TBSW0093Updater()
    {
    }

    TBSW0093Updater::~TBSW0093Updater()
    {
    }

    bool TBSW0093Updater::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_pb_reason_code = this->navigate( m_sourceFieldPath + ".segments.common.pb_reason_code" );
        m_ext_network_code = this->navigate( m_sourceFieldPath + ".segments.common.ext_network_code" );

		// t694446@FIS_BEGIN - Data: 23/10/2013 - GAP3 - 1.1.4.5 - Remo��o da coluna
        //m_settlement_date = this->navigate( m_sourceFieldPath + ".shc_msg.settlement_date" );
		// t694446@FIS_END - Data: 23/10/2013 - GAP3 - 1.1.4.5 - Remo��o da coluna

        return true;
    }

    void TBSW0093Updater::finish()
    {
    }

    int TBSW0093Updater::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_msgtype;

            acq_common::OPERACAO operacao = acq_common::UPDATE;

            acq_common::tbsw0093_params tbsw0093_params = { 0 };

            fieldSet::fsextr( l_msgtype,				m_msgtype );
            fieldSet::fsextr( tbsw0093_params.refnum,			m_refnum );
            fieldSet::fsextr( tbsw0093_params.local_date,		m_local_date );
            fieldSet::fsextr( tbsw0093_params.origdate,			m_origdate );
            fieldSet::fsextr( tbsw0093_params.common_origrefnum,	m_origrefnum );
            fieldSet::fsextr( tbsw0093_params.common_pb_reason_code,	m_pb_reason_code );
            fieldSet::fsextr( tbsw0093_params.common_ext_network_code,	m_ext_network_code );

            switch ( l_msgtype )
            {
                case 110 :
                case 210 :
                case 230 :
                    l_whereClause << "DAT_MOV_TRAN = " << tbsw0093_params.local_date << " AND NUM_SEQ_UNC = " << tbsw0093_params.refnum;
                    break;
                    
                default:
                    fieldSet::fscopy( m_result, "EMPTY QUERY", 11 );
                    a_stop = false;
                    return 0;
            }

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0093 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );

            dbaccess_common::TBSW0093 tbsw0093( l_whereClause.str() );

            tbsw0093.prepare_for_update();
            tbsw0093.execute();
            int ret = tbsw0093.fetch();

            if( !ret )
            {
                fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {   
            
                dbaccess_pdv::TBSW0093RegrasFormatacao regrasFormatacao;                  
                
                fieldSet::fsextr( tbsw0093_params.common_ext_network_code, m_ext_network_code );
                // COD_MOT_RSPS_EXT               NOT NULL CHAR(3)   
                // COD_OPER_CNFR                  NOT NULL CHAR(6) 
                regrasFormatacao.COD_OPER_CNFR( tbsw0093, tbsw0093_params, acq_common::UPDATE );
                
                // COD_OPER_ESTR                  NOT NULL CHAR(7)   
                // COD_ITEM                       NOT NULL CHAR(11)  
                // TIP_MODO_TRAN                  NOT NULL CHAR(1)   
                // TIP_MSG                        NOT NULL CHAR(1)   
                // TIP_VD_SAID                    NOT NULL CHAR(2)   
                // NUM_OPER_ETD                   NOT NULL NUMBER(12)
                // NUM_RD_DEST                    NOT NULL NUMBER(7) 
                // COD_MOT_ESTR_DEST              NOT NULL CHAR(2)   
                // COD_MOT_RSPS_DEST              NOT NULL CHAR(2) 
                regrasFormatacao.COD_MOT_RSPS_DEST( tbsw0093, tbsw0093_params, acq_common::UPDATE ); 
                // DAT_MOV_TRAN                   NOT NULL NUMBER(8) 
                // NUM_SEQ_UNC                    NOT NULL NUMBER(12)

                //tbsw0093.show(0);
                tbsw0093.update();
                tbsw0093.commit();
                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }

        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0093 <" + l_what + ">";
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Erro no UPDATE DA TBSW0093 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_msg.c_str() );
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0093 <" + l_what + ">";
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Erro no UPDATE DA TBSW0093 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_msg.c_str() );
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    TBSW0093Updater& TBSW0093Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0093Updater& TBSW0093Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0093Updater::clone() const
    {
        return new TBSW0093Updater(*this);
    }

}//namespace plugins_pdv

