/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -----------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2013, 1 de marco
/ Hist�rico Mudan�as: 2013, 1 de marco, t689066, Alexandre Teodoro 
                                                      Guimaraes, Versao Inicial
/ -----------------------------------------------------------------------------
*/

/*
*********************** MODIFICACOES ************************
Autor    : Joao Paulo F. Costa
Data     : 16/03/2021
Empresa  : Rede
Descricao: Falha no processo de Sonda
ID       : EAK-6005
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 23/04/2021
Empresa  : Rede
Descricao: Segregacao do timeout
ID       : EAK-6538
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 26/04/2021
Empresa  : Rede
Descricao: Controle de CheckPoint
ID       : EAK-6544
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 28/04/2021
Empresa  : Rede
Descricao: Virada do dia
ID       : EAK-6550
*************************************************************
*/



#pragma once
#include "configBase/TagList.hpp"
#include "configBase/ConfigBase.hpp"
#include "fieldSet/fscopy.hpp"
#include "plugins_pdv/StatusInqReader.hpp"
#include "logger/LoggerGen.hpp"
#include "fieldSet/fsextr.hpp"
#include <sstream>
#include <cmath>
#include <unistd.h>
#include <ist_ipc.h>


namespace plugins_pdv
{
    base::Identificable* createStatusInqReader( )
    {
        StatusInqReader* l_new = new StatusInqReader;
        return l_new;
    }

	StatusInqReader::StatusInqReader( )
	{
        m_historyDaysRange = 25;
        m_searchInterval = 3600;
        m_pendingWaitingTime = 600;
        m_iteractions_interval = 10800;
        m_tps = 2;

        m_initInterval = 0;
        m_finalInterval = 3600;

        m_firstRun = true;
        m_finalRange = false;
        m_stopExec = false;

        m_flagRemoteExec = false;
        m_flagSleep = false;

		/* EAK-6544 - JPFC - Inicio */
		// Seta flag indicativa de primeira execucao
		m_isInicialization = true;
		/* EAK-6544 - JPFC - Fim */
		
        m_logger = logger::LoggerGen::getInstance();
        m_cfg = configBase::ConfigBase::getInstance();
        //TODOSW75 m_cntHandler = dbaccess_common::ContigencyHandler::getInstance( );

	}

	StatusInqReader::~StatusInqReader( ) { }

    bool StatusInqReader::startConfiguration( const configBase::Tag* a_tag )
    {
		m_logger->init( );
        m_cfg->init();

        if (!m_cfg->findFirst(HISTORY_DAYS_RANGE, this->m_historyDaysRange))
            return false;

        if (!m_cfg->findFirst(SEARCH_INTERVAL, this->m_searchInterval))
            return false;
        
        if (!m_cfg->findFirst(PENDING_WAITING_TIME, this->m_pendingWaitingTime))
            return false;    

        if (!m_cfg->findFirst(ITERACTIONS_INTERVAL, this->m_iteractions_interval))
            return false;    

        if (!m_cfg->findFirst(TPS, this->m_tps))
            return false;          

        if (!m_cfg->findFirst(ENABLE_REMOTE_QUERY, this->m_enable_remote_query))
            return false;          

        m_cfg->findFirst(REMOTE_ACQR_HOST_NAME, this->m_remote_acqr_host_name);

        if( atoi(m_enable_remote_query.c_str()) && m_remote_acqr_host_name.size() == 0) {
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, 
                " Host remoto nao foi definido!" );
            return false;                          
        }
		
		/* EAK-6544 - JPFC - Inicio */
		// Carrega flag indicativa de repeticao do ultimo ciclo
		if (!m_cfg->findFirst(REPETE_ULTIMO, this->m_repeteUltimo))
			return false;
		
		if(atoi(m_repeteUltimo.c_str())) {
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " Repete Ultimo habilitado." );
		} else {
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " Repete Ultimo desabilitado." );
		}
		// Carrega flag indicativa de repeticao do ultimo ciclo
		
		// Carrega flag indicativa de uso do recurso de CheckPoint
		if (!m_cfg->findFirst(USA_CHECKPOINT, this->m_usaCheckPoint))
			return false;

		if(atoi(m_usaCheckPoint.c_str())) {
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " CheckPoint habilitado." );
		} else {
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " CheckPoint desabilitado." );
		}		
		// Carrega flag indicativa de uso do recurso de CheckPoint

		// Faz a carga de dados do checkPoint
		if (getCheckPointData() == CHECKPOINT_DATA_FOUND && atoi(m_usaCheckPoint.c_str()))
		{
			m_isCheckPointData = true;
		}
		else
		{
			m_isCheckPointData = false;
		}
		/* EAK-6544 - JPFC - Fim */

		this->setMsgHeaderSize( getenv( "MSG_HEADER_SIZE" ) );

        std::string l_acqsrvMbname = std::string( getenv( "ACQSRV_MBNAME" ) );		
        m_acqsrvMbid = mb_locatemailbox( l_acqsrvMbname.c_str() );

        /* EAK-2782 - EMS - Preparando alias Id do servidor local */
        /* Ex: _SERVER_ALIAS="437 7.5" =>  serverAliasId="437" */
        serverAliasId = std::string( getenv( "_SERVER_ALIAS" ) ).substr(0,3);
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "=========SERVER_ALIAS=========" );
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, serverAliasId.c_str( ) );
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "=========SERVER_ALIAS=========" );
        /* EAK-2782 - EMS - FIM */

        return true; 
    }    

	bool StatusInqReader::open( )
	{    
        std::ostringstream l_whereClause;
        bool bdError = false;

        if(m_flagSleep) {  

            if(!atoi(m_enable_remote_query.c_str())) {
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, 
                    "Consulta remota esta desativada para esse módulo." );
            }

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "\nSleep..." );
            sleep( atoi(m_iteractions_interval.c_str()) );
            m_flagSleep = false;
        }

        l_whereClause.str("");
        l_whereClause << " NOM_FE_ACQR_ORGL = '" << getenv( "NOM_FE_ACQR" ) << "'";
        l_whereClause << " AND IND_STTU_TRAN = '0'";
        l_whereClause << " AND COD_MSG_ISO in (200, 210, 220, 230)";
        l_whereClause << " AND (TIP_TRAN != 72 OR TIP_TRAN != 73) ";

        l_whereClause << "AND NOM_HOST_ACQR_ORGL = '";

            if(m_flagRemoteExec) {
                l_whereClause << m_remote_acqr_host_name;
            } else {
                l_whereClause << getenv( "NOM_HOST_ACQR" );
             }

        l_whereClause << "'";

        calculateQueryIntervals();

        l_whereClause << " AND DAT_MOV_TRAN = to_number(to_char(CURRENT_DATE-" << m_auxDaysRange << ", 'yyyymmdd'), '99999999')";
        l_whereClause << " AND to_number(to_char(DTH_INI_TRAN, 'sssss'), '99999') ";
        l_whereClause << "    between " << m_initInterval << " and " << m_finalInterval;
        l_whereClause << " ORDER BY NUM_SEQ_UNC";

        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str( ) );

        /* EAK-6544 - JPFC - Inicio */
		// Apos a construcao do SQL registra no arquivo de checkpoint os dados necessarios
		int resultadoProcessamento = 0;
		resultadoProcessamento = setCheckPointData();
		if (atoi(m_usaCheckPoint.c_str())){
			if (resultadoProcessamento == CHECKPOINT_FILE_CLOSE_OK || resultadoProcessamento == CHECKPOINT_FILE_WRITE_OK){
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " Escrita CheckPoint ok.");
			} else {
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " Escrita CheckPoint falhou.");
			}
		}
        /* EAK-6544 - JPFC - Fim */

        do {

            bdError = false;

            try {

                m_TBSW0030.setWhereClause( l_whereClause.str() );
                //TODOSW75 m_TBSW0030.unsetDualSelect( );

                string table_name = "TBSW0030";
                
                if(m_flagRemoteExec) {

                    if(!checkContingency()) {

                        string owner, dblink, acq_name, aux = "";

                        //SWCAPT.TBSW0030@CAPT_CAS_CTO
                        acq_name = getenv( "NOM_SITE_ACQR" );
                        //TODOSW75 owner = m_cntHandler->GetDblinkOwner( table_name );
                        owner = "SWCAPT";
                        dblink = owner.substr(2); 
                        aux = owner + "." + table_name; 

                        // PRODUCAO pode ser CTO ou CTM
                        // SIMULACAO E DESENV pode ser CTO, CAS ou CTM
                        if (!acq_name.compare("CTO")) {
                            table_name.clear();
                            table_name = aux + "@" + dblink + "_CTO_CAS";
                        } else { // CTM or CAS
                            table_name.clear();
                            table_name = aux + "@" + dblink + "_CAS_CTO";
                        }

                        m_TBSW0030.setTableName(table_name);
                        
                    } else {
                        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, 
                            " ==> Contingencia esta ativa! Não vai realizar consulta remota!" );
                        m_stopExec = true;  
                    }
                }

                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, table_name.c_str( ) );

                if(!m_stopExec) {
					/* JPFC - EAK-6538: Segregacao do timeout - Inicio */
                    m_TBSW0030.prepare(true);
                    m_TBSW0030.execute();   
					/* JPFC - EAK-6538: Segregacao do timeout - Fim */
                } else {
                    m_firstRun = true;
                    m_finalRange = false;
                    m_stopExec = false;
                    m_flagRemoteExec = false;
                    m_flagSleep = true;
                }

            } catch( base::GenException e ) {
                std::string l_what( e.what( ) );
                std::string l_msg = "base::GeException in TBSW0030 <" + l_what + ">";
                m_logger->print( logger::LEVEL_ERROR, l_msg );
                bdError = true;
                return false;

            } catch( std::exception e ) {
                std::string l_what( e.what( ) );
                std::string l_msg = "std::exception in TBSW0030 <" + l_what + ">";
                m_logger->print( logger::LEVEL_ERROR, l_msg );
                bdError = true;
                return false;
            }

        } while  ( bdError == true ); 

        m_firstRun = false;

		return true;
	}

	void StatusInqReader::close( ) {}

	bool StatusInqReader::fetch( ) {      

		logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ==> Inicia o fetch" );
		
        ostringstream l_whereClause;
        char l_bufferTemp[32];   
        bool found;

        found = false;

		/* JPFC - EAK-6538: Segregacao do timeout - Inicio */
        if( m_TBSW0030.fetch() ) {          
		/* JPFC - EAK-6538: Segregacao do timeout - Fim */
		
            //tofix: para o bigip, devemos obter o header de que forma?
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.msgtype" ), 600 );
            fieldSet::fscopy( this->navigate( "imf_inq.segments.common.acq_msgtype" ), 600 );
            fieldSet::fscopy( this->navigate( "imf_inq.segments.common.ecr_msgtype" ), 600 );

            // Nava - EAK-2007
			fieldSet::fscopy( this->navigate( "imf_inq.segments.common.msg_name" ), "SONDA" );
			fieldSet::fscopy( this->navigate( "imf_inq.segments.common.termid_type" ), "INAC" );
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.respcode" ), 0 );
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.reason_code" ), 0 );
            fieldSet::fscopy( this->navigate( "imf_inq.segments.common.pb_reason_code" ), 0 );
            
            /* EAK-2782 - EMS - Para transa��es obtidas no site remoto, o NetworkId da rota original   */
            /* deve ser alterado para o alias do servidor local. (posi��es 4 a 6) do NTWK_ID_ROUT_ORGL */
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "========= Servidor da transacao =========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG,  std::string(m_TBSW0030.get_NOM_HOST_ACQR_ORGL( )).c_str() );

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "========= Servidor remoto =========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(m_remote_acqr_host_name).c_str() );

            /*Se o Servidor da transacao for o Servidor Remoto altera NTWK_ID_ROUT_ORGL */
            if(m_TBSW0030.get_NOM_HOST_ACQR_ORGL( ).compare(m_remote_acqr_host_name) == 0){
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "========= Servidor da transacao eh o servidor remoto altera NTWK_ID_ROUT_ORGL =========" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "========= NTWK_ID_ROUT_ORGL original =========" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG,  std::string(m_TBSW0030.get_NTWK_ID_ROUT_ORGL( )).c_str() );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "========= NTWK_ID_ROUT_ORGL alterado =========" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG,  std::string(m_TBSW0030.get_NTWK_ID_ROUT_ORGL( )).replace(3,3,serverAliasId.c_str()).c_str() );

                fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.acquirer" ), std::string(m_TBSW0030.get_NTWK_ID_ROUT_ORGL( )).replace(3,3,serverAliasId.c_str()).c_str() );
            } else {        
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "========= Servidor da transacao eh o servidor local nao altera NTWK_ID_ROUT_ORGL =========" );                
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "========= NTWK_ID_ROUT_ORGL original =========" );                
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG,  std::string(m_TBSW0030.get_NTWK_ID_ROUT_ORGL( )).c_str() );

                fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.acquirer" ), m_TBSW0030.get_NTWK_ID_ROUT_ORGL( ) );    
            }
            /* EAK-2782 - EMS - FIM*/

            try {

                l_whereClause.str("");               
                l_whereClause << " DAT_MOV_TRAN = ";
                l_whereClause << m_TBSW0030.get_DAT_MOV_TRAN();
                l_whereClause << " AND NUM_SEQ_UNC = "; 
                l_whereClause << m_TBSW0030.get_NUM_SEQ_UNC();    

                dbaccess_common::TBSW0121 l_TBSW0121( l_whereClause.str( ) );

				/* JPFC - EAK-6538: Segregacao do timeout - Inicio */
                l_TBSW0121.prepare(true);
                l_TBSW0121.execute();

                if( l_TBSW0121.fetch() ) 
				/* JPFC - EAK-6538: Segregacao do timeout - Fim */
			        fieldSet::fscopy( this->navigate( "imf_inq.segments.common.ecr_sftw_verid" ), l_TBSW0121.get_COD_VERS_SRVD_PDV() );
                else 
                    m_logger->print( logger::LEVEL_DEBUG, ": No row was returned from TBSW0121." );
        
            } catch( base::GenException e ) {
                std::string l_what( e.what( ) );
                std::string l_msg = " base::Exception in TBSW0121 <" + l_what + ">";
                m_logger->print( logger::LEVEL_ERROR, l_msg );

            } catch( std::exception e ) {
                std::string l_what( e.what( ) );
                std::string l_msg = " std::exception in TBSW0121 <" + l_what + ">";
                m_logger->print( logger::LEVEL_ERROR, l_msg );
            }                              

            time_t datetimeGmt = m_TBSW0030.get_DTH_GMT();
            struct tm *dtGmt = localtime( &datetimeGmt );
            char auxDtGmt[256];
            string strDtGmt;
            sprintf( auxDtGmt, "%04d%02d%02d", ( dtGmt->tm_year + 1900 ), ( dtGmt->tm_mon + 1 ), dtGmt->tm_mday );
            strDtGmt = auxDtGmt;
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.local_date" ), strDtGmt );
            sprintf( auxDtGmt, "%02d%02d%02d", dtGmt->tm_hour, dtGmt->tm_min, dtGmt->tm_sec );
            strDtGmt = auxDtGmt;
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.local_time" ), strDtGmt );

            time_t datetimeIniTran = m_TBSW0030.get_DTH_INI_TRAN();
            struct tm *dtIniTran = localtime( &datetimeIniTran );
            char auxDtIniTran[256];
            string strDtIniTran;
            sprintf( auxDtIniTran, "%04d%02d%02d", ( dtIniTran->tm_year + 1900 ), ( dtIniTran->tm_mon + 1 ), dtIniTran->tm_mday );
            strDtIniTran = auxDtIniTran;
            fieldSet::fscopy( this->navigate( "imf_inq.segments.common.orig_local_date" ), strDtIniTran );
            sprintf( auxDtIniTran, "%02d%02d%02d", dtIniTran->tm_hour, dtIniTran->tm_min, dtIniTran->tm_sec );
            strDtIniTran = auxDtIniTran;
            fieldSet::fscopy( this->navigate( "imf_inq.segments.common.orig_local_time" ), strDtIniTran );

            //fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.local_date" ), m_TBSW0030.get_DAT_MOV_TRAN( ) );
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.refnum" ),     m_TBSW0030.get_NUM_SEQ_UNC( ) );
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.origtrace" ),  m_TBSW0030.get_NUM_STAN( ) );
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.termid" ),     m_TBSW0030.get_COD_TERM( ) );
            fieldSet::fscopy( this->navigate( "imf_inq.segments.common.terminal_pdv" ),	m_TBSW0030.get_COD_TERM( ) );
           
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            sprintf( l_bufferTemp, "%06d", m_TBSW0030.get_NUM_STAN( ) );
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.trace" ), l_bufferTemp );

            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            sprintf( l_bufferTemp, "%09d", m_TBSW0030.get_NUM_ESTB( ) );
            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.termloc" ), l_bufferTemp );

            fieldSet::fscopy( this->navigate( "imf_inq.shc_msg.netcode" ),   m_TBSW0030.GetCodigoRoteamentoTransacao( ) );
	
            // Mailbox que processara a resposta, para o qual sera criado evento
			fieldSet::fscopy( this->navigate( "environment.RETURN_ADDRESS" ), m_acqsrvMbid );	

            found = true;

        } else {
            m_logger->print( logger::LEVEL_DEBUG,": No row was returned from TBSW0030." );
            found = false;
        }

        if(m_finalRange == true) {

            m_firstRun = true;
            m_finalRange = false;
            /* JPFC - EAK-6005: Falha no processo de Sonda - Inicio */
            m_auxDaysRange = m_globalDaysRange;
            /* JPFC - EAK-6005: Falha no processo de Sonda - Fim */

            if(!m_flagRemoteExec && atoi(m_enable_remote_query.c_str())) {
                m_flagRemoteExec = true;
            } else {

                m_flagSleep = true;

                if(m_flagRemoteExec)
                    m_flagRemoteExec = false;
            }    

        }

        return found;        
    }    
    
    StatusInqReader& StatusInqReader::setMsgHeaderSize( const char* a_value ) {  

        if ( a_value == NULL ) {
            m_msgHeaderSize = 0;
        } else {
            m_msgHeaderSize = strtol ( a_value, NULL, 10 );
        }
        return *this;
    }
    

    /* EAK-6550 - JPFC - Inicio */
	void StatusInqReader::getSecsFromMidnight( int &a_value ) {    
	/* EAK-6550 - JPFC - Fim */
        
        struct tm *ltime;
        time_t long_time;

        time( &long_time );              /* Get time as long integer. */
        ltime = localtime( &long_time ); /* Convert to local time. */

        a_value = 0;
        a_value = ltime->tm_hour * 3600 + ltime->tm_min * 60 + ltime->tm_sec;
    }

    int StatusInqReader::getTps() {    
       return atoi(m_tps.c_str()); 
    }

    bool StatusInqReader::checkContingency( ) {

        try {

            string acrq_site_name = getenv( "NOM_SITE_ACQR" );

            //TODOSW75 
            /***
            dbaccess_common::TBSW0059 m_TBSW0059( " NOM_SITE = '" + acrq_site_name + "' AND NOM_HOST = '*'" );

            m_TBSW0059.prepare( );
            m_TBSW0059.execute( );

            if ( m_TBSW0059.fetch( ) == true ) {
                std::string l_strIndFlhaCnxo = m_TBSW0059.get_IND_FLHA_CNXO( );

                if(l_strIndFlhaCnxo == "N")
                    return false;
                else
                    return true;    
            }
            ***/
            return true;

        } catch( base::GenException e ) {
            std::string l_what( e.what( ) );
            std::string l_msg = " base::Exception in TBSW0121 <" + l_what + ">";
            m_logger->print( logger::LEVEL_ERROR, l_msg );
            return true;

        } catch( std::exception e ) {
            std::string l_what( e.what( ) );
            std::string l_msg = " std::exception in TBSW0121 <" + l_what + ">";
            m_logger->print( logger::LEVEL_ERROR, l_msg );
            return true;
        }      

        return true;
    }

    void StatusInqReader::calculateQueryIntervals() { 

        unsigned int current_sec = 0;
		/* EAK-6544 - JPFC - Inicio */
		std::ostringstream outputMessage;
		/* EAK-6544 - JPFC - Fim */

        if(m_firstRun) { 
            /* EAK-6544 - JPFC - Inicio */
            if (m_isCheckPointData && m_isInicialization) {
				/*********************************************************************************
				 * Aqui, 'init_interval' sera igual ao checkPoint menos o 'search_interval' caso *
				 * 'repete_ultimo' estiver habilitado ou, se nao estiver mas checkPoint for      *
				 * igual 86400.                                                                  *
				 *********************************************************************************/
				if((atoi(m_repeteUltimo.c_str()) && (m_checkPointFinalInterval >= atoi(m_searchInterval.c_str()))) || 
				   (!atoi(m_repeteUltimo.c_str()) && (m_checkPointFinalInterval == 86400))) {
					m_initInterval = m_checkPointFinalInterval - atoi(m_searchInterval.c_str());
				} else {
					m_initInterval = m_checkPointFinalInterval;
				}
				m_auxDaysRange = m_checkPointDaysRange;
				outputMessage.str("");
				if ((!atoi(m_repeteUltimo.c_str()) && (m_checkPointFinalInterval == 86400))){
					outputMessage << " Valores iniciais corrigidos:";
				} else {
					outputMessage << " Valores iniciais:";
				}
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
				outputMessage.str("");
				outputMessage << "\tm_initInterval : [" << m_initInterval << "]";
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
				outputMessage.str("");
				outputMessage << "\tm_auxDaysRange : [" << m_auxDaysRange << "]";
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
            } else {
            /* EAK-6544 - JPFC - Fim */
                m_initInterval = 0;
                m_auxDaysRange = atoi(m_historyDaysRange.c_str());
                /* JPFC - EAK-6005: Falha no processo de Sonda - Inicio */
                m_globalDaysRange = m_auxDaysRange;
                /* JPFC - EAK-6005: Falha no processo de Sonda - Fim */
            }

            calculateFinalInterval();

        } else {

            if (m_finalInterval < 86400) {

                int last_final_int = 0;
                last_final_int = m_finalInterval;

                m_initInterval = m_initInterval + atoi(m_searchInterval.c_str());
                
                calculateFinalInterval();

                if(m_initInterval > m_finalInterval)
                    m_initInterval = last_final_int;

            } else {

                if(m_auxDaysRange != 0) {
                    m_auxDaysRange--;
                    m_initInterval = 0;
                    calculateFinalInterval();
                }
            }
        }
   
    }

    void StatusInqReader::calculateFinalInterval() {    

        /* EAK-6550 - JPFC - Inicio */
		int current_sec = 0;
		/* EVO1-216 - JPFC - Inicio */
		int m_finalInterval_aux = 0;
		/* EVO1-216 - JPFC - Fim */
		long localCurrentDate = 0; /* Data atual de processamento, long, no formato 'YYYYMMDD' */
		/* EAK-6550 - JPFC - Fim */
		/* EAK-6544 - JPFC - Inicio */
		std::ostringstream outputMessage;
		/* EAK-6544 - JPFC - Fim */

        if(m_firstRun) {
            /* EAK-6544 - JPFC - Inicio */
            if (m_isCheckPointData && m_isInicialization) {
				/********************************************************************************
				 * Aqui, 'final_interval' sera igual ao checkPoint caso 'repete_ultimo' estiver *
				 * habilitado ou, se nao estiver mas checkPoint for igual 86400.                *
				 *******************************************************************************/
				if((atoi(m_repeteUltimo.c_str()) && (m_checkPointFinalInterval >= atoi(m_searchInterval.c_str()))) || 
				   (!atoi(m_repeteUltimo.c_str()) && (m_checkPointFinalInterval == 86400))) {
					m_finalInterval = m_checkPointFinalInterval;
				} else {
					m_finalInterval = m_checkPointFinalInterval + atoi(m_searchInterval.c_str());
				}
				m_isInicialization = false;
				outputMessage.str("");
				outputMessage << "\tm_finalInterval: [" << m_finalInterval << "]";
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
            } else {
            /* EAK-6544 - JPFC - Fim */
                m_finalInterval = atoi(m_searchInterval.c_str());
            }
        } else {
            if (m_finalInterval < 86400) {
                m_finalInterval = m_finalInterval + atoi(m_searchInterval.c_str());
            } else {
                m_finalInterval = atoi(m_searchInterval.c_str());
            }
        }

        if(m_finalInterval > 86400) {
            m_finalInterval = 86400;
        }

        getSecsFromMidnight(current_sec);

		/* EAK-6550 - JPFC - Inicio */
		getCurrentDate(localCurrentDate);
		/* Mudou de dia */
		if ((localCurrentDate > lastCurrentDate) && !m_firstRun ) {
			outputMessage.str("");
			outputMessage << " Virada de dia... localCurrentDate[" << localCurrentDate << "], lastCurrentDate [" << lastCurrentDate << "]";
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
			m_auxDaysRange++;
		}
		lastCurrentDate = localCurrentDate;
		/* EAK-6550 - JPFC - Fim */

        //m_finalInterval é igual ao horario corrente, menos os secs das trx q ainda não devem ser sondadas                
        /* EVO1-216 - JPFC - Inicio */
		m_finalInterval_aux = m_finalInterval;
		if(m_auxDaysRange == 0 && m_finalInterval_aux >= (current_sec - atoi(m_pendingWaitingTime.c_str()))) {
		/* EVO1-216 - JPFC - Fim */
			/* EAK-6550 - JPFC - Inicio */
			if (current_sec < atoi(m_pendingWaitingTime.c_str())) {
				m_finalInterval = current_sec;
			} else {
				m_finalInterval = current_sec - atoi(m_pendingWaitingTime.c_str());
			}
			/* EAK-6550 - JPFC - Fim */
            m_finalRange = true;
			/* EVO1-216 - JPFC - Inicio */
			outputMessage.str("");
			outputMessage << " Ultimo bloco de sondagem. Vai comecar tudo novamente ... " ;
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
			/* EVO1-216 - JPFC - Fim */
        }

    }

    /* EAK-6544 - JPFC - Inicio */
    int StatusInqReader::getCheckPointData(){
    
	/*******************************************************************
	 * Esta funcao tem os seguintes objetivos:                         *
	 * 1-) Obter dados de checkpoint do arquivo de texto;              *
	 * 2-) Avaliar como estes dados devem ser utilizados em relacao ao *
	 *     instante da incializacao;                                   *
	 * 3-) Setar os valores a serem utilizados como ponto de partida.  *
	 *******************************************************************/
		
		FILE *checkPointFile      = NULL;   /* Ponteiro para arquivo de checkpoint                      */
		char *tokenRegCheckPoint  = NULL;   /* Ponteiro para token do conteudo do arquivo de checkpoint */
		char *delimiterResult     = NULL;   /* Ponteiro para o delimitador do arquivo ';'               */
		const char fileDelimiter  =  ';';   /* Caractere delimitador de campos do arquivo de CheckPoint */
		char checkPointDate      [  8 + 1]; /* Data no checkpoint YYYYMMDD                              */
		char checkPointTimeStamp [ 14 + 1]; /* Data/hora no checkpoint YYYYMMDDHHMMSS                   */
		char checkPointFullPath  [255 + 1]; /* Caminho completo do arquivo de checkPoint                */
		char checkPointBuffer    [CHECKPOINT_BUFFER_LENGTH + 1];
		char checkPointBufferAux [CHECKPOINT_BUFFER_LENGTH + 1];

		std::ostringstream outputMessage;  /* Mensagens ao usuario */

		int  resultFlag          = 0;      /* Flag com resultado de processamento                      */
		long localCurrentDate    = 0;      /* 'currentDate' em formato long                            */
		long localCheckPointDate = 0;      /* 'checkPointDate' em formato long                         */
		int  dateDiff            = 0;      /* Diferenca entre 'currentDate' e 'checkPointDate'         */

		memset(checkPointDate     , '\0', sizeof(checkPointDate));
		memset(checkPointFullPath , '\0', sizeof(checkPointFullPath));
		memset(checkPointBuffer   , '\0', CHECKPOINT_BUFFER_LENGTH + 1);
		memset(checkPointBufferAux, '\0', CHECKPOINT_BUFFER_LENGTH + 1);
        memset(checkPointTimeStamp, '\0', sizeof(checkPointTimeStamp));

		/* Obtem data atual */
		getCurrentDate(localCurrentDate);

		/* Monta path do arquivo de checkpoint */
		sprintf(checkPointFullPath, "%s%s", getenv ("HOME"), CHECKPOINT_FULL_FILE_PATH);
		outputMessage << " Caminho completo do arquivo de checkpoint: [" << checkPointFullPath << "]";
		logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
		
		/* Abre arquivo para leitura */
		if((checkPointFile = fopen(checkPointFullPath, "r")) == NULL){
			outputMessage.str("");
			outputMessage << " Arquivo de Checkpoint nao localizado.";
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
			m_isCheckPointData = false;
			resultFlag = CHECKPOINT_FILE_NOTFOUND;
		} else {
			outputMessage.str("");
			outputMessage << " Arquivo de Checkpoint localizado. Tratando registro.";
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
			/* Faz o parse do registro */
			fgets(checkPointBuffer, CHECKPOINT_BUFFER_LENGTH + 1, checkPointFile);
			if (strlen(checkPointBuffer) == 0){
				outputMessage.str("");
				outputMessage << " Dados nao encontrados.";
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
				resultFlag = CHECKPOINT_DATA_NOTFOUND;
			} else {
				sprintf(checkPointBufferAux, "%s", checkPointBuffer);
				delimiterResult = strchr(checkPointBufferAux, fileDelimiter);
				if(delimiterResult == NULL){
					outputMessage.str("");
					outputMessage << " Formato invalido de dados: " << checkPointBuffer;
					logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
					resultFlag = CHECKPOINT_INVALID_DATA_FORMAT;
				} else {
					delimiterResult = strchr(delimiterResult + 1, fileDelimiter);
					if(delimiterResult == NULL){
						outputMessage.str("");
						outputMessage << " Formato invalido de dados: " << checkPointBuffer;
						logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
						resultFlag = CHECKPOINT_INVALID_DATA_FORMAT;
					} else {
						tokenRegCheckPoint = strtok(checkPointBuffer,";");
						sprintf(checkPointTimeStamp, "%s", tokenRegCheckPoint);
						m_checkPointDaysRange = atol(strtok(NULL,";"));
						m_checkPointFinalInterval = atol(strtok(NULL,";"));
						outputMessage.str("");
						outputMessage << " Valores obtidos: TimeStamp: [" << checkPointTimeStamp << "], DaysRange:[" << m_checkPointDaysRange << "], FinalInterval:[" << m_checkPointFinalInterval << "]";
						logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
						strncpy(checkPointDate, checkPointTimeStamp, 8);
						localCheckPointDate = atol(checkPointDate);
						/* EAK-6550 - JPFC - Inicio */
						lastCurrentDate = localCheckPointDate;
						/* EAK-6550 - JPFC - Fim */
						/*********************************************************************
						* Significa que o arquivo de checkPoint esta 'atras' da data atual. *
						* E necessario considerar esta diferenca, afim de retornar ao ponto *
						* no tempo com exatidao.                                            *
						*********************************************************************/
						dateDiff = localCurrentDate - localCheckPointDate;
						if (dateDiff > 0){
							m_checkPointDaysRange = m_checkPointDaysRange + dateDiff;
							outputMessage.str("");
							outputMessage << " Arquivo de checkPoint " << dateDiff << " dia(s) atras da data atual. Considerando esta diferenca.";
							logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
							outputMessage.str("");
							outputMessage << " Valores considerados: TimeStamp: [" << checkPointTimeStamp << "], DaysRange:[" << m_checkPointDaysRange << "], FinalInterval:[" << m_checkPointFinalInterval << "]";
							logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
							resultFlag = CHECKPOINT_DATA_FOUND;
						} else if (dateDiff < 0){
							outputMessage.str("");
							outputMessage << " Arquivo de checkPoint com data futura. Nao sera considerado.";
							logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
							resultFlag = CHECKPOINT_INVALID_DATA_FORMAT;
						} else {
							outputMessage.str("");
							outputMessage << " Arquivo de checkPoint ok.";
							logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
							resultFlag = CHECKPOINT_DATA_FOUND;
						}
					}
				}
            }
        }
        
        /* Caso arquivo de checkpoint tenha sido aberto, tenta fechar */
        if (checkPointFile) {
			if (fclose(checkPointFile) != 0) {
	            outputMessage.str("");
				outputMessage << " Falha no fechamento do Arquivo de CheckPoint.";
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
			} else {
	            outputMessage.str("");
				outputMessage << " Arquivo de CheckPoint fechado com sucesso.";
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
			}
		}
        
        return resultFlag;
    }
    
    int StatusInqReader::setCheckPointData(){

	/*********************************************************************
	 * Esta funcao tem os seguintes objetivos:                           *
	 * 1-) Registrar no arquivo de checkpoint em texto plano, os dados   *
	 *     necessarios para retomada do processamento de transacoes no   *
	 *     ponto em que pararam de ser processadas (independente do      *
	 *     motivo), no formato "YYYYMMDDHHMMSS;DDD;SSSSS", onde:         *
	 *     YYYYMMDDHHMMSS: timestamp referente ao momento do processa-   *
	 *        mento;                                                     *
	 *     DDD: Quantidade de dias corrente a ser sondada;               *
	 *     SSSSS: filtro, em segundos, das transacoes que serao sondadas *
	 *********************************************************************/
    
        FILE *checkPointFile = NULL;          /* Ponteiro para arquivo de checkpoint         */
        std::ostringstream outputMessage;     /* Mensagens ao usuario                        */
        int resultFlag  = 0;                  /* Flag com resultado de processamento         */
        int writeResult = 0;                  /* Resultado da escrita do arquivo             */
        
		time_t realTime;                      /* Estrutura para armazenamento do 'tempo'     */
        struct tm *realTimeConvertido = NULL; /* Estrutura para armazenamento do 'tempo'     */
        char timeStamp          [ 14 + 1];    /* Data checkPoint no formato 'YYYYMMDDHHMMSS' */
		char checkPointFullPath [255 + 1];    /* Caminho completo do arquivo de checkPoint   */
        
        memset(timeStamp         , '\0', sizeof(timeStamp));
		memset(checkPointFullPath, '\0', sizeof(checkPointFullPath));		
        
        /* Obtem time stamp */
        time( &realTime );
        realTimeConvertido = localtime( &realTime );
        strftime(timeStamp, 15, "%Y%m%d%H%M%S\0", realTimeConvertido);

		/* Obtem caminho do arquivo de checkpoint */
		sprintf(checkPointFullPath, "%s%s", getenv ("HOME"), CHECKPOINT_FULL_FILE_PATH);

		/* Abertura do arquivo de CheckPoint para escrita */
        if((checkPointFile = fopen(checkPointFullPath, "w")) == NULL){
            outputMessage.str("");
			outputMessage << " Falha na abertura do arquivo de Checkpoint para escrita.";
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
            resultFlag = CHECKPOINT_FILE_WRITE_OPEN_FAIL;
        } else {
            outputMessage.str("");
			outputMessage << " Escrevendo " << timeStamp << ";" << m_auxDaysRange << ";" << m_finalInterval << " no arquivo de CheckPoint.";
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
            writeResult = fprintf(checkPointFile, "%14s;%03d;%05d",
                                                timeStamp,
                                                m_auxDaysRange,
                                                m_finalInterval);
            if (writeResult < 0){
                outputMessage.str("");
				outputMessage << " Falha na escrita no arquivo de CheckPoint.";
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
                resultFlag = CHECKPOINT_FILE_WRITE_FAIL;
            } else {
                /* Escrita realizada com sucesso */
				outputMessage.str("");
                outputMessage << " Escrita no arquivo de CheckPoint efetuada com sucesso.";
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
                resultFlag = CHECKPOINT_FILE_WRITE_OK;
            }
        }
		
        /* Caso arquivo de checkpoint tenha sido aberto, tenta fechar */
        if (checkPointFile) {
			if (fclose(checkPointFile) != 0) {
	            outputMessage.str("");
				outputMessage << " Falha no fechamento do Arquivo de CheckPoint.";
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
				resultFlag = CHECKPOINT_FILE_CLOSE_FAIL;
			} else {
	            outputMessage.str("");
				outputMessage << " Arquivo de CheckPoint fechado com sucesso.";
				logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, std::string(outputMessage.str()).c_str());
				resultFlag = CHECKPOINT_FILE_CLOSE_OK;
			}
		}
        
        return resultFlag;
    }
	
	void StatusInqReader::getCurrentDate( long& currentDate ){
		
		time_t realTime;                      /* Estrutura para armazenamento do 'tempo' */
        struct tm *realTimeConvertido = NULL; /* Estrutura para armazenamento do 'tempo' */
		char localCurrentDate [ 8 + 1];       /* Data atual YYYYMMDD                     */
		
		memset(localCurrentDate, '\0', sizeof(currentDate));		
		
		time( &realTime );
        realTimeConvertido = localtime( &realTime );
        strftime(localCurrentDate, 9, "%Y%m%d\0", realTimeConvertido);
		currentDate = atol(localCurrentDate);
		
	}
    /* EAK-6544 - JPFC - Fim */
}//namespace plugins_pdv
