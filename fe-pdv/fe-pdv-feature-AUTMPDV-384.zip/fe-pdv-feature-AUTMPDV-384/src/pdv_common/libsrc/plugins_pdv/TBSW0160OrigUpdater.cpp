#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0160.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0160OrigUpdater.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
//TODOSW75 #include "dualHandler.hpp"

#include "dbaccess_pdv/TBSW0160RegrasFormatacao.hpp"

namespace plugins_pdv
{
	base::Identificable* createTBSW0160OrigUpdater()
	{
		TBSW0160OrigUpdater* l_new = new TBSW0160OrigUpdater;
		return l_new;
	}

	TBSW0160OrigUpdater::TBSW0160OrigUpdater()
	{
	}

	TBSW0160OrigUpdater::~TBSW0160OrigUpdater()
	{
	}

	bool TBSW0160OrigUpdater::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;

		a_tag->findTag( "sourceFieldPath", l_tagList );
		this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );

		a_tag->findTag( "targetFieldPath", l_tagList );
		this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

		return true;
	}

	bool TBSW0160OrigUpdater::init()
	{
        m_result     = this->navigate( m_targetFieldPath + ".RESULT" );
        m_refnum     = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
		m_orig_local_date  = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_date" );
        m_msg_name   = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
		m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
		return true;
	}

	void TBSW0160OrigUpdater::finish()
	{
	}

	int TBSW0160OrigUpdater::execute( bool& a_stop )
	{
        dbaccess_common::TBSW0160 tbsw0160;
        std::ostringstream l_whereClause;

		try
		{
            std::string l_origrefnum;
            std::string l_orig_local_date;

            fieldSet::fsextr( l_orig_local_date, m_orig_local_date );
            fieldSet::fsextr( l_origrefnum, m_origrefnum ); 
            l_whereClause << "DAT_MOV_TRAN = " << l_orig_local_date << " AND NUM_SEQ_UNC = " << l_origrefnum;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0160 ORIG ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );            

            dbaccess_common::TBSW0160 l_table0160( l_whereClause.str( ) );
            l_table0160.prepare_for_update( );
            l_table0160.execute( );

            //TODOSW75 
            /***
            dbaccess_common::DualHandler l_dualHand( &l_table0160 );
            int ret = l_dualHand.fetch( dbaccess::table::UPDATE );
            ***/
            int ret = l_table0160.fetch( );
            if ( !ret )
            {
                logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ORIGINAL TRANSACTION NOT UPDATED" );
                fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {  
                dbaccess_pdv::TBSW0160RegrasFormatacao regrasFormatacao;         
                acq_common::tbsw0160_params tbsw0160_params = { 0 };

                l_table0160.let_as_is( );
                fieldSet::fsextr( tbsw0160_params.refnum,   m_refnum ); 
                fieldSet::fsextr( tbsw0160_params.msg_name, m_msg_name);
                regrasFormatacao.NUM_SEQ_UNC_CNFR( l_table0160, tbsw0160_params, acq_common::UPDATE ); 
				l_table0160.update( );
				l_table0160.commit( );
				fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0160 <" + l_what + "> SqlDump <" + tbsw0160.getSqlDump() + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0160 <" + l_what + ">" + "> SqlDump <" + tbsw0160.getSqlDump() + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

	TBSW0160OrigUpdater& TBSW0160OrigUpdater::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
    
	TBSW0160OrigUpdater& TBSW0160OrigUpdater::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}

	dataManip::Command* TBSW0160OrigUpdater::clone() const
	{
		  return new TBSW0160OrigUpdater(*this);
	}
}//namespace standardAcqPlugins
