#pragma once

#include <cstdio>
#include <ctime>
#include "cstring"
#include <sstream>
#include <shcdef.h>
#include <algorithm>

#include "base/GenException.hpp"
#include "configBase/ConfigBase.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "defines.hpp"
#include "TBSW0036.hpp"
#include "AcqUtils.hpp"
#include "plugins_pdv/TBSW0036Inserter.hpp"

using namespace std;

namespace plugins_pdv
{
    base::Identificable* createTBSW0036Inserter( )
    {
        TBSW0036Inserter* l_new = new TBSW0036Inserter;
        return( l_new );
    }

    TBSW0036Inserter::TBSW0036Inserter( )
    {
    }

    TBSW0036Inserter::~TBSW0036Inserter( )
    {
    }

    bool TBSW0036Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList tagList;
        std::string source;

        a_tag->findTag( "sourceFieldPath", tagList );
        for ( unsigned int i = 0; i < tagList.size(); i++ )
        {
            source = tagList.at( i ).findProperty( "value" ).value();
            if ( source == "LOCAL" )
            {
                this->setLocalFieldPath( source );
            }
            else
            {
                this->setSourceFieldPath( source );
            }
        }

        a_tag->findTag( "targetFieldPath", tagList );
        this->setTargetFieldPath( tagList.front().findProperty( "value" ).value() );

        return( true );
    }

    bool TBSW0036Inserter::init( )
    {
        result = this->navigate( targetFieldPath + ".RESULT" );

        localDate = this->navigate( sourceFieldPath + ".shc_msg.local_date" );
        refnum = this->navigate( sourceFieldPath + ".shc_msg.refnum" );
        valorMoedaEstrangeira = this->navigate( sourceFieldPath + ".segments.common.valorMoedaEstrangeira" );
        codigoMoedaEstrangeira = this->navigate( sourceFieldPath + ".segments.common.codigoMoedaEstrangeira" );
        percentualTaxaMarkup = this->navigate( sourceFieldPath + ".segments.common.percentualTaxaMarkup" );
        valorTaxaConvMoeda = this->navigate( sourceFieldPath + ".segments.common.valorTaxaConvMoeda" );
        dataTranPlanet = this->navigate( sourceFieldPath + ".segments.common.dataTranPlanet" );
        numSeqUnicoPlanet = this->navigate( sourceFieldPath + ".segments.common.numSeqUnicoPlanet" );

        return( true );
    }

    void TBSW0036Inserter::finish( )
    {
    }

    int TBSW0036Inserter::execute( bool& a_stop )
    {
        int lastLine = __LINE__;
        unsigned long localDataMovimentoTransacao;
        unsigned long localNumeroSequencialUnico;
        string localValorMoedaEstrangeira;
        string localCodigoMoedaEstrangeira;
        long localPercentualTaxaMarkup;
        unsigned long localValorTaxaConversaoMoeda;
        unsigned long localDataMovimentoTransacaoConsulta;
        unsigned long localNumeroSequencialUnicoConsulta;
        
        try
        {
            dbaccess_common::TBSW0036 tbsw0036;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Inserting in TBSW0036 =========" );

            fieldSet::fsextr( localDataMovimentoTransacao, localDate );
            fieldSet::fsextr( localNumeroSequencialUnico, refnum );
            fieldSet::fsextr( localValorMoedaEstrangeira, valorMoedaEstrangeira );
            fieldSet::fsextr( localCodigoMoedaEstrangeira, codigoMoedaEstrangeira );
            fieldSet::fsextr( localPercentualTaxaMarkup, percentualTaxaMarkup );
            fieldSet::fsextr( localValorTaxaConversaoMoeda, valorTaxaConvMoeda );
            fieldSet::fsextr( localDataMovimentoTransacaoConsulta, dataTranPlanet );
            fieldSet::fsextr( localNumeroSequencialUnicoConsulta, numSeqUnicoPlanet );

            tbsw0036.SetDataMovimentoTransacao(localDataMovimentoTransacao);
            tbsw0036.SetNumeroSequencialUnico(localNumeroSequencialUnico);
            oasis_dec_t dect;
            dbm_chartodec( &dect, localValorMoedaEstrangeira.c_str( ), 0 );
            if( dbm_cmpzero( &dect ) > 0 )
                tbsw0036.SetValorMoedaEstrangeira(dect);
            tbsw0036.SetCodigoMoedaEstrangeira(localCodigoMoedaEstrangeira);
            tbsw0036.SetPercentualTaxaMarkup(localPercentualTaxaMarkup);
            if(localValorTaxaConversaoMoeda > 0)
                tbsw0036.SetValorTaxaConversaoMoeda(localValorTaxaConversaoMoeda);
            if(localDataMovimentoTransacaoConsulta > 0)
                tbsw0036.SetDataMovimentoTransacaoConsulta(localDataMovimentoTransacaoConsulta);
            if(localNumeroSequencialUnicoConsulta > 0)
                tbsw0036.SetNumeroSequencialUnicoConsulta(localNumeroSequencialUnicoConsulta);

            tbsw0036.insert( );
            tbsw0036.commit( );
            fieldSet::fscopy( result, "OK", 2 );
        }
        catch( base::GenException e )
        {
            char line[10];
            fieldSet::fscopy( result, "ERROR", 5 );
            memset( line, 0, sizeof( line ) );
            snprintf( line, sizeof( line ), "%d", lastLine );
            std::string msg = "Exception in TBSW0036 <" + std::string( e.what() ) +
                                "> at <" + std::string( line ) + ">";
            this->enableError( true );
            this->setErrorMessage( msg );
        }
        catch( std::exception e )
        {
            char line[10];
            fieldSet::fscopy( result, "ERROR", 5 );
            memset( line, 0, sizeof( line ) );
            snprintf( line, sizeof( line ), "%d", lastLine );
            std::string msg = "Exception in TBSW0036 <" + std::string( e.what() ) +
                                "> at <" + std::string( line ) + ">";
            this->enableError( true );
            this->setErrorMessage( msg );
        }

        a_stop = false;
        return( 0 );
    }
    TBSW0036Inserter& TBSW0036Inserter::setSourceFieldPath( const std::string& a_path )
    {
        sourceFieldPath = a_path;
        return( *this );
    }

    TBSW0036Inserter& TBSW0036Inserter::setTargetFieldPath( const std::string& a_path )
    {
        targetFieldPath = a_path;
        return( *this );
    }

    TBSW0036Inserter& TBSW0036Inserter::setLocalFieldPath( const std::string& a_path )
    {
        localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0036Inserter::clone( ) const
    {
        return( new TBSW0036Inserter( *this ) );
    }

}//namespace plugins_pdv

