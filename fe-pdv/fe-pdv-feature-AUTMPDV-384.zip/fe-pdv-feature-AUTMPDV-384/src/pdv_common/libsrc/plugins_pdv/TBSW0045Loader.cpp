/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0045Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0045Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>  / <698224, Raphael Gomes>
/ Data de Cria��o: <Fri Jan 11 09:26:32 2013>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0045.hpp"
#include "plugins_pdv/TBSW0045Loader.hpp"
namespace plugins_pdv
{
    base::Identificable* createTBSW0045Loader( )
    {
        TBSW0045Loader* l_new = new TBSW0045Loader;
        return l_new;
    }
    bool TBSW0045Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );
        return true;
    }
    TBSW0045Loader::TBSW0045Loader( )
    {
    }
    TBSW0045Loader::~TBSW0045Loader( )
    {
    }
    bool TBSW0045Loader::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        
        m_target_num_rv = this->navigate( m_targetFieldPath + ".NUM_RV");
        m_target_num_pdv = this->navigate( m_targetFieldPath + ".NUM_PDV");
        m_target_ind_num_qbra = this->navigate( m_targetFieldPath + ".IND_NUM_QBRA");
        m_target_dat_rv = this->navigate( m_targetFieldPath + ".DAT_RV");
        m_target_cod_bndr = this->navigate( m_targetFieldPath + ".COD_BNDR");
        m_target_nom_bndr = this->navigate( m_targetFieldPath + ".NOM_BNDR");
        m_target_cod_prod = this->navigate( m_targetFieldPath + ".COD_PROD");
        m_target_nom_prod = this->navigate( m_targetFieldPath + ".NOM_PROD");
        m_target_qtd_cv = this->navigate( m_targetFieldPath + ".QTD_CV");
        m_target_val_totl_lqdo = this->navigate( m_targetFieldPath + ".VAL_TOTL_LQDO");
        m_target_val_totl_dsct = this->navigate( m_targetFieldPath + ".VAL_TOTL_DSCT");
        m_target_val_totl_grjt = this->navigate( m_targetFieldPath + ".VAL_TOTL_GRJT");
        m_target_val_totl_pago = this->navigate( m_targetFieldPath + ".VAL_TOTL_PAGO");
        m_target_dat_cre_rv = this->navigate( m_targetFieldPath + ".DAT_CRE_RV");
        m_target_val_sit_rvs = this->navigate( m_targetFieldPath + ".VAL_SIT_RVS");
        m_target_dth_ini = this->navigate( m_targetFieldPath + ".DTH_INI");
        m_target_dth_fim = this->navigate( m_targetFieldPath + ".DTH_FIM");
        m_target_qtd_prcl = this->navigate( m_targetFieldPath + ".QTD_PRCL");
        m_target_val_entr = this->navigate( m_targetFieldPath + ".VAL_ENTR");
        m_target_val_tx_serv_rvs = this->navigate( m_targetFieldPath + ".VAL_TX_SERV_RVS");
        m_target_val_flag_qbra = this->navigate( m_targetFieldPath + ".VAL_FLAG_QBRA");
        m_target_cod_tcnl = this->navigate( m_targetFieldPath + ".COD_TCNL");
        m_target_cod_term = this->navigate( m_targetFieldPath + ".COD_TERM");
        m_target_num_stan = this->navigate( m_targetFieldPath + ".NUM_STAN");
        m_target_cod_cmpm_tran = this->navigate( m_targetFieldPath + ".COD_CMPM_TRAN");
        m_target_val_sque = this->navigate( m_targetFieldPath + ".VAL_SQUE");
        m_target_val_pres_brto = this->navigate( m_targetFieldPath + ".VAL_PRES_BRTO");
        m_target_val_rmnr_rcd = this->navigate( m_targetFieldPath + ".VAL_RMNR_RCD");
        m_target_val_iof = this->navigate( m_targetFieldPath + ".VAL_IOF");
        m_target_val_cpmf = this->navigate( m_targetFieldPath + ".VAL_CPMF");
        m_target_val_tac = this->navigate( m_targetFieldPath + ".VAL_TAC");
        m_target_tip_iof = this->navigate( m_targetFieldPath + ".TIP_IOF");
        
        m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );            
        m_in_tpo_tcn = this->navigate( m_sourceFieldPath + ".segments.merchant.in_tpo_tcn" );
        m_trace = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
        
        return true;
    }
    void TBSW0045Loader::finish( )
    {
    }
    int TBSW0045Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            long l_num_pdv, l_trace, l_in_tpo_tcn;
            char l_tech_group;
            
            fieldSet::fsextr( l_num_pdv, m_termloc );
            fieldSet::fsextr( l_in_tpo_tcn, m_in_tpo_tcn );
            fieldSet::fsextr( l_trace, m_trace );
            
            switch (l_in_tpo_tcn) 
            {
              case 3:
              case 8:
                  l_tech_group = 'P';   /* PDV */
                  break;
              case 7:
                  l_tech_group = 'G';   /* PDV Discado */
                  break;
              case 27:
                  l_tech_group = 'F';   /* PDV Leitor Trilha */
                  break;
              case 36:
                  l_tech_group = '6';   /* POS Lite */
                  break;
              default:
                  l_tech_group = 'H';   /* POS */
            }

            l_whereClause << "NUM_PDV = " << l_num_pdv << " AND COD_TCNL = '" << l_tech_group << "' AND ( (VAL_SIT_RVS = -1 AND NUM_STAN <> " << l_trace << ") OR VAL_SIT_RVS = 0)";
            
            dbaccess_common::TBSW0045 l_table0045( l_whereClause.str( ) );
            l_table0045.prepare( );
            l_table0045.execute( );
            int ret = l_table0045.fetch( );

            if( !ret )
            {
              fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
              fieldSet::fscopy( m_result, "OK", 2 );
              oasis_dec_t l_dec_temp;
              char l_bufferTemp[64];
              
              
              //fieldSet::fscopy( m_target_num_rv, l_table0045.get_NUM_RV( ) );
              l_dec_temp = l_table0045.get_NUM_RV( );
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
              fieldSet::fscopy( m_target_num_rv, std::string( l_bufferTemp ) );
              
              
              fieldSet::fscopy( m_target_num_pdv, l_table0045.get_NUM_PDV( ) );
              fieldSet::fscopy( m_target_ind_num_qbra, l_table0045.get_IND_NUM_QBRA( ) );
              fieldSet::fscopy( m_target_dat_rv, l_table0045.get_DAT_RV( ) );
              fieldSet::fscopy( m_target_cod_bndr, l_table0045.get_COD_BNDR( ) );
              fieldSet::fscopy( m_target_nom_bndr, l_table0045.get_NOM_BNDR( ) );
              fieldSet::fscopy( m_target_cod_prod, l_table0045.get_COD_PROD( ) );
              fieldSet::fscopy( m_target_nom_prod, l_table0045.get_NOM_PROD( ) );
              
              //fieldSet::fscopy( m_target_qtd_cv, l_table0045.get_QTD_CV( ) );
              l_dec_temp = l_table0045.get_QTD_CV( );
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
              fieldSet::fscopy( m_target_qtd_cv, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_totl_lqdo, l_table0045.get_VAL_TOTL_LQDO( ) );
              l_dec_temp = l_table0045.get_VAL_TOTL_LQDO( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_totl_lqdo, std::string( l_bufferTemp ) );
           
              //fieldSet::fscopy( m_target_val_totl_dsct, l_table0045.get_VAL_TOTL_DSCT( ) );
              l_dec_temp = l_table0045.get_VAL_TOTL_DSCT( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_totl_dsct, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_totl_grjt, l_table0045.get_VAL_TOTL_GRJT( ) );
              l_dec_temp = l_table0045.get_VAL_TOTL_GRJT( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_totl_grjt, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_totl_pago, l_table0045.get_VAL_TOTL_PAGO( ) );
              l_dec_temp = l_table0045.get_VAL_TOTL_PAGO( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_totl_pago, std::string( l_bufferTemp ) );
              
              
              fieldSet::fscopy( m_target_dat_cre_rv, l_table0045.get_DAT_CRE_RV( ) );
              fieldSet::fscopy( m_target_val_sit_rvs, l_table0045.get_VAL_SIT_RVS( ) );
              fieldSet::fscopy( m_target_dth_ini, l_table0045.get_DTH_INI( ) );
              fieldSet::fscopy( m_target_dth_fim, l_table0045.get_DTH_FIM( ) );
              fieldSet::fscopy( m_target_qtd_prcl, l_table0045.get_QTD_PRCL( ) );
              
              //fieldSet::fscopy( m_target_val_entr, l_table0045.get_VAL_ENTR( ) );
              l_dec_temp = l_table0045.get_VAL_ENTR( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_entr, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_tx_serv_rvs, l_table0045.get_VAL_TX_SERV_RVS( ) );
              l_dec_temp = l_table0045.get_VAL_TX_SERV_RVS( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_tx_serv_rvs, std::string( l_bufferTemp ) );
              
              
              fieldSet::fscopy( m_target_val_flag_qbra, l_table0045.get_VAL_FLAG_QBRA( ) );
              fieldSet::fscopy( m_target_cod_tcnl, l_table0045.get_COD_TCNL( ) );
              fieldSet::fscopy( m_target_cod_term, l_table0045.get_COD_TERM( ) );
              fieldSet::fscopy( m_target_num_stan, l_table0045.get_NUM_STAN( ) );
              fieldSet::fscopy( m_target_cod_cmpm_tran, l_table0045.get_COD_CMPM_TRAN( ) );
              
              //fieldSet::fscopy( m_target_val_sque, l_table0045.get_VAL_SQUE( ) );
              l_dec_temp = l_table0045.get_VAL_SQUE( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_sque, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_pres_brto, l_table0045.get_VAL_PRES_BRTO( ) );
              l_dec_temp = l_table0045.get_VAL_PRES_BRTO( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_pres_brto, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_rmnr_rcd, l_table0045.get_VAL_RMNR_RCD( ) );
              l_dec_temp = l_table0045.get_VAL_RMNR_RCD( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_rmnr_rcd, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_iof, l_table0045.get_VAL_IOF( ) );
              l_dec_temp = l_table0045.get_VAL_IOF( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_iof, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_cpmf, l_table0045.get_VAL_CPMF( ) );
              l_dec_temp = l_table0045.get_VAL_CPMF( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_cpmf, std::string( l_bufferTemp ) );
              
              //fieldSet::fscopy( m_target_val_tac, l_table0045.get_VAL_TAC( ) );
              l_dec_temp = l_table0045.get_VAL_TAC( );                          
              memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );               
              dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );              
              fieldSet::fscopy( m_target_val_tac, std::string( l_bufferTemp ) );
              
              fieldSet::fscopy( m_target_tip_iof, l_table0045.get_TIP_IOF( ) );
            }
        }
        
        catch( base::GenException e )
        {
         fieldSet::fscopy( m_result, "ERROR", 5 );
         std::string l_what( e.what( ) );
         std::string l_msg = "Gen Exception in TBSW0045 <" + l_what + ">";
         this->enableError( true );
         this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
         fieldSet::fscopy( m_result, "ERROR", 5 );
         std::string l_what( e.what( ) );
         std::string l_msg = "std::exception in TBSW0045 <" + l_what + ">";
         this->enableError( true );
         this->setErrorMessage( l_msg );
        }
        
     a_stop = false;
     return 0;
    }
    
    TBSW0045Loader& TBSW0045Loader::setTargetFieldPath( const std::string& a_path )
    {
     m_targetFieldPath = a_path;
     return *this;
    }
    
    TBSW0045Loader& TBSW0045Loader::setSourceFieldPath( const std::string& a_path )
    {
     m_sourceFieldPath = a_path;
     return *this;
    }
    
    dataManip::Command* TBSW0045Loader::clone( ) const
    {
     return new TBSW0045Loader(*this);
    }
    
}//namespace plugins_pdv
