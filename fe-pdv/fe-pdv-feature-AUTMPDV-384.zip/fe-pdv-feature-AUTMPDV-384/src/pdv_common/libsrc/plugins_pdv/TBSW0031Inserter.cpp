#pragma once
#include <cstdio>
#include <cstring>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0031Inserter.hpp"
#include "dbaccess_pdv/TBSW0031RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0031Inserter( )
    {
        TBSW0031Inserter* l_new = new TBSW0031Inserter;
        return( l_new );
    }

    TBSW0031Inserter::TBSW0031Inserter( )
    {
    }

    TBSW0031Inserter::~TBSW0031Inserter( )
    {
    }

    bool TBSW0031Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return( true );
    }

    bool TBSW0031Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =          this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =              this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_ind_term_flex =       this->navigate( m_sourceFieldPath + ".segments.merchant.ind_term_flex" );
        m_ctah =                this->navigate( m_sourceFieldPath + ".segments.voucher.ctah" );
        m_num_ref_tran =        this->navigate( m_sourceFieldPath + ".segments.credit.numeroTransacaoEmissor" );
        m_cod_cpcd_term =       this->navigate( m_sourceFieldPath + ".segments.credit.codigoCapacidadeTerminalEmissor" );

        /// COD_PROD_MTC
        infoCodigoProdutoMastercard = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_prod_code" );
        /// COD_RGAO_MTC
        infoRegiaoMastercard  = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_region" );

        categoriaMensagem = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        nomeIssuer        = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );

        numeroEstabelecimentoPreAutorizacao = this->navigate( m_localFieldPath + ".num_estb_pauz" );
        codigoTerminalPreAutorizacao = this->navigate( m_localFieldPath + ".cod_term_pauz" );

        return( true );
    }

    void TBSW0031Inserter::finish( )
    {
    }

    int TBSW0031Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0031 l_table0031;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0031" );
            dbaccess_pdv::TBSW0031RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0031_params params = { 0 };

            fieldSet::fsextr( params.local_date,    m_local_date );
            fieldSet::fsextr( params.refnum,        m_refnum );
            fieldSet::fsextr( params.ind_term_flex, m_ind_term_flex );
            fieldSet::fsextr( params.ctah,          m_ctah );
            fieldSet::fsextr( params.num_ref_tran,  m_num_ref_tran );
            fieldSet::fsextr( params.cod_cpcd_term, m_cod_cpcd_term );
            fieldSet::fsextr( params.mc_info_prod_code, infoCodigoProdutoMastercard ); /// COD_PROD_MTC
            fieldSet::fsextr( params.mc_info_region,    infoRegiaoMastercard );  /// COD_RGAO_MTC
            fieldSet::fsextr( params.categoriaMensagem, categoriaMensagem );
            fieldSet::fsextr( params.iss_name,          nomeIssuer );
            fieldSet::fsextr( params.numeroEstabelecimentoPreAutorizacao, numeroEstabelecimentoPreAutorizacao );
            fieldSet::fsextr( params.codigoTerminalPreAutorizacao, codigoTerminalPreAutorizacao );

            regrasFmt.DAT_MOV_TRAN      ( l_table0031, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC       ( l_table0031, params, acq_common::INSERT );
            regrasFmt.NUM_ADM           ( l_table0031, params, acq_common::INSERT );
            regrasFmt.VAL_MN_CAR        ( l_table0031, params, acq_common::INSERT );
            regrasFmt.IND_TERM_FATR_EXPS( l_table0031, params, acq_common::INSERT );
            regrasFmt.COD_CTAH_VOCH     ( l_table0031, params, acq_common::INSERT );
            regrasFmt.NUM_REF_TRAN      ( l_table0031, params, acq_common::INSERT );
            regrasFmt.COD_CPCD_TERM     ( l_table0031, params, acq_common::INSERT );
            regrasFmt.COD_PROD_MTC      ( l_table0031, params, acq_common::INSERT );
            regrasFmt.COD_RGAO_MTC      ( l_table0031, params, acq_common::INSERT );
            regrasFmt.NumeroEstabelecimentoPreAutorizacao( l_table0031, params, acq_common::INSERT );
            regrasFmt.CodigoTerminalPreAutorizacao( l_table0031, params, acq_common::INSERT );

            l_table0031.insert( );
            l_table0031.commit( );

            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "NOT INSERTED", 12 );
            std::string l_msg = "Gen Exception in TBSW0031 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "NOT INSERTED", 12 );
            std::string l_msg = "std::exception in TBSW0031 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }

    TBSW0031Inserter& TBSW0031Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    TBSW0031Inserter& TBSW0031Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    TBSW0031Inserter& TBSW0031Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0031Inserter::clone( ) const
    {
        return( new TBSW0031Inserter( *this ) );
    }
} // namespace plugins_pdv
