/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0033RevInserter>
/ Descricao: <Arquivo de implementacao da classe plugins_pdv::TBSW0033RevInserter>
/ Conteudo: <Lista de Modulos definidos>
/ Autor: <689687, Felipe Bezerra>
/ Data de Criacao: <2013, 18 de Janeiro>
/ Historico Mudancas: <Data, Modulo, Autor, Descricao da Mudanca>
/ . . .
/ <Data, Modulo, Autor, Descricao da Mudanca>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0033.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0033RevInserter.hpp"

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "dbaccess_pdv/TBSW0033RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0033RevInserter()
    {
        TBSW0033RevInserter* l_new = new TBSW0033RevInserter;     
        return l_new;
    }
    
    TBSW0033RevInserter::TBSW0033RevInserter()
    {
    }
    
    TBSW0033RevInserter::~TBSW0033RevInserter()
    {
    }
    
    bool TBSW0033RevInserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;
    
        a_tag->findTag( "sourceFieldPath", l_tagList );    
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
                this->setLocalFieldPath( l_source );
            else
                this->setSourceFieldPath( l_source );
        }
    
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );
            
        return true;  
    }
    
    bool TBSW0033RevInserter::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );      
        m_ecr_orig_elems = this->navigate( m_sourceFieldPath + ".segments.common.ecr_orig_elems" );
        m_trace = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
        m_cd_tpo_trm = this->navigate( m_sourceFieldPath + ".segments.merchant.cd_tpo_trm" );
        m_load_program = this->navigate( m_sourceFieldPath + ".segments.merchant.load_program" );
        m_load_init = this->navigate( m_sourceFieldPath + ".segments.merchant.load_init" );
        m_nu_age_etb = this->navigate( m_sourceFieldPath + ".segments.merchant.nu_age_etb" );
        m_cod_cta_etb = this->navigate( m_sourceFieldPath + ".segments.merchant.cd_cta_etb" ); 
        m_in_tpo_tcn = this->navigate( m_sourceFieldPath + ".segments.merchant.in_tpo_tcn" ); 
        m_is_void = this->navigate( m_sourceFieldPath + ".segments.common.is_void" );  //BT 55.768
        m_is_reversal = this->navigate( m_sourceFieldPath + ".segments.common.is_reversal" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".common.origrefnum" );
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_origtime = this->navigate( m_sourceFieldPath + ".shc_msg.origtime" );
        m_origmsg = this->navigate( m_sourceFieldPath + ".shc_msg.origmsg" );
        m_indUtlzPnpd = this->navigate( m_localFieldPath + ".IND_UTLZ_PNPD" );
        mensagemCategoria = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        dataLocalOriginal = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_date" );
        horaLocalOriginal = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_time" );
        nomeMensagem       = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        nomeEmissor        = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        cartao             = this->navigate( m_sourceFieldPath + ".shc_msg.pan" );
        
        // t689049@FIS - Data: 28/09/2014 - origtrace ..
        m_origtrace = this->navigate( m_sourceFieldPath + ".shc_msg.origtrace" );
        
        return true;
    }

    void TBSW0033RevInserter::finish()
    {
    }

    int TBSW0033RevInserter::execute( bool& a_stop )
    {
        char l_msgAux[64] = {0};
        int l_lastLine = __LINE__;
   
        try
        {            
            dbaccess_pdv::TBSW0033RegrasFormatacao regrasFormatacao;
            dbaccess_common::TBSW0033 tbsw0033;
            acq_common::tbsw0033_params tbsw0033_params = { 0 };
            
            fieldSet::fsextr( tbsw0033_params.local_date,   m_local_date );
            fieldSet::fsextr( tbsw0033_params.refnum,       m_refnum );
            fieldSet::fsextr( tbsw0033_params.origdate,     m_origdate );
            fieldSet::fsextr( tbsw0033_params.origtime,     m_origtime );
            fieldSet::fsextr( tbsw0033_params.origtrace,    m_origtrace );
            fieldSet::fsextr( tbsw0033_params.origmsg,      m_origmsg );
            fieldSet::fsextr( tbsw0033_params.trace,        m_trace );
            fieldSet::fsextr( tbsw0033_params.msg_category, mensagemCategoria );
            fieldSet::fsextr( tbsw0033_params.cd_tpo_trm,   m_cd_tpo_trm );
            fieldSet::fsextr( tbsw0033_params.in_tpo_tcn,   m_in_tpo_tcn );
            fieldSet::fsextr( tbsw0033_params.load_program, m_load_program );
            fieldSet::fsextr( tbsw0033_params.load_init,    m_load_init );
            fieldSet::fsextr( tbsw0033_params.nu_age_etb,   m_nu_age_etb );
            fieldSet::fsextr( tbsw0033_params.cd_cta_etb,   m_cod_cta_etb );
            fieldSet::fsextr( tbsw0033_params.indUtlzPnpd,  m_indUtlzPnpd );
            fieldSet::fsextr( tbsw0033_params.dataLocalOriginal, dataLocalOriginal );
            fieldSet::fsextr( tbsw0033_params.horaLocalOriginal, horaLocalOriginal );
            fieldSet::fsextr( tbsw0033_params.msg_name,      nomeMensagem );
            fieldSet::fsextr( tbsw0033_params.nomeEmissor,   nomeEmissor );
            fieldSet::fsextr( tbsw0033_params.cartao,        cartao );
            
            regrasFormatacao.NUM_BCO_DEB ( tbsw0033, tbsw0033_params, acq_common::INSERT );
            regrasFormatacao.NUM_TEL     ( tbsw0033, tbsw0033_params, acq_common::INSERT );
            regrasFormatacao.DAT_MOV_TRAN( tbsw0033, tbsw0033_params, acq_common::INSERT );
            regrasFormatacao.NUM_SEQ_UNC ( tbsw0033, tbsw0033_params, acq_common::INSERT );  
            regrasFormatacao.TXT_MSG_1   ( tbsw0033, tbsw0033_params, acq_common::INSERT );
            regrasFormatacao.TXT_MSG_2   ( tbsw0033, tbsw0033_params, acq_common::INSERT );

            tbsw0033.insert( );
            tbsw0033.commit( );
            
            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch( base::GenException e )
        {
            char l_line[10];
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0033 <" + std::string( e.what() ) + 
                                "> at <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            char l_line[10];
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0033 <" + std::string( e.what() ) + 
                                "> at <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        
        a_stop = false;
        return 0; 
    }

    TBSW0033RevInserter& TBSW0033RevInserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
  
    TBSW0033RevInserter& TBSW0033RevInserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
    
    TBSW0033RevInserter& TBSW0033RevInserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }
    
    dataManip::Command* TBSW0033RevInserter::clone() const
    {
        return new TBSW0033RevInserter(*this);
    }
  
}//namespace standardAcqPlugins
