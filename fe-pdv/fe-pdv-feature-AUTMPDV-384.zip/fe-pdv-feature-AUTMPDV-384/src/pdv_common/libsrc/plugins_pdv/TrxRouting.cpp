#pragma once
#include <sstream>
#include "dbaccess_pdv/RoutingTablesJoint.hpp"
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TrxRouting.hpp"
#include "plugins_pdv/Range.hpp"

namespace plugins_pdv
{
	base::Identificable* createTrxRouting( )
	{
		TrxRouting* l_new = new TrxRouting;
		return l_new;
	}
	bool TrxRouting::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "targetFieldPath", l_tagList );
		m_targetFieldPath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "sourceFieldPath", l_tagList );
		m_sourceFieldPath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "sourceBin", l_tagList );
		m_binPath = l_tagList.front( ).findProperty( "value" ).value( );
		
		return true;
	}
	TrxRouting::TrxRouting( )
	{
	}
	TrxRouting::~TrxRouting( )
	{
	}
	bool TrxRouting::init( )
	{
		m_inputBin = navigate( m_binPath );
		if ( !m_inputBin )
		{
			std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + ".bin" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_inputCodTipTran = navigate( m_sourceFieldPath + ".codTipTran" );
		if ( !m_inputCodTipTran )
		{
			std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + ".codTipTran" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_inputNomHostAcqr = navigate( m_sourceFieldPath + ".nomHostAcqr" );
		if ( !m_inputNomHostAcqr )
		{
			std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + ".nomHostAcqr" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_inputNomFeAcqr = navigate( m_sourceFieldPath + ".nomFeAcqr" );
		if ( !m_inputNomFeAcqr )
		{
			std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + ".nomFeAcqr" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		
		m_outputCodRota = navigate( m_targetFieldPath + ".codRota" );
		if ( !m_outputCodRota )
		{
			std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".codRota" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_outputCodIssrSw = navigate( m_targetFieldPath + ".codIssrSw" );
		if ( !m_outputCodIssrSw )
		{
			std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".codIssrSw" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_outputNetworkId = navigate( m_targetFieldPath + ".networkId" );
		if ( !m_outputNetworkId )
		{
			std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".networkId" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
        m_outputNetworkIdVan = navigate( m_targetFieldPath + ".networkIdVan" );
        if ( !m_outputNetworkIdVan )
        {
            std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".networkIdVan" + ">" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
			
		m_outputNomEmsrSw = navigate( m_targetFieldPath + ".nomEmsrSw" );
		if ( !m_outputNomEmsrSw )
		{
			std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".nomEmsrSw" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_outputCodEmsrSw = navigate( m_targetFieldPath + ".codEmsrSw" );
		if ( !m_outputCodEmsrSw )
		{
			std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".codEmsrSw" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_outputCodBndr = navigate( m_targetFieldPath + ".codBndr" );
		if ( !m_outputCodBndr )
		{
			std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".codBndr" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_outputCodFeEmsr = navigate( m_targetFieldPath + ".codFeEmsr" );
		if ( !m_outputCodFeEmsr )
		{
			std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".codFeEmsr" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		m_resultField = navigate( m_targetFieldPath + ".result" );
		if ( !m_resultField )
		{
			std::string l_errorMsg( "Field not found <" + m_targetFieldPath + ".result" + ">" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg );
			return false;
		}
		
		std::string l_whereClause;
		
		l_whereClause += " TB_ROTA.COD_TIP_TRAN='" + m_inputCodTipTran.value() + "' AND ( TB_ROTA.NOM_HOST_ACQR='";
		l_whereClause += m_inputNomHostAcqr.value() + "' OR TB_ROTA.NOM_HOST_ACQR='*' ) ";
		l_whereClause += " AND ( TB_ROTA.NOM_FE_ACQR ='" + m_inputNomFeAcqr.value() + "' OR TB_ROTA.NOM_FE_ACQR='*' ) ";
		dbaccess_pdv::RoutingTablesJoint l_routingTablesJoint( l_whereClause );
		l_routingTablesJoint.prepare();
		
		l_routingTablesJoint.execute();
		
		while ( l_routingTablesJoint.fetch() )
		{
			Range l_range;

			l_range.setCOD_ROTA( l_routingTablesJoint.getCOD_ROTA() );
			l_range.setNUM_BIN_CAR_INI( l_routingTablesJoint.getNUM_BIN_CAR_INI() );
			l_range.setNUM_BIN_CAR_FIM( l_routingTablesJoint.getNUM_BIN_CAR_FIM() );
			l_range.setCOD_ISSR_SW( l_routingTablesJoint.getCOD_ISSR_SW() );
			l_range.setCOD_TIP_TRAN( l_routingTablesJoint.getCOD_TIP_TRAN() );
			l_range.setIND_PRRD( l_routingTablesJoint.getIND_PRRD() );
			l_range.setNETWORK_ID( l_routingTablesJoint.getNETWORK_ID() );
			l_range.setNETWORK_ID_VAN( l_routingTablesJoint.getNETWORK_ID_VAN() );
			l_range.setNOM_HOST_ACQR( l_routingTablesJoint.getNOM_HOST_ACQR() );
			l_range.setNOM_FE_ACQR( l_routingTablesJoint.getNOM_FE_ACQR() );
			l_range.setNOM_EMSR_SW( l_routingTablesJoint.getNOM_EMSR_SW() );
			l_range.setCOD_EMSR_SW( l_routingTablesJoint.getCOD_EMSR_SW() );
			l_range.setCOD_BNDR( l_routingTablesJoint.getCOD_BNDR() );
			l_range.setCOD_FE_EMSR( l_routingTablesJoint.getCOD_FE_EMSR() );
			l_range.setIS_VALID( true );

			m_binRangeSearch.m_rangeDeque.push_back( l_range );
		}
		
		m_binRangeSearch.init();

		return true;
	}
	void TrxRouting::finish( )
	{
	}
	int TrxRouting::execute( bool& a_stop )
	{
		try
		{
			Range routingRange;
			int l_bin = 0;

			fieldSet::fsextr( l_bin, m_inputBin );
			routingRange = m_binRangeSearch.findRange( l_bin );			
			
			if( routingRange.getIS_VALID() == true )
			{
				fieldSet::fscopy( m_outputCodRota, routingRange.getCOD_ROTA() );
				fieldSet::fscopy( m_outputCodIssrSw, routingRange.getCOD_ISSR_SW() );
				fieldSet::fscopy( m_outputNetworkId, routingRange.getNETWORK_ID() );
				fieldSet::fscopy( m_outputNetworkIdVan, routingRange.getNETWORK_ID_VAN() );
				fieldSet::fscopy( m_outputNomEmsrSw, routingRange.getNOM_EMSR_SW() );
				fieldSet::fscopy( m_outputCodEmsrSw, routingRange.getCOD_EMSR_SW() );
				fieldSet::fscopy( m_outputCodBndr, routingRange.getCOD_BNDR() );
				fieldSet::fscopy( m_outputCodFeEmsr, routingRange.getCOD_FE_EMSR() );
				fieldSet::fscopy( m_resultField, "OK" );
			}
			else
			{
				fieldSet::fscopy( m_resultField, "NOT FOUND" );
			}
		}
		catch( base::GenException e )
		{
			std::string l_what( e.what() );
			std::string l_msg = "Exception in TrxRouting<" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}

		a_stop = false;
		return 0;
	}
	dataManip::Command* TrxRouting::clone( ) const
	{
		return new TrxRouting( *this );
	}
}//namespace plugins_pdv
