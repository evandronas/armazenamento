/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0140.hpp"
#include "plugins_pdv/TBSW0140Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
	base::Identificable* createTBSW0140Loader( )
	{
		TBSW0140Loader* l_new = new TBSW0140Loader;
		return l_new;
	}
	bool TBSW0140Loader::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		
		a_tag->findTag( "sourceFieldPath", l_tagList );
		this->setSourceFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
		a_tag->findTag( "targetFieldPath", l_tagList );		
		this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
		
		return true;
	}
	TBSW0140Loader::TBSW0140Loader( )
	{
	}
	TBSW0140Loader::~TBSW0140Loader( )
	{
	}
	bool TBSW0140Loader::init( )
	{
		m_RESULT = this->navigate( m_targetFieldPath + ".RESULT" );
        m_COD_MCC = this->navigate( m_targetFieldPath + ".COD_MCC" );
		
		m_mer_cat_code = this->navigate( m_sourceFieldPath + ".segments.merchant.mer_cat_code" );
		m_cod_bndr = this->navigate( m_sourceFieldPath + ".segments.common.cod_bndr" );
		
		return true;
	}
	void TBSW0140Loader::finish( )
	{
	}
	int TBSW0140Loader::execute( bool& a_stop )
	{
		try
		{
			//std::string l_mer_cat_code;
            //std::string l_cod_bndr;
            
			//fieldSet::fsextr( l_mer_cat_code, m_mer_cat_code );
            //fieldSet::fsextr( l_cod_bndr, m_cod_bndr );

			long l_mer_cat_code = 0;
            long l_cod_bndr = 0;

			fieldSet::fsextr( l_mer_cat_code, m_mer_cat_code );
            fieldSet::fsextr( l_cod_bndr, m_cod_bndr );
			
			std::ostringstream l_whereClause;
			//l_whereClause << "COD_RAM_ATVD = '" << l_mer_cat_code << "' AND COD_BNDR = '" << l_cod_bndr << "' ";
            l_whereClause << "COD_RAM_ATVD = " << l_mer_cat_code << " AND COD_BNDR = " << l_cod_bndr << " ";
						
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0140 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
            dbaccess_common::TBSW0140 l_table0140( l_whereClause.str( ) );

			l_table0140.prepare( );
			l_table0140.execute( );
			
			if ( !l_table0140.fetch( ) )
			{
				fieldSet::fscopy( m_RESULT, std::string( "NO ROWS" ) );
			}
			else
			{
				fieldSet::fscopy( m_RESULT, std::string( "OK" ) );
				fieldSet::fscopy( m_COD_MCC, l_table0140.getCOD_MCC( ) );
			}
		}
		catch( base::GenException e )
		{
			fieldSet::fscopy( m_RESULT, std::string( "ERROR" ) );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0140 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			fieldSet::fscopy( m_RESULT, std::string( "ERROR" ) );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0140[" + l_what + "]";
			this->enableError( true );
			this->setErrorMessage( l_msg );			
		}
		
		a_stop = false;
		return 0;
	}
	TBSW0140Loader& TBSW0140Loader::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	TBSW0140Loader& TBSW0140Loader::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	dataManip::Command* TBSW0140Loader::clone( ) const
	{
		return new TBSW0140Loader( *this );
	}
}//namespace plugins_pdv

