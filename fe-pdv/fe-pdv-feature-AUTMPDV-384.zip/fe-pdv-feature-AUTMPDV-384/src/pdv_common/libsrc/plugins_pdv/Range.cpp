/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Teller
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t689064, Raphael Teller, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "plugins_pdv/Range.hpp"

namespace plugins_pdv
{
	Range::Range()
	{
	}
	Range::~Range()
	{
	}
	
	//--------------------------- GET ---------------------------
	long Range::getCOD_ROTA() const
	{
		return m_COD_ROTA;
	}
	const std::string& Range::getNUM_BIN_CAR_INI() const
	{
		return m_NUM_BIN_CAR_INI;
	}
	const std::string& Range::getNUM_BIN_CAR_FIM() const
	{
		return m_NUM_BIN_CAR_FIM;
	}
	long Range::getCOD_ISSR_SW() const
	{
		return m_COD_ISSR_SW;
	}
	const std::string& Range::getCOD_TIP_TRAN() const
	{
		return m_COD_TIP_TRAN;
	}
	long Range::getIND_PRRD() const
	{
		return m_IND_PRRD;
	}
	const std::string& Range::getNETWORK_ID() const
	{
		return m_NETWORK_ID;
	}
    const std::string& Range::getNETWORK_ID_VAN() const
    {
        return m_NETWORK_ID_VAN;
    }
	const std::string& Range::getNOM_HOST_ACQR() const
	{
		return m_NOM_HOST_ACQR;
	}
	const std::string& Range::getNOM_FE_ACQR() const
	{
		return m_NOM_FE_ACQR;
	}
	const std::string& Range::getNOM_EMSR_SW() const
	{
		return m_NOM_EMSR_SW;
	}
	long Range::getCOD_EMSR_SW() const
	{
		return m_COD_EMSR_SW;
	}
	long Range::getCOD_BNDR() const
	{
		return m_COD_BNDR;
	}
	long Range::getCOD_FE_EMSR() const
	{
		return m_COD_FE_EMSR;
	}
	bool Range::getIS_VALID() const
	{
		return m_IS_VALID;
	}

	//--------------------------- SET ---------------------------
	void Range::setCOD_ROTA( long a_COD_ROTA )
	{
		m_COD_ROTA = a_COD_ROTA;
	}
	void Range::setNUM_BIN_CAR_INI( const std::string& a_NUM_BIN_CAR_INI )
	{
		m_NUM_BIN_CAR_INI = a_NUM_BIN_CAR_INI;
	}
	void Range::setNUM_BIN_CAR_FIM( const std::string& a_NUM_BIN_CAR_FIM )
	{
		m_NUM_BIN_CAR_FIM = a_NUM_BIN_CAR_FIM;
	}
	void Range::setCOD_ISSR_SW( long a_COD_ISSR_SW )
	{
		m_COD_ISSR_SW = a_COD_ISSR_SW;
	}
	void Range::setCOD_TIP_TRAN( const std::string& a_COD_TIP_TRAN )
	{
		m_COD_TIP_TRAN = a_COD_TIP_TRAN;
	}
	void Range::setIND_PRRD( long a_IND_PRRD )
	{
		m_IND_PRRD = a_IND_PRRD;
	}
	void Range::setNETWORK_ID( const std::string& a_NETWORK_ID )
	{
		m_NETWORK_ID = a_NETWORK_ID;
	}
    void Range::setNETWORK_ID_VAN( const std::string& a_NETWORK_ID_VAN )
    {
        m_NETWORK_ID_VAN = a_NETWORK_ID_VAN;
    }
	void Range::setNOM_HOST_ACQR( const std::string& a_NOM_HOST_ACQR )
	{
		m_NOM_HOST_ACQR = a_NOM_HOST_ACQR;
	}
	void Range::setNOM_FE_ACQR( const std::string& a_NOM_FE_ACQR )
	{
		m_NOM_FE_ACQR = a_NOM_FE_ACQR;
	}
	void Range::setNOM_EMSR_SW( const std::string& a_NOM_EMSR_SW )
	{
		m_NOM_EMSR_SW = a_NOM_EMSR_SW;
	}
	void Range::setCOD_EMSR_SW( long a_COD_EMSR_SW )
	{
		m_COD_EMSR_SW = a_COD_EMSR_SW;
	}
	void Range::setCOD_BNDR( long a_COD_BNDR )
	{
		m_COD_BNDR = a_COD_BNDR;
	}
	void Range::setCOD_FE_EMSR( long a_COD_FE_EMSR )
	{
		m_COD_FE_EMSR = a_COD_FE_EMSR;
	}
	void Range::setIS_VALID( bool a_boolean )
	{
		m_IS_VALID = a_boolean;
	}
}

