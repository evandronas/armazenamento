#pragma once
#include <cstring>
#include <sstream>
#include "dbaccess_pdv/RoutingVoucherTablesJoint.hpp"
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TrxVoucherRouting.hpp"
#include "plugins_pdv/RangeVoucher.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTrxVoucherRouting( )
    {
        TrxVoucherRouting* l_new = new TrxVoucherRouting;
        return l_new;
    }
    bool TrxVoucherRouting::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        a_tag->findTag( "targetFieldPath", l_tagList );
        m_targetFieldPath = l_tagList.front( ).findProperty( "value" ).value( );

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            std::string l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
                localFieldPath = l_tagList.at( i ).findProperty( "value" ).value();
            else
                m_sourceFieldPath = l_tagList.at( i ).findProperty( "value" ).value();
        }

        return true;
    }
    TrxVoucherRouting::TrxVoucherRouting( )
    {
    }
    TrxVoucherRouting::~TrxVoucherRouting( )
    {
    }
    bool TrxVoucherRouting::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".result" );

        m_cod_sttu_reg = this->navigate( m_targetFieldPath + ".COD_STTU_REG" );
        m_num_rtdr = this->navigate( m_targetFieldPath + ".NUM_RTDR" );
        m_cod_sbpd = this->navigate( m_targetFieldPath + ".COD_SBPD" );
        m_cod_emsr = this->navigate( m_targetFieldPath + ".COD_EMSR" );
        m_nom_emsr = this->navigate( m_targetFieldPath + ".NOM_EMSR" );
        m_cod_tran_ge = this->navigate( m_targetFieldPath + ".COD_TRAN_GE" );
        m_nom_prod_cpom = this->navigate( m_targetFieldPath + ".NOM_PROD_CPOM" );
        m_txt_rdpe_cpom = this->navigate( m_targetFieldPath + ".TXT_RDPE_CPOM" );
        m_cod_usr_atlz_reg = this->navigate( m_targetFieldPath + ".COD_USR_ATLZ_REG" );
        m_dat_atlz_reg = this->navigate( m_targetFieldPath + ".DAT_ATLZ_REG" );
        m_dat_atvc_voch = this->navigate( m_targetFieldPath + ".DAT_ATVC_VOCH" );
        m_ntwkid = this->navigate( m_targetFieldPath + ".NTWKID" );
        m_num_bin = this->navigate( m_targetFieldPath + ".NUM_BIN" );

        m_cod_issr_sw = this->navigate( m_targetFieldPath + ".COD_ISSR_SW" );
        m_nom_emsr_sw = this->navigate( m_targetFieldPath + ".NOM_EMSR_SW" );
        m_cod_emsr_sw = this->navigate( m_targetFieldPath + ".COD_EMSR_SW" );
        m_cod_bndr = this->navigate( m_targetFieldPath + ".COD_BNDR" );
        m_cod_fe_emsr = this->navigate( m_targetFieldPath + ".COD_FE_EMSR" );

        m_bin = this->navigate( m_sourceFieldPath + ".segments.common.bin" );
        m_cod_issuer_sw = this->navigate( m_sourceFieldPath + ".segments.common.issuer_id" );
        m_track2 = this->navigate( m_sourceFieldPath + ".shc_msg.track2" );
        pan = this->navigate( m_sourceFieldPath + ".shc_msg.pan" );
        categoriaMensagem = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );

        numeroRoteador = this->navigate( localFieldPath + ".num_rtdr" );

        return true;

    }
    void TrxVoucherRouting::finish( )
    {
    }
    int TrxVoucherRouting::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_bin, l_cod_issuer_sw;
            unsigned long l_num_rtdr = 0;
            unsigned long numeroSubBin = 0;
            std::string l_track2;
            std::string cartao;
            std::string categoria;
            std::string numeroRoteadorOriginal;

            fieldSet::fsextr( l_bin, m_bin );
            fieldSet::fsextr( l_cod_issuer_sw, m_cod_issuer_sw );
            fieldSet::fsextr( l_track2, m_track2 );
            fieldSet::fsextr( cartao, pan );
            fieldSet::fsextr( categoria, categoriaMensagem );
            fieldSet::fsextr( numeroRoteadorOriginal, numeroRoteador );

            l_whereClause << " TB_EMSR.COD_ISSR_SW = " << l_cod_issuer_sw << " AND ";
            l_whereClause << " TB_ROTA.NUM_BIN = " << l_bin << " AND TB_ROTA.COD_STTU_REG = 'A' ";
            l_whereClause << " AND TB_ROTA.DAT_ATVC_VOCH <= CURRENT_TIMESTAMP ";

            if( categoria == "ESTORNO" )
            {
                if( numeroRoteadorOriginal.empty( ) == false && numeroRoteadorOriginal != "0" )
                {
                    l_num_rtdr = atol( numeroRoteadorOriginal.c_str( ) );
                    l_whereClause << " AND TB_ROTA.NUM_RTDR = " << numeroRoteadorOriginal;
                }
                if ( cartao.length() > 8)
                {
                    numeroSubBin = atol( cartao.substr(6,2).c_str() );
                }
            }
            else
            {
                if( strlen( l_track2.c_str() ) > 32 )
                {
                    l_num_rtdr = atol( l_track2.substr(31,2).c_str( ) );
                }
                if ( l_track2.length() > 8)
                {
                    numeroSubBin = atol( l_track2.substr(6,2).c_str() );
                }
            }
            
            l_whereClause << " ORDER BY TB_ROTA.NUM_RTDR DESC ";

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= DADOS UTILIZADOS NO ROTEAMENTO ==========" );
            char logDados[255] = {0};
            sprintf( logDados, "CATEGORY=[%s]RTDR=[%d]SUBBIN=[%d]PAN=[%s]TRACK2=[%s]",
                                categoria.c_str(), l_num_rtdr, numeroSubBin, cartao.c_str(), l_track2.c_str() );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, logDados );

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TrxVoucherRouting ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );

            dbaccess_pdv::RoutingVoucherTablesJoint l_Route( l_whereClause.str() );

            l_Route.prepare();
            l_Route.execute();
            int ret = l_Route.fetch();
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= SELECT DO VOUCHERROUTING NAO OBTEVE RESULTADO ==========" );
            }
            else
            {
                bool achei = false;

                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= SELECT DO VOUCHERROUTING OBTEVE RESULTADO ==========" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= #PARTIU ANALISAR O TIPO DE ROTEAMENTO ==========" );

                char logFetch[255] = {0};
                sprintf( logFetch, "FETCH --> TBSW0113.NUM_RTDR=[%d]", l_Route.get_NUM_RTDR( ) );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, logFetch );

                if( ( l_Route.get_NUM_RTDR( ) > 99 ) && ( l_Route.get_NUM_RTDR( ) < 300 ) )
                {
                    achei = true;
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= SELECT DO VOUCHERROUTING OBTEVE RESULTADO COM ROTEADOR ENTRE 100 e 299 ==========" );
                }
                else
                {
                    while ( !achei && ret )
                    {
                        if( ( ( l_Route.get_NUM_RTDR( ) < 100 ) && ( l_Route.get_NUM_RTDR( ) == l_num_rtdr ) ) ||
                            ( ( l_Route.get_NUM_RTDR( ) >= 300 ) && ( ( l_Route.get_NUM_RTDR( ) % 100 ) == numeroSubBin ) ) )
                        {
                            achei = true;

                            if( l_Route.get_NUM_RTDR( ) < 100 )
                            {
                                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= SELECT DO VOUCHERROUTING OBTEVE RESULTADO COM ROTEADOR < 100 ==========" );
                            }
                            else if ( l_Route.get_NUM_RTDR( ) >= 300 )
                            {
                                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= SELECT DO VOUCHERROUTING OBTEVE RESULTADO COM ROTEADOR >= 300 ==========" );
                            }
                        }
                        else
                        {
                            ret = l_Route.fetch();

                            char logFetch2[255] = {0};
                            sprintf( logFetch2, "FETCH --> TBSW0113.NUM_RTDR=[%d]", l_Route.get_NUM_RTDR( ) );
                            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, logFetch2 );
                        }
                    }
                }

                if( achei )
                {
                    fieldSet::fscopy( m_result, "OK", 2 );                           
                    fieldSet::fscopy( m_cod_sttu_reg, l_Route.get_COD_STTU_REG( ) );            
                    fieldSet::fscopy( m_num_rtdr, l_Route.get_NUM_RTDR( ) );
                    fieldSet::fscopy( m_cod_sbpd, l_Route.get_COD_SBPD( ) );
                    fieldSet::fscopy( m_cod_emsr, l_Route.get_COD_EMSR( ) );
                    fieldSet::fscopy( m_nom_emsr, l_Route.get_NOM_EMSR( ) );
                    fieldSet::fscopy( m_cod_tran_ge, l_Route.get_COD_TRAN_GE( ) );
                    fieldSet::fscopy( m_nom_prod_cpom, l_Route.get_NOM_PROD_CPOM( ) );
                    fieldSet::fscopy( m_txt_rdpe_cpom, l_Route.get_TXT_RDPE_CPOM( ) );
                    fieldSet::fscopy( m_cod_usr_atlz_reg, l_Route.get_COD_USR_ATLZ_REG( ) );
                    fieldSet::fscopy( m_dat_atlz_reg, l_Route.get_DAT_ATLZ_REG( ) );
                    fieldSet::fscopy( m_dat_atvc_voch, l_Route.get_DAT_ATVC_VOCH( ) );
                    fieldSet::fscopy( m_ntwkid, l_Route.get_NTWKID( ) );
                    fieldSet::fscopy( m_num_bin, l_Route.get_NUM_BIN( ) );

                    fieldSet::fscopy( m_cod_issr_sw, l_Route.get_COD_ISSR_SW( ) );
                    fieldSet::fscopy( m_nom_emsr_sw, l_Route.get_NOM_EMSR_SW( ) );
                    fieldSet::fscopy( m_cod_emsr_sw, l_Route.get_COD_EMSR_SW( ) );
                    fieldSet::fscopy( m_cod_bndr, l_Route.get_COD_BNDR( ) );
                    fieldSet::fscopy( m_cod_fe_emsr, l_Route.get_COD_FE_EMSR( ) );
                }
                else
                {
                    fieldSet::fscopy( m_result, "NO ROWS", 7 );
                    logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= SELECT DO VOUCHERROUTING OBTEVE RESULTADO, MAS NENHUM BATEU COM O ROTEADOR INFORMADO NA TRILHA/PAN ==========" );
                }
            }//else
        }//try
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TrxVoucherRouting <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TrxVoucherRouting <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }
    dataManip::Command* TrxVoucherRouting::clone( ) const
    {
        return new TrxVoucherRouting( *this );
    }
}//namespace plugins_pdv
