/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0045Updater>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TBSW0045Updater>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694451, Ricardo Deus>
/ Data de Criação: 
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ <Data, Módulo, Autor, Descrição da Mudança>
/ ---------------------------------------------------------------------------
*/

#pragma once

#include "plugins_pdv/TBSW0045Updater.hpp"
//TODOSW75 #include "dualHandler.hpp"

namespace plugins_pdv
{
  base::Identificable* createTBSW0045Updater( )
  {
    TBSW0045Updater* l_new = new TBSW0045Updater;
    return l_new;
  }

  TBSW0045Updater::TBSW0045Updater( )
  {
  }

  TBSW0045Updater::~TBSW0045Updater( )
  {
  }

  bool TBSW0045Updater::startConfiguration( const configBase::Tag* a_tag )
  {
    configBase::TagList l_tagList;

    a_tag->findTag( "sourceFieldPath", l_tagList );
    this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );

    a_tag->findTag( "targetFieldPath", l_tagList );
    this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

    return true;  
  }


  bool TBSW0045Updater::init( )
  {

    m_result = this->navigate( m_targetFieldPath + ".RESULT" );

	m_cod_term = this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
	m_num_stan = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
	
    return true;
  }

  void TBSW0045Updater::finish( )
  {
  }

  int TBSW0045Updater::execute( bool& a_stop )
  {
    try
    {
		std::ostringstream l_whereClause;
		
		std::string l_cod_term;
		long l_num_stan;
		
		fieldSet::fsextr( l_cod_term, m_cod_term );
		fieldSet::fsextr( l_num_stan, m_num_stan );
										
		l_whereClause << "COD_TERM = '" << l_cod_term << "' AND NUM_STAN = " << l_num_stan << " AND VAL_SIT_RVS = 0";
		dbaccess_common::TBSW0045 l_table0045( l_whereClause.str() );
		l_table0045.prepare_for_update();			
		l_table0045.execute();
        //TODOSW75 
        /***
		dbaccess_common::DualHandler l_dualHand( &l_table0045 );            
		if( l_dualHand.fetch( dbaccess::table::UPDATE ) )
        ***/
		if( l_table0045.fetch( ) )
		{
			do
			{
				l_table0045.let_QTD_CV_as_is();
				l_table0045.let_VAL_TOTL_LQDO_as_is();
				l_table0045.let_VAL_TOTL_DSCT_as_is();
				l_table0045.let_VAL_TOTL_GRJT_as_is();
				l_table0045.let_VAL_ENTR_as_is();
				l_table0045.let_VAL_TX_SERV_RVS_as_is();
				l_table0045.let_NUM_STAN_as_is();
				l_table0045.let_VAL_SQUE_as_is();
				l_table0045.let_VAL_PRES_BRTO_as_is();
				l_table0045.let_VAL_RMNR_RCD_as_is();
				l_table0045.let_VAL_IOF_as_is();
				l_table0045.let_VAL_CPMF_as_is();
				l_table0045.let_VAL_TAC_as_is();                
				l_table0045.set_VAL_SIT_RVS( 1 );
				l_table0045.update();
				
			//TODOSW75 } while ( l_dualHand.fetch( dbaccess::table::UPDATE ) );
			} while ( l_table0045.fetch( ) );
			l_table0045.commit();				
			fieldSet::fscopy( m_result, "OK", 2 );
		}
		else
		{				
			fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
		}
	}
    catch( base::GenException e )
    {
        fieldSet::fscopy( m_result, "ERROR", 5 );	  
        std::string l_msg = "Exception in TBSW0045Updater <" + std::string( e.what() ) + ">";
        this->enableError( true );
        this->setErrorMessage( l_msg );
    }
    catch( std::exception e )
    {
        fieldSet::fscopy( m_result, "ERROR", 5 );
        std::string l_msg = "Exception in TBSW0045Updater <" + std::string( e.what() ) + ">";
        this->enableError( true );
        this->setErrorMessage( l_msg );
    }
    a_stop = false;
    return 0;
  }

  TBSW0045Updater& TBSW0045Updater::setSourceFieldPath( const std::string& a_path )
  {
    m_sourceFieldPath = a_path;
    return *this;
  }
  TBSW0045Updater& TBSW0045Updater::setTargetFieldPath( const std::string& a_path )
  {
    m_targetFieldPath = a_path;
    return *this;
  }

  dataManip::Command* TBSW0045Updater::clone( ) const
  {
    return new TBSW0045Updater( *this );
  }
}//namespace standardAcqPlugins

