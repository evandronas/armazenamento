#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0160.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0160Inserter.hpp"
#include "msgConv/TextConv.hpp"

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "dbaccess_pdv/TBSW0160RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0160Inserter( )
    {
        TBSW0160Inserter* l_new = new TBSW0160Inserter;
        return( l_new );
    }

    TBSW0160Inserter::TBSW0160Inserter( )
    {
    }

    TBSW0160Inserter::~TBSW0160Inserter( )
    {
    }

    bool TBSW0160Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value( );
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        return( true );
    }

    bool TBSW0160Inserter::init( )
    {
        m_result             = this->navigate( m_targetFieldPath + ".RESULT" );
        m_local_date         = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_local_time         = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_refnum             = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_termid_type        = this->navigate( m_sourceFieldPath + ".segments.common.termid_type");
        m_txt_rlcd_chip      = this->navigate( m_sourceFieldPath + ".segments.chip.chip_full_data" );
        m_chip_full_data_len = this->navigate( m_sourceFieldPath + ".segments.chip.chip_full_data_len" );
        m_txt_info_cmpm_chip = this->navigate( m_sourceFieldPath + ".segments.chip.second_gen_ac" );
        m_txt_rstd_atlz_chip = this->navigate( m_sourceFieldPath + ".segments.chip.isr" );
        m_pin                = this->navigate( m_sourceFieldPath + ".shc_msg.pin" );
        m_ecr_cvm            = this->navigate( m_sourceFieldPath + ".segments.common.cvm_code" );
        m_msg_name           = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        m_iss_name           = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );

        numeroSequencialCartao = this->navigate( m_sourceFieldPath + ".segments.common.card_seqno" );

        return( true );
    }

    void TBSW0160Inserter::finish( )
    {
    }

    int TBSW0160Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_pdv::TBSW0160RegrasFormatacao regrasFormatacao;
            acq_common::tbsw0160_params tbsw0160_params = { 0 };
            dbaccess_common::TBSW0160 tbsw0160;

            fieldSet::fsextr( tbsw0160_params.local_date,         m_local_date );
            fieldSet::fsextr( tbsw0160_params.refnum,             m_refnum );
            fieldSet::fsextr( tbsw0160_params.termid_type,        m_termid_type );
			fieldSet::fsextr( tbsw0160_params.chip_full_data,     m_txt_rlcd_chip );
            fieldSet::fsextr( tbsw0160_params.chip_full_data_len, m_chip_full_data_len );
            fieldSet::fsextr( tbsw0160_params.second_gen_ac,      m_txt_info_cmpm_chip );
            fieldSet::fsextr( tbsw0160_params.isr,                m_txt_rstd_atlz_chip );
            fieldSet::fsextr( tbsw0160_params.pin,                m_pin );
            fieldSet::fsextr( tbsw0160_params.cvm_code,           m_ecr_cvm );
            fieldSet::fsextr( tbsw0160_params.msg_name,           m_msg_name);
            fieldSet::fsextr( tbsw0160_params.iss_name,           m_iss_name );

            fieldSet::fsextr( tbsw0160_params.numeroSequenciaCartaoChip, numeroSequencialCartao );

            regrasFormatacao.DAT_MOV_TRAN      ( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.NUM_SEQ_UNC       ( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.IND_RD_ORG        ( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.COD_PGM_AUT       ( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.TXT_RLCD_CHIP     ( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.TXT_INFO_CMPM_CHIP( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.TXT_RSTD_ATLZ_CHIP( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.IND_NVL_SGRA_KMRC ( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.IND_PRSC_SNHA     ( tbsw0160, tbsw0160_params, acq_common::INSERT );
            regrasFormatacao.IND_MTDO_VRFC_PORT( tbsw0160, tbsw0160_params, acq_common::INSERT );

            regrasFormatacao.NumeroSequencialCartaoValidacaoChip( tbsw0160, tbsw0160_params, acq_common::INSERT );

            tbsw0160.insert( );
            tbsw0160.commit( );
            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Gen Exception when inserting into table tbsw0160 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception when inserting into table tbsw0160 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return( 0 );
    }

    TBSW0160Inserter& TBSW0160Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    TBSW0160Inserter& TBSW0160Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    TBSW0160Inserter& TBSW0160Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0160Inserter::clone( ) const
    {
        return( new TBSW0160Inserter( *this ) );
    }

} //namespace plugins_pdv


