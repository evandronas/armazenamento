#pragma once
#include <cstring>
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbaccess_pdv/TBSW0152RegrasFormatacao.hpp"
#include "plugins_pdv/TBSW0152Loader.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0152Loader( )
    {
        TBSW0152Loader* l_new = new TBSW0152Loader;
        return l_new;
    }
    
    bool TBSW0152Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );
        return true;
    }
    
    TBSW0152Loader::TBSW0152Loader( )
    {
    }
    
    TBSW0152Loader::~TBSW0152Loader( )
    {
    }
    
    bool TBSW0152Loader::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        m_qtd_cicl_crnc_prmr_prcl = this->navigate( m_targetFieldPath + ".QTD_CICL_CRNC_PRMR_PRCL" );
        m_qtd_prcl = this->navigate( m_targetFieldPath + ".QTD_PRCL" );
        m_dat_vcto_prmr_prcl = this->navigate( m_targetFieldPath + ".DAT_VCTO_PRMR_PRCL" );
        m_val_prcl_entr = this->navigate( m_targetFieldPath + ".VAL_PRCL_ENTR" );
        m_val_prcl = this->navigate( m_targetFieldPath + ".VAL_PRCL" );
        m_prcn_tx_juro = this->navigate( m_targetFieldPath + ".PRCN_TX_JURO" );
        m_prcn_tx_juro_mes = this->navigate( m_targetFieldPath + ".PRCN_TX_JURO_MES" );
        m_prcn_tx_juro_ano = this->navigate( m_targetFieldPath + ".PRCN_TX_JURO_ANO" );
        m_prcn_tx_juro_mora = this->navigate( m_targetFieldPath + ".PRCN_TX_JURO_MORA" );
        m_val_pres_brto = this->navigate( m_targetFieldPath + ".VAL_PRES_BRTO" );
        m_val_tx_eftv = this->navigate( m_targetFieldPath + ".VAL_TX_EFTV" );
        m_val_tx_mnsl = this->navigate( m_targetFieldPath + ".VAL_TX_MNSL" );
        m_dat_mov_tran = this->navigate( m_targetFieldPath + ".DAT_MOV_TRAN" );
        m_num_seq_unc = this->navigate( m_targetFieldPath + ".NUM_SEQ_UNC" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date");
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum");
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );   
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );	
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_is_3a_perna = this->navigate( m_sourceFieldPath + ".segments.common.is_3a_perna" );

        return true;
    }

    void TBSW0152Loader::finish( )
    {
    }
    
    int TBSW0152Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_msgtype, l_local_date, l_origdate, l_refnum, l_origrefnum, l_origtrace;
            std::string l_is_3a_perna, l_origpan, l_termid;
            
            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );
            fieldSet::fsextr( l_msgtype, m_msgtype );                    
            fieldSet::fsextr( l_origrefnum, m_origrefnum );
            fieldSet::fsextr( l_origdate, m_origdate );
            fieldSet::fsextr( l_is_3a_perna, m_is_3a_perna );

            if ( !l_is_3a_perna.compare("Y") )
            {
                l_whereClause << "DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
            }
            else
            {
                switch ( l_msgtype )
                {
                    case 100 :
                    case 200 :
                        l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
                        break;
                    
                    case 220 :
                    case 400 :
                    case 420 :
                        l_whereClause << "DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
                        break;
                    
                    default:
                        fieldSet::fscopy( m_result, "EMPTY QUERY", 11 );
                        a_stop = false;
                        return 0;
                        break;
                }
            }

            dbaccess_common::TBSW0152 l_table0152( l_whereClause.str() );

            l_table0152.prepare( );
            l_table0152.execute( );
            int ret = l_table0152.fetch( );

            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "OK", 2 );

                fieldSet::fscopy( m_dat_mov_tran, l_table0152.get_DAT_MOV_TRAN( ) );
                fieldSet::fscopy( m_qtd_cicl_crnc_prmr_prcl, l_table0152.get_QTD_CICL_CRNC_PRMR_PRCL( ) );
                fieldSet::fscopy( m_qtd_prcl, l_table0152.get_QTD_PRCL( ) );
                fieldSet::fscopy( m_dat_vcto_prmr_prcl, l_table0152.get_DAT_VCTO_PRMR_PRCL( ) );

                char l_bufferTemp[64];
                oasis_dec_t l_dec_temp;

                l_dec_temp = l_table0152.get_NUM_SEQ_UNC( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_seq_unc, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_VAL_PRCL_ENTR( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
                fieldSet::fscopy( m_val_prcl_entr, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_VAL_PRCL( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
                fieldSet::fscopy( m_val_prcl, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_PRCN_TX_JURO( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
                fieldSet::fscopy( m_prcn_tx_juro, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_PRCN_TX_JURO_MES( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
                fieldSet::fscopy( m_prcn_tx_juro_mes, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_PRCN_TX_JURO_ANO( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
                fieldSet::fscopy( m_prcn_tx_juro_ano, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_PRCN_TX_JURO_MORA( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
                fieldSet::fscopy( m_prcn_tx_juro_mora, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_VAL_PRES_BRTO( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
                fieldSet::fscopy( m_val_pres_brto, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_VAL_TX_EFTV( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 5 );
                fieldSet::fscopy( m_val_tx_eftv, std::string( l_bufferTemp ) );

                l_dec_temp = l_table0152.get_VAL_TX_MNSL( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 5 );
                fieldSet::fscopy( m_val_tx_mnsl, std::string( l_bufferTemp ) );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0152 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0152 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    TBSW0152Loader& TBSW0152Loader::setTargetFieldPath( const std::string& a_path )
    {
         m_targetFieldPath = a_path;
         return *this;
    }

    TBSW0152Loader& TBSW0152Loader::setSourceFieldPath( const std::string& a_path )
    {
         m_sourceFieldPath = a_path;
         return *this;
    }

    dataManip::Command* TBSW0152Loader::clone( ) const
    {
        return new TBSW0152Loader(*this);
    }

}//namespace plugins_pdv
