#pragma once
#include <cstring>
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW1039Loader.hpp"
#include "dbaccess_pdv/TBSW1039RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW1039Loader( )
    {
        TBSW1039Loader* l_new = new TBSW1039Loader;
        return l_new;
    }

    bool TBSW1039Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW1039Loader::TBSW1039Loader( )
    {
    }

    TBSW1039Loader::~TBSW1039Loader( )
    {
    }

    bool TBSW1039Loader::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_dat_mov_tran = this->navigate( m_targetFieldPath + ".DAT_MOV_TRAN" );
        m_num_seq_unc = this->navigate( m_targetFieldPath + ".NUM_SEQ_UNC" );
        m_cod_msg_iso_orgl = this->navigate( m_targetFieldPath + ".COD_MSG_ISO_ORGL" );
        m_dth_sttu_tran_orgl = this->navigate( m_targetFieldPath + ".DTH_STTU_TRAN_ORGL" );
        m_num_stan_orgl = this->navigate( m_targetFieldPath + ".NUM_STAN_ORGL" );
        m_cod_istt_acqr_orgl = this->navigate( m_targetFieldPath + ".COD_ISTT_ACQR_ORGL" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        
        return true;
    }

    void TBSW1039Loader::finish( )
    {
    }

    int TBSW1039Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_local_date, l_refnum;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );

            l_whereClause << "DAT_MOV_TRAN = " << l_local_date;
            l_whereClause << " AND NUM_SEQ_UNC = " << l_refnum;

            dbaccess_common::TBSW1039 l_TBSW1039( l_whereClause.str() );

            l_TBSW1039.prepare( );
            l_TBSW1039.execute( );
            int ret = l_TBSW1039.fetch( );

            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );

                fieldSet::fscopy( m_dat_mov_tran, l_TBSW1039.get_DAT_MOV_TRAN( ) );
                fieldSet::fscopy( m_cod_msg_iso_orgl, l_TBSW1039.get_COD_MSG_ISO_ORGL( ) );
                fieldSet::fscopy( m_dth_sttu_tran_orgl, l_TBSW1039.get_DTH_STTU_TRAN_ORGL( ) );

                char l_bufferTemp[64];
                oasis_dec_t l_dec_temp;

                l_dec_temp = l_TBSW1039.get_NUM_SEQ_UNC( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_seq_unc, std::string( l_bufferTemp ) );

                l_dec_temp = l_TBSW1039.get_NUM_STAN_ORGL( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_stan_orgl, std::string( l_bufferTemp ) );

                l_dec_temp = l_TBSW1039.get_COD_ISTT_ACQR_ORGL( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_cod_istt_acqr_orgl, std::string( l_bufferTemp ) );

            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0084 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0084 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    TBSW1039Loader& TBSW1039Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW1039Loader& TBSW1039Loader::setSourceFieldPath( const std::string& a_path )
    {
          m_sourceFieldPath = a_path;
          return *this;
    }

    dataManip::Command* TBSW1039Loader::clone() const
    {
        return new TBSW1039Loader(*this);
    }
}//namespace plugins_pdv
