/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/Tbsw0102Loader.hpp"
#include "dbaccess_pdv/Tbsw0102RegrasFormatacao.hpp"

namespace plugins_pdv
{
base::Identificable* createTbsw0102Loader()
{
    Tbsw0102Loader* objetoLocal = new Tbsw0102Loader;     
    return objetoLocal;
}

    Tbsw0102Loader::Tbsw0102Loader()
    {
    }

    Tbsw0102Loader::~Tbsw0102Loader()
    {
    }
  
    /// startConfiguration
    /// Prepara os parametros recebidos na chamada do plugin dentro do XML
    ///  sourceFieldPath: parametros para clausula WHERE 
    ///  targetFieldPath: parametros para receber as colunas resultantes do SELECT
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0102Loader::startConfiguration( const configBase::Tag* tagParametro )
    {
        configBase::TagList tagListLocal;

        tagParametro->findTag( "sourceFieldPath", tagListLocal );
        this->SetSourceFieldPath( tagListLocal.front().findProperty( "value" ).value() );

        tagParametro->findTag( "targetFieldPath", tagListLocal );
        this->SetTargetFieldPath( tagListLocal.front().findProperty( "value" ).value() );

        return true;    
    }
  
    /// init
    /// Prepara os parametros de entrada e saida
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0102Loader::init()
    {
        /// Preparando as variaveis para receber as colunas do SELECT
        result                         = this->navigate( targetFieldPath + ".RESULT" );
        dataMovimentoTransacao         = this->navigate( targetFieldPath + ".DAT_MOV_TRAN" );
        numeroSequencialUnico          = this->navigate( targetFieldPath + ".NUM_SEQ_UNC" );
        codigoNivelSegurancaToken      = this->navigate( targetFieldPath + ".COD_NVL_SGRA_TKN" );
        codigoReferenciaContaPagamento = this->navigate( targetFieldPath + ".COD_REF_CTA_PGMN" );

        /// Preparando as variaveis para os parametros da clausula WHERE
        localDateSource  = this->navigate( sourceFieldPath + ".shc_msg.local_date" );
        refnumSource     = this->navigate( sourceFieldPath + ".shc_msg.refnum" );
        msgtypeSource    = this->navigate( sourceFieldPath + ".shc_msg.msgtype" );
        origDateSource   = this->navigate( sourceFieldPath + ".shc_msg.origdate" );
        origRefnumSource = this->navigate( sourceFieldPath + ".segments.common.origrefnum" );

        
        return true;
    }

    void Tbsw0102Loader::finish()
    {
    }

    /// execute
    /// Efetua o select da TBSW0101, passando no where a 
    ///  DATA e REFNUM da transcao ou da original
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    int Tbsw0102Loader::execute( bool& stopParametro )
    {
        try
        {
            std::ostringstream whereClauseLocal;
            unsigned long localDateLocal, origDateLocal,  msgtypeLocal, refnumLocal, origRefnumLocal;

            /// Montando a clausula WHERE
            fieldSet::fsextr( localDateLocal, localDateSource );
            fieldSet::fsextr( refnumLocal, refnumSource );
            fieldSet::fsextr( msgtypeLocal, msgtypeSource );
            fieldSet::fsextr( origDateLocal, origDateSource );
            fieldSet::fsextr( origRefnumLocal, origRefnumSource );

            switch ( msgtypeLocal )
            {
                /// Montando a clausula WHERE com os dados da transacao atual
                case 100 :
                case 200 :
                    whereClauseLocal << "DAT_MOV_TRAN = " << localDateLocal << " AND NUM_SEQ_UNC = " << refnumLocal;
                    break;

                /// Montando a clausula WHERE com os dados da transacao original
                case 220 :
                case 400 :
                case 420 :
                    whereClauseLocal << "DAT_MOV_TRAN = " << origDateLocal << " AND NUM_SEQ_UNC = " << origRefnumLocal;
                    break;
                default:
                    fieldSet::fscopy( result, "EMPTY QUERY", 11 );
                    stopParametro = false;
                    return 0;
                    break;
            }

            dbaccess_common::TBSW0102 tbsw0102Local( whereClauseLocal.str() );

            tbsw0102Local.prepare();
            tbsw0102Local.execute();
            int retornoLocal = tbsw0102Local.fetch();
            if( !retornoLocal )
            {
                /// Select não retornou registro
                fieldSet::fscopy( result, "NO ROWS", 7 );
            }
            else
            {
                /// Select retornou registo
                fieldSet::fscopy( result, "OK", 2 );

                fieldSet::fscopy( dataMovimentoTransacao        , tbsw0102Local.get_DAT_MOV_TRAN( ) );
                fieldSet::fscopy( numeroSequencialUnico         , tbsw0102Local.get_NUM_SEQ_UNC( ) );
                fieldSet::fscopy( codigoNivelSegurancaToken     , tbsw0102Local.get_COD_NVL_SGRA_TKN( ) );
                fieldSet::fscopy( codigoReferenciaContaPagamento, tbsw0102Local.get_COD_REF_CTA_PGMN( ) );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "Exception in TBSW0102 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "std::exception in TBSW0102 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        stopParametro = false;
        return 0;
    }

    /// SetSourceFieldPath
    /// Define Source FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0102Loader& Tbsw0102Loader::SetSourceFieldPath( const std::string& pathParametro )
    {
        sourceFieldPath = pathParametro;
        return *this;
    }

    /// SetTargetFieldPath
    /// Define Target FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0102Loader& Tbsw0102Loader::SetTargetFieldPath( const std::string& pathParametro )
    {
        targetFieldPath = pathParametro;
        return *this;
    }

    dataManip::Command* Tbsw0102Loader::clone() const
    {
        return new Tbsw0102Loader(*this);
    }

} // namespace plugins_pdv

