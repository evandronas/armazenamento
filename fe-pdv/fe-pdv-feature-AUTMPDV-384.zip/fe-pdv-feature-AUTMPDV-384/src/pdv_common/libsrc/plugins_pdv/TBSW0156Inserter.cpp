/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0156Inserter>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TBSW0156Inserter>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694451, Ricardo Deus>
/ Data de Criação: <Thur Apr 11 18:15:29 2013
>
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ . . .
/ <Data, Módulo, Autor, Descrição da Mudança>
/ ---------------------------------------------------------------------------
*/

#pragma once

#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0156Inserter.hpp"

//TODOSW75 
/***
dbm_datetime_t f_datetime( long a_data, long a_time )
{
    struct tm l_dattim;
    char l_szdate[20], l_sztime[20];
    std::string l_date, l_time;
    
    memset( &l_dattim, 0, sizeof( l_dattim ) );
    sprintf( l_szdate, "%08d", a_data );
    sprintf( l_sztime, "%06d", a_time );
    l_date = l_szdate;
    l_time = l_sztime;
    l_dattim.tm_sec = atoi( l_time.substr( 4, 2 ).c_str( ) );
    l_dattim.tm_min = atoi( l_time.substr( 2, 2 ).c_str( ) );
    l_dattim.tm_hour = atoi( l_time.substr( 0, 2 ).c_str( ) );
    l_dattim.tm_mday = atoi( l_date.substr( 6, 2 ).c_str( ) );
    l_dattim.tm_mon = atoi( l_date.substr( 4, 2 ).c_str( ) ) - 1;
    l_dattim.tm_year = atoi( l_date.substr( 0, 4 ).c_str( ) ) - 1900;
    l_dattim.tm_isdst = -1;
    
    return( mktime( &l_dattim ) );
}
***/

namespace plugins_pdv
{
  base::Identificable* createTBSW0156Inserter( )
  {
    TBSW0156Inserter* l_new = new TBSW0156Inserter;     
    return l_new;
  }
  
  TBSW0156Inserter::TBSW0156Inserter( )
  {
  }

  TBSW0156Inserter::~TBSW0156Inserter( )
  {
  } 

  dbm_datetime_t TBSW0156Inserter::f_datetime( long a_data, long a_time )
  {
      struct tm l_dattim;
      char l_szdate[20], l_sztime[20];
      std::string l_date, l_time;

      memset( &l_dattim, 0, sizeof( l_dattim ) );
      sprintf( l_szdate, "%08d", a_data );
      sprintf( l_sztime, "%06d", a_time );
      l_date = l_szdate;
      l_time = l_sztime;
      l_dattim.tm_sec = atoi( l_time.substr( 4, 2 ).c_str( ) );
      l_dattim.tm_min = atoi( l_time.substr( 2, 2 ).c_str( ) );
      l_dattim.tm_hour = atoi( l_time.substr( 0, 2 ).c_str( ) );
      l_dattim.tm_mday = atoi( l_date.substr( 6, 2 ).c_str( ) );
      l_dattim.tm_mon = atoi( l_date.substr( 4, 2 ).c_str( ) ) - 1;
      l_dattim.tm_year = atoi( l_date.substr( 0, 4 ).c_str( ) ) - 1900;
      l_dattim.tm_isdst = -1;

      return( mktime( &l_dattim ) );
  }

  bool TBSW0156Inserter::startConfiguration( const configBase::Tag* a_tag )
  {		
    configBase::TagList l_tagList;
    std::string l_source;

    a_tag->findTag( "sourceFieldPath", l_tagList );
  
    for ( unsigned int i = 0; i < l_tagList.size(); i++ )
    {	  
      l_source = l_tagList.at( i ).findProperty( "value" ).value();
	  
      if ( l_source == "target" )
      {
        this->setSourceFieldPath( l_source );
      }

      if ( l_source == "LOCAL" )
      {
        this->setLocalFieldPath( l_source );
      }
    }

    a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_target = l_tagList.front().findProperty( "value" ).value();
        this->setTargetFieldPath( l_target );

		return true;  
  }
  
  bool TBSW0156Inserter::init( )
  {	
    m_result = this->navigate( m_targetFieldPath + ".RESULT" );
	
	COD_TERM = this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
	NUM_STAN = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
	VERS_SFTW_TERM = this->navigate( m_sourceFieldPath + ".segments.adm.nmversion" );	
	COD_STTU_TERM = this->navigate(  m_sourceFieldPath + ".segments.adm.nmstatus" );                          
	QTD_MSG_RCBD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmmin" );                           
	QTD_MSG_ENVD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmmout" );
	
	//buf63
	//QTD_TRAN = this->navigate(  m_sourceFieldPath + ".segments.adm.nmstran" );      	
	
	QTD_NOVA_DSGM = this->navigate(  m_sourceFieldPath + ".segments.adm.nmredials" );
	QTD_ERR_COM = this->navigate(  m_sourceFieldPath + ".segments.adm.nmcerr" ); 	
	QTD_TMOT_TRAN = this->navigate(  m_sourceFieldPath + ".segments.adm.nmtout" );                          
	QTD_TMOT_RVRS = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrtout" );                          
	QTD_RTRM = this->navigate(  m_sourceFieldPath + ".segments.adm.nmretxc" );                              
	QTD_ERR_RCBM_MSG = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrxerr" );                       
	QTD_SNRM_RCBD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmsnrin" );                          
	QTD_SNRM_ENVD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmsnrout" );                          
	QTD_RNR_RCBD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrnrin" );                           
	QTD_RNR_ENVD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrnrout" );                           
	QTD_TST_RCBD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmtstin" );                           
	QTD_TST_ENVD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmtstout" );                           
	QTD_DM_RCBD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmdmin" );                            
	QTD_DM_ENVD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmdmout" );                            
	QTD_UAS_RCBD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmuain" );                           
	QTD_UAS_ENVD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmuaout" );                           
	QTD_FRME_RCBD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmfrmin" );                          
	QTD_FRME_ENVD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmfrmout" ); 
	CONT_TMPO_RSPS = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspcnt" );                         
	LIM_TMPO_RSPS_1 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspb1" );                        
	LIM_TMPO_RSPS_2 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspb2" );                        
	LIM_TMPO_RSPS_3 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspb3" );                        
	LIM_TMPO_RSPS_4 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspb4" );                        
	CONT_TMPO_RSPS_1 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspc1" );                       
	CONT_TMPO_RSPS_2 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspc2" );                       
	CONT_TMPO_RSPS_3 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspc3" );                       
	CONT_TMPO_RSPS_4 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmrspc4" ); 
	QTD_MIN_ATVD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmuptime" );                           
	QTD_MIN_INTD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmdntime" );                           
	
	//bit63
	//QTD_REINCZ = this->navigate(  m_sourceFieldPath + ".segments.adm." );                             
	
	//swmsg.bit63
	//QTD_ERR_ENT = this->navigate(  m_sourceFieldPath + ".segments.adm." );                            
	
	MODL_OPE_TERM = this->navigate(  m_sourceFieldPath + ".segments.adm.nmmode" );                          
	IND_TIP_ALRM = this->navigate(  m_sourceFieldPath + ".segments.adm.nmalarms" );                           
	QTD_TRAN_SCSO_NUM_PRMI = this->navigate(  m_sourceFieldPath + ".segments.adm.nmptran" );                 
	QTD_TRAN_SCSO_NUM_SECD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmstran" );                 
	QTD_NOVA_DSGM_SCSO_NUM_PRMI = this->navigate(  m_sourceFieldPath + ".segments.adm.nmpredial" );            
	QTD_NOVA_DSGM_SCSO_NUM_SECD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmsredial" );            
	QTD_ERR_LEIT_CAR = this->navigate(  m_sourceFieldPath + ".segments.adm.nmcrderr" );                       
	QTD_ERR_CNXO_HOST = this->navigate(  m_sourceFieldPath + ".segments.adm.nmlop" );                      
	QTD_TMPO_OFLN = this->navigate(  m_sourceFieldPath + ".segments.adm.nmoffl" );                          
	QTD_LEIT_MSR = this->navigate(  m_sourceFieldPath + ".segments.adm.nmcrdreads" );                           
	
	//aparentemente removido
	//CPO_RSVA_1 = this->navigate(  m_sourceFieldPath + ".segments.adm." );                             	
	
	VLCD_OPE_TERM = this->navigate(  m_sourceFieldPath + ".segments.adm.veloc_trn_primario" );                          
	QTD_TNTA_SECD_OCPD = this->navigate(  m_sourceFieldPath + ".segments.adm.veloc_trn_secundario" );                     
	PSSW = this->navigate(  m_sourceFieldPath + ".segments.adm.nmsepin" );                                   
	QTD_TNTA_PRMI_NAO_ATDD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmnap" );                 
	
	//buf63
	//OPC_TERM = this->navigate(  m_sourceFieldPath + ".segments.adm." );                               	
	
	//buf63
	//OPC_TERM_LOCL = this->navigate(  m_sourceFieldPath + ".segments.adm." ); 	
	
	CPO_RSVA_2 = this->navigate(  m_sourceFieldPath + ".segments.adm.nmresv" );                             
	IND_OPE_PNPD = this->navigate(  m_sourceFieldPath + ".segments.adm.nmpinpad" );                           
	QTD_LIN_IMPR = this->navigate(  m_sourceFieldPath + ".segments.adm.nmlinprnt" );                           
	
	//não encontrado no 7.1
	//CPCD_MMRA_TERM = this->navigate(  m_sourceFieldPath + ".segments.adm." );                         
	
	MODL_OPE_CMPH = this->navigate(  m_sourceFieldPath + ".segments.adm.nmmode" );                          
	QTD_FALLBACK = this->navigate(  m_sourceFieldPath + ".segments.adm.nfallback" );                           
	TIP_DSGM = this->navigate(  m_sourceFieldPath + ".segments.adm.tp_discagem" );                               
	TIP_CNXO = this->navigate(  m_sourceFieldPath + ".segments.adm.tp_conexao" );                               
                      
	NUM_TEL_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.fone_inic" );                           
	NUM_TEL_PRMI_TERM = this->navigate(  m_sourceFieldPath + ".segments.adm.fone_prim" );                      
	NUM_TEL_SECD_TERM = this->navigate(  m_sourceFieldPath + ".segments.adm.fone_secund" );                      
	TMPO_MDOI_CNXO = this->navigate(  m_sourceFieldPath + ".segments.adm.tmp_conexao" );                         
	TMPO_MDOI_OPE = this->navigate(  m_sourceFieldPath + ".segments.adm.tmp_operador" );                          
	TMPO_MDOI_TRAN = this->navigate(  m_sourceFieldPath + ".segments.adm.tmp_transacao" );                         
	QTD_ENTR_ERR_PIN = this->navigate(  m_sourceFieldPath + ".segments.adm.npinerro" );                       
	QTD_TRAN_CNCL_PSSW = this->navigate(  m_sourceFieldPath + ".segments.adm.ntrncanc" );                     
	QTD_CAR_BLQD_PSSW = this->navigate(  m_sourceFieldPath + ".segments.adm.ncrtbloq" );                      
	QTD_TRAN_OFLN = this->navigate(  m_sourceFieldPath + ".segments.adm.noffline" );                          
	IND_STTU_RPLC = this->navigate(  m_sourceFieldPath + ".segments.adm.cod_sttu_rplc" );                          
	
	//usa o BIT63
	/*
	QTD_CV_IMPR_PRMR_SGND_VIA = this->navigate(  m_sourceFieldPath + ".segments.adm. " );              
	QTD_CV_IMPR_PRMR_VIA = this->navigate(  m_sourceFieldPath + ".segments.adm. " );                   
	QTD_CV_IMPR_SGND_VIA = this->navigate(  m_sourceFieldPath + ".segments.adm. " );                   
	QTD_CV_NAO_IMPR = this->navigate(  m_sourceFieldPath + ".segments.adm. " );                        
	QTD_TRAN_DEB_MAGN_CHIP = this->navigate(  m_sourceFieldPath + ".segments.adm. " );                 
	IND_UTLZ_PABX = this->navigate(  m_sourceFieldPath + ".segments.adm." );   
	*/
	
	//TAG95 parser
	QTD_CNXO_TLCG_SCSO = this->navigate(  m_sourceFieldPath + ".segments.adm.cicttotok" );                     
	QTD_CNXO_INCZ_SCSO = this->navigate(  m_sourceFieldPath + ".segments.adm.ciittotok" );                     
	TMPO_CNXO_INCZ_SCSO = this->navigate(  m_sourceFieldPath + ".segments.adm.ciqttcok" );
	TMPO_CNXO_TLCG_SCSO = this->navigate(  m_sourceFieldPath + ".segments.adm.ciqtinok" );                    
	QTD_CNXO_PRBL_COM_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfcom" );                 
	QTD_CNXO_PRBL_COM_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfcom" );                 
	QTD_ERR_TMOT_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfto" );                      
	QTD_ERR_TMOT_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfto" );                      
	QTD_ERR_MAP_BIT_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfmi" );                   
	QTD_ERR_MAP_BIT_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfmi" );                   
	QTD_ERR_DA_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfid" );                        
	QTD_ERR_DA_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfid" );                        
	QTD_ERR_CNXO_PRDD_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtflc" );                 
	QTD_ERR_CNXO_PRDD_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtflc" );                 
	QTD_ERR_COM_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfce" );                       
	QTD_ERR_COM_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfce" ); 
	QTD_ERR_LIN_USO_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfluso" );                   
	QTD_ERR_LIN_USO_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfluso" );                   
	QTD_ERR_SEM_TOM_DSGM_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfstom" );              
	QTD_ERR_SEM_TOM_DSGM_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfstom" );             
	QTD_ERR_LIN_OCPD_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtflo" );                  
	QTD_ERR_LIN_OCPD_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtflo" );                  
	QTD_ERR_NAO_ATND_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfna" );                  
	QTD_ERR_NAO_ATND_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfna" );                  
	QTD_ERR_FLHA_ANXO_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtfat" );                
	QTD_ERR_FLHA_ANXO_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtfat" );                 
	QTD_ERR_FLHA_TCP_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciiqtftc" );                  
	QTD_ERR_FLHA_TCP_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cicqtftc" );                  
	TMPO_CNCT_TLCG = this->navigate(  m_sourceFieldPath + ".segments.adm.cictconec" );                         
	TMPO_CNCT_INCZ = this->navigate(  m_sourceFieldPath + ".segments.adm.ciitconec" );                        
	NUM_TEL_CRGA_RMT = this->navigate(  m_sourceFieldPath + ".segments.adm.cinumtel" );                       
	NUM_IP_CNFG = this->navigate(  m_sourceFieldPath + ".segments.adm.ciip" );
	
	
	m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
	m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
	
	
    return true;
  }

  void TBSW0156Inserter::finish( )
  {
  }

  int TBSW0156Inserter::execute( bool& a_stop )
  {	  
	try
    {
		std::string l_string = "";		
		unsigned long l_ulong;
		oasis_dec_t l_dect;
		
		//COD_TERM
		fieldSet::fsextr( l_string, COD_TERM );
		m_table0156.set_COD_TERM( l_string );
		
		//NUM_STAN
		fieldSet::fsextr( l_ulong, NUM_STAN );
		dbm_inttodec( &l_dect, l_ulong );
		m_table0156.set_NUM_STAN( l_dect );		
		
		//VERS_SFTW_TERM
		fieldSet::fsextr( l_string, VERS_SFTW_TERM );
		m_table0156.set_VERS_SFTW_TERM( l_string );
	
		//DTH_ESTT 
		unsigned long l_local_date, l_local_time;
    fieldSet::fsextr( l_local_date, m_local_date );
    fieldSet::fsextr( l_local_time, m_local_time );
    m_table0156.set_DTH_ESTT ( f_datetime( l_local_date, l_local_time ) );
		
		/*
		time_t ltt_currentTime = time( 0 );
		struct tm* lstm_currentDate = localtime( &ltt_currentTime );
		long ll_curDate_day = lstm_currentDate->tm_mday;
		long ll_curDate_mon = ( lstm_currentDate->tm_mon + 1 );
		long ll_curDate_year = ( lstm_currentDate->tm_year - 100 );
		long ll_curDate_hour = lstm_currentDate->tm_hour;
		long ll_curDate_min = lstm_currentDate->tm_min;
		long ll_curDate_sec = lstm_currentDate->tm_sec;

		std::stringstream sCurrentDate;
		std::stringstream sCurrentHour;

		long LDate;
		long LHour;
		
		sCurrentDate<<ll_curDate_day<<ll_curDate_mon<<ll_curDate_year;
		sCurrentHour<<ll_curDate_hour<<ll_curDate_min<<ll_curDate_sec;
		
		sCurrentDate>>LDate;
		sCurrentHour>>LHour;
		
		dbm_datetime_t trxDTH = f_datetime( LDate, LHour );
		m_table0156.set_DTH_ESTT( trxDTH );
		*/

		//COD_STTU_TERM
		fieldSet::fsextr( l_ulong, COD_STTU_TERM );
		m_table0156.set_COD_STTU_TERM( l_ulong );		
		
		//QTD_MSG_RCBD
		fieldSet::fsextr( l_ulong, QTD_MSG_RCBD );
		m_table0156.set_QTD_MSG_RCBD( l_ulong );		

		//QTD_MSG_ENVD
		fieldSet::fsextr( l_ulong, QTD_MSG_ENVD );
		m_table0156.set_QTD_MSG_ENVD( l_ulong );		
		
		//QTD_TRAN
		/*
		fieldSet::fsextr( l_ulong, QTD_TRAN );
		m_table0156.set_QTD_TRAN( l_ulong );		
		*/
		//QTD_NOVA_DSGM
		fieldSet::fsextr( l_ulong, QTD_NOVA_DSGM );
		m_table0156.set_QTD_NOVA_DSGM( l_ulong );		
		
		//QTD_ERR_COM
		fieldSet::fsextr( l_ulong, QTD_ERR_COM );
		m_table0156.set_QTD_ERR_COM( l_ulong );		
		
		//QTD_TMOT_TRAN
		fieldSet::fsextr( l_ulong, QTD_TMOT_TRAN );
		m_table0156.set_QTD_TMOT_TRAN( l_ulong );		

		//QTD_RTRM
		fieldSet::fsextr( l_ulong, QTD_RTRM );
		m_table0156.set_QTD_RTRM( l_ulong );		

		//QTD_ERR_RCBM_MSG
		fieldSet::fsextr( l_ulong, QTD_ERR_RCBM_MSG );
		m_table0156.set_QTD_ERR_RCBM_MSG( l_ulong );		

		//QTD_SNRM_RCBD
		fieldSet::fsextr( l_ulong, QTD_SNRM_RCBD );
		m_table0156.set_QTD_SNRM_RCBD( l_ulong );		

		//QTD_SNRM_ENVD
		fieldSet::fsextr( l_ulong, QTD_SNRM_ENVD );
		m_table0156.set_QTD_SNRM_ENVD( l_ulong );		

		//QTD_RNR_RCBD
		fieldSet::fsextr( l_ulong, QTD_RNR_RCBD );
		m_table0156.set_QTD_RNR_RCBD( l_ulong );		

		//QTD_RNR_ENVD
		fieldSet::fsextr( l_ulong, QTD_RNR_ENVD );
		m_table0156.set_QTD_RNR_ENVD( l_ulong );		

		//QTD_TST_RCBD
		fieldSet::fsextr( l_ulong, QTD_TST_RCBD );
		m_table0156.set_QTD_TST_RCBD( l_ulong );		

		//QTD_TST_ENVD
		fieldSet::fsextr( l_ulong, QTD_TST_ENVD );
		m_table0156.set_QTD_TST_ENVD( l_ulong );		

		//QTD_TST_ENVD
		fieldSet::fsextr( l_ulong, QTD_TST_ENVD );
		m_table0156.set_QTD_TST_ENVD( l_ulong );		

		//QTD_DM_RCBD
		fieldSet::fsextr( l_ulong, QTD_DM_RCBD );
		m_table0156.set_QTD_DM_RCBD( l_ulong );		

		//QTD_DM_ENVD
		fieldSet::fsextr( l_ulong, QTD_DM_ENVD );
		m_table0156.set_QTD_DM_ENVD( l_ulong );		

		//QTD_UAS_RCBD
		fieldSet::fsextr( l_ulong, QTD_UAS_RCBD );
		m_table0156.set_QTD_UAS_RCBD( l_ulong );		

		//QTD_UAS_ENVD
		fieldSet::fsextr( l_ulong, QTD_UAS_ENVD );
		m_table0156.set_QTD_UAS_ENVD( l_ulong );		

		//QTD_FRME_RCBD
		fieldSet::fsextr( l_ulong, QTD_FRME_RCBD );
		m_table0156.set_QTD_FRME_RCBD( l_ulong );		

		//QTD_FRME_ENVD
		fieldSet::fsextr( l_ulong, QTD_FRME_ENVD );
		m_table0156.set_QTD_FRME_ENVD( l_ulong );		

		//CONT_TMPO_RSPS
		fieldSet::fsextr( l_ulong, CONT_TMPO_RSPS );
		m_table0156.set_CONT_TMPO_RSPS( l_ulong );		

		//LIM_TMPO_RSPS_1
		fieldSet::fsextr( l_ulong, LIM_TMPO_RSPS_1 );
		m_table0156.set_CONT_TMPO_RSPS( l_ulong );		

		//LIM_TMPO_RSPS_2
		fieldSet::fsextr( l_ulong, LIM_TMPO_RSPS_2 );
		m_table0156.set_LIM_TMPO_RSPS_2( l_ulong );		

		//LIM_TMPO_RSPS_3
		fieldSet::fsextr( l_ulong, LIM_TMPO_RSPS_3 );
		m_table0156.set_LIM_TMPO_RSPS_3( l_ulong );		

		//LIM_TMPO_RSPS_4
		fieldSet::fsextr( l_ulong, LIM_TMPO_RSPS_4 );
		m_table0156.set_LIM_TMPO_RSPS_4( l_ulong );		

		//CONT_TMPO_RSPS_1
		fieldSet::fsextr( l_ulong, CONT_TMPO_RSPS_1 );
		m_table0156.set_CONT_TMPO_RSPS_1( l_ulong );		

		//CONT_TMPO_RSPS_2
		fieldSet::fsextr( l_ulong, CONT_TMPO_RSPS_2 );
		m_table0156.set_CONT_TMPO_RSPS_2( l_ulong );		

		//CONT_TMPO_RSPS_3
		fieldSet::fsextr( l_ulong, CONT_TMPO_RSPS_3 );
		m_table0156.set_CONT_TMPO_RSPS_3( l_ulong );		

		//CONT_TMPO_RSPS_4
		fieldSet::fsextr( l_ulong, CONT_TMPO_RSPS_4 );
		m_table0156.set_CONT_TMPO_RSPS_4( l_ulong );		

		//QTD_MIN_ATVD
		fieldSet::fsextr( l_ulong, QTD_MIN_ATVD );
		m_table0156.set_QTD_MIN_ATVD( l_ulong );		

		//QTD_MIN_INTD
		fieldSet::fsextr( l_ulong, QTD_MIN_INTD );
		m_table0156.set_QTD_MIN_INTD( l_ulong );		

		//QTD_REINCZ
		/*
		fieldSet::fsextr( l_ulong, QTD_REINCZ );
		m_table0156.set_QTD_REINCZ( l_ulong );		
		printf("\nTBSW0156Updater::execute: QTD_REINCZ: %d\n", l_ulong);
		*/

		//QTD_ERR_ENT
		/*
		fieldSet::fsextr( l_ulong, QTD_ERR_ENT );
		m_table0156.set_QTD_ERR_ENT( l_ulong );		
		printf("\nTBSW0156Updater::execute: QTD_ERR_ENT: %d\n", l_ulong);
		*/
		
		//MODL_OPE_TERM
		fieldSet::fsextr( l_string, MODL_OPE_TERM );
		m_table0156.set_MODL_OPE_TERM( l_string );

		//IND_TIP_ALRM
		fieldSet::fsextr( l_string, IND_TIP_ALRM );
		m_table0156.set_IND_TIP_ALRM( l_string );

		//QTD_TRAN_SCSO_NUM_PRMI
		fieldSet::fsextr( l_ulong, QTD_TRAN_SCSO_NUM_PRMI );
		m_table0156.set_QTD_TRAN_SCSO_NUM_PRMI( l_ulong );		

		//QTD_TRAN_SCSO_NUM_SECD
		fieldSet::fsextr( l_ulong, QTD_TRAN_SCSO_NUM_SECD );
		m_table0156.set_QTD_TRAN_SCSO_NUM_SECD( l_ulong );		
		
		//QTD_NOVA_DSGM_SCSO_NUM_PRMI
		fieldSet::fsextr( l_ulong, QTD_NOVA_DSGM_SCSO_NUM_PRMI );
		m_table0156.set_QTD_NOVA_DSGM_SCSO_NUM_PRMI( l_ulong );		

		//QTD_NOVA_DSGM_SCSO_NUM_SECD
		fieldSet::fsextr( l_ulong, QTD_NOVA_DSGM_SCSO_NUM_SECD );
		m_table0156.set_QTD_NOVA_DSGM_SCSO_NUM_SECD( l_ulong );		

		//QTD_ERR_LEIT_CAR
		fieldSet::fsextr( l_ulong, QTD_ERR_LEIT_CAR );
		m_table0156.set_QTD_ERR_LEIT_CAR( l_ulong );		

		//QTD_ERR_CNXO_HOST
		fieldSet::fsextr( l_ulong, QTD_ERR_CNXO_HOST );
		m_table0156.set_QTD_ERR_CNXO_HOST( l_ulong );		
		
		//QTD_TMPO_OFLN
		fieldSet::fsextr( l_ulong, QTD_TMPO_OFLN );
		m_table0156.set_QTD_TMPO_OFLN( l_ulong );		

		//QTD_LEIT_MSR
		fieldSet::fsextr( l_ulong, QTD_LEIT_MSR );
		m_table0156.set_QTD_LEIT_MSR( l_ulong );		

		//m_CPO_RSVA_1
		/*
		fieldSet::fsextr( l_string, m_CPO_RSVA_1 );
		m_table0156.set_m_CPO_RSVA_1( l_string );
		printf("\nTBSW0156Updater::execute: m_CPO_RSVA_1: %s\n", l_string.c_str());
		*/
		
		//VLCD_OPE_TERM
		fieldSet::fsextr( l_ulong, VLCD_OPE_TERM );
		m_table0156.set_VLCD_OPE_TERM( l_ulong );		

		//QTD_TNTA_SECD_OCPD
		/*
		fieldSet::fsextr( l_ulong, QTD_TNTA_SECD_OCPD );
		m_table0156.set_QTD_TNTA_SECD_OCPD( l_ulong );		
		printf("\nTBSW0156Updater::execute: QTD_TNTA_SECD_OCPD: %d\n", l_ulong);
		*/

		//PSSW
		fieldSet::fsextr( l_ulong, PSSW );
		m_table0156.set_PSSW( l_ulong );		

		//QTD_TNTA_PRMI_NAO_ATDD
		fieldSet::fsextr( l_ulong, QTD_TNTA_PRMI_NAO_ATDD );
		m_table0156.set_QTD_TNTA_PRMI_NAO_ATDD( l_ulong );		

		//OPC_TERM
		/*
		fieldSet::fsextr( l_string, OPC_TERM );
		m_table0156.set_OPC_TERM( l_string );
		printf("\nTBSW0156Updater::execute: OPC_TERM: %s\n", l_string.c_str());
		*/
		
		//OPC_TERM_LOCL
		/*
		fieldSet::fsextr( l_string, OPC_TERM_LOCL );
		m_table0156.set_OPC_TERM_LOCL( l_string );
		printf("\nTBSW0156Updater::execute: OPC_TERM_LOCL: %s\n", l_string.c_str());
		*/

		//CPO_RSVA_2
		fieldSet::fsextr( l_string, CPO_RSVA_2 );
		m_table0156.set_CPO_RSVA_2( l_string );

		//IND_OPE_PNPD
		fieldSet::fsextr( l_ulong, IND_OPE_PNPD );
		m_table0156.set_IND_OPE_PNPD( l_ulong );		
		
		//QTD_LIN_IMPR
		fieldSet::fsextr( l_ulong, QTD_LIN_IMPR );
		m_table0156.set_QTD_LIN_IMPR( l_ulong );		
		
		//CPCD_MMRA_TERM
		/*
		fieldSet::fsextr( l_ulong, CPCD_MMRA_TERM );
		m_table0156.set_CPCD_MMRA_TERM( l_ulong );		
		printf("\nTBSW0156Updater::execute: CPCD_MMRA_TERM: %d\n", l_ulong);
		*/
		
		//MODL_OPE_CMPH
		/*
		fieldSet::fsextr( l_ulong, MODL_OPE_CMPH );
		m_table0156.set_MODL_OPE_CMPH( l_ulong );		
		printf("\nTBSW0156Updater::execute: MODL_OPE_CMPH: %d\n", l_ulong);
		*/

		//QTD_FALLBACK
		fieldSet::fsextr( l_ulong, QTD_FALLBACK );
		m_table0156.set_QTD_FALLBACK( l_ulong );		
		
		//TIP_DSGM
		fieldSet::fsextr( l_string, TIP_DSGM );
		m_table0156.set_TIP_DSGM( l_string );

		//TIP_CNXO
		/*
		fieldSet::fsextr( l_string, TIP_CNXO );
		m_table0156.set_TIP_CNXO( l_string );
		printf("\nTBSW0156Updater::execute: TIP_CNXO: %s\n", l_string.c_str());
		*/	

		//IND_UTLZ_PABX
		//fieldSet::fsextr( l_string, IND_UTLZ_PABX );
		//m_table0156.set_IND_UTLZ_PABX( l_string );

		//NUM_TEL_INCZ
		fieldSet::fsextr( l_string, NUM_TEL_INCZ );
		m_table0156.set_NUM_TEL_INCZ( l_string );

		//NUM_TEL_PRMI_TERM
		fieldSet::fsextr( l_string, NUM_TEL_PRMI_TERM );
		m_table0156.set_NUM_TEL_PRMI_TERM( l_string );

		//NUM_TEL_SECD_TERM
		fieldSet::fsextr( l_string, NUM_TEL_SECD_TERM );
		m_table0156.set_NUM_TEL_SECD_TERM( l_string );

		//TMPO_MDOI_CNXO
		fieldSet::fsextr( l_ulong, TMPO_MDOI_CNXO );
		m_table0156.set_TMPO_MDOI_CNXO( l_ulong );		

		//TMPO_MDOI_OPE
		fieldSet::fsextr( l_ulong, TMPO_MDOI_OPE );
		m_table0156.set_TMPO_MDOI_OPE( l_ulong );		

		//TMPO_MDOI_TRAN
		fieldSet::fsextr( l_ulong, TMPO_MDOI_TRAN );
		m_table0156.set_TMPO_MDOI_TRAN( l_ulong );		

		//QTD_ENTR_ERR_PIN
		fieldSet::fsextr( l_ulong, QTD_ENTR_ERR_PIN );
		m_table0156.set_QTD_ENTR_ERR_PIN( l_ulong );		

		//QTD_TRAN_CNCL_PSSW
		fieldSet::fsextr( l_ulong, QTD_TRAN_CNCL_PSSW );
		m_table0156.set_QTD_TRAN_CNCL_PSSW( l_ulong );		

		//QTD_CAR_BLQD_PSSW
		fieldSet::fsextr( l_ulong, QTD_CAR_BLQD_PSSW );
		m_table0156.set_QTD_CAR_BLQD_PSSW( l_ulong );		

		//QTD_TRAN_OFLN
		fieldSet::fsextr( l_ulong, QTD_TRAN_OFLN );
		m_table0156.set_QTD_TRAN_OFLN( l_ulong );		

		//IND_STTU_RPLC
		fieldSet::fsextr( l_string, IND_STTU_RPLC );
		m_table0156.set_IND_STTU_RPLC( l_string );

		//QTD_CV_IMPR_PRMR_SGND_VIA
		/*
		fieldSet::fsextr( l_string, QTD_CV_IMPR_PRMR_SGND_VIA );
		m_table0156.set_QTD_CV_IMPR_PRMR_SGND_VIA( l_string );
		printf("\nTBSW0156Updater::execute: QTD_CV_IMPR_PRMR_SGND_VIA: %s\n", l_string.c_str());
		*/	

		//QTD_CV_IMPR_PRMR_VIA
		/*
		fieldSet::fsextr( l_string, QTD_CV_IMPR_PRMR_VIA );
		m_table0156.set_QTD_CV_IMPR_PRMR_VIA( l_string );
		printf("\nTBSW0156Updater::execute: QTD_CV_IMPR_PRMR_VIA: %s\n", l_string.c_str());
		*/	

		//QTD_CV_IMPR_SGND_VIA
		/*
		fieldSet::fsextr( l_string, QTD_CV_IMPR_SGND_VIA );
		m_table0156.set_QTD_CV_IMPR_SGND_VIA( l_string );
		printf("\nTBSW0156Updater::execute: QTD_CV_IMPR_SGND_VIA: %s\n", l_string.c_str());
		*/	

		//QTD_CV_NAO_IMPR
		/*
		fieldSet::fsextr( l_string, QTD_CV_NAO_IMPR );
		m_table0156.set_QTD_CV_NAO_IMPR( l_string );
		printf("\nTBSW0156Updater::execute: QTD_CV_NAO_IMPR: %s\n", l_string.c_str());
		*/	

		//QTD_TRAN_DEB_MAGN_CHIP
		/*
		fieldSet::fsextr( l_string, QTD_TRAN_DEB_MAGN_CHIP );
		m_table0156.set_QTD_TRAN_DEB_MAGN_CHIP( l_string );
		printf("\nTBSW0156Updater::execute: QTD_TRAN_DEB_MAGN_CHIP: %s\n", l_string.c_str());
		*/	

		//QTD_CNXO_TLCG_SCSO
		fieldSet::fsextr( l_ulong, QTD_CNXO_TLCG_SCSO );
		m_table0156.set_QTD_CNXO_TLCG_SCSO( l_ulong );

		//QTD_CNXO_INCZ_SCSO
		fieldSet::fsextr( l_ulong, QTD_CNXO_INCZ_SCSO );
		m_table0156.set_QTD_CNXO_INCZ_SCSO( l_ulong );

		//TMPO_CNXO_TLCG_SCSO
		fieldSet::fsextr( l_ulong, TMPO_CNXO_TLCG_SCSO );
		m_table0156.set_TMPO_CNXO_TLCG_SCSO( l_ulong );
		
		//TMPO_CNXO_INCZ_SCSO
		fieldSet::fsextr( l_ulong, TMPO_CNXO_INCZ_SCSO );
		m_table0156.set_TMPO_CNXO_INCZ_SCSO( l_ulong );

		//QTD_CNXO_PRBL_COM_INCZ
		fieldSet::fsextr( l_ulong, QTD_CNXO_PRBL_COM_INCZ );
		m_table0156.set_QTD_CNXO_PRBL_COM_INCZ( l_ulong );

		//QTD_CNXO_PRBL_COM_TLCG
		fieldSet::fsextr( l_ulong, QTD_CNXO_PRBL_COM_TLCG );
		m_table0156.set_QTD_CNXO_PRBL_COM_TLCG( l_ulong );

		//QTD_ERR_TMOT_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_TMOT_INCZ );
		m_table0156.set_QTD_ERR_TMOT_INCZ( l_ulong );

		//QTD_ERR_TMOT_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_TMOT_TLCG );
		m_table0156.set_QTD_ERR_TMOT_TLCG( l_ulong );

		//QTD_ERR_MAP_BIT_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_MAP_BIT_INCZ );
		m_table0156.set_QTD_ERR_MAP_BIT_INCZ( l_ulong );

		//QTD_ERR_MAP_BIT_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_MAP_BIT_TLCG );
		m_table0156.set_QTD_ERR_MAP_BIT_TLCG( l_ulong );

		//QTD_ERR_DA_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_DA_INCZ );
		m_table0156.set_QTD_ERR_DA_INCZ( l_ulong );

		//QTD_ERR_DA_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_DA_TLCG );
		m_table0156.set_QTD_ERR_DA_TLCG( l_ulong );

		//QTD_ERR_CNXO_PRDD_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_CNXO_PRDD_INCZ );
		m_table0156.set_QTD_ERR_CNXO_PRDD_INCZ( l_ulong );
		
		//QTD_ERR_CNXO_PRDD_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_CNXO_PRDD_TLCG );
		m_table0156.set_QTD_ERR_CNXO_PRDD_TLCG( l_ulong );

		//QTD_ERR_COM_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_COM_INCZ );
		m_table0156.set_QTD_ERR_COM_INCZ( l_ulong );

		//QTD_ERR_COM_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_COM_TLCG );
		m_table0156.set_QTD_ERR_COM_TLCG( l_ulong );

		//QTD_ERR_LIN_USO_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_LIN_USO_INCZ );
		m_table0156.set_QTD_ERR_LIN_USO_INCZ( l_ulong );

		//QTD_ERR_LIN_USO_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_LIN_USO_TLCG );
		m_table0156.set_QTD_ERR_LIN_USO_TLCG( l_ulong );

		//QTD_ERR_SEM_TOM_DSGM_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_SEM_TOM_DSGM_INCZ );
		m_table0156.set_QTD_ERR_SEM_TOM_DSGM_INCZ( l_ulong );

		//QTD_ERR_SEM_TOM_DSGM_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_SEM_TOM_DSGM_TLCG );
		m_table0156.set_QTD_ERR_SEM_TOM_DSGM_TLCG( l_ulong );

		//QTD_ERR_LIN_OCPD_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_LIN_OCPD_INCZ );
		m_table0156.set_QTD_ERR_LIN_OCPD_INCZ( l_ulong );

		//QTD_ERR_LIN_OCPD_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_LIN_OCPD_TLCG );
		m_table0156.set_QTD_ERR_LIN_OCPD_TLCG( l_ulong );

		//QTD_ERR_NAO_ATND_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_NAO_ATND_INCZ );
		m_table0156.set_QTD_ERR_NAO_ATND_INCZ( l_ulong );

		//QTD_ERR_NAO_ATND_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_NAO_ATND_TLCG );
		m_table0156.set_QTD_ERR_NAO_ATND_TLCG( l_ulong );

		//QTD_ERR_FLHA_ANXO_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_FLHA_ANXO_INCZ );
		m_table0156.set_QTD_ERR_FLHA_ANXO_INCZ( l_ulong );

		//QTD_ERR_FLHA_ANXO_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_FLHA_ANXO_TLCG );
		m_table0156.set_QTD_ERR_FLHA_ANXO_TLCG( l_ulong );

		//QTD_ERR_FLHA_TCP_INCZ
		fieldSet::fsextr( l_ulong, QTD_ERR_FLHA_TCP_INCZ );
		m_table0156.set_QTD_ERR_FLHA_TCP_INCZ( l_ulong );

		//QTD_ERR_FLHA_TCP_TLCG
		fieldSet::fsextr( l_ulong, QTD_ERR_FLHA_TCP_TLCG );
		m_table0156.set_QTD_ERR_FLHA_TCP_TLCG( l_ulong );

		//TMPO_CNCT_TLCG
		fieldSet::fsextr( l_ulong, TMPO_CNCT_TLCG );
		m_table0156.set_TMPO_CNCT_TLCG( l_ulong );
		
		//TMPO_CNCT_INCZ
		fieldSet::fsextr( l_ulong, TMPO_CNCT_INCZ );
		m_table0156.set_TMPO_CNCT_INCZ( l_ulong );

		//NUM_TEL_CRGA_RMT
		fieldSet::fsextr( l_ulong, NUM_TEL_CRGA_RMT );
		dbm_inttodec( &l_dect, l_ulong );
		m_table0156.set_NUM_TEL_CRGA_RMT( l_dect );		

		//NUM_IP_CNFG
		fieldSet::fsextr( l_ulong, NUM_IP_CNFG );
		dbm_inttodec( &l_dect, l_ulong );
		m_table0156.set_NUM_IP_CNFG( l_dect );		
		
		//NOM_SITE_ACQR_ORGL
		l_string = getenv( "NOM_SITE_ACQR" );
		m_table0156.set_NOM_SITE_ACQR_ORGL( l_string );
            
		//NOM_HOST_ACQR_ORGL
		l_string = getenv( "NOM_HOST_ACQR" );
		m_table0156.set_NOM_HOST_ACQR_ORGL( l_string );
            
		//NOM_FE_ACQR_ORGL
		l_string = getenv( "NOM_FE_ACQR" );
		m_table0156.set_NOM_FE_ACQR_ORGL( l_string );
			
		m_table0156.insert( );
		
		m_table0156.commit( );

		fieldSet::fscopy( m_result, "OK", 2 );
	}
	catch( base::GenException e )
    {
      fieldSet::fscopy( m_result, "ERROR", 5 );
      std::string l_msg = "Exception in TBSW0156 Inserter <" + std::string( e.what() ) + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }
    catch( std::exception e )
    {
      fieldSet::fscopy( m_result, "ERROR", 5 );
      std::string l_msg = "std::exception in TBSW0156 Inserter <" + std::string( e.what() ) + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }
	
    a_stop = false;
	
    return 0;
	
  }

  TBSW0156Inserter& TBSW0156Inserter::setSourceFieldPath( const std::string& a_path )
  {
    m_sourceFieldPath = a_path;
    return *this;
  }
  TBSW0156Inserter& TBSW0156Inserter::setTargetFieldPath( const std::string& a_path )
  {
    m_targetFieldPath = a_path;
    return *this;
  }
  TBSW0156Inserter& TBSW0156Inserter::setLocalFieldPath( const std::string& a_path )
  {
    m_localFieldPath = a_path;
    return *this;
  }

  dataManip::Command* TBSW0156Inserter::clone( ) const
  {
    return new TBSW0156Inserter( *this );
  }
}//namespace standardAcqPlugins
