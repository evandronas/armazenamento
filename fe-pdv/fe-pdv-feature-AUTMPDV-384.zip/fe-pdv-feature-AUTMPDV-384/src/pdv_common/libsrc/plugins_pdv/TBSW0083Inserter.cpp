/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0083Inserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0083Inserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, cken>
/ Data de Cria��o: <Fri Oct 26 15:21:52 2012
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <cctype>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0083.hpp"
#include "plugins_pdv/TBSW0083Inserter.hpp"
#include "dbaccess_pdv/TBSW0083RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0083Inserter()
    {
        TBSW0083Inserter* l_new = new TBSW0083Inserter;
        return l_new;
    }

    bool TBSW0083Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0083Inserter::TBSW0083Inserter()
    {
    }

    TBSW0083Inserter::~TBSW0083Inserter()
    {
    }

    bool TBSW0083Inserter::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_avs_cep = this->navigate( m_sourceFieldPath + ".segments.credit.avs_cep" );
        m_avs_end_fat = this->navigate( m_sourceFieldPath + ".segments.credit.avs_end_fat" );
        m_avs_end_num = this->navigate( m_sourceFieldPath + ".segments.credit.avs_end_num" );
        m_avs_end_com = this->navigate( m_sourceFieldPath + ".segments.credit.avs_end_com" );
        m_avs_cpf = this->navigate( m_sourceFieldPath + ".segments.credit.avs_cpf" );
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );

        return true;
    }

    void TBSW0083Inserter::finish()
    {
    
    }

    int TBSW0083Inserter::execute( bool& a_stop )
    {
        try
        { 
            dbaccess_pdv::TBSW0083RegrasFormatacao regrasFormatacao;
            dbaccess_common::TBSW0083 tbsw0083;
            acq_common::tbsw0083_params tbsw0083_params = { 0 };
            
            fieldSet::fsextr( tbsw0083_params.avs_cep,     m_avs_cep );
            fieldSet::fsextr( tbsw0083_params.avs_end_fat, m_avs_end_fat );
            fieldSet::fsextr( tbsw0083_params.avs_end_num, m_avs_end_num );
            fieldSet::fsextr( tbsw0083_params.avs_end_com, m_avs_end_com );
            fieldSet::fsextr( tbsw0083_params.avs_cpf,     m_avs_cpf );
            fieldSet::fsextr( tbsw0083_params.local_date,  m_local_date );
            fieldSet::fsextr( tbsw0083_params.refnum,      m_refnum );
            
            //COD_CEP_PORT                            CHAR(5) 
            regrasFormatacao.COD_CEP_PORT( tbsw0083, tbsw0083_params, acq_common::INSERT ); 
            
            //COD_CEP_CMPM_PORT                       CHAR(3) 
            regrasFormatacao.COD_CEP_CMPM_PORT( tbsw0083, tbsw0083_params, acq_common::INSERT ); 
            
            //TXT_ENDR_PORT                           CHAR(8)
            regrasFormatacao.TXT_ENDR_PORT( tbsw0083, tbsw0083_params, acq_common::INSERT ); 
            
            //NUM_CPF_PORT                            CHAR(11) 
            regrasFormatacao.NUM_CPF_PORT( tbsw0083, tbsw0083_params, acq_common::INSERT ); 
            
            //DAT_MOV_TRAN                   NOT NULL NUMBER(8)
            regrasFormatacao.DAT_MOV_TRAN( tbsw0083, tbsw0083_params, acq_common::INSERT ); 
            
            //NUM_SEQ_UNC                    NOT NULL NUMBER(12) 
            regrasFormatacao.NUM_SEQ_UNC( tbsw0083, tbsw0083_params, acq_common::INSERT ); 
            
            //COD_RSPS_AVS  somente updater...                          CHAR(1)        
            
            //TXT_CMPM_ENDR_PORT                      VARCHAR2(70)  
            regrasFormatacao.TXT_CMPM_ENDR_PORT( tbsw0083, tbsw0083_params, acq_common::INSERT );  
            
            //NUM_CNPJ_PORT  *MMS* existe no banco mas nao existe no BDCaptura...
    
            tbsw0083.insert( );
            tbsw0083.commit( );
    
            fieldSet::fscopy( m_result, "OK", 2 );
        }

    catch( base::GenException e )
    {
      fieldSet::fscopy( m_result, "ERROR", 5 );
      std::string l_what( e.what( ) );
      std::string l_msg = "Exception in TBSW0083 <" + l_what + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }
    catch( std::exception  e )
    {
      fieldSet::fscopy( m_result, "ERROR", 5 );
      std::string l_what( e.what( ) );
      std::string l_msg = "std::exception in TBSW0083 <" + l_what + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }

        a_stop = false;
        return 0;
    }

    TBSW0083Inserter& TBSW0083Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0083Inserter& TBSW0083Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0083Inserter::clone() const
    {
        return new TBSW0083Inserter(*this);
    }
}//namespace plugins_pdv

