#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "plugins_pdv/TBSW1039Updater.hpp"
#include "dbaccess_pdv/TBSW1039RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW1039Updater( )
    {
        TBSW1039Updater* l_new = new TBSW1039Updater;
        return l_new;
    }

    bool TBSW1039Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
                l_source = l_tagList.at( i ).findProperty( "value" ).value( );
                if ( l_source == "TBSW1039_DE48" )
                    this->setLocalFieldPath( l_source );
                else
                    this->setSourceFieldPath( l_source );
        }

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value();

        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW1039Updater::TBSW1039Updater( )
    {
    }

    TBSW1039Updater::~TBSW1039Updater( )
    {
    }

    bool TBSW1039Updater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_ecr_acqinst_id = this->navigate( m_sourceFieldPath + ".segments.common.ecr_acqinst_id" );
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_origtime = this->navigate( m_sourceFieldPath + ".shc_msg.origtime" );
        m_origtrace = this->navigate( m_sourceFieldPath + ".shc_msg.origtrace" );
        m_origpcode = this->navigate( m_sourceFieldPath + ".shc_msg.origpcode" );
        m_origmsg = this->navigate( m_sourceFieldPath + ".shc_msg.origmsg" );        

        return true;
    }

    void TBSW1039Updater::finish( )
    {
    }

    int TBSW1039Updater::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_local_date = 0;
            unsigned long l_refnum = 0;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );

            l_whereClause << "DAT_MOV_TRAN = " << l_local_date;
            l_whereClause << " AND NUM_SEQ_UNC = " << l_refnum;

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW1039 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );

            dbaccess_common::TBSW1039 l_table1039( l_whereClause.str( ) );
            dbaccess_pdv::TBSW1039RegrasFormatacao regrasFmt;
            struct acq_common::tbsw1039_params params = { 0 };

            l_table1039.prepare_for_update( );
            l_table1039.execute( );
            int ret = l_table1039.fetch( );

            if( !ret )
            {
                fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {
                fieldSet::fsextr( params.origpcode,         m_origpcode );
                fieldSet::fsextr( params.origtrace,         m_origtrace );
                fieldSet::fsextr( params.ecr_acqinst_id,    m_ecr_acqinst_id );
                fieldSet::fsextr( params.origdate,          m_origdate );
                fieldSet::fsextr( params.origtime,          m_origtime );
                fieldSet::fsextr( params.origmsg,           m_origmsg );
 
                regrasFmt.COD_MSG_ISO_ORGL  ( l_table1039, params, acq_common::UPDATE );
                regrasFmt.NUM_STAN_ORGL     ( l_table1039, params, acq_common::UPDATE );
                regrasFmt.DTH_STTU_TRAN_ORGL( l_table1039, params, acq_common::UPDATE );
                regrasFmt.COD_ISTT_ACQR_ORGL( l_table1039, params, acq_common::UPDATE );

                l_table1039.update( );
                l_table1039.commit( );

                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW1039 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW1039 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW1039Updater& TBSW1039Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW1039Updater& TBSW1039Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW1039Updater& TBSW1039Updater::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW1039Updater::clone( ) const
    {
        return new TBSW1039Updater(*this);
    }

} // namespace plugins_pdv
