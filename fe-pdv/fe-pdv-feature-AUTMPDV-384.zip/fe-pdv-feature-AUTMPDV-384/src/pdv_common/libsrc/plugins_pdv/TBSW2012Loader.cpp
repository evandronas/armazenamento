/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/


/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW2012Loader>
/ Descri��o: <Arquivo de implementacao da classe plugins_pdv::TBSW2012Loader>
/ Conte�do: <Lista de Modulos definidos>
/ Autor: <698224, Raphael Gomes>
/ Data de Cria��o: <Fri Apr 12 08:48:00 2013>
/ Historico Mudancas: <Data, Modulo, Autor, Descricao da Mudanca>
/ <Data, Modulo, Autor, Descricao da Mudanca>
/ ---------------------------------------------------------------------------
*/

#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW2012.hpp"
#include "plugins_pdv/TBSW2012Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW2012Loader( )
    {
        TBSW2012Loader* l_new = new TBSW2012Loader;
        return l_new;
    }
    bool TBSW2012Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
       
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
        
        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );
        
        return true;
    }
    TBSW2012Loader::TBSW2012Loader( )
    {
    }
    TBSW2012Loader::~TBSW2012Loader( )
    {
    }
    bool TBSW2012Loader::init( )
    {
		     m_result = this->navigate( m_targetFieldPath + ".RESULT" );		     
         
         m_cod_rota_admn = this->navigate( m_targetFieldPath + ".COD_ROTA_ADMN"); ;     
         m_cod_msg_iso = this->navigate( m_targetFieldPath + ".COD_MSG_ISO");  
         m_cod_pcm_iso = this->navigate( m_targetFieldPath + ".COD_PCM_ISO");  
         m_network_id = this->navigate( m_targetFieldPath + ".NETWORK_ID");   
         m_nom_host_acqr = this->navigate( m_targetFieldPath + ".NOM_HOST_ACQR");
         m_nom_fe_acqr = this->navigate( m_targetFieldPath + ".NOM_FE_ACQR");
         m_cod_issr_sw = this->navigate( m_targetFieldPath + ".COD_ISSR_SW");
				
				
				 m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
         m_pcode   = this->navigate( m_sourceFieldPath + ".shc_msg.pcode" );
         
         return true;
    }
    void TBSW2012Loader::finish( )
    {
    }
    int TBSW2012Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_msgtype, l_pcode;
            std::string l_nomHostAcqr, l_nomFeAcqr;
			
            fieldSet::fsextr( l_msgtype, m_msgtype );
            fieldSet::fsextr( l_pcode, m_pcode );
            
            l_nomHostAcqr = getenv( "NOM_HOST_ACQR" ); 
            l_nomFeAcqr = getenv( "NOM_FE_ACQR" );
            
            l_whereClause << "COD_MSG_ISO = " << l_msgtype << " AND COD_PCM_ISO = " << l_pcode
                    << " AND (NOM_HOST_ACQR = '" << l_nomHostAcqr << "' OR NOM_HOST_ACQR='*')" 
                    << " AND (NOM_FE_ACQR = '"   << l_nomFeAcqr   << "' OR NOM_FE_ACQR = '*')";
                    
                    
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW2012  ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );

            dbaccess_common::TBSW2012 l_table2012( l_whereClause.str( ) );
			
            l_table2012.prepare( );
            l_table2012.execute( );
            int ret = l_table2012.fetch( );
			
            if( !ret )
            {
              fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
              fieldSet::fscopy( m_result, "OK", 2 );
              fieldSet::fscopy( m_cod_rota_admn, l_table2012.get_COD_ROTA_ADMN( ) );
              fieldSet::fscopy( m_cod_msg_iso, l_table2012.get_COD_MSG_ISO( ) );
              fieldSet::fscopy( m_cod_pcm_iso, l_table2012.get_COD_PCM_ISO( ) );
              fieldSet::fscopy( m_network_id, l_table2012.get_NETWORK_ID( ) );
              fieldSet::fscopy( m_nom_host_acqr, l_table2012.get_NOM_HOST_ACQR( ) );
              fieldSet::fscopy( m_nom_fe_acqr, l_table2012.get_NOM_FE_ACQR( ) );
              fieldSet::fscopy( m_cod_issr_sw, l_table2012.get_COD_ISSR_SW( ) );
            }
        }
        catch( base::GenException e )
		    {
		    	fieldSet::fscopy( m_result, "ERROR", 5 );
		    	std::string l_what( e.what( ) );
		    	std::string l_msg = "Exception in TBSW2012 <" + l_what + ">";
		    	this->enableError( true );
		    	this->setErrorMessage( l_msg );
		    }
		    catch( std::exception  e )
		    {
		    	fieldSet::fscopy( m_result, "ERROR", 5 );
		    	std::string l_what( e.what( ) );
		    	std::string l_msg = "std::exception in TBSW2012 <" + l_what + ">";
		    	this->enableError( true );
		    	this->setErrorMessage( l_msg );
		    }
        a_stop = false;
        return 0;
    }
    TBSW2012Loader& TBSW2012Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
		    return *this;
    }
    TBSW2012Loader& TBSW2012Loader::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
		    return *this;
    }
    dataManip::Command* TBSW2012Loader::clone( ) const
    {
        return new TBSW2012Loader(*this);
    }
}//namespace plugins_pdv
