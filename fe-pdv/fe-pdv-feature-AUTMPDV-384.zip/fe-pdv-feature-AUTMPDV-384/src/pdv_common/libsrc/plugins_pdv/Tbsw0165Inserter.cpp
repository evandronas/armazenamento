/* Copyright 2019 Rede S.A.
Autor : Fernando Brum
Empresa : Rede
*/

#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "plugins_pdv/Tbsw0165Inserter.hpp"

using namespace std;

namespace plugins_pdv
{
    /// CreateTbsw0165Inserter
    /// Funcao de inicializacao do plugin
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    base::Identificable* createTbsw0165Inserter( )
    {
        Tbsw0165Inserter* novaClasse = new Tbsw0165Inserter;
        return novaClasse;
    }

    /// Tbsw0165Inserter
    /// Construtor da classe
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    Tbsw0165Inserter::Tbsw0165Inserter( )
    {
    }

    /// ~Tbsw0165Inserter
    /// Destrutor da classe
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    Tbsw0165Inserter::~Tbsw0165Inserter( )
    {
    }

    /// finish
    /// Finalizacao da execucao do objeto
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    void Tbsw0165Inserter::finish( )
    {
    }

    /// SetSourceFieldPath
    /// Atribui valor ao campo sourceFieldPath
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// valuePath: Valor a ser atribuido
    Tbsw0165Inserter& Tbsw0165Inserter::SetSourceFieldPath( const string& valuePath )
    {
        sourceFieldPath = valuePath;
        return *this;
    }

    /// SetTargetFieldPath
    /// Atribui valor ao campo targetFieldPath
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// valuePath: Valor a ser atribuido
    Tbsw0165Inserter& Tbsw0165Inserter::SetTargetFieldPath( const string& valuePath )
    {
        targetFieldPath = valuePath;
        return *this;
    }

    /// clone
    /// Efetua uma copia da classe
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    dataManip::Command* Tbsw0165Inserter::clone( ) const
    {
        return new Tbsw0165Inserter( *this );
    }

    /// startConfiguration
    /// Inicializacao do plugin
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// configTag: Tags da lista de xml
    bool Tbsw0165Inserter::startConfiguration( const configBase::Tag* configTag )
    {
        configBase::TagList localTagList;

        configTag->findTag( "sourceFieldPath", localTagList );
        this->SetSourceFieldPath( localTagList.front( ).findProperty( "value" ).value( ) );

        configTag->findTag( "targetFieldPath", localTagList );
        this->SetTargetFieldPath( localTagList.front( ).findProperty( "value" ).value( ) );

        return true;
    }

    /// init
    /// Incializacao do plugin
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    bool Tbsw0165Inserter::init( )
    {        
        result = this->navigate( string(targetFieldPath).append(".RESULT") ) ;
        
        dataMovimentoTransacao = this->navigate( string(sourceFieldPath).append(".shc_msg.local_date") ) ;
        numeroSequencialUnico = this->navigate( string(sourceFieldPath).append(".shc_msg.refnum") ) ;
        
        paymentFacilitator = this->navigate( string(sourceFieldPath).append(".segments.sublojista.paymentFacilitator") );
        codigoSubLojista = this->navigate( string(sourceFieldPath).append(".segments.sublojista.codigoSubLojista") );
        cnpjSubLojista = this->navigate( string(sourceFieldPath).append(".segments.sublojista.cnpjSubLojista") );
        enderecoSubLojista = this->navigate( string(sourceFieldPath).append(".segments.sublojista.enderecoSubLojista") );
        nomeSubLojista = this->navigate( string(sourceFieldPath).append(".segments.sublojista.nomeSubLojista") );
        cidadeSubLojista = this->navigate( string(sourceFieldPath).append(".segments.sublojista.cidadeSubLojista") );
        paisSubLojista = this->navigate( string(sourceFieldPath).append(".segments.sublojista.paisSubLojista") );
        cepSubLojista = this->navigate( string(sourceFieldPath).append(".segments.sublojista.cepSubLojista") );
        estadoSubLojista = this->navigate( string(sourceFieldPath).append(".segments.sublojista.estadoSubLojista") );
        
        return true;
    }

    /// execute
    /// Execucao do plugin
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// stopExecute: Fim da execucao do plugin
    int Tbsw0165Inserter::execute( bool& stopExecute )
    {
        try
        {
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= INSERTER TABELA TBSW0165 ==========" );
            
            unsigned long localDataMovimentoTransacao = 0;
            unsigned long localNumeroSequencialUnico = 0;
            string localPaymentFacilitator = "";
            string localCodigoSubLojista = "";
            string localCnpjSubLojista = "";
            string localEnderecoSubLojista = "";
            string localNomeSubLojista = "";
            string localCidadeSubLojista = "";
            string localPaisSubLojista = "";
            string localCepSubLojista = "";
            string localEstadoSubLojista = "";
            oasis_dec_t oasisDecAuxiliar;
            
            fieldSet::fsextr( localDataMovimentoTransacao, dataMovimentoTransacao );
            fieldSet::fsextr( localNumeroSequencialUnico, numeroSequencialUnico );
            fieldSet::fsextr( localPaymentFacilitator, paymentFacilitator );
            fieldSet::fsextr( localCodigoSubLojista, codigoSubLojista );
            fieldSet::fsextr( localCnpjSubLojista, cnpjSubLojista );
            fieldSet::fsextr( localEnderecoSubLojista, enderecoSubLojista );
            fieldSet::fsextr( localNomeSubLojista, nomeSubLojista );
            fieldSet::fsextr( localCidadeSubLojista, cidadeSubLojista );
            fieldSet::fsextr( localPaisSubLojista, paisSubLojista );
            fieldSet::fsextr( localCepSubLojista, cepSubLojista );
            fieldSet::fsextr( localEstadoSubLojista, estadoSubLojista );
            
            memberTable.clearFields();
            memberTable.SetDataMovimentoTransacao( localDataMovimentoTransacao );
            memberTable.SetNumeroSequencialUnico( localNumeroSequencialUnico );
            
            if ( localPaymentFacilitator.length( ) ) 
            {
                dbm_chartodec( &oasisDecAuxiliar, localPaymentFacilitator.c_str( ), 0 );
                memberTable.SetPaymentFacilitator( oasisDecAuxiliar );
            }
            
            if ( localCodigoSubLojista.length() )
            {
                memberTable.SetCodigoSubLojista( localCodigoSubLojista );
            }
            
            if ( localNomeSubLojista.length() )
            {
                memberTable.SetNomeSubLojista( localNomeSubLojista );
            }
            
            if ( localEnderecoSubLojista.length() )
            {
                memberTable.SetEnderecoSubLojista( localEnderecoSubLojista );
            }
            
            if ( localCidadeSubLojista.length() )
            {
                memberTable.SetCidadeSubLojista( localCidadeSubLojista );
            }
            
            if ( localEstadoSubLojista.length() )
            {
                memberTable.SetEstadoSubLojista( localEstadoSubLojista );
            }
            
            if ( localPaisSubLojista.length() )
            {
                memberTable.SetPaisSubLojista( localPaisSubLojista );
            }
            
            if ( localCepSubLojista.length() )
            {
                dbm_chartodec( &oasisDecAuxiliar, localCepSubLojista.c_str( ), 0 );
                memberTable.SetCepSubLojista( oasisDecAuxiliar );
            }
            
            if ( localCnpjSubLojista.length() )
            {
                dbm_chartodec( &oasisDecAuxiliar, localCnpjSubLojista.c_str( ), 0 );
                memberTable.SetCnpjSubLojista( oasisDecAuxiliar );
            }

            memberTable.insert();
            memberTable.commit();
            
            fieldSet::fscopy( result, string( "OK" ) );
        }
        catch( base::GenException errorException )
        {
            fieldSet::fscopy( result, string( "NOT INSERTED" ) );
            string localWhat( errorException.what( ) );
            string localErrorMessage = "Exception in TBSW0165 <";
            localErrorMessage.append(localWhat).append(">");
            this->enableError( true );
            this->setErrorMessage( localErrorMessage );
        }
        catch( exception  errorException )
        {
            fieldSet::fscopy( result, string( "NOT INSERTED" ) );
            string localWhat( errorException.what( ) );
            string localErrorMessage = "Exception in TBSW0165 [";
            localErrorMessage.append(localWhat).append("]");
            this->enableError( true );
            this->setErrorMessage( localErrorMessage );
        }

        stopExecute = false;
        return 0;
    }

} //namespace plugins_pdv
