/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0033Inserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0033Inserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>
/ Data de Cria��o: <2013, 18 de Janeiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ <28.11.2013, FEPDV, t694449, Padronizacao de Erro>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0033.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0033Inserter.hpp"

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "dbaccess_pdv/TBSW0033RegrasFormatacao.hpp"
    
namespace plugins_pdv
{
    base::Identificable* createTBSW0033Inserter()
    {
        TBSW0033Inserter* l_new = new TBSW0033Inserter;     
        return l_new;
    }
    
    TBSW0033Inserter::TBSW0033Inserter()
    {
    }
    
    TBSW0033Inserter::~TBSW0033Inserter()
    {
    }
    
    bool TBSW0033Inserter::startConfiguration( const configBase::Tag* a_tag )
    {            
        configBase::TagList l_tagList;
        std::string l_source;
    
        a_tag->findTag( "sourceFieldPath", l_tagList );    
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
                this->setLocalFieldPath( l_source );
            else
                this->setSourceFieldPath( l_source );
        }
    
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );
            
        return true;  
    }
  
    bool TBSW0033Inserter::init()
    {        
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        
        mensagemCategoria = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        nomeMensagem     = this->navigate( m_sourceFieldPath + ".segments.common.msg_name"     );
        
        m_nu_rv = this->navigate( m_sourceFieldPath + ".segments.common.nu_rv" );
        m_dt_rv = this->navigate( m_sourceFieldPath + ".segments.common.dt_rv" );
        
        //Campos TXT1
        trace     = this->navigate( m_sourceFieldPath + ".shc_msg.trace"      );
        mensagemOriginal   = this->navigate( m_sourceFieldPath + ".shc_msg.origmsg"   );
        traceOriginal = this->navigate( m_sourceFieldPath + ".shc_msg.origtrace" );
        dataOriginal  = this->navigate( m_sourceFieldPath + ".shc_msg.origdate"  );
        horaOriginal  = this->navigate( m_sourceFieldPath + ".shc_msg.origtime"  );
        dataLocalOriginal = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_date" );
        horaLocalOriginal = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_time" );
        nomeEmissor       = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        cartao            = this->navigate( m_sourceFieldPath + ".shc_msg.pan" );
        
        //Campos TXT2
        m_cd_tpo_trm     = this->navigate( m_sourceFieldPath + ".segments.merchant.cd_tpo_trm" );
        m_load_program   = this->navigate( m_sourceFieldPath + ".segments.merchant.load_program" );
        m_load_init      = this->navigate( m_sourceFieldPath + ".segments.merchant.load_init" );
        m_nu_age_etb     = this->navigate( m_sourceFieldPath + ".segments.merchant.nu_age_etb" );
        m_cd_cta_etb     = this->navigate( m_sourceFieldPath + ".segments.merchant.cd_cta_etb" );
        m_in_tpo_tcn     = this->navigate( m_sourceFieldPath + ".segments.merchant.in_tpo_tcn" );
        
        m_indUtlzPnpd = this->navigate( m_localFieldPath + ".IND_UTLZ_PNPD" );
        
        enderecoFantasia    = this->navigate( m_sourceFieldPath + ".segments.credit.avs_end_fat" );
        cpf        = this->navigate( m_sourceFieldPath + ".segments.credit.avs_cpf" );
        
        return true;
    }

    void TBSW0033Inserter::finish()
    {
    }

    int TBSW0033Inserter::execute( bool& a_stop )
    {
        try
        {            
            dbaccess_pdv::TBSW0033RegrasFormatacao regrasFormatacao;
            dbaccess_common::TBSW0033 tbsw0033;
            acq_common::tbsw0033_params tbsw0033_params = { 0 };        
    
            fieldSet::fsextr( tbsw0033_params.local_date,   m_local_date   );
            fieldSet::fsextr( tbsw0033_params.refnum,       m_refnum       );
            fieldSet::fsextr( tbsw0033_params.msg_category, mensagemCategoria );
            fieldSet::fsextr( tbsw0033_params.msg_name,     nomeMensagem     );
            
            fieldSet::fsextr( tbsw0033_params.nu_rv, m_nu_rv );
            fieldSet::fsextr( tbsw0033_params.dt_rv, m_dt_rv );
            
            // Infos para formatar TXT_MSG_1
            fieldSet::fsextr( tbsw0033_params.trace,     trace     );
            fieldSet::fsextr( tbsw0033_params.origmsg,   mensagemOriginal   );
            fieldSet::fsextr( tbsw0033_params.origtrace, traceOriginal );
            fieldSet::fsextr( tbsw0033_params.origdate,  dataOriginal  );
            fieldSet::fsextr( tbsw0033_params.origtime,  horaOriginal  );
            fieldSet::fsextr( tbsw0033_params.dataLocalOriginal, dataLocalOriginal );
            fieldSet::fsextr( tbsw0033_params.horaLocalOriginal, horaLocalOriginal );
            fieldSet::fsextr( tbsw0033_params.nomeEmissor,        nomeEmissor );
            fieldSet::fsextr( tbsw0033_params.cartao,             cartao );

            // Infos para formatar TXT_MSG_2
            fieldSet::fsextr( tbsw0033_params.cd_tpo_trm,   m_cd_tpo_trm   );
            fieldSet::fsextr( tbsw0033_params.in_tpo_tcn,   m_in_tpo_tcn   );
            fieldSet::fsextr( tbsw0033_params.indUtlzPnpd,  m_indUtlzPnpd  );
            fieldSet::fsextr( tbsw0033_params.load_init,    m_load_init    );
            fieldSet::fsextr( tbsw0033_params.load_program, m_load_program );
            fieldSet::fsextr( tbsw0033_params.nu_age_etb,   m_nu_age_etb   );
            fieldSet::fsextr( tbsw0033_params.cd_cta_etb,   m_cd_cta_etb   ); 
            
            fieldSet::fsextr( tbsw0033_params.enderecoFantasia,  enderecoFantasia  ); 
            fieldSet::fsextr( tbsw0033_params.cpf,      cpf      ); 
            
            //regrasFormatacao.NUM_CGC_CPF ( tbsw0033, tbsw0033_params, acq_common::INSERT ); //PDV null
            //regrasFormatacao.NUM_CHQ     ( tbsw0033, tbsw0033_params, acq_common::INSERT ); //PDV null
            //regrasFormatacao.TIP_DOC     ( tbsw0033, tbsw0033_params, acq_common::INSERT ); //PDV null
            //regrasFormatacao.DTH_CON_TRAN( tbsw0033, tbsw0033_params, acq_common::INSERT ); //Fixo Null
            
            regrasFormatacao.NUM_BCO_DEB ( tbsw0033, tbsw0033_params, acq_common::INSERT ); //Fixo 999
            regrasFormatacao.NUM_TEL     ( tbsw0033, tbsw0033_params, acq_common::INSERT ); //Fixo 0
            regrasFormatacao.DAT_MOV_TRAN( tbsw0033, tbsw0033_params, acq_common::INSERT );
            regrasFormatacao.NUM_SEQ_UNC ( tbsw0033, tbsw0033_params, acq_common::INSERT );
            regrasFormatacao.TXT_MSG_1   ( tbsw0033, tbsw0033_params, acq_common::INSERT );
            regrasFormatacao.TXT_MSG_2   ( tbsw0033, tbsw0033_params, acq_common::INSERT );
            
            tbsw0033.insert( );
            tbsw0033.commit( );
            
            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0033 [" + std::string( e.what() ) + "]";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0033 [" + std::string( e.what() ) + "]";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        
        a_stop = false;
        return 0;
    }

    TBSW0033Inserter& TBSW0033Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    
    TBSW0033Inserter& TBSW0033Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
    
    TBSW0033Inserter& TBSW0033Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }
    
    dataManip::Command* TBSW0033Inserter::clone() const
    {
        return new TBSW0033Inserter(*this);
    }
  
} //namespace standardAcqPlugins


