/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::Signon>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::Signon>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689068, Jos� Augusto T. Gavazza>
/ Data de Cria��o: <2013, 04 de Fevereiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o: EAK-1677 - Homologacao Logon
/ Autor: Renato de Camargo
/ Data : 11/09/2019
/ -------------------------------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <shcdef.h>
#include <stdio.h>
#include <stdlib.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/SeekInitFile.hpp"
#include "plugins_pdv/Signon.hpp"	

namespace plugins_pdv
{
  base::Identificable* createSignon( )
  {
    Signon* l_new = new Signon;     
    return l_new;
  }

  Signon::Signon()
  {
  }

  Signon::~Signon()
  {
  }
  
  bool Signon::startConfiguration( const configBase::Tag* a_tag )
  {
    configBase::TagList l_tagList;
    std::string l_source;

    a_tag->findTag( "sourceFieldPath", l_tagList );    
    for ( unsigned int i = 0; i < l_tagList.size(); i++ )
    {
		l_source = l_tagList.at( i ).findProperty( "value" ).value();
		if ( l_source == "SIGNON" )
			this->setSignonFieldPath( l_source );
		else
			this->setShcMsgFieldPath( l_source );
    }

    a_tag->findTag( "targetFieldPath", l_tagList );
    this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );
        
    return true;
  }
  
  bool Signon::init()
  {
    m_result = this->navigate( m_targetFieldPath + ".result" );

    if( !m_result )
		{
            std::string l_errorMsg( "Invalid field path <" + 
                                    m_targetFieldPath +
                                    ".result>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}    
	m_ecrInitDir = this->navigate( m_signonFieldPath + ".ecrInitDir" );
    if( !m_ecrInitDir )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_signonFieldPath +
                                    ".ecrInitDir>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
	m_ecrInitDirTmp = this->navigate( m_signonFieldPath + ".ecrInitDirTmp" );  

    if( !m_ecrInitDirTmp )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_signonFieldPath +
                                    ".ecrInitDirTmp>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}
	m_de48 = this->navigate( m_shcmsgFieldPath + ".segments.common.bit48" );
    if( !m_de48 )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".segments.common.bit48>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
    m_de48Len = this->navigate( m_shcmsgFieldPath + ".segments.common.bit48len" );
    if( !m_de48Len )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".segments.common.m_de48Len>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}                 
    m_termloc = this->navigate( m_shcmsgFieldPath + ".shc_msg.termloc" );
    if( !m_termloc )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".shc_msg.termloc>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
	m_termid = this->navigate( m_shcmsgFieldPath + ".shc_msg.termid" );
    if( !m_termid )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".shc_msg.termid>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
	m_verid = this->navigate( m_shcmsgFieldPath + ".segments.common.ecr_sftw_verid" );

    if( !m_verid )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".segments.common.ecr_sftw_verid>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}    
    return true;
  }

  void Signon::finish()
  {
  }

  int Signon::execute( bool& a_stop )
  {




	std::string l_de48;	
	fieldSet::fsextr( l_de48, m_de48 );	
	std::string l_de48Indicator = l_de48.substr(0,2);
	std::string l_currentVersion = l_de48.substr(2,10);

	SeekInitFile l_seekInitFile;

	if(l_de48.compare("") != 0 && l_de48Indicator.compare("LG") == 0)
	{
		char l_tmp[14];
		memset(l_tmp,0,14);
		sprintf(l_tmp, "%-13s", l_de48.c_str());
		l_de48 = l_tmp;



        
		std::string l_ecrInitDir, l_ecrInitDirTmp, l_verid, l_termid, l_termloc;		
		fieldSet::fsextr( l_ecrInitDir, m_ecrInitDir );
		fieldSet::fsextr( l_ecrInitDirTmp, m_ecrInitDirTmp );
		fieldSet::fsextr( l_verid, m_verid );
		fieldSet::fsextr( l_termid, m_termid );
		fieldSet::fsextr( l_termloc, m_termloc );

		if (l_seekInitFile.seekFile(l_ecrInitDir, l_ecrInitDirTmp, l_verid, l_termid, l_termloc) == 0)
		{
			std::ifstream l_file(l_seekInitFile.getCurrentInitInfoFileName().c_str());
			if( l_file.is_open() == 0 )
            {
				fieldSet::fscopy( m_result, "ERROR", 5 );
            }

			else
			{
				std::string l_line;
				//First record: '*VER*ddmmaaaass' identifying init table version
				std::string l_ddmmaaaass;
				do
				{
					std::getline(l_file, l_line);
					l_ddmmaaaass = l_line.substr(0, 16);

					if( l_ddmmaaaass.compare("") == 0)
					{
						l_file.close();
						fieldSet::fscopy( m_result, "ERROR", 5 );

						a_stop = false;
						return 0;
					}
					// Ignore comment line
					if(l_ddmmaaaass[0] == '#')
					{
						continue;
					}
				}
				while( !l_file.eof() && l_ddmmaaaass.compare(0, 5, "*VER*") != 0 );

				l_file.close();

				// Throw away '*VER*'
				l_ddmmaaaass = l_ddmmaaaass.substr(5, 10);

				// Check if the version in ECR is up-to-dated
				if(l_ddmmaaaass.compare(l_currentVersion) != 0)
				{
					l_de48[12] = 'S';
					
					fieldSet::fscopy( m_result, "YES", 3 );
				}
				else
				{
					l_de48[12] = 'N';     // Up-to-dated
					
					fieldSet::fscopy( m_result, "NO", 2 );
					
					std::string l_cmd = "rm -f ";
					l_cmd.append(l_seekInitFile.getCurrentInitInfoFileName());
					system (l_cmd.c_str());
				}
			}
		}
		else
		{
			l_de48[12] = 'N';
            
			fieldSet::fscopy( m_result, "NO", 2 );
			
			std::string l_cmd = "rm -f ";
			l_cmd.append(l_seekInitFile.getCurrentInitInfoFileName());
			system (l_cmd.c_str());
		}
   }



    fieldSet::fscopy( m_de48, l_de48);

    fieldSet::fscopy( m_de48Len, l_de48.length() );
    a_stop = false;
    return 0;
  }

  Signon& Signon::setShcMsgFieldPath( const std::string& a_path )
  {

    m_shcmsgFieldPath = a_path;
    return *this;
  }
  
  Signon& Signon::setTargetFieldPath( const std::string& a_path )
  {
    m_targetFieldPath = a_path;
    return *this;
  }
  
  Signon& Signon::setSignonFieldPath( const std::string& a_path )
  {
    m_signonFieldPath = a_path;
    return *this;
  }
  
  dataManip::Command* Signon::clone() const
  {
    return new Signon(*this);
  }
  
}//namespace plugins_pdv
