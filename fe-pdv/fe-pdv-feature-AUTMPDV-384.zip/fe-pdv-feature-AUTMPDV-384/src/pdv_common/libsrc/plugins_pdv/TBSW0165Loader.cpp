/* Copyright 2018 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "plugins_pdv/TBSW0165Loader.hpp"
//TODOSW75 #include "dualHandler.hpp"

using namespace std;

namespace plugins_pdv
{
    /// CreateTBSW0165Loader
    /// Funcao de inicializacao do plugin
    base::Identificable* CreateTBSW0165Loader( )
    {
        TBSW0165Loader* novaClasse = new TBSW0165Loader;
        return novaClasse;
    }

    /// TBSW0165Loader
    /// Construtor da classe
    TBSW0165Loader::TBSW0165Loader( )
    {
    }

    /// ~TBSW0165Loader
    /// Destrutor da classe
    TBSW0165Loader::~TBSW0165Loader( )
    {
    }

    /// finish
    /// Finalizacao da execucao do objeto
    void TBSW0165Loader::finish( )
    {
    }

    /// SetSourceFieldPath
    /// Atribui valor ao campo memberSourceFieldPath
    /// valuePath: Valor a ser atribuido
    TBSW0165Loader& TBSW0165Loader::SetSourceFieldPath( const string& valuePath )
    {
        memberSourceFieldPath = valuePath;
        return *this;
    }

    /// Tbsw0151
    /// Atribui valor ao campo memberTargetFieldPath
    /// valuePath: Valor a ser atribuido
    TBSW0165Loader& TBSW0165Loader::SetTargetFieldPath( const string& valuePath )
    {
        memberTargetFieldPath = valuePath;
        return *this;
    }

    /// clone
    /// Efetua uma copia da classe
    dataManip::Command* TBSW0165Loader::clone( ) const
    {
        return new TBSW0165Loader( *this );
    }

    /// startConfiguration
    /// Inicializacao do plugin
    /// configTag: Tags da lista de xml
    bool TBSW0165Loader::startConfiguration( const configBase::Tag* configTag )
    {
        configBase::TagList localTagList;

        configTag->findTag( "sourceFieldPath", localTagList );
        this->SetSourceFieldPath( localTagList.front( ).findProperty( "value" ).value( ) );

        configTag->findTag( "targetFieldPath", localTagList );
        this->SetTargetFieldPath( localTagList.front( ).findProperty( "value" ).value( ) );

        return true;
    }

    /// Tbsw0151
    /// Incializacao do plugin
    bool TBSW0165Loader::init( )
    {
        dataMovimentoTransacaoQuery = this->navigate( string(memberSourceFieldPath).append(".shc_msg.local_date") );
        numeroSequencialUnicoQuery = this->navigate( string(memberSourceFieldPath).append(".shc_msg.refnum") );
        dataMovimentoTransacaoOriginalQuery = this->navigate( string(memberSourceFieldPath).append(".shc_msg.origdate") ) ;
        numeroSequencialUnicoOriginalQuery = this->navigate( string(memberSourceFieldPath).append(".segments.common.origrefnum") ) ;
        codigoTipoMensagem = this->navigate( string(memberSourceFieldPath).append(".shc_msg.msgtype") );

        memberResult = this->navigate( string(memberTargetFieldPath).append(".RESULT") ) ;
        dataMovimentoTransacao = this->navigate( string(memberTargetFieldPath).append(".DAT_MOV_TRAN") ) ;
        numeroSequencialUnico = this->navigate( string(memberTargetFieldPath).append(".NUM_SEQ_UNC") ) ;
        paymentFacilitator = this->navigate( string(memberTargetFieldPath).append(".ID_FACR_PGMN_BNDR") );
        codigoSubLojista = this->navigate( string(memberTargetFieldPath).append(".COD_SMRC") );
        cnpjSubLojista = this->navigate( string(memberTargetFieldPath).append(".NUM_CNPJ_SMRC") );
        enderecoSubLojista = this->navigate( string(memberTargetFieldPath).append(".DES_ENDR_SMRC") );
        nomeSubLojista = this->navigate( string(memberTargetFieldPath).append(".NOM_SMRC") );
        cidadeSubLojista = this->navigate( string(memberTargetFieldPath).append(".NOM_CID_SMRC") );
        paisSubLojista = this->navigate( string(memberTargetFieldPath).append(".COD_PAIS_SMRC") );
        cepSubLojista = this->navigate( string(memberTargetFieldPath).append(".NUM_CEP_SMRC") );
        estadoSubLojista = this->navigate( string(memberTargetFieldPath).append(".SGL_EST_SMRC") );

        return true;
    }

    /// Tbsw0151
    /// Execucao do plugin
    /// stopExecute: Fim da execucao do plugin
    int TBSW0165Loader::execute( bool& stopExecute )
    {
        try
        {            

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= LOADER TABELA TBSW0165 ==========" );

            unsigned long localDataMovimentoTransacaoQuery = 0;
            unsigned long localNumeroSequencialUnicoQuery = 0;
            unsigned long localDataMovimentoTransacaoOriginalQuery = 0;
            unsigned long localNumeroSequencialUnicoOriginalQuery = 0;
            unsigned long localCodigoTipoMensagem = 0;
            
            ostringstream localWhereClause;

            fieldSet::fsextr( localDataMovimentoTransacaoQuery, dataMovimentoTransacaoQuery );
            fieldSet::fsextr( localNumeroSequencialUnicoQuery, numeroSequencialUnicoQuery );
            fieldSet::fsextr( localDataMovimentoTransacaoOriginalQuery, dataMovimentoTransacaoOriginalQuery );
            fieldSet::fsextr( localNumeroSequencialUnicoOriginalQuery, numeroSequencialUnicoOriginalQuery );
            fieldSet::fsextr( localCodigoTipoMensagem, codigoTipoMensagem );

            
            switch ( localCodigoTipoMensagem )
            {
                case 100:
                case 200:
                    localWhereClause << "DAT_MOV_TRAN = " << localDataMovimentoTransacaoQuery << " AND NUM_SEQ_UNC = " << localNumeroSequencialUnicoQuery;
                    break;

                case 220:
                case 400:
                case 420:
                    localWhereClause << "DAT_MOV_TRAN = " << localDataMovimentoTransacaoOriginalQuery << " AND NUM_SEQ_UNC = " << localNumeroSequencialUnicoOriginalQuery;
                    break;
                    
                default:
                    fieldSet::fscopy( memberResult, "EMPTY QUERY", 11 );
                    stopExecute = false;
                    return 0;
                    break;
            }

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, localWhereClause.str( ).c_str( ) );


            dbaccess_pdv::Tbsw0165 localTable( localWhereClause.str( ) );
            localTable.prepare( );
            localTable.execute( );

            //TODOSW75 
            /***
            dbaccess_common::DualHandler dualHandler( &localTable );
            if ( !dualHandler.fetch( ) )
            ***/
            if ( !localTable.fetch( ) )
            {
                fieldSet::fscopy( memberResult, string( "NO ROWS" ) );
            }
            else
            {
                fieldSet::fscopy( memberResult, string( "OK" ) );
                
                char localBufferAuxilidar[100] = {0};
                oasis_dec_t localOasisDecAuxiliar;

                fieldSet::fscopy( dataMovimentoTransacao, localTable.GetDataMovimentoTransacao() );
                fieldSet::fscopy( numeroSequencialUnico, localTable.GetNumeroSequencialUnico() );
                
                localOasisDecAuxiliar = localTable.GetPaymentFacilitator();
                if ( dbm_cmpzero(&localOasisDecAuxiliar) != 0 )
                {
                    memset( localBufferAuxilidar, 0, sizeof( localBufferAuxilidar ) );
                    dbm_dectochar_conv( &localOasisDecAuxiliar, localBufferAuxilidar, 0 );
                    fieldSet::fscopy( paymentFacilitator, string(localBufferAuxilidar) );
                }
                
                fieldSet::fscopy( codigoSubLojista, localTable.GetCodigoSubLojista() );
                fieldSet::fscopy( enderecoSubLojista, localTable.GetEnderecoSubLojista() );
                fieldSet::fscopy( nomeSubLojista, localTable.GetNomeSubLojista() );
                fieldSet::fscopy( cidadeSubLojista, localTable.GetCidadeSubLojista() );
                fieldSet::fscopy( estadoSubLojista, localTable.GetEstadoSubLojista() );
                fieldSet::fscopy( paisSubLojista, localTable.GetPaisSubLojista() );
                
                localOasisDecAuxiliar = localTable.GetCepSubLojista();
                if ( dbm_cmpzero(&localOasisDecAuxiliar) != 0 )
                {
                    memset( localBufferAuxilidar, 0, sizeof( localBufferAuxilidar ) );
                    dbm_dectochar_conv( &localOasisDecAuxiliar, localBufferAuxilidar, 0 );
                    fieldSet::fscopy( cepSubLojista, string(localBufferAuxilidar) );
                }

                if ( dbm_cmpzero(&localOasisDecAuxiliar) != 0 )
                {
                    localOasisDecAuxiliar = localTable.GetCnpjSubLojista();
                    memset( localBufferAuxilidar, 0, sizeof( localBufferAuxilidar ) );
                    dbm_dectochar_conv( &localOasisDecAuxiliar, localBufferAuxilidar, 0 );
                    fieldSet::fscopy( cnpjSubLojista, string(localBufferAuxilidar) );
                }
            }
        }
        catch( base::GenException errorException )
        {
            fieldSet::fscopy( memberResult, string( "ERROR" ) );
            string localWhat( errorException.what( ) );
            string localErrorMessage = "Exception in TBSW0165 <";
            localErrorMessage.append(localWhat).append(">");
            this->enableError( true );
            this->setErrorMessage( localErrorMessage );
        }
        catch( exception  errorException )
        {
            fieldSet::fscopy( memberResult, string( "ERROR" ) );
            string localWhat( errorException.what( ) );
            string localErrorMessage = "Exception in TBSW0165 [";
            localErrorMessage.append(localWhat).append("]");
            this->enableError( true );
            this->setErrorMessage( localErrorMessage );
        }

        stopExecute = false;
        return 0;
    }

}//namespace plugins_pdv
