#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0033.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0033Updater.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "dbaccess_pdv/TBSW0033RegrasFormatacao.hpp"
#include <defines.hpp>

namespace plugins_pdv
{
    base::Identificable* createTBSW0033Updater()
    {
        TBSW0033Updater* l_new = new TBSW0033Updater;
        return l_new;
    }

    TBSW0033Updater::TBSW0033Updater()
    {
    }

    TBSW0033Updater::~TBSW0033Updater()
    {
    }

    bool TBSW0033Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

        return true;
    }

    bool TBSW0033Updater::init()
    {
        m_result = this->navigate(m_targetFieldPath + ".RESULT");

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date"       );
        m_refnum     = this->navigate( m_sourceFieldPath + ".shc_msg.refnum"           );
        m_msg_name   = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        
        m_nu_rv = this->navigate( m_sourceFieldPath + ".segments.common.nu_rv" );
        m_dt_rv = this->navigate( m_sourceFieldPath + ".segments.common.dt_rv" );
        
        enderecoFantasia    = this->navigate( m_sourceFieldPath + ".segments.credit.avs_end_fat" );
        cpf                 = this->navigate( m_sourceFieldPath + ".segments.credit.avs_cpf" );
        respcode            = this->navigate( m_sourceFieldPath + ".segments.credit.avs_respcode" );

        codigoMembroBandeira    = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_ica" );
        nomeEmissor             = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );

        return true;
    }

    void TBSW0033Updater::finish()
    {
    }

    int TBSW0033Updater::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long  l_local_date,l_refnum;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );

            l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0033 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );

            dbaccess_common::TBSW0033 tbsw0033( l_whereClause.str() );
            tbsw0033.prepare_for_update();
            tbsw0033.execute();
            int ret = tbsw0033.fetch();
			
            if( !ret )
            {
              fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {
				tbsw0033.let_as_is( );

				acq_common::tbsw0033_params tbsw0033_params = { 0 };
				dbaccess_pdv::TBSW0033RegrasFormatacao regrasFormatacao;

                fieldSet::fsextr( tbsw0033_params.nu_rv,    m_nu_rv );
                fieldSet::fsextr( tbsw0033_params.dt_rv,    m_dt_rv );
                fieldSet::fsextr( tbsw0033_params.msg_name, m_msg_name );
                
                fieldSet::fsextr( tbsw0033_params.enderecoFantasia,  enderecoFantasia  ); 
                fieldSet::fsextr( tbsw0033_params.cpf,      cpf      ); 
                fieldSet::fsextr( tbsw0033_params.respcode, respcode ); 
            
                fieldSet::fsextr( tbsw0033_params.codigoMembroBandeira,  codigoMembroBandeira  );
                fieldSet::fsextr( tbsw0033_params.nomeEmissor,     nomeEmissor     );
            
                regrasFormatacao.NUM_RSMO_VD( tbsw0033, tbsw0033_params, acq_common::UPDATE );
                regrasFormatacao.DAT_RSMO_VD( tbsw0033, tbsw0033_params, acq_common::UPDATE );
                regrasFormatacao.TXT_MSG_1  ( tbsw0033, tbsw0033_params, acq_common::UPDATE );
                regrasFormatacao.TXT_MSG_2  ( tbsw0033, tbsw0033_params, acq_common::UPDATE );

				tbsw0033.update();
				tbsw0033.commit();
				fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0033 [" + std::string( e.what() ) + "]";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0033 [" + std::string( e.what() ) + "]";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    TBSW0033Updater& TBSW0033Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW0033Updater& TBSW0033Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0033Updater::clone() const
    {
        return new TBSW0033Updater(*this);
    }
}//namespace standardAcqPlugins

