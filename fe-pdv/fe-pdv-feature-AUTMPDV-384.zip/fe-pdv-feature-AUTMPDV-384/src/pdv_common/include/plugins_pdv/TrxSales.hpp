/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TRXSales>
/ Descrição: <Arquivo de declaracao da classe plugins_pdv::TRXSales>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694449, Fernando Ramires>
/ Data de Criação: <Mon Apr 29 08:48:00 2013>
/ Historico Mudancas: <11-05-13, TRX Sales, 694449, Versao Final>
/ ---------------------------------------------------------------------------
*/

#pragma once

#include <iostream>
#include <sstream>
#include <ctime>
#include "logger/LoggerGen.hpp"
#include "dataManip/Command.hpp"
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbaccess_pdv/SalesTablesJoint.hpp"
#include "TBSW0045.hpp"
#include "TBSW0051.hpp"

struct summ_lines
{
	char lc_line01[ 40 ];
	char lc_line02[ 40 ];
	char lc_line03[ 40 ];
	char lc_line04[ 40 ];
	char lc_line05[ 40 ];
	char lc_line06[ 40 ];
	char lc_line07[ 40 ];
	char lc_line08[ 40 ];
	char lc_line09[ 40 ];
	char lc_line10[ 40 ];
	char lc_line11[ 40 ];
	char lc_line12[ 40 ];
	char lc_line13[ 40 ];
	char lc_line14[ 40 ];
	char lc_line15[ 40 ];
	char lc_line16[ 40 ];
	char lc_line17[ 40 ];
	char lc_line18[ 40 ];
	char lc_line19[ 40 ];
	char lc_line20[ 40 ];
	char lc_line21[ 40 ];
    char lc_line22[ 40 ];
    char lc_line23[ 40 ];
    char lc_line24[ 40 ];
    char lc_line25[ 40 ];
    char lc_line26[ 40 ];
    char lc_line27[ 40 ];
    char lc_line28[ 40 ];
    char lc_line29[ 40 ];
    char lc_line30[ 40 ];
    char lc_line31[ 40 ];
    char lc_line32[ 40 ];
    char lc_line33[ 40 ];
};


namespace plugins_pdv
{
	extern "C" base::Identificable* createTrxSales( );
	
	class TrxSales : public dataManip::Command
    {
		public:
			TrxSales( );
            TrxSales( const std::string& str );
            virtual ~TrxSales( );
			dataManip::Command* clone( ) const;
			bool init( );
            void finish( );
            TrxSales& setTargetFieldPath( const std::string& a_path );
            TrxSales& setSourceFieldPath( const std::string& a_path );
			int execute( bool& a_stop );
		private:        
            bool startConfiguration( const configBase::Tag* a_tag );
            void padSummary( struct summ_lines* a_stSlSummary );
   			int  getElegivelRAV( const long a_clNumPdv );
			char getTerminalTechGroup( const long a_clInTpoTcn );
			long getNumRV( const long a_clNumPdv, 
						   const char a_ccTechGroup );
			int  getNumQBRA( const long a_clNumPdv, 
							 const char a_ccTechGroup );
			int  getMoreRecordsFlag( const long a_clNumPdv, 
									 const char a_ccTechGroup,
                                     const long a_clNumRv,
                                     const int numQuebra );
            int  prepareGetSalesSumm( const long a_clNumRv,
			     				      const int a_ciNumQbra,
									  const long a_clNumPdv, 
									  const std::string& a_csTermPdvId, 
									  const char a_ccTechGroup,
									  const long a_clTrace );	
			int  getSalesSumm( const long a_clNumPdv, 
							   const std::string& a_csTermPdvId, 
							   const long a_clRefnum, 
							   const std::string& a_csMerName, 
							   const long a_clInTpoTcn, 
							   const long a_clTrace);
            void fmtPdvSalesSummaryCredidlrIata( const long a_clNumPdv,
                                                 const long a_clRefnum, 
                                                 const std::string& a_csTermPdvId, 
                                                 const std::string& a_csMerName, 
                                                 struct summ_lines* a_stSlSummary, 
												 dbaccess_pdv::SalesTablesJoint* a_salesSumm ); 
            void fmtPdvSalesSummaryParcelemais( const long a_clRefnum, 
                                                const std::string& a_csTermPdvId,
                                                const std::string& a_csMerName,
                                                struct summ_lines* a_stSlSummary,
                                                dbaccess_pdv::SalesTablesJoint* a_salesSumm,
                                                const int a_clMoreRecordsFlag );
            void fmtPdvSalesSummaryPostDated( const long a_clRefnum, 
                                              const std::string& a_csTermPdvId,
                                              const std::string& a_csMerName, 
                                              struct summ_lines* a_stSlSummary, 
                                              dbaccess_pdv::SalesTablesJoint* a_salesSumm,
                                              const int a_clMoreRecordsFlag );
            void fmtPdvSalesSummaryGeneral( const long a_clRefnum, 
                                            const std::string& a_csTermPdvId, 
                                            const std::string& a_csMerName, 
                                            struct summ_lines* a_stSlSummary, 
                                            dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
                                            const int a_clMoreRecordsFlag );       
            void fmtPdvSalesSummaryNoRow( const std::string& a_csTermPdvId,
                                          const long a_clNumPdv,
                                          struct summ_lines* a_stSlSummary );                   
            int fmtSalesSummaryQtdPrcl( const long a_clNumPdv,
                                        const long a_clRefnum, 
                                        const std::string& a_csTermPdvId, 
                                        const std::string& a_csMerName,
                                        dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
                                        const int a_ciMoreRecordsFlag );
            void fmtPdvSalesSummaryInstallment( const long a_clRefnum, 
                                                const std::string& a_csTermPdvId, 
                                                const std::string& a_csMerName, 
												struct summ_lines* a_stSlSummary, 
												dbaccess_pdv::SalesTablesJoint* a_salesSumm );
            void doPdvLines( struct summ_lines* a_stSlSummary, 
						     dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
						     const int a_ciLinha );
            void doPdvLinesCredidlrIata( struct summ_lines* a_stSlSummary, 
                                         dbaccess_pdv::SalesTablesJoint* a_salesSumm, 
                                         const int a_ciLinha );          
										 
			std::string GetBrDecimalFormat( std::string usDecFormat );
			std::string m_sourceFieldPath;
			std::string m_targetFieldPath;			
			fieldSet::FieldAccess m_termloc;     
			fieldSet::FieldAccess m_termpdvid;
			fieldSet::FieldAccess m_refnum;
			fieldSet::FieldAccess m_merName;
			fieldSet::FieldAccess m_inTpoTcn; 
			fieldSet::FieldAccess m_trace;                    
			fieldSet::FieldAccess m_swmsgNuRv;
			fieldSet::FieldAccess m_swmsgDtRv;
			fieldSet::FieldAccess m_shcMsgAmount;
            fieldSet::FieldAccess m_shcMsgShiftNumber;
            fieldSet::FieldAccess m_shcMsgActualAmount;
			fieldSet::FieldAccess m_report;
			fieldSet::FieldAccess m_returnCode;
			fieldSet::FieldAccess m_result;
            //char m_buff63[ 640 ];
            char m_buff63[ 760 ];
    };
}//namespace plugins_pdv
