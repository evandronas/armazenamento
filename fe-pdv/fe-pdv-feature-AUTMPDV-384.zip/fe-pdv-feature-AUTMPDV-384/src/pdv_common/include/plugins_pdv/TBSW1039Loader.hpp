#pragma once
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"
#include "TBSW1039.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW1039Loader( );

    class TBSW1039Loader : public dataManip::Command
    {
    public:
        TBSW1039Loader( );
        TBSW1039Loader( const std::string& str );
        virtual ~TBSW1039Loader( );

        bool init( );
        void finish( );
        int execute( bool& a_stop );
        dataManip::Command* clone( ) const;

        std::string getStatus( void );
        TBSW1039Loader& setStatus( const std::string& a_status );

        TBSW1039Loader& setTargetFieldPath( const std::string& a_path );
        TBSW1039Loader& setSourceFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        std::string m_targetFieldPath;
        std::string m_sourceFieldPath;

        fieldSet::FieldAccess m_result;
        fieldSet::FieldAccess m_dat_mov_tran;
        fieldSet::FieldAccess m_num_seq_unc;
        fieldSet::FieldAccess m_cod_msg_iso_orgl;
        fieldSet::FieldAccess m_dth_sttu_tran_orgl;
        fieldSet::FieldAccess m_num_stan_orgl;
        fieldSet::FieldAccess m_cod_istt_acqr_orgl;

        fieldSet::ConstFieldAccess m_local_date;
        fieldSet::ConstFieldAccess m_refnum;
        
    };
}
