/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-WEB
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 06 de setembro
/ Hist�rico Mudan�as: 2012, 06 de setembro, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "logger/Logger.hpp"
namespace plugins_pdv
{
	extern "C" base::Identificable* createTraceTrx( );
	class TraceTrx : public dataManip::Command
	{
	public:
		TraceTrx( );
		virtual ~TraceTrx( );
		
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		logger::Logger* m_logger;
		
		pid_t m_pid;
		
		fieldSet::ConstFieldAccess m_msgType;
		fieldSet::ConstFieldAccess m_pcode;
		fieldSet::ConstFieldAccess m_terminal_pdv;
		fieldSet::ConstFieldAccess m_termloc;
		fieldSet::ConstFieldAccess m_amount;
		fieldSet::ConstFieldAccess m_transcode;
		fieldSet::ConstFieldAccess m_stanTerm;
		fieldSet::ConstFieldAccess m_stanIssuer;
		fieldSet::ConstFieldAccess m_pan;
		fieldSet::ConstFieldAccess m_posEntryCode;
		fieldSet::ConstFieldAccess m_azReasonCode;
		fieldSet::ConstFieldAccess m_portName;
		fieldSet::ConstFieldAccess m_direction;
        fieldSet::ConstFieldAccess m_issuer;
        fieldSet::ConstFieldAccess m_codMtvSw;
        fieldSet::ConstFieldAccess m_authNum;
		fieldSet::ConstFieldAccess m_origRefNum;
		
		std::string m_sourceFieldPath;
		std::string m_engineFieldPath;
		std::string m_portNamePath;
	};
}//namespace plugins_pdv
