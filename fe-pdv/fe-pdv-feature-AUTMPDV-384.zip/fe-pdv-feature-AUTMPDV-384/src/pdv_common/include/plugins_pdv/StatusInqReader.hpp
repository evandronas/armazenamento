/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -----------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2013, 1 de marco
/ Hist�rico Mudan�as: 2013, 1 de marco, t689066, Alexandre Teodoro 
                                                      Guimaraes, Versao Inicial
/ -----------------------------------------------------------------------------
*/

/*
*********************** MODIFICACOES ************************
Autor    : Joao Paulo F. Costa
Data     : 16/03/2021
Empresa  : Rede
Descricao: Falha no processo de Sonda
ID       : EAK-6005
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 26/04/2021
Empresa  : Rede
Descricao: Controle de CheckPoint
ID       : EAK-6544
*************************************************************
Autor    : Joao Paulo F. Costa
Data     : 28/04/2021
Empresa  : Rede
Descricao: Virada do dia
ID       : EAK-6550
*************************************************************
*/

#pragma once
#include "plugins_pdv/ProtomServer.hpp"
#include "dispatcher/Reader.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "TBSW0030.hpp"
#include "TBSW0121.hpp"
//TODOSW75 #include "TBSW0059.hpp"
#include "base/GenException.hpp"
#include "logger/Logger.hpp"
//TODOSW75 #include "contigencyHandler.hpp"

using namespace std;

namespace plugins_pdv
{
    extern "C" base::Identificable* createStatusInqReader();
    extern "C" long shc_local_currenttime();

    class StatusInqReader : public dispatcher::Reader
    {
        #define HISTORY_DAYS_RANGE      "statusinq.history_days_range"
        #define SEARCH_INTERVAL         "statusinq.search_interval"
        #define PENDING_WAITING_TIME    "statusinq.pending_waiting_time"
        #define ITERACTIONS_INTERVAL    "statusinq.iteractions_interval"
        #define TPS                     "statusinq.tps"
        #define ENABLE_REMOTE_QUERY     "statusinq.enable_remote_query"
        #define REMOTE_ACQR_HOST_NAME   "statusinq.remote_acqr_host_name"
		/* EAK-6544 - JPFC - Inicio */
        #define REPETE_ULTIMO           "statusinq.repete_ultimo"
        #define USA_CHECKPOINT          "statusinq.usa_checkpoint"
		#define CHECKPOINT_DATA_FOUND           1
		#define CHECKPOINT_FILE_NOTFOUND        2
		#define CHECKPOINT_DATA_NOTFOUND        3
		#define CHECKPOINT_FILE_WRITE_OPEN_FAIL 4
		#define CHECKPOINT_FILE_WRITE_FAIL      5
		#define CHECKPOINT_FILE_WRITE_OK        6
		#define CHECKPOINT_FILE_CLOSE_FAIL      7
		#define CHECKPOINT_FILE_CLOSE_OK        8
		#define CHECKPOINT_INVALID_DATA_FORMAT  9
		#define CHECKPOINT_BUFFER_LENGTH        24
		#define CHECKPOINT_FULL_FILE_PATH       "/PDV/cfg/statusinq_checkpoint"
		/* EAK-6544 - JPFC - Fim */

    public:
        StatusInqReader();
        virtual ~StatusInqReader();
        bool startConfiguration( const configBase::Tag* a_tag );
		bool open( ) ;
		void close( );
		bool fetch( ); 
        int getTps( );       
        int getNetMbid( short a_netcode );
		/* EAK-6550 - JPFC - Inicio */
        void getSecsFromMidnight( int& a_value );
		/* EAK-6550 - JPFC - Fim */
        bool checkContingency();
        void calculateQueryIntervals();
        void calculateFinalInterval();
		/* EAK-6544 - JPFC - Inicio */
		int getCheckPointData();
		int setCheckPointData();
		void getCurrentDate( long& currentDate );
		/* EAK-6544 - JPFC - Fim */

        StatusInqReader& setHistoryDaysRange( string& a_value );
        StatusInqReader& setSearchInterval( string& a_value );
        StatusInqReader& setPendingWaitingTime( string& a_value );
        StatusInqReader& setInteractions_Interval( string& a_value );                           
        StatusInqReader& setTps( string& a_value ); 

        StatusInqReader& setMsgHeaderSize( const char* a_value );

    private: 
        dbaccess_common::TBSW0030 m_TBSW0030;
        //TODOSW75 dbaccess_common::ContigencyHandler *m_cntHandler;
        logger::Logger* m_logger;
        configBase::ConfigBase* m_cfg;

        string m_historyDaysRange;
        string m_searchInterval;
        string m_pendingWaitingTime;
        string m_iteractions_interval;
        string m_tps;
        string m_enable_remote_query;
        string m_remote_acqr_host_name;
        string serverAliasId;
		/* EAK-6544 - JPFC - Inicio */
		string m_repeteUltimo;
		string m_usaCheckPoint;
		/* EAK-6544 - JPFC - Fim */

        unsigned int m_initInterval;
        unsigned int m_finalInterval;
        unsigned int m_auxDaysRange;
		unsigned int m_currentSec;
        /* JPFC - EAK-6005: Falha no processo de Sonda - Inicio */
        unsigned int m_globalDaysRange;
        /* JPFC - EAK-6005: Falha no processo de Sonda - Fim */

        bool m_firstRun;
        bool m_finalRange;
        bool m_stopExec;
        bool m_flagRemoteExec;
        bool m_flagSleep;
		/* EAK-6544 - JPFC - Inicio */
		bool m_isCheckPointData;
		bool m_isInicialization;
		/* EAK-6544 - JPFC - Fim */

        int m_acqsrvMbid;
		/* EAK-6544 - JPFC - Inicio */
		int m_checkPointDaysRange;
		int m_checkPointFinalInterval;
		/* EAK-6544 - JPFC - Fim */

        long int m_msgHeaderSize;
		/* EAK-6550 - JPFC - Inicio */
		long lastCurrentDate; /* Data de processmento do ultimo ciclo, long, no formato 'YYYYMMDD' */
		/* EAK-6550 - JPFC - Fim */

    };
}

