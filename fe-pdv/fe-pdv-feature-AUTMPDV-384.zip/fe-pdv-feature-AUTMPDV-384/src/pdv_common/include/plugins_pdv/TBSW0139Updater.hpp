#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "TBSW0139.hpp"
#include "dbaccess_pdv/TBSW0139RegrasFormatacao.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0139Updater( );

    class TBSW0139Updater : public dataManip::Command
    {
        public:
            TBSW0139Updater( );
            virtual ~TBSW0139Updater( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0139Updater& setTargetFieldPath( const std::string& a_path );
            TBSW0139Updater& setSourceFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_termid;
            fieldSet::ConstFieldAccess m_indCripto;
            fieldSet::ConstFieldAccess m_nom_site_issr;
            fieldSet::ConstFieldAccess m_nom_host_issr;
            fieldSet::ConstFieldAccess m_nom_fe_issr;
    }; // class TBSW0139Updater
} // namespace plugins_pdv
