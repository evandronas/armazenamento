#pragma once
#include "TBSW0153.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0153Inserter( );
    
    class TBSW0153Inserter : public dataManip::Command
    {
        public:
            TBSW0153Inserter( );
            virtual ~TBSW0153Inserter( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0153Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0153Inserter& setTargetFieldPath( const std::string& a_path );

            /// SetLocalFieldPath
            /// Cadastra caminho para tratativa de parametros
            /// EF/ET: 000
            /// Historico: 03/05/2018 - 000 - Implementacao inicial
            TBSW0153Inserter& SetLocalFieldPath( const std::string& pathParametro );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string localFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_cd_ems;
            fieldSet::ConstFieldAccess m_bin;
            fieldSet::ConstFieldAccess m_track2;
            fieldSet::ConstFieldAccess m_local_time;
            fieldSet::ConstFieldAccess m_ind_mot_aprov_chip;
            fieldSet::ConstFieldAccess m_iss_name;
            fieldSet::ConstFieldAccess m_cod_emsr;
            fieldSet::ConstFieldAccess numeroRoteamento;
            fieldSet::ConstFieldAccess valEftvAprv;
    }; // class TBSW0153Inserter
} // namespace plugins_pdv
