
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dbaccess_pdv/Tbsw0164.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* CreateTBSW0164Loader( );

    /// TBSW0164Loader
    /// Obtem registro da tabela TBSW0164
    class TBSW0164Loader : public dataManip::Command
    {
        public:
            TBSW0164Loader( );
            TBSW0164Loader( const std::string &stringValue );
            virtual ~TBSW0164Loader( );

            bool init( ); // metodo herdado da classe base
            void finish( );  // metodo herdado da classe base
            int execute( bool& stopExecute );  // metodo herdado da classe base
            dataManip::Command* clone( ) const;  // metodo herdado da classe base

            TBSW0164Loader& SetSourceFieldPath( const std::string& valuePath );
            TBSW0164Loader& SetTargetFieldPath( const std::string& valuePath );

        private:
            // metodo executado pela engine fwsw e herdado da classe base
            bool startConfiguration( const configBase::Tag* configTag );

            std::string memberSourceFieldPath;
            std::string memberTargetFieldPath;

            fieldSet::ConstFieldAccess dataMovimentoTransacaoQuery;
            fieldSet::ConstFieldAccess numeroSequencialUnicoQuery;
            fieldSet::ConstFieldAccess dataMovimentoTransacaoOriginalQuery;
            fieldSet::ConstFieldAccess numeroSequencialUnicoOriginalQuery;
            fieldSet::ConstFieldAccess codigoTipoMensagem;

            fieldSet::FieldAccess memberResult;
            fieldSet::FieldAccess dataMovimentoTransacao;
            fieldSet::FieldAccess numeroSequencialUnico;
            fieldSet::FieldAccess paymentFacilitator;
            fieldSet::FieldAccess codigoSubLojista;
            fieldSet::FieldAccess cnpjSubLojista;
            fieldSet::FieldAccess enderecoSubLojista;
            fieldSet::FieldAccess nomeSubLojista;
            fieldSet::FieldAccess cidadeSubLojista;
            fieldSet::FieldAccess paisSubLojista;
            fieldSet::FieldAccess cepSubLojista;
            fieldSet::FieldAccess estadoSubLojista;
            fieldSet::FieldAccess codigoRamoMcc;
    };
}
