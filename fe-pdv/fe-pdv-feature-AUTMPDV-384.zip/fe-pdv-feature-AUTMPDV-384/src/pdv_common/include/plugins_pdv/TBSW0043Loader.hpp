/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0043Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0043Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>
/ Data de Cria��o: <Thu Nov 01 09:26:32 2012>
/ ---------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/ConstFieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0043Loader( );
    class TBSW0043Loader : public dataManip::Command
    {
        public:
            TBSW0043Loader( );
            TBSW0043Loader( const std::string& str );
            virtual ~TBSW0043Loader( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            TBSW0043Loader& setResult( const std::string& a_result );
            TBSW0043Loader& setTargetFieldPath( const std::string& a_path );
            TBSW0043Loader& setSourceFieldPath( const std::string& a_path );
            std::string getResult( );
        private:
            bool startConfiguration( const configBase::Tag* a_tag );
            fieldSet::FieldAccess m_target_cod_term;
            fieldSet::FieldAccess m_target_cod_sttu_reg;
            fieldSet::FieldAccess m_target_dat_atlz_reg;
			fieldSet::FieldAccess m_target_cod_fun;			
			fieldSet::FieldAccess m_source_terminal_pdv;
            fieldSet::FieldAccess m_result;
            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
    };
}
