/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0045Updater>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TBSW0045Updater>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694451, Ricardo Deus>
/ Data de Criação: 
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ <Data, Módulo, Autor, Descrição da Mudança>
/ ---------------------------------------------------------------------------
*/

#pragma once

#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "TBSW0045.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"

namespace plugins_pdv
{
  extern "C" base::Identificable* createTBSW0045Updater( );

  class TBSW0045Updater : public dataManip::Command
  {
  public:
    TBSW0045Updater( );
    virtual ~TBSW0045Updater( );
    
    bool init( );
    void finish( );
    int execute( bool& a_stop );
    dataManip::Command* clone( ) const;
    
    TBSW0045Updater& setSourceFieldPath( const std::string& a_path );
    TBSW0045Updater& setTargetFieldPath( const std::string& a_path );

  private:
    bool startConfiguration( const configBase::Tag* a_tag );
	
    std::string m_sourceFieldPath;
    std::string m_targetFieldPath;
    
    fieldSet::FieldAccess m_result;   
	
    fieldSet::ConstFieldAccess m_cod_term;
	fieldSet::ConstFieldAccess m_num_stan;
  };
}
