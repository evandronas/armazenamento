#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0032Updater( );

    class TBSW0032Updater : public dataManip::Command
    {
        public:
            TBSW0032Updater( );
            virtual ~TBSW0032Updater( );
            
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            
            TBSW0032Updater& setSourceFieldPath( const std::string& a_path );
            TBSW0032Updater& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );
            
            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            
            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_iss_name;
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_origrefnum;
            fieldSet::ConstFieldAccess m_orig_local_date;
            fieldSet::ConstFieldAccess m_ind_car_mltp;
            fieldSet::ConstFieldAccess m_mc_info_prod_code;
            fieldSet::ConstFieldAccess m_trxTaxa;
            fieldSet::ConstFieldAccess m_vlTrfTxaMtc;
            fieldSet::ConstFieldAccess m_mc_info_cod_rvda_prod;
            fieldSet::ConstFieldAccess m_amount;
            fieldSet::ConstFieldAccess m_respcode;
			
			fieldSet::ConstFieldAccess m_status;
    };
}
