#pragma once
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"
#include "TBSW0139.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0139Loader();

    class TBSW0139Loader : public dataManip::Command
    {
        public:
            TBSW0139Loader();
            TBSW0139Loader( const std::string& str );
            virtual ~TBSW0139Loader();

            bool init();
            void finish();
            int execute( bool& a_stop );
            dataManip::Command* clone() const;

            std::string getStatus( void );
            TBSW0139Loader& setStatus( const std::string& a_status );

            TBSW0139Loader& setTargetFieldPath( const std::string& a_path );
            TBSW0139Loader& setSourceFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );
            std::string m_targetFieldPath;
            std::string m_sourceFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::FieldAccess m_target_cod_term; 
            fieldSet::FieldAccess m_target_num_pdv; 
            fieldSet::FieldAccess m_target_cod_pnpd_pdv;
            fieldSet::FieldAccess m_target_tip_cip;
            fieldSet::FieldAccess m_target_num_vers_srvd_pdv;
            fieldSet::FieldAccess m_target_cod_vers_sftw;
            fieldSet::FieldAccess m_target_num_vers_aplv_rcd;
            fieldSet::FieldAccess m_target_num_vers_sftw_bblt_pnpd;
            fieldSet::FieldAccess m_target_num_vers_espf_bblt_pnpd;
            fieldSet::FieldAccess m_target_cod_fbrc_pdv;
            fieldSet::FieldAccess m_target_dat_mov_tran; 

            fieldSet::FieldAccess m_source_local_date; 
            fieldSet::FieldAccess m_source_terminal_pdv; 
    };
}
