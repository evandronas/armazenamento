/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descrição:
/ Conteúdo:
/ Autor: t694530, Iuri Fabiano Martins
/ Data de Criação: 2013, 08 de Junho
/ Histórico Mudanças: 2013, 08 de Junho, t694530, Iuri Fabiano Martins, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "logger/LoggerGen.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createGetGMTDate( );
	class GetGMTDate : public dataManip::Command
	{
	public:
		GetGMTDate( );
		virtual ~GetGMTDate( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		GetGMTDate& setTargetFieldPath( const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_targetFieldDate;
		fieldSet::FieldAccess m_targetFieldTime;
		std::string m_targetFieldPath;
	};
}//namespace plugins_pdv

