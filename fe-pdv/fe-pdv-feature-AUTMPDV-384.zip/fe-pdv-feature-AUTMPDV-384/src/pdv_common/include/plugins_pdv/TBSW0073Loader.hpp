/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0073Loader( );
	class TBSW0073Loader : public dataManip::Command
	{
	public:
		enum tableFields
		{
			RESULT, COD_RAM_ATVD, COD_STTU_REG, QTD_DIA_PRZO_PRE_AUT, LAST_TB_FIELD
		};
		enum sourceFields
		{
			MER_CAT_CODE, LAST_SOURCE_FIELD
		};
		TBSW0073Loader( );
		TBSW0073Loader( const std::string& str );
		virtual ~TBSW0073Loader( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		std::string getResult( );
		TBSW0073Loader& setResult( const std::string& a_result );
		TBSW0073Loader& setTargetFieldPath( const std::string& a_path );
		TBSW0073Loader& setSourceFieldPath( const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_targetField[LAST_TB_FIELD];
		fieldSet::FieldAccess m_sourceField[LAST_SOURCE_FIELD];
		std::string m_targetFieldPath;
		std::string m_sourceFieldPath;
		std::string m_result;
	};
}

