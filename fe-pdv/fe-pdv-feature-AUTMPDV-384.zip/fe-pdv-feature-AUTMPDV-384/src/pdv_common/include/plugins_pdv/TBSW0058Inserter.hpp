#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0058Inserter( );
    
    class TBSW0058Inserter : public dataManip::Command
    {
        public:
        
            TBSW0058Inserter( );
            TBSW0058Inserter( const std::string &str );
            virtual ~TBSW0058Inserter( );
            
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            
            TBSW0058Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0058Inserter& setLocalFieldPath( const std::string& a_path );
            TBSW0058Inserter& setTargetFieldPath( const std::string& a_path );
            TBSW0058Inserter& setResult( const std::string& a_result );
            
            std::string getResult( );
            
        private:
            
            bool startConfiguration( const configBase::Tag* a_tag );
            
            fieldSet::ConstFieldAccess m_local_time       ;
            fieldSet::ConstFieldAccess m_local_date       ;
            fieldSet::ConstFieldAccess m_msgtype          ;
            fieldSet::ConstFieldAccess m_cd_ems           ;
            fieldSet::ConstFieldAccess m_amount           ;
            fieldSet::ConstFieldAccess m_acq_currency_code;
            fieldSet::ConstFieldAccess m_mer_cat_code     ;
            fieldSet::ConstFieldAccess m_orig_pan         ;
            fieldSet::ConstFieldAccess m_bin              ;
            fieldSet::ConstFieldAccess m_pcode            ;
            fieldSet::ConstFieldAccess m_refnum           ;
            fieldSet::ConstFieldAccess m_transcode        ;
            fieldSet::ConstFieldAccess m_pb_reason_code   ;
            fieldSet::ConstFieldAccess m_termloc          ;
            fieldSet::ConstFieldAccess m_pos_entry_code   ;
            fieldSet::ConstFieldAccess m_expiry_date      ;
            fieldSet::ConstFieldAccess m_trandate         ;
            fieldSet::ConstFieldAccess m_trantime         ;
            fieldSet::ConstFieldAccess m_trace            ;
            fieldSet::ConstFieldAccess m_dt_vdd_pre_auz   ;
            fieldSet::ConstFieldAccess m_cod_bndr         ;
            fieldSet::ConstFieldAccess m_issuer           ;
            fieldSet::ConstFieldAccess m_cod_ctah_voch    ;
            fieldSet::ConstFieldAccess m_status           ;
            fieldSet::ConstFieldAccess m_mc_info_ica      ;
            fieldSet::ConstFieldAccess m_track2           ;
            fieldSet::ConstFieldAccess m_authnum          ;
            fieldSet::ConstFieldAccess m_termid           ;
            fieldSet::ConstFieldAccess m_cod_gru_estb     ;
            fieldSet::ConstFieldAccess m_cod_mtz_estb     ;
            fieldSet::ConstFieldAccess m_receive_inst_id  ;
            fieldSet::ConstFieldAccess m_termid_type      ;
            fieldSet::ConstFieldAccess m_mc_info_country  ;
            fieldSet::ConstFieldAccess m_cod_cndc_cptr    ;
            fieldSet::ConstFieldAccess m_addresponse      ;
            fieldSet::ConstFieldAccess m_has_pin      ;
            
            fieldSet::ConstFieldAccess m_iss_name ;         
            fieldSet::ConstFieldAccess m_msg_category ;     
            fieldSet::ConstFieldAccess m_acq_name ; 
            fieldSet::ConstFieldAccess m_msg_name ;         
            fieldSet::ConstFieldAccess m_is_pre_auth ;    
            fieldSet::ConstFieldAccess m_install_num ;                
            fieldSet::ConstFieldAccess m_isVan ;
            fieldSet::ConstFieldAccess m_cod_gru_clas_ram ;
            fieldSet::ConstFieldAccess m_track3           ;
            fieldSet::ConstFieldAccess m_tokenIdentifier ;
            fieldSet::ConstFieldAccess m_codigoOrigemRespostaAutorizacao ;
            
            // Release Bandeiras PDV - Abril 2019 - INICIO
            fieldSet::ConstFieldAccess indicadorModoEntrada;
            fieldSet::ConstFieldAccess indicadorPresencaPortador;
            fieldSet::ConstFieldAccess indicadorTecnologiaTerminal;
            // Release Bandeiras PDV - Abril 2019 - FIM
            
            std::string m_sourceFieldPath;
            std::string m_localFieldPath;
            std::string m_targetFieldPath; 
            
            
            std::string m_str_result;
            fieldSet::FieldAccess m_result;
    };
}


