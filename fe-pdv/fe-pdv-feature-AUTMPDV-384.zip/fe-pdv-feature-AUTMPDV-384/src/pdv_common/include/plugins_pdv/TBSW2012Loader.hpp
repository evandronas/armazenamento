/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW2012Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW2012Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <698224, Raphael Gomes>
/ Data de Cria��o: <Fri Apr 12 08:48:00 2013>
/ Historico Mudancas: <Data, Modulo, Autor, Descricao da Mudanca>
/ <Data, Modulo, Autor, Descricao da Mudanca>
/ ---------------------------------------------------------------------------
*/


#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW2012Loader( );
    class TBSW2012Loader : public dataManip::Command
    {
		public:
			TBSW2012Loader( );
			TBSW2012Loader( const std::string& str );
			virtual ~TBSW2012Loader( );
			bool init( );
			void finish( );
			int execute( bool& a_stop );
			dataManip::Command* clone( ) const;
			TBSW2012Loader& setTargetFieldPath( const std::string& a_path );
			TBSW2012Loader& setSourceFieldPath( const std::string& a_path );
		private:
			bool startConfiguration( const configBase::Tag* a_tag );
			
      fieldSet::FieldAccess m_result;
      
      fieldSet::FieldAccess m_cod_rota_admn;     
      fieldSet::FieldAccess m_cod_msg_iso;  
      fieldSet::FieldAccess m_cod_pcm_iso;  
      fieldSet::FieldAccess m_network_id;   
      fieldSet::FieldAccess m_nom_host_acqr;
      fieldSet::FieldAccess m_nom_fe_acqr;  
      fieldSet::FieldAccess m_cod_issr_sw;        
      
      fieldSet::FieldAccess m_msgtype; 
      fieldSet::FieldAccess m_pcode; 

        
      std::string m_sourceFieldPath;
			std::string m_targetFieldPath;
    };
}
