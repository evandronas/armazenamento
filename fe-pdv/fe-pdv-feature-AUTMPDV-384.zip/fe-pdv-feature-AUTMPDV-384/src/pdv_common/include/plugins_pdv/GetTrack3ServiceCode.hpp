#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "logger/LoggerGen.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createGetTrack3ServiceCode( );
    class GetTrack3ServiceCode : public dataManip::Command
    {
		public:
			
			GetTrack3ServiceCode( );
			virtual ~GetTrack3ServiceCode( );
			dataManip::Command* clone( ) const;
			
			bool init( );
			void finish( );
			int execute( bool& a_stop );
			
			GetTrack3ServiceCode& setSourceFieldPath( const std::string& a_path );
			GetTrack3ServiceCode& setTargetFieldPath( const std::string& a_path );
			
		private:
			
			bool startConfiguration( const configBase::Tag* a_tag );
			
			std::string m_targetFieldPath;
			std::string m_sourceFieldPath;
			
			fieldSet::FieldAccess m_track3;
			fieldSet::FieldAccess m_service_code;
    };
} //namespace plugins_pdv


