#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "TBSW2020.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW2020Loader( );
    class TBSW2020Loader : public dataManip::Command
    {
    public:
        TBSW2020Loader( );
        TBSW2020Loader( const std::string &str );
        virtual ~TBSW2020Loader( );
        bool init( );
        void finish( );
        int execute( bool& a_stop );
        dataManip::Command* clone( ) const;
        TBSW2020Loader& setTargetFieldPath( const std::string& a_path );
        TBSW2020Loader& setResult( const std::string& a_result );
        std::string getResult( );
    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        fieldSet::FieldAccess m_targetField;
        std::string m_targetFieldPath;
        std::string m_result;
        dbaccess_common::TBSW2020 l_nsu;
    };
}

