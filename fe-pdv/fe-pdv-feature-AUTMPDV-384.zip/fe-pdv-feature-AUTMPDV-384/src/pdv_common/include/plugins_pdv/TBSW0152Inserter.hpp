#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0152Inserter( );
    
    class TBSW0152Inserter : public dataManip::Command
    {
        public:
            
            TBSW0152Inserter( );
            virtual ~TBSW0152Inserter( );
            
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            
            dataManip::Command* clone( ) const;
            
            TBSW0152Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0152Inserter& setTargetFieldPath( const std::string& a_path );
            
        private:
            
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            
            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_install_num;
            fieldSet::ConstFieldAccess m_install_amt;
            fieldSet::ConstFieldAccess m_msg_name;
            fieldSet::ConstFieldAccess m_vl_pca_ent;
            fieldSet::ConstFieldAccess m_iss_name;
    };
}
