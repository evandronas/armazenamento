#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "TBSW2020.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW2020GetNSU( );
    class TBSW2020GetNSU : public dataManip::Command
    {
    public:
        TBSW2020GetNSU( );
        TBSW2020GetNSU( const std::string &str );
        virtual ~TBSW2020GetNSU( );
        bool init( );
        void finish( );
        int execute( bool& a_stop );
        dataManip::Command* clone( ) const;
        TBSW2020GetNSU& setTargetFieldPath( const std::string& a_path );
        TBSW2020GetNSU& setResult( const std::string& a_result );
        std::string getResult( );
    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        fieldSet::FieldAccess m_targetField;
        std::string m_targetFieldPath;
        std::string m_result;
        dbaccess_common::TBSW2020 l_nsu;
    };
}

