#pragma once

#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0030Updater( );

    class TBSW0030Updater : public dataManip::Command
    {
        public:

            TBSW0030Updater( );
            virtual ~TBSW0030Updater( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0030Updater& setSourceFieldPath( const std::string& a_path );
            TBSW0030Updater& setTargetFieldPath( const std::string& a_path );
            TBSW0030Updater& setLocalFieldPath( const std::string& a_path );

        private:

            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::FieldAccess m_ind_impr_cpom;
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_authnum;
            fieldSet::ConstFieldAccess m_ext_network_code;
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_status;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_origauthnum;
            fieldSet::ConstFieldAccess m_cod_istt_acqr;
            fieldSet::ConstFieldAccess m_cod_istt_frwd;
            fieldSet::ConstFieldAccess m_cod_rsps_dtlh_emsr;
            fieldSet::ConstFieldAccess m_ext_refnum;
            fieldSet::ConstFieldAccess m_de_adc_ete;
            fieldSet::ConstFieldAccess m_mc_info_country;
            fieldSet::ConstFieldAccess m_mc_info_ica;
            fieldSet::ConstFieldAccess m_settlement_date;
            fieldSet::ConstFieldAccess m_addresponse;
            fieldSet::ConstFieldAccess m_respcode;
            fieldSet::ConstFieldAccess m_num_rsmo_vd;
            fieldSet::ConstFieldAccess m_ind_tran_refd;
            fieldSet::ConstFieldAccess m_extrac_out_de60;
            fieldSet::ConstFieldAccess m_localNumAut;
            fieldSet::ConstFieldAccess m_localCodAutEmsr;
            fieldSet::ConstFieldAccess m_localCodAutEmsrCnvt;
            fieldSet::ConstFieldAccess m_issuer;
            fieldSet::ConstFieldAccess m_iss_name;
            fieldSet::ConstFieldAccess m_msg_category;
            fieldSet::ConstFieldAccess m_acq_name;
            fieldSet::ConstFieldAccess m_msg_name;
            fieldSet::ConstFieldAccess m_hor_tran_emsr;
            fieldSet::ConstFieldAccess m_dat_mov_tran_emsr;
            fieldSet::ConstFieldAccess m_receive_inst_id;
            fieldSet::ConstFieldAccess m_pb_reason_code;
            fieldSet::ConstFieldAccess m_local_time;
            fieldSet::ConstFieldAccess m_has_pin;
            fieldSet::ConstFieldAccess m_az_reason_code;
            fieldSet::ConstFieldAccess m_nom_site_issr;
            fieldSet::ConstFieldAccess m_nom_fe_issr;
            fieldSet::ConstFieldAccess m_nom_host_issr;
            fieldSet::ConstFieldAccess m_quem_negou;
            fieldSet::ConstFieldAccess m_ind_modl_cptr;
            fieldSet::ConstFieldAccess m_txt_adic_pos;
            fieldSet::ConstFieldAccess m_segments_credit_fee;
            // t689049@FIS - 16/01/2017 - IND_IMPR_CPOM
            fieldSet::ConstFieldAccess m_trn_tem_cupom;
            fieldSet::ConstFieldAccess m_cod_mtv_sw;
            fieldSet::ConstFieldAccess m_is_desfaz_estorno;
            fieldSet::ConstFieldAccess m_sender_mbname;
            fieldSet::ConstFieldAccess m_de38IssOff;
            fieldSet::ConstFieldAccess tokenIdentifier;
            fieldSet::ConstFieldAccess temOriginal;
            fieldSet::ConstFieldAccess codigoOrigemRespostaAutorizacao;
            fieldSet::ConstFieldAccess alphaResponseCode;
            fieldSet::ConstFieldAccess m_origtranscode;
            // Release Bandeiras PDV - Abril 2019 - INICIO
            fieldSet::ConstFieldAccess indicadorPresencaPortador;
            fieldSet::ConstFieldAccess indicadorTecnologiaTerminal;
            // Release Bandeiras PDV - Abril 2019 - FIM
            // J01_2020 - Novo Debito da Mastercard - INICIO
            fieldSet::ConstFieldAccess codigoSubtranscode;
            // J01_2020 - Novo Debito da Mastercard - FIM
            fieldSet::ConstFieldAccess termloc;
            // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
            fieldSet::ConstFieldAccess codigoProcessoEmissor;
            // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM
            fieldSet::ConstFieldAccess identificadorReferenciaBandeira;
    };
}

