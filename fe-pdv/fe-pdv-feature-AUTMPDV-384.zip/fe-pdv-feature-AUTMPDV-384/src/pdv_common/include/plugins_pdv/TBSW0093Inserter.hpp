/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0093Inserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0093Inserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <698224, Raphael Gomes>
/ Data de Cria��o: <2013, 16 de Janeiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
  extern "C" base::Identificable* createTBSW0093Inserter();

  class TBSW0093Inserter : public dataManip::Command
  {
   public:
     TBSW0093Inserter();
     virtual ~TBSW0093Inserter();
     
     bool init();
     void finish();
     int execute( bool& a_stop );
     dataManip::Command* clone() const;
     
     TBSW0093Inserter& setSourceFieldPath( const std::string& a_path );
     TBSW0093Inserter& setTargetFieldPath( const std::string& a_path );
   
   private:
     bool startConfiguration( const configBase::Tag* a_tag );
      
     std::string m_sourceFieldPath;
     std::string m_targetFieldPath;
   
     fieldSet::FieldAccess m_result;
   
     fieldSet::ConstFieldAccess m_local_date;
     fieldSet::ConstFieldAccess m_refnum;
     fieldSet::ConstFieldAccess m_az_reason_code;
     fieldSet::ConstFieldAccess m_ext_network_code;
     fieldSet::ConstFieldAccess m_settlement_date;
     fieldSet::ConstFieldAccess m_pb_reason_code;
     fieldSet::ConstFieldAccess m_bit63;
     fieldSet::ConstFieldAccess m_transcode;
     fieldSet::ConstFieldAccess m_pcode;
     fieldSet::ConstFieldAccess m_pay_code;
     fieldSet::ConstFieldAccess m_pos_entry_code;
     fieldSet::ConstFieldAccess m_cd_ems;    
     fieldSet::ConstFieldAccess m_cod_item;    
     // t719926 - Gaps - 19/07/2016 - Inicio
     fieldSet::ConstFieldAccess m_msg_name;
     // t719926 - Gaps - 19/07/2016 - Fim

  };
}

