/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include "TBSW0101.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTbsw0101Loader();

    class Tbsw0101Loader : public dataManip::Command
    {
        public:
            Tbsw0101Loader();
            virtual ~Tbsw0101Loader();

            bool init();
            void finish();
            int execute( bool& stopParametro );
            dataManip::Command* clone() const;

            Tbsw0101Loader& SetSourceFieldPath( const std::string& pathParametro );
            Tbsw0101Loader& SetTargetFieldPath( const std::string& pathParametro );

        private:
            bool startConfiguration( const configBase::Tag* tagParametro );

            std::string sourceFieldPath;
            std::string targetFieldPath;

            fieldSet::FieldAccess result;

            fieldSet::FieldAccess dataMovimentoTransacao;           /// DAT_MOV_TRAN     : DATA_MOVIMENTO_TRANSACAO
            fieldSet::FieldAccess numeroSequencialUnico;            /// NUM_SEQ_UNC      : NUMERO_SEQUENCIAL_UNICO
            fieldSet::FieldAccess codigoNivelSegurancaToken;        /// COD_NVL_SGRA_TKN : CODIGO_NIVEL_SEGURANCA_TOKEN
            fieldSet::FieldAccess codigoReferenciaContaPagamento;   /// COD_REF_CTA_PGMN : CODIGO_REFERENCIA_CONTA_PAGAMENTO

            fieldSet::ConstFieldAccess localDateSource;     /// shc_msg.local_date
            fieldSet::ConstFieldAccess refnumSource;        /// shc_msg.refnum
            fieldSet::ConstFieldAccess msgtypeSource;       /// shc_msg.msgtype
            fieldSet::ConstFieldAccess origDateSource;      /// shc_msg.origdate
            fieldSet::ConstFieldAccess origRefnumSource;    /// shc_msg.origrefnum

    }; // class Tbsw0101Loader

} // namespace plugins_pdv
