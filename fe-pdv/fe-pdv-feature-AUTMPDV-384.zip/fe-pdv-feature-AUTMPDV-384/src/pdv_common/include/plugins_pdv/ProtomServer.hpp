/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/------------------------------------------------------------------------------
/Sigla: SW - FE-PDV
/Descri��o:
/Conte�do:
/Autor: t689066, Alexandre Teodoro Guimaraes
/Data de Cria��o: 2012, 07 de fevereiro
/Hist�rico Mudan�as: 2012, 07 de fevereiro, t689066, Alexandre Teodoro Guimaraes
                                                               , Versao Inicial
/------------------------------------------------------------------------------
*/
#pragma once
#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"
#include "plugins_pdv/ecrprotsrv.hpp"

#define NOERROR "No error"

namespace plugins_pdv
{
    extern "C" base::Identificable* createProtomServer();          
    class ProtomServer : public dataManip::Command
    {                
    public:
        ProtomServer();
        virtual ~ProtomServer();
        bool init();
        void finish(); 
        int execute( bool& a_stop );
        dataManip::Command* clone() const;
		ProtomServer& setArgsFieldPath( const std::string& a_path );
        ProtomServer& setResultFieldPath( const std::string& a_path );
        ProtomServer& setSourceFieldPath( const std::string& a_path );
        ProtomServer& setTargetFieldPath( const std::string& a_path );
    private:
        bool startConfiguration( const configBase::Tag* a_tag );        
        std::string determinePorts();
        void updateEcrShm( short a_netcode, int a_mbid, char a_status );
        void setNetstatus( short a_netcode, int a_fromportMbid, int a_status );
        int gainResource( int a_resourceid, int a_waituntil, int a_waitinterval );
        void processEvent();
        void printoutActivetable();
        void sendInquiryMsg();
        void cleanUpConnAll();
        void cleanUpConnDown();
        void procApplicationCommand( char *a_cmmdmsg );
        bool msgtype01or02();
        bool msgtype16();        
        time_t mbstarttime();
        fieldSet::FieldAccess m_targetField;
        fieldSet::FieldAccess m_resultField;
        fieldSet::ConstFieldAccess m_sourceField;
        fieldSet::ConstFieldAccess m_netcodexField;
        fieldSet::ConstFieldAccess m_argsField;
        size_t	m_ecrShmTotalSize;
		std::string m_sourceFieldPath;
        std::string m_targetFieldPath;
        std::string m_resultFieldPath;
        std::string m_argsFieldPath;
        std::string m_operation;
        int m_routerInstance;   
        std::string m_protomMbName;
        std::string m_activeTableFilepath;
        struct _ecrshm_hdr * m_ecrshmHdr;
        struct _ecrshm * m_ecrshm;        
        int	m_ecrshmId;
        int m_ecrsemId;
        int m_ecrsemsrvId;
        struct _port_tbl m_portTbl[ MAX_PORT_TBL_ELEM ];
        struct _ecrmsg	m_ecrmsg; 
        struct _ecrprothdr * m_ecrprotHdr;        
        struct _ecrprothdr2 * m_ecrprotHdr2;
        struct mbport * m_xngePort;
        int	m_xngePortmbid;
        int	m_xngePortIsLocal;    
        int m_ecrprotsrvMbid;
        int	m_fromPortmbid;
        int	m_fromRouterInstance;
        struct _conn_info * m_connInfoElem;
        bool m_isProtomMsg;
    };
}
