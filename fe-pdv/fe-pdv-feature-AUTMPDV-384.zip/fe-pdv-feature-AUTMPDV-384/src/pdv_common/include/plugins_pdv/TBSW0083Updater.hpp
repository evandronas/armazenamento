/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0083Updater>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0083Updater>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, cken> / <698224, Raphael Gomes>
/ Data de Cria��o: <Fri Oct 26 15:21:52 2012
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0083Updater();
    class TBSW0083Updater : public dataManip::Command
    {
     public:
        TBSW0083Updater();
        TBSW0083Updater( const std::string& str );
        virtual ~TBSW0083Updater();
        bool init( );
        void finish( );
        int execute( bool& a_stop );
        dataManip::Command* clone( ) const;
        TBSW0083Updater& setTargetFieldPath( const std::string& a_path );
        TBSW0083Updater& setSourceFieldPath( const std::string& a_path );
    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        
        fieldSet::FieldAccess m_result;
        fieldSet::ConstFieldAccess m_local_date;
        fieldSet::ConstFieldAccess m_refnum;
        fieldSet::ConstFieldAccess m_msgtype;
        fieldSet::ConstFieldAccess m_origrefnum; 
        fieldSet::ConstFieldAccess m_orig_local_date;
        fieldSet::ConstFieldAccess m_avs_respcode;
        
        std::string m_targetFieldPath;
        std::string m_sourceFieldPath;
    };
}




