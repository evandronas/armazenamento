/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0161Loader( );
	
	class TBSW0161Loader : public dataManip::Command
	{
	public:
		TBSW0161Loader( );
		TBSW0161Loader( const std::string &str );
		virtual ~TBSW0161Loader( );
		
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		
		dataManip::Command* clone( ) const;
		
		TBSW0161Loader& setSourceFieldPath( const std::string& a_path );
		TBSW0161Loader& setTargetFieldPath( const std::string& a_path );
		
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		
		fieldSet::FieldAccess m_RESULT;
		fieldSet::FieldAccess m_NUM_PDV_BNDR;
        
		fieldSet::ConstFieldAccess m_termloc;
        fieldSet::ConstFieldAccess m_cod_bndr;
        fieldSet::ConstFieldAccess m_iss_name;
			
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
	};
}

