#pragma once
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"
#include "TBSW0084.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0084Inserter();

    class TBSW0084Inserter : public dataManip::Command
    {
        public:
            TBSW0084Inserter();
            TBSW0084Inserter( const std::string& str );
            virtual ~TBSW0084Inserter();

            bool init();
            void finish();
            int execute( bool& a_stop );
            dataManip::Command* clone() const;

            TBSW0084Inserter& setTargetFieldPath( const std::string& a_path );
            TBSW0084Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0084Inserter& setLocalFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_targetFieldPath;
            std::string m_sourceFieldPath;
            std::string m_localFieldPath;
            std::string m_status;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_time;
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_terminal_pdv;
            fieldSet::ConstFieldAccess m_trace;
            fieldSet::ConstFieldAccess m_termloc;
            fieldSet::ConstFieldAccess m_id_pinpad;
            fieldSet::ConstFieldAccess m_statistics;
            fieldSet::ConstFieldAccess m_refnum;

    };

}
