/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include "TBSW0101.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTbsw0101Updater( );

    class Tbsw0101Updater : public dataManip::Command
    {
        public:
            Tbsw0101Updater( );
            virtual ~Tbsw0101Updater( );

            bool init( );
            void finish( );
            int execute( bool& stopParametro );
            dataManip::Command* clone( ) const;

            Tbsw0101Updater& SetSourceFieldPath( const std::string& pathParametro );
            Tbsw0101Updater& SetTargetFieldPath( const std::string& pathParametro );
            Tbsw0101Updater& SetLocalFieldPath( const std::string& pathParametro );

        private:
            bool startConfiguration( const configBase::Tag* tagParametro );

            std::string sourceFieldPath;
            std::string targetFieldPath;
            std::string localFieldPath;

            fieldSet::FieldAccess      result;

            fieldSet::ConstFieldAccess localDateSource;     /// shc_msg.local_date
            fieldSet::ConstFieldAccess refnumSource;        /// shc_msg.refnum
            fieldSet::ConstFieldAccess msgtypeSource;       /// shc_msg.msgtype
            fieldSet::ConstFieldAccess origDateSource;      /// shc_msg.origdate
            fieldSet::ConstFieldAccess origRefnumSource;    /// shc_msg.origrefnum

            fieldSet::ConstFieldAccess codigoNivelSegurancaToken;        /// COD_NVL_SGRA_TKN : segments.common.tokenAssuranceLevel
            fieldSet::ConstFieldAccess codigoReferenciaContaPagamento;   /// COD_REF_CTA_PGMN : segments.common.paymentAccountReference

    }; // class Tbsw0101Updater
} // namespace plugins_pdv
