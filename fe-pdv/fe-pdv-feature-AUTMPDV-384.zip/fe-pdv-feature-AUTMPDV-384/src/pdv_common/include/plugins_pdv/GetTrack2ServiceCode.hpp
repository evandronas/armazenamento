#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "logger/LoggerGen.hpp"
namespace plugins_pdv
{
	extern "C" base::Identificable* createGetTrack2ServiceCode( );
	class GetTrack2ServiceCode : public dataManip::Command
	{
	public:
		GetTrack2ServiceCode( );
		virtual ~GetTrack2ServiceCode( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		GetTrack2ServiceCode& setSourceFieldPath( const std::string& a_path );
		GetTrack2ServiceCode& setTargetFieldPath( const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::ConstFieldAccess m_sourceField;
		fieldSet::FieldAccess m_targetField;
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
	};
}//namespace plugins_pdv

