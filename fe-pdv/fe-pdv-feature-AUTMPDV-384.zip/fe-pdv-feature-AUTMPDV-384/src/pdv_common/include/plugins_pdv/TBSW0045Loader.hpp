/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0045Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0045Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>  / <698224, Raphael Gomes>
/ Data de Cria��o: <Fri Jan 11 09:26:32 2013>
/ ---------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0045Loader( );
    class TBSW0045Loader : public dataManip::Command
    {
		public:
			TBSW0045Loader( );
			TBSW0045Loader( const std::string& str );
			virtual ~TBSW0045Loader( );
			bool init( );
			void finish( );
			int execute( bool& a_stop );
			dataManip::Command* clone( ) const;
			TBSW0045Loader& setResult( const std::string& a_result );
			TBSW0045Loader& setTargetFieldPath( const std::string& a_path );
			TBSW0045Loader& setSourceFieldPath( const std::string& a_path );
			std::string getResult( );
		private:
			bool startConfiguration( const configBase::Tag* a_tag );

			fieldSet::FieldAccess m_target_num_rv;
			fieldSet::FieldAccess m_target_num_pdv;
			fieldSet::FieldAccess m_target_ind_num_qbra;	
			fieldSet::FieldAccess m_target_dat_rv;
			fieldSet::FieldAccess m_target_cod_bndr;
			fieldSet::FieldAccess m_target_nom_bndr;	
			fieldSet::FieldAccess m_target_cod_prod;
			fieldSet::FieldAccess m_target_nom_prod;
			fieldSet::FieldAccess m_target_qtd_cv;	
			fieldSet::FieldAccess m_target_val_totl_lqdo;
			fieldSet::FieldAccess m_target_val_totl_dsct;
			fieldSet::FieldAccess m_target_val_totl_grjt;	
			fieldSet::FieldAccess m_target_val_totl_pago;
			fieldSet::FieldAccess m_target_dat_cre_rv;
			fieldSet::FieldAccess m_target_val_sit_rvs;	
			fieldSet::FieldAccess m_target_dth_ini;
			fieldSet::FieldAccess m_target_dth_fim;
			fieldSet::FieldAccess m_target_qtd_prcl;	
			fieldSet::FieldAccess m_target_val_entr;
			fieldSet::FieldAccess m_target_val_tx_serv_rvs;
			fieldSet::FieldAccess m_target_val_flag_qbra;	
			fieldSet::FieldAccess m_target_cod_tcnl;
			fieldSet::FieldAccess m_target_cod_term;
			fieldSet::FieldAccess m_target_num_stan;
			fieldSet::FieldAccess m_target_cod_cmpm_tran;	
			fieldSet::FieldAccess m_target_val_sque;
			fieldSet::FieldAccess m_target_val_pres_brto;
			fieldSet::FieldAccess m_target_val_rmnr_rcd;	
			fieldSet::FieldAccess m_target_val_iof;
			fieldSet::FieldAccess m_target_val_cpmf;
			fieldSet::FieldAccess m_target_val_tac;
			fieldSet::FieldAccess m_target_tip_iof;
					
			fieldSet::FieldAccess m_termloc;     
			fieldSet::FieldAccess m_in_tpo_tcn; 
			fieldSet::FieldAccess m_trace;                    
			
			fieldSet::FieldAccess m_result;
			
			std::string m_sourceFieldPath;
			std::string m_targetFieldPath;
    };
}//namespace plugins_pdv
