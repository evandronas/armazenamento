/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/------------------------------------------------------------------------------
/Sigla: SW - FE-PDV
/Descri��o:
/Conte�do:
/Autor: t689066, Alexandre Teodoro Guimaraes
/Data de Cria��o: 2013, 11 de marco
/Hist�rico Mudan�as: 2013, 11 de marco, t689066, Alexandre Teodoro Guimaraes
                                                               , Versao Inicial
/------------------------------------------------------------------------------
*/
#pragma once
#include <mb.h>

#define ECRPROTSRV_SHM              "EPSH"
#define ECRPROTSRV_SEM              "EPSE"
#define ECRPROTSRV_SEM_SRV          "EPSV" 
#define ECR_MAX_CONN                32767
#define MAX_PORT_TBL_ELEM           128
#define ECRPROTSRV_EVENT_TIMEOUT    90
#define PRINTOUT_ACTIVETABLE	    1

struct _ecrprothdr {
            char    version;
            char    type;
            char    reason;
            char    net_codex[2];
            char    linex[4];
            char    instance_id;
            char    APP_use;
            char    APP_line;
            char    APP_channelx[2];
            char    APP_reservedx[4];
            char    msg_lenx[2];
        };
struct  _ecrmsg {
            struct _ecrprothdr  ecrprothdr_buf;
            char    data[1120];
        };
struct _ecrshm_hdr {
            int     id;				
            time_t	datetime_creat;	
            int		conn_primary;	
            int		conn_secondary;	
            long    max_elems_num;	
            size_t  elem_len;		
        };
struct _ecrprothdr2 {
            struct	_ecrprothdr	prothdr1;
            char				msg_seq;
            char				total_msgs;
            char				instance_id;
            char				total_conns[2];
    };            
struct _ecrshm {
            char    status;
            int mbid;
        };    
struct _port_tbl {
        char            portname[ MB_MAX_NAME + 1 ];
        char			instance_id;
        struct mbport   *client_port;
        int             client_portid;
        int             client_mbid;
    };       
struct _conn_info {
        char        net_codex[2];
        char        status;
    };

