#pragma once
#include "TBSW0139.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0139Inserter( );

    class TBSW0139Inserter : public dataManip::Command
    {
        public:
            TBSW0139Inserter( );
            TBSW0139Inserter( const std::string& str );
            virtual ~TBSW0139Inserter( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0139Inserter& setTargetFieldPath( const std::string& a_path );
            TBSW0139Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0139Inserter& setLocalFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_targetFieldPath;
            std::string m_sourceFieldPath;
            std::string m_localFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_termid;
            fieldSet::ConstFieldAccess m_indCripto;
            fieldSet::ConstFieldAccess m_termloc;
            fieldSet::ConstFieldAccess m_nom_site_issr;
            fieldSet::ConstFieldAccess m_nom_host_issr;
            fieldSet::ConstFieldAccess m_nom_fe_issr;
            fieldSet::ConstFieldAccess m_termid_type;
            fieldSet::ConstFieldAccess m_codver;
            fieldSet::ConstFieldAccess m_cod_vers_sftw;
            fieldSet::ConstFieldAccess m_num_vers_clit;
            fieldSet::ConstFieldAccess m_num_vers_aplv_rcd;
            fieldSet::ConstFieldAccess m_versSotfwBiblCompartPinpad;
            fieldSet::ConstFieldAccess m_versEspecBiblCompartPinpad;
            fieldSet::ConstFieldAccess m_ecr_fabr_id;
            fieldSet::ConstFieldAccess m_ecr_sftw_verid;
    }; // class TBSW0139Inserter
} // namespace plugins_pdv
