/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include "TBSW0101.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTbsw0101Inserter( );

    class Tbsw0101Inserter : public dataManip::Command
    {
        public:
            Tbsw0101Inserter( );
            virtual ~Tbsw0101Inserter( );

            bool init( );
            void finish( );
            int execute( bool& stopParametro );
            dataManip::Command* clone( ) const;

            Tbsw0101Inserter& SetSourceFieldPath( const std::string& pathParametro );
            Tbsw0101Inserter& SetTargetFieldPath( const std::string& pathParametro );

        private:
            bool startConfiguration( const configBase::Tag* tagParametro );

            std::string sourceFieldPath;
            std::string targetFieldPath;

            fieldSet::FieldAccess result;

            fieldSet::ConstFieldAccess localDate;                /// shc_msg.local_date
            fieldSet::ConstFieldAccess refnum;                   /// shc_msg.refnum
            fieldSet::ConstFieldAccess tokenAssuranceLevel;      /// segments.common.tokenAssuranceLevel
            fieldSet::ConstFieldAccess paymentAccountReference;  /// segments.common.paymentAccountReference
    }; // class Tbsw0101Inserter
} // namespace plugins_pdv
