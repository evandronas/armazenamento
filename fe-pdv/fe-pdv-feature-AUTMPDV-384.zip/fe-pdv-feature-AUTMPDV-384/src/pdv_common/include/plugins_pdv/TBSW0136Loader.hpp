#pragma once

#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0136Loader();

    class TBSW0136Loader : public dataManip::Command
    {
    public:
        TBSW0136Loader();
        TBSW0136Loader( const std::string& str );
        virtual ~TBSW0136Loader();

        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;

        TBSW0136Loader& setTargetFieldPath( const std::string& a_path );
        TBSW0136Loader& setSourceFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        std::string m_targetFieldPath;
        std::string m_sourceFieldPath;
        
        fieldSet::FieldAccess m_termTPK;
        fieldSet::FieldAccess m_mac;
        fieldSet::ConstFieldAccess m_idxTPK;
        
        std::map<unsigned long,std::string> m_tbsw0136_records;
    };
}
