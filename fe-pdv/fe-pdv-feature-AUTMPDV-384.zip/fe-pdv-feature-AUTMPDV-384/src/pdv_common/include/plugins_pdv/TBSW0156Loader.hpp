/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0130Loader>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TBSW0130Loader>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694451, Ricardo Deus>
/ Data de Criação: <2013, 18 de Abril>
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ . . .
/ <Data, Módulo, Autor, Descrição da Mudança>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "TBSW0156.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0156Loader();

	class TBSW0156Loader : public dataManip::Command
	{
	public:
    TBSW0156Loader();
		virtual ~TBSW0156Loader();
		
		bool init();
		void finish();
		int execute( bool& a_stop );
		dataManip::Command* clone() const;
		
		TBSW0156Loader& setSourceFieldPath( const std::string& a_path );
		TBSW0156Loader& setTargetFieldPath( const std::string& a_path );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;

		fieldSet::FieldAccess m_result;
		
		fieldSet::FieldAccess COD_TERM;
		fieldSet::FieldAccess NUM_STAN;                                
	};

}



