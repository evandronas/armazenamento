/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include "fieldSet/FieldAccess.hpp"
#include "msgConv/FieldSetLoader.hpp"
#include "msgConv/Iso8583Properties.hpp"


namespace msgConv
{
    extern "C" FieldSetLoader* createIso8583xPdvParser();
    
	class Iso8583xPdvParser : public FieldSetLoader
	{
	public:
		Iso8583xPdvParser( );
        bool startConfiguration( const configBase::Tag* a_tag );		
		virtual ~Iso8583xPdvParser( );
		bool open( );
		void close( );
		bool parse( const unsigned char* a_source, unsigned int a_sourceLen );
		Iso8583xPdvParser& setIso8583Properties( const Iso8583Properties& a_iso8583Properties );
	private:
        bool loadXml( const std::string& a_xmlPath, const std::string& l_xmlName, configBase::Tag& a_tag );
		bool extractPieces( const std::string& a_specific );
		void convertToAscii( std::string& a_ascii, const std::string& a_input, DataCoding a_dataCoding );
		unsigned int convertToHEX( unsigned char*a_hex, unsigned int a_hexSize, const std::string& a_input, DataCoding a_dataCoding );
		unsigned int calculateSize( unsigned int a_numDigits, DataCoding a_dataCoding );
		bool loadBitmap( const unsigned char* a_bitmapBuffer, unsigned int a_size, unsigned int a_bitMapNumber );
		bool loadFieldSet( );
		bool initialiseIndexers( );
		fieldSet::Field& getDataElement( unsigned int a_deNumber );
		Iso8583Properties m_iso8583Properties;
		std::string m_header;
        std::string m_niip;
		std::string m_msgType;
		std::string m_messageType;
		unsigned char m_firstBitmap[8];
		unsigned char m_secondBitmap[8];
		std::string m_dataElements;
		std::deque<unsigned int> m_dequeBitsOn;
		bool m_hasSecondBitmapPart;
		static const unsigned int m_deCount = 128;
		fieldSet::FieldAccess m_dataElementsAccess[m_deCount];
		fieldSet::FieldAccess m_headerAccess;
        fieldSet::FieldAccess m_niipAccess;
		fieldSet::FieldAccess m_msgTypeAccess;
		fieldSet::FieldAccess m_isISO8583Access;
		unsigned char* m_auxBuffer;
		unsigned int m_auxBufferLength;
	};
}//namespace msgConv

