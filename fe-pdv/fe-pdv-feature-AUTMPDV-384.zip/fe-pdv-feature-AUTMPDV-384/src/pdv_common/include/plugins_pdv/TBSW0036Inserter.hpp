#pragma once

#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0036Inserter( );
    
    class TBSW0036Inserter : public dataManip::Command
    {
        public:
            
            TBSW0036Inserter( );
            virtual ~TBSW0036Inserter( );
            
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            
            TBSW0036Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0036Inserter& setTargetFieldPath( const std::string& a_path );
            TBSW0036Inserter& setLocalFieldPath( const std::string& a_path );
            
        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string sourceFieldPath;
            std::string targetFieldPath;
            std::string localFieldPath;
            
            fieldSet::FieldAccess result;
            
            fieldSet::ConstFieldAccess localDate;
            fieldSet::ConstFieldAccess refnum;
            fieldSet::ConstFieldAccess valorMoedaEstrangeira;
            fieldSet::ConstFieldAccess codigoMoedaEstrangeira;
            fieldSet::ConstFieldAccess percentualTaxaMarkup;
            fieldSet::ConstFieldAccess valorTaxaConvMoeda;
            fieldSet::ConstFieldAccess dataTranPlanet;
            fieldSet::ConstFieldAccess numSeqUnicoPlanet;
    };
}

