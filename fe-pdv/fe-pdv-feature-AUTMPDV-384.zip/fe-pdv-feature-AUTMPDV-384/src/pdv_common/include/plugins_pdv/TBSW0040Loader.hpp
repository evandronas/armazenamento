/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
/ 2021-02-01 Breder - AUT1-2821 - PIX CNPJ Owner +Refactory
/ 2021-05-21 Eduardo Sert�rio - AUT1-1830 - ELO endereco EC no CV
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0040Loader( );

    class TBSW0040Loader : public dataManip::Command
    {
    public:
        TBSW0040Loader( );
        TBSW0040Loader( const std::string &str );
        virtual ~TBSW0040Loader( );

        bool init( );
        void finish( );
        int execute( bool& a_stop );

        dataManip::Command* clone( ) const;

        TBSW0040Loader& setSourceFieldPath( const std::string& a_path );
        TBSW0040Loader& setTargetFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );

        fieldSet::ConstFieldAccess m_TERMLOC;
        fieldSet::ConstFieldAccess m_COD_DSTR;

        std::string m_sourceFieldPath;
        std::string m_targetFieldPath;

        fieldSet::FieldAccess m_RESULT;

        fieldSet::FieldAccess m_MER_POST;           // COD_CEP_PDV + COD_CEP_CPL_PDV
        fieldSet::FieldAccess m_COD_RAM_ATVD_INTER; // ( COD_RAM_ATVD/1000 ) % 10
        fieldSet::FieldAccess m_POS_GEO_LOC;        // COD_PAIS + m_MER_POST
        fieldSet::FieldAccess m_RESULT_DSTR;        // depende de m_COD_DSTR
        fieldSet::FieldAccess m_COD_RAM_ATVD_DSTR;  // m_COD_DSTR ? COD_RAM_ATVD : 0

        fieldSet::FieldAccess m_NUM_PDV;
        fieldSet::FieldAccess m_COD_TIP_ESTB_PDV;
        fieldSet::FieldAccess m_COD_CTGR;
        fieldSet::FieldAccess m_NOM_RZAO_SCLA_ESTB;
        fieldSet::FieldAccess m_NOM_FAT_PDV;
        fieldSet::FieldAccess m_COD_CEP_PDV;
        fieldSet::FieldAccess m_COD_CEP_CPL_PDV;
        fieldSet::FieldAccess m_NOM_CID_PDV;
        fieldSet::FieldAccess m_NOM_ESTB_PDV;
        fieldSet::FieldAccess m_COD_PAIS;
        fieldSet::FieldAccess m_COD_RAM_ATVD;
        fieldSet::FieldAccess m_COD_RAM_ATVD_MTC;
        fieldSet::FieldAccess m_COD_CTGR_TRAN_MTC;
        fieldSet::FieldAccess m_COD_RAM_ATVD_MTC_DNRS;
        fieldSet::FieldAccess m_COD_MTZ_ESTB;
        fieldSet::FieldAccess m_COD_GRU_ESTB;
        fieldSet::FieldAccess m_NUM_CNPJ;
        fieldSet::FieldAccess m_COD_STTU_REG;
        fieldSet::FieldAccess m_DAT_ATLZ_REG;
        fieldSet::FieldAccess m_COD_ID_DSTR;
        fieldSet::FieldAccess m_IND_PDV_CART_DGTL;
        fieldSet::FieldAccess m_COD_TIP_PES;
        fieldSet::FieldAccess m_COD_GRU_CLAS_RAM;
        fieldSet::FieldAccess m_COD_TIP_FACR;
        fieldSet::FieldAccess m_COD_MVV;               // J10_2020 - Release Outubro
        fieldSet::FieldAccess m_COD_PRCR_PSP;          // AUT1-2121 - Codigo da Chave PIX
        fieldSet::FieldAccess m_COD_TIP_CHAV_PIX;      // AUT1-2121 - Codigo do Parceiro PSP - PIX
        fieldSet::FieldAccess m_COD_CHAV_PIX;          // AUT1-2320 - Codigo do tipo da Chave PIX
        fieldSet::FieldAccess m_NUM_CNPJ_PIX_OWN_CHAV; // AUT1-2821 - PIX CNPJ Owner
        fieldSet::FieldAccess m_NOM_LOGR_PDV;          // AUT1-1830 - ELO endereco EC no CV
        fieldSet::FieldAccess m_NUM_LOGR_PDV;          // AUT1-1830 - ELO endereco EC no CV
        fieldSet::FieldAccess m_NOM_BRR_PDV;           // AUT1-1830 - ELO endereco EC no CV
        fieldSet::FieldAccess m_DES_CPL_ENDR_PDV;      // AUT1-1830 - ELO endereco EC no CV
    };
}// plugins_pdv
