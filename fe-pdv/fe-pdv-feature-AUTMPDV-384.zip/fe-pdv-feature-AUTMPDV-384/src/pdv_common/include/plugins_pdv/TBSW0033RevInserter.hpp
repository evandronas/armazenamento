/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0033RevInserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0033RevInserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>
/ Data de Cria��o: <2013, 18 de Janeiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
  extern "C" base::Identificable* createTBSW0033RevInserter();

  class TBSW0033RevInserter : public dataManip::Command
  {
  public:
        TBSW0033RevInserter();
    virtual ~TBSW0033RevInserter();

    bool init();
    void finish();
    int execute( bool& a_stop );
    dataManip::Command* clone() const;

    TBSW0033RevInserter& setSourceFieldPath( const std::string& a_path );
    TBSW0033RevInserter& setTargetFieldPath( const std::string& a_path );
    TBSW0033RevInserter& setLocalFieldPath( const std::string& a_path );

  private:
    bool startConfiguration( const configBase::Tag* a_tag );

    std::string m_sourceFieldPath;
    std::string m_targetFieldPath;
    std::string m_localFieldPath;

    fieldSet::FieldAccess m_result;

    fieldSet::ConstFieldAccess m_local_date;    
    fieldSet::ConstFieldAccess m_refnum;
    fieldSet::ConstFieldAccess m_msgtype;
    fieldSet::ConstFieldAccess m_trace;
    fieldSet::ConstFieldAccess m_cd_tpo_trm;
    fieldSet::ConstFieldAccess m_in_tpo_tcn;
    fieldSet::ConstFieldAccess m_load_init;
    fieldSet::ConstFieldAccess m_load_program;    
    fieldSet::ConstFieldAccess m_nu_age_etb;
    fieldSet::ConstFieldAccess m_cod_cta_etb;
    fieldSet::ConstFieldAccess m_ecr_orig_elems;    
    fieldSet::ConstFieldAccess m_is_void;
    fieldSet::ConstFieldAccess m_is_reversal;
    fieldSet::ConstFieldAccess m_origrefnum;
    fieldSet::ConstFieldAccess m_origdate;
    fieldSet::ConstFieldAccess m_origtime;
    fieldSet::ConstFieldAccess m_origmsg;
    fieldSet::ConstFieldAccess m_indUtlzPnpd;
    fieldSet::ConstFieldAccess mensagemCategoria;
    fieldSet::ConstFieldAccess dataLocalOriginal;
    fieldSet::ConstFieldAccess horaLocalOriginal;
    fieldSet::ConstFieldAccess nomeMensagem;
    fieldSet::ConstFieldAccess nomeEmissor;
    fieldSet::ConstFieldAccess cartao;
    
    // t689049@FIS - Data: 28/09/2014 - origtrace ..
    fieldSet::ConstFieldAccess m_origtrace;
  };
}

