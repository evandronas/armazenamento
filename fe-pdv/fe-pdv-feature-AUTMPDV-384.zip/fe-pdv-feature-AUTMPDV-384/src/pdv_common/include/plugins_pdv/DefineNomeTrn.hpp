#pragma once

#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createDefineNomeTrn( );

    class DefineNomeTrn : public dataManip::Command
    {
        public:

            DefineNomeTrn( );
            virtual ~DefineNomeTrn( );
            static bool defineNome( const long &l_msgtype,
                                    const long &l_pcode,
                                    const std::string &l_pdvTrnId,
									const bool &l_instalNumPresente,
                                    const std::string &l_origMsg,
                                    const std::string &l_transactionId,
									const bool &l_de047_031Presente,
									const bool &l_settlementDatePresent,
									const int  &l_loadInit,
                                    std::string &nome_transacao,
                                    std::ostringstream &l_log );
            
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            DefineNomeTrn& setSourceFieldPath( const std::string& a_path );
            DefineNomeTrn& setTargetFieldPath( const std::string& a_path );
            DefineNomeTrn& setLocalFieldPath( const std::string& a_path );
			
        private:

            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;
			
			fieldSet::FieldAccess m_msg_name;
        
            fieldSet::ConstFieldAccess m_msgtype;
			fieldSet::ConstFieldAccess m_pcode;
            fieldSet::ConstFieldAccess m_pdv_trn_id;
            fieldSet::ConstFieldAccess m_install_num;
            fieldSet::ConstFieldAccess m_origmsg;
            fieldSet::ConstFieldAccess m_transactionId;
            fieldSet::ConstFieldAccess m_settlement_date;
            fieldSet::ConstFieldAccess m_idPagFatura;
            fieldSet::ConstFieldAccess m_loadInit;            
    };
}
