/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::PedidosPreAutorizacao>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::PedidosPreAutorizacao>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <694037, Fernando Amaral>
/ Data de Cria��o: <Tue Aug 14 18:57:32 2012
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createPedidosPreAutorizacao();

    class PedidosPreAutorizacao : public dataManip::Command
    {
    public:
        enum tableFields
        { 
            RESULT, COUNT, LAST_TB_FIELD
        };
    
		enum sourceFields
		{
			ORIGPAN, TERMLOC, LAST_SOURCE_FIELD, RECEIVE_INST_ID
		};
		
		enum localFields
		{
			COD_GRU_ESTB, COD_MTZ_ESTB, LAST_LOCAL_FIELD
		};		

        PedidosPreAutorizacao();
        PedidosPreAutorizacao( const std::string& str );
        virtual ~PedidosPreAutorizacao();

        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;

        std::string getResult( );
        PedidosPreAutorizacao& setResult( const std::string& a_result );

        PedidosPreAutorizacao& setTargetFieldPath( const std::string& a_path );
        PedidosPreAutorizacao& setSourceFieldPath( const std::string& a_path );
		PedidosPreAutorizacao& setLocalFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        fieldSet::FieldAccess m_targetField[LAST_TB_FIELD];
        fieldSet::FieldAccess m_sourceField[LAST_SOURCE_FIELD];
		fieldSet::FieldAccess m_localField[LAST_LOCAL_FIELD];
        std::string m_targetFieldPath;
        std::string m_sourceFieldPath;
		std::string m_localFieldPath;
        std::string m_result;
    };
}




