/* Copyright 2018 Rede S.A.
Autor : Danilo Jose de Oliveia
Empresa : FIS
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* CreateCheckTrapIsOn( );

    class CheckTrapIsOn : public dataManip::Command
    {
        public:
            CheckTrapIsOn( );
            virtual ~CheckTrapIsOn( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            CheckTrapIsOn& SetSourceFieldPath( const std::string& pathParametro );
            CheckTrapIsOn& SetTargetFieldPath( const std::string& pathParametro );

        private:
            bool startConfiguration( const configBase::Tag* tagParametro );

            std::string sourceFieldPath;
            std::string targetFieldPath;

            fieldSet::FieldAccess result;
            fieldSet::ConstFieldAccess trapNumber;
            fieldSet::ConstFieldAccess trapsOnFile;

    }; // class CheckTrapIsOn

} // namespace plugins_pdv


