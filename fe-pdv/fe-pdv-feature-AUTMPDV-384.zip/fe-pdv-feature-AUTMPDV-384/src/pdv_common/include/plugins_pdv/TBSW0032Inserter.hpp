#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0032Inserter( );

    class TBSW0032Inserter : public dataManip::Command
    {
        public:
            TBSW0032Inserter( );
            virtual ~TBSW0032Inserter( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0032Inserter& setLocalFieldPath( const std::string& a_path );
            TBSW0032Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0032Inserter& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_localFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_nu_bco_etb;
            fieldSet::ConstFieldAccess m_iss_name;
            fieldSet::ConstFieldAccess m_bin;
            fieldSet::ConstFieldAccess m_nu_age_etb;
            fieldSet::ConstFieldAccess m_cd_cta_etb;
            fieldSet::ConstFieldAccess m_cash_back;
            fieldSet::ConstFieldAccess m_cap_positive_conf;
            fieldSet::ConstFieldAccess m_cap_data_positive_conf;
            fieldSet::ConstFieldAccess m_amount;
            fieldSet::ConstFieldAccess m_tip_cob_tran_mtc;
            fieldSet::ConstFieldAccess m_mc_info_cod_rvda_prod;
			fieldSet::ConstFieldAccess m_val_cob_tran;
			fieldSet::ConstFieldAccess m_respcode;
            // t719926 - GAPS Revisao do MER - 13/07/2016 - Inicio
            fieldSet::ConstFieldAccess m_msg_category;
            // t719926 - GAPS Revisao do MER - 13/07/2016 - Fim

    };
}
