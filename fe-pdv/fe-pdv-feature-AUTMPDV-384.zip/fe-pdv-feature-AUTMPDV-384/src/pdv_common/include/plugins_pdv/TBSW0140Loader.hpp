/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0140Loader( );
	
	class TBSW0140Loader : public dataManip::Command
	{
	public:
		TBSW0140Loader( );
		TBSW0140Loader( const std::string &str );
		virtual ~TBSW0140Loader( );
		
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		
		dataManip::Command* clone( ) const;
		
		TBSW0140Loader& setSourceFieldPath( const std::string& a_path );
		TBSW0140Loader& setTargetFieldPath( const std::string& a_path );
		
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		
		fieldSet::FieldAccess m_RESULT;
		fieldSet::FieldAccess m_COD_MCC;
        
		fieldSet::ConstFieldAccess m_mer_cat_code;
		fieldSet::ConstFieldAccess m_cod_bndr;
			
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
	};
}

