#pragma once
#include "TBSW0121.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0121Inserter( );

    class TBSW0121Inserter : public dataManip::Command
    {
        public:
            TBSW0121Inserter( );
            virtual ~TBSW0121Inserter( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0121Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0121Inserter& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_codver;
            fieldSet::ConstFieldAccess m_termid;
            fieldSet::ConstFieldAccess m_cod_vers_sftw;
            fieldSet::ConstFieldAccess m_ecr_sftw_verid;
    }; // class TBSW0121Inserter
} // namespace plugins_pdv
