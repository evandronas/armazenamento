/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0160Inserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0160Inserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <698224, Raphael Ferreira Gomes>
/ Data de Cria��o: <2013, 14 de Janeiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ <05.09.2013, FEPOS, t694449, Fernando Ramires, Correcoes na tabela TBSW0160>
/ <11.03.2013, FEPOS, t694449, Fernando Ramires, BT57923, Correcao campo TXT_RLCD_CHIP>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0160Inserter( );

    class TBSW0160Inserter : public dataManip::Command
    {
        public:

            TBSW0160Inserter( );
            virtual ~TBSW0160Inserter( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            TBSW0160Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0160Inserter& setTargetFieldPath( const std::string& a_path );
            TBSW0160Inserter& setLocalFieldPath ( const std::string& a_path );

        private:

            bool startConfiguration( const configBase::Tag* a_tag );
            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;
            fieldSet::FieldAccess m_result;
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_local_time;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_termid_type;
            fieldSet::ConstFieldAccess m_txt_rlcd_chip;
            fieldSet::ConstFieldAccess m_chip_full_data_len;
            fieldSet::ConstFieldAccess m_txt_info_cmpm_chip;
            fieldSet::ConstFieldAccess m_txt_rstd_atlz_chip;
            fieldSet::ConstFieldAccess m_pin;
            fieldSet::ConstFieldAccess m_ecr_cvm;
            fieldSet::ConstFieldAccess m_msg_name;
            fieldSet::ConstFieldAccess m_iss_name;

            fieldSet::ConstFieldAccess numeroSequencialCartao;
    };
}


