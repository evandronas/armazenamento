/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0042Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0042Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, CKen>
/ Data de Cria��o: <Thu Oct 25 13:26:42 2012
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0042Loader();

    class TBSW0042Loader : public dataManip::Command
    {
        enum sourceFields
        {
            TERMLOC,
            LAST_SOURCE_FIELD
        };
    
    public:
        TBSW0042Loader();
        TBSW0042Loader( const std::string& str );
        virtual ~TBSW0042Loader();

        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;

        std::string getResult( );
        TBSW0042Loader& setResult( const std::string& a_status );

        TBSW0042Loader& setTargetFieldPath( const std::string& a_path );
        TBSW0042Loader& setSourceFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );
		
		fieldSet::FieldAccess m_RESULT;
		fieldSet::FieldAccess m_NUM_PDV;
		fieldSet::FieldAccess m_COD_TERM;
		fieldSet::FieldAccess m_COD_STTU_REG;
		fieldSet::FieldAccess m_DAT_ATLZ_REG;
		fieldSet::FieldAccess m_COD_PSSE_TERM;
		fieldSet::FieldAccess m_COD_SIT_TERM;
		fieldSet::FieldAccess m_COD_PRDC_TERM;
		fieldSet::FieldAccess m_IND_ATIN;
		fieldSet::FieldAccess m_IND_ATCG;
		fieldSet::FieldAccess m_IND_UTLZ_PNPD;
		fieldSet::FieldAccess m_IND_TRAN_DGTD;
		fieldSet::FieldAccess m_COD_VERS_SFTW;
		fieldSet::FieldAccess m_COD_VERS_DLL;
		fieldSet::FieldAccess m_COD_TCNL;
		fieldSet::FieldAccess m_SGL_TCNL;
		fieldSet::FieldAccess m_TIP_LGCO;
		fieldSet::FieldAccess m_IND_TERM_BLQD;
		fieldSet::FieldAccess m_TIP_TERM;
		fieldSet::FieldAccess m_TIP_EQPM;
		fieldSet::FieldAccess m_IND_TRAN_CHIP;
		fieldSet::FieldAccess m_IND_TERM_LTRO_CHIP;
		fieldSet::FieldAccess m_DAT_ATCG;
        fieldSet::FieldAccess m_IND_TERM_FATR_EXPS;
		
		fieldSet::ConstFieldAccess m_termloc;
		fieldSet::ConstFieldAccess m_termid;
		fieldSet::ConstFieldAccess m_in_tpo_tcn;
			
        std::string m_targetFieldPath;
        std::string m_sourceFieldPath;
    };
}




