#pragma once

#include <vector>
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createBit48Parser( );

    typedef struct tAD // Private Label, Voucher e demais casos
    {
        char id[2];
        char cvv2[5];
        char indCripto[2];
        char id_pedido[14];
    } AD;
    
    typedef struct tADII // Credito (nao IATA)
    {
        char id[2];
        char cvv2[3];
        char indCripto[2];
        char id_pedido[14];
        char req_signature[1];
    } ADII;

    typedef struct tADIII // Credito IATA
    {
        char id[2];
        char cvv2[3];
        char vl_txa[12];
        char vl_pca_ent[12];
        char indCripto[2];
        char id_pedido[14];
        char req_signature[1];
    } ADIII;

    typedef struct tAVS
    {
        char id[3];
        char avs_cep[9];
        char avs_end_fat[8];
        char avs_cpf[11];
        char indCripto[2];
    } AVS;

    typedef struct tCO
    {
        char id[2];
        char cvv2[3];
        char indCripto[2];
        char id_pedido[14];
        char transactionId[4];
        char req_signature[1];
    } CO;

    typedef struct tCP
    {
        char id[2];
        char cvv2[5];
        char indCripto[2];
        char id_pedido[14];
        char cap_positive_conf[1];
        char num_prompts_cp[2];
        char cap_data_positive_conf[1];
        char dados_coletados[17];
    } CP;

    typedef struct tDO
    {
        char id[2];
        char transactionId[4];
        char cvv2[5];
        char indCripto[2];
        char id_pedido[14];
        char cap_positive_conf[1];
        char num_prompts_cp[2];
        char cap_data_positive_conf[1];
        char dados_coletados[17];
    } DO;

    typedef struct tNE
    {
        char id[2];
        char indCripto[2];
        char transactionId[4];
    } NE;
    
    typedef struct tPA
    {
        char id[2];
        char indCripto[2];
        char cvv2[3];
        char id_pedido[14];
    } PA;
    
    typedef struct tPAA
    {
        char id[2];
        char indCripto[2];
    } PAA;

    typedef struct tPI
    {
        char id[1];
        char cvv2[3];
        char indCripto[2];
    } PI;

    typedef struct tPII
    {
        char id[1];
        char dt_preaut[4];
        char indCripto[2];
        char cvv2[3];
        char id_pedido[14];
    } PII;

    typedef struct tPIII
    {
        char id[1];
        char dt_preaut[4];
        char indCripto[2];
    } PIII;

    typedef struct tPIV
    {
        char id[1];
        char dt_preaut[4];
    } PIV;

    typedef struct tPC
    {
        char id[2];
        char indCripto[2];
        char transactionId[4];
        char cvv2[3];
    } PC;

    typedef struct tR1
    {
        char id[2];
        char cvv2[3];
        char indCripto[2];
        char id_pedido[14];
        char req_signature[1];
        char cap_referal[1];
        char num_prompts_rf[2];
    } R1;
    
    typedef struct tR1_Iata
    {
        char id[2];
        char cvv2[3];
        char indCripto[2];
        char id_pedido[14];
        char req_signature[1];
        char cap_referal[1];
        char num_prompts_rf[2];
        char vl_txa[12]; 
        char vl_pca_ent[12];
    } R1_Iata;

    typedef struct tR2
    {
        char id[2];
        char cvv2[3];
        char indCripto[2];
        char id_pedido[14];
        char req_signature[1];
        char id_prompt[4];
        char size_prompt[4];
        char qtd_prompt[4];
    } R2;
    
    typedef struct tR2_Iata
    {
        char id[2];
        char cvv2[3];
        char indCripto[2];
        char id_pedido[14];
        char req_signature[1];
        char vl_txa[12]; 
        char vl_pca_ent[12];
        char id_prompt[4];
        char size_prompt[4];
        char qtd_prompt[4];
    } R2_Iata;

    typedef struct tTS
    {
        char id[2];
        char indCripto[2];
        char transactionId[4];
    } TS;

    typedef struct tVF
    {
        char id[2];
        char cvv2[5];
        char indCripto[2];
        char id_pedido[14];
        char saldo_parcial[1];
        char cod_veiculo[8];
        char cod_condutor[8];
        char tipo_servico[2];
        char cod_combustivel[2];
        char litragem[7];
        char quilometragem[10];
    } VF;

    typedef struct tVI
    {
        char id[2];
        char indCripto[2];
        char transactionId[4];
    } VI;

    typedef struct tVO
    {
        char id[2];
        char cvv2[5];
        char indCripto[2];
        char id_pedido[14];
        char saldo_parcial[1];
    } VO;
    
    typedef struct tNOIDI
    {
        char vl_txa[12];
        char vl_pca_ent[12];
    } NOIDI;

    typedef struct tNOIDII
    {
        char vl_txa[12];
    } NOIDII;
    
    typedef struct tDC
    {
        char id[2];
        char cvv2[3];
        char indCripto[2];
        char id_pedido[14];
    } DC;

    typedef union uBit48
    {
        R1 r1;
        R2 r2;
        R1_Iata r1_iata;
        R2_Iata r2_iata;
        AD ad;
        ADII adii;
        ADIII adiii;
        AVS avs;
        CP cp;
        DO doff;
        CO co;
        NE ne;
        PA pa;
        PAA paa;
        PI pi;
        PII pii;
        PIII piii;
        PIV piv;
        PC pc;
        TS ts;
        VF vf;
        VI vi;
        VO vo;
        NOIDI noidi;
        NOIDII noidii;
        DC dc;
    } Bit48;
    
    typedef struct tPrompt
    {
        char id[4];
        char size[4];
        char data[32];
    } Prompt;

    typedef struct tCriptLegado
    {
        char tipo[1];
        char cart[1];
    } CriptLegado;

    class Bit48Parser : public dataManip::Command
    {
        public:

            Bit48Parser( );
            virtual ~Bit48Parser( );
            Bit48Parser& setSourceFieldPath( const std::string& a_path );
            Bit48Parser& setTargetFieldPath( const std::string& a_path );
            Bit48Parser& setLocalFieldPath( const std::string& a_path );
            dataManip::Command* clone( ) const;
            bool init( );
            void finish( );
            int execute( bool& a_stop );

        private:

            bool startConfiguration( const configBase::Tag* a_tag );
            bool processa_bit48( std::ostringstream &l_log );
            void processa_bit48_ad( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_adii( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_adiii( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_avs( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_co( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_cp( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_do( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_ne( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_pa( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_paa( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_pi( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_pii( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_piii( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_piv( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_pc( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_r1( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_r1_iata( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_r2( const std::string &l_bit48, Bit48 &l_fields, std::vector<Prompt> l_prompt, int m_versao_aplicativo );
            void processa_bit48_r2_iata( const std::string &l_bit48, Bit48 &l_fields, std::vector<Prompt> l_prompt, int m_versao_aplicativo );
            void processa_bit48_ts( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_vf( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_vi( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_vo( const std::string &l_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void processa_bit48_noidi( const std::string &l_bit48, Bit48 &l_fields );
            void processa_bit48_noidii( const std::string &l_bit48, Bit48 &l_fields );
            void processa_bit48_estatistica( const std::string &l_bit48, int m_versao_aplicativo );
            void processa_bit48_baixaOS( const std::string &l_bit48 );
            void processa_bit48_dc( const std::string &l_bit48, Bit48 &l_fields );
            void processa_prompt( const std::string &l_bit48, std::vector<Prompt> prompt );
            void insere_prompt( const std::string &l_bit48, std::vector<Prompt> prompt );
            std::string processa_tag( const std::string &m_bit48, const std::string &m_tag );
            void obtem_indCripto_ad( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_adii( const std::string &m_bit48, Bit48 &l_fields );
            void obtem_indCripto_adiii( const std::string &m_bit48, Bit48 &l_fields );
            void obtem_indCripto_avs( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_co( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_cp( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_do( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_ne( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_pa( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_paa( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_pi( const std::string &m_bit48, Bit48 &l_fields );
            void obtem_indCripto_pii( const std::string &m_bit48, Bit48 &l_fields );
            void obtem_indCripto_piii( const std::string &m_bit48, Bit48 &l_fields );
            void obtem_indCripto_pc( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_r1( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_r1_iata( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_r2( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_r2_iata( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_ts( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_vf( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_vi( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_vo( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo );
            void obtem_indCripto_dc( const std::string &m_bit48, Bit48 &l_fields );
            void monta_indCripto( CriptLegado &l_legado, unsigned char *l_indCripto );
            void processaFieldSet_ad( Bit48 &l_fields, const long &m_pcode, int m_versao_aplicativo );
            void processaFieldSet_adii( Bit48 &l_fields );
            void processaFieldSet_adiii( Bit48 &l_fields );
            void processaFieldSet_avs( Bit48 &l_fields );
            void processaFieldSet_co( Bit48 &l_fields );
            void processaFieldSet_cp( Bit48 &l_fields );
            void processaFieldSet_do( Bit48 &l_fields );
            void processaFieldSet_ne( Bit48 &l_fields );
            void processaFieldSet_pa( Bit48 &l_fields );
            void processaFieldSet_paa( Bit48 &l_fields );
            void processaFieldSet_pi( Bit48 &l_fields );
            void processaFieldSet_pii( Bit48 &l_fields );
            void processaFieldSet_piii( Bit48 &l_fields );
            void processaFieldSet_piv( Bit48 &l_fields );
            void processaFieldSet_pc( Bit48 &l_fields );
            void processaFieldSet_r1( Bit48 &l_fields );
            void processaFieldSet_r1_iata( Bit48 &l_fields );
            void processaFieldSet_r2( Bit48 &l_fields, std::vector<Prompt> l_prompt );
            void processaFieldSet_r2_iata( Bit48 &l_fields, std::vector<Prompt> l_prompt );
            void processaFieldSet_ts( Bit48 &l_fields );
            void processaFieldSet_vf( Bit48 &l_fields );
            void processaFieldSet_vi( Bit48 &l_fields );
            void processaFieldSet_vo( Bit48 &l_fields );
            void processaFieldSet_noidi( Bit48 &l_fields );
            void processaFieldSet_noidii( Bit48 &l_fields );
            void processaFieldSet_dc( Bit48 &l_fields );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;
            std::string m_is_reversal;
            std::string m_is_void;
            std::string m_bit48;
            long m_msgtype;
            long m_pcode;
            long m_versao_aplicativo;
            
            fieldSet::ConstFieldAccess m_common_is_reversal;
            fieldSet::ConstFieldAccess m_common_is_void;
            fieldSet::ConstFieldAccess m_shc_msg_msgtype;
            fieldSet::ConstFieldAccess m_shc_msg_pcode;
            fieldSet::ConstFieldAccess m_common_bit48;
            fieldSet::ConstFieldAccess m_common_versao_aplicativo;
            fieldSet::FieldAccess m_cvv2;
            fieldSet::FieldAccess m_indCripto;
            fieldSet::FieldAccess m_tipoCriptLegado;
            fieldSet::FieldAccess m_cartCriptLegado;
            fieldSet::FieldAccess m_id_pedido;
            fieldSet::FieldAccess m_req_signature;
            fieldSet::FieldAccess m_cap_referal;
            fieldSet::FieldAccess m_num_prompts_rf;
            fieldSet::FieldAccess m_vl_txa;
            fieldSet::FieldAccess m_vl_pca_ent;
            fieldSet::FieldAccess m_cap_positive_conf;
            fieldSet::FieldAccess m_num_prompts_cp;
            fieldSet::FieldAccess m_cap_data_positive_conf;
            fieldSet::FieldAccess m_dados_coletados;
            fieldSet::FieldAccess m_avs_cep;
            fieldSet::FieldAccess m_avs_end_fat;
            fieldSet::FieldAccess m_avs_cpf;
            fieldSet::FieldAccess m_saldo_parcial;
            fieldSet::FieldAccess m_cod_veiculo;
            fieldSet::FieldAccess m_cod_condutor;
            fieldSet::FieldAccess m_tipo_servico;
            fieldSet::FieldAccess m_cod_combustivel;
            fieldSet::FieldAccess m_litragem;
            fieldSet::FieldAccess m_quilometragem;
            fieldSet::FieldAccess m_transactionId;
            fieldSet::FieldAccess m_pdv_trn_id;
            fieldSet::FieldAccess m_statistics;
            fieldSet::FieldAccess m_bit63;
    };
}
