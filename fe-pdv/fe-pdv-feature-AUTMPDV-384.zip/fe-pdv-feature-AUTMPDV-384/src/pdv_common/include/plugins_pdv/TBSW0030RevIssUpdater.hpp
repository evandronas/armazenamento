#pragma once

#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0030RevIssUpdater( );

    class TBSW0030RevIssUpdater : public dataManip::Command
    {
        public:

            TBSW0030RevIssUpdater( );
            virtual ~TBSW0030RevIssUpdater( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0030RevIssUpdater& setSourceFieldPath( const std::string& a_path );
            TBSW0030RevIssUpdater& setTargetFieldPath( const std::string& a_path );
            TBSW0030RevIssUpdater& setLocalFieldPath( const std::string& a_path );

        private:

            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_issuer;
            fieldSet::ConstFieldAccess m_nom_site_issr;
            fieldSet::ConstFieldAccess m_nom_fe_issr;
            fieldSet::ConstFieldAccess m_nom_host_issr;
            fieldSet::ConstFieldAccess m_settlement_date;
            fieldSet::ConstFieldAccess m_iss_name;
            fieldSet::ConstFieldAccess m_mc_info_ica;
            fieldSet::ConstFieldAccess quemNegou;
            fieldSet::ConstFieldAccess codigoAcquirer;
            fieldSet::ConstFieldAccess codigoIssuer;
            fieldSet::ConstFieldAccess codigoOrigemRespostaAutorizacao;
            fieldSet::ConstFieldAccess categoriaMensagem;
    };
}

