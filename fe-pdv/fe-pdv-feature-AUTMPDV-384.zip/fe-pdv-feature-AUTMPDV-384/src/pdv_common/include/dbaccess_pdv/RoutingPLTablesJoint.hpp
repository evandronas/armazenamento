#pragma once
#include <string>
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_pdv
{
	class RoutingPLTablesJoint : public dbaccess::table
	{
	public:
		RoutingPLTablesJoint();
		RoutingPLTablesJoint( const std::string &str );
		virtual ~RoutingPLTablesJoint();

		void bind_columns( );

        // TBSW0044
        unsigned long       get_NUM_PDV() const;
        oasis_dec_t         get_NUM_BIN_INI() const;
        oasis_dec_t         get_NUM_BIN_FIM() const;
        unsigned long       get_COD_EMSR() const;
        const std::string&  get_COD_STTU_TRAN() const;
        dbm_datetime_t      get_DAT_ATLZ_REG() const;
        const std::string&  get_COD_USR_ATLZ_REG() const;
        const std::string&  get_IND_STTU_REG() const;
        // TBSW2011
        unsigned long       get_COD_ISSR_SW() const;
        const std::string&  get_NOM_EMSR_SW() const;
        unsigned long       get_COD_EMSR_SW() const;
        unsigned long       get_COD_BNDR() const;
        unsigned long       get_COD_FE_EMSR() const;
        // TBSW2013
        unsigned long       get_COD_ROTA_PRVT_LBEL() const;
        const std::string&  get_NETWORK_ID() const;
        const std::string&  get_NOM_FE_ACQR() const;
        const std::string&  get_NOM_HOST_ACQR() const;

        std::string getSelect( )
        {
            return this->get_sql_select();
        }

	private:
        // TBSW0044
        unsigned long       m_NUM_PDV;
        oasis_dec_t         m_NUM_BIN_INI;
        oasis_dec_t         m_NUM_BIN_FIM;
        unsigned long       m_COD_EMSR;
        std::string         m_COD_STTU_TRAN;
        dbm_datetime_t      m_DAT_ATLZ_REG;
        std::string         m_COD_USR_ATLZ_REG;
        std::string         m_IND_STTU_REG;
        // TBSW2011
        unsigned long       m_COD_ISSR_SW;
        std::string         m_NOM_EMSR_SW;
        unsigned long       m_COD_EMSR_SW;
        unsigned long       m_COD_BNDR;
        unsigned long       m_COD_FE_EMSR;
        // TBSW2013
        unsigned long       m_COD_ROTA_PRVT_LBEL;
        std::string         m_NETWORK_ID;
        std::string         m_NOM_FE_ACQR;
        std::string         m_NOM_HOST_ACQR;

        // TBSW0044
        int m_NUM_PDV_pos;
        int m_NUM_BIN_INI_pos;
        int m_NUM_BIN_FIM_pos;
        int m_COD_EMSR_pos;
        int m_COD_STTU_TRAN_pos;
        int m_DAT_ATLZ_REG_pos;
        int m_COD_USR_ATLZ_REG_pos;
        int m_IND_STTU_REG_pos;
        // TBSW2011
        int m_COD_ISSR_SW_pos;
        int m_NOM_EMSR_SW_pos;
        int m_COD_EMSR_SW_pos;
        int m_COD_BNDR_pos;
        int m_COD_FE_EMSR_pos;
        // TBSW2013
        int m_COD_ROTA_PRVT_LBEL_pos;
        int m_NETWORK_ID_pos;
        int m_NOM_FE_ACQR_pos;
        int m_NOM_HOST_ACQR_pos;
        
	};
}
