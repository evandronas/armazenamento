/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once

#include<TBSW0102RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class Tbsw0102RegrasFormatacao : public TBSW0102RegrasFormatacaoBase
    {
        public:
            Tbsw0102RegrasFormatacao( );
            ~Tbsw0102RegrasFormatacao( );
    };
}
