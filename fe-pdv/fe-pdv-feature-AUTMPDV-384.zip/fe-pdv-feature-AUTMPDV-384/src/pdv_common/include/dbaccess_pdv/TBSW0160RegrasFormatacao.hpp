#pragma once

#include<TBSW0160RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
	class TBSW0160RegrasFormatacao : public TBSW0160RegrasFormatacaoBase
	{
	public:
		TBSW0160RegrasFormatacao( );
		~TBSW0160RegrasFormatacao( );
	};
}