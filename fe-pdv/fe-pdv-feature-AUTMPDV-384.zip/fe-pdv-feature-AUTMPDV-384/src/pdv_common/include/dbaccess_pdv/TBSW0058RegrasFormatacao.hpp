#pragma once

#include<TBSW0058RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
	class TBSW0058RegrasFormatacao : public TBSW0058RegrasFormatacaoBase
	{
	public:
		TBSW0058RegrasFormatacao( );
		~TBSW0058RegrasFormatacao( );
        void insert_IND_RD_CPTR( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params );
	};
}