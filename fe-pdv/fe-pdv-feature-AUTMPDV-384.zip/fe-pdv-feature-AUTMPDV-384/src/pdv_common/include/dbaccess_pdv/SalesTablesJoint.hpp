#pragma once
#include <string>
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_pdv
{
    class SalesTablesJoint : public dbaccess::table
    {
    public:
        SalesTablesJoint();
        SalesTablesJoint( const std::string &str );
        virtual ~SalesTablesJoint();

        void bind_columns( );

        void set_NUM_RV( oasis_dec_t a_NUM_RV );
        void set_NUM_PDV( unsigned long a_NUM_PDV );
        void set_IND_NUM_QBRA( unsigned long a_IND_NUM_QBRA );
        void set_DAT_RV( dbm_datetime_t a_DAT_RV );
        void set_COD_BNDR( unsigned long a_COD_BNDR );
        void set_NOM_BNDR( const std::string& a_NOM_BNDR );
        void set_COD_PROD( long a_COD_PROD );
        void set_NOM_PROD( const std::string& a_NOM_PROD );
        void set_QTD_CV( oasis_dec_t a_QTD_CV );
        void set_VAL_TOTL_LQDO( oasis_dec_t a_VAL_TOTL_LQDO );
        void set_VAL_TOTL_DSCT( oasis_dec_t a_VAL_TOTL_DSCT );
        void set_VAL_TOTL_GRJT( oasis_dec_t a_VAL_TOTL_GRJT );
        void set_VAL_TOTL_PAGO( oasis_dec_t a_VAL_TOTL_PAGO );
        void set_DAT_CRE_RV( dbm_datetime_t a_DAT_CRE_RV );
        void set_VAL_SIT_RVS( unsigned long a_VAL_SIT_RVS );
        void set_DTH_INI( dbm_datetime_t a_DTH_INI );
        void set_DTH_FIM( dbm_datetime_t a_DTH_FIM );
        void set_QTD_PRCL( unsigned long a_QTD_PRCL );
        void set_VAL_ENTR( oasis_dec_t a_VAL_ENTR );
        void set_VAL_TX_SERV_RVS( oasis_dec_t a_VAL_TX_SERV_RVS );
        void set_VAL_FLAG_QBRA( const std::string& a_VAL_FLAG_QBRA );
        void set_COD_TCNL( const std::string& a_COD_TCNL );
        void set_COD_TERM( const std::string& a_COD_TERM );
        void set_NUM_STAN( unsigned long a_NUM_STAN );
        void set_COD_CMPM_TRAN( unsigned long a_COD_CMPM_TRAN );
        void set_VAL_SQUE( oasis_dec_t a_VAL_SQUE );
        void set_VAL_PRES_BRTO( oasis_dec_t a_VAL_PRES_BRTO );
        void set_VAL_RMNR_RCD( oasis_dec_t a_VAL_RMNR_RCD );
        void set_VAL_IOF( oasis_dec_t a_VAL_IOF );
        void set_VAL_CPMF( oasis_dec_t a_VAL_CPMF );
        void set_VAL_TAC( oasis_dec_t a_VAL_TAC );
        void set_TIP_IOF( const std::string& a_TIP_IOF );
        void set_NUM_PRCL( long a_NUM_PRCL );
        void set_VAL_PRCL( oasis_dec_t a_VAL_PRCL );
        void set_DAT_PRCL( dbm_datetime_t a_DAT_PRCL );

        oasis_dec_t get_NUM_RV() const;
        unsigned long get_NUM_PDV() const;
        unsigned long get_IND_NUM_QBRA() const;
        dbm_datetime_t get_DAT_RV() const;
        unsigned long get_COD_BNDR() const;
        const std::string& get_NOM_BNDR() const;
        long get_COD_PROD() const;
        const std::string& get_NOM_PROD() const;
        oasis_dec_t get_QTD_CV() const;
        oasis_dec_t get_VAL_TOTL_LQDO() const;
        oasis_dec_t get_VAL_TOTL_DSCT() const;
        oasis_dec_t get_VAL_TOTL_GRJT() const;
        oasis_dec_t get_VAL_TOTL_PAGO() const;
        dbm_datetime_t get_DAT_CRE_RV() const;
        unsigned long get_VAL_SIT_RVS() const;
        dbm_datetime_t get_DTH_INI() const;
        dbm_datetime_t get_DTH_FIM() const;
        unsigned long get_QTD_PRCL() const;
        oasis_dec_t get_VAL_ENTR() const;
        oasis_dec_t get_VAL_TX_SERV_RVS() const;
        const std::string& get_VAL_FLAG_QBRA() const;
        const std::string& get_COD_TCNL() const;
        const std::string& get_COD_TERM() const;
        unsigned long get_NUM_STAN() const;
        unsigned long get_COD_CMPM_TRAN() const;
        oasis_dec_t get_VAL_SQUE() const;
        oasis_dec_t get_VAL_PRES_BRTO() const;
        oasis_dec_t get_VAL_RMNR_RCD() const;
        oasis_dec_t get_VAL_IOF() const;
        oasis_dec_t get_VAL_CPMF() const;
        oasis_dec_t get_VAL_TAC() const;
        const std::string& get_TIP_IOF() const;
		long get_NUM_PRCL() const;
        oasis_dec_t get_VAL_PRCL() const;
        dbm_datetime_t get_DAT_PRCL() const;

    private:		
        // Colunas da tabela TBSW0045
        oasis_dec_t         m_NUM_RV;
        unsigned long       m_NUM_PDV;
        unsigned long       m_IND_NUM_QBRA;
        dbm_datetime_t      m_DAT_RV;
        unsigned long       m_COD_BNDR;
        std::string         m_NOM_BNDR;
        long       			m_COD_PROD;
        std::string         m_NOM_PROD;
        oasis_dec_t         m_QTD_CV;
        oasis_dec_t         m_VAL_TOTL_LQDO;
        oasis_dec_t         m_VAL_TOTL_DSCT;
        oasis_dec_t         m_VAL_TOTL_GRJT;
        oasis_dec_t         m_VAL_TOTL_PAGO;
        dbm_datetime_t      m_DAT_CRE_RV;
        unsigned long       m_VAL_SIT_RVS;
        dbm_datetime_t      m_DTH_INI;
        dbm_datetime_t      m_DTH_FIM;
        unsigned long       m_QTD_PRCL;
        oasis_dec_t         m_VAL_ENTR;
        oasis_dec_t         m_VAL_TX_SERV_RVS;
        std::string         m_VAL_FLAG_QBRA;
        std::string         m_COD_TCNL;
        std::string         m_COD_TERM;
        unsigned long       m_NUM_STAN;
        unsigned long       m_COD_CMPM_TRAN;
        oasis_dec_t         m_VAL_SQUE;
        oasis_dec_t         m_VAL_PRES_BRTO;
        oasis_dec_t         m_VAL_RMNR_RCD;
        oasis_dec_t         m_VAL_IOF;
        oasis_dec_t         m_VAL_CPMF;
        oasis_dec_t         m_VAL_TAC;
        std::string         m_TIP_IOF;
        // Colunas da tabela TBSW0046
        long                m_NUM_PRCL;
        oasis_dec_t         m_VAL_PRCL;
        dbm_datetime_t      m_DAT_PRCL;
		
		int m_IND_NUM_QBRA_pos;  
		int m_COD_BNDR_pos;
		int m_COD_PROD_pos;
		int m_QTD_PRCL_pos;
		int m_VAL_FLAG_QBRA_pos;
		int m_NOM_BNDR_pos;  
		int m_NOM_PROD_pos;
		int m_NUM_RV_pos;		
		int m_NUM_PDV_pos;
		int m_DAT_RV_pos;  
		int m_DTH_INI_pos;
		int m_DTH_FIM_pos;  
		int m_QTD_CV_pos;	
		int m_VAL_TOTL_PAGO_pos;
		int m_VAL_TOTL_DSCT_pos;		
		int m_VAL_TOTL_LQDO_pos;
		int m_DAT_CRE_RV_pos;
		int m_VAL_IOF_pos;		
        int m_TIP_IOF_pos;
        int m_VAL_CPMF_pos;	
        int m_VAL_TOTL_GRJT_pos;
        int m_VAL_SIT_RVS_pos;     
        int m_VAL_ENTR_pos;		
        int m_VAL_TX_SERV_RVS_pos;
        int m_COD_TCNL_pos;
        int m_COD_TERM_pos;		
        int m_NUM_STAN_pos;
        int m_COD_CMPM_TRAN_pos;
        int m_VAL_SQUE_pos;		
        int m_VAL_PRES_BRTO_pos;		
        int m_VAL_RMNR_RCD_pos;		
        int m_VAL_TAC_pos;
        int m_VAL_PRCL_pos;
		int m_DAT_PRCL_pos;
		int m_NUM_PRCL_pos;	
    };
} // namespace dbaccess_pdv
