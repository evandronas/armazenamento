#pragma once

#include <TBSW0139RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0139RegrasFormatacao : public TBSW0139RegrasFormatacaoBase
    {
        public:
            TBSW0139RegrasFormatacao( );
            ~TBSW0139RegrasFormatacao( );
            void insert_NUM_VERS_SRVD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
            void insert_NUM_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params );
    };
}
