/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once

#include<TBSW0101RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class Tbsw0101RegrasFormatacao : public TBSW0101RegrasFormatacaoBase
    {
        public:
            Tbsw0101RegrasFormatacao( );
            ~Tbsw0101RegrasFormatacao( );
    };
}
