#pragma once

#include <TBSW1039RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW1039RegrasFormatacao : public TBSW1039RegrasFormatacaoBase
    {
        public:
            TBSW1039RegrasFormatacao( );
            ~TBSW1039RegrasFormatacao( );

            void insert_COD_ISTT_ACQR_ORGL( dbaccess_common::TBSW1039& tbsw1039, const struct acq_common::tbsw1039_params& tbsw1039_params );
    };
}
