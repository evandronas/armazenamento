#pragma once

#include <TBSW0152RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0152RegrasFormatacao : public TBSW0152RegrasFormatacaoBase
    {
        public:
            TBSW0152RegrasFormatacao( );
            ~TBSW0152RegrasFormatacao( );
            void insert_VAL_PRCL_ENTR( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
            void insert_VAL_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
            void update_VAL_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
    };
}