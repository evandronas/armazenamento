/* Copyright 2019 Rede S.A.
Autor : Fernando Brum
Empresa : Rede
*/

#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_pdv
{
    /// Tbsw0165
    /// Tabela para armazenar dados do Facilitador
    /// EF/ET: ET1
    /// Histórico: [Data] – [Autor] - ET - Descrição
    /// 28/08/2019 – Fernando Brum - ET1 - Criacao da versao inicial
    class Tbsw0165 : public dbaccess::table
    {
        public:
            Tbsw0165( );
            Tbsw0165( std::string whereParam );
            ~Tbsw0165( );
            void SetWhereCondition( const std::string& value );
            void SetQueryFields( const std::string& value );

            void bind_columns( );  // metodo herdado da classe base

            void clearFields();
            void SetNumeroSequencialUnico( const unsigned long value );
            void SetDataMovimentoTransacao( const unsigned long value );
            void SetPaymentFacilitator( oasis_dec_t value );
            void SetCodigoSubLojista( const std::string& value );
            void SetNomeSubLojista( const std::string& value );
            void SetEnderecoSubLojista( const std::string& value );
            void SetCidadeSubLojista( const std::string& value );
            void SetEstadoSubLojista( const std::string& value );
            void SetPaisSubLojista( const std::string& value );
            void SetCepSubLojista( oasis_dec_t value );
            void SetCnpjSubLojista( oasis_dec_t value );
            
            const unsigned long GetDataMovimentoTransacao() const;
            const unsigned long GetNumeroSequencialUnico() const;
            oasis_dec_t GetPaymentFacilitator() const;
            const std::string& GetCodigoSubLojista() const;
            const std::string& GetNomeSubLojista() const;
            const std::string& GetEnderecoSubLojista() const;
            const std::string& GetCidadeSubLojista() const;
            const std::string& GetEstadoSubLojista() const;
            const std::string& GetPaisSubLojista() const;
            oasis_dec_t GetCepSubLojista() const;
            oasis_dec_t GetCnpjSubLojista() const;

        private:
            // table fields
            unsigned long     numeroSequencialUnico;    // NUM_SEQ_UNC          NUMBER(12)
            unsigned long     dataMovimentoTransacao;   // DAT_MOV_TRAN         NUMBER(8)
            oasis_dec_t       paymentFacilitator;       // ID_FACR_PGMN_BNDR    NUMBER(11)
            std::string       codigoSubLojista;         // COD_SMRC             CHAR(15)
            std::string       nomeSubLojista;           // NOM_SMRC             CHAR(22)
            std::string       enderecoSubLojista;       // DES_ENDR_SMRC        CHAR(48)
            std::string       cidadeSubLojista;         // NOM_CID_SMRC         CHAR(13)
            std::string       estadoSubLojista;         // SGL_EST_SMRC         CHAR(3)
            std::string       paisSubLojista;           // COD_PAIS_SMRC        CHAR(3)
            oasis_dec_t       cepSubLojista;            // NUM_CEP_SMRC         NUMBER(10)
            oasis_dec_t       cnpjSubLojista;           // NUM_CNPJ_SMRC        NUMBER(15)

            int numeroSequencialUnicoPosicao;
            int dataMovimentoTransacaoPosicao;
            int paymentFacilitatorPosicao;
            int codigoSubLojistaPosicao;
            int nomeSubLojistaPosicao;
            int enderecoSubLojistaPosicao;
            int cidadeSubLojistaPosicao;
            int estadoSubLojistaPosicao;
            int paisSubLojistaPosicao;
            int cepSubLojistaPosicao;
            int cnpjSubLojistaPosicao;
            
            int paymentFacilitatorNulo;
            int cepSubLojistaNulo;
            int cnpjSubLojistaNulo;
    }; // class Tbsw0165

} // namespace dbaccess_pdv
