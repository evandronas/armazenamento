#pragma once

#include<TBSW0083RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
	class TBSW0083RegrasFormatacao : public TBSW0083RegrasFormatacaoBase
	{
	public:
		TBSW0083RegrasFormatacao( );
		~TBSW0083RegrasFormatacao( );
	};
}