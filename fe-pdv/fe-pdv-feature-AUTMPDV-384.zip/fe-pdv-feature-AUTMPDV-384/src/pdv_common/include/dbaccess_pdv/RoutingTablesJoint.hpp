#pragma once
#include <string>
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_pdv
{
	class RoutingTablesJoint : public dbaccess::table
	{
	public:
		RoutingTablesJoint();
		RoutingTablesJoint( const std::string &str );
		virtual ~RoutingTablesJoint();

		void bind_columns( );

		long getCOD_ROTA( ) const;
		const std::string& getNUM_BIN_CAR_INI( ) const;
		const std::string& getNUM_BIN_CAR_FIM( ) const;
		long getCOD_ISSR_SW( ) const;
		const std::string& getCOD_TIP_TRAN( ) const;
		long getIND_PRRD( ) const;
		const std::string& getNETWORK_ID( ) const;
		const std::string& getNETWORK_ID_VAN( ) const;
		const std::string& getNOM_HOST_ACQR( ) const;
		const std::string& getNOM_FE_ACQR( ) const;
		const std::string& getNOM_EMSR_SW( ) const;
		long getCOD_EMSR_SW( ) const;
		long getCOD_BNDR( ) const;
		long getCOD_FE_EMSR( ) const;

	private:
		int m_COD_ROTA_pos;
		int m_NUM_BIN_CAR_INI_pos;
		int m_NUM_BIN_CAR_FIM_pos;
		int m_COD_ISSR_SW_pos;
		int m_COD_TIP_TRAN_pos;
		int m_IND_PRRD_pos;
		int m_NETWORK_ID_pos;
		int m_NETWORK_ID_VAN_pos;
		int m_NOM_HOST_ACQR_pos;
		int m_NOM_FE_ACQR_pos;
		int m_NOM_EMSR_SW_pos;
		int m_COD_EMSR_SW_pos;
		int m_COD_BNDR_pos;
		int m_COD_FE_EMSR_pos;

		long m_COD_ROTA;
		std::string m_NUM_BIN_CAR_INI;
		std::string m_NUM_BIN_CAR_FIM;
		long m_COD_ISSR_SW;
		std::string m_COD_TIP_TRAN;
		long m_IND_PRRD;
		std::string m_NETWORK_ID;
		std::string m_NETWORK_ID_VAN;
		std::string m_NOM_HOST_ACQR;
		std::string m_NOM_FE_ACQR;
		std::string m_NOM_EMSR_SW;
		long m_COD_EMSR_SW;
		long m_COD_BNDR;
		long m_COD_FE_EMSR;
	};
}
