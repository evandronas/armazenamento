from conans import ConanFile, tools
import os

class ResolveDependency(ConanFile):
    settings = "os", "compiler", "build_type", "arch"
    description = "FE-PDV APLICATION"
    url = "http://gitlab.prd.useredecloud/SW7/autorizador/aplicacao/online/fe-pdv"
    license = "None"
    author = "RT Autorizador"
    topics = ("sw7", "online", "fe", "pdv")

    REQ_FEPDVLIB = "sw7-autorizador-aplicacao-online-libs-fe-pdv-lib/" + os.getenv("req_fepdvlib") + "@SW7/rede"
    REQ_FEPDVMONLIB = "sw7-autorizador-aplicacao-online-libs-fe-pdv-monlib/" + os.getenv("req_fepdvmonlib") + "@SW7/rede"
    requires = REQ_FEPDVLIB, REQ_FEPDVMONLIB

    def imports(self):
        self.copy("*", dst="include", src="include")
        self.copy("*", dst="lib", src="lib")

    def package_info(self):
        self.cpp_info.libs = tools.collect_libs(self)
