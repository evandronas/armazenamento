#!/usr/bin/bash

SOURCE_DIR="/opt/rpm/SW7/autorizador/aplicacao/ferramentas/fepdvutilities/build/*"
TARGET_DIR="/home/SW/PDV/bin"

for file in $SOURCE_DIR; do
    rm -f "${TARGET_DIR}/${basename $file}"
done

echo "[rpm] The package has been uninstalled"

exit 0
