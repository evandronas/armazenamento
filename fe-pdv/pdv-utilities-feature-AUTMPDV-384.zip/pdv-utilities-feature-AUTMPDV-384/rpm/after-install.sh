#!/usr/bin/bash

set -x

{
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep region| awk '{print $3}'|sed  's/"//g'|sed 's/,//g')
AMBIENTE=$(/usr/local/bin/aws ssm get-parameter --name "ambiente" --region $REGION --output text | awk '{ print $7 }')
SW_GROUP="Sistemas"

SOURCE_DIR="/opt/rpm/SW7/autorizador/aplicacao/ferramentas/fepdvutilities/build/*"
TARGET_DIR="/home/SW/PDV/bin"

mkdir -p "$TARGET_DIR"

for file in $SOURCE_DIR; do
    cp -vf "$file" "$TARGET_DIR"
done

# Permissions
chown -R swoper_appl_${AMBIENTE}:${SW_GROUP} $TARGET_DIR/*

chmod -R 774 $TARGET_DIR

echo "[rpm] The package has been installed"
} > /tmp/batch_ferramentas_fepdvutilities_after-install.log 2>&1

set +x

exit 0
