/*
Copyright 2015 Rede S.A.
*************************************************************
Nome     : Mask_ELO_Interpreter.cpp
Descri��o: Classe responsavel pela interpreta�ao do Log ELO com mascaramento
Autor    : Fabio Mazzer e Diogo Fernandes
Data     : 15/02/2015
Empresa  : Rede
Descri��o: Multicaptura ELO
ID       : 91915 - SW Multicaptura ELO
*************************************************************
*/

#include "MaskEloInterpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include "onvertEBCDICtoASCII.h"
#include "FilterHandler.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

// Construtor
MaskEloInterpreter::MaskEloInterpreter( int _max, int _headerSize, int _mapType ):Mask_Interpreter( _max, _headerSize, _mapType  )
{

}
// Destruidor
MaskEloInterpreter::~MaskEloInterpreter()
{

}

// Met�do principal para o parse da mensagem TCP
void MaskEloInterpreter::maskRecord( const char* _record )
{
	//Declara��o de vari�veis de controle
	int i;
	int pos = 0;
	int siz;
	int type;
	int size;
	//delcara��o e buffers
	char bufferAux[MAX_VALUE_LEN];
	char auxiliar[2048];
	char auxiliar2[2048];

	// vari�veis relativas ao DE
	int recordSize;
	recordSize = strlen(_record);

	FilterHandler conv;
	char str[2048];
	int len, lenAux;
	char cSiz [4];
	char cBit [4];

	int sizeOK;
	sizeOK = OK;
	bool isFix = TRUE;


	memset(this->retorno, 0, sizeof(this->retorno));

	// Para cada DE presente no bitmap, faz o loop para parse
	for ( i = 0; ((i < this->usedBits) && (sizeOK == OK)); i++ )
	{
		memset(bufferAux, 0, sizeof(bufferAux));
		memset(auxiliar, 0, sizeof(auxiliar));
		memset(auxiliar2, 0, sizeof(auxiliar));
		memset(str, 0, sizeof(str));
		size = 0;
		
		char sizeByte[3] = {0,};
		//Trata cada DE presente na mensagem (bitmap) de acordo com a mensageria do parceiro
		switch (this->bitsUsed[i])
		{
			//
			// Campos de tamanho fixo
			//
		
			// Campos de tamanho 12
			case 4:
			case 12:
			case 22:
			{
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 24) <= recordSize)
				{
					strncpy(auxiliar, _record+pos, 24);
					auxiliar[24] = '\0';
					pos += 24;
					isFix = TRUE;
					size=24;

					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 12);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			
			// Campos de tamanho 4
			case 14:
			case 18:
			{
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 8) <= recordSize)
				{
					strncpy(auxiliar, _record+pos, 8);
					auxiliar[8] = '\0';
					pos += 8;
					isFix = TRUE;
					size=8;

					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 4);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			

			// Campos de tamanho 3
			case 19:
			case 23:
			case 39:
			case 49:
			{
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 6) <= recordSize)
				{
					strncpy(auxiliar, _record+pos, 6);
					auxiliar[6] = '\0';
					pos += 6;
					isFix = TRUE;
					size=6;

					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 3);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			


			// Campos de tamanho 6
			case 3:
			case 11:
			case 38:
			{
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 12) <= recordSize)
				{
					strncpy(auxiliar, _record+pos, 12);
					auxiliar[12] = '\0';
					pos += 12;
					isFix = TRUE;
					size=12;

					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 6);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			
			// Campos de tamanho 8
			case 41:
			case 52:
			case 64:
			{
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 16) <= recordSize)
				{
					strncpy(auxiliar, _record+pos, 16);
					auxiliar[16] = '\0';
					pos += 16;
					isFix = TRUE;
					size=16;

					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 8);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			


			// Campos de tamanho 10
			case 7:
			{
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 20) <= recordSize)
				{
					strncpy(auxiliar, _record+pos, 20);
					auxiliar[20] = '\0';
					pos += 20;
					isFix = TRUE;
					size=20;

					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 10);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			
			// Campos de tamanho 15
			case 42:
			{
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 30) <= recordSize)
				{
					strncpy(auxiliar, _record+pos, 30);
					auxiliar[30] = '\0';
					pos += 30;
					isFix = TRUE;
					size=30;

					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 15);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}
				}
				else
					sizeOK = NOK;
				break;
			}		
			
			

			// CAMPOS DE TAMANHO LLVAR
			case 32:
			case 34:
			case 43:
			{
				type = 1;
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 4) <= recordSize)
				{
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
				}
				if ((pos + 4 + size) <= recordSize)
				{
					strncat(auxiliar, _record+pos, 4);
					pos += 4;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+4] = '\0';
					pos += size;
					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						size = (size + 4)/2;
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
						strcpy(auxiliar, auxiliar2);
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			
			// CAMPOS DE TAMANHO LLVAR BINARIO
			case 53:
			{
				type = 1;
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 4) <= recordSize)
				{
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
				}
				if ((pos + 4 + size) <= recordSize)
				{
					strncat(auxiliar, _record+pos, 4);
					pos += 4;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+4] = '\0';
					pos += size;
				}
				else
					sizeOK = NOK;
				break;
			}			
			// CAMPOS DE TAMANHO LLLVAR
			case 48:
			case 54:
			case 60:
			case 61:
			{
				type = 2;
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 6) <= recordSize)
				{
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';
					siz =  atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
				}
				if ((pos + 6 + size) <= recordSize)
				{
					strncat(auxiliar, _record+pos, 6);
					pos += 6;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					pos += size;
					// Caso apresenta��o em tela, converte formato
					if ( this->getFlagDisplay() != 0 ) {
						size = (size+ 6 )/2;
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
						strcpy(auxiliar, auxiliar2);
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			// CAMPOS DE TAMANHO LLLVAR BINARIO
			case 55:
			{
				type = 2;
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 6) <= recordSize)
				{
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';
					siz =  atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
				}
				if ((pos + 6 + size) <= recordSize)
				{
					strncat(auxiliar, _record+pos, 6);
					pos += 6;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					pos += size;
				}
				else
					sizeOK = NOK;
				break;
			}
			//
			// Campos de tamanho com mascaramento
			//
			// PAN	
			case 2:
			{
				type = 1;
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 4) <= recordSize)
				{
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
				}
				if ((pos + 4 + size) <= recordSize)
				{
					pos += maskFields_2102(_record+pos, auxiliar);
					if ( this->getFlagDisplay() != 0 ) {
						size = (size + 4)/2;
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
						strcpy(auxiliar, auxiliar2);
					}
				}
				else
					sizeOK = NOK;
			break;
			}
			// Trilha 2
			case 35:
			{
				type = 1;
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 4) <= recordSize)
				{
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
				}
				if ((pos + 4 + size) <= recordSize)
				{
					pos += maskFields_35(_record+pos,auxiliar);
					auxiliar[size+4] = '\0';
					if ( this->getFlagDisplay() != 0 ) {
						size = (size + 4)/2;
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
						strcpy(auxiliar, auxiliar2);
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			// Trilha 1
			case 45:
			{
				type = 1;
				// Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 4) <= recordSize)
				{
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
				}
				if ((pos + 4 + size) <= recordSize)
				{
					pos += maskFields_45(_record+pos, auxiliar);
					auxiliar[size+4] = '\0';
					if ( this->getFlagDisplay() != 0 ) {
						size = (size + 4)/2;
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
						strcpy(auxiliar, auxiliar2);
					}
				}
				else
					sizeOK = NOK;
				break;
			}
			// Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
			default:
			{
				sizeOK = NOK;
			}
		}
		
	

		if ( this->getFlagDisplay() != 0 ) {
		
			sprintf( cSiz, "%03d", size );
			sprintf( cBit, "%03d", this->bitsUsed[i] );
		}
		// Tratamento para apresneta��o de tela um DE por linha	
		if ( this->getFlagDisplay() == 1 ) {
		
			if ( sizeOK == NOK ) {
				cout << "DE [" <<  cBit << "] [ERRO]" << endl;
			}
			else
			if ( isFix == FALSE ) {
				cout << "DE [" <<  cBit << "] [V" << cSiz << "] [" << auxiliar << "]" << endl;
			}
			else {
				cout << "DE [" <<  cBit << "] [F" << cSiz << "] [" << auxiliar << "]" << endl;
			}
		}
		// Tratamento para apresneta��o de tela da mensagem em uma linha
		else
		if ( this->getFlagDisplay() == 2 ) {
		
			if ( sizeOK == NOK ) {
				cout << "DE [" <<  cBit << "] [ERRO]" << endl;
			}
			else
			if ( isFix == FALSE ) {
				cout << "DE [" <<  cBit << "] [V" << cSiz << "] [" << auxiliar << "]";
			}
			else {
				cout << "DE [" <<  cBit << "] [F" << cSiz << "] [" << auxiliar << "]";
			}
		}


		// Adiciona o DE ao buffer principal
		if (sizeOK == OK)
			strncat(this->retorno, auxiliar, strlen(auxiliar));

	} // final do for

	// Se houve algum erro retorna o registro original
	if (sizeOK == NOK)
	{
		memset(this->retorno, 0, sizeof(this->retorno));
		strncat(this->retorno, _record, strlen(_record));
	}
}
