// Mask_VISA_Interpreter.cpp: implementation of the Mask_VISA_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

/*
*********************** MODIFICA��ES ************************
Autor    : Andre Morishita
Data     : 14/07/2017
Empresa  : Leega
Descri��o: Tokenizacao MPV2
ID       : 200293
*************************************************************
Autor    : Andre Morishita
Data     : 10/08/2017
Empresa  : Leega
Descri��o: Release de bandeiras Outubro-2017 
ID       : 204705
*************************************************************
Autor    : Andre Morishita
Data     : 01/02/2018
Empresa  : Leega
Descri��o: Release de Bandeiras de Janeiro 2018 - SW75
ID       : 219278
*************************************************************
*/

#include "Mask_VISA_Interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include "onvertEBCDICtoASCII.h"
#include "FilterHandler.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_VISA_Interpreter::Mask_VISA_Interpreter( int _max, int _headerSize ):Mask_Interpreter( _max, _headerSize )
{

}

Mask_VISA_Interpreter::~Mask_VISA_Interpreter()
{

}


/////////////////////////////////////////
/**
*
*   Masks the CONFIDENTIAL fields in the record.
*
*   @param char* _record The record to be masked
*   @param char* _masked The masked record to be returned.
*
*
*////////////////////////////////////////
void Mask_VISA_Interpreter::maskRecord( const char* _record )
{
	int i;
	int pos = 0;
	int size;
	char bufferAux[MAX_VALUE_LEN];
	char auxiliar[2048];
	char auxiliar2[2048];

	int recordSize;
	recordSize = strlen(_record);

	FilterHandler conv;
	char str[2048];
	int len, lenAux;
	char c_siz [4];
	char c_bit [4];

	int sizeOK;
	sizeOK = OK;
	bool isFix = TRUE;


	memset(this->retorno, 0, sizeof(this->retorno));

	for ( i = 0; ((i < this->usedBits) && (sizeOK == OK)); i++ )
	{
		memset(bufferAux, 0, sizeof(bufferAux));
		memset(auxiliar, 0, sizeof(auxiliar));
		memset(auxiliar2, 0, sizeof(auxiliar));
		memset(str, 0, sizeof(str));
		size = 0;
		
		char size_byte[3] = {0,};

		switch (this->bitsUsed[i])
		{
			case 65: break;
			//
			// Campos de tamanho fixo
			//

			// Campos de tamanho 02
			case 25:
			{
                if ((pos + 2) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 2);
    	            auxiliar[2] = '\0';
					pos += 2;
					size = 2;
					isFix = TRUE;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 04
			case 13:
			case 14:
			case 15:
			case 18:
			case 19:
			case 22:
			case 23:
			case 49:
			case 50:
			case 51:
			case 70:
            {
                if ((pos + 4) <= recordSize)
                {
                    strncpy(auxiliar, _record+pos, 4);
                    auxiliar[4] = '\0';
                    pos += 4;
                    isFix = TRUE;
                    size=4;
                }
                else
                    sizeOK = NOK;
                break;
            }


			case 39:
			{
                if ((pos + 4) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 4);
        	        auxiliar[4] = '\0';
					pos += 4;
					isFix = TRUE;
					size=4;
					if ( this->getFlagDisplay() != 0 ) {
                    	conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
                    	conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
                    	auxiliar[2]='\0';
                    	size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 06
			case 3:
			case 11:
			case 12:			{
                if ((pos + 6) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 6);
        	        auxiliar[6] = '\0';
					isFix = TRUE;
					size=6;
					pos += 6;
                }
                else
                    sizeOK = NOK;
				break;
			}
			
			// Campos de tamanho 8
			case 9:
			case 10:
			{
				if ( (pos + 8) <= recordSize)
				{
					strncpy(auxiliar, _record+pos, 8);
					auxiliar[8]= '\0';
					isFix= true;
					size = 8;
					pos+= 8;
				}
				else
					sizeOK = NOK;
					
				break;
			}
						
			// Campos de tamanho 10
			case 7:
			{
                if ((pos + 10) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 10);
                	auxiliar[10] = '\0';
					pos += 10;
					isFix = TRUE;
					size=10;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 12
			case 4:
			case 5:
			case 6:
            {
                if ((pos + 12) <= recordSize)
                {
                    strncpy(auxiliar, _record+pos, 12);
                    auxiliar[12] = '\0';
                    pos += 12;
                    isFix = TRUE;
                    size=12;
                }
                else
                    sizeOK = NOK;
                break;
            }

			case 90:
            {
                if ((pos + 42) <= recordSize)
                {
                    strncpy(auxiliar, _record+pos, 42);
                    auxiliar[42] = '\0';
                    pos += 42;
                    isFix = TRUE;
                    size=42;
                }
                else
                    sizeOK = NOK;
                break;
            }

			case 37:
			{
                if ((pos + 24) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 24);
        	        auxiliar[24] = '\0';
					pos += 24;
					isFix = TRUE;
					size=24;
					if ( this->getFlagDisplay() != 0 ) {
                    	conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
                    	conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
                    	auxiliar[12]='\0';
                    	size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}
			
			case 38:
			{
                if ((pos + 12) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 24);
        	        auxiliar[12] = '\0';
					pos += 12;
					isFix = TRUE;
					size=12;
					if ( this->getFlagDisplay() != 0 ) {
                    	conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
                    	conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
                    	auxiliar[6]='\0';
                    	size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}
			// Campos de tamanho 16
			case 41:
			{
                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
        	        auxiliar[16] = '\0';
					pos += 16;
					isFix = TRUE;
					size=16;
					if ( this->getFlagDisplay() != 0 ) {
                    	conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
                    	conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
                    	auxiliar[8]='\0';
                    	size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}

			case 52:
			case 53:
			{

                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
                	auxiliar[16] = '\0';
					pos += 16;
					isFix = TRUE;
					size=16;

                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 30
			case 42:
			{
                if ((pos + 30) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 30);
        	        auxiliar[30] = '\0';
					pos += 30;
					isFix = TRUE;
					size=30;
					if ( this->getFlagDisplay() != 0 ) {
                    	conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
                    	conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
                    	auxiliar[15]='\0';
                    	size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}
			
			// Campos de tamanho 80
			case 43:
			{
                if ((pos + 80) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 80);
        	        auxiliar[80] = '\0';
					pos += 80;
					isFix = TRUE;
					size=80;
					if ( this->getFlagDisplay() != 0 ) {
                    	conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
                    	conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
                    	auxiliar[40]='\0';
                    	size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}

			//
			// Campos de tamanho vari�vel
			//

			// Campos vari�veis NUM�RICOS LLvar e LLLvar 
			//(tem que pegar 2, sempre, e converter pra decimal)
			case 32:
			case 47:
			{
          if ((pos + 2) <= recordSize)
          {
						strncpy( bufferAux, _record+pos, 2);
						convertSize(bufferAux, &size);
						//size = atoi(bufferAux);
						isFix = FALSE;
          }
          if ((pos + 2 + size) <= recordSize)
          {
						strncat( auxiliar, _record+pos, (size + (size % 2)) + 2 );
						pos += 2;
						pos = pos + size + (size % 2) ;
						auxiliar[(size)+2] = '\0';
					}
          else
          	sizeOK = NOK;
				break;
			}
			
			//campos de tamanho vari�vel ALFA-NUM�RICOS
			case 44:
			case 54:
            case 59: // 219278 -  Release de Bandeiras de Janeiro 2018 - SW75
			case 102:
            case 117: // ID204705 - Release de bandeiras Outubro-2017
 			{
          if ((pos + 2) <= recordSize)
          {
						strncpy( bufferAux, _record+pos, 2);
						convertSize(bufferAux, &size);
						//size = atoi(bufferAux);
						isFix = FALSE;
          }
          pos +=2;
          size = size*2;
          if ((pos + size) <= recordSize)
          {
             strncpy(auxiliar, _record+pos, size);
        	   auxiliar[size] = '\0';
        	   //isFix = TRUE;
					   //size=size;
					  if ( this->getFlagDisplay() != 0 ) {
          	  pos += size;
          	  conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
          	  conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
          	  size = size/2;
          	  auxiliar[size]='\0';
					   }
					   else
					   {
					     strncpy(auxiliar2,_record+pos-2,2);
					     strcat(auxiliar2, auxiliar);
					     strcpy(auxiliar,auxiliar2);
					     pos += size;
             }

          }
          else
             sizeOK = NOK;
				break;
			}
			
			//campos bin�rios (em hexa):
			case 48:
			case 55:
            case 56: // ID200293 - Tokenizacao MPV2
			case 60:
      case 61:
			case 62:
			case 63:
			case 104:
      case 123:
            case 125:    // J07_2019 - Release Bandeiras Julho 2019
			case 126:
			{
          if ((pos + 2) <= recordSize)
          {
						strncpy( bufferAux, _record+pos, 2);
						convertSize(bufferAux, &size);
						isFix = FALSE;
          }
          if ((pos + 2 + size*2) <= recordSize)
          {
						//strncat(auxiliar, bufferAux, 2);
						/*if(this->bitsUsed[i]==126)
							maskFields_126(_record+pos);*/
						strncat( auxiliar, _record+pos, (size*2) + 2);
						pos += 2;
						pos = pos + size*2;
						auxiliar[(size*2)+2] = '\0';
					}
          else
          	sizeOK = NOK;
				break;
			}
			
			//
			// Campos de tamanho vari�vel com mascaramento
			//
			case 2:
			{
        if ((pos + 2) <= recordSize)
        {
						size_byte[0] = _record[pos];
   					size_byte[1] = _record[pos+1];
   					size_byte[2] = '\0';
   				convertSize(size_byte, &size);
					//sscanf(size_byte, "%X", &size);
					//sprintf(size_byte, "%2d", size);
					isFix = FALSE;
				}
				if ((pos + 2 + size) <= recordSize)
					pos += maskFields_2102(_record+pos, auxiliar);
				else
					sizeOK = NOK;
				break;
			}

			case 35:
			{
        if ((pos + 2) <= recordSize)
        {
					size_byte[0] = _record[pos];
					size_byte[1] = _record[pos+1];
					size_byte[2] = '\0';

					//size = atoi(size_byte);
					convertSize(size_byte, &size);
					isFix = FALSE;
				}

                /* se o tamanho for �mpar, ocupa mais uma posi��o com um 'f',*/
				if ( size % 2) size++;

                if ((pos + 2 + size) <= recordSize)
                    pos += maskFields_35(_record+pos, auxiliar);
                else
                    sizeOK = NOK;
                break;
			}

			case 45:
			{
        if ((pos + 2) <= recordSize)
          {
						size_byte[0] = _record[pos];
   					size_byte[1] = _record[pos+1];
   					size_byte[2] = '\0';
   					convertSize(size_byte, &size);
						isFix = FALSE;
          }
          //pos +=2;
          size = size*2;
          if ((pos + 2 + size) <= recordSize)
          {
						strncpy(auxiliar, _record+pos, size);
        		auxiliar[size] = '\0';
						//pos += size;
						pos += maskFields_45(_record + pos, auxiliar);
						//isFix = TRUE;
						size=size;
						if ( this->getFlagDisplay() != 0 ) {
          		conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
          		conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
          		size = size/2;
          		auxiliar[size]='\0';
						}

          }
          else
            sizeOK = NOK;
            
          break;
      }



			//
			// Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
			//
			default:
			{
				sizeOK = NOK;
			}

		}
/*
		if ( isFix == FALSE ) {
			cout << "DE [" <<  this->bitsUsed[i] << "] [V" << size << "] [" << auxiliar << "]" << endl;
		}
		else {
			cout << "DE [" <<  this->bitsUsed[i] << "] [F" << size << "] [" << auxiliar << "]" << endl;
		}
*/


       if ( this->getFlagDisplay() != 0 ) {

            sprintf( c_siz, "%03d", size );
            sprintf( c_bit, "%03d", this->bitsUsed[i] );
        }

        if ( this->getFlagDisplay() == 1 ) {

            if ( sizeOK == NOK ) {
                cout << "DE [" <<  c_bit << "] [ERRO]" << endl;

            }
            else
            if ( isFix == FALSE ) {

                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << auxiliar << "]" << endl;
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << auxiliar << "]" << endl;
            }

        }
        else
        if ( this->getFlagDisplay() == 2 ) {

            if ( sizeOK == NOK ) {
                cout << "DE [" <<  c_bit << "] [ERRO]" << endl;
            }
            else
            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << auxiliar << "]";
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << auxiliar << "]";
            }
        }

       if ( this->getFlagDisplay() != 0 && sizeOK != NOK) {

				  if(this->bitsUsed[i] == 55 ){
					  strncpy( bufferAux, _record+pos- size*2 -2, size*2 + 2);
					  openDE55(bufferAux, this->getFlagDisplay());
				  }
			  }
				
		

		if (sizeOK == OK)
			strncat(this->retorno, auxiliar, strlen(auxiliar));

	} // final do for

	// Se houve algum erro retorna o registro original
	if (sizeOK == NOK)
	{
		memset(this->retorno, 0, sizeof(this->retorno));
		strncat(this->retorno, _record, strlen(_record));
	}
}

void Mask_VISA_Interpreter::convertSize( char * size_byte, int *size){
	sscanf(size_byte, "%X", size);
	sprintf(size_byte, "%02d", *size);
}

void Mask_VISA_Interpreter::openDE55(char *buffer, int tipoDisplay){
	char auxiliar[255];
	char size_byte[3];
	char c_siz[4];
	int pos = 0;
	int sizeDE55;
	int size_tag=0;
	char tag_id[5];
	int err=0;
	char endLine;
	
	memset(auxiliar, 0, sizeof(auxiliar));
	memset(size_byte, 0, sizeof(size_byte));
	
	strncpy(size_byte, buffer, 2);
	convertSize(size_byte, &sizeDE55);
	sizeDE55 *=2;
	sizeDE55+=2;
	
	pos+=2;
	
	if(tipoDisplay == 1)
		endLine='\n';
	else
		endLine=' ';
		
	//pula os campos usage, tamanho dos tags (desnecessario, pois � igual a sizeDE55 - cabe�alho)
	pos+= 6;
	while(pos < sizeDE55){
			memset(tag_id, 0, sizeof(tag_id));
			err=0;
			
			if((pos + 2) <= sizeDE55){
				strncpy(size_byte, buffer+pos, 2);
				strncpy(tag_id, buffer+pos, 2);
				convertSize(size_byte, &size_tag);
				pos+=2;
				//if((size_tag==0x9F) || (size_tag==0x5F)) //id da tag tem 2 bytes
				if((size_tag & 0x1F) == 0x1F ) //se os ultimos 5 bits do primeiro byte = 1, id da tag tem 2 bytes
				{
					if((pos+2) <= sizeDE55){
						strncpy(tag_id + 2, buffer+pos, 2);
						pos +=2;
					}
					else{
						err=1;
					}
				}				
				if(err==0){
					if((pos + 2 ) <= sizeDE55 ){
						strncpy(size_byte, buffer+pos, 2);
						size_byte[2] = '\0';
						convertSize(size_byte, &size_tag);
					}
					if((pos + size_tag*2 + 2) <= sizeDE55){
						strncpy(auxiliar, buffer + pos, size_tag*2 + 2);
						auxiliar[size_tag*2+2] = '\0';
						pos += size_tag*2 + 2;
					}
					else{
						err=1;
					}
				}
				
			}
			else{
				err=1;
			}
			
			if(err){
				cout << "       Erro na abertura do DE55\n";
				break;
			}
			else{
				sprintf(c_siz, "%03d", size_tag);
				cout << "      TAG [" << tag_id << "] [V" << c_siz << "] [" << auxiliar << "]" << endLine;
			}
	}
	
}

void Mask_VISA_Interpreter::maskFields_126(const char *_rec){
	int field_size;
	int aux;
	int bitmap_byte;
	char size_byte[3];
	char bitmap[16];
	char mask=0x80;
	char teste;
	int pos=0;
	
	memcpy(bitmap, _rec+2, 16);
	
	memcpy(size_byte, bitmap, 2);
	size_byte[2]='\0';
	convertSize(size_byte, &aux);
	bitmap_byte = (char) aux;
	
	pos=18; //2 caracteres correspondentes ao byte de tamanho do campo + 16 dos 8 bytes do bitmap
	
	for(int i=0; i<10; i++){
		if((i % 8) == 0){
			memcpy(size_byte, bitmap, 2);
			size_byte[2]='\0';
			convertSize(size_byte, &aux);
			bitmap_byte = (char) aux;
		}
		teste = bitmap_byte & mask;
		if(teste){
			switch (i+1){
				case 6:
				case 7:
				{
					memcpy(size_byte, _rec, 2);
					size_byte[2]='\0';
					convertSize(size_byte, &aux);
					pos += 2+aux*2;
					break;
				}
				
				case 9:
				{
					pos+=40;
					break;
				}
				
				case 10:
				{
					//memset(_rec+pos+6, 0x40, 6);
					break;
				}
			}
		}
		
	}
	
}


void Mask_VISA_Interpreter::openDE126(char *buffer){
	int de126_size, field_size;
	char bitmap[17];
	char size_byte[3];
	int i_byte, i_bit;
	char bitmap_byte;
	int byte_aux, err=0;
	int pos=0;
	int bit_used = 0;
	char mask, teste;
	char auxiliar[255], auxiliar2[255];
	
	FilterHandler conv;
	
	memset(size_byte, 0, sizeof(size_byte));
	memset(auxiliar, 0, sizeof(auxiliar));
	memset(auxiliar2, 0, sizeof(auxiliar2));
	
	memcpy(size_byte, buffer, 2);
	size_byte[2]='\0';
	convertSize(size_byte, &de126_size);
	de126_size *=2;
	de126_size +=2; //incrementa o tamanho para considerar o byte de informa��o de tamanho do DE
	pos+=2;
	
	/*memcpy(auxiliar, buffer +2, de126_size-2);
	conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
  conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
	cout << "buffer 'decoded'" << auxiliar << "\n";*/
	
	memcpy(bitmap, buffer + pos, 16);
	bitmap[16]='\0';
	pos+=16;
	
	for(i_byte=0; i_byte<8; i_byte++){//l� os 8 bytes do bitmap
		size_byte[0]= bitmap[i_byte *2];
		size_byte[1]= bitmap[i_byte *2 +1];
		size_byte[2]= '\0';
		convertSize(size_byte, &byte_aux);
		bitmap_byte = (char) byte_aux;
		mask=0x80;
		
		for(i_bit=0; i_bit<8; i_bit++){
			teste = bitmap_byte & mask;
			bit_used ++;
			if(teste){
				switch (bit_used){
					//campos binarios (com informacao de tamanho):
					case 6:
					case 7:
					{
						if((pos + 2) <= de126_size){
							memcpy(size_byte, buffer + pos, 2);
							size_byte[2]='\0';
							convertSize(size_byte, &field_size);
							pos +=2;
						}
						else
							err=1;
						if((pos + field_size*2) <= de126_size){
							memcpy(auxiliar, buffer + pos, field_size*2);
							auxiliar[field_size*2]='\0';
							pos+=field_size*2;
						}
						else
							err=1;
							
						break;
					}
					
					//campos de tamanho fixo:
					case 9: //20 bytes
					{
						if((pos + 40) <= de126_size ){
							memcpy(auxiliar, buffer+pos, 40);
							auxiliar[40]='\0';
							pos+=40;
						}
						else
							err=1;
							
						break;
					}
					
					case 10://6 bytes em ebcdic e com mascaramento
					{
						if((pos + 12) <= de126_size ){
							//memcpy(auxiliar, buffer+pos, 12);
							memset(buffer+pos+6, 0x40, 6);
							cout << "Buffer: " << buffer << "\n";
							//auxiliar[12]='\0';
							pos+=12;
							/*conv.xebcdic2xascii((unsigned char*)auxiliar, auxiliar2);
              conv.xascii2ascii((unsigned char*)auxiliar2, auxiliar, strlen(auxiliar2));
          		memset(auxiliar + 2, 0x40, 4); //mascara CVV
          		auxiliar[6]='\0';*/
						}
						else
							err=1;
							
						break;
					}
					
				}
				//cout << "       bit " << bit_used << ": " << auxiliar <<"\n";
			}
			mask= mask/2;
		}
		
	}
	
	
}
