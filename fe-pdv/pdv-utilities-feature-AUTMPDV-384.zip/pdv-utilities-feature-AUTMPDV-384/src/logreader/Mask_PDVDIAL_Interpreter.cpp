// Mask_PDVDIAL_Interpreter.cpp: implementation of the Mask_PDVDIAL_Interpreter class.
//
//////////////////////////////////////////////////////////////////////
/*
Copyright 2015 Rede S.A.
*********************** MODIFICA��ES ************************
Autor    : Fabio Mazzer
Data     : 13/06/2016
Empresa  : Rede
Descri��o: Merge com vers�o da AM 47.909 para inclus�o do Log Acquirer PDV Dial
*************************************************************
Autor    : Andre Morishita
Data     : 08/09/2021
Empresa  : Leega
Descrio: AUT1-4011 - Inclusao do DCC
ID       : AUT1-4011
*************************************************************
*/

#include "Mask_PDVDIAL_Interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#include "FilterHandler.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_PDVDIAL_Interpreter::Mask_PDVDIAL_Interpreter( int _max, int _headerSize, int _mapType ):Mask_Interpreter( _max, _headerSize, _mapType  )
{

}

Mask_PDVDIAL_Interpreter::~Mask_PDVDIAL_Interpreter()
{

}

void Mask_PDVDIAL_Interpreter::maskRecord( const char* _record )
{
	int i;
	int pos = 0;
	int size;
	int siz;
	char bufferAux[MAX_VALUE_LEN];
	char auxiliar[2048];

    char bufferConv[2048];
    char bufferConv2[2048];
    FilterHandler conv;
    char c_siz[4];
    char c_bit[4];

    bool isFix = TRUE;


	int recordSize;
	recordSize = strlen(_record);

	int sizeOK;
	sizeOK = OK;

	memset(this->retorno, 0, sizeof(this->retorno));


	for( i = 0; ((i < this->usedBits) && (sizeOK == OK)); i++ )
    {
		memset(bufferAux, 0, sizeof(bufferAux));
		memset(auxiliar, 0, sizeof(auxiliar));
		size = 0;

        char size_byte[3] = {0,};

        switch (this->bitsUsed[i])
        {
			//
			// Campos de tamanho fixo
			//

			// Campos de tamanho 04
			case 25:
            case 39:
            {
				siz = 2;
				isFix=TRUE;
                if ((pos + 4) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 4);
					auxiliar[4] = '\0';
					pos += 4;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 06
            case 22:
            case 23:
            case 24:
            case 51: // AUT1-4011 - DCC
            {
				siz = 3;
				isFix=TRUE;
                if ((pos + 6) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 6);
					auxiliar[6] = '\0';
					pos += 6;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 08
            case 13:
            case 14:
			case 15:
            {
				siz = 4;
				isFix=TRUE;
                if ((pos + 8) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 8);
					auxiliar[8] = '\0';
					pos += 8;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 12
            case 3:
            case 11:
            case 12:
            case 38:
            {
				siz = 6;
				isFix=TRUE;
                if ((pos + 12) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 12);
					auxiliar[12] = '\0';
					pos += 12;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 16
            case 41:
            case 10:
            {
				siz = 8;
				isFix=TRUE;
                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
					auxiliar[16] = '\0';
					pos += 16;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 24
            case 4:
            case 5:
            case 37:
            case 6:
            {
				siz = 12;
				isFix=TRUE;
                if ((pos + 24) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 24);
					auxiliar[24] = '\0';
					pos += 24;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 30
            case 42:
            {
				siz = 15;
				isFix=TRUE;
                if ((pos + 30) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 30);
					auxiliar[30] = '\0';
					pos += 30;
                }
                else
                    sizeOK = NOK;
				break;
            }


            // Campos vari�veis LLvar

            case 36:
            {
                if ((pos + 4) <= recordSize)
                {
                    bufferAux[0] = _record[pos+1];
                    bufferAux[1] = _record[pos+3];
                    bufferAux[2] = '\0';
                    siz = atoi(bufferAux);
                    size = siz*2;
                    isFix=FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
                    strncat(auxiliar, _record+pos, 4);
                    pos += 4;
                    strncat(auxiliar, _record+pos, size);
                    auxiliar[size+4] = '\0';
                    pos += size;
                }
                else
                    sizeOK = NOK;
                break;
            }



/*
copiado do PDV
*/

            case 45:
            {
                //type = 1;
                if ((pos + 4) <= recordSize)
                {
                    bufferAux[0] = _record[pos+1];
                    bufferAux[1] = _record[pos+3];
                    bufferAux[2] = '\0';

                    siz = atoi(bufferAux);
                    size = siz*2;
                    isFix=FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
                    pos += maskFields_45(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
                break;
            }

			// Campos de tamanho 32
            case 52:
            {
				siz = 16;
				isFix=TRUE;
                if ((pos + 32) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 32);
					auxiliar[32] = '\0';
					pos += 32;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Campos de tamanho vari�vel
			//

			// Campos vari�veis LLLvar
			case 47:
			case 55:
			case 56:
			case 60:
            case 61:
            case 62:
            case 63:
            {
				isFix=FALSE;
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					siz =  atoi(bufferAux);
					size = siz*2;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 6);
					pos += 6;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Campos de tamanho vari�vel com mascaramento
			//

			case 2:
            {
				isFix=FALSE;
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					siz =  atoi(bufferAux);
					size = siz*2;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_2102(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

            case 35:
            {
				isFix=FALSE;
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					siz =  atoi(bufferAux);
					size = siz*2;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_35(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

			case 48:
            {
				isFix=FALSE;
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					siz =  atoi(bufferAux);
					size = siz*2;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat( auxiliar, Mask_SelLayOut( 0,0, _record+ pos), size + 6 );
					auxiliar[size+6] = '\0';
					pos += 6;
					pos += size;
                }
                else{
                    sizeOK = NOK;
				}
				break;
            }

			//
			// Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
			//
			default:
			{
				sizeOK = NOK;
			}

        }



        if ( this->getFlagDisplay() != 0 ) {

            strncpy(bufferConv, "", 2048 );
            strncpy(bufferConv2, "", 2048 );

            if ( ( this->idLog == LOG_PDVDIAL ) || ( this->idLog == LOG_ACQPDVDIALTG ) ||( this->idLog == LOG_PDVM ) || ( this->idLog == LOG_PDVDIALMTG) || ( this->idLog == LOG_ACQPDVDIALMTG) ){

                conv.xascii2ascii( (unsigned char*) auxiliar, bufferConv2, strlen(auxiliar)/2 );
            }
            else {

                conv.xebcdic2xascii( (unsigned char*) auxiliar, bufferConv );
                conv.xascii2ascii( (unsigned char*) bufferConv, bufferConv2, strlen(bufferConv)/2 );
            }

            sprintf( c_siz, "%03d", siz );
            sprintf( c_bit, "%03d", this->bitsUsed[i] );
        }

        if ( this->getFlagDisplay() == 1 ) {

            if ( sizeOK == NOK ) {
                cout << "DE [" <<  c_bit << "] [ERRO]" << endl;

            }
            else
            if ( isFix == FALSE ) {

                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << bufferConv2 << "]" << endl;
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << bufferConv2 << "]" << endl;
            }

        }
        else
        if ( this->getFlagDisplay() == 2 ) {

            if ( sizeOK == NOK ) {
                cout << "DE [" <<  c_bit << "] [ERRO]" << endl;
            }
            else
            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << bufferConv2 << "]";
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << bufferConv2 << "]";
            }
        }




//		cout << "Aux " <<  this->bitsUsed[i] << " " << auxiliar << endl;
//		cout << "sizeOK " << sizeOK << endl;

		if (sizeOK == OK)
			strncat(this->retorno, auxiliar, strlen(auxiliar));

	} // final do for

	// Se houve algum erro retorna o registro original
	if (sizeOK == NOK)
	{
		memset(this->retorno, 0, sizeof(this->retorno));
		strncat(this->retorno, _record, strlen(_record));
	}
}
