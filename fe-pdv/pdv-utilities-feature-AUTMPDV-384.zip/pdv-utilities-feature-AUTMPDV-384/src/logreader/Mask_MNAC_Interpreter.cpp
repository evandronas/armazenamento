// Mask_MNAC_Interpreter.cpp: implementation of the Mask_MNAC_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#include "Mask_MNAC_Interpreter.h"
#include "FilterHandler.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <iostream>

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1	

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_MNAC_Interpreter::Mask_MNAC_Interpreter( int _max, int _headerSize ) : Mask_POS_Interpreter( _max, _headerSize )
{

}

Mask_MNAC_Interpreter::~Mask_MNAC_Interpreter()
{

}


/////////////////////////////////////////
/**
*
*   Fun�ao que
*
*
*////////////////////////////////////////
int Mask_MNAC_Interpreter::initRecord( char * _buffer )
{
    int bitmapSize = 0;
    char *auxBitmap = NULL;
    char *auxBuffer = NULL;
    char bitAux[2] = {0};
    char xbuffer[3] = {0};
	char ret[128] = {0};
 	int i=0;
	int offSet = 0;
	FilterHandler *filter = NULL;

	cout << "MNAC INIT RECORD" << endl;
    if (_buffer[20] == 'I') {

		offSet= 32;
	}
	else {
		offSet = 0;
	}

    // Se nao foi inicializado o objeto, retorna msg de erro
    if ( this->initialized == FALSE )
    {
        return ( NOK );
    }

    // Se nao possui a parte a ser ignorada copia o buffer original
    if ( ( auxBuffer = strrchr( _buffer, ' ' ) ) == NULL )
        auxBuffer = _buffer;
    else
        auxBuffer++;

	this->headerSize += offSet;

	// Captura o tamanho do header
	int tamHeader;

	tamHeader = auxBuffer - _buffer;


	/////////////////////////////////////////////////////////////
    //printf("\nbuffer auxilixar: %s", auxBuffer+this->headerSize);
    /////////////////////////////////////////////////////////////

    // Se for o mapa de bits em hexadecimal
    if ( this->mapType )
    {
   		filter = new FilterHandler();

		// Inicializa o bitmap com 32
        bitmapSize = 32;

        strncpy(xbuffer, auxBuffer+this->headerSize, 2);

        // Chamo a fun�ao conversora de acordo com o log
		if ( this->idLog == LOG_PDVDIAL )
		{
			filter->xascii2ascii((unsigned char*)xbuffer, (char*)ret, 1);
			bitAux[0] = ret[0];
		}
		else
		{
		    this->hexa2Integer((char*)xbuffer);
        	bitAux[0] = this->bufferConv[0];
		}

		bitAux[1] = '\0';
    }
    else
    {
        // Inicializa o bitmap com 16
        bitmapSize = 16;

        bitAux[0] = *(auxBuffer+this->headerSize);
    }

    /////////////////////////////////////////////////////////////
    //printf("\nbit 1 buffer auxilixar: %c", bitAux[0]);
    /////////////////////////////////////////////////////////////
    // O primeiro campo do mapa de bits nao for um digito
    // ou se o digito for maior do que 7 temos que pegar o segundo mapa de bits
    // portanto o dobro das posicoes
    if ( !isdigit((char)bitAux[0]) || ( atoi(bitAux) > 7 ) )
    {
        if ( this->mapType )
            bitmapSize = 64;
        else
            bitmapSize = 32;
    }

	// Obtem o Header da mensagem e joga numa membro da classe
	strncpy(this->maskedLog, _buffer, tamHeader+this->headerSize+bitmapSize);
 	maskedLog[tamHeader+this->headerSize+bitmapSize] = '\0';


	this->getMessageType( maskedLog );


	// Inicializa o bitmap auxiliar
    auxBitmap = new char[bitmapSize+1];
    memset(auxBitmap, 0, sizeof(auxBitmap));

    // Copia a msg para o bitmap auxiliar com o tamanho correspondente
    memcpy( auxBitmap, auxBuffer+this->headerSize, bitmapSize );

    auxBitmap[bitmapSize] = NULL;


    // Se for do tipo com o bitmap hexadecimal devemos converter o mapa
    if ( this->mapType )
    {
		if ( this->idLog == LOG_PDVDIAL )
		{
			int size;
			size = bitmapSize/2;
			filter->xascii2ascii((unsigned char*)auxBitmap, (char*)ret, size );
			memset(auxBitmap, 0, sizeof(auxBitmap));
			strncpy( auxBitmap, ret, size );
			auxBitmap[size] = '\0';
		}
		else
		{
			this->hexa2Integer( auxBitmap );
			auxBitmap = this->bufferConv;
		}

		delete filter;
		filter = NULL;
    }

    for ( i=0; i < this->maxBits; i++ )
    {
        memset(this->values[i], 0, MAX_VALUE_LEN);
    }

    // Chamada para a fun�oea que irao interpretar o bitmap
    this->fillBitmap( auxBitmap );
    this->fillBitsUsed( );

	this->maskRecord(auxBuffer+this->headerSize+bitmapSize);

	strncat(this->maskedLog, this->retorno, strlen(retorno) );

    return OK;

}
