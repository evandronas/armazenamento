﻿// Mask_POS_Interpreter.cpp: implementation of the Mask_POS_Interpreter class.
//
//////////////////////////////////////////////////////////////////////
/*
Copyright 2015 Rede S.A.
//*********************** MODIFICACOES ************************
Autor    : Danielle Cristina Pereira
Data     : 03/10/2017
Empresa  : Rede
Descrião: Upgrade Captura - Impressão de campos em Hexa e 
alteração do tamanho do header de IN ou OUT do POSIP
ID       : AM 231.044
*************************************************************
Autor    : Andre Morishita
Data     : 10/12/2018
Empresa  : Leega
Descrição: J1_2019 - Comprovante transacoes negadas
ID       : 239526
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 26/06/2019
Empresa  : Rede
Descrição: Alterando função de quebrar tags do DE para ser genérica e adicionando quebra do DE 56 para QH
ID       : EAK - 1593
*************************************************************
Autor    : Andre Morishita
Data     : 08/09/2021
Empresa  : Leega
Descrição: AUT1-4011 - Inclusao do DCC
ID       : AUT1-4011
*************************************************************
*/

#include "Mask_POS_Interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include "onvertEBCDICtoASCII.h"
#include "FilterHandler.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_POS_Interpreter::Mask_POS_Interpreter( int _max, int _headerSize ):Mask_Interpreter( _max, _headerSize )
{

}

Mask_POS_Interpreter::~Mask_POS_Interpreter()
{

}


/////////////////////////////////////////
/**
*
*   Masks the CONFIDENTIAL fields in the record.
*
*   @param char* _record The record to be masked
*   @param char* _masked The masked record to be returned.
*
*
*////////////////////////////////////////
void Mask_POS_Interpreter::maskRecord( const char* _record )
{
	int i;
	int pos = 0;
	int size;
	char bufferAux[MAX_VALUE_LEN];
	char auxiliar[2048];
	char auxiliar2[2048];

	int recordSize;
	recordSize = strlen(_record);

	FilterHandler conv;
	char str[2048];
	int len, lenAux;
	char c_siz [4];
	char c_bit [4];

	int sizeOK;
	sizeOK = OK;
	bool isFix = TRUE;


	memset(this->retorno, 0, sizeof(this->retorno));

	for ( i = 0; ((i < this->usedBits) && (sizeOK == OK)); i++ )
	{
		memset(bufferAux, 0, sizeof(bufferAux));
		memset(auxiliar, 0, sizeof(auxiliar));
		memset(auxiliar2, 0, sizeof(auxiliar));
		memset(str, 0, sizeof(str));
		size = 0;
		
		char size_byte[3] = {0,};

		switch (this->bitsUsed[i])
		{
			//
			// Campos de tamanho fixo
			//

			// Campos de tamanho 02
			case 25:
			{
                if ((pos + 2) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 2);
    	            auxiliar[2] = '\0';
					pos += 2;
					size = 2;
					isFix = TRUE;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 04
			case 13:
			case 14:
			case 15:
			case 18:
			case 22:
			case 23:
			case 24:
			case 71:
            {
                if ((pos + 4) <= recordSize)
                {
                    strncpy(auxiliar, _record+pos, 4);
                    auxiliar[4] = '\0';
                    pos += 4;
                    isFix = TRUE;
                    size=4;
                }
                else
                    sizeOK = NOK;
                break;
            }


			case 39:
			{
                if ((pos + 4) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 4);
        	        auxiliar[4] = '\0';
					pos += 4;
					isFix = TRUE;
					size=4;
                    //cout << "Tratando " <<  this->bitsUsed[i] << " " << auxiliar << " size = " << size << endl;
					if ( this->getFlagDisplay() != 0 ) {
                    	conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 2);
                    	strcpy(auxiliar, auxiliar2);
                    	size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 06
			case 3:
			case 11:
			case 12:
			{
                if ((pos + 6) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 6);
        	        auxiliar[6] = '\0';
					isFix = TRUE;
					size=6;
					pos += 6;
                }
                else
                    sizeOK = NOK;
				break;
			}

			case 49:
            case 51: // AUT1-4011 - DCC
			{
                if ((pos + 6) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 6);
        	        auxiliar[6] = '\0';
					isFix = TRUE;
					size=6;
					pos += 6;

					if ( this->getFlagDisplay() != 0 ) {
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 3);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 8
			case 10:
			{
                if ((pos + 8) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 8);
                	auxiliar[8] = '\0';
					pos += 8;
					isFix = TRUE;
					size=8;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 10
			case 7:
			{
                if ((pos + 10) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 10);
                	auxiliar[10] = '\0';
					pos += 10;
					isFix = TRUE;
					size=10;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 12
			case 4:
			case 6:
            {
                if ((pos + 12) <= recordSize)
                {
                    strncpy(auxiliar, _record+pos, 12);
                    auxiliar[12] = '\0';
                    pos += 12;
                    isFix = TRUE;
                    size=12;
                }
                else
                    sizeOK = NOK;
                break;
            }

			case 38:
			{
                if ((pos + 12) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 12);
        	        auxiliar[12] = '\0';
					pos += 12;
					isFix = TRUE;
					size=12;
                    //cout << "Tratando " <<  this->bitsUsed[i] << " " << auxiliar << " size = " << size << endl;
					if ( this->getFlagDisplay() != 0 ) {
                    	conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 6);
                    	strcpy(auxiliar, auxiliar2);
                    	size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 16
			case 41:
			{

                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
                	auxiliar[16] = '\0';
					pos += 16;
					isFix = TRUE;
					size=16;

					if ( this->getFlagDisplay() != 0 ) {
						//cout << "Tratando " <<  this->bitsUsed[i] << " " << auxiliar << " size = " << size << endl;
						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 8);
						strcpy(auxiliar, auxiliar2);
						size = size/2;
					}

                }
                else
                    sizeOK = NOK;
				break;
			}

			case 52:
			{

                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
                	auxiliar[16] = '\0';
					pos += 16;
					isFix = TRUE;
					size=16;

                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 24
			case 37:
			{
                if ((pos + 24) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 24);
    	            auxiliar[24] = '\0';
					pos += 24;
					isFix = TRUE;
					size=24;

					if ( this->getFlagDisplay() != 0 ) {
                    	//cout << "Tratando " <<  this->bitsUsed[i] << " " << auxiliar << " size = " << size << endl;
                    	conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 12);
                    	strcpy(auxiliar, auxiliar2);
                    	size = size/2;
					}


                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 30
			case 42:
			{
                if ((pos + 30) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 30);
        	        auxiliar[30] = '\0';
					pos += 30;
					if ( this->getFlagDisplay() != 0 ) {

						conv.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 15);
						strcpy(auxiliar, auxiliar2);
						size=15;
						isFix = TRUE;
					}
                }
                else
                    sizeOK = NOK;
				break;
			}

			//
			// Campos de tamanho vari�vel
			//

			// Campos vari�veis LLLvar (tem que pegar 4, n�o 3)
            // Inclusao do DE 47 - Projeto Nutricash Frota - set/2007
			case 47:
			case 54:
			case 55:
			case 60:
			case 61:
			case 62:
			case 63:
			{

                if ((pos + 4) <= recordSize)
                {
					strncpy( bufferAux, _record+pos, 4);
					size = atoi(bufferAux);
					isFix = FALSE;
                }

                if ((pos + 4 + size) <= recordSize)
                {
					strncat(auxiliar, bufferAux, 4);
					pos += 4;
					strncat( auxiliar, _record+pos, (size*2) );
					pos += size*2;
					auxiliar[(size*2)+4] = '\0';

                    lenAux = 4+(size * 2);
                    lenAux = lenAux - 4;

                    //cout << "lenAux = " << lenAux << endl;

                    strncpy( str, auxiliar+4, lenAux );
                    str[lenAux] = '\0';

                    len = lenAux/2;

                    //cout << "Tratando " <<  this->bitsUsed[i] << " " << str << endl;
					if ( this->getFlagDisplay() != 0 ) {

						if(this->bitsUsed[i] == 47 || this->bitsUsed[i] == 55) {
							if (this->getFlagDisplay() == 1)
								cout << "DE [0" << this->bitsUsed[i] << "] [HEXA] [" << auxiliar << "]\n";
							else if (this->getFlagDisplay() == 2)
								cout << "DE [0" << this->bitsUsed[i] << "] [HEXA] [" << auxiliar << "]";
							else 
								cout << "Tipo de display desconhecido!\n";
						}

                    	conv.xascii2ascii((unsigned char*)str, auxiliar2, (long) len);
                    	//cout << "Tratando " <<  this->bitsUsed[i] << " " << auxiliar2 << endl;

 	                   memcpy(auxiliar+4, auxiliar2, len);
    	               auxiliar[len+4] = '\0';
					}

                }
                else
                    sizeOK = NOK;
				break;
			}

			//
			// Campos de tamanho vari�vel com mascaramento
			//
			case 2:
			{
                if ((pos + 2) <= recordSize)
                {
					size_byte[0] = _record[pos];
   					size_byte[1] = _record[pos+1];
   					size_byte[2] = '\0';

					size = atoi(size_byte);
					isFix = FALSE;
				}
				if ((pos + 2 + size) <= recordSize)
					pos += maskFields_2102(_record+pos, auxiliar);
				else
					sizeOK = NOK;
				break;
			}

			case 35:
			{
                if ((pos + 2) <= recordSize)
                {
					size_byte[0] = _record[pos];
					size_byte[1] = _record[pos+1];
					size_byte[2] = '\0';

					size = atoi(size_byte);
					isFix = FALSE;
				}

                /* se o tamanho for �mpar, ocupa mais uma posi��o com um 'f',*/
				if ( size % 2) size++;

                if ((pos + 2 + size) <= recordSize)
                    pos += maskFields_35(_record+pos, auxiliar);
                else
                    sizeOK = NOK;
                break;
			}

			case 45:
			{
                if ((pos + 2) <= recordSize)
                {
					size_byte[0] = _record[pos];
					size_byte[1] = _record[pos+1];
					size_byte[2] = '\0';

					size = atoi(size_byte);
					isFix = FALSE;
				}

                /* se o tamanho for �mpar, ocupa mais uma posi��o com um 'f',*/
                if ( size % 2) size++;

                if ((pos + 2 + size) <= recordSize)
					pos += maskFields_45(_record+pos, auxiliar);
                else
                    sizeOK = NOK;
                break;
			}



			case 48:
			case 56:
			{
                if ((pos + 4) <= recordSize)
                {
					strncpy( bufferAux, _record+pos, 4);
					size = atoi(bufferAux);
					isFix = FALSE;
				}
				if ((pos + 4 + size) <= recordSize)
				{


					//strncat( auxiliar, Mask_SelLayOut( 0,0, _record+pos), (size*2) + 4 );
					strncat( auxiliar, _record+pos, (size*2) + 4 );
					pos += 4;
					pos += size*2;
					auxiliar[(size*2)+4] = '\0';

					
					lenAux = 4+(size * 2);
					lenAux = lenAux - 4;

					//cout << "lenAux = " << lenAux << endl;

					strncpy( str, auxiliar+4, lenAux );
					str[lenAux] = '\0';

					len = lenAux/2;

					if ( this->getFlagDisplay() != 0 ) {

						if(this->getFlagDisplay() == 1)
							cout << "DE [0" <<  this->bitsUsed[i] << "] [HEXA] [" << auxiliar << "]\n";
						else if(this->getFlagDisplay() == 2)
							cout << "DE [0" <<  this->bitsUsed[i] << "] [HEXA] [" << auxiliar << "]";
						else
							cout << "Tipo de display desconhecido!\n";
						
						//cout << "Tratando " <<  this->bitsUsed[i] << " " << str << endl;
						conv.xascii2ascii((unsigned char*)str, auxiliar2, (long) len);
						//cout << "Tratando " <<  this->bitsUsed[i] << " " << auxiliar2 << endl;

						memcpy(auxiliar+4, auxiliar2, len);
						auxiliar[len+4] = '\0';
					}

				}
				else
					sizeOK = NOK;
				break;
			}

			//
			// Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
			//
			default:
			{
				sizeOK = NOK;
			}

		}
/*
		if ( isFix == FALSE ) {
			cout << "DE [" <<  this->bitsUsed[i] << "] [V" << size << "] [" << auxiliar << "]" << endl;
		}
		else {
			cout << "DE [" <<  this->bitsUsed[i] << "] [F" << size << "] [" << auxiliar << "]" << endl;
		}
*/


       if ( this->getFlagDisplay() != 0 ) {

            sprintf( c_siz, "%03d", size );
            sprintf( c_bit, "%03d", this->bitsUsed[i] );
        }

        if ( this->getFlagDisplay() == 1 ) {

            if ( sizeOK == NOK ) {
                cout << "DE [" <<  c_bit << "] [ERRO]" << endl;

            }
            else
            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << auxiliar << "]" << endl;
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << auxiliar << "]" << endl;
            }

        }
        else
        if ( this->getFlagDisplay() == 2 ) {

            if ( sizeOK == NOK ) {
                cout << "DE [" <<  c_bit << "] [ERRO]" << endl;
            }
            else
            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << auxiliar << "]";
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << auxiliar << "]";
            }
        }

        /* 239524 - J1_2019 - Comprovante Transacoes negadas - INICIO */
        if ( sizeOK != NOK && this->getFlagDisplay() != 0 )
        {
              if ( this->bitsUsed[i] == 47 || this->bitsUsed[i] == 56 )
              {
                  OpenDataElementTags( str, this->getFlagDisplay(), len ,this->bitsUsed[i] );
              }
        }
        /* 239524 - J1_2019 - Comprovante Transacoes negadas - FIM */

		
		//cout << "sizeOK " << sizeOK << endl;

		if (sizeOK == OK)
			strncat(this->retorno, auxiliar, strlen(auxiliar));

	} // final do for

	// Se houve algum erro retorna o registro original
	if (sizeOK == NOK)
	{
		memset(this->retorno, 0, sizeof(this->retorno));
		strncat(this->retorno, _record, strlen(_record));
	}
}

/* 239524 - J1_2019 - Comprovante Transacoes negadas - INICIO */
/// OpenDataElementTags
/// Abre o DE em tags
/// EF/ET: 1
/// Historico: [Data] - ET - Descrição
/// 10/12/2018 - ET1 - Criacao da versão inicial
/// 26/06/2019 - ET1 - Alterando pra ser uma função genérica
///
/// buffer: conteudo do DE
/// tipoDisplay: Indicador para abrir inline ou nao
/// lengthData: Tamanho do DE
void Mask_POS_Interpreter::OpenDataElementTags( char *buffer, int tipoDisplay, int lengthData, int DE )
{
    char valueTag[1024] = {0};
    char sizeByte[4+1] = {0};
    char sizeTagFormatted[4+1] = {0};
    int position = 0;
    int sizeDataElement = 0;
    int sizeTag = 0;
    char tagIdentifier[5] = {0};
    int error = 0;
    char endLine = ' ';
    bool showTags = false;
    short tamanhoTag = 4;

    memset(valueTag, 0, sizeof(valueTag));
    memset(sizeByte, 0, sizeof(sizeByte));
    memset(sizeTagFormatted, 0, sizeof(sizeTagFormatted));
    memset(tagIdentifier, 0, sizeof(tagIdentifier));

    if (tipoDisplay == 1)
    {
        endLine = '\n';
    }
    else
    {
        endLine = ' ';
    }
    
    sizeDataElement = lengthData*2;
    //cout << "lengthData: " << sizeDataElement << endl;
    position += 0;
    
    while ( position < sizeDataElement )
    {
        memset(tagIdentifier, 0, sizeof(tagIdentifier));
        memset(sizeByte, 0, sizeof(sizeByte));
        memset(valueTag, 0, sizeof(valueTag));
        error = 0;
        
        if ( (position + 2) <= sizeDataElement )
        {
            strncpy(tagIdentifier, buffer+position, 2);
            //cout << "tagIdentifier: " << tagIdentifier << endl;
            
            strncpy(sizeByte, buffer+position+2, tamanhoTag);
            sizeTag = atoi(sizeByte);
            //cout << "tag_len: " << sizeTag << endl;
            
            position += 2;
            
            if ( (position + sizeTag*2 + tamanhoTag) <= sizeDataElement )
            {
                strncpy(valueTag, buffer + position + tamanhoTag, sizeTag*2);
                //cout << "dados: " << valueTag << endl;
                valueTag[sizeTag*2+tamanhoTag] = '\0';
                position += sizeTag*2 + tamanhoTag;
                //cout << "soma: " << position << endl;
            }
            else
            {
                error = 1;
            }
        }
        else
        {
            error = 1;
        }
        
        if (error)
        {
            cout << "      Erro na abertura do DE" << DE << "\n";
            break;
        }
        else
        {
            memset(sizeTagFormatted, 0, sizeof(sizeTagFormatted));
            sprintf(sizeTagFormatted, "%04d", sizeTag);
            
            if ( showTags == false )
            {
                cout << "DE [0" << DE << "]" << " [TAGS]" << endLine;
                showTags = true;
            }
            
            if (endLine == '\n')
            {
                cout << "      TAG [" << tagIdentifier << "] [V" << sizeTagFormatted << "] [" << valueTag << "]" << endLine;
            }
            else
            {
                cout << " TAG [" << tagIdentifier << "] [V" << sizeTagFormatted << "] [" << valueTag << "]" << endLine;
            }
        }
    }
}
/* 239524 - J1_2019 - Comprovante Transacoes negadas - FIM */
