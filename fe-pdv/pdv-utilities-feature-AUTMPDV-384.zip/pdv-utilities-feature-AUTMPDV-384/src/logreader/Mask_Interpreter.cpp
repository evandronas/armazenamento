// Mask_Interpreter.cpp: implementation of the Mask_Interpreter class.
//
//////////////////////////////////////////////////////////////////////
/*
Copyright 2015 Rede S.A.
*********************** MODIFICAES ************************
Autor    : Fabio Mazzer e Diogo Fernandes
Data     : 15/02/2015
Empresa  : Rede
Descrio: Multicaptura ELO
ID       : 91915 - SW Multicaptura ELO
*************************************************************
Autor    : Fernanda Carvalho
Data     : 20/03/2015
Empresa  : Rede
Descrio: Multicaptura Amex
ID       : 92100 - SW Multicaptura Amex
*************************************************************
Autor    : Mrio Ado
Data     : 03/12/2015
Empresa  : Rede
Descrio: SW 7.5 - POS/PDV - merge desenv com produo
ID       : 
*************************************************************
Autor    : Joao Paulo Ferraz Costa
Data     : 29/07/2016
Empresa  : Rede
Descrio: Ajuste LogReader - Tag CVC2
ID       : 89.439, 0584_SW
*************************************************************
Autor    : Andre Morishita
Data     : 30/01/2017
Empresa  : Leega
Descrio: Inclusao dos logs da Amex Full e Elo Full
ID       : 184820
Autor    : Misunori Namioka
Data     : 03/03/2017
Empresa  : Fidelity
Descrio: Merge da versao contendo o tratamento do POS-IP
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 25/09/2018
Empresa  : Rede
Descrio: Inclusao TPDU INAC
ID       : AM 228.120
*************************************************************
*************************************************************
Autor    : Danielle Cristina Pereira
Data     : 03/10/2017
Empresa  : Rede
Descri��o: Upgrade Captura - Impressão de campos em Hexa e 
alteração do tamanho do header de IN ou OUT do POSIP
ID       : AM 225.800 
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 26/06/2019
Empresa  : Rede
Descrio: Adicionando tratamento para QH
ID       : EAK - 1593
**************************************************************
Autor    : Fernando Brum
Data     : 24/07/2019
Empresa  : Rede
Descrio: Tratamento mensagens PDV INAC
ID       : EAK-1623
*************************************************************
Autor    : Andre Morishita
Data     : 26/09/2020
Empresa  : Leega
Descricao: Tratamento mensagens PDV - NIIP 000071 e 000000
ID       : EAK-4223
*************************************************************
Autor    : Andre Morishita
Data     : 24/08/2021
Empresa  : Leega
Descrio: Inclusao do Projeto DCC
ID       : AUT1-4011
*************************************************************
Autor    : Andre Morishita
Data     : 10/12/2021
Empresa  : Leega
Descri��o: AUT2-4397 - Tap On Phone
ID       : AUT2-4397
*************************************************************
*/

#include "LVS_Constants.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <fstream>
#include "Mask_Interpreter.h"
#include "FilterHandler.h"
#include "onvertEBCDICtoASCII.h"
#include "Fields.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_Interpreter::Mask_Interpreter(int _max, int _headerSize, int _mapType)
{
    this->maxBits = _max;
    this->headerSize = _headerSize;
    this->mapType = _mapType;

}

Mask_Interpreter::~Mask_Interpreter()
{
    if ( this->values != NULL )
    {
        for ( int i=0; i <this->maxBits; i++ )
        {
            delete this->values[i];
        }
        delete this->values;
    }
}

/////////////////////////////////////////
/**
*
*   Funao que limpa o bitmap.
*
*   @param none
*
*////////////////////////////////////////
void Mask_Interpreter::resetBitmap( )
{
    int i=0;

    for (i=0;i<128;i++)
    {
        this->bitmap[i] = '0';
    }
}


/////////////////////////////////////////
/**
*
*   Funao que preenche o bitmap.
*
*   @param char* _map: o string contendo o map dos bits
*
*////////////////////////////////////////
void Mask_Interpreter::fillBitmap( char * _map )
{
	const char hex2bin[16][5] = { "0000", "0001", "0010", "0011", "0100",
	"0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101",
	"1110", "1111" };

    char aux[2] = { 0 };
    int i = 0;
    int j = 0;
    char upper;
	int iTamanho;

    memset (this->bitmap, 0, BITMAP_SIZE);

	iTamanho = strlen(_map);
	for ( i = 0; i < iTamanho; i++ )
	{
		if (isdigit(_map[i]))
		{
			aux[0] = _map[i];
			j = atoi(aux);
			strcat( this->bitmap , hex2bin[j] );
		}
		else
		{
			upper = toupper(_map[i]);
            strcat( this->bitmap, hex2bin[upper-55] );
		}
	}

//cout << " map---> " << _map << " Bitmap " <<  this->bitmap << endl;
}

void Mask_Interpreter::showBits()
{
  int i;
  cout << "Bitmap ";
  for( i = 0; i < this->usedBits; i++ ){
    cout << " "  << this->bitsUsed[i];

  }
  cout << " ";
}

/////////////////////////////////////////
/**
*
*   Funao que inicializa o objeto interpretador
*
*
*////////////////////////////////////////
int Mask_Interpreter::initInterpreter(int layout, int detail )
{
    int i = 0;

    this->values = new char*[this->maxBits];
    for ( i=0; i < this->maxBits; i++ )
    {
        this->values[i] = new char[MAX_VALUE_LEN];
        memset( this->values[i], 0,  MAX_VALUE_LEN );
    }

    this->usedBits = 0;
    this->layoutDE48 = layout;	
	this->detail = detail;

    this->initialized = OK;

    return 0;
}


/////////////////////////////////////////
/**
*
*   Funao que faz a
*
*
*////////////////////////////////////////
int Mask_Interpreter::compare(char* response, int _bit , const char * _value )
{

	int pos;
	char pan[512];
	char auxValue[512];
	int auxBit = _bit;
	char *ptr, *auxPtr;
	auxPtr = (char *) NULL;
	memset(auxValue, 0, sizeof(auxValue));
	memset(pan, 0, sizeof(pan));


	strcpy(auxValue,_value);
	ptr = (char *) auxValue;
	pos = this->getBufferPos(auxBit);


	if(_bit == 2 && pos == -1)
	{
		auxBit = 35;
		pos = this->getBufferPos(auxBit);
	}

    if ( this->idLog != LOG_POS && this->idLog != LOG_ACQPOSIP && this->idLog != LOG_ACQPOSTOP && this->idLog != LOG_PDVDIAL  && this->idLog != LOG_PDVM && this->idLog != LOG_PDVDIALMTG && this->idLog != LOG_ACQPDVDIALTG && this->idLog != LOG_ACQPDVDIALMTG && this->idLog != LOG_ACQPOSTG)
	{
		if(_bit == 37 && pos == -1)
		{
			auxBit = 127;
			pos = this->getBufferPos(auxBit);
		}
	}


	if(pos != -1)
	{
		if(auxBit  == 2 || auxBit == 35)
		{
			if(auxBit == 35)
			{
				panExtract(pan, this->values[pos]);
			}

			auxPtr = strchr(auxValue,'-');

			if(auxPtr != (char *) NULL )
				ptr = ++auxPtr;

		}

		int len = strlen(ptr);

		if(auxBit == 35)
		{
			if ( strcmp( ptr, pan ) == 0 )
            {
				return OK;
			}
		}
		else
		{
			if ( this->idLog == LOG_POS || this->idLog == LOG_ACQPOSIP || this->idLog == LOG_ACQPOSTOP || this->idLog == LOG_ACQPOSTG)
			{
				if ( auxBit == 2 )
				{
					if ( strncmp( ptr, this->values[pos]+3,len ) == 0 )
						return OK;
				}
				else
				{
					if ( strncmp( ptr, this->values[pos],len ) == 0 )
					return OK;
				}

			}
			else
			{
				if ( auxBit == 2 )
				{
					//auxi.Format("\nptr: %s - this->values[pos]: %s - len:%d", ptr, this->values[pos]+5, len);

					if ( strncmp( ptr, this->values[pos]+5,len ) == 0 )
						return OK;
				}
				else if ( auxBit == 127 )
				{
					//auxi.Format("\nptr: %s - this->values[pos]: %s - len:%d", ptr, this->values[pos]+7, len);

					if ( strncmp( ptr, this->values[pos]+7,len ) == 0 )
						return OK;
				}
				else
				{
					//auxi.Format("\nptr: %s - this->values[pos]: %s - len:%d", ptr, this->values[pos], len);
					if ( strncmp( ptr, this->values[pos],len ) == 0 )
						return OK;
				}
			}
		}
	}

	return NOK;
}

int Mask_Interpreter::getBufferPos(int _bit)
{
	int i, pos = -1;

	for ( i = 0; i < this->usedBits; i++ )
	{
		if ( this->bitsUsed[i] == _bit )
		{
			pos = i;
			break;
		}
	}
	return pos;
}


void Mask_Interpreter::resetRecord()
{
    return;
}

int Mask_Interpreter::initCaptureRecord( char * _buffer )
{
	memset(this->retorno, 0 , sizeof(this->retorno));
	memset(this->maskedLog, 0 , sizeof(this->maskedLog));
	this->maskRecord(_buffer);
	strcpy(this->maskedLog, this->retorno);
	return OK;

}

/////////////////////////////////////////
/**
*
*   Funao que
*
*
*////////////////////////////////////////
int Mask_Interpreter::initRecord( char * _buffer )
{

    int bitmapSize = 0;
	char auxBitmap[65] = {0,};
	int size = 0;
    char *auxBuffer = NULL;
    char IC[4]= {0};
    char auxMsgType[4]= {0};
    char Salt[32]= {0};
    char Hash[64]= {0};
    char bitAux = 0;
    char bitAux2= 0;
    char xbuffer[3] = {0};
	char ret[128] = {0};
	char trailer[10] = {0,};
	char header[128] = {0,};
    char print_header [2048] = {0};
 	int i=0;
	int headerLen;
	char reject_error[5];
	
	if(this->idLog == LOG_EPACK) {
		//cout << "Antes-->" << _buffer << endl;
		transEpack(_buffer);
		strcpy(	trailer, (_buffer + strlen(_buffer) - 6));
		//cout << "Trailer--> " <<  trailer << endl;
		//cout << "Depois-->" << _buffer << endl;

	}
	memset(this->maskedLog, 0, sizeof(this->maskedLog));

	FilterHandler *filter = NULL;
	headerLen = this->headerSize;
     
	//cout << "Mask_Interpreter::initRecord     this->idLog-->" << this->idLog << endl; 
	
	if ((this->idLog == LOG_MNAC || this->idLog == LOG_PDVM || this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPOSMTG || this->idLog == LOG_ACQPDVDIALMTG || this->idLog == LOG_POSQH ) && _buffer[20] == 'I') {

		headerLen +=  32;
	}

	if(this->idLog == LOG_ACQPOSIP) {
		if(_buffer[20] == 'I')
        {
            // IC 9905 ou IC 9906 pula SALT
            strncpy(IC, _buffer+62, 4 );
            if ( (strncmp(IC, "9905", 4)==0) || (strncmp(IC, "9906", 4)==0) )
            {
                strncpy(Salt, _buffer+86, 32 );    
                headerLen += 66;
            }
            else
            {
			headerLen += 34;
            }
        }
		else if (_buffer[20] == 'O')
        {
			headerLen += 10;
            strncpy(auxMsgType, _buffer+62, 4 );
            if ( this->validMsgType (atoi(auxMsgType)) != 1 )
            {
                headerLen += 64;
                strncpy(Hash, _buffer+62, 64 );    
            }
                
        }
	}
    
    // AUT2-4397 - Tap On Phone - INICIO
    if(this->idLog == LOG_ACQPOSTOP) {
        if(_buffer[20] == 'I')
        {
            // IC 9907 pula SALT
            strncpy(IC, _buffer+62, 4 );
            if ( (strncmp(IC, "9907", 4)==0) )
            {
                strncpy(Salt, _buffer+90, 32 );    
                headerLen += 70;
            }
            else
            {
                headerLen += 34;
            }
        }
        else if (_buffer[20] == 'O')
        {
            headerLen += 10;
            strncpy(auxMsgType, _buffer+62, 4 );
            if ( this->validMsgType (atoi(auxMsgType)) != 1 )
            {
                headerLen += 64;
                strncpy(Hash, _buffer+62, 64 );    
            }
        }
    }
    // AUT2-4397 - Tap On Phone - FIM
    

		// Se nao foi inicializado o objeto, retorna msg de erro
    if ( this->initialized == FALSE )
    {
        return ( NOK );
    }

    // Se nao possui a parte a ser ignorada copia o buffer original
    if ( ( auxBuffer = strrchr( _buffer, ' ' ) ) == NULL )
        auxBuffer = _buffer;
    else
        auxBuffer++;

	// Captura o tamanho do header
	int tamHeader;
	
	/* Pula o cabecalho da CUP */
	if( this->idLog == LOG_CUP )
	{
		headerLen = 100;
		auxBuffer+= 4;
		this->mapType = 0;
	}


	if(this->mapType && this->idLog != LOG_SICREDI)
		auxBuffer+=8;
	else
		auxBuffer+=4;

	/*Exceo da visa: cabealho tcp maior e varia o tamanho do header da mensagem.
	Busca o tamanho no cabealho logo depois do cabealho tcp.
	*/
	if(this->idLog == LOG_VISA){
		int t_aux;
		reject_error[0]= auxBuffer[4];
		reject_error[1]= auxBuffer[5];
		reject_error[2]= '\0';
		sscanf(reject_error, "%X", &t_aux);
		if(t_aux == 22)
			headerLen= (t_aux * 2) + 8;
		else if(t_aux == 26){
			reject_error[0]= auxBuffer[t_aux*2];
			reject_error[1]= auxBuffer[t_aux*2 +1];
			reject_error[2]= auxBuffer[t_aux*2 +2];
			reject_error[3]= auxBuffer[t_aux*2 +3];
			reject_error[4]= '\0';
			t_aux +=22;
			headerLen= (t_aux*2) + 8;
		}
		else headerLen= 8;
	}
	/*Fim exceo visa*/
	
	/*Teste de DUKPT*/
	/* BRUM - EAK-1623 - 24/07/2019 - Tratamento mensagem PDV intellinac */
	if((this->idLog == LOG_PDV) || (this->idLog == LOG_ACQPDVPROTOM) || (this->idLog == LOG_ACQPDVKMS) || (this->idLog == LOG_ACQPDVIP) || (this->idLog == LOG_ACQPDVBIGIP) || (this->idLog == LOG_ACQPDVINAC) || (this->idLog == LOG_ACQPDVQH) || (this->idLog == LOG_ACQPDVCORBAN))
	{
		if(	(strncmp(auxBuffer+headerLen-8, "222003", 6)==0) ||
				(strncmp(auxBuffer+headerLen-8, "020003", 6)==0) ||
				(strncmp(auxBuffer+headerLen-8, "000050", 6)==0) ||
				(strncmp(auxBuffer+headerLen-8, "000032", 6)==0) ||
				(strncmp(auxBuffer+headerLen-8, "111050", 6)==0) ||
				(strncmp(auxBuffer+headerLen-8, "004e23", 6)==0) ||
				(strncmp(auxBuffer+headerLen-8, "004E23", 6)==0) ||
				(strncmp(auxBuffer+headerLen-8, "000071", 6)==0) || // EAK 4223 - NIIP 000071
				(strncmp(auxBuffer+headerLen-8, "000000", 6)==0) || // EAK 4223 - NIIP 000000
				(strncmp(auxBuffer+headerLen-8, "000100", 6)==0) )
		{
			auxBuffer += 6;
		}
	}
	tamHeader = auxBuffer - _buffer;
	
	/////////////////////////////////////////////////////////////
    // printf("\nbuffer auxilixar: %s", auxBuffer+headerLen);
    /////////////////////////////////////////////////////////////

    // Se for o mapa de bits em hexadecimal
    if ( this->mapType )
    {
		filter = new FilterHandler();

		// Inicializa o bitmap com 32
        size = 32;
        strncpy(xbuffer, auxBuffer+headerLen, 2);

        // Chamo a funao conversora de acordo com o log
		if ( this->idLog == LOG_PDVDIAL || this->idLog == LOG_ACQPDVDIALTG || this->idLog == LOG_PDVM || this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPDVDIALMTG ||
			this->idLog == LOG_TICKET || this->idLog == LOG_SICREDI || this->idLog == LOG_ELO || this->idLog == LOG_ELO_FULL )
		{
			filter->xascii2ascii((unsigned char*)xbuffer, (char*)ret, 1);
			bitAux = ret[0];
			bitAux2= ret[16];
		}
		else
		{
		    this->hexa2Integer((char*)xbuffer);
        	bitAux = this->bufferConv[0];
        	bitAux2 = this->bufferConv[16];
			
		}
    }
	else
    {
        // Inicializa o bitmap com 16
        size = 16;
        bitAux = *(auxBuffer+headerLen);
        bitAux2 = *(auxBuffer+headerLen+16);
    }

    /////////////////////////////////////////////////////////////
    // printf("\nbit 1 buffer auxilixar: %c", bitAux[0]);
    /////////////////////////////////////////////////////////////
    // cout << "\nbit 1 buffer auxilixar: " << bitAux << endl;
    // O primeiro campo do mapa de bits nao for um digito
    // ou se o digito for maior do que 7 temos que pegar o segundo mapa de bits
    // portanto o dobro das posicoes
	
	bitmapSize = size;
	//cout << "|" << bitmapSize << "|" << bitAux << "|" << bitAux2 << "|";
    if ( !isdigit(bitAux) || ( (bitAux - '0') > 7 ) )
    {
    				if( (bitAux2 - '0') >= 7 ){
    					bitmapSize = size*3; //cobre o caso do terceiro bitmap usado pela visa
    				}
    				else{
            	bitmapSize = size*2;
            }
    }

	// Obtem o Header da mensagem e joga numa membro da classe
	strncpy(this->maskedLog, _buffer, tamHeader+headerLen+bitmapSize);
 	maskedLog[tamHeader+headerLen+bitmapSize] = '\0';

	int tamAux = 4;

	if (( this->idLog == LOG_ACQPDVPROTOM ) || ( this->idLog == LOG_ACQPDVKMS ) )
	{
		tamAux += 4;
	}
	
    strncpy( print_header, _buffer, tamHeader+headerLen - tamAux );
    print_header[ tamHeader + headerLen  - tamAux] = '\0';

	int sizMsgType = this->getMessageType( auxBuffer + headerLen );

	// Inicializa o bitmap auxiliar
    memset(auxBitmap, 0, sizeof(auxBitmap));

    // Copia a msg para o bitmap auxiliar com o tamanho correspondente
    memcpy( auxBitmap, auxBuffer+headerLen, bitmapSize );
    
	auxBitmap[bitmapSize] = NULL;
	//  cout << "bitmapSize " << bitmapSize << " auxBitmap " << auxBitmap << endl;

    // Se for do tipo com o bitmap hexadecimal devemos converter o mapa
	//cout << "\n\nthis->mapType:" << this->mapType << "|\tSauxBitmap:" << auxBitmap <<"\n";
    if ( this->mapType )
    {
		if ( this->idLog == LOG_PDVDIAL || this->idLog == LOG_PDVM || this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPDVDIALMTG || this->idLog == LOG_ACQPDVDIALTG ||
			 this->idLog == LOG_TICKET || this->idLog == LOG_SICREDI || this->idLog == LOG_ELO || this->idLog == LOG_ELO_FULL )
		{
			filter->xascii2ascii((unsigned char*)auxBitmap, (char*)ret, size );
			strncpy( auxBitmap, ret, size );
			auxBitmap[size] = '\0';
		}
		else if ( this->idLog == LOG_PLANET )
		{
			auxBitmap[16] = '\0';
			bitmapSize = 16;
		}
		else
		{
			this->hexa2Integer( auxBitmap );
			strcpy(auxBitmap,this->bufferConv);
		}
		delete filter;
		filter = NULL;
    }

    for ( i=0; i < this->maxBits; i++ )
    {
        memset(this->values[i], 0, MAX_VALUE_LEN);
    }

    // Chamada para a funoea que irao interpretar o bitmap
    this->fillBitmap( auxBitmap );
    this->fillBitsUsed( );

	if ( ( this->getFlagDisplay() == 1 ) ) {

		cout << "-------------------------------------------------------------------------------" << endl;
		//cout << "Header: [" << this->maskedLog << "] " << endl;
		cout << "Header: [" << print_header << "] " << endl;
		if((this->idLog==LOG_VISA)&&(headerLen==104))
			cout << "Reject_error: [" << reject_error << "] " << endl;
        if((this->idLog==LOG_ACQPOSIP || this->idLog==LOG_ACQPOSTOP) && strlen(IC)>0 )
            cout << "IndCryp: [" << IC << "] " << endl;             
        if((this->idLog==LOG_ACQPOSIP || this->idLog==LOG_ACQPOSTOP) && strlen(Salt)>0 )
            cout << "Salt   : [" << Salt << "] " << endl;                         
        if((this->idLog==LOG_ACQPOSIP || this->idLog==LOG_ACQPOSTOP) && strlen(Hash)>0 )
            cout << "Hash   : [" << Hash << "] " << endl;                                     
		cout << "MsgType: [" << this->msgType << "] " << endl;
		this->showBits();
        cout << "\n";
	}
    else if ( this->getFlagDisplay() == 2 ) {

        cout << "\n";
        cout << "-------------------------------------------------------------------------------" << endl;
        //cout << "Header: [" << this->maskedLog << "] " ;
        cout << "Header: [" << print_header << "] " ;
        if((this->idLog==LOG_VISA)&&(headerLen==104))
					cout << "Reject_error: [" << reject_error << "] ";
        if((this->idLog==LOG_ACQPOSIP || this->idLog==LOG_ACQPOSTOP) && strlen(IC)>0 )
            cout << "IndCryp: [" << IC << "] " ;             
        if((this->idLog==LOG_ACQPOSIP || this->idLog==LOG_ACQPOSTOP) && strlen(Salt)>0 )
            cout << "Salt   : [" << Salt << "] ";              
        if((this->idLog==LOG_ACQPOSIP || this->idLog==LOG_ACQPOSTOP) && strlen(Hash)>0 )
            cout << "Hash   : [" << Hash << "] ";
        cout << "MsgType: [" << this->msgType << "] " ;
        this->showBits();

    }

	this->maskRecord(auxBuffer+headerLen+bitmapSize);
	
	strcat(this->maskedLog, this->retorno);
//	cout <<  this->maskedLog << endl;

	if(this->idLog == LOG_EPACK) 
		strncat(this->maskedLog, trailer, 6);
    return OK;
}


/////////////////////////////////////////
/**
*
*   Funao que
*
*
*////////////////////////////////////////
void Mask_Interpreter::fillBitsUsed( )
{
    int i = 0;

    this->usedBits=0;

    for ( i = 1; i < BITMAP_SIZE ; i++ )
    {
        if( this->bitmap[i] == '1')
        {
            this->bitsUsed[this->usedBits]=i+1;
            this->usedBits++;
             //printf("\n<interpreter> bitsUsed[%d] = %d\n", this->usedBits, i+1);
        }
    }

    // printf( "\n\n" );
}


/////////////////////////////////////////
/**
*
*   Funcao que retorna o ponteiro para os valores interpretados.
*
*
*////////////////////////////////////////
char ** Mask_Interpreter::getValues( )
{
	return this->values;
}


/////////////////////////////////////////
/**
*
*   Funcao que converte o char * que contem os valores em hexadecimal
*   para inteiros que serao devolvidos em um array
*
*
*////////////////////////////////////////
void Mask_Interpreter::hexa2Integer( char* _strHexa )
{

    int n = 0;         // position in string
    int m = 0;         // position in digit[] to shift
    int count;         // loop index
    int intValue = 0;  // integer value of hex string
    int digit[5];      // hold values to convert

    char hexStg[3];
    int iCont;
    int pos = 0;
    int tam;

    int valuesHexa[32];

    memset(this->bufferConv, 0, sizeof(this->bufferConv));

    // Capturo o tamanho do buffer de entrada
    tam = strlen(_strHexa );

    // Lao pelo tamanho do buffer dividido por 2 que resultara
    // no numero total de elementos
    for ( iCont = 0; iCont < tam/2; iCont++ )
    {
        // Limpo o buffer auxiliar
        memset(hexStg, 0, sizeof(hexStg));
        intValue = 0;
        n = 0;
        m = 0;

        // Copio para o buffer auxiliar 2 posicoes
        // que representam o caracter hexadecimal
        strncpy( hexStg, _strHexa+pos, 2 );
        hexStg[2] = '\0';

        // printf("\ncaracteres copiados %s", hexStg);
        // incremento no contador de posicoes
        pos += 2;

        count = n;
        m = n - 1;
        n = 0;
        // Lao para conversao em inteiros
        while (n < 2)
        {
            if (hexStg[n]=='\0')
                break;
            if (hexStg[n] > 0x29 && hexStg[n] < 0x40 ) // se 0 - 9
                digit[n] = hexStg[n] & 0x0f;            // converte para int
            else if (hexStg[n] >='a' && hexStg[n] <= 'f') // se a - f
                digit[n] = (hexStg[n] & 0x0f) + 9;      // converte para int
            else if (hexStg[n] >='A' && hexStg[n] <= 'F') // se A - F
                digit[n] = (hexStg[n] & 0x0f) + 9;      // converte para int
            else
                break;

            n++;
        }

        count = n;
        m = n - 1;
        n = 0;

        while ( n < count )
        {
            // digit[n] is value of hex digit at position n
            // (m << 2) is the number of positions to shift
            // OR the bits into return value
            intValue = intValue | (digit[n] << (m << 2));
            m--;   // adjust the position to set
            n++;   // next digit to process
        }
        // printf("\nNumero convertido %d", intValue );
        valuesHexa[iCont] =  intValue;

    }


    char bufferAux[MAX_BUFFER_SIZE];
    onvertEBCDICtoASCII conv;

	for ( int i = 0; i < tam/2; i++ )
    {
        sprintf(bufferAux, "%c", conv.Decimal_to_xEBCDIC[valuesHexa[i]]);
        strcat(this->bufferConv, bufferAux);
    }
}


/////////////////////////////////////////
/**
*
*   Retorna o numero de bits utilizados no bitmap.
*
*   @return int usedBits Numero de bitas utilizados pelo bitmap
*
*////////////////////////////////////////
int Mask_Interpreter::getUsedBits( )
{
	return this->usedBits;
}


int* Mask_Interpreter::getBitsInUse( )
{
	return this->bitsUsed;
}

int Mask_Interpreter::getMessageType( char * _header)
{
	char * msgPtr = (char  *) NULL;
	char auxiliar[256] = {0};
	char msg[5] = {0};
	int size; 

	size = 4;
	switch ( this->idLog )
	{
		case 0: // POS
		case 2: // PDV
		case 7: // MNAC
		case 8: // EPACK
		case 67: // PDVM
		case 200: //VISA
		case LOG_ACQPOSMTG:
		case LOG_ACQPOSIP:
		case LOG_ACQPOSTG:
		case LOG_POSQH:
        case LOG_ACQPOSTOP: // AUT2-4397 - Tap On Phone
		{
			strncpy(this->msgType, _header - size, size);
			this->msgType[size]='\0';
			break;
		}
		case 1: // CRE / DV
		case 3: // MCI mae
		case 4: // MCI
		case LOG_AVR: // AVR
		case LOG_EC: // EC
		case LOG_TPDU: // TPDU
		case LOG_OL: // OL 
		case LOG_MPG: // MPG
		case 6: // PDVDIAL
		case 17: // COOP
		case 68: // POS PDVDIALMTG
		case 100: // PDV sitef
		case 101: // HST SMNT
		case 102: //  HSTPV
		case 103: //  AVR VARIG
		case 105: //  HST
		case LOG_ACQPDVDIALMTG: 
		case LOG_ACQPDVDIALTG: 
		case LOG_ACQPDVIP: 
		case LOG_ACQPDVBIGIP: 
		case LOG_ACQPDVKMS: 
		case LOG_ACQPDVPROTOM: 
		case LOG_ACQPDVINAC:
		case LOG_ACQPDVQH:
		case LOG_ACQPDVCORBAN:
		case LOG_SICREDI:
		case LOG_TICKET:
  	case LOG_CUP:
  	case LOG_CEFPV:
  	case LOG_ITAUPL:
	case LOG_ELO:
	case LOG_AMEX:
    //case LOG_AMEX_FULL:
    case LOG_ELO_FULL:
		{
			size *= 2;	
			msgPtr = _header -	size; 
			this->msgType[0] = *(msgPtr + 1);
			this->msgType[1] = *(msgPtr + 3);
			this->msgType[2] = *(msgPtr + 5);
			this->msgType[3] = *(msgPtr + 7);
			this->msgType[4] = '\0';

			break;
		}
    case LOG_PLANET:
		{
			msgPtr = _header -	size; 
			this->msgType[0] = *(msgPtr + 0);
			this->msgType[1] = *(msgPtr + 1);
			this->msgType[2] = *(msgPtr + 2);
			this->msgType[3] = *(msgPtr + 3);
			this->msgType[4] = '\0';

			break;
		}

		default:
		{
			break;
		}
	}

	return size;
}

void Mask_Interpreter::panExtract(char *pan, char *track2)
{
		char *s, *p;

	//p = track2;

	s = pan;
	int count = 0;

	if ((this->idLog == LOG_POS) || (this->idLog == LOG_EPACK) || (this->idLog == LOG_ACQPOSTG))
	{
		// Remove o tamanho e o traco
		p = track2+3;

		while(*p != '=' && *p != 'D' && *p != 'd' && *p != ' ' && *p != '^' && count < 19)
		{
   			*s++ = *p++;
			count++;
		}
	}
	else
	{
		// Remove o tamanho e o traco
		p = track2+5;

	    while( count < 38 )
        {
		    // Separador "D"
			if(*p == 'c' && *(p+1) == '4')
				break;

			// Separador " "(espaco)
			if(*p == '7' && *(p+1) == 'e')
	            break;


			// Validacoes para formato hexadecimal ascii
			// Separador "="
			if(*p == '3' && *(p+1) == 'd')
				break;

			if(*p == '3' && *(p+1) == 'd')
				break;

			if(*p == '3' && *(p+1) == 'd')
				break;

			if(*p == '3' && *(p+1) == 'd')
				break;


			*s++ = *p++;
            count++;

		}
	}

	*s = '\0';
}

int Mask_Interpreter::findDelimiter(const char *track2)
{
	const char  *p;

	p = track2;


	int count = 0;

	if ((this->idLog == LOG_POS) || (this->idLog == LOG_ACQPOSIP) || (this->idLog == LOG_ACQPOSTOP) || (this->idLog == LOG_ACQPOSTG)|| (this->idLog == LOG_MNAC) || (this->idLog == LOG_EPACK) || (this->idLog == LOG_ACQPOSMTG) || (this->idLog == LOG_POSQH) )
	{

		while(*p != '=' && *p != 'D' && *p != 'd' && *p != ' ' && *p != '^' && count < 19)
		{
			*p++;
			count++;
		}

	}
	else
	{


	    while( count < 38 )
        {
		    // Separador "D"
			if(*p == 'c' && *(p+1) == '4')
				break;

			// Separador " "(espaco)
			if(*p == '7' && *(p+1) == 'e')
	            break;


			// Validacoes para formato hexadecimal ascii
			// Separador "="
			if(*p == '3' && *(p+1) == 'd')
				break;

			p += 2;
            count += 2;

		}
	}

	return count;
}


/*      Desenvolvido por A.C - 01/09/2005
 *** Field 2 e 102 ***                         */
int Mask_Interpreter::maskFields_2102(const char *_rec, char *rec_aux)
{
   char auxiliar[256] = {0,};
   char size_byte[3]  = {0,};
   char flagPosMnac   = 'P';  // POS e POS MNAC
   char tipoLog       = 'O';  // OUTROS

   if (this->idLog == LOG_POS || (this->idLog == LOG_ACQPOSIP) || (this->idLog == LOG_ACQPOSTOP) || this->idLog == LOG_ACQPOSTG || this->idLog == LOG_MNAC ||(this->idLog == LOG_EPACK)||(this->idLog == LOG_VISA) || (this->idLog == LOG_ACQPOSMTG) || (this->idLog == LOG_POSQH) )
      tipoLog = flagPosMnac;
      
   int size, finalPanPos, maskLimit, iniMaskPos, i;
   int unitSize = (tipoLog == flagPosMnac ? 1 : 2);
   int fieldLenSize = unitSize*2;
   int binSize = unitSize*6;
   int unMaskSize = unitSize*4;

   char maskEbcSymb[3] = "7c";
   char maskAscSymb[3] = "40";
   char *symbPtr = maskEbcSymb;

   if (this->idLog == LOG_PDVDIAL || this->idLog == LOG_PDVM || this->idLog == LOG_PDVDIALMTG ||
		this->idLog == LOG_TICKET || this->idLog == LOG_SICREDI || this->idLog == LOG_ELO || this->idLog == LOG_ELO_FULL || this->idLog == LOG_PLANET)
      symbPtr = maskAscSymb;

   size_byte[0] = (tipoLog == flagPosMnac ? _rec[0] : _rec[1]);
   size_byte[1] = (tipoLog == flagPosMnac ? _rec[1] : _rec[3]);
   size_byte[2] = '\0';

	 //se for visa, precisa converter o tamanho de hexa para decimal
	 if (this->idLog == LOG_VISA || this->idLog == LOG_PLANET)
   {
   		//int size;
   		char auxSize[3];
   		auxSize[0] = _rec[0];
   		auxSize[1] = _rec[1];
   		auxSize[2] = '\0';
   		sscanf(auxSize, "%X", &size);
   		sprintf(size_byte, "%02d",size);
   }

   size = atoi(size_byte) * unitSize;

   /* Determina a posicao inicial da mascara */
   iniMaskPos = fieldLenSize + binSize;

   if (tipoLog == flagPosMnac)
   {
      if ( size % 2)
      {
         size++;
         if (this->idLog == LOG_VISA){
         	 iniMaskPos++;
         }
         else {
        	 unMaskSize++;
         }
         
      }
   }


   /* Numero do cartao */
   finalPanPos = size + fieldLenSize;
   maskLimit = finalPanPos - unMaskSize;
   memcpy(auxiliar, _rec, finalPanPos);
   auxiliar[finalPanPos] = '\0';

		//cout << "SIZE >>>> "<< size;
		//cout << "fieldLenSize >>>> "<< fieldLenSize;
		//cout << "unMaskSize >>>> "<< unMaskSize;
		//cout << "fieldLenSize >>>> "<< fieldLenSize;
		//cout << "iniMaskPos >>>> "<< iniMaskPos;

   if (this->idLog == LOG_PDVDIAL || this->idLog == LOG_PDVM || this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPDVDIALMTG || this->idLog == LOG_ACQPDVDIALTG
		|| this->idLog == LOG_TICKET || this->idLog == LOG_SICREDI || this->idLog == LOG_ELO || this->idLog == LOG_ELO_FULL || this->idLog == LOG_PLANET)
      {
		 /* Mascara sem o bin e os 4 ultimos digitos */
		 for (i = iniMaskPos; i < maskLimit; )
		 {
			 auxiliar[i++] = *symbPtr;
			 auxiliar[i++] = *(symbPtr + 1);
	     }
      }
   else
      {
		 for (i = iniMaskPos; i < maskLimit; i++)
		     auxiliar[i] = '@';
      }

   strcpy(rec_aux, auxiliar);
   return finalPanPos;
}


/*      Desenvolvido por A.C - 01/09/2005
 *** Field 35 ***                         */
int Mask_Interpreter::maskFields_35(const char *_rec, char *rec_aux)
{
   char auxiliar[256] = {0,};
   char size_byte[3]  = {0,};
   char flagPosMnac   = 'P';  // POS e POS MNAC
   char tipoLog       = 'O';  // OUTROS

   if ((this->idLog == LOG_POS) || (this->idLog == LOG_ACQPOSIP) ||  (this->idLog == LOG_ACQPOSTOP) || (this->idLog == LOG_ACQPOSTG) || (this->idLog == LOG_MNAC)  || (this->idLog == LOG_EPACK) || this->idLog == LOG_VISA || (this->idLog == LOG_ACQPOSMTG) || (this->idLog == LOG_POSQH))
      tipoLog = flagPosMnac;

   int size, maskLimit, iniMaskPos, i;
   int unitSize = (tipoLog == flagPosMnac ? 1 : 2);
   int totalSize = 0;
   int fieldLenSize = unitSize*2;
   int binSize = unitSize*6;
   int unMaskSize = unitSize*4;

   /* Trilha II */

   int posDelimiter = 0;
   int expDateSize = 4;
   int svcSize = 3;
   int finalSvcPos = 0;

   char maskEbcSymb[3] = "7c";
   char maskAscSymb[3] = "40";
   char *symbPtr = maskEbcSymb;

   if (this->idLog == LOG_PDVDIAL || this->idLog == LOG_PDVM || this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPDVDIALMTG || this->idLog == LOG_ACQPDVDIALTG
		|| this->idLog == LOG_TICKET || this->idLog == LOG_SICREDI || this->idLog == LOG_ELO || this->idLog == LOG_ELO_FULL || this->idLog == LOG_PLANET)
      symbPtr = maskAscSymb;

   size_byte[0] = (tipoLog == flagPosMnac ? _rec[0] : _rec[1]);
   size_byte[1] = (tipoLog == flagPosMnac ? _rec[1] : _rec[3]);
   size_byte[2] = '\0';

	 //se for visa, precisa converter o tamanho de hexa para decimal
	 if (this->idLog == LOG_VISA)
   {
   		int size;
   		char auxSize[3];
   		auxSize[0] = _rec[0];
   		auxSize[1] = _rec[1];
   		auxSize[2] = '\0';
   		sscanf(auxSize, "%X", &size);
   		sprintf(size_byte, "%02d",size);
   }

   /* se for POS e de tamanho mpar, ocupa mais uma posio com um 'f',*/

   size = atoi(size_byte) * unitSize;

   if (tipoLog == flagPosMnac)
   {
      if ( size % 2) size++;
   }

   totalSize = size + fieldLenSize;
   memcpy(auxiliar, _rec, totalSize);
   auxiliar[totalSize] = '\0';

   /* Determina a posicao inicial da mascara */
   iniMaskPos = fieldLenSize + binSize;

   /* Acha o delimitador */
   posDelimiter = findDelimiter(_rec + fieldLenSize);
   
   if (posDelimiter > size - unMaskSize) {
     posDelimiter = size;
   }

   maskLimit = fieldLenSize + (posDelimiter - unMaskSize);

   if (this->idLog == LOG_PDVDIAL || this->idLog == LOG_PDVM || this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPDVDIALTG || this->idLog == LOG_ACQPDVDIALMTG
		|| this->idLog == LOG_TICKET || this->idLog == LOG_ELO || this->idLog == LOG_ELO_FULL || this->idLog == LOG_PLANET)
      {
		  for (i = iniMaskPos; i < maskLimit;)
		  {
			  auxiliar[i++] = *symbPtr;
			  auxiliar[i++] = *(symbPtr + 1);
		  }
      }
   else
      {
		  for (i = iniMaskPos; i < maskLimit; i++)
		      auxiliar[i] = '@';
      }


   finalSvcPos = (unitSize + fieldLenSize + posDelimiter) + (unitSize * ( expDateSize + svcSize));
   int flagZero = 0;

   int mask = 1;
   if (this->idLog == LOG_PDV || this->idLog == LOG_SITEF || this->idLog == LOG_SMNT)
   {
      mask = checkNonZero(_rec, finalSvcPos, totalSize);;
      /* Interface PDV */
   }
   if (mask)
   {
	   if (this->idLog == LOG_PDVDIAL || this->idLog == LOG_PDVM  || this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPDVDIALTG || this->idLog == LOG_ACQPDVDIALMTG
		|| this->idLog == LOG_TICKET || this->idLog == LOG_ELO || this->idLog == LOG_ELO_FULL || this->idLog == LOG_PLANET) 
	   {
          for (i = finalSvcPos; i < totalSize; )
          {
			  auxiliar[i++] = *symbPtr;
			  auxiliar[i++] = *(symbPtr + 1);
	      }
       }
    else
       {
          for (i = finalSvcPos; i < totalSize; i++)
              auxiliar[i] = '@';
       }

   }
   strcpy(rec_aux, auxiliar);
   return totalSize;

}

int Mask_Interpreter::checkNonZero(const char * buf, int offSet, int size )
{
 int found = 0;
 int pos;
 const char *p;
 p = buf + offSet;
 pos = offSet;
 do {
	/* printf("%c%c\n",*p, *(p + 1)); */
        if(*p == 'f' && *(p + 1) == '0') {
		p += 2;
		pos += 2;
	}
	else {
		found = 1;
	}
   } while  (!found && pos < size);
 return found;
}


// Procura o separador "^" do campo 45 - Trilha I
int Mask_Interpreter::findSeparator(const char * buf, int offSet, int size, char ch )
{
 int found = 0;
 int pos;
 const char *p;
 p = buf + offSet;
 pos = offSet;
 do {
        if(*p == '5' && *(p + 1) == ch) {
		found = 1;
	}
	else {
		p += 2;
		pos += 2;
	}
   } while  (!found && pos < size);
 return pos;
}


/*      Desenvolvido por A.C - 01/09/2005
 *** Field 45 ***                         */
int Mask_Interpreter::maskFields_45(const char *_rec, char *rec_aux)
{
   char auxiliar[256] = {0,};
   char size_byte[3]  = {0,};
   char flagPosMnac   = 'P';  // POS e POS MNAC
   char tipoLog       = 'O';  // OUTROS

   if (this->idLog == LOG_POS || (this->idLog == LOG_ACQPOSIP) || (this->idLog == LOG_ACQPOSTOP) || this->idLog == LOG_ACQPOSTG || this->idLog == LOG_MNAC || this->idLog == LOG_ACQPOSMTG || (this->idLog == LOG_EPACK) || (this->idLog == LOG_PDVM) ||( this->idLog == LOG_PDVDIALMTG) ||( this->idLog == LOG_ACQPDVDIALMTG) || (this->idLog == LOG_POSQH)) {

      tipoLog = flagPosMnac;
   }

   int size, totalSize, maskLimit, iniMaskPos, i;
   int unitSize = 2;
   int formatCodlen = 2;
   int fieldLenSize;
   int binSize = unitSize*6;
   int unMaskSize = unitSize*4;

   char maskEbcSymb[3] = "7c";
   char maskAscSymb[3] = "40";
   char *symbPtr = maskEbcSymb;

   if ((tipoLog == flagPosMnac) || (this->idLog == LOG_PDVDIAL) || (this->idLog == LOG_PDVM) || (this->idLog == LOG_PDVDIALMTG)  || (this->idLog == LOG_MCI)  || (this->idLog == LOG_TICKET) || (this->idLog == LOG_ACQPDVDIALTG) || (this->idLog == LOG_ACQPDVDIALMTG) || (this->idLog == LOG_ELO) || (this->idLog == LOG_ELO_FULL) || (this->idLog == LOG_AMEX) || (this->idLog == LOG_PLANET))
      symbPtr = maskAscSymb;

   /* Trilha I */

   /* Acha o delimitador */
   int posDelimiter = 0;
   int expDateSize = 4;
   int svcSize = 3;
   int finalSvcPos = 0;
   int nameDelimiter = 0;
   int posAfterdelimiter = 0;
   int iniMaskname = 0;


   if ( this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPDVDIALMTG) {

	   size_byte[0] = (tipoLog == flagPosMnac ? _rec[1] : _rec[1]);
	   size_byte[1] = (tipoLog == flagPosMnac ? _rec[3] : _rec[3]);
 	  size_byte[2] = '\0';
   }
   else {

	   size_byte[0] = (tipoLog == flagPosMnac ? _rec[0] : _rec[1]);
	   size_byte[1] = (tipoLog == flagPosMnac ? _rec[1] : _rec[3]);
 	  size_byte[2] = '\0';

   }

   //se for visa, precisa converter o tamanho de hexa para decimal
	 if (this->idLog == LOG_VISA)
   {
   		int size;
   		char auxSize[3];
   		auxSize[0] = _rec[0];
   		auxSize[1] = _rec[1];
   		auxSize[2] = '\0';
   		sscanf(auxSize, "%X", &size);
   		sprintf(size_byte, "%02d",size);
   		
   		fieldLenSize=2;
   }

   size = atoi(size_byte) * unitSize;
    /* se for POS e de tamanho mpar, ocupa mais uma posio com um 'f',*/
   /* que deve ser descartado */
   fieldLenSize = unitSize * 2;

   if (tipoLog == flagPosMnac)
   {
      if(size %2)size++;
      fieldLenSize = 2;
   }
   if ( this->idLog == LOG_PDVDIALMTG || this->idLog == LOG_ACQPDVDIALMTG){

       fieldLenSize = unitSize * 2;
   }
   if ( this->idLog == LOG_VISA){
   		 fieldLenSize=2;
   }

   totalSize = size + fieldLenSize;
    
   memcpy(auxiliar, _rec, totalSize);
   auxiliar[totalSize] = '\0';
 /* Encontra o delimitador do inicio do nome */

   char ch = 'f';
   if (tipoLog == flagPosMnac) ch = 'e';
   int found = 0;

   posDelimiter = findSeparator(_rec, 0, totalSize, ch);
   nameDelimiter =  findSeparator(_rec, posDelimiter + 2, totalSize, ch);

   /* Determina a posicao inicial da mascara */
   iniMaskPos = fieldLenSize + binSize + formatCodlen;
   /* posicao final do numero do cartao */
   maskLimit = posDelimiter - unitSize - unMaskSize + formatCodlen;

   if ((tipoLog == flagPosMnac) || (this->idLog == LOG_PDVDIAL) || (this->idLog == LOG_PDVM) || (this->idLog == LOG_PDVDIALMTG) || (this->idLog == LOG_MCI)  || (this->idLog == LOG_TICKET) || (this->idLog == LOG_ACQPDVDIALMTG) || (this->idLog == LOG_ACQPDVDIALTG) || (this->idLog == LOG_ELO) || (this->idLog == LOG_ELO_FULL) || (this->idLog == LOG_AMEX) || (this->idLog == LOG_PLANET))
   {
	   for (i = iniMaskPos  ; i < maskLimit;)
	   {
		   auxiliar[i++] = *symbPtr;
		   auxiliar[i++] = *(symbPtr + 1);
       }
   }
   else
   {
	   for (i = iniMaskPos  ; i < maskLimit; i++)
	   {
		   auxiliar[i] = '@';
	   }
   }
   

   iniMaskname = posDelimiter + unitSize;

   if ((tipoLog == flagPosMnac) || (this->idLog == LOG_PDVDIAL) || (this->idLog == LOG_PDVM) || (this->idLog == LOG_PDVDIALMTG) || (this->idLog == LOG_MCI)  || (this->idLog == LOG_TICKET) || (this->idLog == LOG_ACQPDVDIALMTG) || (this->idLog == LOG_ACQPDVDIALTG) || (this->idLog == LOG_ELO) || (this->idLog == LOG_ELO_FULL) || (this->idLog == LOG_AMEX) || (this->idLog == LOG_PLANET))
      {
		  for (i = iniMaskname; i < nameDelimiter;)
		  {
			  auxiliar[i++] = *symbPtr;
			  auxiliar[i++] = *(symbPtr + 1);
	      }
      }
   else
      {
		  for (i = iniMaskname; i < nameDelimiter; i++)
		      auxiliar[i] = '@';
      }

   finalSvcPos = nameDelimiter + unitSize + (unitSize * ( expDateSize + svcSize));
   int mask = 1;

   if (this->idLog == LOG_PDV || this->idLog == LOG_SITEF || this->idLog == LOG_SMNT)
   {
      mask = checkNonZero(_rec, finalSvcPos, totalSize);;
      /* Interface PDV */
   }

   if (mask)
   {
	   if ((tipoLog == flagPosMnac) || (this->idLog == LOG_PDVDIAL) || (this->idLog == LOG_PDVM) || (this->idLog == LOG_PDVDIALMTG) ||(this->idLog == LOG_MCI)  || (this->idLog == LOG_TICKET) ||(this->idLog == LOG_ACQPDVDIALMTG)  || (this->idLog == LOG_ACQPDVDIALTG) || (this->idLog == LOG_ELO) || (this->idLog == LOG_ELO_FULL) || (this->idLog == LOG_AMEX) || (this->idLog == LOG_PLANET) )
	      {
			  for (i = finalSvcPos; i < totalSize;)
			  {
				  auxiliar[i++] = *symbPtr;
				  auxiliar[i++] = *(symbPtr + 1);
		      }
	      }
	   else
	      {
			  for (i = finalSvcPos; i < totalSize; i++)
			      auxiliar[i] = '@';
          }
   }
   strcpy(rec_aux, auxiliar);
   return totalSize;

}

void Mask_Interpreter::transEpack( char * buffer)
{
	char *p, *s;
	char aux[2048];
	strcpy(aux, buffer);
	p = aux;
	do {
		s = strstr(p, "1030");
		if( s != (char *) NULL ) {
			p = s + 4;
			if ( *(s + 4) == '3' && *(s + 5) == '2') {  	
				substitute(s, 0);
				p += 2;
			}
			else if ( *(s + 4) == '3' && *(s + 5) == '3') {
				substitute(s, 1);
				p += 2;
                	}
			else if ( *(s + 4) == '4' && *(s + 5) == '4') {
				substitute(s, 2);
				p += 2;
                	}
		}
	} while ( s != (char *) NULL);

	p = aux;
	do {
		s = strstr(p, "1031");
        	if( s != (char *) NULL ) {
			p = s + 4;
                	if ( *(s + 4) == '3' && *(s + 5) == '0') {
				substitute(s, 3);
				p += 2;
                	}
		}
	} while ( s != (char *) NULL);

	p = aux;
	do {
 		s = strstr(p, "1035");
        	if( s != (char *) NULL ) {
			p = s + 4;
               		if ( *(s + 4) == '3' && *(s + 5) == '2') {
				substitute(s, 4);
				p += 2;
                	}
			else if ( *(s + 4) == '4' && *(s + 5) == '1') {
				substitute(s, 5);
				p += 2;
                	}
		}
	} while ( s != (char *) NULL);

	p = aux;
	do {
		s = strstr(p, "1038");
        	if( s != (char *) NULL ) {
			p = s + 4;
                	if ( *(s + 4) == '3' && *(s + 5) == '2') {
				substitute(s, 6);
				p += 2;
                	}
			else if ( *(s + 4) == '4' && *(s + 5) == '4') {
				substitute(s, 7);
				p += 2;
                	}
		}
	} while ( s != (char *) NULL);

	p = aux;
	do {
        
		s = strstr(p, "1046");
        	if( s != (char *) NULL ) {
			p = s + 4;
                	if ( *(s + 4) == '3' && *(s + 5) == '0') {
				substitute(s, 8);
				p += 2;
                	}
                	if ( *(s + 4) == '4' && *(s + 5) == '4') {
				substitute(s, 9);
				p += 2;
                	}

		}
	} while ( s != (char *) NULL);
	removeStar(aux, buffer);

}

void Mask_Interpreter::removeStar(char * src, char * dest)
{
	int	count;	
	char *p, *s;
	char aux[2048];
	count = 0;
	dest[0] = '\0';	
	strcpy(aux, src);
	p = aux;
	do {
		s = strstr(p, "****");
		if( s != (char *) NULL ) {	
			*s = '\0';
			strcat(dest, p);
			p = s + 4;
		}
	} while ( s != (char *) NULL ) ;
	if(count == 0) strcat(dest, p);
}

void Mask_Interpreter::substitute (char *s, int cod)
{
	switch(cod) {
	case 0: 
 		*s = '0';
        	*(s+1) = '2';
	break;
	case 1:
 		*s = '0';
        	*(s+1) = '3';
	break;
	case 2:
 		*s = '0';
        	*(s+1) = 'D';
	break;
	case 3:
                *s = '1';
                *(s+1) = '0';
	break;
	case 4:
                *s = '5';
                *(s+1) = '2';
	break;
	case 5: 
                *s = '5';
                *(s+1) = 'A';
	break;
	case 6: 
	case 7: 
                *s = '8';
                *(s+1) = 'D';
	break;
	case 8: 
                *s = '8';
                *(s+1) = 'F';
	break;
	case 9: 
                *s = '8';
                *(s+1) = '0';
	break;
	default:
	break;	

	}
	*(s + 2) = '*';
        *(s + 3) = '*';
        *(s + 4) = '*';
        *(s + 5) = '*';

}

        
// *** Seleciona Mascaramento em funo do Cdigo do Lay-out ***
char * Mask_Interpreter::Mask_SelLayOut( long Proc_Cod, int VerLayOut, const char *Str)
{
	static char *StrRet;
	int CodMsg = atoi(this->msgType);

	switch (this->layoutDE48)
	{
		// 0 => PDV, 1 => TG; 2 => POS; 3 => DV; 4 => AVR; 5 => MCI //
		case 0:	StrRet = Mask_CVC2_PDV(CodMsg, Proc_Cod, VerLayOut, Str);
				break;
		
		case 1: StrRet = Mask_CVC2TagsPOS(CodMsg, Str);
				break;

		case 2:	StrRet = Mask_CVC2POS(CodMsg,  Str);
				break;

		case 3:	StrRet = Mask_CVC2CRE(CodMsg, Str);
				break;

		case 4:	StrRet = Mask_CVC2AVR(CodMsg, Str);
				break;

		case 5:	StrRet = Mask_CVC2MCI(CodMsg, Str);
				break;
	}

	return (StrRet);
}

// *** Mascara PDV ***
char * Mask_Interpreter::Mask_CVC2_PDV(int CodMsg, long Proc_Cod, int VerLayOut, const char *Str)
{
	int LenRet;
	char StrAux[5] = {0};
	char TipoTrans[4] = {0};

	static char StrRet[2048] = {0};
  	memset(StrRet, 0, sizeof(StrRet));
	char *StrRet_P;
 

	LenRet = strlen(Str);
	memcpy(StrRet,Str, LenRet);

	StrRet_P = StrRet;
	
	StrRet_P += 6; // Pula Size

	memset(StrAux,0x00,sizeof(StrAux));

	StrAux[0] = StrRet_P[1];
	StrAux[1] = StrRet_P[3];
	StrAux[2] = '\0';

	if (StrRet_P[0] == 'd' && StrRet_P[1] == '7')
		strcpy(TipoTrans,"P");
	 else
		if ((StrRet_P[0] == 'c' && StrRet_P[1] == '1') && 
			(StrRet_P[2] == 'c' && StrRet_P[3] == '4'))
			strcpy(TipoTrans,"AD");
		 else
			if ((StrRet_P[0] == 'd' && StrRet_P[1] == '9') && 
				(StrRet_P[2] == 'f' && StrRet_P[3] == '1'))
				strcpy(TipoTrans,"R1");
			 else
				if ((StrRet_P[0] == 'c' && StrRet_P[1] == '1') && 
					(StrRet_P[2] == 'e' && StrRet_P[3] == '4') && 
					(StrRet_P[4] == 'e' && StrRet_P[5] == '3'))
					strcpy(TipoTrans,"AUT");
	
	
	if ((TipoTrans == "P") && 
		(CodMsg != 400 && CodMsg != 420 && CodMsg != 220 && CodMsg != 110) && 
		(strlen(StrRet_P)) >= 8)
	{
		StrRet_P += 2; /* Nota: d1 = 'P' */
		strncpy(StrRet_P,"@@@@@@", 6);
	}
 
	if ((strcmp(TipoTrans,"AUT") == 0) && (VerLayOut == 202)) // L.02.02
	{
		StrRet_P += 6; /* Nota: c1e4e3 = "AUT" */
		strncpy(StrRet_P,"@@@@@@", 6);
	}
	
	if ((strcmp(TipoTrans,"AD") == 0) && 
		(Proc_Cod != 2000 && Proc_Cod != 2900 && Proc_Cod != 173000))
	{
		StrRet_P += 4; /* Nota: c1c4 = "AD" */
		strncpy(StrRet_P,"@@@@@@", 6);
	}

	if (((strcmp(TipoTrans,"AD") == 0) || (strcmp(TipoTrans,"R1") == 0)) && 
		(isdigit(StrRet_P[5]) && isdigit(StrRet_P[7]) && isdigit(StrRet_P[9])))
	{
		StrRet_P += 4;	/* Nota: c1c4 = "AD" ou d9f1 = "R1" */
		strncpy(StrRet_P,"@@@@@@", 6);
	}

	return(StrRet); 
}

// *** Mascara Tags POS ***
char * Mask_Interpreter::Mask_CVC2TagsPOS(int CodMsg, const char *Str)
{
  /* Tabelas para Auxiliar no Mascaramento das Tags */
  char TabTipo[142] = " DHHDDDDHDDDDDDHDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDHHHHDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDHHHHD";
  int TabSize[141] = {0,4,8,2,2,4,6,8,6,-2,10,4,6,30,12,1,12,30,12,50,6,14,28,0,0,0,0,0,0,0,0,0,14,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,-1,2,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,14,22,24,0,0,-2,-2,0,18,1,61,40,12};
  int TabSizeLvar[141] = {0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,2,0,0,0,0,0,0};	

  int LenLvar, IndexStr = 0, NumTags = 0, size, SizeTag, sizeRegTag, CodTag, LenRet;
  char *StrDe48_P;

  char simbTag;
  char StrAux[5] = {0};

  static char StrRet[2048] = {0,};

  LenRet = strlen(Str);
  memset(StrRet, 0, sizeof(StrRet));
  memcpy(StrRet,Str, LenRet);

  StrDe48_P = StrRet;

  strncpy(StrAux,StrDe48_P,4);

  size = (atoi(StrAux)*2);
  sizeRegTag = (size - 4);

  StrDe48_P += 4;  

  memset(StrAux,0x00,5);

  strncpy(StrAux,StrDe48_P,2);

  simbTag = char(convHexInt(StrAux));

  StrDe48_P += 2;

  if ( simbTag != 'T')
  {
	/* Retorna o mesmo contedo, pois no foi identificado o formato P.03.01.06 */
	return (StrRet);
  }

  memset(StrAux,0x00,5);

  while ( IndexStr <= sizeRegTag )
  {
    memset(StrAux,0x00,5);

    // Extrai cdigo da Tag
    strncpy(StrAux,StrDe48_P,2);

    StrDe48_P += 2;
    IndexStr +=2;

    CodTag = convHexInt(StrAux);

    memset(StrAux,0x00,5);

    // Essa Condio verifica se o tamanho da estrutura da Tag  fixa ou varivel
    if ( (TabSize[CodTag] == -1) || (TabSize[CodTag] == -2))
    {
      LenLvar = TabSizeLvar[CodTag];

      // Extrai Tamanho (n x Lvar)
      strncpy(StrAux, StrDe48_P, LenLvar);

      StrDe48_P += LenLvar;

      SizeTag = atoi(StrAux);

      IndexStr += TabSizeLvar[CodTag];
      
      /*
         Qualquer numero menor que -1 ser convertido para positivo e multiplicado
         pela quantidade de bytes da Tag em processamento.
      */
      if (TabSize[CodTag] < -1)
         SizeTag *= (TabSize[CodTag] *= -1);
    }
    else
    {
      SizeTag = TabSize[CodTag];
    }

    if (TabTipo[CodTag] == 'H')
       SizeTag *= 2;
    
	/*
       Esta Tag(0x15) tem um tamanho varivel que depende do Nro de parcelas contido na
       estrutura da Tag nas posies 13a e 14a (26 X Nro_Parcelas + TamFixo = sizeTag)
    */
    if (CodTag == 21)
    {
      memset(StrAux,0x00,5);
      strncpy(StrAux, StrDe48_P+12,2);
      SizeTag += (26 * atoi(StrAux));
    }

    if (CodTag == 5)
    {
      memcpy(StrDe48_P,"@@@@", SizeTag);
      // break;
    }
	
	if (CodTag == 12)
    {
      memcpy(StrDe48_P,"@@@@@@", SizeTag);
      // break;
    }

    StrDe48_P += SizeTag;
    IndexStr += SizeTag;
  }
// 	cout << "MASKDE48 " << StrRet << endl;
  
  return (StrRet);
}

// *** Converte Hexadecimal para int ***
int Mask_Interpreter::convHexInt(char valHexa[2])
{
  char tabHexInt[17] = "0123456789ABCDEF";
  int valInt;
  int indTabHex;
  char dig1, dig2;

  // Verifica se digitos so Minusculos, se for converte
  if ( islower(int(valHexa[0])) )
     dig1 = char(toupper(int(valHexa[0])));
  else
     dig1 = valHexa[0];

  if ( islower(int(valHexa[1])) )
     dig2 = char(toupper(int(valHexa[1])));
  else
     dig2 = valHexa[1];

  // Converte 1o.digito de hexa para Inteiro
  for (indTabHex=0; (tabHexInt[indTabHex] != dig1) && (indTabHex<16); indTabHex++);

  if ( tabHexInt[indTabHex] == dig1 )
     valInt = indTabHex*16;
  else
     return (-2); // Cdigo hexa invlido para converso

  // Converte 2o.digito de hexa para Inteiro
  for (indTabHex=0; (tabHexInt[indTabHex] != dig2) && (indTabHex<16); indTabHex++);

  if ( tabHexInt[indTabHex] == dig2 )
     valInt += indTabHex;
  else
     return (-2); // Cdigo hexa invlido para converso

  return valInt;
}


// *** Mascara POS ***
char *Mask_Interpreter::Mask_CVC2POS(int CodMsg, const char *Str)
{	
	int LenRet;
	char StrAux[5] = {0};
	char StrCarc[2] = {0};
	char TipoTrans[4] = {0};
	char DigHexCvc1[3] = {0};
	char DigHexCvc2[3] = {0};
	char DigHexCvc3[3] = {0};

	char DigCvc1;
	char DigCvc2;
	char DigCvc3;
	
	static char StrRet[2048] = {0,};
	char *StrRet_P;

	LenRet = strlen(Str);
	memset(StrRet,0, sizeof(StrRet));
	memcpy(StrRet,Str, LenRet);


//	cout << "DE48 " << StrRet << endl;
	StrRet_P = StrRet;
	StrRet_P +=4; // Pula Size
	if(this->idLog == LOG_PDVDIAL || this->idLog == LOG_ACQPDVDIALTG) StrRet_P +=2;

	StrAux[0] = StrRet_P[0];
	StrAux[1] = StrRet_P[1];
	StrAux[2] = '\0';
	
	StrCarc[0] = char(convHexInt(StrAux));
	strcat(TipoTrans, StrCarc);

	memset(StrAux,0x00,sizeof(StrAux));

	StrAux[0] = StrRet_P[2];
	StrAux[1] = StrRet_P[3];
	StrAux[2] = '\0';

	StrCarc[0] = char(convHexInt(StrAux));
	strcat(TipoTrans, StrCarc);
//	cout << "TipoTrans " << TipoTrans << endl;	
	DigHexCvc1[0] = StrRet_P[8];
	DigHexCvc1[1] = StrRet_P[9];

	DigHexCvc2[0] = StrRet_P[10];
	DigHexCvc2[1] = StrRet_P[11];

	DigHexCvc3[0] = StrRet_P[12];
	DigHexCvc3[1] = StrRet_P[13];

	DigCvc1 = char(convHexInt(DigHexCvc1));
	DigCvc2 = char(convHexInt(DigHexCvc2));
	DigCvc3 = char(convHexInt(DigHexCvc3));

//	cout << "CodMsg " << CodMsg << endl;	
//	cout << "dig1 " << DigCvc1 << "dig2 " << DigCvc2 << "dig3 " << DigCvc3 << endl;
	if ((CodMsg = 100 || CodMsg == 200)     && 
		((strcmp(TipoTrans,"R1") == 0) || 
	     (strcmp(TipoTrans,"R2") == 0) ||
		 (strcmp(TipoTrans,"CP") == 0) ||
		 (strcmp(TipoTrans,"AD") == 0))     &&	
		((isdigit(DigCvc1))   && 
		 (isdigit(DigCvc2))   && 
		 (isdigit(DigCvc3)))) 
	{
		StrRet_P += 8;
		memcpy(StrRet_P,"404040", 6);	
//		cout << "MSK1 " << StrRet << endl;
	}
//	cout << "MSK2 " << StrRet << endl;
	
	return(StrRet); 
}

// *** Mascara CRE ***
char * Mask_Interpreter::Mask_CVC2CRE(int CodMsg, const char *Str)
{
	static char StrRet[2048] = {0};
	char *StrRet_P;
	char StrAux[5] = {0};
	int IdTrans, LenRet, FlagMask = 0, IdTecno;


	LenRet = strlen(Str);
	memset(StrRet,0, sizeof(StrRet));
	memcpy(StrRet,Str, LenRet);

	StrRet_P = StrRet;
	// cout << "DE48 " << StrRet_P << endl;
	
	StrRet_P += 6;

	StrAux[0] = StrRet_P[1];
	StrAux[1] = StrRet_P[3];
	StrAux[2] = StrRet_P[5];
	StrAux[3] = '\0';
	// cout << "StrAux " << StrAux << endl;
	IdTrans = atoi(StrAux);
	// cout << "CodMsg " << CodMsg << endl;
	// cout <<  "IdTrans " << IdTrans << endl;

	if((CodMsg == 100) && 
		(IdTrans == 20  || 
		 IdTrans == 101 || 
		 IdTrans == 102 || 
		 IdTrans == 103 ||
		 IdTrans == 105 ||
		 IdTrans == 107)||
		 IdTrans == 108 ||
         IdTrans == 109 ||
         IdTrans == 110)
	{
		memset(StrAux,0x00,5);

		StrAux[0] = StrRet_P[7];
		StrAux[1] = StrRet_P[9];
		StrAux[0] = '\0';
		
		IdTecno = atoi(StrAux);
	
		if ((IdTecno == 84) ||
			(IdTecno == 85) ||
			(IdTecno == 86))
		    StrRet_P += 40;	
	     else
		    StrRet_P += 24;

		FlagMask = 1;
	}
 else 
	if(CodMsg == 120)
	{
		StrRet_P  += 40;
		FlagMask = 1;
	}
	// cout << "CVC2 " << StrRet_P << endl;
	if (FlagMask == 1)
	{
		if( strncmp( StrRet_P, "404040", 6) != 0 ) {
	//			cout << "DigCvc1 " << *(StrRet_P + 1) << " DigCvc2 " << *(StrRet_P + 3) << " DigCvc3 " << *(StrRet_P + 5)  << endl;
			if ((isdigit(*(StrRet_P + 1))) && (isdigit(*(StrRet_P + 3))) && (isdigit(*(StrRet_P + 5)))) {
				strncpy(StrRet_P,"@@@@@@",6);
			}
		}
	}
 
	// cout << "MSKE48 " << StrRet_P << endl;

	return(StrRet); 
}

// *** Mascara AVR ***
char * Mask_Interpreter::Mask_CVC2AVR(int CodMsg, const char *Str)
{
	int LenRet;
	static char StrRet[2048] = {0};
	char *StrRet_P;

	char DigHexCvc1[3] = {0};
	char DigHexCvc2[3] = {0};
	char DigHexCvc3[3] = {0};

	char DigCvc1;
	char DigCvc2;
	char DigCvc3;

	LenRet = strlen(Str);
	memset(StrRet,0, sizeof(StrRet));
	memcpy(StrRet,Str, LenRet);

	StrRet_P = StrRet;

	if(CodMsg == 100 || CodMsg == 120)
	{
		StrRet_P += 22;

		if( strncmp( StrRet_P, "404040", 6) != 0 ) {
			DigCvc1 =  StrRet_P[1];
			DigCvc2 =  StrRet_P[3];
			DigCvc3 = StrRet_P[5];
			if ((isdigit(DigCvc1)) && (isdigit(DigCvc2)) && (isdigit(DigCvc3)))
				strncpy(StrRet_P,"@@@@@@",6);
		}
	}

	return(StrRet);
}

// *** Mascara MCI ***
char * Mask_Interpreter::Mask_CVC2MCI(int CodMsg, const char *Str)
{
	int LenRet, IdSubElement, LenLenField, Size = 0, StrSize = 0;
	static char StrRet[2048] = {0};
	char maskStr[8] = {0};
	char StrAux[5] = {0};
	char *StrRet_P;

	LenRet = strlen(Str);
	memset(StrRet,0, sizeof(StrRet));
	memcpy(StrRet,Str, LenRet);

	StrRet_P = StrRet;

	StrAux[0] = StrRet_P[1];
	StrAux[1] = StrRet_P[3];
	StrAux[2] = StrRet_P[5];
	StrAux[3] = '\0';

	Size = (atoi(StrAux)*2);
	StrSize = 8; // Somados Size e TCC

	StrRet_P += 8; // Size e TCC
	IdSubElement = 0;		
	while ((StrSize < Size) || (IdSubElement == 92))
	{
		/* Determina o ID do Sub-element */
		StrAux[0] = StrRet_P[1];
		StrAux[1] = StrRet_P[3];
		StrAux[2] = '\0';
		
		IdSubElement = atoi(StrAux);

		memset(StrAux,0x00,sizeof(StrAux));
		
		/* Determina o Tamanho do Sub-element */
		StrAux[0] = StrRet_P[5];
		StrAux[1] = StrRet_P[7];
		StrAux[2] = '\0';

		LenLenField = atoi(StrAux);
		
		if (IdSubElement != 92)
		{
			StrRet_P +=  8 + (LenLenField *= 2);
		}
		/* 0584_SW - Adequacao LogReader CVC2 Amex - JPFC - Inicio */
		else 
		{
			if ( LenLenField <= 4 )
			{
				StrRet_P += 8; // Size Field Subelement + Length Field
				memset(maskStr, '@', LenLenField * 2);
				strncpy(StrRet_P, maskStr, LenLenField * 2);
				break;
			}
			else
			{
				StrRet_P += 8; // Size Field Subelement + Length Field
				memset(maskStr, '@', 8);
				strncpy(StrRet_P, maskStr, 8);
				break;
			}
		}
		/* 0584_SW - Adequacao LogReader CVC2 Amex - JPFC - Fim */

		if (( this->idLog == LOG_ACQPDVPROTOM ) || ( this->idLog == LOG_ACQPDVKMS ))
		{

		   StrSize += (8 + (LenLenField *= 2));
		} else {   
		StrSize += LenLenField;
		}
	}
	
	return(StrRet); 
}

int Mask_Interpreter::setFlagDisplay( int _flag)
{

	flagDisplay = _flag;

	return 0;
}

int Mask_Interpreter::getFlagDisplay()
{

	return flagDisplay;

}


int Mask_Interpreter::validMsgType(int mtype)
{
    int ret = -1; // valor default - msgtype invalido

    switch (mtype)
    {
        case 100: // pre-autorizacao
        case 200: // venda
        case 202: // confirmacao
        case 220: // advice
        case 400: // estorno
        case 420: // desfazimento
        case 500: // adm
        case 600: // pooling
        case 800: // adm
        case 1624: // rav
            // mtype request
            ret = 0;
            break;

        case 110: // pre-autorizacao
        case 210: // venda
        case 230: // advice
        case 410: // estorno
        case 430: // desfazimento
        case 510: // adm
        case 610: // pooling
        case 810: // adm
        case 1634: // rav
            // mtype response
            ret = 1;
            break;
    }

    return ret;
}