/*
Copyright 2016 Rede S.A.
*********************** MODIFICA��ES ************************
Autor : Sandra Silveira
Data : 19/02/2016
Empresa : Rede
Descri��o: Cria��o do arquivo de tratamento para CAPAMEX e REVAMEX
ID : AM 147.449
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 15/10/2017
Empresa  : Rede
Descri��o: Upgrade Captura - ELOVAN / AMEX
ID       : AM 61.353
*************************************************************
*/

#include "MaskCapAmexInterpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <iostream>

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

MaskCapAmexInterpreter::MaskCapAmexInterpreter( int _max, int _headerSize ):Mask_Interpreter( _max, _headerSize )
{

}

MaskCapAmexInterpreter::~MaskCapAmexInterpreter()
{

}


void MaskCapAmexInterpreter::maskRecord( const char* _record )
{

	int aux;
	int curPos;
	int cardPos;

	static char returnString[2048] = {0x00};
	memset(returnString, 0 , sizeof(returnString));
	strcpy(returnString, _record);

	if (returnString[0] == '1')
	{
		cardPos   = 72; 

		curPos = cardPos;

		if (returnString[curPos] != ' ')
		{
			curPos += 6;
			aux = curPos;
			while ((returnString[aux] != ' ') && ((aux - curPos) < 13))
				aux++;
			for ( ;curPos < (aux - 4);curPos++)
				returnString[curPos] = '@';
		}

	}
	strcpy(this->retorno, returnString);
}

