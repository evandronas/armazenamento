// Mask_CAPDEB_Interpreter.cpp: implementation of the Mask_CAPDEB_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#include "Mask_CAPDEB_Interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_CAPDEB_Interpreter::Mask_CAPDEB_Interpreter( int _max, int _headerSize ):Mask_Interpreter( _max, _headerSize )
{

}

Mask_CAPDEB_Interpreter::~Mask_CAPDEB_Interpreter()
{

}


void Mask_CAPDEB_Interpreter::maskRecord( const char* _record )
{

	int aux;
	int curPos;
	int cardPos;
	int trail2Pos;

	static char returnString[2048] = {0x00,};
 	memset(returnString, 0 , sizeof(returnString));

	strcpy(returnString, _record);

	if (returnString[0] == '1')
	{
		cardPos   = 93+5;   // Somamos 5 por causa do aumento do campo NSU de 7 para 12,
		trail2Pos = 165+5;  // sendo este um campo anterior aos mascarados.

		curPos = cardPos;

		if (returnString[curPos] != ' ')
		{
			curPos += 6;
			aux = curPos;
			while ((returnString[aux] != ' ') && ((aux - curPos) < 13))
				aux++;
			for ( ;curPos < (aux - 4);curPos++)
				returnString[curPos] = '@';
		}

		curPos = trail2Pos;

		if (returnString[curPos] != ' ')
		{
				if (isalpha(returnString[curPos]))
						curPos += 7;
				else
						curPos += 6;

				aux = curPos;
				while ((isdigit(returnString[aux]))&&
						((aux - curPos) < 14))
						aux++;
				for ( ;curPos < (aux - 4);curPos++)
						returnString[curPos] = '@';

				curPos += 5; /* final do cart�o + delimitador */
				if (isdigit(returnString[curPos]))
						curPos += 7;
				for ( ;curPos < (trail2Pos+37);curPos++)
						returnString[curPos] = '@';
		}
	}
	strcpy(this->retorno, returnString);
}

