// Mask_AVR_Interpreter.cpp: implementation of the Mask_AVR_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#include "Mask_AVR_Interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include "Fields.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_AVR_Interpreter::Mask_AVR_Interpreter( int _max, int _headerSize, int _mapType ):Mask_Interpreter( _max, _headerSize, _mapType  )
{

}

Mask_AVR_Interpreter::~Mask_AVR_Interpreter()
{

}


void Mask_AVR_Interpreter::maskRecord( const char* _record )
{
	int i;
	int pos = 0;
	int siz;
	int size;
	int type;
	int code;
	char bufferAux[MAX_VALUE_LEN];
	char auxiliar[2048];

    char bufferConv[2048];
    char bufferConv2[2048];
    FilterHandler conv;
	bool isFix=TRUE;
    char c_siz[4];
    char c_bit[4];


	int recordSize;
	recordSize = strlen(_record);

	int sizeOK;
	sizeOK = OK;

	memset(this->retorno, 0, sizeof(this->retorno));

//	cout << "usedBits= " << this->usedBits << endl;
	code = 2; // XEBCDIC

    for ( i = 0; ((i < this->usedBits) && (sizeOK == OK)); i++ )
    {
        memset(bufferAux, 0, sizeof(bufferAux));
		memset(auxiliar, 0, sizeof(auxiliar));
        size = 0;
		type = 0;
        switch (this->bitsUsed[i])
        {
			//
			// Campos de tamanho fixo
			//

			// Campos de tamanho 04
            case 39:
            case 67:
            {
				siz = 2;
                if ((pos + 4) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 4);
        	        auxiliar[4] = '\0';
					pos += 4;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }


			// Campos de tamanho 06
            case 22:
            case 49:
            {
				siz = 3;
                if ((pos + 6) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 6);
					auxiliar[6] = '\0';
					pos += 6;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 08
            case 14:
		    {
				siz = 4;
                if ((pos + 8) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 8);
					auxiliar[8] = '\0';
					pos += 8;
					isFix=TRUE;	
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 12
            case 3:
            case 11:
            case 38:
            {
				siz = 6;
                if ((pos + 12) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 12);
					auxiliar[12] = '\0';
					pos += 12;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 16
            case 41:
            {
				siz = 8;
                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
					auxiliar[16] = '\0';
					pos += 16;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 20
            case 7:
            {
				siz = 10;
                if ((pos + 20) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 20);
					auxiliar[20] = '\0';
					pos += 20;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 24
            case 4:
            case 37:
            {
				siz = 12;
                if ((pos + 24) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 24);
					auxiliar[24] = '\0';
					pos += 24;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 30
            case 42:
            {
				siz = 15;
                if ((pos + 30) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 30);
					auxiliar[30] = '\0';
					pos += 30;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 84
            case 90:
            {
				siz = 42;
                if ((pos + 84) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 84);
					auxiliar[84] = '\0';
					pos += 84;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }


			//
			// Campos de tamanho vari�vel
			//

			// Campos vari�veis LLvar
            case 32:
            {
				type = 1;
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 4);
					pos += 4;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+4] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos vari�veis LLLvar
            case 60:
            case 62:
            case 63:
            {
				type = 2; 
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';
					siz =  atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 6);
					pos += 6;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Campos de tamanho vari�vel com mascaramento
			//

			case 2:
			{
				type = 1;
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					siz =  atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_2102(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
			}

			case 48:
            {
				type = 2;
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					siz =  atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat( auxiliar, Mask_SelLayOut( 0,0, _record+ pos), size + 6);
					auxiliar[size+6] = '\0';
					pos += 6;
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
			//
			default:
			{
				sizeOK = NOK;
			}

        }


        if ( this->getFlagDisplay() != 0 ) {

            strncpy(bufferConv, "", 2048 );
            strncpy(bufferConv2, "", 2048 );
            conv.xebcdic2xascii( (unsigned char*) auxiliar, bufferConv );
            conv.xascii2ascii( (unsigned char*) bufferConv, bufferConv2, strlen(bufferConv)/2 );

            sprintf( c_siz, "%03d", siz );
            sprintf( c_bit, "%03d", this->bitsUsed[i] );

            // ID_226514 - NOVOS PRODUTOS ELO - DE48 FORMATO TLV - LOGREADER - INICIO
            // formata saida do DE48
            if ( this->bitsUsed[i] == 48 )
            {
                char dadosFormatado[1024] = {0};
                memset(dadosFormatado, 0, sizeof(dadosFormatado));
                PrintDE48Data(bufferConv2, strlen(bufferConv2), dadosFormatado);
                memset(bufferConv2, 0, sizeof(bufferConv2));
                strncat(bufferConv2, dadosFormatado, strlen(dadosFormatado));
            }
            // ID_226514 - NOVOS PRODUTOS ELO - DE48 FORMATO TLV - LOGREADER - FIM
        }

        if ( this->getFlagDisplay() == 1 ) {

            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << bufferConv2 << "]" << endl;
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << bufferConv2 << "]" << endl;
            }

        }
        else
        if ( this->getFlagDisplay() == 2 ) {

            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << bufferConv2 << "]";
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << bufferConv2 << "]";
            }
        }


//        cout << "DE[" <<  this->bitsUsed[i] << "] " << auxiliar << endl;
//        cout << "DE [" <<  this->bitsUsed[i] << "] [" << bufferConv2 << "] " << endl;
//        cout << "sizeOK " << sizeOK << endl;


		if (sizeOK == OK)
			strncat(this->retorno, auxiliar, strlen(auxiliar));

	} // final do for

	// Se houve algum erro retorna o registro original
	if (sizeOK == NOK)
	{
		memset(this->retorno, 0, sizeof(this->retorno));
		strncat(this->retorno, _record, strlen(_record));
	}
}


// ID_226514 - NOVOS PRODUTOS ELO - DE48 FORMATO TLV - LOGREADER - INICIO
/// PrintDE48Data
/// Descricao: Formata a saida dos dados TLV do DE48 do AVR-OL
/// EF/ET: EF1
/// Historico: 06/06/2018 - ET1 - Criacao
/// input  : Buffer com os dados de entrada
/// length : Tamanho dos dados de entrada
/// output : Buffer com os dados de saida
void Mask_AVR_Interpreter::PrintDE48Data(char *input, int length, char *output)
{
    char idSubElemento[4] = {0};
    char tamanhoSubElemento[4] = {0};
    char dadosSubElemento[1024] = {0};
    char dadoFormatado[1024] = {0};
    int totalLength = 0;
    int tagDataLength = 0;
    char *dados = NULL;

    totalLength = length;
    dados = input;

    // tratamento do LLLvar
    memset(dadoFormatado, 0, sizeof(dadoFormatado));
    memcpy(dadoFormatado, dados, 3);
    strncat(output, dadoFormatado, strlen(dadoFormatado));
    dados += 3;
    totalLength -= 3;

    // varre o elemento formatando o TLV
    while ( totalLength > 0 )
    {
        memset(idSubElemento, 0, sizeof(idSubElemento));
        memset(tamanhoSubElemento, 0, sizeof(tamanhoSubElemento));
        memset(dadosSubElemento, 0, sizeof(dadosSubElemento));
        memset(dadoFormatado, 0, sizeof(dadoFormatado));

        memcpy(idSubElemento, dados, 3);
        memcpy(tamanhoSubElemento, dados+3, 3);
        tagDataLength = atoi(tamanhoSubElemento);
        memcpy(dadosSubElemento, dados+3+3, tagDataLength);

        // tratamento diferenciado para o CVC2
        if ( strncmp (idSubElemento, "003", 3) == 0 )
        {
            sprintf(dadoFormatado, " %s='***'", idSubElemento);
        }
        else
        {
            sprintf(dadoFormatado, " %s='%s'", idSubElemento, dadosSubElemento);
        }

        strncat(output, dadoFormatado, strlen(dadoFormatado));

        dados += 3 + 3 + tagDataLength;
        totalLength -= 3 + 3 + tagDataLength;
    }
}
// ID_226514 - NOVOS PRODUTOS ELO - DE48 FORMATO TLV - LOGREADER - FIM
