/* Copyright 2017 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#include "MaskEloFullInterpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include "onvertEBCDICtoASCII.h"
#include "FilterHandler.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

/// MaskEloFullInterpreter
/// Metodo Construtor da Classe
/// EF/ET: ET1
/// Historico: [Data] - ET - Descricao
/// 31/01/2017 - Andre Morishita - ET1 - Criacao da versao inicial
/// maximo: tamanho maximo
/// headerSize: tamanho header
/// mapType: tipo da mensagem
MaskEloFullInterpreter::MaskEloFullInterpreter(int maximo, int headerSize, int mapType):Mask_Interpreter( maximo, headerSize, mapType )
{
}

/// ~MaskEloFullInterpreter
/// Metodo Destrutor da Classe
/// EF/ET: ET1
/// Historico: [Data] - ET - Descricao
/// 31/01/2017 - Andre Morishita - ET1 - Criacao da versao inicial
MaskEloFullInterpreter::~MaskEloFullInterpreter()
{
}

/// maskRecord (Metodo herdado da base)
/// Metodo de parse da mensagem
/// EF/ET: ET1
/// Historico: [Data] - ET - Descricao
/// 31/01/2017 - Andre Morishita - ET1 - Criacao da versao inicial
/// 23/02/2017 - Philipe Pompeu/Jose Neto - Release Elo 2018
/// 21/08/2018 - Andre Morishita - ET2 - Inclusao do DE56 e DE100
/// record: registro que se aberto
void MaskEloFullInterpreter::maskRecord( const char* record )
{
    //Declara��o de vari�veis de controle
    int index = 0;
    int posicao = 0;
    int size = 0;
    int size2 = 0;
    int type = 0;
    
    //delcara��o e buffers
    char bufferAuxiliar[MAX_VALUE_LEN] = {0};
    char auxiliar[2048] = {0};
    char auxiliar2[2048] = {0};

    // vari�veis relativas ao DE
    int recordSize = 0;
    recordSize = strlen(record);

    FilterHandler filterHandler;
    char charSize[4] = {0};
    char charBit[4] = {0};

    int sizeOK = 0;
    sizeOK = OK;
    bool isFixo = TRUE;

    memset(this->retorno, 0, sizeof(this->retorno));

    // Para cada DE presente no bitmap, faz o loop para parse
    for ( index = 0; ((index < this->usedBits) && (sizeOK == OK)); index++ )
    {
        memset(bufferAuxiliar, 0, sizeof(bufferAuxiliar));
        memset(auxiliar, 0, sizeof(auxiliar));
        memset(auxiliar2, 0, sizeof(auxiliar));
        size = 0;
        
        //Trata cada DE presente na mensagem (bitmap) de acordo com a mensageria do parceiro
        switch (this->bitsUsed[index])
        {
            //
            // Campos de tamanho fixo
            //
            
            // Campos de tamanho 2
            case 25:
            case 26:
            case 39:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 4) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 4);
                    auxiliar[4] = '\0';
                    posicao += 4;
                    isFixo = TRUE;
                    size=4;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 2);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
        
            // Campos de tamanho 3
            case 19:
            case 22:
            case 23:
            case 24:
            case 49:
            case 70:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 6) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 6);
                    auxiliar[6] = '\0';
                    posicao += 6;
                    isFixo = TRUE;
                    size=6;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 3);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            

            // Campos de tamanho 4
            case 13:
            case 14:
            case 18:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 8) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 8);
                    auxiliar[8] = '\0';
                    posicao += 8;
                    isFixo = TRUE;
                    size=8;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 4);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }


            // Campos de tamanho 6
            case 3:
            case 11:
            case 12:
            case 38:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 12) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 12);
                    auxiliar[12] = '\0';
                    posicao += 12;
                    isFixo = TRUE;
                    size=12;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 6);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            // Campos de tamanho 8
            case 41:
            case 52:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 16) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 16);
                    auxiliar[16] = '\0';
                    posicao += 16;
                    isFixo = TRUE;
                    size=16;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 8);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            // Campos de tamanho 10
            case 7:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 20) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 20);
                    auxiliar[20] = '\0';
                    posicao += 20;
                    isFixo = TRUE;
                    size=20;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 10);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            // Campos de tamanho 12
            case 4:
            case 37:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 24) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 24);
                    auxiliar[24] = '\0';
                    posicao += 24;
                    isFixo = TRUE;
                    size=24;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 12);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }

            
            // Campos de tamanho 15
            case 42:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 30) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 30);
                    auxiliar[30] = '\0';
                    posicao += 30;
                    isFixo = TRUE;
                    size=30;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 15);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            // Campos de tamanho 16
            case 53:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 32) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 32);
                    auxiliar[32] = '\0';
                    posicao += 32;
                    isFixo = TRUE;
                    size=32;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 16);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }

            
            // Campos de tamanho 40
            case 43:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 80) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 80);
                    auxiliar[80] = '\0';
                    posicao += 80;
                    isFixo = TRUE;
                    size=80;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 40);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }

            // Campos de tamanho 42
            case 90:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 84) <= recordSize)
                {
                    strncpy(auxiliar, record+posicao, 84);
                    auxiliar[84] = '\0';
                    posicao += 84;
                    isFixo = TRUE;
                    size=84;

                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) 42);
                        strcpy(auxiliar, auxiliar2);
                        size = size/2;
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }

            
            // CAMPOS DE TAMANHO LLVAR
            case 32:
            case 100: // R10_2018 - Release Outubro
            {
                type = 1;
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 4) <= recordSize)
                {
                    bufferAuxiliar[0] = record[posicao+1];
                    bufferAuxiliar[1] = record[posicao+3];
                    bufferAuxiliar[2] = '\0';
                    size2 = atoi(bufferAuxiliar);
                    size = size2*2;
                    isFixo=FALSE;
                }
                if ((posicao + 4 + size) <= recordSize)
                {
                    strncat(auxiliar, record+posicao, 4);
                    posicao += 4;
                    strncat(auxiliar, record+posicao, size);
                    auxiliar[size+4] = '\0';
                    posicao += size;
                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        size = (size + 4)/2;
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
                        strcpy(auxiliar, auxiliar2);
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            // CAMPOS DE TAMANHO LLLVAR
            case 46:
            case 48:
            case 54:
            case 58:
            case 60:
            case 62:
            case 104:
            case 105:
            case 122: // R10_2018 - Release Outubro
            case 125:
            case 126:
            case 127:
            {
                type = 2;
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 6) <= recordSize)
                {
                    bufferAuxiliar[0] = record[posicao+1];
                    bufferAuxiliar[1] = record[posicao+3];
                    bufferAuxiliar[2] = record[posicao+5];
                    bufferAuxiliar[3] = '\0';
                    size2 =  atoi(bufferAuxiliar);
                    size = size2*2;
                    isFixo=FALSE;
                }
                if ((posicao + 6 + size) <= recordSize)
                {
                    strncat(auxiliar, record+posicao, 6);
                    posicao += 6;
                    strncat(auxiliar, record+posicao, size);
                    auxiliar[size+6] = '\0';
                    posicao += size;
                    // Caso apresenta��o em tela, converte formato
                    if ( this->getFlagDisplay() != 0 ) {
                        size = (size+ 6 )/2;
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
                        strcpy(auxiliar, auxiliar2);
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            // CAMPOS DE TAMANHO LLLVAR BINARIO
            case 55:
            case 56: // ID_231690 - NFC Elo e Diners 
            {
                type = 2;
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 6) <= recordSize)
                {
                    bufferAuxiliar[0] = record[posicao+1];
                    bufferAuxiliar[1] = record[posicao+3];
                    bufferAuxiliar[2] = record[posicao+5];
                    bufferAuxiliar[3] = '\0';
                    size2 =  atoi(bufferAuxiliar);
                    size = size2*2;
                    isFixo=FALSE;
                }
                if ((posicao + 6 + size) <= recordSize)
                {
                    strncat(auxiliar, record+posicao, 6);
                    posicao += 6;
                    strncat(auxiliar, record+posicao, size);
                    auxiliar[size+6] = '\0';
                    posicao += size;
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            //
            // Campos de tamanho com mascaramento
            //
            // PAN
            case 2:
            {
                type = 1;
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 4) <= recordSize)
                {
                    bufferAuxiliar[0] = record[posicao+1];
                    bufferAuxiliar[1] = record[posicao+3];
                    bufferAuxiliar[2] = '\0';
                    size2 = atoi(bufferAuxiliar);
                    size = size2*2;
                    isFixo=FALSE;
                }
                if ((posicao + 4 + size) <= recordSize)
                {
                    posicao += maskFields_2102(record+posicao, auxiliar);
                    if ( this->getFlagDisplay() != 0 ) {
                        size = (size + 4)/2;
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
                        strcpy(auxiliar, auxiliar2);
                    }
                }
                else
                    sizeOK = NOK;
            break;
            }
            
            // Trilha 2
            case 35:
            {
                type = 1;
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 4) <= recordSize)
                {
                    bufferAuxiliar[0] = record[posicao+1];
                    bufferAuxiliar[1] = record[posicao+3];
                    bufferAuxiliar[2] = '\0';
                    size2 = atoi(bufferAuxiliar);
                    size = size2*2;
                    isFixo=FALSE;
                }
                if ((posicao + 4 + size) <= recordSize)
                {
                    posicao += maskFields_35(record+posicao,auxiliar);
                    auxiliar[size+4] = '\0';
                    if ( this->getFlagDisplay() != 0 ) {
                        size = (size + 4)/2;
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
                        strcpy(auxiliar, auxiliar2);
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            // Trilha 1
            case 45:
            {
                type = 1;
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((posicao + 4) <= recordSize)
                {
                    bufferAuxiliar[0] = record[posicao+1];
                    bufferAuxiliar[1] = record[posicao+3];
                    bufferAuxiliar[2] = '\0';

                    size2 = atoi(bufferAuxiliar);
                    size = size2*2;
                    isFixo=FALSE;
                }
                if ((posicao + 4 + size) <= recordSize)
                {
                    posicao += maskFields_45(record+posicao, auxiliar);
                    auxiliar[size+4] = '\0';
                    if ( this->getFlagDisplay() != 0 ) {
                        size = (size + 4)/2;
                        filterHandler.xascii2ascii((unsigned char*)auxiliar, auxiliar2, (long ) size);
                        strcpy(auxiliar, auxiliar2);
                    }
                }
                else
                    sizeOK = NOK;
                break;
            }
            
            // Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
            default:
            {
                sizeOK = NOK;
            }
        }
        


        if ( this->getFlagDisplay() != 0 ) {
        
            sprintf( charSize, "%03d", size );
            sprintf( charBit, "%03d", this->bitsUsed[index] );
        }
        
        // Tratamento para apresneta��o de tela um DE por linha	
        if ( this->getFlagDisplay() == 1 ) {
        
            if ( sizeOK == NOK ) {
                cout << "DE [" <<  charBit << "] [ERRO]" << endl;
            }
            else
            if ( isFixo == FALSE ) {
                cout << "DE [" <<  charBit << "] [V" << charSize << "] [" << auxiliar << "]" << endl;
            }
            else {
                cout << "DE [" <<  charBit << "] [F" << charSize << "] [" << auxiliar << "]" << endl;
            }
        }
        // Tratamento para apresneta��o de tela da mensagem em uma linha
        else {
            if ( this->getFlagDisplay() == 2 ) {
            
                if ( sizeOK == NOK ) {
                    cout << "DE [" <<  charBit << "] [ERRO]" << endl;
                }
                else
                if ( isFixo == FALSE ) {
                    cout << "DE [" <<  charBit << "] [V" << charSize << "] [" << auxiliar << "]";
                }
                else {
                    cout << "DE [" <<  charBit << "] [F" << charSize << "] [" << auxiliar << "]";
                }
            }
        }

        // Adiciona o DE ao buffer principal
        if (sizeOK == OK)
            strncat(this->retorno, auxiliar, strlen(auxiliar));

    } // final do for

    // Se houve algum erro retorna o registro original
    if (sizeOK == NOK)
    {
        memset(this->retorno, 0, sizeof(this->retorno));
        strncat(this->retorno, record, strlen(record));
    }
}
