// Mask_CAPENDPDT_Interpreter.cpp: implementation of the Mask_CAPENDPDT_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#include "Mask_CAPENDPDT_Interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_CAPENDPDT_Interpreter::Mask_CAPENDPDT_Interpreter( int _max, int _headerSize ):Mask_Interpreter( _max, _headerSize )
{

}

Mask_CAPENDPDT_Interpreter::~Mask_CAPENDPDT_Interpreter()
{

}


void Mask_CAPENDPDT_Interpreter::maskRecord( const char* _record )
{

	int aux;
	int curPos;
	int cardPos;

	static char returnString[2048] = {0x00};
	memset(returnString, 0 , sizeof(returnString));

	strcpy(returnString, _record);

	if (returnString[0] == '1')
	{
		cardPos   = 1;

		curPos = cardPos;

		if (returnString[curPos] != ' ')
		{
			curPos += 6;
			aux = curPos;
			while ((returnString[aux] != ' ') && ((aux - curPos) < 13))
				aux++;
			for ( ;curPos < (aux - 4);curPos++)
				returnString[curPos] = '@';
		}
	}
	strcpy(this->retorno, returnString);
}

