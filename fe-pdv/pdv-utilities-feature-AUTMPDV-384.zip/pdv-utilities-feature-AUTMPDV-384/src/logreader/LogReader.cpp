/**
*
*	LogReader
*
******
*
* Vers�o: 2.0.1.1
*	Data: 18/05/2011
* Altera��o: Inclu�do o tratamento para o Log CEF PDV
* Autor: Fabio Mazzer  (servicoresource696181@redecard.com.br)
*
*
///////////
*
* Vers�o: 2.0.2.0
*	Data: 30/06/2011
* Altera��o: Inclu�do o tratamento para o Log Hipercard (hc)
* Autor: Fabio Mazzer  (servicoresource696181@redecard.com.br)
*  
////////////////////////////////////////
///////////
*
* Vers�o: 2.0.2.1
*	Data: 18/07/2011
* Altera��o: Inclu�do o tratamento para o Log Calcard e AVISTA (calcard e avista)
* Autor: Ligia Andrade  (ligia.andrade@redecard.com.br)
*  
////////////////////////////////////////
///////////
*
* Vers�o: 2.0.2.2
*	Data: 13/09/2011
* Altera��o: Inclu�do o tratamento para o Log CRT Credsystems (credsysvan e credsysfull)
* Altera��o: Inclu�do o tratamento para o Log HST Vb beneficios e coopercred voucher (vbbn e ipcoop)
* Autor: Ligia Andrade  (ligia.andrade@redecard.com.br)
*  
*
* Vers�o: 2.0.2.3
*	Data: 13/09/2011
* Altera��o: Inclu�do o tratamento para a coopercred VAN
* Autor: Ligia Andrade  (ligia.andrade@redecard.com.br)
*  
*
* Vers�o: 2.0.2.4
*	Data: 15/09/2011
* Altera��o: Inclu�do o tratamento para a SOROCRED VAN e criado fonte espec�fico para o ITAUPL
* Autor: Fabio Mazzer  (servicoresource696181@redecard.com.br)
*
*
* Vers�o: 2.0.2.5
*       Data: 10/04/2012
* Altera��o: Inclu�do o tratamento para transacoes administrativas do PB
* Autor: Carlos Borges (carlos.borges@redecard.com.br)

* Vers�o: 2.0.2.6
*       Data: 08/05/2012
* Altera��o: Inclu�do o tratamento para transacoes  da sodexo
* Autor: Eduardo Paiva (eduardo.paiva@redecard.com.br)

* Vers�o: 2.0.2.7
*       Data: 18/10/2012
* Altera��o: Inclu�do o tratamento para transacoes RAV
* Autor: Ricardo Calegaro (eduardo.paiva@redecard.com.br)

* Vers�o: 2.0.2.8
*	Data: 12/11/2012
* Altera��o: Inclu�do o tratamento para a o FE-WEB  os logs avr e ol
* Autor: Fabio Mazzer  (fabio.mazzer@redecard.com.br)
*
*       Data: 25/01/3013
* Altera��o: Inclu�do tratamento para Voucher Chip
* Autor: Sandra (sandra.silveira@redecard.com.br)

* Vers�o: 2.0.2.9
*	Data: 03/12/2012
* Altera��o: Inclu�do o tratamento para a o FE-WEB novo komerci 
* Autor: Francine Bellucco  (francine.bellucco@redecard.com.br)
*

* Vers�o: 2.0.3
*	Data:05/02/2013
* Altera��o: Inclu�do o tratamento para a o FE-WEB MPG 
* Autor: Francine Bellucco  (francine.bellucco@redecard.com.br)
*

* Vers�o: 2.0.4
*	Data:04/06/2013
* Altera��o: Inclu�do o tratamento para arquivos de captura
* Autor: Jo�o Henrique de Moraes Silva  (servicoresource694677@redecard.com.br)
*
* Vers�o: 2.0.5
*	Data:11/07/2013
* Altera��o: Inclu�do o tratamento para a o FE-POS e FE-PDV 
* Autor: Jo�o Henrique de Moraes Silva  (servicoresource694677@redecard.com.br)
*
* Vers�o: 2.0.5
*	Data:05/12/2014
* Altera��o: Inclu�do o tratamento DEs 126, 127 e 128 do WEB
* Autor: Renato de Camargo  (renato.camargo@userede.com.br)
*
* Vers�o: 2.0.6
*	Data:06/11/2013
* Altera��o: Inclu�do o tratamento para a o FE-POS e FE-PDV 
* Autor: Francine Bellucco  (francine.bellucco@userede.com.br)
*

* Vers�o: 2.0.7
*	Data:14/08/2014
* Altera��o: Inclu�do o tratamento do log "hipdeb"(FE-DBTM para tratar as transa��es de d�bito da hiper)
* Autor: Ligia Andrade  (ligia.andrade@userede.com.br)
* Merge efetuado por: Diego Lima
*
**////////////////////////////////////////
/*
Copyright 2015 Rede S.A.
*********************** MODIFICA��ES ************************
Autor    : Diogo Fernandes
Data     : 15/02/2015
Empresa  : Rede
Descri��o: Multicaptura ELO
ID       : 91915 - SW Multicaptura ELO
*************************************************************
Autor    : Fernanda Carvalho
Data     : 20/03/2015
Empresa  : Rede
Descri��o: Multicaptura Amex
ID       : 92100 - SW Multicaptura Amex
*************************************************************
Autor    : Igor Oliveira
Data     : 15/05/2015
Empresa  : Stefanini
Descri��o: Nova Bandeira Mastercard Itau
ID       : 106001 - Nova Bandeira Mastercard Itau
*************************************************************
Autor    : Andre Morishita
Data     : 31/12/2015
Empresa  : Stefanini
Descri��o: Alteracao para abertura das mensagens do AVISTA
ID       : 145342 Avista no modelo Tarja + Senha - SW75
*************************************************************
Autor    : Igor Oliveira
Data     : 20/01/2016
Empresa  : Stefanini
Descri��o: Inclusao do projeto do Programa de Captura de Bandeiras
ID       : 146912 - Programa de Captura de Bandeiras
*************************************************************
Autor    : Fabio Mazzer
Data     : 13/06/2016
Empresa  : Rede
Descri��o: Merge com vers�o para inclus�o dos FEs POS e PDV SW 7.5
*************************************************************
Autor    : Andre Morishita
Data     : 30/01/2017
Empresa  : Leega
Descri��o: Inclusao dos logs da Amex Full e Elo Full
ID       : 184820
Autor    : Misunori Namioka
Data     : 03/03/2017
Empresa  : Fidelity
Descri��o: Merge com vers�o para inclus�o do POS-IP.
*************************************************************
Autor    : Ana Carolina Dias Silva
Data     : 10/07/2017
Empresa  : Rede
Descri��o: 0677_SW - Correcao LogReader JCB
ID       : 181.389, AM188.918
*************************************************************
Autor    : Andre Morishita
Data     : 14/07/2017
Empresa  : Leega
Descri��o: Tokenizacao MPV2
ID       : 200293
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 15/10/2017
Empresa  : Rede
Descri��o: Upgrade Captura - ELOVAN / AMEX
ID       : AM 61.353
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 25/09/2018
Empresa  : Rede
Descri��o: Inclusao TPDU INAC
ID       : AM 228.120
*************************************************************
Autor    : Danielle Cristina Pereira
Data     : 03/10/2017
Empresa  : Rede
Descricao: Upgrade Captura - Impressão de campos em Hexa e 
alteracao do tamanho do header de IN ou OUT do POSIP
ID       : AM 231.044
*************************************************************
Autor    : Andre Morishita
Data     : 05/02/2019
Empresa  : Leega
Descri��o: J3 - ITI
ID       : 200999
*************************************************************
Autor    : Igor Oliveira
Data     : 02/04/2019
Empresa  : Leega
Descri��o: VOUCHER SFORZA
ID       : J5_2019
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 26/06/2019
Empresa  : Rede
Descri��o: Adicionando tratamento para QH
ID       : EAK - 1593
*************************************************************
Autor    : Fernando Brum
Data     : 24/07/2019
Empresa  : Rede
Descri��o: Tratamento mensagens PDV INAC
ID       : EAK-1623
*************************************************************
Autor    : Andre Morishita
Data     : 08/10/2019
Empresa  : Leega
Descri��o: Novo Debito Mastercard
ID       : AM257779
*************************************************************
Autor    : Danielly Neves
Data     : 14/02/2020
Empresa  : Rede
Descri��o: QrCode
ID       : AM263537
*************************************************************
Autor    : Eduardo De Souza
Data     : 03/03/2020
Empresa  : Rede
Descri��o: Tratamento mensagens PDV INAC
ID       : EAK-2455
*************************************************************
Autor    : James Cooley
Data     : 18/08/2020
Empresa  : Rede
Descri??o: Tratamento no arquivo de log para abrir .debug
ID       : AUT2-3058
*************************************************************
Autor    : Andre Morishita
Data     : 22/10/2020
Empresa  : Leega
Descri??o: Inclusao do Hub de Bandeiras
ID       : HUB de Bandeiras
*************************************************************
Autor    : Andre Morishita
Data     : 24/08/2021
Empresa  : Leega
Descri??o: Inclusao do Projeto DCC
ID       : AUT1-4011
*************************************************************
Autor    : Andre Morishita
Data     : 10/12/2021
Empresa  : Leega
Descri��o: AUT2-4397 - Tap On Phone
ID       : AUT2-4397
*************************************************************
*/

#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>

#include "Mask_Factory.h"
#define         OPTSTRING               "olOL"

using namespace std;

class LogReader { 
	public:
		LogReader(int , char ** );
		~LogReader(){}; 
		int getIdLog();
		void getLogName(char * );
		int getLayoutDe48();
		void usage();
		int isCapture();
		int flagStdin;
		int flagDisplay;
	private:
		int idLog;
		int detail;
		int idSis;
		int layout;
		char sis[10];	
		char logName[256];
		char complemento[20];
		char adInfo[20];
		void getLogPath(char * );
    	bool fileExists(const char *);
	protected:
		int getIdLogDbt(char * );
		int getIdLogDbtm(char * );
        int GetIdentifierLogDbto( char *complemento );
		int getIdLogHst(char * ) ;
		int getIdLogCrt(char * );
		int getIdLogCrtm(char * );
        int GetIdentifierLogCrto( char *complemento );
		int getIdLogWeb(char * );
		int GetIdLogPos(char * );
		int GetIdLogPdv(char * );
		int getIdLogCapture(char * );
		int getIdSis(char * sist);
		int getLayoutHst(int );
		int getLayoutDbt(char * );
		int getLayoutCrt(char * );
		int getLayoutDbtm(char * );
        int GetLayoutDbto( char *complemento);
		int getLayoutCrtm(char * );
        int GetLayoutCrto( char *complemento);
		int getLayoutWeb(char * );
		int GetLayoutPos(char * );
		int GetLayoutPdv(char * );
};

#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>




static char *opt[] = {"DBT", "CRT", "HST", "WEB","DBTM", "CRTM", "POS", "PDV", "CAP", "CRTO", "DBTO", NULL};
static char *hst[] = { "smnt", "fini", "visi", "fide", "bbra", "brad", "fic", "bnqt", "ptsg", "credsyspl", NULL};
static char *cap[] = {"CRED","DEB", "NFIN", "PRIV", "END", "ENDPDT", "CREDMTVN", "CREDVISA", 
                      "DEBVISA", "ENDPDTVISA", "CREDVISAD", "CREDD", "DEBVISAD", "DEBD", "ELOVAN", "AMEX",  NULL};

extern int optind, opterr, optopt;

LogReader::LogReader(int numargs, char **args)
{
	int idx;		
        if(numargs < 2) {
                usage();

        }
	args++;
	flagStdin = 0;
    flagDisplay = 0; // funciona como a vers�o anterior

	if( *args!= NULL)
	if(strcasecmp(*args,"stdin") == 0) {
		flagStdin = 1;
		args++;
	}

    if( *args!= NULL)
	{
    if(strcasecmp(*args,"open") == 0) {
        flagDisplay = 1;
		args++;
    }else {
        if(strcasecmp(*args,"line") == 0) {
           flagDisplay = 2;
		   args++;
        }
    }
}
        this->idSis = getIdSis(*args);
        if(this->idSis != -1) {
		if( *args!= NULL)
                	strcpy(this->sis, *args);
		
                memset(this->complemento, 0, sizeof(this->complemento));
                memset(this->adInfo, 0, sizeof(this->adInfo));
                if(numargs > 2) {
			args++;
			if( *args!= NULL)
                        	strcpy(this->complemento, *args);
                }
                if(numargs > 3) {
			args++;
			if( *args!= NULL)
 				strcpy(this->adInfo, *args);
                }
        }
        memset(logName,0, sizeof(logName));
}


void LogReader::usage()
{
    cout << "Versao [3.0.10] - 27/12/2021\n";
	cout << "LogReader < stdin < open | line > >\n"; 
	cout << "\t\t[ HST  [ smnt | hstpp | hstpv | tktc | tkch | fini | itaupl |\n\t\t\t visi | cef | cefpv | nutr | vchr | cabal | plvl |\n\t\t\t vrcq | srcr | fide | grsp | sdxo | vale | bnbc |\n\t\t\t bbra | brad | fic | bnqt | gncd | ptsg |";
    cout << "\n\t\t\t credsyspl | ipcoop | vbbn | hostpb | hostdef |" ;
    cout << "\n\t\t\t sodexo | ravp | alelo | vr | iti | sforza | wq3 |" ;
    cout << "\n\t\t\t rdcmp | ben | plnt ] ] \n" ;
	cout << "\t\t[ DBT  [ mae | visa | sicredi | cabal | elo | banescard | rdcmp ] ]\n";
	cout << "\t\t[ CRT  [ di | dv | mci | visa | sicredi | cabal |\n\t\t\t coopvn | cupcred | sorocred | srcrvn | hc | calcard |";
    cout << "\n\t\t\t avista | credsysvan | credsysfull | elo | amex |";
    cout << "\n\t\t\t banescard | credz | rdcmp ] ]\n";
	cout << "\t\t[ DBTM [ mae | sicredi | hipdeb | mait | dmc ] ]\n";
	cout << "\t\t[ CRTM [ di | dv | mci | sicredi | mcit | jcb ] ]\n";
	cout << "\t\t[ WEB  [ avr | ol | ec | mpg | tpdu] ]\n";
	cout << "\t\t[ POS  [ posmtg | pdvdialmtg | postg | pdvdialtg | posip | posipdec | posqh | poswq3 | postop | postopdec ] ] \n";
	cout << "\t\t[ PDV  [ protom | pdvip | bigip | kms | inac | inac1 | inac2 | inac3 |\n\t\t\t inac4 | inac5 | pdvqh | pdvcorban ] ] \n";
	cout << "\t\t[ CAP  [ POS | PDV ]  [ CRED | DEB | NFIN | PRIV | END | ENDPDT |\n\t\t\t\t\tCREDMTVN | CREDVISA | DEBVISA | ENDPDTVISA |\n\t\t\t\t\tCREDVISAD | CREDD | DEBVISAD | DEBD | ELOVAN | AMEX ] ] \n"; 
	cout << "\t\t[ CRTO [ amex | elo ] ]\n";
    cout << "\t\t[ DBTO [ elo ] ]\n";
	exit(0);
}

int LogReader::getIdLog()
{
	if(strlen(this->complemento) == 0) {
			cout << "\nArgumentos insuficientes!\n\n\n";
			usage();	
			exit(0);
	}
	else {
		switch(idSis)
		{
		case 0:
			idLog = getIdLogDbt(complemento);
			break;
		case 1:
			idLog = getIdLogCrt(complemento);
			break;
		case 2:
			idLog = getIdLogHst(complemento);
			break;
		case 3:
			idLog = getIdLogWeb(complemento);
			break;
		case 4:
			idLog = getIdLogDbtm(complemento);
			break;
        case 5:
            idLog = getIdLogCrtm(complemento);
			break;
		case 6:	
			idLog = GetIdLogPos(complemento);
			break;
		case 7:
  		    idLog = GetIdLogPdv(complemento);
			break;	
		case 8:
		    if(strlen(adInfo) == 0) {
				cout << "Falta identificacao do tipo de captura\n";
				usage();
			} 
			idLog = getIdLogCapture(adInfo);
			break;    	
            
        case 9:
            idLog = GetIdentifierLogCrto(complemento);
            break;
            
        case 10:
            idLog = GetIdentifierLogDbto(complemento);
            break;
            
		default:
			cout << "Sistema inexistente\n";
			usage();
			break;
		}
	}
     //cout << "getIdlog idlog--->:\t" << idLog << endl;
	return idLog;
}


int LogReader::getLayoutDe48()
{
	switch(idSis) {
	case 0:
		layout = getLayoutDbt(complemento);
		break;
	case 1:
		layout = getLayoutCrt(complemento);
		break;
	case 2:
		layout = getLayoutHst(this->idLog);
		break;
	case 3:
		layout = getLayoutWeb(complemento);
		break;
	case 4:
		layout = getLayoutDbtm(complemento);
		break;
	case 5:
		layout = getLayoutCrtm(complemento);
		break;
	case 6:
        	layout = GetLayoutPos(complemento);
		break;
    	case 7:
        	layout = GetLayoutPdv(complemento);
		break;	
        
    case 9:
        layout = GetLayoutCrto(complemento);
        break;
        
    case 10:
        layout = GetLayoutDbto(complemento);
        break;

        
	default:
		layout = -1;
	}

     //cout << "getLayoutDe48--->:\t" << layout << endl;	
	return layout;
}


int LogReader::getIdLogCrt(char * complemento)
{
	int idLogi = 0;
	if(strcasecmp(complemento, "di") == 0) { //dinners
		idLog = 1; 
	}
	else
	if(strcasecmp(complemento, "dv") == 0) { //on-us
		idLog = 1;
	}
	else
	if(strcasecmp(complemento, "mci") == 0) { //off-us
		idLog = 4;
	}
	else
	if(strcasecmp(complemento, "visa") == 0) { //visa
		idLog = 200;
	}
	else
	if(strcasecmp(complemento, "cabal") == 0) { //cabal
		idLog = 15;
	}
	else
	if(strcasecmp(complemento, "sicredi") == 0) {
		idLog = 15; //sicredi (Maestro)
	}
	else
	if(strcasecmp(complemento, "coopvn") == 0) {
		idLog = 17; // COOP
	}
	else
	if(strcasecmp(complemento, "hc") == 0) {
		idLog = 1;
	}
	else
	if(strcasecmp(complemento, "sorocred") == 0) {
		idLog = 15;
	}
	else
	if(strcasecmp(complemento, "srcrvn") == 0) {
		idLog = 17;
	}
	else
	if(strcasecmp(complemento, "cupcred") == 0) {
		idLog = 201;
	}
	else
	if(strcasecmp(complemento, "calcard") == 0) {
		idLog = 15; //sicredi (Maestro)
	}
	else
	if(strcasecmp(complemento, "avista") == 0) {
		idLog = 17;
	}
	else
	if(strcasecmp(complemento, "credsysvan") == 0) {
		idLog = 1;
	}
	else
	if(strcasecmp(complemento, "credsysfull") == 0) {
		idLog = 15;
	}
	else
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - INICIO */
	if(strcasecmp(complemento, "banescard") == 0) { //BANESCARD
		idLog = 15;
	}
	else
	if(strcasecmp(complemento, "credz") == 0) { //CREDZ
		idLog = 15;
	}
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - FIM */
	else
	if(strcasecmp(complemento, "elo") == 0) { //ELO CRT
		idLog = LOG_ELO; 
	}
	else
	if(strcasecmp(complemento, "amex") == 0) { //AMEX CRT
		idLog = LOG_AMEX; 
	}
    /* HUB de Bandeiras - INICIO */
    else
    if(strcasecmp(complemento, "rdcmp") == 0) { 
        idLog = 17;
    }
    /* HUB de Bandeiras - FIM */
	else{
		cout << "Complemento invalido! \n\n";
		usage();
		exit(0);
	}
	return idLog;
}

int LogReader::getIdLogDbt(char * complemento)
{
	int idLog;
	if(strcasecmp(complemento, "mae") == 0) {
		idLog = 3; //MDS (Maestro)
	}
	else
	if(strcasecmp(complemento, "sicredi") == 0) {
		idLog = 15; //sicredi (Maestro)
	}
	else
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - INICIO */
	if(strcasecmp(complemento, "banescard") == 0) { //BANESCARD
		idLog = 15;
	}
	else
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - FIM */
	if(strcasecmp(complemento, "cabal") == 0) {
		idLog = 15; //cabal 
	}
	else
	if(strcasecmp(complemento, "visa") == 0) {
		idLog = 200; //visa
	}
	else
	if(strcasecmp(complemento, "elo") == 0) { //ELO DBT
		idLog = LOG_ELO;
	}
    /* HUB de Bandeiras - INICIO */
    else
    if(strcasecmp(complemento, "rdcmp") == 0) {
        idLog = 15;
    }
    /* HUB de Bandeiras - FIM */
	else{
		cout << "Complemento invalido! \n\n";
		usage();
		exit(0);
	}
	return idLog;
}

int LogReader::getIdLogWeb(char * complemento)
{
	int idLogi = 0;
	if(strcasecmp(complemento, "avr") == 0) { //AVR
		idLog = LOG_AVR; 
	}
	else
	if(strcasecmp(complemento, "ol") == 0) { //OL
		idLog = LOG_OL;
	}
	else
	if(strcasecmp(complemento, "ec") == 0) { //komerci
		idLog = LOG_EC;
	}
	else
	if(strcasecmp(complemento, "tpdu") == 0) { //komerci TPDU
		idLog = LOG_TPDU;
	}
	else
	if(strcasecmp(complemento, "mpg") == 0) { //MPG
		idLog = LOG_MPG;
	}
	else{
		cout << "Complemento invalido! \n\n";
		usage();
		exit(0);
	}
	return idLog;
}


int LogReader::getIdLogCrtm(char * complemento)
{
	int idLogi = 0;
	if(strcasecmp(complemento, "di") == 0) { //dinners
		idLog = 1; 
	}
	else
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - INICIO */
	if(strcasecmp(complemento, "jcb") == 0) { //JCB
		idLog = 1;
	}
	else
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - FIM */
	if(strcasecmp(complemento, "dv") == 0) { //on-us
		idLog = 1;
	}
	else
	if(strcasecmp(complemento, "mci") == 0) { //off-us
		idLog = 4;
	}
    /* ID_106001 - MASTER_ITAU CREDITO - R3_2015 - LOGTCP - INICIO */
	else if(strcasecmp(complemento, "mcit") == 0) {
		idLog = 4;  // MASTER HIPER - Mastercard off-us
	}
    /* ID_106001 - MASTER_ITAU CREDITO - R3_2015 - LOGTCP - FIM */
	else
	if(strcasecmp(complemento, "sicredi") == 0) {
		idLog = 15; //sicredi (Maestro)
	}
	else{
		cout << "Complemento invalido! \n\n";
		usage();
		exit(0);
	}
	return idLog;
}

/// GetIdentifierLogCrto
/// Obtem o Id do Log
/// EF/ET: ET1
/// Historico: [Data] - ET - Descricao
/// 31/01/2017 - Andre Morishita - ET1 - Criacao da versao inicial
/// complemento: complemento do log
int LogReader::GetIdentifierLogCrto(char * complemento)
{
    if(strcasecmp(complemento, "amex") == 0) { // Amex
        idLog = LOG_AMEX_FULL; 
    }
    else if(strcasecmp(complemento, "elo") == 0) { // Elo full 
        idLog = LOG_ELO_FULL;
    }
    else {
        cout << "Complemento invalido! \n\n";
        usage();
        exit(0);
    }
    
    return idLog;
}

int LogReader::getIdLogDbtm(char * complemento)
{
	int idLog;
	if(strcasecmp(complemento, "mae") == 0) {
		idLog = 3; //MDS (Maestro)
	}
	else
	if(strcasecmp(complemento, "hipdeb") == 0) {
		idLog = 3; //HIPER (Maestro)
	}
    /* ID_106001 - MASTER_ITAU DEBITO - R3_2015 - LOGTCP - INICIO */
	else if(strcasecmp(complemento, "mait") == 0) {
		idLog = 3; //MASTER ITAU (Maestro)
	}
    /* ID_106001 - MASTER_ITAU DEBITO - R3_2015 - LOGTCP - FIM */
    // 
    // J01_2020 - Novo Debito da Mastercard - INICIO
    else if(strcasecmp(complemento, "dmc") == 0) {
        idLog = 3; // Novo debito Mastercard (Maestro)
    }
    // J01_2020 - Novo Debito da Mastercard - FIM
	else
	if(strcasecmp(complemento, "sicredi") == 0) {
		idLog = 15; //sicredi (Maestro)
	}
	else{
		cout << "Complemento invalido! \n\n";
		usage();
		exit(0);
	}
	return idLog;
}

/// GetIdentifierLogDbto
/// Obtem o Id do Log
/// EF/ET: ET1
/// Historico: [Data] - ET - Descricao
/// 31/01/2017 - Andre Morishita - ET1 - Criacao da versao inicial
/// complemento: complemento do log
int LogReader::GetIdentifierLogDbto( char *complemento )
{
    int identificadorLog = 0;
    
    if (strcasecmp(complemento, "elo") == 0) {
        identificadorLog = LOG_ELO_FULL; // Elo Full
    }
    else {
        cout << "Complemento invalido! \n\n";
        usage();
        exit(0);
    }
    
    return identificadorLog;
}

// Nome: GetIdLogPos
// Descricao: Define o tipo do Log para o FE POS
// Parametros: par�metro complemento da chamada
// Retorno: ID do tipo do Log
int LogReader::GetIdLogPos(char * complemento)
{
	int idLog = 0;
	
	if(strcasecmp(complemento, "posmtg") == 0) { 
		idLog = LOG_ACQPOSMTG; 
	}
	else
	if(strcasecmp(complemento, "pdvdialmtg") == 0) {
		idLog = LOG_ACQPDVDIALMTG; 
	}
	else
	if(strcasecmp(complemento, "postg") == 0) {
		idLog = LOG_ACQPOSTG; 
	}
	else
	if(strcasecmp(complemento, "pdvdialtg") == 0) {
		idLog = LOG_ACQPDVDIALTG;
	}
	else
	if(strcasecmp(complemento, "posip") == 0) {
		idLog = LOG_ACQPOSIP;
	}
	else
	if(strcasecmp(complemento, "posipdec") == 0) {
		idLog = LOG_ACQPOSIP;
	}
	else
	if(strcasecmp(complemento, "posqh") == 0) {
		idLog = LOG_POSQH;
	}
	else
	if(strcasecmp(complemento, "poswq3") == 0) {
		idLog = LOG_ACQPOSTG;
	}
    // AUT2-4397 - Tap On Phone - INICIO
	else
	if(strcasecmp(complemento, "postop") == 0) {
		idLog = LOG_ACQPOSTOP;
	}
	else
	if(strcasecmp(complemento, "postopdec") == 0) {
		idLog = LOG_ACQPOSTOP;
	}
    // AUT2-4397 - Tap On Phone - FIM
	else{
		cout << "Complemento invalido! \n\n";
		usage();
		exit(0);
	}
	return idLog;
}


// Nome: GetIdLogPdv
// Descricao: Define o tipo do Log para o FE PDV
// Parametros: par�metro complemento da chamada
// Retorno: ID do tipo do Log
int LogReader::GetIdLogPdv(char * complemento)
{
	int idLog = 0;

	if(strcasecmp(complemento, "pdvip") == 0) { 
		idLog = LOG_ACQPDVIP;
	}
	else
	if(strcasecmp(complemento, "bigip") == 0) { 
		idLog = LOG_ACQPDVBIGIP;
	}
	else
	if(strcasecmp(complemento, "kms") == 0) { 
		idLog = LOG_ACQPDVKMS;
	}
	else
	if(strcasecmp(complemento, "protom") == 0) { 
		idLog = LOG_ACQPDVPROTOM;
	}
	/* BRUM - EAK-1623 - 24/07/2019 - Tratamento mensagem PDV intellinac - Inicio */
	else
	if(strcasecmp(complemento, "inac") == 0) { 
		idLog = LOG_ACQPDVINAC;
	}
	/* BRUM - EAK-1623 - Fim */
		/* EMS - EAK-2455 - 03/03/2020 - Tratamento mensagem PDV intellinac - Inicio */
	else
	if(strcasecmp(complemento, "inac1") == 0) { 
		idLog = LOG_ACQPDVINAC;
	}
	else
	if(strcasecmp(complemento, "inac2") == 0) { 
		idLog = LOG_ACQPDVINAC;
	}
	else
	if(strcasecmp(complemento, "inac3") == 0) { 
		idLog = LOG_ACQPDVINAC;
	}
	else
	if(strcasecmp(complemento, "inac4") == 0) { 
		idLog = LOG_ACQPDVINAC;
	}
	else
	if(strcasecmp(complemento, "inac5") == 0) { 
		idLog = LOG_ACQPDVINAC;
	}
	else
	if(strcasecmp(complemento, "pdvqh") == 0) {
		idLog = LOG_ACQPDVQH;
	}
	else
	if(strcasecmp(complemento, "pdvcorban") == 0) {
		idLog = LOG_ACQPDVCORBAN;
	}
	/* EMS - EAK-2455 - Fim */
	else{
		cout << "Complemento invalido! \n\n";
		usage();
		exit(0);
	}
	return idLog;
}

int LogReader::getIdLogCapture(char * adInfo)
{
	char **ptr;
	ptr = cap;
	int found;
	found = 0;
	int idx;
	for(idx = 0;*ptr != (char *) NULL && !found; idx++) {
		if(strcasecmp(adInfo, *ptr++) == 0) {
			found = 1;
		}
	}
	if(found) {
		idLog =  idx + 500;
	}
	else idLog = -1;		
	return idLog;
}

int LogReader::getLayoutDbt(char * complemento)
{
	int layout;
	if(strcasecmp(complemento, "mae") == 0) {
		layout = -1; //MDS (Maestro)
	}
	else
	if(strcasecmp(complemento, "sicredi") == 0) {
		layout = -1; //sicredi
	}
	else
		if(strcasecmp(complemento, "cabal") == 0) {
		layout = -1; //cabal
	}
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - INICIO */
	else if(strcasecmp(complemento, "banescard") == 0) {
		layout = -1; //BANESCARD
	}
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - FIM */
	else
	if(strcasecmp(complemento, "visa") == 0) {
		layout = 6; //Visa
	}
	else
	if(strcasecmp(complemento, "elo") == 0) {
		layout = 3; //Elo Verificar
	}
    /* HUB de Bandeiras - INICIO */
    else
    if(strcasecmp(complemento, "rdcmp") == 0) {
        layout = -1;
    }
    /* HUB de Bandeiras - FIM */
	else{
		cout << "Complemento invalido! \ngetLayoutDbt\n";
		usage();
		exit(0);
	}
	return layout;
}

int LogReader::getLayoutCrt(char * complemento)
{
	int layout;
	if(strcasecmp(complemento, "di") == 0) {
		layout = 3; //Diners Internacional
	}
	if(strcasecmp(complemento, "dv") == 0) {
		layout = 3; //On-us
	}
	if(strcasecmp(complemento, "mci") == 0) {
		layout = 5; //Off-us
	}
	if(strcasecmp(complemento, "sicredi") == 0) {
		layout = 5; 
	}
	if(strcasecmp(complemento, "sorocred") == 0) {
		layout = 5; 
	}
	if(strcasecmp(complemento, "cabal") == 0) {
		layout = 5; 
	}
	if(strcasecmp(complemento, "visa") == 0) {
		layout = 6; //Visa
	}
	if(strcasecmp(complemento, "cupcred") == 0) {
		layout = 2; //cup
	}
	if(strcasecmp(complemento, "coopvn") == 0) {
		layout = 3; //Hipercard
	}
	if(strcasecmp(complemento, "srcrvn") == 0) {
		layout = 3; //Hipercard
	}
	if(strcasecmp(complemento, "hc") == 0) {
		layout = 3; //Hipercard
	}
	if(strcasecmp(complemento, "calcard") == 0) {
		layout = 5; //Sicredi
	}
	if(strcasecmp(complemento, "avista") == 0) {
		layout = 3; //Hipercard
	}
	if(strcasecmp(complemento, "credsysvan") == 0) {
		layout = 3; //Hipercard
	}
	if(strcasecmp(complemento, "credsysfull") == 0) {
		layout = 5; //Sicred
	}
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - INICIO */
	if(strcasecmp(complemento, "banescard") == 0) {
		layout = 5; //Sicred
	}
	if(strcasecmp(complemento, "credz") == 0) {
		layout = 5; //Sicred
	}
    /* ID_146912 - CAPTURA DE BANDEIRAS - R1_2016 - LOG TCPIP - FIM */
	if(strcasecmp(complemento, "amex") == 0) {
		layout = 5; //Amex
	}
    /* HUB de Bandeiras - INICIO */
    if(strcasecmp(complemento, "rdcmp") == 0) {
        layout = 3;
    }
    /* HUB de Bandeiras - FIM */
	return layout;
}

int LogReader::getLayoutWeb(char * complemento)
{
	int layout;
	if(strcasecmp(complemento, "avr") == 0) {
		layout = 4; //AVR
	}
	else if(strcasecmp(complemento, "ol") == 0) {
		layout = 4; //OL
	}
	else if(strcasecmp(complemento, "ec") == 0) {
		layout = 5; //Komerci
	}
	else if(strcasecmp(complemento, "tpdu") == 0) {
		layout = 5; //Komerci TPDU
	}
	else if(strcasecmp(complemento, "mpg") == 0) {
		layout = 4; //MPG
	}
	return layout;
}

int LogReader::getLayoutDbtm(char * complemento)
{
	int layout;
	if(strcasecmp(complemento, "mae") == 0) {
		layout = -1; //MDS (Maestro)
	}
	else
	if(strcasecmp(complemento, "hipdeb") == 0) {
		layout = -1; //HIPER (Maestro)
	}
    /* ID_106001 - MASTER_ITAU DEBITO - R3_2015 - LOGTCP - INICIO */
	else if(strcasecmp(complemento, "mait") == 0) {
		layout = -1; //MASTER ITAU (Maestro)
	}
    /* ID_106001 - MASTER_ITAU DEBITO - R3_2015 - LOGTCP - FIM */
    // J01_2020 - Novo Debito da Mastercard - INICIO
    else if(strcasecmp(complemento, "dmc") == 0) {
        idLog = -1; // Novo debito Mastercard (Maestro)
    }
    // J01_2020 - Novo Debito da Mastercard - FIM
	else
	if(strcasecmp(complemento, "sicredi") == 0) {
		layout = -1; //sicredi (Maestro)
	}
	else{
		cout << "Complemento invalido! \n\n";
		usage();
		exit(0);
	}
	return layout;
}

int LogReader::getLayoutCrtm(char * complemento)
{
	int layout;
	if(strcasecmp(complemento, "di") == 0) {
		layout = 3; //Diners Internacional
	}
	if(strcasecmp(complemento, "dv") == 0) {
		layout = 3; //On-us
	}
	/* 0677_SW - Correcao LogReader JCB - ACDS - INICO */
	if(strcasecmp(complemento, "jcb") == 0) {
		layout = 3; //On-us
	}
	/* 0677_SW - Correcao LogReader JCB - ACDS - FIM */
	if(strcasecmp(complemento, "sicredi") == 0) {
		layout = 5; 
	}
	if(strcasecmp(complemento, "mci") == 0) {
		layout = 5; //Off-us
	}
    /* ID_106001 - MASTER_ITAU CREDITO - R3_2015 - LOGTCP - INICIO */
	if(strcasecmp(complemento, "mcit") == 0) {
		layout = 5; // MASTER ITAU - Mastercard Off-us
	}
    /* ID_106001 - MASTER_ITAU CREDITO - R3_2015 - LOGTCP - FIM */
	return layout;
}

/// GetLayoutDbto
/// Obtem o Id do layout do Log
/// EF/ET: ET1
/// Historico: [Data] - ET - Descricao
/// 31/01/2017 - Andre Morishita - ET1 - Criacao da versao inicial
/// complemento: complemento do log
int LogReader::GetLayoutDbto( char *complemento)
{
    int layout = 0;
    
    if(strcasecmp(complemento, "elo") == 0) {
        layout = 5; // Elo
    }
    else {
        layout = 0;
    }
    
    return layout;
}

/// GetLayoutCrto
/// Obtem o Id do layout do Log
/// EF/ET: ET1
/// Historico: [Data] - ET - Descricao
/// 31/01/2017 - Andre Morishita - ET1 - Criacao da versao inicial
/// complemento: complemento do log
int LogReader::GetLayoutCrto(char * complemento)
{
    int layout = 0;
    
    if(strcasecmp(complemento, "amex") == 0) {
        layout = 5; // Amex 
    }
    else if(strcasecmp(complemento, "elo") == 0) {
        layout = 5; // Elo
    }
    else {
        layout = 0;
    }
    
    return layout;
}


// Nome: GetLayoutPos
// Descricao: Define o layout do Log para o FE POS
// Parametros: par�metro complemento da chamada
// Retorno: ID do layout do Log
int LogReader::GetLayoutPos(char * complemento)
{
	int layout;

	if(strcasecmp(complemento, "posmtg") == 0) {
		layout = 2; 
	}
	else if(strcasecmp(complemento, "pdvdialmtg") == 0) {
		layout = 2; 
	}
	else if(strcasecmp(complemento, "postg") == 0) {
		layout = 2;
	}
	else if(strcasecmp(complemento, "pdvdialtg") == 0) {
		layout = 2;
	}
	else if(strcasecmp(complemento, "posip") == 0) {
		layout = 2;
	}	
	else if(strcasecmp(complemento, "posqh") == 0) {
		layout = 2;
	}
	else if(strcasecmp(complemento, "poswq3") == 0) {
		layout = 2;
	}	
	else if(strcasecmp(complemento, "posipdec") == 0) {
		layout = 2;
    }
    // AUT2-4397 - Tap On Phone - INICIO
    else if(strcasecmp(complemento, "postop") == 0) {
        layout = 2;
    }
    else if(strcasecmp(complemento, "postopdec") == 0) {
        layout = 2;
    // AUT2-4397 - Tap On Phone - FIM 
	} else {
		return -1;
	}

	return layout;
}

// Nome: GetLayoutPdv
// Descricao: Define o layout do Log para o FE POS
// Parametros: par�metro complemento da chamada
// Retorno: ID do layout do Log
int LogReader::GetLayoutPdv(char * complemento)
{
	int layout;

	if(strcasecmp(complemento, "pdvip") == 0) {
		layout = 0; 
	}
	else if(strcasecmp(complemento, "bigip") == 0) {
		layout = 0; 
	}
	else if(strcasecmp(complemento, "kms") == 0) {
		layout = 0;
	}
	else if(strcasecmp(complemento, "protom") == 0) {
		layout = 0;
	}
	/* BRUM - EAK-1623 - 24/07/2019 - Tratamento mensagem PDV intellinac - Inicio */
	else if(strcasecmp(complemento, "inac") == 0) {
		layout = 0;
	}
	/* BRUM - EAK-1623 - Fim */
	/* EMS - EAK-2455 - 03/03/2020 - Tratamento mensagem PDV intellinac - Inicio */
	else if(strcasecmp(complemento, "inac1") == 0) {
		layout = 0;
	}
	else if(strcasecmp(complemento, "inac2") == 0) {
		layout = 0;
	}
	else if(strcasecmp(complemento, "inac3") == 0) {
		layout = 0;
	}
	else if(strcasecmp(complemento, "inac4") == 0) {
		layout = 0;
	}
	else if(strcasecmp(complemento, "inac5") == 0) {
		layout = 0;
	}
	/* EMS - EAK-2455 - Fim */
	else if(strcasecmp(complemento, "pdvqh") == 0) {
		layout = 0;
	}
	else if(strcasecmp(complemento, "pdvcorban") == 0) {
		layout = 0;
	}
	
	return layout;
}


int LogReader::getIdLogHst(char * complemento) 
{
	int idLog = -1;
	char **ptr;
	ptr = hst;
	int found;
	found = 0;
	int idx;
	for(idx = 0;*ptr != (char *) NULL && !found; idx++) {
		if(strcasecmp(complemento, *ptr++) == 0) {
			found = 1; //smnt, fini, visi, fide, bbra, brad, fic, gncd, ptsg, credsyspl
		}
	}
	if(found) {
		idLog = 101; // PDV SEM HEADER - bitmap hexa de ebcdic
	}
	else 
		if(strcasecmp(complemento,"hstpv") == 0 || strcasecmp(complemento,"hstpp") == 0) {
			idLog = 102; // PDV COM HEADER TAMANHO 6
		}
		else if ((strcasecmp(complemento,"tktc") == 0) || (strcasecmp(complemento,"tkch") == 0)) {
			idLog = 104; //  TICKET
		}
		else if(strcasecmp(complemento,"gncd") == 0) {
			idLog = 1; //  GREENCARD
		}
		else if(strcasecmp(complemento,"nutr") == 0) {
			idLog = 104; //  NUTRICASH
		}
		else if(strcasecmp(complemento,"cabal") == 0) {
			idLog = 104; //  CABAL
		}
		else if(strcasecmp(complemento,"plvl") == 0) {
			idLog = 104; //  PLANVALE
		}
		else if(strcasecmp(complemento,"vrcq") == 0) {
			idLog = 104; //  VEROCHEQUE
		}
		else if(strcasecmp(complemento,"srcr") == 0) {
			idLog = 104; //  SOROCRED
		}
		else if(strcasecmp(complemento,"grsp") == 0) {
			idLog = 104; //  GRAN SAPORE
		}
		else if(strcasecmp(complemento,"vchr") == 0) {
			idLog = 104; //  Voucher
		}
		else if(strcasecmp(complemento,"sdxo") == 0) {
			idLog = 104; //  SODEXHO
		}
		else if(strcasecmp(complemento,"vale") == 0) {
			idLog = 104; //  VALECARD
		}
		else if(strcasecmp(complemento,"bnbc") == 0) {
			idLog = 104; //  BNB CLUB
		}
		else if(strcasecmp(complemento,"bnqt") == 0) {
			idLog = 104; //  Banquet
		}
		else if(strcasecmp(complemento,"smnt") == 0) {
			idLog = 104; //  VR
		}
		else if(strcasecmp(complemento,"itaupl") == 0) {
			idLog = LOG_ITAUPL; //  itaupl
                }
		else if(strcasecmp(complemento,"cef") == 0) {
      		idLog = 0; //construcard
                }
		else if(strcasecmp(complemento,"cefpv") == 0) {
      		idLog = LOG_CEFPV; //construcard PDV
                }
   	        else if(strcasecmp(complemento,"hostpb") == 0) {
			idLog = 0; //  serasa
                }
   	        else if(strcasecmp(complemento,"ravp") == 0) {
			idLog = 0; 
                }				
                else if(strcasecmp(complemento,"hostdef") == 0) {
                        idLog = 0; // Finalizacao e Fechamento Private Label
                }
		else if(strcasecmp(complemento,"ipcoop") == 0) {
			idLog = 104;
                }
		else if(strcasecmp(complemento,"vbbn") == 0) {
			idLog = 104;
                }
		else if(strcasecmp(complemento,"sodexo") == 0) {
			idLog = 104;
                }

        /* ID_146912 - CAPTURA BANDEIRAS - R1_2016 - LOG TCPIP - INICIO */
		else if(strcasecmp(complemento,"vr") == 0)
        {
			idLog = 104;
        }
        /* ID_146912 - CAPTURA BANDEIRAS - R1_2016 - LOG TCPIP - FIM */
        /* J5_2019 - VOUCHER SFORZA - INICIO */
		else if( strcasecmp(complemento, "sforza") == 0 )
        {
			idLog = LOG_TICKET;
        }
        /* J5_2019 - VOUCHER SFORZA - FIM */
        /* ID_145448 - ALELO - R1_2016 - LOG TCPIP - INICIO */
		else if(strcasecmp(complemento,"alelo") == 0)
        {
			idLog = LOG_ELO;
        }
        /* ID_145448 - ALELO - R1_2016 - LOG TCPIP - FIM */
        /* J3_2019 - ITI - INICIO */
        else if (strcasecmp(complemento,"iti") == 0)
        {
            idLog = LOG_TICKET;
        }
        /* J3_2019 - ITI - FIM */
		/* J2_2020 - QRCODE - INICIO */
		else if (strcasecmp(complemento,"wq3") == 0)
        {
            idLog = LOG_TICKET;
        }
		/* J2_2020 - QRCODE - FIM */
        /* HUB de Bandeiras - INICIO */
        else if (strcasecmp(complemento,"rdcmp") == 0)
        {
            idLog = 104;
        }
        /* HUB de Bandeiras - FIM */
        /* AM_J07_2021 - VOUCHER BEN - INICIO */
        else if (strcasecmp(complemento,"ben") == 0)
        {
            idLog = 200;
        }
        /* AM_J07_2021 - VOUCHER BEN - FIM */
        // AUT1-4011 - DCC - INICIO
        else if (strcasecmp(complemento,"plnt") == 0)
        {
            idLog = LOG_PLANET;
        }
        // AUT1-4011 - DCC - FIM

		else {
			idLog = 2; // PDV
		}
         //cout << "getIdLogHst--->:\t" << idLog << endl;
	return idLog;
}

int LogReader::getLayoutHst(int idLog)
{
	int layout;
    if(idLog == 0) {
        layout = 2; // POS sem TAG
    }
    else {
        layout = 0; // PDV
    }
    //cout << "getIdLayoutHst--->:\t" << layout << endl;
    return layout;
}


int LogReader::getIdSis(char * sist)
{
	char **ptr;
	int found;
	int idSis;
	ptr = opt;
	found = 0;
	idSis = 0;
	if (sist != NULL)
	{  
		while(*ptr != (char *) NULL && !found) {
			if(strcasecmp(sist, *ptr++) == 0 ) {
				found = 1;
			}
			idSis++;
		}
	}
	
	if(!found) idSis = -1;
    //cout << "getIdSis--->:\t" << idSis << endl;
	return --idSis;
}

int LogReader::isCapture()
{
	int cap = 0;
	if(501 <= this->idLog && this->idLog <= 516)cap = 1;
	return cap;
}

void LogReader::getLogName(char * logName)
{	
	if(flagStdin)  {
		strcpy(logName, "stdin");
	}
	else {
		getLogPath(logName);
		if(strlen(complemento) == 0) {
			strcat(logName, "logtcp.log");
		}
		else {
	  		strcat(logName,"logtcp");
  			strcat(logName, complemento);
		  	strcat(logName, ".log");
		}
		if(!fileExists(logName)){
			strcat(logName, ".debug");
		}
	}
}

bool LogReader::fileExists(const char *logName)
{
    ifstream infile(logName);
    return infile.good();
}

void LogReader::getLogPath(char * logPath)
{
	char* l_path = getenv( "SW_ROOT"  );
	if ( l_path != NULL ){
		sprintf(logPath, "%s/site/",l_path);
	}
	else {
		strcpy(logPath,"/home/SW/site/");
	}
	if(strcasecmp(sis,"AVR") == 0 ) {
		strcat(logPath, "EC");
	}
	else 
		strcat(logPath, sis);
	strcat(logPath,"/log/sys/tcp/");


}


int  main(int argc, char *argv[])
{
	char fileName[80];
	char tipo[10];
	char maskedFile[80];
	char buffer[4096];

	int idLog;
	int option, detail;
	char logName[256];


	LogReader* lgi = new LogReader(argc, argv);
	optind = argc - 1;
	detail = 0;
    while ((option = getopt(argc, argv, OPTSTRING)) != EOF) {
       switch (option) {
          case 'o':
          case 'O':
			detail = 1;
			break;
		  case 'l':
			case 'L':
			detail = 2;
			break;
		  default:
			detail= 0;
       }
     } /* end while */

	idLog = lgi->getIdLog();
	if(idLog == -1) {
		cout << "idLog invalido " << idLog << endl;
		exit(1);
	}

	lgi->getLogName(logName);
	int layout = lgi->getLayoutDe48();

	Mask_Factory factory;
	Mask_Interpreter* interpreter;
	interpreter = factory.CreateInstance(idLog, layout, detail);

	interpreter->setFlagDisplay( lgi->flagDisplay );
	if(lgi->flagStdin == 0) {
		ifstream fin(logName,ios::binary);
		if( !fin)
		{
			cout << "Nao abriu " << logName << " para leitura\n";
			lgi->usage();
		}	
		else {
		
			while(fin) {
				memset(buffer, 0, sizeof(buffer));
				fin.getline(buffer,  sizeof(buffer));
				if(fin) {
					if(lgi->isCapture())
						interpreter->initCaptureRecord(buffer);
					else	
						interpreter->initRecord(buffer);

					if ( lgi->flagDisplay == 0 )
						cout << interpreter->maskedLog << endl;
				}
			}
			fin.close();
		}
	}	


	else {
			while(cin) {
				memset(buffer, 0, sizeof(buffer));
				cin.getline(buffer,  sizeof(buffer));
				if(cin) {
					if(lgi->isCapture()) {
						interpreter->initCaptureRecord(buffer);
					}
					else	
						interpreter->initRecord(buffer);

					if ( lgi->flagDisplay == 0 ) {
						cout <<  interpreter->maskedLog << endl;
					}
				}
			}
	} 
}
