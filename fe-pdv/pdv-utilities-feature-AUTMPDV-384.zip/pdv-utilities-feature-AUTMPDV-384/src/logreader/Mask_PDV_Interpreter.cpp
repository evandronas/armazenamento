/* Copyright 2017 Rede S.A.
Autor : Ana Carolina Dias Silva
Empresa : Rede
*/
// Mask_PDV_Interpreter.cpp: implementation of the Mask_PDV_Interpreter class.
//
//////////////////////////////////////////////////////////////////////
/*
* Copyright 2015 Rede S.A.
* *********************** MODIFICA��ES ************************
* Autor    : Fabio Mazzer
* Data     : 13/06/2016
* Empresa  : Rede
* Descri��o: Merge com vers�o da AM 47.909 para inicializa��o da variavel pcode
* *************************************************************
* Autor    : Ana Carolina Dias Silva
* Data     : 16/02/2017
* Empresa  : Rede
* Descricao: 0633_SW - LogReader SW75 - Acerto abertura msg 0420 DE60 Private Label
* ID       : 181.389, AM186.489
* *************************************************************
Autor    : Andre Morishita
Data     : 05/02/2019
Empresa  : Leega
Descri��o: J3 - ITI
ID       : 200999
*************************************************************
Autor    : Andre Morishita
Data     : 08/09/2021
Empresa  : Leega
Descrio: AUT1-4011 - Inclusao do DCC
ID       : AUT1-4011
*************************************************************
*/


#include "Mask_PDV_Interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include "onvertEBCDICtoASCII.h"
#include "FilterHandler.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_PDV_Interpreter::Mask_PDV_Interpreter( int _max, int _headerSize, int _mapType ):Mask_Interpreter( _max, _headerSize, _mapType  )
{

}

Mask_PDV_Interpreter::~Mask_PDV_Interpreter()
{

}


void Mask_PDV_Interpreter::maskRecord( const char* _record )
{
	int i;
	int pos = 0;
	int size;
	int siz;
	int type;
	int code;
	int pos48;
	int len48;
	int flg48;
	int version;
	long pcode=0;
	char strVersion[10];
	static char de48[2048];
	
	char bufferAux[MAX_VALUE_LEN];
	char auxiliar[2048];
    char bufferConv[2048];
    char bufferConv2[2048];
	FilterHandler conv;
    char c_siz[4];
    char c_bit[4];


	bool isFix = TRUE;

	memset(this->retorno, 0, sizeof(this->retorno));

	flg48 = 0;	
	memset(de48,0,sizeof(de48));

	int recordSize;
	recordSize = strlen(_record);

	int sizeOK;
	sizeOK = OK;
// Show bits
 /*
    cout << "\nbits ";
    for( i = 0; i < this->usedBits; i++ )
    cout << " "  << this->bitsUsed[i];
    cout << "\n";
 */
   
	// flst = new FieldList();
	code = 2; // XEBCDIC
    for( i = 0; ((i < this->usedBits) && (sizeOK == OK)); i++ )
    {
		memset(bufferAux, 0, sizeof(bufferAux));
		memset(auxiliar, 0, sizeof(auxiliar));
		size = 0;
		type = 0;

        switch (this->bitsUsed[i])
        {
			//
			// Campos de tamanho fixo
			//

			// Campos de tamanho 04
            case 39:
            case 67:
            {
				siz = 2; 
                if ((pos + 4) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 4);
					auxiliar[4] = '\0';
					pos += 4;
					size=4;
					isFix=TRUE;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 06
            case 19:
	    case 22:
            case 23:
            case 49:
            case 51: // AUT1-4011 - DCC
            case 70:
            {
				siz = 3;
                if ((pos + 6) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 6);
					auxiliar[6] = '\0';
					pos += 6;
					isFix=TRUE;
					size=6;

                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 08
            case 13:
            case 14:
            case 15:
            case 18:
            case 71:
            {
				siz = 4;
                if ((pos + 8) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 8);
					auxiliar[8] = '\0';
					pos += 8;
					isFix=TRUE;
					size=8;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 12
            case 3:
            case 11:
            case 12:
            case 38:
            {
				siz = 6;
                if ((pos + 12) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 12);
					auxiliar[12] = '\0';
					pos += 12;
					isFix=TRUE;
					size=12;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 16
            case 41:
            case 10:
            {
				siz = 8;
                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
					auxiliar[16] = '\0';
					pos += 16;
					isFix=TRUE;
					size=16;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 20
            case 7:
            {
				siz = 10;
                if ((pos + 20) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 20);
					auxiliar[20] = '\0';
					pos += 20;
					isFix=TRUE;
					size=20;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 24
            case 4:
            case 37:
            case 6:
            {
				siz = 12;
                if ((pos + 24) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 24);
					auxiliar[24] = '\0';
					pos += 24;
					isFix=TRUE;
					size=24;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 30
            case 42:
            {
				siz = 15;
                if ((pos + 30) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 30);
					auxiliar[30] = '\0';
					pos += 30;
					isFix=TRUE;
					size=30;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 32
            case 52:
            {
				siz = 16;
                if ((pos + 32) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 32);
					auxiliar[32] = '\0';
					pos += 32;
					isFix=TRUE;
					size=32;

                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 84
            case 90:
            {
				siz = 42;
                if ((pos + 84) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 84);
					auxiliar[84] = '\0';
					pos += 84;
					isFix=TRUE;
					size=84;

                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 98
/*  Romovido dia 15/08 devido a solicitacao SW pois o DE 54 e llvar norma antiga
            case 54:

            {
				siz = 49;
                if ((pos + 98) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 98);
					auxiliar[98] = '\0';
					pos += 98;
					isFix=TRUE;
					size=98;
                }
                else
                    sizeOK = NOK;
				break;
            }
*/
			//
			// Campos de tamanho vari�vel
			//

			// Campos vari�veis LLvar
			case 32:
            case 33: /* J3_2019 - ITI */
			case 54:
            {
				type = 1;
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 4);
					pos += 4;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+4] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos vari�veis LLLvar
            // Inclusao set/2007 - projeto Nutricash Frota - DE 47 
            case 47:
            case 55:
			/* 0633_SW - LogReader SW75 - Acerto abertura msg 0420 DE60 Private Label - ACDS - Inicio */
			case 60:
			/* 0633_SW - LogReader SW75 - Acerto abertura msg 0420 DE60 Private Label - ACDS - Fim */
            case 61:
            case 62:
            case 63:
            case 104:
			case 124:
            case 125:
            case 127:
            {
				type = 2;
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';
					siz =  atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 6);
					pos += 6;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Campos de tamanho vari�vel com mascaramento
			//

			case 2:
            {
				type = 1;
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_2102(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

            case 35:
            {
				type = 1;
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_35(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

            case 45:
            {
				type = 1;
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_45(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

			// O DE48 s� pode ser mascarado de acordo com a vers�o indicada no DE123
			// Para tanto � guardada a posi��o e o conte�do do mesmo no registro at� a leitura do DE123
            case 48:
            {
				type = 2;
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					pos48 = pos;
					flg48 = 1;

					strncpy(de48, _record+pos, 6);
					strncat(auxiliar, _record+pos, 6);
					pos += 6;

					strncat(de48, _record+pos, size);
					de48[size+6] = '\0';
					len48 = size + 6;

					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

            case 123:
            {
				type = 2;
               if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					siz = atoi(bufferAux);
					size = siz*2;
					isFix=FALSE;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 6);
					pos += 6;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					// Aqui mascara-se o CVC2 no DE48 de acordo com a vers�o
					// indicada nos 4 primeiros d�gitos do DE123, se houver DE48
					if (flg48 != 0) 
					{
						strncpy(strVersion, &auxiliar[1], 4);					
						strVersion[4] = '\0';
						version = atoi(strVersion);
						memcpy(this->retorno + pos48, Mask_SelLayOut( pcode,version, de48), len48 );
					}
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
			//
			default:
			{
				sizeOK = NOK;
			}

        }


/*        cout << "IDLOG [" <<  this->idLog << "]" << endl;
*/


        if ( this->getFlagDisplay() != 0 ) {

            strncpy(bufferConv, "", 2048 );
            strncpy(bufferConv2, "", 2048 );

			if ( this->idLog == LOG_TICKET ) {

           		conv.xascii2ascii( (unsigned char*) auxiliar, bufferConv2, strlen(auxiliar)/2 );
			}
			else {
				
	            conv.xebcdic2xascii( (unsigned char*) auxiliar, bufferConv );
    	        conv.xascii2ascii( (unsigned char*) bufferConv, bufferConv2, strlen(bufferConv)/2 );
			}

            sprintf( c_siz, "%03d", siz );
            sprintf( c_bit, "%03d", this->bitsUsed[i] );
        }

        if ( this->getFlagDisplay() == 1 ) {

			if ( sizeOK == NOK ) {
                cout << "DE [" <<  c_bit << "] [ERRO]" << endl;

			}
			else
            if ( isFix == FALSE ) {

                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << bufferConv2 << "]" << endl;
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << bufferConv2 << "]" << endl;
            }

        }
        else
        if ( this->getFlagDisplay() == 2 ) {

			if ( sizeOK == NOK ) {
                cout << "DE [" <<  c_bit << "] [ERRO]" << endl;
			}
			else
            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << bufferConv2 << "]";
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << bufferConv2 << "]";
            }
        }


/* Comentado para compilar - ver com ZF porque isso est� aqui
		flst->addField(new Field(auxiliar, siz, this->bitsUsed[i],type, code));
*/

		if (sizeOK == OK)
			strncat(this->retorno, auxiliar, strlen(auxiliar));

	} // final do for
//	flst->traverse();

	// Se houve algum erro retorna o registro original
	if (sizeOK == NOK)
	{
		memset(this->retorno, 0, sizeof(this->retorno));
		strncat(this->retorno, _record, strlen(_record));
	}
}
