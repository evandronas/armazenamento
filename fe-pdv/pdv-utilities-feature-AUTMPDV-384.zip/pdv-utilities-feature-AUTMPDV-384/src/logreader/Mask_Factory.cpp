// Mask_Factory.cpp: implementation of the Mask_Factory class.
//
//////////////////////////////////////////////////////////////////////
/*
Copyright 2015 Rede S.A.
*********************** MODIFICA��ES ************************
Autor    : Fabio Mazzer e Diogo Fernandes
Data     : 15/02/2015
Empresa  : Rede
Descri��o: Multicaptura ELO
ID       : 91915 - SW Multicaptura ELO
*************************************************************
Autor    : Fernanda Carvalho
Data     : 20/03/2015
Empresa  : Rede
Descri��o: Multicaptura Amex
ID       : 92100 - SW Multicaptura Amex
*************************************************************
Autor    : M�rio Ad�o
Data     : 03/12/2015
Empresa  : Rede
Descri��o: Merge desenv PDV/POS SW 7.5 com produ��o
*************************************************************
Autor    : Andre Morishita
Data     : 30/01/2017
Empresa  : Leega
Descri��o: Inclusao dos logs da Amex Full e Elo Full
ID       : 184820
Autor    : Misunori Namioka
Data     : 03/03/2017
Empresa  : Fidelity
Descri��o: Merge da versao com o tratamento POS-IP.
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 15/10/2017
Empresa  : Rede
Descri��o: Upgrade Captura - ELOVAN / AMEX
ID       : AM 61.353
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 25/09/2018
Empresa  : Rede
Descri��o: Inclusao TPDU INAC
ID       : AM 228.120
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 26/06/2019
Empresa  : Rede
Descri��o: Adicionando tratamento para QH
ID       : EAK - 1593
**************************************************************
Autor    : Fernando Brum
Data     : 24/07/2019
Empresa  : Rede
Descri��o: Tratamento mensagens PDV INAC
ID       : EAK-1623
*************************************************************
Autor    : Andre Morishita
Data     : 24/08/2021
Empresa  : Leega
Descrio: Inclusao do Projeto DCC
ID       : AUT1-4011
*************************************************************
Autor    : Andre Morishita
Data     : 10/12/2021
Empresa  : Leega
Descri��o: AUT2-4397 - Tap On Phone
ID       : AUT2-4397
*************************************************************
*/

#include "Mask_Factory.h"
#include "LVS_Constants.h"
#include "Mask_Interpreter.h"
#include "Mask_DV_Interpreter.h"
#include "Mask_COOP_Interpreter.h"
#include "Mask_PDV_Interpreter.h"
#include "MaskPDVACQInterpreter.h"
#include "Mask_MDS_Interpreter.h"
#include "Mask_SIC_Interpreter.h"
#include "Mask_CUP_Interpreter.h"
#include "Mask_MCI_Interpreter.h"
#include "Mask_VISA_Interpreter.h"
#include "Mask_POS_Interpreter.h"
#include "Mask_CEFPV_Interpreter.h"
#include "Mask_ITAUPL_Interpreter.h"
#include "Mask_AVR_Interpreter.h"
#include "Mask_EC_Interpreter.h"
#include "Mask_MNAC_Interpreter.h"
#include "Mask_PDVDIAL_Interpreter.h"
#include "MaskEloInterpreter.h"
#include "MaskAmexInterpreter.h"
#include "MaskEloFullInterpreter.h"
#include "MaskPlanetInterpreter.h"
// Bibliotecas de Captura.
#include "Mask_CAPCRED_Interpreter.h"
#include "Mask_CAPDEB_Interpreter.h"
#include "Mask_CAPNFIN_Interpreter.h"
#include "Mask_CAPPRIV_Interpreter.h"
#include "Mask_CAPEND_Interpreter.h"
#include "Mask_CAPENDPDT_Interpreter.h"

#include "MaskCapEloVanInterpreter.h"
#include "MaskCapAmexInterpreter.h"


#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <fstream>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_Factory::Mask_Factory()
{

}

Mask_Factory::~Mask_Factory()
{

}


Mask_Interpreter* Mask_Factory::CreateInstance( int _id , int layout)
{
}

Mask_Interpreter* Mask_Factory::CreateInstance( int _id , int layout, int detail)
{
    Mask_Interpreter* interpreter;
    
    switch ( _id ) 
    {
        case LOG_POS:
        {
            interpreter = new Mask_POS_Interpreter( 27, 18 );
            break;
        }
        case LOG_ACQPOSIP:
        {
             // POS-IP does not contains header
            interpreter = new Mask_POS_Interpreter( 27, 0 );
            break;
        }
        // AUT2-4397 - Tap On Phone - INICIO
        case LOG_ACQPOSTOP:
        {
            // POS-TOP does not contains header
            interpreter = new Mask_POS_Interpreter( 27, 0 );
            break;
        }
        // AUT2-4397 - Tap On Phone - FIM
        case LOG_SMNT:
        {
            interpreter = new Mask_PDV_Interpreter( 27, 8, 1 );
            break;
        }
	
        case LOG_DV:

        {
            interpreter = new Mask_DV_Interpreter( 38, 12 );
            break;
        }

        case LOG_ITAUPL:
        {
            interpreter = new Mask_ITAUPL_Interpreter( 38, 12 );
            break;
        }


        case LOG_PDV:
        {
            interpreter = new Mask_PDV_Interpreter( 33, 48, 1 );
            break;
        }
		case LOG_ACQPDVIP: // PDV IP ACQ SW75
        {
            interpreter = new MaskPDVACQInterpreter( 33, 4, 1 );
            break;
        }
		
        case LOG_ACQPDVBIGIP: // PDV BIGIP ACQ SW75
        {
            interpreter = new MaskPDVACQInterpreter( 33, 36, 1 );
            break;
        }
		
		case LOG_ACQPDVPROTOM: // PDV PROTOM ACQ SW75
		case LOG_ACQPDVKMS: // PDV KMS ACQ SW75
        {
            interpreter = new MaskPDVACQInterpreter( 33, 44, 1 );
            break;
        }

        /* BRUM - EAK-1623 - 24/07/2019 - Tratamento mensagem PDV intellinac - Inicio */
        case LOG_ACQPDVINAC: // PDV INAC ACQ SW75
        {
            interpreter = new MaskPDVACQInterpreter( 33, 44, 1 );
            break;
        }
        /* BRUM - EAK-1623 - Fim */

        case LOG_ACQPDVQH:
        {
            interpreter = new MaskPDVACQInterpreter( 33, 4, 1 );
            break;
        }
		
        case LOG_ACQPDVCORBAN:
        {
            interpreter = new MaskPDVACQInterpreter( 33, 4, 1 );
            break;
        }
		
		case LOG_HSTPV:
        {
            interpreter = new Mask_PDV_Interpreter( 33, 14, 1 );
            break;
        }
		case LOG_CEFPV:
        {
            interpreter = new Mask_CEFPV_Interpreter( 33, 14, 1 );
            break;
        }

    	case LOG_SRSA:
        {
            interpreter = new Mask_PDV_Interpreter( 33, 8, 0 );
            break;
        }
        
        case LOG_TICKET:
        {
            interpreter = new Mask_PDV_Interpreter( 33, 8, 1 );
            break;
        }
		
		case LOG_ELO:
        {
			interpreter = new MaskEloInterpreter( 27, 14, 1 );
            break;
        }
        
        case LOG_ELO_FULL:
        {
            interpreter = new MaskEloFullInterpreter( 127, 14, 1 );
            break;
        }
 
		case LOG_MDS:
        {
            interpreter = new Mask_MDS_Interpreter( 75, 8 );
            break;
        }
		case LOG_SICREDI:
        {
            interpreter = new Mask_SIC_Interpreter( 75, 8 , 1);
            break;
        }
		case LOG_MPG:
        case LOG_MCI:
        {
            interpreter = new Mask_MCI_Interpreter( 57, 8 );
            break;
        }
        case LOG_AMEX:
        {
            interpreter = new MaskAmexInterpreter( 57, 8 );
            break;
        }
        
        case LOG_VISA:
        {
            interpreter = new Mask_VISA_Interpreter( 75, 48 );
            break;
        }
 
        case LOG_CUP:
        {
            interpreter = new Mask_CUP_Interpreter( 75, 48 , 1 );
            break;
        }
 
        case LOG_COOP:
        {
            interpreter = new Mask_COOP_Interpreter( 38, 12 );
            break;
        }

        case LOG_AVR:
        {
            interpreter = new Mask_AVR_Interpreter( 19, 4, 1 );
            break;
        }
		
        case LOG_OL:
        {
            interpreter = new Mask_AVR_Interpreter( 19, 8, 1 );
            break;
        }
		
        case LOG_EC:
        {
            interpreter = new Mask_EC_Interpreter( 19, 4, 1 );
            break;
        }
        
        case LOG_TPDU:
        {
            interpreter = new Mask_EC_Interpreter( 19, 14, 1 );
            break;
        }
		
		case LOG_ACQPOSMTG: // POSMTG ACQ SW75
		case LOG_ACQPOSTG: // POS TG ACQ SW75
		case LOG_POSQH: // POS QH SW75
        {
            interpreter = new Mask_MNAC_Interpreter( 27, 14 );
            break;
        }

		case LOG_ACQPDVDIALMTG: // POS PDVDIAL MTG ACQ SW75
		case LOG_ACQPDVDIALTG: // POS PDVDIAL TG ACQ SW75
        {
            interpreter = new Mask_PDVDIAL_Interpreter( 20, 14, 1 );
            break;
        }
        // AUT1-4011 - DCC - INICIO
        case LOG_PLANET:
        {
            interpreter = new MaskPlanetInterpreter( 127, 10, 1 );
            break;
        }
        // AUT1-4011 - DCC - FIM

//Captura
		
		case LOG_CAPCRED:
        {
            interpreter = new Mask_CAPCRED_Interpreter( 0, 0 );
            break;
        }
        case LOG_CAPDEB:
        {
            interpreter = new Mask_CAPDEB_Interpreter( 0, 0 );
            break;
        }
        case LOG_CAPNFIN:
        {
            interpreter = new Mask_CAPNFIN_Interpreter( 0, 0 );
            break;
        }

        case LOG_CAPPRIV:
        {
            interpreter = new Mask_CAPPRIV_Interpreter( 0, 0 );
            break;
        }
        case LOG_CAPEND:
        {
            interpreter = new Mask_CAPEND_Interpreter( 0, 0 );
            break;
        }
        case LOG_CAPENDPDT:
        {
            interpreter = new Mask_CAPENDPDT_Interpreter( 0, 0 );
            break;
		}	
        case LOG_CAPCREDMTVN:
        {
            interpreter = new Mask_CAPCRED_Interpreter( 0, 0 );
            break;
		}	
	
        case LOG_CAPCREDVISA:
        {
            interpreter = new Mask_CAPCRED_Interpreter( 0, 0 );
            break;
        }
        case LOG_CAPDEBVISA:
        {
            interpreter = new Mask_CAPDEB_Interpreter( 0, 0 );
            break;
        }
        case LOG_CAPENDPDTVISA:
        {
            interpreter = new Mask_CAPENDPDT_Interpreter( 0, 0 );
            break;
        }		
		case LOG_CAPCREDVISAD:
        {
            interpreter = new Mask_CAPCRED_Interpreter( 0, 0 );
            break;
        }		
		case LOG_CAPCREDD:
        {
            interpreter = new Mask_CAPCRED_Interpreter( 0, 0 );
            break;
        }
		case LOG_CAPDEBVISAD:
        {
            interpreter = new Mask_CAPDEB_Interpreter( 0, 0 );
            break;
        }
		case LOG_CAPDEBD:
        {
            interpreter = new Mask_CAPDEB_Interpreter( 0, 0 );
            break;
        }
		case LOG_CAPELOVAN:
        {
            interpreter = new MaskCapEloVanInterpreter( 0, 0 );
            break;
        }
		case LOG_CAPAMEX:
        {
            interpreter = new MaskCapAmexInterpreter( 0, 0 );
            break;
        }
        
	default :
        {
            interpreter=NULL;
            break;
        }
	}
   if ( interpreter == NULL )
   {
       interpreter = NULL;
   }
   else {
       interpreter->idLog = _id;
       interpreter->initInterpreter(layout, detail);
   }

   return ( interpreter );
}
    
