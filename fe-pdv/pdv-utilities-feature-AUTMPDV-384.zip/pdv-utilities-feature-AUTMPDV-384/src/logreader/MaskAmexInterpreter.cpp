/*
Copyright 2015 Rede S.A.
*************************************************************
Nome     : MaskAmexInterpreter.cpp
Descri��o: Classe responsavel pela interpreta�ao do Log Amex com mascaramento
Autor    : Fernanda Carvalho
Data     : 20/03/2015
Empresa  : Rede
Descri��o: Multicaptura Amex
ID       : 92100 - SW Multicaptura Amex
*************************************************************
*/
#include "MaskAmexInterpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include "Fields.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

// Construtor
MaskAmexInterpreter::MaskAmexInterpreter( int _max, int _headerSize ):Mask_Interpreter( _max, _headerSize )
{

}
// Destruidor
MaskAmexInterpreter::~MaskAmexInterpreter()
{

}

// Met�do principal para o parse da mensagem TCP
void MaskAmexInterpreter::maskRecord( const char* _record )
{
	//Declara��o de vari�veis de controle
	int i;
	int pos = 0;
	int size;
	int siz;
	//delcara��o e buffers
	char bufferAux[MAX_VALUE_LEN];
	char auxiliar[2048];
    char bufferConv[2048];
    char bufferConv2[2048];
    FilterHandler conv; 
	bool isFix=TRUE;
    char cSiz[4];
    char cBit[4];

	// vari�veis relativas ao DE
	int recordSize;
	recordSize = strlen(_record);

	int sizeOK;
	sizeOK = OK;



	memset(this->retorno, 0, sizeof(this->retorno));

	// Para cada DE presente no bitmap, faz o loop para parse
    for( i = 0; ((i < this->usedBits) && (sizeOK == OK)); i++ )
    {
    	memset(bufferAux, 0, sizeof(bufferAux));
		memset(auxiliar, 0, sizeof(auxiliar));
		size = 0;
		//Trata cada DE presente na mensagem (bitmap) de acordo com a mensageria do parceiro
		switch (this->bitsUsed[i])
        {
			//
			// Campos de tamanho fixo
			//

			// Campos de tamanho 02
            case 91:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 2) <= recordSize) 
                {
					strncpy(auxiliar, _record+pos, 2);
					auxiliar[2] = '\0';
					pos += 2;
					isFix = TRUE;
					siz = 2;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 06
            case 39:
            case 19:
            case 20:
            case 23:
            case 24:
            case 49:
            case 50:
            case 51:
            case 70:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
				if ((pos + 6) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 6);
					auxiliar[6] = '\0';
					pos += 6;
					isFix = TRUE;
					siz = 3;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 08
            case 26:
            case 13:
            case 14:
            case 15:
            case 16:
            case 18:
            case 25:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 8) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 8);
					auxiliar[8] = '\0';
					pos += 8;
					isFix = TRUE;
					siz = 4;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 12
            case 3:
            case 11:
            case 38:
            case 73:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 12) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 12);
					auxiliar[12] = '\0';
					pos += 12;
					isFix = TRUE;
					siz = 6;
                }
                else
                    sizeOK = NOK;
				break;
            }
            
            // Leitura com DE de tamanho 24*2 - INICIO
            case 30:
            {
                // Verifica se excede o tamanho do buffer de entrada
                // Adiciona o valor no buffer para sa�da
                if ((pos + 48) <= recordSize)
                {
                    strncpy(auxiliar, _record+pos, 48);
                    auxiliar[48] = '\0';
                    pos += 48;
                    isFix = TRUE;
                    siz = 24;
                }
                else 
                {
                    sizeOK = NOK;
                }
                break;
            }
            // Leitura com DE de tamanho 24*2 - FIM


			// Campos de tamanho 14
			case 94:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 14) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 14);
					auxiliar[14] = '\0';
					pos += 14;
					isFix = TRUE;
					siz = 7;
                }
                else
                    sizeOK = NOK;
				break;
            }
            
			// Campos de tamanho 16
            case 9:
            case 10:
            case 41:
            case 52:
            case 96:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
					auxiliar[16] = '\0';
					pos += 16;
					isFix = TRUE;
					siz = 8;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 20
            case 7:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 20) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 20);
					auxiliar[20] = '\0';
					pos += 20;
					isFix = TRUE;
					siz = 10;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 24
            case 22:
            case 12:
            case 4:
            case 5:
            case 6:
            case 37:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 24) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 24);
					auxiliar[24] = '\0';
					pos += 24;
					isFix = TRUE;	
					siz = 12;	
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 30
            case 42:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 30) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 30);
					auxiliar[30] = '\0';
					pos += 30;
					isFix = TRUE;
					siz = 15;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos de tamanho 84
			case 90:
            case 95:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 84) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 84);
					auxiliar[84] = '\0';
					pos += 84;
					isFix = TRUE;
					siz = 42;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Campos de tamanho vari�vel
			//

			// Campos vari�veis LLvar
            case 31:
            case 32:
            case 53:
            case 56:
            case 33:
            case 43:
            case 44:
            case 100:
			case 101:
            case 103:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';
					siz = atoi(bufferAux);
					size = siz*2;
					isFix = FALSE;
					
                }
                if ((pos + 4 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 4);
					pos += 4;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+4] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }


			// Campos vari�veis LLLvar
            // Inclusao DE 124 - Projeto Nutricash Frota - set/2007
			// Inclus�o DE 126 - nov/2007
            case 47:
            case 54:
            case 55:
            case 60:
            case 61:
            case 62:
            case 63:
			/* JPFC - Inicio - Inclusao DE 110 - Solicitacao de FMSC. */
            case 110:
			/* JPFC - Fim - Inclusao DE 110 - Solicitacao de FMSC. */			
            case 112:
            case 120:
            case 121:
            case 122:
            case 124:
			case 126:
            case 127:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					siz = atoi(bufferAux);
					size = siz * 2;
					isFix = FALSE;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 6);
					pos += 6;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Campos de tamanho vari�vel com mascaramento
			//

            case 2:
            case 102:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					siz = atoi(bufferAux);
					size = siz * 2;
					isFix = FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_2102(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

            case 35:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					isFix = FALSE;
					siz = atoi(bufferAux);
					size = siz * 2;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_35(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }


            case 45:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					siz = atoi(bufferAux);
					size = siz * 2;
					isFix = FALSE;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_45(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

            case 48:
            {
                // Verifica se excede o tamanho do buffer de entrada
				// Adiciona o valor no buffer para sa�da
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					isFix = FALSE;
					siz = atoi(bufferAux);
					size = siz * 2;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat( auxiliar, Mask_SelLayOut( 0,0, _record+ pos), size + 6 );
					auxiliar[size+6] = '\0';
					pos += 6;
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
			//
			default:
			{
				sizeOK = NOK;
			}

        }
		//Caso for para apresenta��o em tela e n�o for DE de senha
		if (( this->getFlagDisplay() != 0 ) && (this->bitsUsed[i] != 52) ) { 


	        strncpy(bufferConv, "", 2048 );
    	    strncpy(bufferConv2, "", 2048 );
        	conv.xebcdic2xascii( (unsigned char*) auxiliar, bufferConv );
        	conv.xascii2ascii( (unsigned char*) bufferConv, bufferConv2, strlen(bufferConv)/2 );

        	sprintf( cSiz, "%03d", siz );
        	sprintf( cBit, "%03d", this->bitsUsed[i] );
		}
		// Para tratamento em arquivo ou DE de senha
		else{
        	strncpy(bufferConv2, auxiliar, 16);
        	bufferConv2[16] = '\0';
        	sprintf( cSiz, "%03d", siz );
          sprintf( cBit, "%03d", this->bitsUsed[i] );
    }
        
	    // Tratamento para apresneta��o de tela um DE por linha	
		if ( this->getFlagDisplay() == 1 ) {

        	if ( isFix == FALSE ) {
            	cout << "DE [" <<  cBit << "] [V" << cSiz << "] [" << bufferConv2 << "]" << endl;
        	}
        	else {
            	cout << "DE [" <<  cBit << "] [F" << cSiz << "] [" << bufferConv2 << "]" << endl;
        	}

		}
	    // Tratamento para apresneta��o de tela da mensagem em uma linha
		else 
		if ( this->getFlagDisplay() == 2 ) {

            if ( isFix == FALSE ) {
                cout << "DE [" <<  cBit << "] [V" << cSiz << "] [" << bufferConv2 << "]";
            }
            else {
                cout << "DE [" <<  cBit << "] [F" << cSiz << "] [" << bufferConv2 << "]";
            }
		}


		// Adiciona o DE ao buffer principal
		if (sizeOK == OK)
			strncat(this->retorno, auxiliar, strlen(auxiliar));

	} // final do for

	// Se houve algum erro retorna o registro original
	if (sizeOK == NOK)
	{
		memset(this->retorno, 0, sizeof(this->retorno));
		strncat(this->retorno, _record, strlen(_record));
	}
}
