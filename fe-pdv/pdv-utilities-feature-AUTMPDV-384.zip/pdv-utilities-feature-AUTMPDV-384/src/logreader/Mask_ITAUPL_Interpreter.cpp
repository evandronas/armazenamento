// Mask_ITAUPL_Interpreter.cpp: implementation of the Mask_ITAUPL_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#include "Mask_ITAUPL_Interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include "Fields.h"

#ifdef FALSE
#undef FALSE
#endif
#define FALSE 0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE  1

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mask_ITAUPL_Interpreter::Mask_ITAUPL_Interpreter( int _max, int _headerSize ):Mask_Interpreter( _max, _headerSize )
{

}

Mask_ITAUPL_Interpreter::~Mask_ITAUPL_Interpreter()
{

}

/////////////////////////////////////////
/**
*
*   Masks the CONFIDENTIAL fields in the record.
*
*   @param char* _record The record to be masked
*   @param char* _masked The masked record to be returned.
*
*
*////////////////////////////////////////
void Mask_ITAUPL_Interpreter::maskRecord( const char* _record )
{
	int i;
	int pos = 0;
	int size;
	char bufferAux[MAX_VALUE_LEN];
	char auxiliar[2048];
    char bufferConv[2048];
    char bufferConv2[2048];
    FilterHandler conv;
	bool isFix = TRUE;
	int siz;
    char c_siz[4];
    char c_bit[4];



	int recordSize;
	recordSize = strlen(_record);

	int sizeOK;
	sizeOK = OK;

	memset(this->retorno, 0, sizeof(this->retorno));

    for ( i = 0; ((i < this->usedBits) && (sizeOK == OK)); i++ )
	{
		memset(bufferAux, 0, sizeof(bufferAux));
		memset(auxiliar, 0, sizeof(auxiliar));
		size = 0;

		switch ( this->bitsUsed[i] )
		{
			//
			// Campos de tamanho fixo
			//

			// Campos de tamanho 04
			case 39:
			case 67:
			{
                if ((pos + 4) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 4);
					auxiliar[4] = '\0';
					pos += 4;
					isFix = TRUE;
					siz = 2;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 06
			case 22:
			case 23:
			case 49:
			case 70:
			{
                if ((pos + 6) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 6);
					auxiliar[6] = '\0';
					pos += 6;
					isFix = TRUE;
					siz = 3;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 08
			case 13:
			case 14:
			case 15:
			case 18:
			{
                if ((pos + 8) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 8);
					auxiliar[8] = '\0';
					pos += 8;
					isFix = TRUE;
					siz = 4;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 12
			case 3:
			case 11:
			case 12:
			case 38:
			{
                if ((pos + 12) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 12);
					auxiliar[12] = '\0';
					pos += 12;
					isFix = TRUE;
					siz = 6;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 16
			case 41:
			case 52:
			{
                if ((pos + 16) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 16);
					auxiliar[16] = '\0';
					pos += 16;
					isFix = TRUE;
					siz = 8;
                }
                else
                    sizeOK = NOK;
				break;
			}


			// Campos de tamanho 20
			case 7:
			{
                if ((pos + 20) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 20);
					auxiliar[20] = '\0';
					pos += 20;
					isFix = TRUE;
					siz = 10;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 24
			case 4:
			case 37:
			{
                if ((pos + 24) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 24);
					auxiliar[24] = '\0';
					pos += 24;
					isFix = TRUE;
					siz = 12;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 30
			case 42:
			{
                if ((pos + 30) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 30);
					auxiliar[30] = '\0';
					pos += 30;
					isFix = TRUE;
					siz = 15;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 80
			case 43:
			{
                if ((pos + 80) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 80);
					auxiliar[80] = '\0';
					pos += 80;
					isFix = TRUE;
					siz = 40;
                }
                else
                    sizeOK = NOK;
				break;
			}

			// Campos de tamanho 84
			case 90:
			{
                if ((pos + 84) <= recordSize)
                {
					strncpy(auxiliar, _record+pos, 84);
					auxiliar[84] = '\0';
					pos += 84;
					isFix = TRUE;
					siz = 42;
                }
                else
                    sizeOK = NOK;
				break;
			}

			//
			// Campos de tamanho vari�vel
			//

			// Campos vari�veis LLvar
			case 32:
			case 33:
			case 103:
            {
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					isFix = FALSE;
					siz = atoi(bufferAux);
					size = siz * 2;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 4);
					pos += 4;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+4] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			// Campos vari�veis LLLvar
			case 47:
			case 55:
			case 60:
			case 61:
			case 62:
			case 63:
			case 104:
      case 112:
      case 124:
			case 125:
			case 127:
            {
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					isFix = FALSE;	
					siz = atoi(bufferAux);
					size = siz * 2;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat(auxiliar, _record+pos, 6);
					pos += 6;
					strncat(auxiliar, _record+pos, size);
					auxiliar[size+6] = '\0';
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Campos de tamanho vari�vel com mascaramento
			//

			case 2:
			{
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					isFix = FALSE;
					siz = atoi(bufferAux);
					size = siz * 2;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_2102(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
			}

			case 35:
            {
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					isFix = FALSE;
					siz = atoi(bufferAux);
					size = siz * 2;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_35(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

			case 45:
            {
                if ((pos + 4) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = '\0';

					isFix = FALSE;
					siz = atoi(bufferAux);
					size = siz * 2;
                }
                if ((pos + 4 + size) <= recordSize)
                {
					pos += maskFields_45(_record+pos, auxiliar);
                }
                else
                    sizeOK = NOK;
				break;
            }

			case 48:
            {
                if ((pos + 6) <= recordSize)
                {
					bufferAux[0] = _record[pos+1];
					bufferAux[1] = _record[pos+3];
					bufferAux[2] = _record[pos+5];
					bufferAux[3] = '\0';

					isFix = FALSE;
					siz = atoi(bufferAux);
					size = siz * 2;
                }
                if ((pos + 6 + size) <= recordSize)
                {
					strncat( auxiliar, Mask_SelLayOut( 0,0, _record+ pos), size + 6 );
					auxiliar[size+6] = '\0';
					pos += 6;
					pos += size;
                }
                else
                    sizeOK = NOK;
				break;
            }

			//
			// Se n�o sabe tratar um campo, devolve o registro original sem mascaramento
			//
			default:
			{
				sizeOK = NOK;
			}

        }



        if ( this->getFlagDisplay() != 0 ) {

            strncpy(bufferConv, "", 2048 );
            strncpy(bufferConv2, "", 2048 );
            conv.xebcdic2xascii( (unsigned char*) auxiliar, bufferConv );
            conv.xascii2ascii( (unsigned char*) bufferConv, bufferConv2, strlen(bufferConv)/2 );

              //  cout << "DE -062-" << bufferConv2 << "]" << endl;

            //conv.xascii2ascii( (unsigned char*) bufferConv2, auxiliar, strlen(bufferConv2)/2 );

                //cout << "DE -062-" << auxiliar << "]" << endl;


            sprintf( c_siz, "%03d", siz );
            sprintf( c_bit, "%03d", this->bitsUsed[i] );
        }

        if ( this->getFlagDisplay() == 1 ) {

            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << bufferConv2 << "]" << endl;
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << bufferConv2 << "]" << endl;
            }

        }
        else
        if ( this->getFlagDisplay() == 2 ) {

            if ( isFix == FALSE ) {
                cout << "DE [" <<  c_bit << "] [V" << c_siz << "] [" << bufferConv2 << "]";
            }
            else {
                cout << "DE [" <<  c_bit << "] [F" << c_siz << "] [" << bufferConv2 << "]";
            }
        }


//        cout << "DE[" <<  this->bitsUsed[i] << "] " << auxiliar << endl;
//        cout << "DE [" <<  this->bitsUsed[i] << "] [" << bufferConv2 << "] " << endl;
//        cout << "sizeOK " << sizeOK << endl;

//		flst->addField(new Field(auxiliar, siz, this->bitsUsed[i],type, code));

		if (sizeOK == OK)
			strncat(this->retorno, auxiliar, strlen(auxiliar));

	} // final do for

	// Se houve algum erro retorna o registro original
	if (sizeOK == NOK)
	{
		memset(this->retorno, 0, sizeof(this->retorno));
		strncat(this->retorno, _record, strlen(_record));
	}
}
