// Mask_POS_Interpreter.h: interface for the Mask_POS_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_POS_INTERPRETER_H__67C1157B_1381_409B_8776_400BA0984D94__INCLUDED_)
#define AFX_MASK_POS_INTERPRETER_H__67C1157B_1381_409B_8776_400BA0984D94__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_POS_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log POS com mascaramento
*
*	Data de cria��o: 17/09/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
**////////////////////////////////////////
class Mask_POS_Interpreter : public Mask_Interpreter 
{
	public:
		Mask_POS_Interpreter(int, int);
		~Mask_POS_Interpreter();
		
		void maskRecord( const char* );
        
        // 239526 - J1_2019 - Comprovante Transacoes negadas - INICIO
        void OpenDataElementTags( char *buffer, int tipoDisplay, int lengthData, int DE );
        // 239526 - J1_2019 - Comprovante Transacoes negadas - FIM
};

#endif // !defined(AFX_MASK_POS_INTERPRETER_H__67C1157B_1381_409B_8776_400BA0984D94__INCLUDED_)
