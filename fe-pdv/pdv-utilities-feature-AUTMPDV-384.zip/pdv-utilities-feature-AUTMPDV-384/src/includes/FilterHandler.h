// FilterHandler.h: interface for the FilterHandler class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTERHANDLER_H__EA89BB64_1837_4104_9D60_A05870154B36__INCLUDED_)
#define AFX_FILTERHANDLER_H__EA89BB64_1837_4104_9D60_A05870154B36__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////
/**
*
*	Nome: FilterHandler.h
*
*   Descri��o: Classe responsavel pela conversao 
*	entre os formatos ASCII, EBCDIC, ASCII(hexa) e EBCDIC(hexa)
*
*	Data de cria��o: 01/09/2003
*
*
**////////////////////////////////////////
class FilterHandler  
{
	private:
	
		static unsigned char ebcdic_ascii_table[ 256 ];
		static unsigned char ascii_ebcdic_table[ 256 ];
		static unsigned char xebcdic_xascii_table[ 256 ];
		static unsigned char xascii_xebcdic_table [ 256 ];


	public:

		void ebcdic2Ascii(unsigned char*, long );

		void ascii2Ebcdic(unsigned char*, long );

		void xebcdic2xascii(unsigned char*, char* );
		
		void xascii2xebcdic(unsigned char*, char* );

		void ascii2xascii(unsigned char*, char* );

		void xascii2ascii(unsigned char*, char*, int );
		
		void ascii2ascii(unsigned char*, char*, int );		

		void xebcdic2ebcdic(unsigned char*, char* );
		
		FilterHandler();
		~FilterHandler();

};

















#endif // !defined(AFX_FILTERHANDLER_H__EA89BB64_1837_4104_9D60_A05870154B36__INCLUDED_)
