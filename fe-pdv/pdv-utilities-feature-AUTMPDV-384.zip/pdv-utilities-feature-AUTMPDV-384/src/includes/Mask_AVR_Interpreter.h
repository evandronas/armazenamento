// Mask_AVR_Interpreter.h: interface for the Mask_AVR_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_AVR_INTERPRETER_H__5358D311_0362_410E_9C07_FCD1F95F4C29__INCLUDED_)
#define AFX_MASK_AVR_INTERPRETER_H__5358D311_0362_410E_9C07_FCD1F95F4C29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_AVR_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log AVR com mascaramento
*
*	Data de cria��o: 18/09/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
**////////////////////////////////////////
class Mask_AVR_Interpreter : public Mask_Interpreter  
{
	public:
		Mask_AVR_Interpreter( int, int, int );
		~Mask_AVR_Interpreter();

		void maskRecord( const char* );

        // ID_226514 - NOVOS PRODUTOS ELO - DE48 FORMATO TLV - LOGREADER
        void PrintDE48Data(char *input, int length, char *output);

};

#endif // !defined(AFX_MASK_AVR_INTERPRETER_H__5358D311_0362_410E_9C07_FCD1F95F4C29__INCLUDED_)
