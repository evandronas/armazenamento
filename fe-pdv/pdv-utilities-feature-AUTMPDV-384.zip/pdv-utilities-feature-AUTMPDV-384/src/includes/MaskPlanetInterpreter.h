/* Copyright 2021 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#ifndef _MASKPLANETINTERPRETER_H_
#define _MASKPLANETINTERPRETER_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/// MaskPlanetInterpreter
/// Classe responsavel pelo parse e mascaramento das transacoes ELO
/// EF/ET: EF1
/// 25/08/2021 - Diego Lima - EF1 - Criao
class MaskPlanetInterpreter : public Mask_Interpreter 
{
	public:
		//Construtor e Destruidor
		MaskPlanetInterpreter(int, int, int);
		~MaskPlanetInterpreter();
		//Mtodo classe base para o parse e mascaramento
		void maskRecord( const char* );

};

#endif // _MASKPLANETINTERPRETER_H_
