/*
Copyright 2015 Rede S.A.
*************************************************************
Nome     : MaskAmexInterpreter.h
Descri��o: Classe responsavel pela interpreta�ao do Log Amex com mascaramento
Autor    : Fernanda Carvalho
Data     : 20/03/2015
Empresa  : Rede
Descri��o: Multicaptura Amex
ID       : 92100 - SW Multicaptura Amex
*************************************************************
*********************** MODIFICA��ES ************************
Autor    : Diego Lima
Data     : 17/06/2016
Empresa  : Rede
Descri��o: Corre�ao de coment�rio
*********************** MODIFICA��ES ************************
*/

#ifndef _MASKAMEXINTERPRETER_H_
#define _MASKAMEXINTERPRETER_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"
/// MaskAmexInterpreter
/// Classe responsavel pelo parse e mascaramento das transacoes Amex
/// EF/ET: EF1
/// 17/06/2016 - Diego Lima - EF1 - Cria��o
class MaskAmexInterpreter : public Mask_Interpreter 
{
	public:
		//Construtor e Destruidor
		MaskAmexInterpreter(int, int);
		~MaskAmexInterpreter();
		//M�todo classe base para o parse e mascaramento
		void maskRecord( const char* );

};

#endif // _MASKAMEXINTERPRETER_H_
