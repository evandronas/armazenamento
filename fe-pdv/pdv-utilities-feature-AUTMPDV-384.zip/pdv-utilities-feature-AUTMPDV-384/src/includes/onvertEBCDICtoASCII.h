// onvertEBCDICtoASCII.h: interface for the ConvertEBCDICtoASCII class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ONVERTEBCDICTOASCII_H__43A7FFB2_1116_4F1E_BE8A_67BDF374B7D2__INCLUDED_)
#define AFX_ONVERTEBCDICTOASCII_H__43A7FFB2_1116_4F1E_BE8A_67BDF374B7D2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////
/**
*
*    Nome: onvertEBCDICtoASCII.h
*
*    Descricao: Classe que realiza a conversao entre os tipos EBCDIC e ASCII.
*
*    Data de cria?o: 29/08/2003
*
*    @author Thais Ruis Furlan ( thais@solvo.com.br )
*
**////////////////////////////////////////
class onvertEBCDICtoASCII
{

    private:    
    
    
    public:
    
        onvertEBCDICtoASCII();
        ~onvertEBCDICtoASCII();

        
        void ASCII_to_EBCDIC(unsigned char *buf_addr, long buf_lenght);
	    /** Tabela EBCDIC para convers? */
	    static unsigned char ASCII_translate_EBCDIC [ 256 ];
        
	    void EBCDIC_to_ASCII (unsigned char *buf_addr, long buf_length);
	    /** Tabela ASCII para convers? */
	    static unsigned char EBCDIC_translate_ASCII [ 256 ];


        static unsigned char Decimal_to_xEBCDIC [ 256 ];

};


#endif // !defined(AFX_ONVERTEBCDICTOASCII_H__43A7FFB2_1116_4F1E_BE8A_67BDF374B7D2__INCLUDED_)
