// Mask_Factory.h: interface for the Mask_Factory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_FACTORY_H__9F876A95_2D3B_4449_8978_16EF8379427F__INCLUDED_)
#define AFX_MASK_FACTORY_H__9F876A95_2D3B_4449_8978_16EF8379427F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_Factory.h
*
*   Descri��o: Classe Fabrica das Instancias de Mascaramento 
*
*	Data de cria��o: 06/10/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
*
**////////////////////////////////////////
class Mask_Factory  
{
	public:
		Mask_Factory();
		~Mask_Factory();
        
		virtual Mask_Interpreter* CreateInstance ( int, int, int );
	    virtual Mask_Interpreter* CreateInstance ( int, int );

};

#endif // !defined(AFX_MASK_FACTORY_H__9F876A95_2D3B_4449_8978_16EF8379427F__INCLUDED_)
