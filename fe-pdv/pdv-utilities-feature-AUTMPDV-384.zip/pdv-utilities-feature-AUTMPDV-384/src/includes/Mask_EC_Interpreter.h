// Mask_EC_Interpreter.h: interface for the Mask_EC_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_EC_INTERPRETER_H__5358D311_0362_410E_9C07_FCD1F95F4C29__INCLUDED_)
#define AFX_MASK_EC_INTERPRETER_H__5358D311_0362_410E_9C07_FCD1F95F4C29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_EC_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log EC com mascaramento
*
*	Data de cria��o: 04/12/2012
*
*   @author Francine Bellucco (francine.bellucco@redecard.com.br)
*
**////////////////////////////////////////
class Mask_EC_Interpreter : public Mask_Interpreter  
{
	public:
		Mask_EC_Interpreter( int, int, int );
		~Mask_EC_Interpreter();

		void maskRecord( const char* );
};

#endif // !defined(AFX_MASK_EC_INTERPRETER_H__5358D311_0362_410E_9C07_FCD1F95F4C29__INCLUDED_)
