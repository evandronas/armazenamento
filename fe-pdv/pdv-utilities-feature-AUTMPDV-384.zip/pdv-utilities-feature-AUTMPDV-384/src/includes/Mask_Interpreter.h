// Mask_Interpreter.h: interface for the Mask_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_INTERPRETER_H__FEF630C5_C4F1_40CD_A165_29AAA13FCBE5__INCLUDED_)
#define AFX_MASK_INTERPRETER_H__FEF630C5_C4F1_40CD_A165_29AAA13FCBE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "LVS_Constants.h"


/////////////////////////////////////////
/**
*
*	Nome: Mask_Interpreter.h
*
*   Descrio: Classe responsavel pelo gerenciamento
*   e interpretacao do mapa de bits enviado
*
*	Data de criao: 28/08/2003
*
*	@author Wagner B. Rosado ( wagner@solvo.com.br )
*   @author Mario Y. Maruta ( mario@solvo.com.br )
*
**////////////////////////////////////////
class Mask_Interpreter
{
	public:

		Mask_Interpreter(int, int, int = 0);
		~Mask_Interpreter();

        int initInterpreter(int, int);
		int initInterpreter(int );
        int initRecord( char * );
        int initCaptureRecord( char * );
		int compare(char*, int, const char * );
		int getUsedBits( );
		int* getBitsInUse( );
	    char ** getValues( );
		void resetRecord();
		void transEpack( char * );
		void showBits();
		int maskFields(char *, char *, int, int );

		char maskedLog[2048];
		char msgHeader[MAX_BUFFER_SIZE];
		char msgType[MAX_BUFFER_SIZE];
		int idLog;
		int detail;

		int setFlagDisplay(int _flag);
		int getFlagDisplay();

	protected:

		char bitmap[BITMAP_SIZE];
        char bufferConv[MAX_BUFFER_SIZE];
		char retorno[4096];
        char ** values;

        int bitsUsed[BITMAP_SIZE];
        int maxBits;
        int usedBits;
        int mapType;
        int initialized;
        int headerSize;

        void resetBitmap( );
        void fillBitmap( char * );
        void fillBitsUsed( );
        void hexa2Integer( char* );

	virtual void maskRecord (const char *) = 0;
	int findDelimiter(const char *);
	int checkNonZero(const char * , int , int );
	int findSeparator(const char * , int , int , char);
	int maskFields_2102(const char *, char *);
	int maskFields_35(const char *, char *);
	int maskFields_45(const char *, char *);
	int getMessageType( char * );
	char *Mask_SelLayOut(long, int, const char *);
	char *Mask_CVC2_PDV(int, long , int, const char *);
	char *Mask_CVC2TagsPOS(int, const char *);
	int convHexInt(char *);
	char *Mask_CVC2POS(int, const char *);
	char *Mask_CVC2CRE(int, const char *);
	char *Mask_CVC2AVR(int, const char *);
	char *Mask_CVC2MCI(int, const char *);



	private:
		int layoutDE48;

		void panExtract(char *pan,char *track2);
		int getBufferPos(int _bit);
		void substitute (char *, int );
		void removeStar(char * , char * );

		int flagDisplay;
		int validMsgType(int mtype);


};

#endif // !defined(AFX_MASK_INTERPRETER_H__FEF630C5_C4F1_40CD_A165_29AAA13FCBE5__INCLUDED_)
