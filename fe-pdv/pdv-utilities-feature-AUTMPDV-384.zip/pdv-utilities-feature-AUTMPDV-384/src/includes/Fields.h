#include <iostream>
#include "FilterHandler.h"

using namespace std;

class Field {
	public:
	Field( char * val, int len, int bitno, int lenType, int conv = 0 ) { 
		fieldLen = len;
		this->bitno = bitno;
		this->lenType = lenType;
		strcpy(value, val);
	}
	char * getVal()  { return value; }
	int getLen() { return fieldLen; }
	int getLenType() { return lenType; }

	int getBitno() { return bitno; }
	private:
	char  value[2048];
	int fieldLen;
	int lenType; // 0 - Fixed  1 - LLVAR 2 -LLLVAR
	int convType; // 0 - No 1- XASCII 2 - XEBCDIC
	int bitno;
};

class FieldList {
	public:
		FieldList() 
		{
   			for (int i=0; i < 128; i++)
      			arr_[i] = (Field* ) NULL;
   			num_ = 0;
		}

		void addField( Field* n ) { arr_[num_++] = n; }
		void convert(FilterHandler * filter, char * src) {
			memset(bufConv, 0, sizeof(bufConv));
			filter->xebcdic2ebcdic((unsigned char *) src, bufConv);
		}	
		void traverse() { 

			FilterHandler * filter = new FilterHandler();
			for (int i=0; i < num_; i++) {
       			cout << "<" ;
				cout.width(3);
				cout << arr_[i]->getBitno() ;
				cout << "> ["  ;
				switch(arr_[i]->getLenType()) {
					case 0:
						cout << "   F";
						break;
					case 1:
						cout << " LLV";
						break;
					case 2:
						cout << "LLLV";
						break;
				}
				cout.width(3);
				cout << arr_[i]->getLen();
				convert(filter, arr_[i]->getVal());
				cout << "] [" << bufConv << "]"

       			<< endl;
			}	
   				cout << endl;
		}
    private:
		Field*  arr_[128];
		char bufConv[1024];
         int    num_;
};


