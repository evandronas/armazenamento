/*
� Copyright 2015 Rede S.A.
*********************** MODIFICA��ES ************************
Autor    : Diogo Fernandes
Data     : 15/02/2015
Empresa  : Rede
Descri��o: Multicaptura ELO
ID       : 91915 - SW Multicaptura ELO
*************************************************************
Autor    : Mario Adao
Data     : 21/03/2015
Empresa  : Rede
Descri��o: Multicaptura Amex
		 : Inclusao da constant LOG_AMEX
ID       : 92100 - SW Multicaptura Amex
*************************************************************
Autor    : Mario Adao
Data     : 03/12/2015
Empresa  : Rede
Descri��o: SW 7.5 - PDV/POS - merge desenv com produ��o
ID       : 
*************************************************************
Autor    : Andre Morishita
Data     : 30/01/2017
Empresa  : Leega
Descri��o: Inclusao dos logs da Amex Full e Elo Full
ID       : 184820
Autor    : Misunori Namioka
Data     : 03/03/2017
Empresa  : Fidelity
Descri��o: Merge da versao com tratamento do POS-IP. 
ID       : 
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 15/10/2017
Empresa  : Rede
Descri��o: Upgrade Captura - ELOVAN / AMEX
ID       : AM 61.353
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 25/09/2018
Empresa  : Rede
Descri��o: Inclusao TPDU INAC
ID       : AM 228.120
*************************************************************
Autor    : Gustavo Silva Franco
Data     : 26/06/2019
Empresa  : Rede
Descri��o: Adicionando tratamento para QH
ID       : EAK - 1593
**************************************************************
Autor    : Fernando Brum
Data     : 24/07/2019
Empresa  : Rede
Descri��o: Tratamento mensagens PDV INAC
ID       : EAK-1623
*************************************************************
Autor    : Andre Morishita
Data     : 24/08/2021
Empresa  : Leega
Descri??o: Inclusao do Projeto DCC
ID       : AUT1-4011
*************************************************************
Autor    : Andre Morishita
Data     : 10/12/2021
Empresa  : Leega
Descri��o: AUT2-4397 - Tap On Phone
ID       : AUT2-4397
*************************************************************
*/


#ifndef LVS_CONSTANTS_H
#define LVS_CONSTANTS_H

const int BITMAP_SIZE                 = 192;
const int MAX_VALUE_LEN               = 2048;
const int LOG_POS                     = 0;
const int LOG_DV                      = 1;
const int LOG_PDV                     = 2;
const int LOG_MDS                     = 3;
const int LOG_MCI                     = 4;
const int LOG_AVR                     = 5;
const int LOG_PDVDIAL                 = 6;
const int LOG_MNAC                    = 7;
const int LOG_EPACK                   = 8;
const int LOG_SICREDI                 = 15;
const int LOG_MTVN                    = 16;
const int LOG_COOP                    = 17;
const int LOG_ITAUPL                  = 18;
const int LOG_EC                      = 19;
const int LOG_MPG                     = 20;
const int LOG_OL                      = 21;
const int LOG_TPDU                    = 22;
const int LOG_PDVM	                  = 67;
const int LOG_PDVDIALMTG              = 68;
const int LOG_SITEF                   = 100;
const int LOG_SMNT                    = 101;
const int LOG_HSTPV                   = 102;
const int LOG_AVRVG                   = 103;
const int LOG_TICKET                  = 104;
const int LOG_HSTPP                   = 102;
const int LOG_SRSA                    = 105;
const int LOG_CEFPV                   = 106;
const int LOG_VISA                    = 200;
const int LOG_CUP                     = 201;
const int LOG_ACQPOSMTG		      	  = 210;
const int LOG_ACQPDVDIALMTG	      	  = 211;
const int LOG_ACQPOSTG		      	  = 212;
const int LOG_ACQPDVDIALTG	      	  = 213;
const int LOG_ACQPDVIP		      	  = 214;
const int LOG_ACQPDVBIGIP	      	  = 215;
const int LOG_ACQPDVKMS		      	  = 216;
const int LOG_ACQPDVPROTOM	      	  = 217;
const int LOG_ACQPOSIP	      	      = 218;
const int LOG_POSQH  	      	      = 219;
const int LOG_ACQPDVINAC      	      = 220; // BRUM - EAK-1623 - 24/07/2019 - Tratamento mensagem PDV intellinac
const int LOG_ACQPDVQH                = 221;
const int LOG_ACQPDVCORBAN            = 222;
const int LOG_ELO                     = 300;
const int LOG_AMEX                    = 301;
const int LOG_AMEX_FULL               = 301;
const int LOG_ELO_FULL                = 302;
const int LOG_PLANET                  = 303;
const int LOG_ACQPOSTOP               = 304; // AUT2-4397 - Tap On Phone

//IdLog utilizados para Caputura
const int LOG_CAPCRED                 = 501;
const int LOG_CAPDEB                  = 502;
const int LOG_CAPNFIN                 = 503;
const int LOG_CAPPRIV                 = 504;
const int LOG_CAPEND                  = 505;
const int LOG_CAPENDPDT               = 506;
const int LOG_CAPCREDMTVN  		      = 507;
const int LOG_CAPCREDVISA             = 508;
const int LOG_CAPDEBVISA              = 509;
const int LOG_CAPENDPDTVISA           = 510;
const int LOG_CAPCREDD	              = 511;    
const int LOG_CAPCREDVISAD            = 512;
const int LOG_CAPDEBD                 = 513;
const int LOG_CAPDEBVISAD             = 514;

const int LOG_CAPELOVAN               = 515;
const int LOG_CAPAMEX                 = 516;

const int MAX_ERROR_SIZE              = 256;
const int TIME_OUT                    = 120000;
const int MAX_BUFFER_SIZE             = 1024;  

const int OK                          = 1;
const int NOK                         = 0;

const int TAM_MAX_TOKEN               = 1024;
const int NUMERO_DE_PARAMETROS        = 15;
const char* const TOKEN_DELIMITER     = "&";

const char* const SAVED_LOG_BASE_PATH = "C:/repositorio";


const char FILE_NOT_FOUND             = '0';
const char FILE_FOUND                 = '1';

const int FILE_DATE_LIMIT             = 15;

const int REG_EXP_MAX_SIZE            = 256;

const int MAX_NUM_REG                 = 9999;

#endif
