/* Copyright 2017 Rede S.A.
Autor : Andre Morishita
Empresa : Leega
*/

#ifndef _MASKELOFULLINTERPRETER_H_
#define _MASKELOFULLINTERPRETER_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/// MaskEloFullInterpreter
/// Classe responsavel pelo parse e mascaramento das transacoes 
/// EF/ET: EF1
/// Historico: [Data] - [Autor] - ET - Descricao
/// 31/01/2017 - Andre Morishita - EF1 - Cria��o
class MaskEloFullInterpreter : public Mask_Interpreter 
{
    public:
    
        //Construtor e Destruidor
        MaskEloFullInterpreter(int maximo, int headerSize, int mapType);
        ~MaskEloFullInterpreter();
        
        //M�todo classe base para o parse e mascaramento
        void maskRecord( const char *record );
};
#endif // _MASKELOFULLINTERPRETER_H_
