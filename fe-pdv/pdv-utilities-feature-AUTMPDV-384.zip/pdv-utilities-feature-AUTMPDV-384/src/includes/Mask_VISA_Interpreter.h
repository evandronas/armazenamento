// Mask_VISA_Interpreter.h: interface for the Mask_VISA_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_VISA_INTERPRETER_H__67C1157B_1381_409B_8776_400BA0984D94__INCLUDED_)
#define AFX_MASK_VISA_INTERPRETER_H__67C1157B_1381_409B_8776_400BA0984D94__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_VISA_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log POS com mascaramento
*
*	Data de cria��o: 17/09/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
**////////////////////////////////////////
class Mask_VISA_Interpreter : public Mask_Interpreter 
{
	public:
		Mask_VISA_Interpreter(int, int);
		~Mask_VISA_Interpreter();
		
		void maskRecord( const char* );

	protected:
		void convertSize( char * size_byte, int *size);
		void openDE55(char *buffer, int tipoDisplay);
		void openDE126(char *buffer);
		void maskFields_126(const char *_rec);


};

#endif // !defined(AFX_MASK_VISA_INTERPRETER_H__67C1157B_1381_409B_8776_400BA0984D94__INCLUDED_)
