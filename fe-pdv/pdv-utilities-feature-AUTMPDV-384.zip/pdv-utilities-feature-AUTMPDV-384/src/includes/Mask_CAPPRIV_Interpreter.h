// Mask_CAPPRIV_Interpreter.h: interface for the Mask_CAPPRIV_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_CAPPRIV_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_)
#define AFX_MASK_CAPPRIV_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_CAPPRIV_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log CAPPRIV com mascaramento
*
*	Data de cria��o: 18/09/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
**////////////////////////////////////////
class Mask_CAPPRIV_Interpreter : public Mask_Interpreter 
{
	public:
		Mask_CAPPRIV_Interpreter(int, int);
		~Mask_CAPPRIV_Interpreter();

		void maskRecord( const char* );

};

#endif // !defined(AFX_MASK_CAPPRIV_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_)
