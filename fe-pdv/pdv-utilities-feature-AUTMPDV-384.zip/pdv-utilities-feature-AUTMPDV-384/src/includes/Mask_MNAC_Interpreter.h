// Mask_MNAC_Interpreter.h: interface for the Mask_MNAC_Interpreter class.
//
//////////////////////////////////////////////////////////////////////



#include "Mask_POS_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_MNAC_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log POS com mascaramento
*
*	Data de cria��o: 17/09/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
**////////////////////////////////////////
class Mask_MNAC_Interpreter : public Mask_POS_Interpreter
{
	public:
		Mask_MNAC_Interpreter(int, int);
		~Mask_MNAC_Interpreter();
		int initRecord( char*);
};

