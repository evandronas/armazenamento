// Mask_CUP_Interpreter.h: interface for the Mask_CUP_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_CUP_INTERPRETER_H__3BA31DE0_C760_4935_8667_36775CA736A6__INCLUDED_)
#define AFX_MASK_CUP_INTERPRETER_H__3BA31DE0_C760_4935_8667_36775CA736A6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_CUP_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log CUP com mascaramento
*
*	Data de cria��o: 18/09/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
**////////////////////////////////////////
class Mask_CUP_Interpreter : public Mask_Interpreter 
{
	public:
		Mask_CUP_Interpreter(int, int, int);
		~Mask_CUP_Interpreter();


		void maskRecord( const char* );
};

#endif // !defined(AFX_MASK_CUP_INTERPRETER_H__3BA31DE0_C760_4935_8667_36775CA736A6__INCLUDED_)
