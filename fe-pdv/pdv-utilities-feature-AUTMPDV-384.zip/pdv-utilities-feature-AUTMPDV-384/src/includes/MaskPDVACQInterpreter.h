/*
Copyright 2015 Rede S.A.
*************************************************************
Nome     : MaskPDVACQInterpreter.h
Descri��o: Classe responsavel pela interpreta�ao do Log PDV com mascaramento
Autor    : Projeto de Captura
Data     : 15/02/2015
Empresa  : Rede
ID       : 30352 - FE-PDV - Migra��o da interface com PDV-Dedicado
*************************************************************
*/

#if !defined(AFX_Mask_PDVACQ_INTERPRETER_H__E30687EF_4EDA_4168_A27F_1B6AE3F6FD58__INCLUDED_)
#define AFX_Mask_PDVACQ_INTERPRETER_H__E30687EF_4EDA_4168_A27F_1B6AE3F6FD58__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/// MaskPDVACQInterpreter
/// Descri��o: Classe responsavel pelo parse e mascaramento das transacoes PDV SW 7.5
class MaskPDVACQInterpreter : public Mask_Interpreter  
{
	public:
		MaskPDVACQInterpreter(int, int, int);
		~MaskPDVACQInterpreter();

		void maskRecord( const char* );

};

#endif // !defined(AFX_Mask_PDVACQ_INTERPRETER_H__E30687EF_4EDA_4168_A27F_1B6AE3F6FD58__INCLUDED_)
