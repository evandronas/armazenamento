// Mask_ITAUPL_Interpreter.h: interface for the Mask_ITAUPL_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Mask_ITAUPL_INTERPRETER_H__B5E28878_018E_446C_8A68_6F03FB5A496F__INCLUDED_)
#define AFX_Mask_ITAUPL_INTERPRETER_H__B5E28878_018E_446C_8A68_6F03FB5A496F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_ITAUPL_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log DV com mascaramento
*
*	Data de cria��o: 18/09/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
**////////////////////////////////////////
class Mask_ITAUPL_Interpreter : public Mask_Interpreter  
{
	public:
		Mask_ITAUPL_Interpreter(int, int);
		~Mask_ITAUPL_Interpreter();

		void maskRecord( const char* );

};

#endif // !defined(AFX_Mask_ITAUPL_INTERPRETER_H__B5E28878_018E_446C_8A68_6F03FB5A496F__INCLUDED_)
