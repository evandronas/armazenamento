// Mask_PDVDIAL_Interpreter.h: interface for the Mask_PDVDIAL_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_PDVDIAL_INTERPRETER_H__9C5FEEBB_4B63_409C_B3EB_0B58DF318AF9__INCLUDED_)
#define AFX_MASK_PDVDIAL_INTERPRETER_H__9C5FEEBB_4B63_409C_B3EB_0B58DF318AF9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_PDVDIAL_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log PDVDIAL com mascaramento
*
*	Data de cria��o: 17/09/2003
*
*   @author Mario Yoshio Maruta (mario@solvo.com.br)
*
**////////////////////////////////////////
class Mask_PDVDIAL_Interpreter : public Mask_Interpreter  
{
	public:
		
		Mask_PDVDIAL_Interpreter( int, int, int );
		~Mask_PDVDIAL_Interpreter();

		void maskRecord( const char* );

};

#endif // !defined(AFX_MASK_PDVDIAL_INTERPRETER_H__9C5FEEBB_4B63_409C_B3EB_0B58DF318AF9__INCLUDED_)
