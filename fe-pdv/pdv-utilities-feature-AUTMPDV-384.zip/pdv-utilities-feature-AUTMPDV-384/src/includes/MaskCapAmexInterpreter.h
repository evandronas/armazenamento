/*
Copyright 2016 Rede S.A.
*********************** MODIFICA��ES ************************
Autor : Sandra Silveira
Data : 19/02/2016
Empresa : Rede
Descri��o: Cria��o do arquivo de tratamento para CAPAMEX e REVAMEX
ID : AM 147.449
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 15/10/2017
Empresa  : Rede
Descri��o: Upgrade Captura - ELOVAN / AMEX
ID       : AM 61.353
*************************************************************
*/

#if !defined(AFX_MASK_CAPAMEX_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_)
#define AFX_MASK_CAPAMEX_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/// MaskCapAmexInterpreter 
/// Mascaramento de dados sensiveis nas CAPs da Amex 
/// EF/ET: Numero da EF ou ET que criou a necessidade da classe 
/// Hist�rico: [Data]     � [Autor]      - ET - Descri��o
///            19/02/2016 � Sandra Silveira - 147449 - Criacao 
/// 

class MaskCapAmexInterpreter : public Mask_Interpreter 
{
	public:
		MaskCapAmexInterpreter (int, int);
		~MaskCapAmexInterpreter ();

		void maskRecord( const char* );

};

#endif // !defined(AFX_MASK_CAPAMEX_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_)
