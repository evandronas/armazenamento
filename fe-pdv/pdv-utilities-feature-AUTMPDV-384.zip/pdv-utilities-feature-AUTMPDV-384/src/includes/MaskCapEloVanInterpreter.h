/*
Copyright 2016 Rede S.A.
*********************** MODIFICA��ES ************************
Autor : Fabio Mazzer
Data : 06/01/2016
Empresa : Rede
Descri��o: Cria��o do arquivo de tratamento para CAPCREDELOVAN e CAPDEBELOVAN
ID : AM 147.449
*************************************************************
Autor    : Mauro Thiago da Silva
Data     : 15/10/2017
Empresa  : Rede
Descri��o: Upgrade Captura - ELOVAN / AMEX
ID       : AM 61.353
*************************************************************
*/

#if !defined(AFX_MASK_CAPELOVAN_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_)
#define AFX_MASK_CAPELOVAN_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/// MaskCapEloVanInterpreter 
/// Mascaramento de dados sensiveis nas CAPs da Elo 
/// EF/ET: Numero da EF ou ET que criou a necessidade da classe 
/// Hist�rico: [Data]     � [Autor]      - ET - Descri��o
///            06/01/2016 � Fabio Mazzer - 147449 - Criacao 
/// 

class MaskCapEloVanInterpreter : public Mask_Interpreter 
{
	public:
		MaskCapEloVanInterpreter (int, int);
		~MaskCapEloVanInterpreter ();

		void maskRecord( const char* );

};

#endif // !defined(AFX_MASK_CAPELOVAN_INTERPRETER_H__B41E95FE_5F8E_40AB_ADD2_AA5EFB3C8F4C__INCLUDED_)
