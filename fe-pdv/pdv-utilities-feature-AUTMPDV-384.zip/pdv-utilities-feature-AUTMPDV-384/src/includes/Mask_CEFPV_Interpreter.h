// Mask_CEFPV_Interpreter.h: interface for the Mask_CEFPV_Interpreter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASK_CEFPV_INTERPRETER_H__E30687EF_4EDA_4168_A27F_1B6AE3F6FD58__INCLUDED_)
#define AFX_MASK_CEFPV_INTERPRETER_H__E30687EF_4EDA_4168_A27F_1B6AE3F6FD58__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Mask_Interpreter.h"

/////////////////////////////////////////
/**
*
*	Nome: Mask_CEFPV_Interpreter.h
*
*   Descri��o: Classe responsavel pela interpreta�ao
*              do Log CEF PDV com mascaramento
*
*	Data de cria��o: 18/05/2011
*
*   @author Fabio Mazzer (servicoresource696181@redecard.com.br)
*
**////////////////////////////////////////
class Mask_CEFPV_Interpreter : public Mask_Interpreter  
{
	public:
		Mask_CEFPV_Interpreter(int, int, int);
		~Mask_CEFPV_Interpreter();

		void maskRecord( const char* );

};

#endif // !defined(AFX_MASK_CEFPV_INTERPRETER_H__E30687EF_4EDA_4168_A27F_1B6AE3F6FD58__INCLUDED_)
