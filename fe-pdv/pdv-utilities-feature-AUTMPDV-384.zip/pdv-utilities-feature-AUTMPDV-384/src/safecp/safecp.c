/*
 *
 *  This program makes a copy of a source file to a destination file.
 *  After the copy, the source file is truncated.
 *  It was created to make backups and clear log files.
 *  The program works in such a way that while making the copy the
 *  source file can be written by other process. The program ensures
 *  that any data written to the source file will not be lost while
 *  making the copy.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

#define CPBUFFERSIZE (96*1024)

char cpbuffer[CPBUFFERSIZE];


int main(int argc, char *argv[])
{
	char *sname, *dname;
	int fsrce, fdest;
	int bytesrd, byteswr;

	if (argc < 3) {
		printf("Usage: %s src_file dst_file\n", argv[0]);
		return 1;
	}

	sname = argv[1];
	dname = argv[2];

	/*	fsrce = open(sname, O_RDWR);
	 * 	209_SW-Erro Backup acima 2Gb-CORRECAO ACCENTURE, TROCA DA FUNCAO OPEN() POR OPEN64() - AM63574 - WRB */
	fsrce = open64(sname, O_RDWR);
	/*
	 * 	209_SW-Erro Backup acima 2Gb-CORRECAO ACCENTURE, TROCA DA FUNCAO OPEN() POR OPEN64() - AM63574 - WRB */
	if (fsrce < 0) {
		printf("Error opening '%s': %s\n", sname, strerror(errno));
		return 1;
	}

	/* 	fdest = creat(dname, 0660);
	 * 	209_SW-Erro Backup acima 2Gb-CORRECAO ACCENTURE, TROCA DA FUNCAO CREAT() POR CREAT64() - AM63574 - WRB */
	fdest = creat64(dname, 0660);
	/* 	
	 * 	209_SW-Erro Backup acima 2Gb-CORRECAO ACCENTURE, TROCA DA FUNCAO CREAT() POR CREAT64() - AM63574 - WRB */
	if (fdest < 0) {
		printf("Error creating '%s': %s\n", dname, strerror(errno));
		return 1;
	}

	/*
	 *  Tries to copy as much as possible from source file
	 *  to destination file before locking the source file
	 */

	do {

		bytesrd = read(fsrce, cpbuffer, CPBUFFERSIZE);
		if (bytesrd < 0) {
			printf("Error reading '%s': %s\n", sname, strerror(errno));
			return 1;
		}

		byteswr = write(fdest, cpbuffer, bytesrd);
		if (byteswr < bytesrd) {
			printf("Error writing '%s': %s\n", dname, strerror(errno));
			return 1;
		}
		
	} while (bytesrd == CPBUFFERSIZE);

	/*
	 *  Now locks the source file to ensure that all of
	 *  its contents be copied to destination file
	 */

	lockf(fsrce, F_LOCK, 0);

	/*
	 *  Copies the remaining part of source to destination
	 */

	do {

		bytesrd = read(fsrce, cpbuffer, CPBUFFERSIZE);
		if (bytesrd < 0) {
			lockf(fsrce, F_ULOCK, 0);
			printf("Error reading '%s': %s\n", sname, strerror(errno));
			return 1;
		}

		byteswr = write(fdest, cpbuffer, bytesrd);
		if (byteswr < bytesrd) {
			lockf(fsrce, F_ULOCK, 0);
			printf("Error writing '%s': %s\n", dname, strerror(errno));
			return 1;
		}

	} while (bytesrd == CPBUFFERSIZE);

   /*
	*  Truncates the source file
	*
	*   ftruncate(fsrce, 0);
	* 	209_SW-Erro Backup acima 2Gb-CORRECAO ACCENTURE, TROCA DA FUNCAO FTRUNCATE() POR FTRUNCATE64() - AM63574 - WRB */
	ftruncate64(fsrce, 0);
	/* 	209_SW-Erro Backup acima 2Gb-CORRECAO ACCENTURE, TROCA DA FUNCAO FTRUNCATE() POR FTRUNCATE64() - AM63574 - WRB */


	ftruncate(fsrce, 0);

	/*
	 *  Unlock the source file
	 */

	lockf(fsrce, F_ULOCK, 0);

	close(fsrce);
	close(fdest);

	return 0;
}
