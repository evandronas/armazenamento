/*
 * Comando datediff
 * ----------------
 *
 * Calcula a diferen�a entre duas datas.
 * Sum�rio:
 * datediff [-c|-h] [-d|-m|-y|-H|-M|-S] <init date> [<end date>]
 *
 * Andr� Lu�s da Silva Monteiro
 * 14 de mar�o de 2005
 * PSE - SOF
 *
 * $Log: datediff.c,v $
 * Revision 1.1  2005-12-05 13:08:48-03  t817392
 * Initial revision
 *
 *
 */

#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#include <stdio.h>

#define MAX_PARAM_LEN		64
#define MAX_OUTPUT_LEN		128

/* utility stuff */
int antoi(char *s, int n);

/*
 * Exibe mensagem descrevendo o comando
 */
void display_help_msg() {
	fprintf(stderr, "Usage: datediff [-c|-h] [-d|-m|-y|-H|-M|-S] <init date> [<end date>]\n");
}

/*
 * Calcula a diferen�a entre os dois timestamps indicados
 */
double evaluate_delta(char granulum, struct tm *tinit, struct tm *tend) {
	#define ONE_MINUTE	60
	#define ONE_HOUR	(60 * ONE_MINUTE)
	#define ONE_DAY		(24 * ONE_HOUR)

	double diff;

	switch (granulum) {
	case 'y':
		return tend->tm_year - tinit->tm_year;

	case 'm':
		return 12 * (tend->tm_year - tinit->tm_year) + tend->tm_mon - tinit->tm_mon;
	}

	diff = difftime(mktime(tend), mktime(tinit));

	switch (granulum) {
	case 'd':
		return floor(diff / ONE_DAY);

	case 'H':
		return floor(diff / ONE_HOUR);

	case 'M':
		return floor(diff / ONE_MINUTE);

	case 'S':
		return floor(diff);

	default:
		fprintf(stderr, "datediff: 021: Bad granulum\n");
		exit(1);
	}
}

/*
 * Processa uma data, gerando um timestamp
 */
int evaluate_timestamp(char *pdate, int no_century, int hours_only, struct tm *tm) {
	int year = 0, month = 0, day = 0;
	struct tm TM;

	memset(&TM, 0, sizeof(struct tm));
	TM.tm_isdst=-1;

	if (!hours_only) {
		/* the year */
		if (no_century) {
			if ((year = antoi(pdate, 2)) < 0)
				return -1;

			pdate += 2;

			if (year > 68)
				year += 1900;
			else
				year += 2000;
		} else {
			if ((year = antoi(pdate, 4)) < 0)
				return -1;

			pdate += 4;
		}

		/* the month */
		if (!*pdate || (month = antoi(pdate, 2)) < 0)
			return -1;
		month--;
		pdate += 2;

		/* the day */
		if (!*pdate || (day = antoi(pdate, 2)) < 0)
			return -1;
		pdate += 2;

		TM.tm_year = year - 1900;
		TM.tm_mon = month;
		TM.tm_mday = day;
	} else {
		time_t now = time(NULL);
		memcpy(&TM, localtime(&now), sizeof(struct tm));

		year = TM.tm_year + 1900;
		month = TM.tm_mon;
		day = TM.tm_mday;
	}

	if (*pdate) {
		/* the hour */
		if ((TM.tm_hour = antoi(pdate, 2)) < 0 || TM.tm_hour > 23)
			return -1;
		pdate += 2;

		/* the minutes */
		if (!*pdate || (TM.tm_min = antoi(pdate, 2)) < 0 || TM.tm_min > 59)
			return -1;
		pdate += 2;

		/* the seconds */
		if (*pdate) {
			if ((TM.tm_sec = antoi(pdate, 2)) < 0 || TM.tm_sec > 59)
				return -1;
			pdate += 2;
		} else {
			TM.tm_sec = 0;
		}
	}

	if (*pdate)
		return -1;

	if ((mktime(&TM)) < 0)
		return -1;

	/* checa a data */
	if (year != TM.tm_year + 1900 || month != TM.tm_mon || day != TM.tm_mday)
		return -1;

	memcpy(tm, &TM, sizeof(struct tm));

	return 0;
}

/*
 * Processa os par�metros passados e inicializa as vari�veis de trabalho
 */
int process_parameters(int argc, char *argv[], double *diff) {
	int a, l, e;
	int no_century, hours_only;
	char *s, granulum, pinitdt[MAX_PARAM_LEN + 1], penddt[MAX_PARAM_LEN + 1];
	struct tm tsinit, tsend;

	if (argc == 1)
		return -1;

	*pinitdt = *penddt = 0;
	no_century = hours_only = 0;
	granulum = 'S';

	for (a = 1; a < argc; a++) {
		if (*argv[a] != '-') {
			if (!*pinitdt) {
				strncpy(pinitdt, argv[a], MAX_PARAM_LEN);
				pinitdt[MAX_PARAM_LEN] = 0;
			} else if (!*penddt) {
				strncpy(penddt, argv[a], MAX_PARAM_LEN);
				penddt[MAX_PARAM_LEN] = 0;
			} else {
				fprintf(stderr, "datediff: 001: Bad parameter: %s.\n", argv[a]);
				return -1;
			}

			continue;
		}

		for (s = argv[a] + 1; *s; s++) {
			switch (*s) {
			case 'c':
				no_century = 1;
				break;

			case 'h':
				hours_only = 1;
				break;

			case 'd':
			case 'm':
			case 'y':
			case 'H':
			case 'M':
			case 'S':
				granulum = *s;
				break;

			default:
				fprintf(stderr, "datediff: 010: Not a recognized flag: %s.\n", argv[a]);
				return -1;
			}
		}
	}

	if (!*pinitdt) {
		fprintf(stderr, "datediff: 011: Missing initial date.\n");
		return -1;
	}

	if (evaluate_timestamp(pinitdt, no_century, hours_only, &tsinit) < 0) {
		fprintf(stderr, "datediff: 012: Bad initial date: %s.\n", pinitdt);
		exit(2);
	}

	if (*penddt) {
		if (evaluate_timestamp(penddt, no_century, hours_only, &tsend) < 0) {
			fprintf(stderr, "datediff: 013: Bad end date: %s.\n", penddt);
			exit(2);
		}
	} else {
		time_t timer = time(NULL);
		memcpy(&tsend, localtime(&timer), sizeof(struct tm));
	}

	*diff = evaluate_delta(granulum, &tsinit, &tsend);

	return 0;
}

int antoi(char *s, int n) {
	int i, v;

	for (i = 0, v = 0; *s && i < n; i++, s++)
		if (isdigit(*s)) {
			v *= 10;
			v += (*s - '0');
		} else
			return -1;
		
	return v;
}


main(int argc, char *argv[]) {
	double diff;

	if (process_parameters(argc, argv, &diff) < 0) {
		display_help_msg();
		exit(3);
	}

	printf("%.12g\n", diff);
}
