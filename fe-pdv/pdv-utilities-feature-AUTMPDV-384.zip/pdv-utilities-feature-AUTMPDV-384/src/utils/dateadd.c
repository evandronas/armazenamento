/*
 * Comando dateadd
 * ---------------
 *
 * Calcula uma nova data, formatando a sa�da similarmente ao comando "date".
 * Sum�rio:
 * dateadd [-ch] [-D<date>] [-H<hour>] [-f<format>] <delta>
 *
 * Andr� Lu�s da Silva Monteiro
 * 14 de mar�o de 2005
 * PSE - SOF
 *
 * $Log:$
 *
 */

#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <stdio.h>

#define MAX_PARAM_LEN		64
#define MAX_OUTPUT_LEN		128

#define ERR_EVAL_BAD_TSTAMP	-1
#define ERR_EVAL_BAD_DELTA	-2

/* utility stuff */
int antoi(char *s, int n);

/*
 * Exibe mensagem descrevendo o comando
 */
void display_help_msg() {
	fprintf(stderr, "Usage: dateadd [-c] [-D<date>] [-H<hour>] [-f<format>] <delta>\n");
	fprintf(stderr, "       where <delta> = <+|-><int><d|m|y|H|M|S>\n");
}

/*
 * Determina formato default baseado nos par�metros passados
 */
void set_default_format(char *format, int no_century, int hours, int no_dd, int no_ss) {
	if (no_century)
		strcpy(format, "%y/%m");
	else
		strcpy(format, "%Y/%m");

	if (!no_dd)
		strcat(format, "/%d");
		
	if (hours) {
		strcat(format, " %H:%M");

		if (!no_ss)
			strcat(format, ":%S");
	}
}

/*
 * Processa o par�metro delta, aplicando-o ao timestamp especificado
 */
int apply_delta(char *pdelta, struct tm *tstmp, int *hrs, int *ndd, int *nss) {
	long delta;
	char *g;

	if (strlen(pdelta) > 9)
		return ERR_EVAL_BAD_DELTA;

	if ((delta = strtol(pdelta, &g, 10)) == 0)
		return ERR_EVAL_BAD_DELTA;

	switch (*g) {
	case 'd':
		tstmp->tm_mday += delta;
		*ndd = 0;
		break;

	case 'm':
		tstmp->tm_mon += delta;
		break;

	case 'y':
		tstmp->tm_year += delta;
		break;

	case 'H':
		tstmp->tm_hour += delta;
		*hrs = 1;
		break;

	case 'M':
		tstmp->tm_min += delta;
		*hrs = 1;
		break;

	case 'S':
		tstmp->tm_sec += delta;
		*hrs = 1;
		*nss = 0;
		break;

	default:
		return ERR_EVAL_BAD_DELTA;
	}

	mktime(tstmp);

	return 0;
}

/*
 * Processa os par�metros data, hora e delta, gerando um timestamp
 */
int evaluate_timestamp(char *pdate, char *phour, char *pdelta, int no_century, struct tm *tstmp, int *hours, int *no_dd, int *no_ss) {
	int year = 0, month = 0, day = 0;
	time_t timer = 0;

	*hours = *no_dd = *no_ss = 0;

	if (time(&timer) == -1) {
		fprintf(stderr, "dateadd: 021: Couldn't access the system time.\n");
		exit(1);
	}

	memcpy(tstmp, localtime(&timer), sizeof(struct tm));

	year = tstmp->tm_year + 1900;
	month = tstmp->tm_mon;
	day = tstmp->tm_mday;

	if (*pdate) {
		/* the year */
		if (no_century) {
			if (strlen(pdate) != 6 && strlen(pdate) != 4)
				return -1;

			if ((year = antoi(pdate, 2)) < 0)
				return -1;

			pdate += 2;

			if (year > 68)
				year += 1900;
			else
				year += 2000;
		} else {
			if (strlen(pdate) != 8 && strlen(pdate) != 6)
				return -1;

			if ((year = antoi(pdate, 4)) < 0)
				return -1;

			pdate += 4;
		}

		/* the month */
		if ((month = antoi(pdate, 2)) < 0)
			return -1;
		month--;
		pdate += 2;

		/* the day */
		if (*pdate) {
			if ((day = antoi(pdate, 2)) < 0)
				return -1;
		} else {
			day = 1;
			*no_dd = 1;
		}

		tstmp->tm_year = year - 1900;
		tstmp->tm_mon = month;
		tstmp->tm_mday = day;
	}

	if (*phour) {
		if (strlen(phour) != 6 && strlen(phour) != 4)
			return -1;

		/* the hour */
		if ((tstmp->tm_hour = antoi(phour, 2)) < 0 || tstmp->tm_hour > 23)
			return -1;
		phour += 2;

		/* the minutes */
		if ((tstmp->tm_min = antoi(phour, 2)) < 0 || tstmp->tm_min > 59)
			return -1;
		phour += 2;

		/* the seconds */
		if (*phour) {
			if ((tstmp->tm_sec = antoi(phour, 2)) < 0 || tstmp->tm_sec > 59)
				return -1;
		} else {
			tstmp->tm_sec = 0;
			*no_ss = 1;
		}
	}

	/* checa a data */
	if ((timer = mktime(tstmp)) < 0)
		return -1;
	if (year != tstmp->tm_year + 1900
	|| month != tstmp->tm_mon || day != tstmp->tm_mday)
		return -1;

	/* aplica o delta */
	return apply_delta(pdelta, tstmp, hours, no_dd, no_ss);
}

/*
 * Processa os par�metros passados e inicializa as vari�veis de trabalho
 */
int process_parameters(int argc, char *argv[], char *format, struct tm *tstmp) {
	int a, l, e;
	int no_century = 0, hours = 0, no_dd = 0, no_ss = 0;
	char *s, pdelta[MAX_PARAM_LEN + 1], pdate[MAX_PARAM_LEN + 1], phour[MAX_PARAM_LEN + 1];

        memset(pdate, 0, MAX_PARAM_LEN + 1);
	#define SHIFT {			\
		if (a < argc) {		\
			a++;			\
			s = argv[a];	\
		} else {			\
			s = "";			\
		}					\
	}

	*format = 0;

	if (argc == 1)
		return -1;

	for (a = 1; a < argc; a++) {
		if (*argv[a] != '-' && *argv[a] != '+') {
			fprintf(stderr, "dateadd: 001: Bad parameter: %s.\n", argv[a]);
			return -1;
		}

		s = argv[a];

		if (*s == '+' || atoi(s)) {
			if (strlen(s) > 10) {
				fprintf(stderr, "dateadd: 002: Bad delta: %s.\n", argv[a]);
				return -1;
			}

			strcpy(pdelta, s);

			continue;
		}

		for (s++; *s; s++) {
			switch (*s) {
			case 'c':
				no_century = 1;
				break;

			case 'D':
				s++;

				if (!*s)
					SHIFT;

				if (!*s) {
					fprintf(stderr, "dateadd: 003: Missing date argument.\n");
					return -1;
				}
				if ((l = strlen(s)) > MAX_PARAM_LEN) {
					fprintf(stderr, "dateadd: 004: Bad date: %s.\n", s);
					exit(2);
				}

				strcpy(pdate, s);
				s += l - 1;

				break;

			case 'f':
				s++;

				if (!*s)
					SHIFT;

				if (!*s) {
					fprintf(stderr, "dateadd: 005: Missing format argument.\n");
					return -1;
				}
				if ((l = strlen(s)) > MAX_PARAM_LEN) {
					fprintf(stderr, "dateadd: 006: Bad format (too long): %s.\n", s);
					exit(2);
				}

				strcpy(format, s);
				s += l - 1;

				break;

			case 'H':
				s++;

				if (!*s)
					SHIFT;

				if (!*s) {
					fprintf(stderr, "dateadd: 007: Missing hour argument.\n");
					return -1;
				}
				if ((l = strlen(s)) > MAX_PARAM_LEN) {
					fprintf(stderr, "dateadd: 008: Bad hour: %s.\n", s);
					return -1;
				}

				strcpy(phour, s);
				s += l - 1;

				break;

			default:
				fprintf(stderr, "dateadd: 010: Not a recognized flag: %s.\n", argv[a]);
				return -1;
			}
		}
	}

	if (!*pdelta) {
		fprintf(stderr, "dateadd: 011: Missing delta parameter.\n");
		return -1;
	}

	e = evaluate_timestamp(pdate, phour, pdelta, no_century, tstmp,
		&hours, &no_dd, &no_ss);

	switch (e) {
	case ERR_EVAL_BAD_TSTAMP:
		fprintf(stderr, "dateadd: 012: Bad date or bad hour:");
		if (*pdate)
			fprintf(stderr, " %s", pdate);
		if (*phour)
			fprintf(stderr, " %s", phour);
		fputs(".\n", stderr);
		exit(2);

	case ERR_EVAL_BAD_DELTA:
		fprintf(stderr, "dateadd: 013: Bad delta: %s.\n", pdelta);
		exit(2);
	}

	if (!*format)
		set_default_format(format, no_century, hours, no_dd, no_ss);

	return 0;
}

int antoi(char *s, int n) {
	int i, v;

	for (i = 0, v = 0; *s && i < n; i++, s++)
		if (isdigit(*s)) {
			v *= 10;
			v += (*s - '0');
		} else
			return -1;
		
	return v;
}


main(int argc, char *argv[]) {
	struct tm timestamp;
	char format[MAX_PARAM_LEN + 1];
	char output[MAX_OUTPUT_LEN + 1];

	if (process_parameters(argc, argv, format, &timestamp) < 0) {
		display_help_msg();
		exit(3);
	}

	if (!strftime(output, MAX_OUTPUT_LEN, format, &timestamp)) {
		fprintf(stderr, "dateadd: 022: Couldn't format output string.\n");
		exit(4);
	}

	printf("%s\n", output);
}
