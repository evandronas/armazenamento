#!/usr/bin/bash

set -x 
{
# RPM Variables
RPM_PREFIX_DIR="/opt/rpm/SW7/autorizador/aplicacao/online/deliverable/fe-pdv-deliverable"

# Install directories
SOURCE_DIR="cfg dtd shell tasks xml"
TARGET_DIR="/home/SW/PDV"

# Log
LOGFILE="/tmp/online_deliverable_fepdvdeliverable-before-remove.log"

for dir in $SOURCE_DIR; do

    cd $RPM_PREFIX_DIR/$dir
    for file in $(find . -type f -print); do
        rm -vf $TARGET_DIR/$dir/${file:2}
    done;
    cd -

done

echo "[rpm] The package has been uninstalled"

set +x
} > /tmp/online_deliverable_fepdvdeliverable-before-remove.log 2>&1

echo "[rpm] A log has been created: ${LOGFILE}"

exit 0;
