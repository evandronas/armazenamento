#!/usr/bin/bash

set -x 
{
# AWS Variables
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep region| awk '{print $3}'|sed  's/"//g'|sed 's/,//g')
AZ=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep availabilityZone| awk '{print $3}'|sed  's/"//g'|sed 's/,//g')
AZDB=$(echo ${AZ} | awk '{print substr($0,length($0),1)}')
INSTANCEID=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep instanceId| awk '{print $3}'|sed  's/"//g'|sed 's/,//g')
SITE=$(/usr/local/bin/aws ec2 describe-tags --filters "Name=resource-id,Values=${INSTANCEID}" --region $REGION --output text | awk '{if( $2 == "SITE") print $5}')
AMBIENTE=$(/usr/local/bin/aws ssm get-parameter --name "ambiente" --region $REGION --output text | awk '{ print $7 }')

# RPM Variables
RPM_PREFIX_DIR="/opt/rpm/SW7/autorizador/aplicacao/online/deliverable/fe-pdv-deliverable"

# Install directories
SOURCE_DIR="PDV site"
TARGET_DIR="/home/SW/"

# Permissions
SW_GROUP="Sistemas"

# Log
LOGFILE="/tmp/online_deliverable_fepdvdeliverable-after-install.log"

echo "[rpm] [$AMBIENTE] [$SITE] [$AZDB]"

# ------------------------------------------------------------------------------------
#  Renaming .cfg files
# ------------------------------------------------------------------------------------
# Examples: 
#           AMBIENTE: homol,  SITE: CTO    => Use .cfg@simulcto and @simul files
#           AMBIENTE: homol,  SITE: CTM    => Use .cfg@simulctm and @simul files
#           AMBIENTE: homol, AZA           => Use .cfg@simulaza and @simul files
#           AMBIENTE: prod,  AZA           => Use .cfg@prodaza and @prod files
#           AMBIENTE: prod, SITE: CTM, AZA => Use .cfg@prodctm, @prodaza, and @prod files
#           
#           AZDB: c  => Use .cfg@azc files
#           AZDB: a  => Use .cfg@aza files
# ------------------------------------------------------------------------------------
SITE_LCASE=$(echo $SITE | awk '{print tolower($0)}')

# Making **/* bring every file and folder recursively
shopt -s globstar

for dir in $SOURCE_DIR; do

    if [ "$AMBIENTE" == "homol" ]; then 
        rm -vf $RPM_PREFIX_DIR/$dir/**/*@prod*
        rename -v "@simul" "" $RPM_PREFIX_DIR/$dir/**/*@simul
        rename -v "@simul$SITE_LCASE" "" $RPM_PREFIX_DIR/$dir/**/*@simul$SITE_LCASE
        rename -v "@simulaz$AZDB" "" $RPM_PREFIX_DIR/$dir/**/*@simulaz$AZDB
        rm -rf $RPM_PREFIX_DIR/$dir/**/*@simul*
    elif [ "$AMBIENTE" == "prod" ]; then
        rm -vf $RPM_PREFIX_DIR/$dir/**/*@simul*
        rename -v "@prod" "" $RPM_PREFIX_DIR/$dir/**/*@prod
        rename -v "@prod$SITE_LCASE" "" $RPM_PREFIX_DIR/$dir/**/*@prod$SITE_LCASE
        rename -v "@prodaz$AZDB" "" $RPM_PREFIX_DIR/$dir/**/*@prodaz$AZDB
        rm -vf $RPM_PREFIX_DIR/$dir/**/*@prod*
    fi
    rm -vf $RPM_PREFIX_DIR/$dir/**/*@dev*

    if [ -n "$AZDB" ]; then
        rename -v "@az$AZDB" "" $RPM_PREFIX_DIR/$dir/**/*@az$AZDB
        rm -vf $RPM_PREFIX_DIR/$dir/**/*@az*
    fi

    #  Installing files
    mkdir -p $TARGET_DIR/$dir;
    cp -vfR $RPM_PREFIX_DIR/$dir/* $TARGET_DIR/$dir

    # Permissions
    chown -R swoper_appl_${AMBIENTE}:${SW_GROUP} $TARGET_DIR/$dir/*
    chmod 775 $TARGET_DIR/$dir/*

done

## Turning globstar option off
shopt -u globstar

echo "[rpm] The package has been installed"

set +x
} > /tmp/online_deliverable_fepdvdeliverable-after-install.log 2>&1

echo "[rpm] A log has been created: ${LOGFILE}"

exit 0;
