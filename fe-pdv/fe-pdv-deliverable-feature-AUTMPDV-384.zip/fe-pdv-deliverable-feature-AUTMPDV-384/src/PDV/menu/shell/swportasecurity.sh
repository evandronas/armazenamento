#!/usr/bin/bash

# Load Functions
. ~/GEN/shell/swvars.sh        # Carrega variaveis globais para o Sistema SW
. ~/GEN/shell/swfunc.sh        # Carrega funcoes genericas do SW
. ~/GEN/menu/shell/swshfunc.sh
. ~/GEN/menu/shell/swmenu.sh
start_sec_ip()
{
IP_SEC=$1
for FE_crypt in HST CRT CRTM DBT DBTM CRTO DBTO
do
        PARAM=${HOME}/site/$FE_crypt/cfg/istparam.cfg
        if [ -f  ${PARAM} ]; then
           . swloadenv ${FE_crypt} > /dev/null 2>&1
           PRT=`grep port.name.*security ${HOME}/site/$FE_crypt/cfg/istparam.cfg | egrep -v "#|ENTER_ADDRESS_HERE" | grep "$IP_SEC\." | awk '{ print $2 }'`
           GRAVALOG $PRT
           if [ -n "$PRT" ]; then
              echo Abrindo $FE_crypt porta $PRT
              mbportcmd start $PRT
              GRAVALOG "Abrindo $FE_crypt porta $PRT"
           fi
        fi
done
}

stop_sec_ip()
{
IP_SEC=$1

for FE_crypt in HST CRT CRTM DBT DBTM CRTO DBTO
do
        PARAM=${HOME}/site/$FE_crypt/cfg/istparam.cfg
        if [ -f  ${PARAM} ]; then
           . swloadenv ${FE_crypt} > /dev/null 2>&1
           PRT=`grep port.name.*security ${HOME}/site/$FE_crypt/cfg/istparam.cfg | egrep -v "#|ENTER_ADDRESS_HERE" | grep "$IP_SEC\." | awk '{ print $2 }'`
           GRAVALOG $PRT
           if [ -n "$PRT" ]; then
              echo Fechando $FE_crypt porta $PRT
              mbportcmd stop $PRT
              GRAVALOG "Fechando $FE_crypt porta $PRT"
           fi
        fi
done
}

list_sec_ip()
{
IP_SEC=$1

for FE_crypt in HST CRT CRTM DBT DBTM CRTO DBTO
do
        PARAM=${HOME}/site/$FE_crypt/cfg/istparam.cfg
        if [ -f  ${PARAM} ]; then
           . swloadenv ${FE_crypt} > /dev/null 2>&1
           PRT=`grep port.name.*security ${HOME}/site/$FE_crypt/cfg/istparam.cfg | egrep -v "#|ENTER_ADDRESS_HERE" | grep "$IP_SEC\." | awk '{ print $2 }'`
           GRAVALOG $PRT
           if [ -n "$PRT" ]; then
              echo Listando $FE_crypt porta $PRT
              mbportcmd list $PRT
              GRAVALOG "Listando $FE_crypt porta $PRT"
           fi
        fi
done
}


list_sec_options()
{
MESS_PORT=$1
    ALL_SECS=`grep port.name.*security ${HOME}/site/*/cfg/istparam.cfg | egrep -v "#|ENTER_ADDRESS_HERE" | awk '{print $7 }' | sort | uniq | awk -F ":" '{ print $2 }' | awk -F "." '{ print $1"."$2"."$3"."$4 }'`
    opc_ip=0
    GRAVALOG $ALL_SECS
    for ip_listed in $ALL_SECS
    do
        opc_ip=$((opc_ip+1))
        printf "                  \t $opc_ip  - $MESS_PORT $ip_listed \n"
        GRAVALOG "$opc_ip  - $MESS_PORT $ip_listed"
    done
}

stop_port_sec()
{
clear
PrintCab "MENU DE STOP portas de security"
echo
list_sec_options "Fechar Portas do IP"
echo
printf "                         0 - Voltar"
echo
printf "          Opcao :"

read VAR_OP

  case $VAR_OP in
        0) exit 0 ;;

        *) if [ -n "$VAR_OP" ]; then
             if [ $VAR_OP -gt `grep port.name.*security ${HOME}/site/*/cfg/istparam.cfg | egrep -v "#|ENTER_ADDRESS_HERE" | awk '{print $7 }' | sort | uniq | wc -l` ]; then
                  printf "\nOpcao Invalida !!!\n"
             else
                  ip_op=`grep port.name.*security ${HOME}/site/*/cfg/istparam.cfg | egrep -v "#|ENTER_ADDRESS_HERE" | awk '{print $7 }' | sort | uniq | awk -F ":" '{ print $2 }' | awk -F "." '{ print $1"."$2"."$3"."$4 }' | head -$VAR_OP | tail -1`
                  echo "IP Escolhido "$ip_op
                  GRAVALOG "IP Escolhido $ip_op"
                  stop_sec_ip $ip_op
                  list_sec_ip $ip_op
                 fi
                else
                  printf "\nEscolha um ip !!!\n"
        fi
             sleep 1
                 PRESS_ENTER
             VAR_OP="" ;;

  esac

}


start_port_sec()
{
clear
PrintCab "MENU DE START portas de security"
echo
list_sec_options "Abrir Portas do IP"
echo
printf "                         0 - Voltar"
echo
printf "          Opcao :"

read VAR_OP

  case $VAR_OP in
        0) exit 0 ;;

        *) if [ -n "$VAR_OP" ]; then
			if [ $VAR_OP -gt `grep port.name.*security ${HOME}/site/*/cfg/istparam.cfg | egrep -v "#|ENTER_ADDRESS_HERE" | awk '{print $7 }' | sort | uniq | wc -l` ]; then
                 printf "\nOpcao Invalida !!!\n"
            else
                 ip_op=`grep port.name.*security ${HOME}/site/*/cfg/istparam.cfg | egrep -v "#|ENTER_ADDRESS_HERE" | awk '{print $7 }' | sort | uniq | awk -F ":" '{ print $2 }' | awk -F "." '{ print $1"."$2"."$3"."$4 }' | head -$VAR_OP | tail -1`
                 echo "IP Escolhido "$ip_op
                 GRAVALOG "IP Escolhido $ip_op"
                 start_sec_ip $ip_op
                 list_sec_ip $ip_op
            fi
           else
                  printf "\nEscolha um ip !!!\n"
           fi
           sleep 1
           PRESS_ENTER
           VAR_OP="" ;;
  esac

}

if [ "$1" == "stop" ]; then
stop_port_sec
elif [ "$1" == "start" ]; then
start_port_sec
else
echo "Opcao Invalida!"
echo
echo "USO: swportasecurity.sh  [stop|start]"
echo
fi

