
BEEP()
{
  printf "\a"
}

PRESS_ENTER()
{
  printf "\nPressione <ENTER> para continuar."
  read var
}

CONFIRM()
{
	while true
	do
	  printf "$1 "
		read x
		case $x in
			s|S)    return 0 ;;
			n|N)    return 1 ;;
		esac
		BEEP
	done
}

GRAVALOG()
{
  var="${LOGNAME:0:6}"
  case $var in
      "swoper") ARQUIVO="menu_000.log" ;;
             *) ARQUIVO="_menu.log" ;;
  esac
  LOG_FILE=${HOME}/site/GEN/tmp/$ARQUIVO
  echo "`date +'%d/%m/%Y %H:%M:%S'' ('$LOGNAME')=>'`" $1 >> $LOG_FILE
}


VERIFICA_USUARIO()
{
    USUARIO="${LOGNAME:0:6}"

    if [ $AMBIENTE != "dev" ]  # Desenvolvimento
    then
    	if [ $USUARIO != "swoper" ]                                    # Em Simulação ou Produção
    	then
    		echo
    		echo "ATENCAO !!!! - Somente o usuario swoper pode utilizar o menu_000."
    		echo
    		exit 1
    	fi
    fi
}

# Função para recarga de tasks.
RECARGA()
{
	. swloadenv $SITE >/dev/null 2>&1
	mbcmd tasks |awk '{print $3 "\t\t\t" $6}'
	echo "Digite o nome da tarefa a ser recarregada:"
	read tarefa
	mbcmd tasks |grep $tarefa |awk '{print $6}' | 
	while read PRID 
	do
		echo "Recarregando tarefa:$tarefa PID $PRID . Por favor aguarde ..."
	 	kill -9 $PRID 
		sleep 1
		echo "Tarefa $tarefa recarregada!"
	done
}

ReativarPgm()
{
      echo "Digite o nome do processo: "
      read PROC_NAME
      CONFIRM "Tem certeza que quer reativar '$PROC_NAME' [s/n] ?"
      if [ ! $? -eq 0 ]
	  then
	      echo "Cancelado!"
	  else
	       echo "Reativando $PROC_NAME . Por favor aguarde ..."
	       ${HOME}/GEN/shell/kill_processes $PROC_NAME
	       echo "$PROC_NAME reativado!"
	       GRAVALOG "$PROC_NAME reativado!"
      fi
      BEEP
      PRESS_ENTER
}

PARAMETROS()
{
     echo
     echo "Digite os parametros do comando: $VAR_CMD"
     read VAR_PARAM
     echo
}

ViewLog()
{
   VAR_CMD="viewlog "
	 PARAMETROS
	 LOG_MSG="$VAR_CMD $VAR_PARAM"

   GRAVALOG "Comando = [$LOG_MSG]"

   if [ $AMBIENTE != "dev" ]    # Em Desenvolvimento
   then
	     eval $VAR_CMD $VAR_PARAM
	     PRESS_ENTER
	 else
	     echo "Opção não permitida para este servidor"
	     PRESS_ENTER
	 fi
}

TailLog()
{
   VAR_CMD="tail -f ${HOME}/site/POS/log/sys/Linuxsyslg.log"
	 LOG_MSG="$VAR_CMD"

   GRAVALOG "Comando = [$LOG_MSG]"

	 trap "return 0" 2
	 $VAR_CMD
	 PRESS_ENTER
}

vd()
{
     DEBUGDIR=$OLOGDIR/debug
     cd $DEBUGDIR
     DEBUGFILE="$1".debug
     trap "return 0" 2
     cat $DEBUGFILE | more -d
     cd - > /dev/null
}

ViewDebug()
{

     VAR_CMD="vd "
	 PARAMETROS
	 LOG_MSG="$VAR_CMD $VAR_PARAM"

     GRAVALOG "Comando = [$LOG_MSG]"

     if [ $AMBIENTE != "dev" ]  # Em Desenvolvimento
     then
	     $VAR_CMD $VAR_PARAM
	     PRESS_ENTER
	 else
	     echo "Opção não permitida para este servidor"
	     PRESS_ENTER
	 fi
}

td()
{
    DEBUGDIR=$OLOGDIR/debug
    cd $DEBUGDIR
    DEBUGFILE="$1".debug
    tail -f $DEBUGFILE
    cd - > /dev/null
}

TailDebug()
{
   VAR_CMD="td "
       PARAMETROS
       LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

	  trap "return 0" 2
	  $VAR_CMD $VAR_PARAM
	  PRESS_ENTER
}

MbCmd()
{
    VAR_CMD="mbcmd "
	  PARAMETROS
	  LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

	  $VAR_CMD $VAR_PARAM
	  PRESS_ENTER
}

ShcCmd()
{
    VAR_CMD="shccmd "
	  PARAMETROS
	  LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

	  $VAR_CMD $VAR_PARAM
	  PRESS_ENTER
}

MbPortCmd()
{
    VAR_CMD="mbportcmd "
	  PARAMETROS
	  LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

	  $VAR_CMD $VAR_PARAM
	  PRESS_ENTER
}

CmmtCmd()
{
    VAR_CMD="cmmtcmd "
	  PARAMETROS
	  LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

	  $VAR_CMD $VAR_PARAM
	  PRESS_ENTER
}

Fp()
{
    VAR_CMD="ps -ef | grep "
	  PARAMETROS
	  LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

	  eval $VAR_CMD $VAR_PARAM
	  PRESS_ENTER
}

OTraceCMDLine()
{
    VAR_CMD="otracecmd "
	  PARAMETROS
	  LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

	  $VAR_CMD $VAR_PARAM
	  PRESS_ENTER
}

DbmCmd()
{
    VAR_CMD="dbmcmd "
          PARAMETROS
          LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

          $VAR_CMD $VAR_PARAM
          PRESS_ENTER
}

SecurityCmd()
{
    VAR_CMD="securitycmd "
	  PARAMETROS
	  LOG_MSG="$VAR_CMD $VAR_PARAM"

    GRAVALOG "Comando = [$LOG_MSG]"

	  $VAR_CMD $VAR_PARAM
	  PRESS_ENTER
}

TskCmd()
{
    VAR_CMD="tskcmd -l "
    LOG_MSG="$VAR_CMD"

    GRAVALOG "Comando = [$LOG_MSG]"

	  $VAR_CMD
	  $VAR_CMD >> ${HOME}/site/POS/log/debug/mbtsk.debug
	  PRESS_ENTER
}

CountTask()
{
          printf "\n\nTask a procurar: "
	  read TASK
	  if [[ -z "$TASK"  ]]
	  then
		  printf "\nTasks em execucao no IST: %d\n\n" `mbcmd tasks | wc -l`
	  else
		  printf "\nTasks em execucao no IST: %d\n\n" `mbcmd tasks | grep $TASK | wc -l`
	  fi
	  BEEP
	  PRESS_ENTER
}



