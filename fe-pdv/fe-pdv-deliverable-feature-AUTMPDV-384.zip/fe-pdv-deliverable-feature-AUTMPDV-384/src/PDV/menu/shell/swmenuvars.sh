##!/usr/bin/ksh
#------------------------------------------------------------------------------
#  switch_vars.sh - Vari�veis Gen�ricas do Menu
#  Data    : Nov/2008
#  Autor   : RCamargo
#------------------------------------------------------------------------------
############################################################################
# Variaveis globais do Sistema SW
############################################################################
#umask g+w
APLIC=~/GEN/menu               	     # -- Topo da arvore do aplicativo
CFG=${APLIC}/cfg                     # -- Localizacao arqs. de configuracao
MENUS=${APLIC}/cfg                   # -- Localizacao arqs. de configuracao
LOG=~/tmp                            # -- Localizacao arqs. de LOG
SCRIPT=${APLIC}/shell                # -- Localizacao arqs. de Scripts
Rtn=0	                             # -- Return code subrotinas
logger=/usr/bin/logger		     # -- Comando 'logger'
ftp=/usr/bin/ftp		     # -- File transfer (ftp)
ftpcred=/usr/bin/ftp		     # -- File transfer (ftp)
