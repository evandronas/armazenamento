##!/usr/bin/ksh
#------------------------------------------------------------------------------
#  switch_menu.sh - Fun��es Gen�ricas do Menu
#  Data    : Nov/2008
#  Autor   : RCamargo
#------------------------------------------------------------------------------
#
# Funcoes contidas neste modulo :
#	MensOper()  - Envia mensagem para o operador, e aguarda <enter>
#  	DisJob()    - Mostra processos do usuario
#	MenuShow()  - Controla a exibicao do menu informado em $1
#	ShowLine()  - Mostra argumentos alinhados esq./centro/dir
#	PrintOpts() - rotina de impressao das opcoes
#	LerMenu()   - carrega menu em op,cmd,dsc
#	PrintCab()  - cabecalho do menu
#	MenuLoad()  - Carrega e mostra as opcoes contidas em um
#			      arquivo de menu informado em $1. 
#------------------------------------------------------------------------------
####################### MODIFICA��ES ########################
# Historico de alteracoes:
# Autor: Renato de Camargo
# Data : 26/Jan/2016
# Empresa: Rede
# Descri��o: Preparacao do ambiente de Captura para o CTMM - Maquinas SW437 a SW443
# ID : AM 137.268
#------------------------------------------------------------------------------------------------------------------------

#DEFINI��O DE VARIAVEIS

negon="$(tput bold)$(tput rev)"			# Liga negrito
negof=$(tput sgr 0)				# Desliga negrito
revon=$(tput rev)$(tput blink)			# negrito para mens
Sublion=$(tput smul)				# liga sublinhado
Subliof=$(tput rmul)				# desliga sublinhado
hifen='================================================================================'
MaxWidth=$(tput cols)				  # largura Maxima do terminal
MaxWidth=80           				# largura Maxima do terminal
MaxHeight=$(tput lines)				# altura Maxima do terminal
((FreeLines=$MaxHeight-9))		# linhas livres para opc do menu

#------------------------------------------------------------------------------
# @ShowLine() - Mostra linha em ate 3 pedacos (esq centro dir)
#        Parametros : $1 = Literal a mostrar do lado esquerdo
#                     $2 = Literal a mostrar no centro da tela
#                     $3 = Literal a mostrar do lado direito
#        Obs: Leva em conta a largura informada na variavel MaxWidth
#             Permite omissao de parametros - devolve posicao
#             do cursor apos imprimir linha
#------------------------------------------------------------------------------
ShowLine()
{
   typeset -i Offset CurPos ret			# variaveis locais
   CurPos=0
   if [[ "$1" == *${_SERVER_ALIAS}* && "${_SERVER_ALIAS}" != "" ]]; then
      #echo "\033[34;47m\c"
      printf "$1"                                  # 1o.parm alinh. esq.
      #echo "\033[0m\c"
   else
      printf "$1"
   fi
   (( CurPos=CurPos+${#1} ))			   # soma tamanho 1o. parm
   if [[ ${#@} -gt 1 ]]				      # tem mais parms?
   then
      (( Offset=(MaxWidth-${#2}) / 2 - CurPos )) # calc. pos. 2o. parm
      printf "%-${Offset}s${2}" " "		      # 2o. parm centralizado
      (( CurPos=CurPos+Offset+${#2} ))		   # soma tamanho 2o. parm
      if [[ ${#@} -gt 2 ]]			            # tem mais parms?
      then
        (( Offset=MaxWidth-CurPos-${#3} ))	# calc pos. 3o. parm
        printf "%-${Offset}s${3}\n" " "		# 3o. parm alinhado dir
        (( CurPos=CurPos+Offset+${#3} ))	   # soma tamanho 3o. parm
      fi
   fi
   ret=${CurPos}				            # devolve pos atual cursor
   unset Offset					         # libera variaveis locais
   return ${ret}
}
#-----------------------------------------------------------------------------
# @PrintCab() cabecalho do menu
#-----------------------------------------------------------------------------
PrintCab()
{
   typeset Offset titulo
   titulo=${1}					# recebe titulo como parametro
   clear					# limpa tela
   ShowLine "${hifen}\n"
   ShowLine "${menu}" "REDECARD" $(date "+  Data %d/%m/%y") 
   ShowLine "$(hostname) ${_SERVER_ALIAS}" "${Sistema}" $(date "+%H.%M.%S")
   printf "${LOGNAME}"
   Offset=${#titulo}
   if [[ Offset -gt 0 ]]
   then
      (( Offset=(MaxWidth-Offset) / 2 -${#LOGNAME} )) 
      printf "%-${Offset}s${negon} ${titulo} ${negof}\n" " "
						      # imprime titulo centralizado
   fi
   ShowLine "${hifen}\n"
   UltCab=5					# guarda No. ult. lin cabec
   return 0
}

#------------------------------------------------------------------------------
# @MensOper() - Envia mensagem para o operador, e aguarda <enter>
#------------------------------------------------------------------------------
MensOper()
{
   PrintCab "${dsc[${ind}]}"			# mostra opcao selec. no cabec
   tput csr $((UltCab)) $(($MaxHeight-1))	# seta area de rolagem da tela 
   tput cup  $UltCab 0				# posic.csr no topo janela
   ## printf "\n${revon}\n"			# liga negrito
   printf "\n\n"
   if [[ ${#1} -gt 0 ]]				# informou parms?
   then
      echo -- "${@}"				# imprime parms
   fi
   printf "\n${negof}"				# desliga negrito (just in case)
   printf "\nTecle <Enter> para continuar\n${hifen}"
   read						# espera <enter>
   tput sc					# save cursor position
   tput csr 0 $MaxHeight-1			# reseta area rolagem tela
   tput rc					# recall cursor position
   return 0
}

#----------------------------------------------------------------------------
# @LerMenu() - carrega menu em op,cmd,dsc
#   devolve arrays op[] cmd[] desc[] e inteiros Max e TamMax
#----------------------------------------------------------------------------
LerMenu()
   {
   typeset _cmd _desc _lixo
   typeset -l _op				# guarda opcao lowercase
   typeset -i ix=0 tam
   IFS=":"					# separador para opc/cmd menu
   # Le arq e guarda em array
   while read -r _op _cmd _desc _lixo		# Le arq e guarda em array
   do
     if [[ "${_op}" = "#" ]]; then		# despreza comentarios
        continue
     fi
     if [[ ${#_op} -eq 0 ]]			# tamanho opcao = 0 ?
     then
        if [[ ${#_desc} -ne 0 ]]		# tamanho descr. = 0 ?
        then
           titulo=${_desc}			# se sim, assume titulo do menu
        else
          if [[ "${_cmd}" = "-" ]]		# separador de opcoes no cmd
          then
            ((ix=ix+1))				# incr.index.opcoes
            dsc[${ix}]=" "			# separador de opcoes
            op[${ix}]=""
          fi
        fi
     else
        ((ix=ix+1))				# incr.index.opcoes
        op[${ix}]=${_op}			# salva codigo da opcao
        cmd[${ix}]=${_cmd}			# salva cmd a executar
						# salva descricao opcao
        dsc[${ix}]=$(printf "%2s - %s" ${op[${ix}]} ${_desc})
        TamOpc=${#dsc[${ix}]}			# calcula tam opc+descr.
        if [[ TamOpc -gt TamMax ]]
        then
           TamMax=${TamOpc}			# guarda tam. da maior opcao
        fi
     fi
   done < ${MENUS}/${menu}			# arq. de menu a carregar
   Max=${ix}					# Salva indexador ult. opcao
   if [[ Max -gt FreeLines ]]			# se nao cabe tudo em 1 tela
   then
      More=1					# liga flag indicativa
   fi

   # Se houverem mais opcoes que linhas, e o tamanho
   # das literais permite 2 colunas, fah-las-ei
   if [[ (More -eq 1) && ( $((MaxWidth-TamMax)) -gt TamMax) ]]
   then
      TwoCol=1
      (( Offset=(MaxWidth - (TamMax *2)) / 3 ))	# espacamento esq/dir
						# espacamento da col central
      (( Center=(MaxWidth - (TamMax *2)) % 3 + Offset ))
      if [[ $(( (Max+1) / 2 )) -le FreeLines ]]	# Sendo duas colunas, sera
      then					# que cabe tudo em uma tela
         More=0					# so?
      fi
   else
      (( Offset=(MaxWidth-TamMax) / 2 )) 	# calcula offset p/ centralizar
   fi
   return ${Max}				# retorna qtd total de opcoes
}

#------------------------------------------------------------------------------
# @PrintOpts() rotina de impressao das opcoes
#------------------------------------------------------------------------------
PrintOpts()
{

   typeset -i TotLin=0 				# Total de linhas impressas
   typeset -i ix=${ProxOpc} iy			# index da 1a. e 2a. colunas

   if [[ TwoCol -eq 1 ]]			# Quando tem 2 colunas, verif.
   then
     (( iy=(Max-ix+1)/2 ))			# Quantas opcoes por coluna?
     if [[ iy -lt FreeLines ]]			# se nao enche a tela,
     then					# mantem a opcao inicial,
        (( iy=iy+ix+(Max-ix+1)%2))		# somando offset da proxima op
     else 					# senao recalcula o primeiro
        (( iy=ix+${FreeLines} )) 		# indx da segunda coluna
     fi
   else
     iy=0
   fi
   Firstiy=${iy}				# salva indx prim opc 2a. col
   tput cup ${UltCab} 0				# pos cursor inicio area opcoes
   while [[ $(( TotLin=TotLin+1 )) -le FreeLines ]]
   do
      tput el					# erase line
      # qdo acabou de mostrar opcoes, continua descendo p/ limpar tela
      if [[ (ix -gt Max) || ( (TwoCol -ne 0) && (ix -ge Firstiy ) ) ]]
      then
         # break
         tput cud 1				# cursor down n lines
         continue
      fi
      if [[ Offset -gt 0 ]]; then
         tput cuf ${Offset}			# avanca cursor p/ centrar opc
      fi
      printf ${dsc[${ix}]}			# mostra opcao alinhada
      if [[ (TwoCol -ne 0) && ($iy -le $Max) ]]
						# tem 2a col, e nao estourou max
      then
         tput cuf $((Center+TamMax-${#dsc[${ix}]}))	# pula v�o central
         printf "${dsc[${iy}]}"
         (( iy=iy+1 ))				# incrementa idx 2a. col
      fi
      echo ""   					# pula lin que printf nao pulou
      (( ix=ix+1 ))				# incrementa idx 1a col
   done
   
   ### printf "${hifen}\n"			# fecha a area de opcoes com ===

   if [[ (ix -gt Max)||(iy -gt Max) ]]		# se mostrei ult.opcao do menu
   then	
     ProxOpc=1					# a prox. a mostrar eh a 1a.
   else
     if [[ TwoCol -eq 1 ]]			# se tem 2 colunas
     then
        ProxOpc=${iy}				# prox opcao=ultima da 2a col
     else					# senao
        ProxOpc=${ix}				# prox opcao=ultima da 1a.col
     fi
   fi
   return ${ProxOpc}
}

#------------------------------------------------------------------------------
## @MenuShow() - Controla a exibicao do menu informado em $1
#------------------------------------------------------------------------------
typeset opcoes
typeset -i level
MenuShow()
{
   typeset op cmd up dsc			            # variaveis array
   typeset -l opcao				               # guarda opcao com lowercase
   typeset menu=${1}				            # string left justified
   typeset -i TamMax=0 ind=0 Max UltCab		# inteiras
   typeset titulo				                  # titulo do menu
   typeset -i FimMenu=0 Refresh=0 advance=0 	# mais inteiras
   typeset -i TwoCol=0 Offset Center err=0	# ainda mais inteiras
   typeset -i More=0 ProxOpc OpcAnt

   if [[ ${#} -eq 2 ]]; then
      opcoes=${2}
   fi

   ((level=level+1))
   if ! [[ -r ${MENUS}/${menu} ]]; then
      MensOper "Erro na leitura do arquivo de menu ${menu}"
      return
   fi

   LerMenu ${menu}				# carrega menu em op,cmd,dsc
   Max=${?}					      # salva qtd opcoes
   ProxOpc=1					   # inicializa prox opc a mostrar
   OpcAnt=${ProxOpc}				# Salva 1a. opcao da tela
   while [[ FimMenu -eq 0 ]]	# enquanto nao pedir p/ sair
   do
      if [[ ${#opcoes} = 0 ]]; then	      # so mostra menu se nao pre opc
         PrintCab ${titulo}			         # Mostra cabecalho do menu
         ProxOpc=${OpcAnt}				         # restaura 1a. opcao da tela
         PrintOpts					            # Mostra opcoes do menu
         tput cup $((UltCab+FreeLines)) 0		# cursor positionning
         printf "${hifen}\n"			# fecha a area de opcoes com ===
         ## set up scrolling region to last 2 lines to avoid side effects
         tput csr $((UltCab+FreeLines+1)) $((MaxHeight-1))
         advance=0
      else
         advance=1
      fi
      Refresh=0

      # loop pedindo opcao de menu
      while [[ ${Refresh} -eq 0 ]]; do		# ateh que seja pedido refresh
         if [[ ${advance} = 0 ]]; then		# nao existem opcoes em avanco?
            tput cup $((UltCab+FreeLines+1)) 0	# cursor positionning
            tput el				               # erase to eof
            if [[ More -eq 0 ]]; then 		      # mostra prompt de acordo
               printf "Informe sua opcao "
            else
               printf "Informe sua opcao (Enter p/ paginar) "
            fi
            read opcao
            opcoes=${opcao}			         # salva p/ implementar multi-ops
            tput el				               # apaga linha de mensagem
         fi
         opcao=${opcoes%%\.*}			         # parse de opcoes (sep=.)
         if [[ ${opcoes} = ${opcao} ]]; then	# sindrome do ultimo reg.
            opcoes=""
         else
            opcoes=${opcoes#$opcao.}	        # exclui do resto
	      fi

         if [[ (${#opcao} -eq 0) ]]; then		# teclou enter no vazio ?
            if [[ More -ne 0 ]]; then		# existem mais opcoes?
               OpcAnt=${ProxOpc}			# Salva 1a.opc da prox. tela
               PrintOpts				# mostra proximas opcoes
            fi
            continue				# volta ao prompt opcao
         fi
         tput sc					# save cursor position
         tput csr 0 $((MaxHeight-1))		# return scrol reg to full
         tput rc					# recall cursor position

         if [[ ${opcao} = [Qq] ]]; then
            if [[ level -gt 1 ]]; then		# Q/q vai para menu principal
	            ((level=level-1))
               return 255				# sai fora de todos os niveis
            else
               continue
            fi
         fi
         _op=$(printf "%u" ${opcao} 2>/dev/null) # tenta converter para numerico
         if [[ $? = 0 ]]; then			# se nao deu erro na conversao
            opcao=$_op				# recebe valor convertido
         fi
         ind=0
         while [[ $((ind=ind+1)) -le Max ]]	# Verifica se opcao valida
         do
            if [[ ${opcao} = ${op[${ind}]} ]]	# achei o indice da opcao?
            then 
               if [[ ${cmd[${ind}]} = [Ee][Xx][Ii][Tt] ]]	# opcao eh de saida
               then
                  FimMenu=1				# liga flag p/ sair do while
               else
                  echo "Opcao: ${cmd[${ind}]}"
                  # nao posso deixar IFS=: por causa da sintaxe do pwdexec
                  IFS=" "
                  eval  ${cmd[${ind}]}		# executa cmd assoc. opcao
                  retCode=$?
                  IFS=":"
                  if [[ retCode -eq 255 ]]		# encerra geral?
                  then
                     if [[ level -gt 1 ]]; then	# para de encerrar no principal
                        ((level=level-1))
                        return 255			# Cascateia quit request
                     fi
	               else
                     if [[ retCode -ne 0 ]]		# problema na execucao
                     then
                        MensOper "Erro ${retCode} ao executar ${cmd[${ind}]}"
                     fi
	               fi
               fi
               Refresh=1				# depois de executar cmd,
               break				# tem que redesenhar tela
            fi
        done

        if [[ (ind -gt Max) ]]			# nao achei opcao valida
        then
            if [[ ${advance} = 1 ]]; then
                     PrintCab ${titulo}			# Mostra cabecalho do menu
                     ProxOpc=${OpcAnt}			# restaura 1a. opcao da tela
                     PrintOpts				# Mostra opcoes do menu
                     tput cup $((UltCab+FreeLines)) 0	# cursor positionning
                     printf "${hifen}\n"		# fecha a area de opcoes com ===
                     ## set up scrolling region to last 2 lines to avoid side effects
                     tput csr $((UltCab+FreeLines+1)) $((MaxHeight-1))
                     advance=0
                     tput cup $((UltCab+FreeLines+2)) 0	# cursor positionning
                     tput el				# erase to eof
            fi
            printf "\a${revon}Opcao (${opcao}) informada invalida${negof}"
            ProxIdx=${IdxAnt}
        fi
     done
   done
   ((level=level-1))
   return
}
#eof

