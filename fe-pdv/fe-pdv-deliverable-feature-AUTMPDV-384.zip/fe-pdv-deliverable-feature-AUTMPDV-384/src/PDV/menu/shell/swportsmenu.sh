##!/bin/ksh
# 
#####################################################################################
# 
# Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
# eFunds Canada Corporation is an authorized user.
# 
# Fonte....: swportsmenu.sh
# Author...: Renato Saito
# Descricao: Carregador de funções para o menu_000, opção de abertura/fechamento \ 
#            de portas.
#
# Versão...: 0.3
# 
####################################################################################
# © Copyright [2013] REDE
####################### MODIFICACOES ########################
# Autor    : Fabio Mazzer
# Data     : 04/12/2013
# Empresa  : Rede
# Descricao: Incluindo parametro para FEs POS e PDV para o SW 75
#############################################################
# Descricao: Inclusao FEs CRTO e DBTO
# Autor    : Renato de Camargo
# Data     : 29/11/2016
# Empresa  : Rede
#############################################################
# Autor    : Diego Lima
# Data     : 14/12/2017
# Empresa  : Rede
# Descricao: Correção do menu de abertura e fechamento de todas as portas
#############################################################
# Autor    : Mauro Thiago da Silva
# Data     : 27/07/2019
# Empresa  : Rede
# Descricao: Jira RTA-141 | Correção para não fechar as portas dual_sync via Menu Operador
#############################################################
	
#Seleciona ambiente de trabalho por Front End.
SELECIONA_AMBIENTE()
{
	echo "FRONT END: ($FE)"

	case ${FE^^} in
	     crt|CRT)
		. swloadenv CRT >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/CRT/cfg/istparam.cfg
		;;
	     crtm|CRTM)
		. swloadenv CRTM >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/CRTM/cfg/istparam.cfg
		;;
	     dbt|DBT)
		. swloadenv DBT >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/DBT/cfg/istparam.cfg
		;;
	     dbtm|DBTM)
		. swloadenv DBTM >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/DBTM/cfg/istparam.cfg
		;;
	     web|WEB)
		. swloadenv WEB >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/WEB/cfg/istparam.cfg
		;;
		 pdv|PDV)
		. swloadenv PDV >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/PDV/cfg/istparam.cfg
		;;
	     pos|POS)
		. swloadenv POS >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/POS/cfg/istparam.cfg
		;;
	     dbto|DBTO)
		. swloadenv DBTO >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/DBTO/cfg/istparam.cfg
		;;
		crto|CRTO)
		. swloadenv CRTO >/dev/null 2>&1
		CONFIGFILE=${HOME}/site/CRTO/cfg/istparam.cfg
		;;
	     *)
		echo "Front-End ${fe} Inválido";
		PRESS_ENTER
		return 1;;
	esac

	export SW_ROOT=${HOME}
	export DEFAULT_PREFIX=$SW_ROOT/$FE
}

# Retornos : Não há
ABRE_TODAS_AS_PORTAS() 
{	
	#lista todas as portas 'accept-call' do arquivo istparam.cfg
        strPortas=$(grep ^port.name ${CONFIGFILE} | awk '{if($6=="accept-call") print $2}' | tr '\n' ' ')
	declare -A ARR_LISTA_PORTAS=$strPortas
	
	echo "-----------------------------------------------------------------------------"
	echo "  ABERTURA DE TODAS AS PORTAS DO FRONT END ($FE)."
	echo "-----------------------------------------------------------------------------"
    
    #Ativa todas as portas listadas com 'accept-call'
	for strPorta in ${ARR_LISTA_PORTAS[@]}
	do
		strStatusAnterior=`mbportcmd list ${strPorta} | awk '{FS="\n";print $1}' | tr '\n' ' ' | awk '{print $2 " " $3}' | awk '{if($1=="active" || $1=="attempting") print $1 " " $2; else print $1;}'`
		mbportcmd start $strPorta
		rm -f $OTMPDIR/Port_$strPorta.lock
		strStatusAtual=`mbportcmd list ${strPorta} | awk '{FS="\n";print $1}' | tr '\n' ' ' | awk '{print $2 " " $3}' | awk '{if($1=="active" || $1=="attempting") print $1 " " $2; else print $1;}'`
		echo " Abrindo ${strPorta} => anterior (${strStatusAnterior}) - atual (${strStatusAtual})"
                GRAVALOG " Abrindo ${strPorta} => anterior (${strStatusAnterior}) - atual (${strStatusAtual})" 
	done

	echo "-----------------------------------------------------------------------------"
}

# Descrição : Fechamento de todas as portas do Front End.
# Parâmetros : Não há
# Retornos : Não há
FECHA_TODAS_AS_PORTAS() 
{
	#lista todas as portas 'accept-call' do arquivo istparam.cfg
	strPortas=$(grep ^port.name ${CONFIGFILE} | awk '{if($6=="accept-call" && $2!~/dual_sync_in|dual_sync_out/) print $2}' | tr '\n' ' ')
	declare -A ARR_LISTA_PORTAS=$strPortas

	echo "-----------------------------------------------------------------------------"
	echo "  FECHAMENTO DE TODAS AS PORTAS DO FRONT END ($FE)."
	echo "-----------------------------------------------------------------------------"
		
	#Desativa todas as portas listadas com 'accept-call'	
	for strPorta in ${ARR_LISTA_PORTAS[@]}
	do
		strStatusAnterior=`mbportcmd list ${strPorta} | awk '{FS="\n";print $1}' | tr '\n' ' ' | awk '{print $2 " " $3}' | awk '{if($1=="active" || $1=="attempting") print $1 " " $2; else print $1;}'`
		mbportcmd stop $strPorta
		strStatusAtual=`mbportcmd list ${strPorta} | awk '{FS="\n";print $1}' | tr '\n' ' ' | awk '{print $2 " " $3}' | awk '{if($1=="active" || $1=="attempting") print $1 " " $2; else print $1;}'`
		echo " Fechando ${strPorta} => anterior (${strStatusAnterior}) - atual (${strStatusAtual})"
                GRAVALOG " Fechando ${strPorta} => anterior (${strStatusAnterior}) - atual (${strStatusAtual})" 
	done

	echo "-----------------------------------------------------------------------------"

}

#Calcula intervalo para pause entre ativacao de portas
CALCULA_INTERVALO_DA_PROXIMA_ATIVACAO()
{
 
	echo "=> TPS anterior....: ($TPS_ANTERIOR)"

	TPS=$(getTPS)

	echo "=> TPS.............: ($TPS)"

	export TPS=$(echo $TPS | awk '{print $2}') 

	((DIFERENCA_TPS=TPS-TPS_ANTERIOR))
	INTERVALO=`echo "$DIFERENCA_TPS * $RAZAO_TPS" |bc`

	#echo "Intervalo: ($INTERVALO)"

	if [ INTERVALO -ge INTERVALO_MINIMO ]
	then
		export INTERVALO_MAIOR=$INTERVALO
	else
		export INTERVALO_MAIOR=$INTERVALO_MINIMO
	fi

	echo "=> Intervalo para a proxima ativação: ($INTERVALO_MAIOR)"

	export TPS_ANTERIOR=$TPS
}
