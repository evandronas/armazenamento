#!/usr/bin/bash
# Load Functions
#set -x
. ~/GEN/shell/swvars.sh        # Carrega variaveis globais para o Sistema SW
. ~/GEN/shell/swfunc.sh        # Carrega funcoes genericas do SW
. ~/GEN/menu/shell/swshfunc.sh   # Carrega funcoes genericas do menu
SELECT_FE()
{
printf "Informe o Front-end HST/CRTM/CRT/CRTO/DBT/DBTM/DBTO/WEB/PDV/POS/TODOS: "
read fe
fe=$(echo ${fe} | tr [:upper:] [:lower:])
    case ${fe} in
        hst|crt|crtm|dbt|dbtm|dbto|crto|web|pdv|pos)
            FRONT_END_LIST=${fe}
            FRONT_END=${fe}
            return 0 ;;
        todos)
            FRONT_END_LIST="hst crt crtm crto dbt dbtm dbto web pdv pos"
            FRONT_END=TODOS
            return 0 ;;
        *)
            printf "Front-end ${fe} Invalido\n";
            PRESS_ENTER
            return 1;;
    esac
    return 1;
}

reload_acq()
{
		if [ "${1}" == "acqsrv_crt" ] || [ "${1}" == "acqsrv_dbt" ] || [ "${1}" == "acqsrv_vch" ] || [ "${1}" == "acqsrv_pl" ] || [ "${1}" == "acqsrv_adm" ]; then
			if ! SELECT_FE; then
				return
			fi

			for FRONT_END in ${FRONT_END_LIST}; do
				. swloadenv ${FRONT_END} > /dev/null 2>&1
				for LINE in `mbcmd tasks | grep "${1}" | awk -vSITE=${FRONT_END} 'BEGIN {FS="]|:|Type"} { proc=$2; pid=$4; gsub(" ", "",proc); gsub(" ", "",pid); printf("%6s;%s;%s\n",SITE,proc,pid ); }'`; do
						 task=`echo $LINE|awk 'BEGIN{FS=";"} {print $2}'`
						 pid=`echo $LINE|awk 'BEGIN{FS=";"} {print $3}'`
						 printf "Reloading task => ${task} [$pid]...Aguarde!!!\n";
						 GRAVALOG "Reloading task => ${task} [$pid]"
						 kill -9 $pid
						 sleep 5
				done

			 done
			GRAVALOG "Executou Reload ${1}"
			PRESS_ENTER
	fi
}
