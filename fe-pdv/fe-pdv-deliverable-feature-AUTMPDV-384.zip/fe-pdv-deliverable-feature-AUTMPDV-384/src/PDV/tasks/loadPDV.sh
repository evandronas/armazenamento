#!/bin/ksh

unset -f unalias
unalias -a

#Rotina "main()" do script
loadTSK.sh PDV
