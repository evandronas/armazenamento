#!/bin/ksh
#############################################################
# Nome : SentinelPDV.sh
# Descricao: Ativa a monitoracao do Sentinel.sh - SCSW-318
# Autor : Fernando Jacinto
# Data : 19/03/2020
# Empresa : REDE
#############################################################

unset -f unalias
unalias -a

#Rotina "main()" do script
/home/SW/GEN/shell/Sentinel.sh PDV