#!/bin/ksh
tSleep=60
while true
do 
strHora=`echo $(date +"%Y/%m/%d %T")`
tail -10000 /home/SW/site/POS/log/sys/Linuxsyslg.log | egrep "DECRIPTOGRAFIA.RESULT" | wc -l | awk -v strHora="$strHora" '{ 
if ($1 > 10) 
	print "Erro HSM POS 7.5 - DECRIPTOGRAFIA.RESULT - ver AIX" >> "/tmp/alarme_gen.txt"
else
	print strHora " - qtde erros DECRIPTOGRAFIA.RESULT " $1 >> "/home/SW/site/POS/log/sys/mon_hsm.log"
}'
sleep $tSleep
done


