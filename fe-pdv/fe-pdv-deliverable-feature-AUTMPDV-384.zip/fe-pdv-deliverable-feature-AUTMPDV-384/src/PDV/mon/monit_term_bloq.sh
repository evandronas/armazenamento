#!/usr/bin/ksh

# � Copyright 2019 Rede S.A.
#############################################################
# Nome:      monit_term_bloq.sh
# Descricao: Gera bloqueio temporario por fraude
# Autor:     Guilherme Sanches
# Data:      30/10/2018
# Empresa:   Rede
# ID:        AM248.335
#############################################################
# Autor:     Danielle Cristina
# Data:      05/06/2019
# Descricao: Acerto do parametro de bloqueio
#############################################################

########################MODIFICACOES########################
# Autor:     Ligellton Martins
# Data:      16/07/2019
# Empresa:   Rede
# ID:        AM250.377
# Descricao: O bloqueio de terminais agora consiste em arquivos
# gerados no diret�rio "/tmp/path_block_term/" e n�o mais por
# processos em looping
#############################################################

# ---------------------------------------------------------
# Garantir que nenhum comando tenha sido substituido
# por uma funcao do mesmo nome
# ---------------------------------------------------------
unset -f unalias
unalias -a

# ---------------------------------------------------------
# | Variaveis
# ---------------------------------------------------------
#export HOME=/home/SW

STR_FILE_SUSP="/home/SW/sw_web/suspeitos.txt"
STR_LOG="${HOME}/site/POS/log/sys/bloqueiolog.log"
STR_BTC="${HOME}/GEN/mon/bloq_term_susp.sh"
STR_ISTPARAM_FILE="${HOME}/site/POS/cfg/istparam.cfg"
STR_CONFIG_FILE=`grep ^bloqueio_terminais.activation_file ${STR_ISTPARAM_FILE} | awk '{print $2}'`
PATH_ARQ_BLOCK="/tmp/path_block_term/"

nohup $STR_BTC "START_LOOPING_BLOCK" >nohup.out 2>&1 &

while (true) do

   STR_FILE_LOG=$STR_LOG

   #Tenta obter codigos de terminais com operacoes suspeitas que foram incluidos no arquivo "/home/SW/sw_web/suspeitos.txt"
   for strTerm in `awk -F";" '$0 !~ /TOTAL/ && !/TSUSP/ && !/DATAM/ && !/PV/ {print $1}' $STR_FILE_SUSP`
   do
      echo `date +"%T - "`"monit_term_bloq.sh - Verificando Bloqueio para [$strTerm] " >> $STR_FILE_LOG

          INT_QTD_PROC=0
          strTerm_tmp=$strTerm.`date +'%Y%m%d%H%M'`

          for bloq_files in `ls -tr $PATH_ARQ_BLOCK | grep $strTerm | awk '{print $NF}'`
          do
              if [ $bloq_files > $strTerm_tmp ]; then
                      INT_QTD_PROC=1
                          break
                  fi
          done

      #Se ainda nao existe o processo de bloqueio, starta um
      if [ $INT_QTD_PROC -gt 0 ]; then
         echo `date +"%T - "`"monit_term_bloq.sh - Bloqueio ja solicitado" >> $STR_FILE_LOG
      else
         echo `date +"%T - "`"monit_term_bloq.sh - Solicitando bloqueio para $strTerm " >> $STR_FILE_LOG

         QTD=`grep ^BLQTERM ${STR_CONFIG_FILE} | wc -l`

         if [ ${QTD} -eq 1 ]; then
                        nohup $STR_BTC $strTerm >nohup.out 2>&1 &
                echo `date +"%T - "`"monit_term_bloq.sh - Aberto bloqueio para o $strTerm " >> $STR_FILE_LOG
         fi
      fi

   done

   #verifica log a cada 60 segundos
   sleep 60

done
