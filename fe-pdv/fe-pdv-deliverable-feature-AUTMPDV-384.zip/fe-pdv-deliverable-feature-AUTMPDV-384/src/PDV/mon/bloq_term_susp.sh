#!/usr/bin/ksh

# � Copyright 2019 Rede S.A.
#############################################################
# Nome:      bloq_term_susp.sh
# Descricao: Gera bloqueio temporario por fraude
# Autor:     Guilherme Sanches
# Data:      30/10/2018
# Empresa:   Rede
# ID:        AM248.335
#############################################################
# Autor:     Danielle Cristina
# Data:      05/06/2019
# Descricao: Acerto no nome do shell
#############################################################

########################MODIFICACOES########################
# Autor:     Ligellton Martins
# Data:      16/07/2019
# Empresa:   Rede
# ID:        AM250.377
# Descricao: O bloqueio de terminais agora consiste em arquivos
# gerados no diret�rio "/tmp/path_block_term/" e n�o mais por
# processos em looping
#############################################################
# Autor:     Mauro Thiago da Silva
# Data:      12/11/2020
# Descricao: Ajustado par 24 horas
#############################################################

#---------------------------------------------------------
#| Garantir que nenhum comando tenha sido substituido
#| por uma funcao do mesmo nome
#---------------------------------------------------------
unset -f unalias
unalias -a


. ~/GEN/shell/swvars.sh     # Carrega variaveis globais para o Sistema SW
. ~/GEN/shell/swfunc.sh     # Carrega funcoes genericas do SW


export STR_POSTGRES_HOME=/usr/bin/psql

#---------------------------------------------------------
#| Variaveis de conexao
#---------------------------------------------------------

USER=`get_db_user       /online/postgresql/POS/${AZ}`
HOST=`get_db_host       /online/postgresql/POS/${AZ}`
DBNAME=`get_db_name    /online/postgresql/POS/${AZ}`
export PGPASSWORD=`get_db_password   /online/postgresql/POS/${AZ}`

#---------------------------------------------------------
#| Variaveis
#---------------------------------------------------------

STR_CONNECT=$STR_POSTGRES_HOME" --host="$HOST" --username="$USER" --dbname="$DBNAME
STR_PROC_NAME="bloq_term_susp.sh"
STR_LOG="${HOME}/site/POS/log/sys/bloqueiolog.log"
STR_LOG_FILE=$STR_LOG
STR_PATH_BLOCK="/tmp/path_block_term/"
STR_ISTPARAM_FILE="${HOME}/site/POS/cfg/istparam.cfg"
STR_TIME_BLOCK=`grep ^bloqueio_terminais.time_block ${STR_ISTPARAM_FILE} | awk '{print $2}'`


if [ "$STR_TIME_BLOCK" = '' ]; then
        STR_TIME_BLOCK=24
fi


check_term()
{
    INT_TERM=$1

    strIsqlLog=`$STR_CONNECT  <<EOF
    select IND_TERM_BLQD from TBSW0042 where COD_TERM = '$INT_TERM';
    \q 
    EOF`
    strIsqlLog=`echo $strIsqlLog | sed -e 's/^[[:space:]]*//'`
    return "$strIsqlLog"
}

block_term()
{
    INT_TERM=$1

#Verifica se o terminal ja esta bloqueado

    strIsqlLog=`$STR_CONNECT  <<EOF
    select IND_TERM_BLQD from TBSW0042 where COD_TERM = '$INT_TERM';
    \q
    EOF`

    strIsqlLog=`echo $strIsqlLog | sed -e 's/^[[:space:]]*//'`


    echo `date +"%T - "`"bloq_term_susp.sh - $strIsqlLog" >> $STR_LOG_FILE

    if [[ "$strIsqlLog2" = "S" ]];then
       echo `date +"%T - "`"bloq_term_susp.sh - Terminal $INT_TERM jah encontra-se bloqueado" >> $STR_LOG_FILE
       exit;
    fi

    strIsqlLog=`$STR_CONNECT  <<EOF
    UPDATE TBSW0042 SET IND_TERM_BLQD = 'S' where COD_TERM = '$INT_TERM';
    \q
    EOF`

    strIsqlLog=`echo $strIsqlLog | sed -e 's/^[[:space:]]*//'`

    echo `date +"%T - "`"bloq_term_susp.sh - $strIsqlLog" >> $STR_LOG_FILE


    #Verifica se o terminal ja esta bloqueado
    strIsqlLog=`$STR_CONNECT  <<EOF
    select IND_TERM_BLQD from TBSW0042 where COD_TERM = '$INT_TERM';
    \q
    EOF`

    strIsqlLog=`echo $strIsqlLog | sed -e 's/^[[:space:]]*//'`

    TIME_BLOCK=`date +"%Y%m%d%H%M"`
    INT_TERM_FULL=$INT_TERM.$TIME_BLOCK

    echo `date +"%T - "`"bloq_term_susp.sh - $strIsqlLog2" >> $STR_LOG_FILE
    echo `date +"%T - "`"bloq_term_susp.sh - Aguarda o desbloqueio $INT_TERM_FULL" >> $STR_LOG_FILE

    #Deixa o terminal bloqueado por 8 horas
    #sleep 28800 #8 h

    FILE_TMP=$STR_PATH_BLOCK$INT_TERM_FULL
echo `date +"%T - "`"bloq_term_susp.sh - FILE_TMP = [$FILE_TMP]" >> $STR_LOG_FILE
    touch $FILE_TMP
    chmod 666 $FILE_TMP
}

unblock_term()
{
    INT_TERM=$1

    echo `date +"%T - "`"bloq_term_susp.sh - Desbloqueando $INT_TERM" >> $STR_LOG_FILE

    #Verifica se o terminal ja esta bloqueado
    strIsqlLog=`$STR_CONNECT  <<EOF
    select IND_TERM_BLQD from TBSW0042 where COD_TERM = '$INT_TERM';
    \q
    EOF`

    strIsqlLog=`echo $strIsqlLog | sed -e 's/^[[:space:]]*//'`

    echo `date +"%T - "`"bloq_term_susp.sh - $strIsqlLog" >> $STR_LOG_FILE

    #Efetua o desbloqueio do terminal
    strIsqlLog=`$STR_CONNECT  <<EOF
    UPDATE TBSW0042 SET IND_TERM_BLQD = 'N' where COD_TERM = '$INT_TERM';
    \q
    EOF`

    strIsqlLog=`echo $strIsqlLog | sed -e 's/^[[:space:]]*//'`

    echo `date +"%T - "`"bloq_term_susp.sh - $strIsqlLog" >> $STR_LOG_FILE

    #Verifica se o terminal ja esta bloqueado
    strIsqlLog=`$STR_CONNECT  <<EOF
    select IND_TERM_BLQD from TBSW0042 where COD_TERM = '$INT_TERM';
    \q
    EOF`

    strIsqlLog=`echo $strIsqlLog | sed -e 's/^[[:space:]]*//'`

    echo `date +"%T - "`"bloq_term_susp.sh - $strIsqlLog2" >> $STR_LOG_FILE
    echo `date +"%T - "`"bloq_term_susp.sh - Fim para o terminal $INT_TERM" >> $STR_LOG_FILE
}

INT_TERM=$1

if [ -z "$INT_TERM" ]; then
    echo `date +"%T - "`"bloq_term_susp.sh - Parametro invalido $INT_TERM" >> $STR_LOG_FILE
    exit;
fi

intLen=`expr length $INT_TERM`

if [ "$INT_TERM" != "START_LOOPING_BLOCK" ] && [ $intLen -ne 8 ]; then
    echo `date +"%T - "`"bloq_term_susp.sh - Tamanho terminal invalido $INT_TERM" >> $STR_LOG_FILE
    exit;
elif [ $intLen -eq 8 ]; then
    block_term $INT_TERM
    exit;
fi

qtePID=0
qtePID=`ps -ef | egrep "$STR_PROC_NAME" | egrep "START_LOOPING_BLOCK" | egrep -v "grep|tail" | wc -l | awk '{ print $1 }'`

#verifica se j� existe shell no ar
if [ "$qtePID" -gt 1 ]; then
        echo `date +"%T - "`"Existe um processo em execucao. Saindo! [$qtePID]" >> $STR_LOG_FILE
        exit;
fi

if [ ! -d "$STR_PATH_BLOCK" ]; then
        echo `date +"%T - "`"Cria diretorio de controle $STR_PATH_BLOCK" >> $STR_LOG_FILE
        mkdir $STR_PATH_BLOCK
        chmod 777 $STR_PATH_BLOCK
fi

while true
do
        TIME_NOW=`date +'%Y%m%d%H%M'`

        for arq_bloq in `ls -tr $STR_PATH_BLOCK | egrep "\." | awk '{print $NF}'`
        do
                if [ `expr length $arq_bloq` -ne 21 ]; then
                        echo `date +"%T - "`"bloq_term_susp.sh - Arquivo invalido $arq_bloq removido" >> $STR_LOG_FILE
                        rm -f $STR_PATH_BLOCK$arq_bloq 2>/dev/null
                        continue;
                fi

                INT_TERM=`echo $arq_bloq | awk -F. '{print $1}'`
                TIME_TERM=`echo $arq_bloq | awk -F. '{print $2}'`

                if [ `expr length $INT_TERM` -ne 8 ] || [ `expr length $TIME_TERM` -ne 12 ] ; then
                        echo `date +"%T - "`"bloq_term_susp.sh - Arquivo invalido $arq_bloq removido" >> $STR_LOG_FILE
                        rm -f $STR_PATH_BLOCK$arq_bloq 2>/dev/null
                        continue;
               fi

                if [ $TIME_NOW -gt $TIME_TERM ]; then
                        unblock_term $INT_TERM
                        rm -f $STR_PATH_BLOCK$arq_bloq 2>/dev/null
                        echo `date +"%T - "`"bloq_term_susp.sh - Bloqueio $arq_bloq removido" >> $STR_LOG_FILE
                fi
        done

        sleep 20
done
     
