#####################################################################
#!/bin/ksh                                                          #
#                                                                   #
# Fonte: MonSecurity.sh                                             #
# Autor: William                                                    #
# Descricao: Este shell foi criado para auxiliar na monitoracao     #
#            das portas Security.                                   #
#                FE = POS|PDV    									#
# USO do SCRIPT :   MonSecurity.sh <FE>                            #
#####################################################################

# Somente comeca a trabalhar depois de um minuto do start da task pelo FE
sleep 60

if [ $# -eq 0 ]
then
    echo "<ERRO>: Utilizacao: MonSecurity.sh <FE>"
    echo "<ERRO>: Onde <FE> precisa ser um Front-end valido : POS ou PDV"
    exit 1

elif [  "$1" = "POS" -o "$1" = "PDV" ]
then
    FE="$1"
else
    echo "<ERRO>: $1 nao eh um front-end valido"
    echo "<ERRO>: Parametro Front-End precisa ter um valor entre  : POS ou PDV"
    exit 1
fi

LOGSHELL="/home/SW/site/$1/log/debug/MonSecurity.debug"

. swloadenv ${FE}

while true
do
        DATE=`date '+%Y-%m-%d %H:%M:%S'`
        STATUSCONECTION=`mbportcmd list security* | sed '/^$/d' | sed 'N;s/\n//' | sed 's/\[//g;s/\]/ /g' | sed "s,:,.,g" | awk '{ if ( ($8=="STOPPED" || $8=="connected" || $8=="attempting") ) print $3"."$8 }' | awk -F"." '{print $1"-"$2}'`;

        echo "$DATE - FE-${FE} - Validando Portas Security" >> ${LOGSHELL}
        for linha in $STATUSCONECTION
        do
                porta=`echo $linha | awk -v variavel1=$linha '{ split( variavel1,a,"-" ); print a[1] }'`
                STATUSPORTA=`echo $linha | awk -v variavel2=$linha '{ split( variavel2,b,"-" ); print b[2] }'`

                echo "$DATE - FE-${FE} - Porta[${porta}] [${STATUSPORTA}]" >> ${LOGSHELL}

                if [[ ${STATUSPORTA} == "attempting" ]]; then
                        QTD=0
                        for CONT in 1 2 3
                        do
                                sleep 1
                                DATE=`date '+%Y-%m-%d %H:%M:%S'`
                                echo "$DATE - FE-${FE} - Iniciando reteste da porta [$porta]" >> ${LOGSHELL}
                                statusRestePorta=`mbportcmd list ${porta} | sed '/^$/d' | sed 'N;s/\n//' | sed 's/\[//g;s/\]/ /g' | sed "s,:,.,g" | awk '{ if ( ($8=="STOPPED" || $8=="connected" || $8=="attempting") ) print $3"."$8 }' | awk -F"." '{print $2}'`
                                if [[ ${statusRestePorta} == "attempting" ]]; then
                                        QTD=$((QTD+1))
                                        echo "$DATE - FE-${FE} - Reteste #${QTD} da porta [$porta]" >> ${LOGSHELL}
                                fi
                        done

                        #
                        # Mais de 3 segundos com a porta attemping, efetua o restart
                        #
                        if [[ ${QTD} -eq 3 ]]; then
                                syslgsend "Stop/Start da porta ${porta}"
                                echo "$DATE - FE-${FE} - Efetuando STOP/START da porta $porta" >> ${LOGSHELL}
                                echo "$DATE - FE-${FE} - mbportcmd stop $porta" >> ${LOGSHELL}
                                mbportcmd stop $porta
                                echo "$DATE - FrontEnd ${FE} - mbportcmd start $porta" >> ${LOGSHELL}
                                sleep 1
                                mbportcmd start $porta
                                statusRestePorta=`mbportcmd list ${porta} | sed '/^$/d' | sed 'N;s/\n//' | sed 's/\[//g;s/\]/ /g' | sed "s,:,.,g" | awk '{ if ( ($8=="STOPPED" || $8=="connected" || $8=="attempting") ) print $3"."$8 }' | awk -F"." '{print $2}'`
                                echo "$DATE - FE-${FE} - Apos restart da $porta status => $statusRestePorta" >> ${LOGSHELL}
                                syslgsend "Apos restart da porta ${porta} => $statusRestePorta"
                        fi
                fi
        done
        sleep 10
done
