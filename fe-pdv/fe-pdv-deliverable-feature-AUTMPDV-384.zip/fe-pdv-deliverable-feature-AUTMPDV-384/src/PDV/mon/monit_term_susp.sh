#!/usr/bin/ksh

# Copyright 2019 Rede S.A.
#############################################################
# Nome:      monit_term_susp.sh
# Descricao: Gera bloqueio temporario por fraude
# Autor:     Guilherme Sanches
# Data:      30/10/2018
# Empresa:   Rede
#############################################################
# Autor:     Danielle Cristina
# Data:      30/10/2018
# Descricao: Acerto no nome do shell
#############################################################
# Autor:     Mauro Thiago da Silva
# Data:      12/11/2020
# Descricao: Inclusao para ContactLess
#############################################################

#---------------------------------------------------------
#| Garantir que nenhum comando tenha sido substituido
#| por uma funcao do mesmo nome
#---------------------------------------------------------
unset -f unalias
unalias -a

# Carrega funçs genécas
. ~/GEN/shell/swvars.sh     # Carrega variaveis globais para o Sistema SW
. ~/GEN/shell/swfunc.sh     # Carrega funcoes genericas do SW
#---------------------------------------------------------
#| Variaveis
#---------------------------------------------------------
STR_LOG_PATH="${HOME}/site/POS/log/sys/swreplic.log"
#STR_SUSPECTS_FILE="/home/SW/sw_web/suspeitos.txt"
STR_PATH_DIR="/home/SW/sw_web"

if [ ! -d "$STR_PATH_DIR" ]; then
        mkdir $STR_PATH_DIR
        chmod 777 $STR_PATH_DIR
fi

STR_SUSPECTS_FILE="/home/SW/sw_web/suspeitos.txt"

#Identifica terminais suspeitos e salva a qtd de trx + codigo do terminal no arquivo "suspeitos.txt"
while (true) do

   #=======================================================================#
   #| Regra de bloqueio:
   #| De acordo com o log do swreplic, se houver mais de 10 trx negadas em
   #| um terminal do tipo POS e "entry_mode" chip / tarja / contactless no
   #| periodo de 5 minutos, classifica o terminal como suspeito
   #=======================================================================#
   cat $STR_LOG_PATH | awk -v strData=`perl -e '($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time() - 5 * 60); printf("%04d%02d%02d%02d%02d\n", $year+1900, $mon+1, $mday, $hour, $min);'` '{
        if (substr($1,0,12) >= strData)
        {
                        intTotAnalisadas++;
                        if (((substr($2, 16, 1) == 2 || substr($2, 16, 1) == 3) && (substr($2, 21, 2) == "01") ) &&
                           ((substr($2, 15, 1) == 2) || (substr($2, 15, 1) == 5) || (substr($2, 15, 1) == 7)))
                           {
                                        strBin[substr($2, 73, 6)]++;
                                        strTerm[substr($2, 38, 8)]++;
                                        intTot++;
                           }
         }
} END {
         for (ii in strTerm)
         {
                if (strTerm[ii]>10)
                        print ii";"term[ii] ; ###| "sort -n";
        }
        print "TOTAL;"intTotAnalisadas;
        print "TSUSP;"intTot;
        print "DATAM;"substr(strData,9,2)":"substr(strData,11,2);
}' > $STR_SUSPECTS_FILE

   #Tenta identificar trx suspeitas a cada 60 segundos
   sleep 60

done

