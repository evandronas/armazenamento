#!/bin/ksh

# © Copyright [2019] Rede S.A.
#############################################################
# Nome :     monitora_filas.sh
# Descricao: Monitora profundidade das filas eleitas e toma
#            acao caso necessario
# Autor :    Joao Paulo F. Costa
# Data :     07/11/2019
# Empresa :  Rede
#############################################################

# Garantir que nenhum comando tenha sido substituido
# por uma funcao do mesmo nome
unset -f unalias
unalias -a

typeset -i MAX_CUR_DEEP
typeset -i MAX_CUR_DEEP_DEFAULT=99
typeset -i DEEP_VALUE
typeset -i DEEP_VALUE_DEFAULT=120
typeset -i SYSTEM_STATUS=0

# Arquivos diversos
CONFIG_FILE="${HOME}/$SITE/cfg/monitorar_"$SITE".cfg"
LOG_FILE="${HOME}/site/$SITE/log/sys/monitora_filas.log"
SHSWNAME="monitora_filas.sh"

# Rotina de gravacao de log
# Parametros:
#       $1 = Caminho/nome do arquivo de log
#       $2 = Nome do script
#       $3 = Mensagem
SHELL_LOG()
{
	SHLOG="$1"
	SHJOB="$2"
	SHMSG="$3"
	SHDATAHOJE=`date "+%d/%m/%Y %H:%M:%S"`
	echo "$SHDATAHOJE $SHJOB $SHMSG" >> $SHLOG
}

STR_PATH_DIR="${HOME}/sw_web"

if [ ! -d "$STR_PATH_DIR" ]; then
        mkdir $STR_PATH_DIR
        chmod 777 $STR_PATH_DIR
fi

ALARM_FILE="${HOME}/sw_web/monitora_filas_"$SITE".log"

# Valida existencia de arquivo de cfg
if [ ! -r "$CONFIG_FILE" ]
then
	SHELL_LOG $LOG_FILE $SHSWNAME "Arquivo de configuracao '$CONFIG_FILE' nao encontrado ou sem permissao de leitura! Finalizando execucao."
	exit 100
else
	# Obtem/valida parametros do arquivo de configuracao
	# Filas para monitorar
	QUEUE_LIST=`awk '/monitor.queue/{print $2}' "$CONFIG_FILE" | sed 'H;$!d;x;s/.//;s/\n/|/g'`
	if [ -z "$QUEUE_LIST" ]
	then
		SHELL_LOG $LOG_FILE $SHSWNAME "Nao foram localizados registros tipo 'monitor.queue' no arquivo '$CONFIG_FILE'! Finalizando execucao."
		exit 101
	fi
	
	# Tamanho maximo toleravel das filas
	MAX_CUR_DEEP=`awk '/monitor.current_deep/{print $2}' "$CONFIG_FILE"`
	if [ -z "$MAX_CUR_DEEP" ]
	then
		SHELL_LOG $LOG_FILE $SHSWNAME "Nao foi localizado registro tipo 'monitor.current_deep' no arquivo '$CONFIG_FILE'! Assumindo valor padrao [$MAX_CUR_DEEP_DEFAULT]."
		MAX_CUR_DEEP="$MAX_CUR_DEEP_DEFAULT"
	fi
	
	# Tempo de espera entre execucoes (em segundos)
	SLEEP_TIME=`awk '/monitor.sleep_time/{print $2}' "$CONFIG_FILE"`
	if [ -z "$SLEEP_TIME" ]
	then
		SHELL_LOG $LOG_FILE $SHSWNAME "Nao foi localizado registro tipo 'monitor.sleep_time' no arquivo '$CONFIG_FILE'! Assumindo valor padrao [$DEEP_VALUE_DEFAULT]."
		SLEEP_TIME="$DEEP_VALUE_DEFAULT"
	fi
fi

# Laco de execucao
while true
do
	QUEUE_STOP_LIST=""
	SYSTEM_STATUS=`mbcmd uptime | egrep -c not`
	if [ "$SYSTEM_STATUS" -ne 0 ]
	then
		SHELL_LOG $LOG_FILE $SHSWNAME "FE-$SITE inativo! Aguardando proximo ciclo."
	else
		# Obtem dados atualizados das filas selecionadas
		QUEUE_STATUS=`mbcmd list -t </'' | egrep "$QUEUE_LIST" | awk '{ print $(NF-5) ";" $(NF-3) ";" $(NF-2)}'`
		
		# Gera timestamp do ciclo para o arquivo de alarmes
		ALARM_TIMESTAMP=`date "+%d/%m/%Y,%H:%M:%S"`
		
		# Processa cada fila
		for RECORD in $QUEUE_STATUS
		do
			QUEUE_NAME=`echo "$RECORD" | awk 'BEGIN{FS=";"}{print $1}'`
			DEEP_VALUE=`echo "$RECORD" | awk 'BEGIN{FS=";"}{print $3}'`
			if [ "$DEEP_VALUE" -gt "$MAX_CUR_DEEP" ]
			then
				ACTION="STOP"
				if [ -z "$QUEUE_STOP_LIST" ]
				then
					QUEUE_STOP_LIST=$QUEUE_NAME
				else
					TEMP_QUEUE_NAME=$(printf " %s" $QUEUE_NAME)
					QUEUE_STOP_LIST=$(printf "%s %s" $QUEUE_STOP_LIST $TEMP_QUEUE_NAME)
				fi
			else
				ACTION="NONE"
			fi
			echo "$ALARM_TIMESTAMP,$QUEUE_NAME,$DEEP_VALUE,$MAX_CUR_DEEP,$ACTION" >> $ALARM_FILE
			SHELL_LOG $LOG_FILE $SHSWNAME "$QUEUE_NAME $DEEP_VALUE $MAX_CUR_DEEP $ACTION"
		done

		# Valida necessidade de executar
		if [ -n "$QUEUE_STOP_LIST" ]
		then
			mbportcmd stop $QUEUE_STOP_LIST
		fi
	fi
	sleep "$SLEEP_TIME"
done

