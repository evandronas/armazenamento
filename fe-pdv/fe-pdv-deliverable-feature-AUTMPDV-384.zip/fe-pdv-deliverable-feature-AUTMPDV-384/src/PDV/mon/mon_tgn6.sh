#!/bin/ksh
strLog="/home/SW/site/POS/log/sys/mon_tgn6.log"
chmod 775 $strLog
chmod 775 /tmp/tgn6_O.log /tmp/tgn6_I.log
. swloadenv POS
while true
do
> /tmp/tgn6_O.log
> /tmp/tgn6_I.log
tail -500 /home/SW/site/POS/log/sys/logmqtgn6_000.log | awk '{ 
hora=$2
io=$4
msg=substr($5,1,4)*1

if ( io == "I" )
	msgg=msg-10;
else
	msgg=msg;
	
nsu=substr($5,5,9)
ter=substr($5,17,8)
if ( io == "O" )
	print nsu ";" ter ";" msgg "|" hora "|" io >> "/tmp/tgn6_"io".log"
else 
  print nsu ";" ter ";" msgg "|" hora "|" io >> "/tmp/tgn6_"io".log"
}'
sort -t"|" -k1 /tmp/tgn6_O.log > /tmp/tgn6_O.sort
sort -t"|" -k1 /tmp/tgn6_I.log > /tmp/tgn6_I.sort
agora=`echo $(date +%T)`
Respondidas=`join -t"|" -j1 1 -j2 1 /tmp/tgn6_O.sort /tmp/tgn6_I.sort | awk -F"|" -v agora=$agora '{ 
now=(substr(agora,1,2)*60*60)+(substr(agora,4,2)*60)+substr(agora,7,2)
now=now-46;
tini=(substr($2,1,2)*60*60)+(substr($2,4,2)*60)+(substr($2,7,2))
tfim=(substr($4,1,2)*60*60)+(substr($4,4,2)*60)+(substr($4,7,2))
dif=tfim-tini
if ( tfim >= now ) 
	print $2 "|" $4 "|" $1 "|" dif "|" agora
}' | sort | wc -l | awk '{ print $1 }'`
NRespondidas=`join -t"|" -j1 1 -j2 1 -v1 /tmp/tgn6_O.sort /tmp/tgn6_I.sort | awk -F"|" -v agora=$agora '{ 
now=(substr(agora,1,2)*60*60)+(substr(agora,4,2)*60)+substr(agora,7,2)
tini=(substr($2,1,2)*60*60)+(substr($2,4,2)*60)+(substr($2,7,2))
dif=now-tini
if ( dif > 15 && dif <= 60 ) 
	print $2 "|Timeout|" $1 "|" dif "|" agora
}' | sort | wc -l | awk '{ print $1 }'`
strHora=`echo $(date +"%Y/%m/%d %T")`
echo "$strHora - Respondidas: $Respondidas - N�o Respondidas: $NRespondidas" >> $strLog

if [ $Respondidas -eq 0 ] && [ $NRespondidas -gt 0 ] ; then
	strHora=`echo $(date +"%Y/%m/%d %T")`
	echo "$strHora - restart" >> $strLog
	mbportcmd stop mqtgn6_000
	sleep 1
	mbportcmd start mqtgn6_000
fi
sleep 10
done
