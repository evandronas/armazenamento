#!/usr/bin/ksh
########################################
# SCRIPT    : mon_EventManager
# Criado em : 03/10/2016
# Monitora o EventManager
#------------
########################################

#sleep 300

# Descrição : Garante preenchimento do front end
# Parâmetros : POS PDV CRT DBT CRTM DBTM CRTO DBTO HST
# Retornos : N/A
if [ "$1" == "" ]; then
        syslgsend "Sintaxe error!"
        syslgsend "Example: mon_EventManager [front end]"
        exit 0;
fi


LOG="${HOME}/site/$1/log/sys/mon_EventManager.log"

touch $LOG
chmod 777 $LOG

ant=0
hant='Sem Limpeza'
while true
do
    agora=`echo $(date +"%Y/%m/%d %T")`
    qtde=`echo | mbcmd list -t | egrep EventManager | awk -F"]:" '{ print $NF }' | awk '{ print $4}'`
    clear
    echo "$agora - Enfileiradas: $qtde -- Qtde Ant: $ant - $hant" >> $LOG
    if [ "$qtde" -gt 3 ]; then
    if [ "$qtde" -lt 50 ]; then
                    echo "$agora - limpando... - $qtde - mensagens" >> $LOG
                    ant=$qtde
                    hant=$agora
                    mbcmd clear queue EventManager >> $LOG
                    echo "$agora - limpou..... - $qtde - mensagens" >> $LOG
            else
                    echo "$agora - Nao limpou - quantidade de msgs acima do esperado... - $qtde - mensagens" >> $LOG
            fi
    fi
    sleep 60
done

