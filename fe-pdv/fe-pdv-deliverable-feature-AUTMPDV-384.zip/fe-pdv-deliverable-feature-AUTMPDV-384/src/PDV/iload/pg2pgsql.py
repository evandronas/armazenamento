#!/usr/bin/python3 -u
from psycopg2 import sql, connect
import argparse
import os
import sys
import time
from datetime import datetime
import logging
import boto3
import json

def get_connection( args ):
    try:
        if args.dbname != "":
            db_name = args.dbname
        else:
            db_name = args.user

        conn = connect(
            dbname = db_name,
            user = args.user,
            host = args.host,
            password = args.pwd
        )
        logging.info("Connection established !!!")
    except Exception as err:
        logging.error("Connect() error: %s", err)
        conn = None
        os.sys.exit(1)
    return conn

def get_columns_names(conn, args):
    columns = {}

    col_cursor = conn.cursor()

    col_names_str = "SELECT column_name, data_type FROM INFORMATION_SCHEMA.COLUMNS WHERE "
    col_names_str += "table_name in ( '{}', '{}' );".format( args.table.upper(), args.table.lower())

    logging.info ("Looking definitions for table %s", args.table )

    try:
        sql_object = sql.SQL( col_names_str ).format( sql.Identifier( args.table ))
        col_cursor.execute( sql_object )
        col_names = ( col_cursor.fetchall() )
        if (len(col_names) == 0):
            logging.error ("No columns identified for table")
            os.sys.exit(1)

        # iterate list of tuples and grab first element
        for tup in col_names:
            columns[tup[0]] = tup[1]
        col_cursor.close()

    except Exception as err:
        logging.error("get_columns_names ERROR:", err)

    return columns

def get_lines( conn, args, columns_definitions ):
    select_cursor = conn.cursor()

    all_columns = ""
    virgula = ""
    for coluna in columns_definitions:
        all_columns = "%s%s%s" % ( all_columns, virgula, coluna )    
        virgula = ","

    logging.info ("Selecting records in %s", args.table )

    # check if any columns don`t have definition
    if len(args.columns) > 0:
        colunas = args.columns.split(',')
        for coluna in colunas:
            # print( '%s in %s = %d' % ( coluna, columns, coluna in colunas ))
            if coluna not in columns_definitions:
               logging.error("Desired Column %s not found in table", coluna )

    # create select    
    if len(args.columns) > 0:
        all_columns = args.columns

    query = "select %s from %s" % ( all_columns, args.table )
    if len(args.where) > 0:
        query = "%s where %s" % ( query, args.where )

    print('-- %s' % query )
    try:
        select_cursor.execute( query )
        line = ( select_cursor.fetchone() )
        colunas_select = all_columns.split(',')
        count = 0
        while line is not None:
            virgula = ""
            print( "insert into %s ( %s ) values ( " % ( args.table, all_columns ), end="" )
            id = 0
            for field in line:
                datatype = columns_definitions[colunas_select[id]]
                if datatype in ( 'character', 'character varying', 'timestamp with time zone', 'timestamp without time zone' ):
                    aspa = "'"
                else:
                    aspa = ""
                if field is None:
                    field = 'NULL'
                    aspa = ""
                print("%s%s%s%s" % ( virgula, aspa, field, aspa  ), end="")
                virgula = ","
                id += 1
            print(" );")
            count += 1
            if( args.max > 0 and count == args.max ):
                break
            if( count % 5000 == 0):
                logging.info('%d records dumped.', count )
            line = ( select_cursor.fetchone() )
        select_cursor.close()
    except Exception as err:
        logging.error("querie error: %s", err)
    
    logging.info('Total of Lines exported : %d', count )

def get_secret(secret_name,region_name ):
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            secret = base64.b64decode(get_secret_value_response['SecretBinary'])

    return json.loads(secret)  # returns the secret as dictionary

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Postgres to Postgres SQL - Version 0.9')
    parser.add_argument("--host",    help="Postgres Server",   default="", type=str, required=False)
    parser.add_argument("--user",    help="User",              default="", type=str, required=False)
    parser.add_argument("--pwd",     help="Password",          default="", type=str, required=False)
    parser.add_argument("--dbname",  help="dbname",            default="", type=str, required=False)
    parser.add_argument("--table",   help="table",             type=str, required=True)
    parser.add_argument("--sm",      help="Secrets Manager",   default="", type=str, required=False)
    parser.add_argument("--region",  help="Region",            default="sa-east-1", type=str, required=False)    
    
    parser.add_argument("--columns", help="columns",           default="", type=str, required=False)
    parser.add_argument("--where",   help="where condition",   default="", type=str, required=False)
    parser.add_argument("--max",     help="max lines",         default=0, type=int, required=False)

    args = parser.parse_args()

    if args.sm != '':
        secrets = get_secret(args.sm,args.region)
        args.host   = secrets['host']
        args.user   = secrets['username']
        args.pwd    = secrets['password']

    format = "%(asctime)s.%(msecs)03d %(levelname)s: %(message)s"
    logging.basicConfig(format=format, level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

    start = datetime.now()
    conn = get_connection( args )
    columns = get_columns_names( conn, args )
    print ("-- Table Columns:", columns)
    print ("-- Output Columns :", args.columns )
    print ("-- Filter :", args.where )
    print ("-- dbname :", args.dbname )
    get_lines( conn, args, columns )
    elapsed = (datetime.now() - start)
    logging.info("Elapsed time : %d seconds", elapsed.seconds )

    conn.close ()

    os.sys.exit(0)