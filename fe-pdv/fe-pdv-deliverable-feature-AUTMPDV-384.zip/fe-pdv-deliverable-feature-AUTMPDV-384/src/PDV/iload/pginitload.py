#!/usr/bin/python3 -u
from psycopg2 import sql, connect
import argparse
import os
import sys
import time
from datetime import datetime
import logging
import boto3
import json

def get_connection( args ):
    try:
        if args.dbname != "":
            db_name = args.dbname
        else:
            db_name = args.user

        conn = connect(
            dbname = db_name,
            user = args.user,
            host = args.host,
            password = args.pwd
        )
        logging.info("Connection established !!!")
    except Exception as err:
        logging.error("Connect() error: %s", err)
        conn = None
        os.sys.exit(1)
    return conn

def get_secret(secret_name,region_name ):
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            secret = base64.b64decode(get_secret_value_response['SecretBinary'])

    return json.loads(secret)  # returns the secret as dictionary

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Postgres Initial Load - Version 1.0')
    parser.add_argument("--host",    help="Postgres Server",   default="", type=str, required=False)
    parser.add_argument("--user",    help="User",              default="", type=str, required=False)
    parser.add_argument("--pwd",     help="Password",          default="", type=str, required=False)
    parser.add_argument("--dbname",  help="dbname",            default="", type=str, required=False)
    parser.add_argument("--table",   help="table",             type=str, required=True)
    parser.add_argument("--sm",      help="Secrets Manager",   default="", type=str, required=False)
    parser.add_argument("--region",  help="Region",            default="sa-east-1", type=str, required=False)
    parser.add_argument("--truncate", help="truncate table before load",   action='store_true')
    parser.add_argument("--file",     help="file name",        default="", type=str, required=False)

    args = parser.parse_args()

    if args.file == '':
        args.file = "%s.sql" % args.table

    if( not os.path.exists(args.file)):
        logging.info("Load file %s not found !!!", args.file )
        os.sys.exit(1)

    if args.sm != '':
        secrets = get_secret(args.sm,args.region)
        args.host   = secrets['host']
        args.user   = secrets['username']
        args.pwd    = secrets['password']

    format = "%(asctime)s.%(msecs)03d %(levelname)s: %(message)s"
    logging.basicConfig(format=format, level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

    start = datetime.now()
    conn = get_connection( args )

    if( args.truncate ):
        logging.info('Truncating table before loading : %s', args.table )
        try:
            loadcursor = conn.cursor()
            loadcursor.execute( 'delete from %s;' % args.table )
        except Exception as err:
            logging.error("Load error: %s", err )
        conn.commit()
        elapsed = (datetime.now() - start)
        logging.info("Duration : %d seconds", elapsed.seconds )

    count = 0
    inserted = 0
    errors = 0
    for line in open(args.file):
        line = line.strip('\n')
        count += 1        
        if not line.startswith( '--' ):
            try:
                loadcursor = conn.cursor()
                loadcursor.execute( line )
                if ( loadcursor.rowcount == 0 ):
                    logging.error("No rows updated in line => %s (%d)", line, count )
                    errors += 1
                else:
                    inserted += 1

                if( count % 5000 == 0):
                    logging.info('%d lines loaded.', count )
                    conn.commit()

            except Exception as err:
                logging.error("Load error: %s in line => %s (%d)", err, line, count )
                errors += 1
                conn.commit()

    conn.commit()
    logging.info('Total of Lines Loaded : %d', inserted )
    logging.info('Total of Errors : %d', errors )

    elapsed = (datetime.now() - start)
    logging.info("Total Elapsed time : %d seconds", elapsed.seconds )
    conn.close ()

    os.sys.exit(0)