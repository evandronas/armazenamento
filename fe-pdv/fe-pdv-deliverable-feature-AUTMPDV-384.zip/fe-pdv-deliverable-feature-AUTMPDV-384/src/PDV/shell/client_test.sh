SERVER=${1}
INIPORT=${2}
FIMPORT=${3}

if [[ "${SERVER}" == "" || "${INIPORT}" == "" || "${FIMPORT}" == "" ]]; then
    echo "${0} [SERVER] [INITIAL PORT] [FINAL PORT]"
    exit 1
fi

DATA=$(date +%Y%m%d_%H%M%S)
LOGSERVER="client_${DATA}.log"

> ${LOGSERVER}
PORTA=${INIPORT}
while [[ ${PORTA} -le ${FIMPORT} ]]; do
    echo "==========================================================================="
    client.pl ${SERVER} ${PORTA} | tee -a ${LOGSERVER}
    PORTA=$((${PORTA}+1))
done
echo "==========================================================================="

exit 0
