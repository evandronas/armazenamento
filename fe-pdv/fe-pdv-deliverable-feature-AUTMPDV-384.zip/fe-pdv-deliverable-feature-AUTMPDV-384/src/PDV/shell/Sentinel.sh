#!/bin/ksh
#
# © Copyright 2020 Rede S.A.
#############################################################
# Nome : Sentinel
# Descrição: Finaliza o front end POS em caso de queda de processo core (mb)
# Autor : Fernando Jacinto
# Data : 11/03/2020
# Empresa : Rede S.A.
#############################################################
# Nome : Sentinel
# Descrição: Adicao de novas funcionalidades e LOG do tempo mais preciso (em segundos)
# Autor : Fernando Jacinto
# Data : 05/08/2020
# Empresa : Rede S.A.

# Load Functions
. ~/GEN/shell/swvars.sh     # Carrega variaveis globais para o Sistema SW
. ~/GEN/shell/swfunc.sh              # Carrega funcoes genericas do SW

# Descrição : Aguarda 60 segundos para inicio do processamento
# Parâmetros : N/A
# Retornos : N/A
#sleep 60

# Descrição : Garante preenchimento do front end
# Parâmetros : POS PDV CRT DBT CRTM DBTM CRTO DBTO HST
# Retornos : N/A
if [ "$1" == "" ]; then
        syslgsend "Sintaxe error!"
        syslgsend "Example: Sentinel.sh [front end]"
        exit 0;
fi

# Descrição : Esta funcao adiciona o "header" do LOG
# Parâmetros : N/A
# Retornos : N/A
addHeader() {
    while IFS= read -r line; do
        printf '%s %s\n' "$(date +"%y.%m.%d %H:%M:%S [   Sentinel:$$] ")" "$line";
    done
}

# Descrição : Verifica se o processo deve ficar no ar
# Parâmetros : N/A
# Retornos : N/A
checkRun()
{
        if (( `ps -fp $$ | grep -v UID | awk '{ print $3}'` == 1 )); then
                echo "Interrupt Processing... Exit!" | addHeader >> $strDebug
                exit 0
        else
                echo "Script Management | PID: $$ | PPID: `ps -fp $$ | grep -v UID | awk '{ print $3}'`" | addHeader >> $strDebug
                print "" >> $strDebug
        fi
}
# Descrição : Esta funcao obtem um "snapshot" do servidor
# Parâmetros : N/A
# Retornos : N/A
snapshot()
{
        print "Processes tree:" | addHeader >> $strDebug
        ps -p $strMbtsk | addHeader >> $strDebug
        print "" >> $strDebug

        print "Processes details:" | addHeader >> $strDebug
        ps -elf | head -1 | addHeader >> $strDebug
        ps -elf | grep $strMbtsk | addHeader >> $strDebug
        print "" >> $strDebug

        print "Memory statistics:" | addHeader >> $strDebug
        ipcs -pmb | head -2 | addHeader >> $strDebug
        ipcs -pmb | grep swoper | addHeader >> $strDebug
        print "" >> $strDebug

        print "CPU utilization:" | addHeader >> $strDebug
        vmstat -tw 1 2 | addHeader >> $strDebug
        print "" >> $strDebug

        print "List of 10+ CPU using processes:" | addHeader >> $strDebug
        ps aux | sort -rn -k2n | head -10 | addHeader >> $strDebug
        print "" >> $strDebug

        print "Amount of available disk space:" | addHeader >> $strDebug
        df -h | head -1 | addHeader >> $strDebug
        df -h | grep SW | addHeader >> $strDebug
        print "" >> $strDebug

        print "Users access information:" | addHeader >> $strDebug
        who -u | addHeader >> $strDebug
        print "" >> $strDebug

        print "Mailbox System statistics:" | addHeader >> $strDebug
        echo "Id    Ty  Name                    ChainId Throttle CurDepth MaxDepth  DropCnt" | addHeader >> $strDebug
        echo "------------------------------------------------------------------------------------------" | addHeader >> $strDebug
        strMBLOOK=`echo " " | mblook -t | sed '/0        0        0/d' | sed '/Cannot/d' | sed '/-/d' | sed '/Id/d' | sed '/^$/d'`
        if [ -n "$strMBLOOK" ]
        then
                echo " " | mblook -t | sed '/0        0        0/d' | sed '/Cannot/d' | sed '/-/d' | sed '/Id/d' | sed '/^$/d' | addHeader >> $strDebug
        else
                echo " " | mblook -t | grep SharedCash | addHeader >> $strDebug
        fi
        mbcmd usage | addHeader >> $strDebug
        print "" >> $strDebug

    print "Malfunction tasks statistics:" | addHeader >> $strDebug
        for strTSK in `grep died $strDBG | awk '{ print $4 }' | cut -d "(" -f 2 | tr -d ")," | sort -u`
    do
        if [ -n "$strTSK" ]
        then
            TIMES=`grep died $strDBG | grep $strTSK | wc -l | xargs`
            echo "$strTSK has died $TIMES times(s)" | addHeader >> $strDebug
        fi
    done
        print "" >> $strDebug

        print "Accept call connections:" | addHeader >> $strDebug
        netstat -an | head -2 | grep -v servers | addHeader >> $strDebug
    for strPORT in `grep accept-call $strCFG | grep -v \# | awk '{ print $2"\t"$NF }' | cut -d':' -f 2 | awk 'FS="." {print $NF}' | sort -u`
    do
                netstat -an | grep $strSourceIP | grep $strPORT | addHeader >> $strDebug
        done
        print "" >> $strDebug

        print "Make call connections:" | addHeader >> $strDebug
        netstat -an | head -2 | grep -v servers | addHeader >> $strDebug
    for strPORT in `grep make-call $strCFG | grep -v \# | awk '{ print $2"\t"$NF }' | cut -d':' -f 2 | awk 'FS="." {print $NF}' | sort -u`
    do
                netstat -an | grep $strSourceIP | grep $strPORT | addHeader >> $strDebug
        done
        print "" >> $strDebug
}

#Rotina "main()" do script
strHostname=`hostname`
strSourceIP=$PRIVATEIP
strMbtsk=`grep mbtsk $OLOGDIR/debug/mbtsk.debug | awk '{ print $4 }' | tr -d "mbtsk:" | awk -F"]" '{ print $1 }' | tail -1`
strCFG="${HOME}/site/$SITE/cfg/istparam.cfg"
strDebug="$OLOGDIR/debug/Sentinel.debug"
strDBG="${HOME}/site/$SITE/log/debug/mbtsk.debug"
strPPID=$2

print "" >> $strDebug
print "" >> $strDebug
strInicialLoad=`date +"%a %h %d %H:%M:%S %Y"`
print "**** Debug started on pid $$ at $strInicialLoad" >> $strDebug
print - "Analyzing the environment: $strHostname" | addHeader >> $strDebug
print - "Application interface: $SITE" | addHeader >> $strDebug

while true; do
        checkRun
        intFilled=${#strMbtsk}
print - "intFilled: $intFilled  strMbtsk: $strMbtsk" | addHeader >> $strDebug
        if (( $intFilled == 0 )); then
                print "$strHostname | File $OLOGDIR/debug/mbtsk.debug not found! Skipping..." | addHeader >> $strDebug
        else
                strChildren=`ps -p $strMbtsk | awk '{ print $1 }' | grep -v PID | grep -v $strMbtsk | grep -v $$`
                strMb=`ps -p $strMbtsk --ppid $strMbtsk --forest | grep 'mb$' | awk '{ print $1 }'`
                intFilled=${#strMb}
                if (( $intFilled == 0 )); then
                        print "The mb process is dead and not being used!" | addHeader >> $strDebug
                        print "The kill_processes() rotine is disable... I´m done!" | addHeader >> $strDebug
                        exit 0;
                else
                        print "The mb ($strMb) process is running... Collecting Statistics..." | addHeader >> $strDebug
                        snapshot
                fi
        fi
        sleep 60
done

