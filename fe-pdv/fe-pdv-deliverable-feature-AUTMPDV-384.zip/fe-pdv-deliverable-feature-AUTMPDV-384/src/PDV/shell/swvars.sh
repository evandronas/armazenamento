#!/usr/bin/bash
#
#  COLORS
#
BLACK=$(tput -Txterm setaf 0)
RED=$(tput -Txterm setaf 1)
GREEN=$(tput -Txterm setaf 2)
YELLOW=$(tput -Txterm setaf 3)
BLUE=$(tput -Txterm setaf 4)
PURPLE=$(tput -Txterm setaf 5)
CYAN=$(tput -Txterm setaf 6)
WHITE=$(tput -Txterm setaf 7)
BOLD=$(tput -Txterm bold)
BRIGHT=$(tput -Txterm dim)
REVERSE=$(tput -Txterm rev)
UNDERLINE=$(tput -Txterm smul)
STANDOUT=$(tput -Txterm smso)

RESET=$(tput -Txterm sgr0)
COFF=${RESET}
NORMAL=${RESET}

if [ "${0}" == "-sh" ]; then
    MODULE="sh"
elif [ "${0}" == "-bash" ]; then
    MODULE="bash"
else
    MODULE=$(basename ${0})
fi

VALIDFES="PDV"
DEFAULTFE=PDV
USERCONTROL=/home/SW/.devusers.cfg
PORTCONTROL=/home/SW/.devbaseports.cfg
WORKSPACE=${HOME}/wspace

EXIT_SUCCESS=0
EXIT_ERROR=1

export SW_ROOT=${HOME}
