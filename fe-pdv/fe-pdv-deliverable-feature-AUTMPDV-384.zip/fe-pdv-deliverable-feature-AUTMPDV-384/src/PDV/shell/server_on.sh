INIPORT=${1}
FIMPORT=${2}

if [[ "${INIPORT}" == "" || "${FIMPORT}" == "" ]]; then
    echo "${0} [INITIAL PORT] [FINAL PORT]"
    exit 1
fi

QTD=$((${FIMPORT}-${INIPORT}))

if [[ ${QTD} -gt 100 ]]; then
	echo "Quantidade de Portas a serem abertas muito alta..."
	exit 1
fi

server_off.sh

DATA=$(date +%Y%m%d_%H%M%S)
LOGSERVER="server_${DATA}.log"

> ${LOGSERVER}
PORTA=${INIPORT}
while [[ ${PORTA} -le ${FIMPORT} ]]; do
    server.pl ${PORTA} &
    PORTA=$((${PORTA}+1))
done

sleep 2
echo "==========================================================================="
echo "Status das Portas"
echo "==========================================================================="
PORTA=${INIPORT}
while [[ ${PORTA} -le ${FIMPORT} ]]; do
    netstat -an | grep ${PORTA}
    PORTA=$((${PORTA}+1))
done
echo "==========================================================================="
ps -fu $(whoami) | grep "server.pl" | grep -v grep
echo "==========================================================================="


while [ true ]; do
    sleep 1
done

exit 0

