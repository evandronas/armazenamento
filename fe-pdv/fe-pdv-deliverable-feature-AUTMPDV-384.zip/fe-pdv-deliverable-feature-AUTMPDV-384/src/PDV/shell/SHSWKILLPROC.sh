#!/bin/ksh
# 
# Fonte: SHSWKILLPROC.sh
# Autor: Joao Paulo Ferraz Costa / Data: 10/06/2011
# Descricao: Finaliza processos com muitas ocorrencias de enfileiramento
#            indicados, via arquivo, pelo modulo scQueue.
#            Este shell nao eh e nao sera acionado via CTRL-M. Seu 
#			 funcionamento eh similar ao de um modulo, ou seja, deve estar
#            presente no istparam.cfg para ser acionado e restartado caso
#            seja necessario.
#            Shell modificado da '7.1' para '7.5'.
#
# $Log $
#

export SW_ROOT=/home/SW
. ~swadm/.profile

. $SW_ROOT/GEN/shell/switch_func.sh
. $SW_ROOT/GEN/shell/shell_func.sh

LOGERR=/home/SW/sw_web/SHSWKILLPROC.sh.txt
LOG_FILE=$SW_ROOT/site/GEN/tmp/SHSWKILLPROC.log
SHSWNAME=SHSWKILLPROC.sh

#
# Funcoes
#

GRAVALOG()
{
	echo "`date +'%d/%m/%Y %H:%M:%S''('$LOGNAME')=>'" $1 >> $LOG_FILE
}

KILL_PROCESS()
{
	count=0
	GRAVALOG "Finalizando instancias do processo '$1'."
	for i in `ps -ef | grep $1 | grep -v grep | awk '{print $2}'`
	do 
		kill -9 $i
		((count=$count+1))
	done
	GRAVALOG "Foram encerradas $count instancias do processo '$1'."
}

HEADER()
{
	SHELL_LOG $LOGERR $SHSWNAME "-------------------------------------------------------------------"
	SHELL_LOG $LOGERR $SHSWNAME "Iniciando shell de Finalizacao de Processos enfileirados.          "
	SHELL_LOG $LOGERR $SHSWNAME "-------------------------------------------------------------------"
	
	GRAVALOG "-------------------------------------------------------------------"
	GRAVALOG "Iniciando shell de Finalizacao de Processos enfileirados.          "
	GRAVALOG "-------------------------------------------------------------------"
}

HANDLE_SIGNAL()
{
	GRAVALOG "-------------------------------------------------------------------"
	GRAVALOG "Encerrando shell de Finalizacao de Processos enfileirados.         "
	GRAVALOG "-------------------------------------------------------------------"
}
#
# Principal
#

trap 'HANDLE_SIGNAL;exit 0' 1 2 15

HEADER

while(true)
do
	for TASK in `ls $OLOGDIR/sys/killfile*.txt 2> /dev/null`
		do
			if [ -f $TASK ]
			then
				task_name=`cat $TASK`
				GRAVALOG "Finalizando Processo $task_name.                                   "
				KILL_PROCESS $task_name
				GRAVALOG "Processo $task_name finalizado.                                    "
				rm $TASK 2> /dev/null
			fi
		done
	sleep 10
done

