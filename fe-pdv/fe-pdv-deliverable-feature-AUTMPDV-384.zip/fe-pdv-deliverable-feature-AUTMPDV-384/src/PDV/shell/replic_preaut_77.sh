#!/usr/bin/ksh
#set -x
#========================================================================================================================================
# � Copyright 2018 Rede S.A.
#========================================================================================================================================
# Nome........: replic_preaut.sh
# Descricao...: Executa replicacao de pre-autorizacoes do BD do SW 7.5 para o BD do SW 7.7
#               Faz a extracao dos registros de pre-autorizacao (TBSW0058) do ORACLE (SW 7.5), fazendo
#               em seguida a inclusao desses registros na tabela TBSW0058 do Aurora (SW 7.7).
#               Ex: replic_preaut77.sh
# Autor.......: Euzebio Silva
# Data........: 13/08/2021
# Empresa.....: BRQ
#
#========================================================================================================================================
#  Formas de Execucao do Shell
#========================================================================================================================================
#    replic_preaut77.sh           => Quando executado sem parametros, ele executa 1 vez ao dia no horario entre 05:30 e 05:45 da
#                                    manha (Horario Default)
#    replic_preaut77.sh H         => Quando executado com parametro HORA, ele executa de HORA em HORA
#    replic_preaut77.sh 0400 0415 => Quando executado com parametro de Hora Inicio/Fim. Ele executa 1 vez ao dia no intervalo informado.
#
#   PONTO DE ATENCAO : ====> O INTERVALO DEVE SER DE NO MAIOR QUE 10 MIN. RECOMENDADO 15 MIN
#                            A EXECUCAO NAO PODE EXCEDER 1 HORA, SENAO A PROX. EXECUCAO FICARA FORA DA JANELA
#
#========================================================================================================================================

# Garantir que nenhum comando tenha sido substituido
# por uma funcao do mesmo nome
unset -f unalias
unalias -a

# Carrega variaveis genericas
#. ~/.profile

. swloadenv ${FE} >> /dev/null 2>&1

# funcoes genericas
. swfunc.sh

# Definicao de PATH
export OASIS_ROOT="/home/SW"

# Parametros passados por linha de comando para o shell
strParam=$@

# Nome do Script para referenciar em modo de usar
STR_SCRIPT_NAME="replic_preaut77"

# Teste se o diretorio de log eh um link
STR_LOG_FILE="${HOME}/site/${FE}/log/sys"
if test ! -d $STR_LOG_FILE
then
        echo "Erro ao acessar o diretorio de Log"
        logger System "Erro ao acessar diretorio: $STR_LOG_FILE"
        exit 1
fi

# Data inicial da execucao do shell
strDataExecInicial="`date +"%Y%m%d-%H:%M:%S"`"

#-----------------------------------------------------------------------------
# Descricao...: Registra no log, o inicio da execucao do script.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

header_inicio_script()
{
    echo $STR_LOG_PATH $STR_SCRIPT_NAME "   " >> $STR_LOG_FILE
    echo $STR_LOG_PATH $STR_SCRIPT_NAME "=================================================================" >> $STR_LOG_FILE
    echo $STR_LOG_PATH $STR_SCRIPT_NAME " Inicio da execucao do script $STR_THIS_FILE                     " >> $STR_LOG_FILE
    echo $STR_LOG_PATH $STR_SCRIPT_NAME "=================================================================" >> $STR_LOG_FILE

        return 0
}  # fim da funcao "header_inicio_script"

#-----------------------------------------------------------------------------
# Descricao...: Registra no log, o fim da execucao do script.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

finaliza_script()
{
    intRawSignal=$?
    if [ "${intRawSignal}" -eq "0" ]
    then
        intSinal=0
    else
        intSinal=$(($intRawSignal - 128))
    fi
    strNomeSinal=`kill -l ${intSinal}`

    echo $STR_LOG_PATH $STR_SCRIPT_NAME "=================================================================" >> $STR_LOG_FILE
    echo $STR_LOG_PATH $STR_SCRIPT_NAME " FIM da execucao do script $STR_SCRIPT_NAME                      " >> $STR_LOG_FILE
    echo $STR_LOG_PATH $STR_SCRIPT_NAME " SINAL recebido = $intSinal - ${strNomeSinal}                    " >> $STR_LOG_FILE
    echo $STR_LOG_PATH $STR_SCRIPT_NAME "=================================================================" >> $STR_LOG_FILE
    exit ${intSinal}

}  # fim da funcao "finaliza_script"


#-----------------------------------------------------------------------------
# Descricao...: Grava no arquivo de LOG, as variaveis utilizadas no programa.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

imprime_parametros() {
    echo $STR_LOG_FILE $STR_SCRIPT_NAME "   "
    echo $STR_LOG_FILE $STR_SCRIPT_NAME "---------------------------PARAMETROS----------------------------" >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME " STR_SCRIPT_NAME        = [$STR_SCRIPT_NAME]        "              >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME " STR_LOG_FILE           = [$STR_LOG_FILE]           "              >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME " STR_SQL_COMMAND_ORACLE = [$STR_SQL_COMMAND_ORACLE] "              >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME " STR_DB_USER_ORACLE     = [$STR_DB_USER_ORACLE]     "              >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME " STR_SQL_COMMAND_POSTGRE= [$STR_SQL_COMMAND_POSTGRE]"              >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME " STR_DB_USER_POSTGRE    = [$STR_DB_USER_POSTGRE]     "             >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME " STR_CONFIG_FILE        = [$STR_CONFIG_FILE]"                      >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME " JANELA DE EXECUCAO     = [$STR_INI_HORA:$STR_FIM_HORA]"           >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME "-----------------------------------------------------------------" >> $STR_LOG_FILE
    echo $STR_LOG_FILE $STR_SCRIPT_NAME "   "
        return 0
} # Fim da funcao imprime_parametros


#-----------------------------------------------------------------------------
# Descricao...: Adiciona mais uma condicao de busca ao final da query  de
#               extracao do oracle. Essa funcao eh usada no caso de busca de
#               todas as transacoes de pre-autorizacoes.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

add_condicao_select_geral()
{
    cat << SQLEOF  >> ${STR_SQL_COMMAND_ORACLE}
        and trunc(DAT_VLD_PAUZ) >= TO_DATE('${intDataFimExtracao}','YYYYMMDD')
        and ( (DAT_MOV_TRAN < '${intDataFimExtracao}'  ) or
              (DAT_MOV_TRAN = '${intDataFimExtracao}' and DTH_INI_TRAN <= TO_DATE('${intDataFimExtracao} ${intHoraFimExtracao}', 'YYYYMMDD HH24MISS')))
SQLEOF

    return 0
} # Fim da funcao add_condicao_select_geral


#-----------------------------------------------------------------------------
# Descricao...: Adiciona mais uma condicao de busca ao final da query  de
#               extracao do oracle. Essa funcao eh usada no caso de busca de
#               transacoes de pre-autorizacoes que estao num intervalo de horas e/ou dias.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

add_condicao_select_range_dias()
{
    cat << SQLEOF  >> ${STR_SQL_COMMAND_ORACLE}
      and trunc(DAT_VLD_PAUZ) >= TO_DATE('${intDataFimExtracao}','YYYYMMDD')
      and ( (DAT_MOV_TRAN = '${intDataInicioExtracao}' and DTH_INI_TRAN >= TO_DATE('${intDataInicioExtracao} ${intHoraInicioExtracao}', 'YYYYMMDD HH24MISS') or
            (DAT_MOV_TRAN = '${intDataFimExtracao}'    and DTH_INI_TRAN <= TO_DATE('${intDataFimExtracao} ${intHoraFimExtracao}'   , 'YYYYMMDD HH24MISS')))    or
            (DAT_MOV_TRAN > '${intDataInicioExtracao}' and DAT_MOV_TRAN <  '${intDataFimExtracao}') )

SQLEOF

    return 0
} # Fim da funcao add_condicao_select_range_dias


#-----------------------------------------------------------------------------
# Descricao...: Adiciona mais uma condicao de busca ao final da query  de
#               extracao do oracle. Essa funcao eh usada no caso de busca de
#               transacoes de pre-autorizacoes realizadas na ultima hora antes da hora atual.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

add_condicao_select_dia_atual()
{
    cat << SQLEOF  >> ${STR_SQL_COMMAND_ORACLE}
        and trunc(DAT_VLD_PAUZ) >= TO_DATE('${intDataFimExtracao}', 'YYYYMMDD' )
        and DAT_MOV_TRAN = '${intDataFimExtracao}'
        and DTH_INI_TRAN >= TO_DATE('${intDataInicioExtracao} ${intHoraInicioExtracao} ', 'YYYYMMDD HH24MISS') and DTH_INI_TRAN <= TO_DATE('${intDataFimExtracao} ${intHoraFimExtracao}', 'YYYYMMDD HH24MISS')
SQLEOF

    return 0
} # Fim da funcao add_condicao_select_dia_atual


#-----------------------------------------------------------------------------
# Descricao...: Adiciona mais uma condicao de busca ao final da query  de
#               extracao do oracle. Essa funcao eh usada no caso em que a execucao
#               atual deste programa eh iniciada num intervalo inferior a 1 hora apos
#               o fim da ultima execucao. Nesse caso a execucao da query NAO deve fazer
#               nada, pois a data do arquivo de controle registra a extracao mais recente.
#               For�a uma condicao inexistente para que o retorno da query nao encontre nenhum registro.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

add_condicao_select_vazio()
{
    intDataAtual=`date "+%Y%m%d"`
    cat << SQLEOF  >> ${STR_SQL_COMMAND_ORACLE}
        and DAT_MOV_TRAN > '${intDataAtual}'
SQLEOF

    return 0
} # Fim da funcao add_condicao_select_vazio


#-----------------------------------------------------------------------------
# Descricao...: Adiciona mais uma condicao de busca ao final da query  de
#               select para update no oracle . Essa funcao eh usada no caso de busca de
#               transacoes de pre-autorizacoes que estao num intervalo de horas e/ou dias.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

add_condicao_update_range_dias()
{
    cat << SQLEOF  >> ${STR_SQL_COMMAND_ORACLE}
      and ( (trunc(DTH_STTU_TRAN) = TO_DATE('${intDataInicioExtracao}','YYYYMMDD' ) and DTH_STTU_TRAN >= TO_DATE('${intDataInicioExtracao} ${intHoraInicioExtracao}', 'YYYYMMDD HH24MISS')) or
            (trunc(DTH_STTU_TRAN) = TO_DATE('${intDataFimExtracao}','YYYYMMDD')    and DTH_STTU_TRAN <= TO_DATE('${intDataFimExtracao} ${intHoraFimExtracao}', 'YYYYMMDD HH24MISS'))    or
            (trunc(DTH_STTU_TRAN) > TO_DATE('${intDataInicioExtracao}','YYYYMMDD' ) and trunc(DTH_STTU_TRAN) <  TO_DATE('${intDataFimExtracao}','YYYYMMDD' )) )
SQLEOF

    return 0
} # Fim da funcao add_condicao_update_range_dias


#-----------------------------------------------------------------------------
# Descricao...: Adiciona mais uma condicao de busca ao final da query  de
#               extracao do oracle. Essa funcao eh usada no caso de busca de
#               transacoes de pre-autorizacoes realizadas na ultima hora antes da hora atual.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

add_condicao_update_dia_atual()
{
    cat << SQLEOF  >> ${STR_SQL_COMMAND_ORACLE}
        and trunc(DTH_STTU_TRAN)  = TO_DATE('${intDataFimExtracao}','YYYYMMDD' )
        and DTH_STTU_TRAN >= TO_DATE('${intDataInicioExtracao} ${intHoraInicioExtracao}', 'YYYYMMDD HH24MISS')
        and DTH_STTU_TRAN <= TO_DATE('${intDataFimExtracao} ${intHoraFimExtracao}', 'YYYYMMDD HH24MISS')
SQLEOF

    return 0
} # Fim da funcao add_condicao_update_dia_atual


#-----------------------------------------------------------------------------
# Descricao...: Adiciona mais uma condicao de busca ao final da query  de
#               extracao do oracle. Essa funcao eh usada no caso em que a execucao
#               atual deste programa eh iniciada num intervalo inferior a 1 hora apos
#               o fim da ultima execucao. Nesse caso a execucao da query NAO deve fazer
#               nada, pois a data do arquivo de controle registra a extracao mais recente.
#               For�a uma condicao inexistente para que o retorno da query nao encontre nenhum registro.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

add_condicao_update_vazio()
{
    intDataAtual=`date "+%Y%m%d"`
    cat << SQLEOF  >> ${STR_SQL_COMMAND_ORACLE}
        and trunc(DTH_STTU_TRAN) > TO_DATE('${intDataAtual}','YYYYMMDD' )
SQLEOF

    return 0
} # Fim da funcao add_condicao_update_vazio

#---------------------------------------------------------------------------------
# Descricao...: Grava num arquivo a query (ORACLE) de consulta da tabela TBSW0058.
#               Sao gerados comandos de inserts das transacoes de pre-autorizacao
#               pendentes no Oracle.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#--------------------------------------------------------------------------------

monta_query_oracle_tbsw0058()
{
    # Por garantia, zera o arquivo que vai receber a query.
    cat /dev/null > ${STR_SQL_COMMAND_ORACLE}

    cat << SQLEOF  > ${STR_SQL_COMMAND_ORACLE}
SET HEADING OFF
SET PAGESIZE 2000
SET LINESIZE 3000
spool ${STR_SQL_COMMAND_POSTGRE}
SELECT
    'INSERT INTO tbsw0058 ' ||
    '   (dat_mov_tran,num_seq_unc,tip_tran,num_mot_rsps,num_estb,cod_term,' ||
    '    num_rd_org,cod_pos_entr_modo,cod_emsr,val_tran,cod_ram_atvd,' ||
    '    num_car,num_aut,val_cot_dlr,dat_vld_car,cod_trk_car,cod_moed,' ||
    '    cod_pais_car,cod_serv_snha,ind_rd_org,cod_mot_aut,dat_pauz,' ||
    '    cod_gru_estb,cod_mtz_estb,dth_ini_tran,dth_sttu_tran,dth_gmt,' ||
    '    num_stan,val_eftv_cptr,qtd_prcl_cnfr,ind_rd_cptr,cod_cndc_cptr,' ||
    '    dat_cnfr_pauz,val_tran_dlr,dat_can_pauz,dat_vld_pauz,nom_port_car,' ||
    '    cod_msg_iso,cod_pcm_iso,nom_site_acqr_orgl,nom_host_acqr_orgl,' ||
    '    nom_fe_acqr_orgl,nom_site_issr, nom_host_issr,nom_fe_issr,' ||
    '    nom_site_acqr_atlz,nom_host_acqr_atlz,nom_fe_acqr_atlz,cod_mot_iso_emsr,' ||
    '    cod_term_cnfr,dat_mov_tran_cnfr,dth_cnfr,ind_rd_org_estr,ind_sttu_tran,' ||
    '    num_emsr,num_estb_cnfr,num_estb_estr,num_id_car,num_seq_unc_cnfr,' ||
    '    num_stan_orgl,cod_bndr,ind_emsr_mtc,num_avso_aut,txt_da_adic_emsr,' ||
    '    nom_fnts_pdv,cod_pgm_aut,ind_nvl_sgra_kmrc,cod_ucaf,cod_aut_emsr_cnvt,' ||
    '    cod_aut_emsr,cod_ntwk_id_acqr_atlz,cod_ntwk_id_acqr_orgl,' ||
    '    cod_ntwk_id_rout_atlz,cod_ntwk_id_rout_orgl,cod_ntwk_id_issr_atlz,' ||
    '    cod_ntwk_id_issr_orgl,cod_ctah_voch,cod_tip_prod_car,num_pdv_ext,' ||
    '    num_pdv_van,cod_gru_clas_ram,num_ref_tran,cod_cpcd_term,' ||
    '    tip_attc_cmc_elet,cod_nvl_sgra,cod_nvl_sgra_orgl,ind_da_tit_car_amzt,' ||
    '    ind_tran_tkn,cod_cpcd_term_vldc_bndr,cod_port_pres_vldc_bndr, cod_prod_mtc,' ||
        '    cod_rgao_mtc, cod_vldc_attc_prto_sgra,id_vers_prto_sgra, cod_hash_prto_sgra, cod_ret_vldc_sgra,cod_crct_tran, cod_pcm_ems, cod_org_aprv, id_ref_bndr ' ||
        ') values  ('  ||
         '''' || DAT_MOV_TRAN || '''' || ',' ||
         '''' || NUM_SEQ_UNC || '''' || ',' ||
         '''' || TIP_TRAN || '''' || ',' ||
         CASE WHEN NUM_MOT_RSPS IS NULL THEN 'NULL' ELSE '''' || NUM_MOT_RSPS || '''' END || ',' ||
         '''' || NUM_ESTB || ''''  || ',' ||
         '''' || COD_TERM || ''''  || ',' ||
         '''' || NUM_RD_ORG || ''''  || ',' ||
         '''' || COD_POS_ENTR_MODO || ''''  || ',' ||
         '''' || COD_EMSR || ''''  || ',' ||
         '''' || VAL_TRAN || ''''  || ',' ||
         '''' || COD_RAM_ATVD || ''''  || ',' ||
         '''' || NUM_CAR || ''''  || ',' ||
         '''' || NUM_AUT || ''''  || ',' ||
         CASE WHEN VAL_COT_DLR IS NULL THEN 'NULL' ELSE '''' || VAL_COT_DLR || '''' END || ',' ||
         '''' || TO_CHAR(DAT_VLD_CAR  ,  'DD-MON-YY HH24:MI:SS') || ''''  || ',' ||
         '''' || COD_TRK_CAR || ''''  || ',' ||
         '''' || COD_MOED || ''''  || ',' ||
         '''' || COD_PAIS_CAR || ''''  || ',' ||
         '''' || COD_SERV_SNHA || ''''  || ',' ||
         '''' || IND_RD_ORG || ''''  || ',' ||
         '''' || COD_MOT_AUT || ''''  || ',' ||
         '''' || TO_CHAR(DAT_PAUZ     ,  'DD-MON-YY HH24:MI:SS') || ''''  || ',' ||
         '''' || COD_GRU_ESTB || ''''  || ',' ||
         '''' || COD_MTZ_ESTB || ''''  || ',' ||
         '''' || TO_CHAR(DTH_INI_TRAN, 'DD-MON-YY HH24:MI:SS') || ''''  || ',' ||
         '''' || TO_CHAR(DTH_STTU_TRAN ,  'DD-MON-YY HH24:MI:SS') || ''''  || ',' ||
         '''' || TO_CHAR(DTH_GMT, 'DD-MON-YY HH24:MI:SS') || ''''  || ',' ||
         '''' || NUM_STAN || ''''  || ',' ||
                 CASE WHEN VAL_EFTV_CPTR IS NULL THEN 'NULL' ELSE '''' || VAL_EFTV_CPTR || '''' END || ',' ||
                 CASE WHEN QTD_PRCL_CNFR IS NULL THEN 'NULL' ELSE '''' || QTD_PRCL_CNFR || '''' END || ',' ||
                 CASE WHEN IND_RD_CPTR IS NULL THEN 'NULL' ELSE '''' || IND_RD_CPTR || '''' END || ',' ||
                 CASE WHEN COD_CNDC_CPTR IS NULL THEN 'NULL' ELSE '''' || COD_CNDC_CPTR || '''' END || ',' ||
                 CASE WHEN DAT_CNFR_PAUZ IS NULL THEN 'NULL' ELSE '''' || TO_CHAR(DAT_CNFR_PAUZ     ,  'DD-MON-YY HH24:MI:SS') || '''' END || ',' ||
                 CASE WHEN VAL_TRAN_DLR IS NULL THEN 'NULL' ELSE '''' || VAL_TRAN_DLR || '''' END || ',' ||
                 CASE WHEN DAT_CAN_PAUZ IS NULL THEN 'NULL' ELSE '''' || TO_CHAR(DAT_CAN_PAUZ      ,  'DD-MON-YY HH24:MI:SS') || '''' END || ',' ||
         '''' || TO_CHAR(DAT_VLD_PAUZ      ,  'DD-MON-YY HH24:MI:SS') || ''''  || ',' ||
                 CASE WHEN NOM_PORT_CAR IS NULL THEN 'NULL' ELSE '''' || NOM_PORT_CAR || '''' END || ',' ||
         '''' || COD_MSG_ISO || ''''  || ',' ||
         '''' || COD_PCM_ISO || ''''  || ',' ||
         '''' || NOM_SITE_ACQR_ORGL || ''''  || ',' ||
         '''' || NOM_HOST_ACQR_ORGL || ''''  || ',' ||
         '''' || NOM_FE_ACQR_ORGL || ''''  || ',' ||
                 CASE WHEN NOM_SITE_ISSR IS NULL THEN 'NULL' ELSE '''' || NOM_SITE_ISSR || '''' END || ',' ||
                 CASE WHEN NOM_HOST_ISSR IS NULL THEN 'NULL' ELSE '''' || NOM_HOST_ISSR || '''' END || ',' ||
                 CASE WHEN NOM_FE_ISSR IS NULL THEN 'NULL' ELSE '''' || NOM_FE_ISSR || '''' END || ',' ||
                 CASE WHEN NOM_SITE_ACQR_ATLZ IS NULL THEN 'NULL' ELSE '''' || NOM_SITE_ACQR_ATLZ || '''' END || ',' ||
                 CASE WHEN NOM_HOST_ACQR_ATLZ IS NULL THEN 'NULL' ELSE '''' || NOM_HOST_ACQR_ATLZ || '''' END || ',' ||
                 CASE WHEN NOM_FE_ACQR_ATLZ IS NULL THEN 'NULL' ELSE '''' || NOM_FE_ACQR_ATLZ || '''' END || ',' ||
                 CASE WHEN COD_MOT_ISO_EMSR IS NULL THEN 'NULL' ELSE '''' || COD_MOT_ISO_EMSR || '''' END || ',' ||
                 CASE WHEN COD_TERM_CNFR IS NULL THEN 'NULL' ELSE '''' || COD_TERM_CNFR || '''' END || ',' ||
                 CASE WHEN DAT_MOV_TRAN_CNFR IS NULL THEN 'NULL' ELSE '''' || DAT_MOV_TRAN_CNFR || '''' END || ',' ||
                 CASE WHEN DTH_CNFR IS NULL THEN 'NULL' ELSE '''' || TO_CHAR(DTH_CNFR          ,  'DD-MON-YY HH24:MI:SS') || '''' END || ',' ||
                 CASE WHEN IND_RD_ORG_ESTR IS NULL THEN 'NULL' ELSE '''' || IND_RD_ORG_ESTR || '''' END || ',' ||
         '''' || IND_STTU_TRAN || ''''  || ',' ||
         '''' || NUM_EMSR || ''''  || ',' ||
                 CASE WHEN NUM_ESTB_CNFR IS NULL THEN 'NULL' ELSE '''' || NUM_ESTB_CNFR || '''' END || ',' ||
                 CASE WHEN NUM_ESTB_ESTR IS NULL THEN 'NULL' ELSE '''' || NUM_ESTB_ESTR || '''' END || ',' ||
                 CASE WHEN NUM_ID_CAR IS NULL THEN 'NULL' ELSE '''' || NUM_ID_CAR || '''' END || ',' ||
                 CASE WHEN NUM_SEQ_UNC_CNFR IS NULL THEN 'NULL' ELSE '''' || NUM_SEQ_UNC_CNFR || '''' END || ',' ||
                 CASE WHEN NUM_STAN_ORGL IS NULL THEN 'NULL' ELSE '''' || NUM_STAN_ORGL || '''' END || ',' ||
         '''' || COD_BNDR || ''''  || ',' ||
         '''' || IND_EMSR_MTC || ''''  || ',' ||
                 CASE WHEN NUM_AVSO_AUT IS NULL THEN 'NULL' ELSE '''' || NUM_AVSO_AUT || '''' END || ',' ||
                 CASE WHEN TXT_DA_ADIC_EMSR IS NULL THEN 'NULL' ELSE '''' || TXT_DA_ADIC_EMSR || '''' END || ',' ||
                 CASE WHEN NOM_FNTS_PDV IS NULL THEN 'NULL' ELSE '''' || NOM_FNTS_PDV || '''' END || ',' ||
                 CASE WHEN COD_PGM_AUT IS NULL THEN 'NULL' ELSE '''' || COD_PGM_AUT || '''' END || ',' ||
                 CASE WHEN IND_NVL_SGRA_KMRC IS NULL THEN 'NULL' ELSE '''' || IND_NVL_SGRA_KMRC || '''' END || ',' ||
                 CASE WHEN COD_UCAF IS NULL THEN 'NULL' ELSE '''' || COD_UCAF || '''' END || ',' ||
                 CASE WHEN COD_AUT_EMSR_CNVT IS NULL THEN 'NULL' ELSE '''' || COD_AUT_EMSR_CNVT || '''' END || ',' ||
                 CASE WHEN COD_AUT_EMSR IS NULL THEN 'NULL' ELSE '''' || COD_AUT_EMSR || '''' END || ',' ||
                 CASE WHEN COD_NTWK_ID_ACQR_ATLZ IS NULL THEN 'NULL' ELSE '''' || COD_NTWK_ID_ACQR_ATLZ || '''' END || ',' ||
                 CASE WHEN COD_NTWK_ID_ACQR_ORGL IS NULL THEN 'NULL' ELSE '''' || COD_NTWK_ID_ACQR_ORGL || '''' END || ',' ||
                 CASE WHEN COD_NTWK_ID_ROUT_ATLZ IS NULL THEN 'NULL' ELSE '''' || COD_NTWK_ID_ROUT_ATLZ || '''' END || ',' ||
                 CASE WHEN COD_NTWK_ID_ROUT_ORGL IS NULL THEN 'NULL' ELSE '''' || COD_NTWK_ID_ROUT_ORGL || '''' END || ',' ||
                 CASE WHEN COD_NTWK_ID_ISSR_ATLZ IS NULL THEN 'NULL' ELSE '''' || COD_NTWK_ID_ISSR_ATLZ || '''' END || ',' ||
                 CASE WHEN COD_NTWK_ID_ISSR_ORGL IS NULL THEN 'NULL' ELSE '''' || COD_NTWK_ID_ISSR_ORGL || '''' END || ',' ||
                 CASE WHEN COD_CTAH_VOCH IS NULL THEN 'NULL' ELSE '''' || COD_CTAH_VOCH || '''' END || ',' ||
         '''' || COD_TIP_PROD_CAR || ''''  || ',' ||
                 CASE WHEN NUM_PDV_EXT IS NULL THEN 'NULL' ELSE '''' || NUM_PDV_EXT || '''' END || ',' ||
                 CASE WHEN NUM_PDV_VAN IS NULL THEN 'NULL' ELSE '''' || NUM_PDV_VAN || '''' END || ',' ||
         '''' || COD_GRU_CLAS_RAM || ''''  || ',' ||
         '''' || NUM_REF_TRAN || ''''  || ',' ||
         '''' || COD_CPCD_TERM || ''''  || ',' ||
         '''' || TIP_ATTC_CMC_ELET || ''''  || ',' ||
         '''' || COD_NVL_SGRA || ''''  || ',' ||
         '''' || COD_NVL_SGRA_ORGL || ''''  || ',' ||
         '''' || IND_DA_TIT_CAR_AMZT || ''''  || ',' ||
         CASE WHEN IND_TRAN_TKN IS NULL THEN 'NULL' ELSE '''' || IND_TRAN_TKN || '''' END || ',' ||
                 CASE WHEN COD_CPCD_TERM_VLDC_BNDR IS NULL THEN 'NULL' ELSE '''' || COD_CPCD_TERM_VLDC_BNDR || '''' END || ',' ||
                 CASE WHEN COD_PORT_PRES_VLDC_BNDR IS NULL THEN 'NULL' ELSE '''' || COD_PORT_PRES_VLDC_BNDR || '''' END || ',' ||
                 CASE WHEN COD_PROD_MTC IS NULL THEN 'NULL' ELSE '''' || COD_PROD_MTC || '''' END || ',' ||
                 CASE WHEN COD_RGAO_MTC IS NULL THEN 'NULL' ELSE '''' || COD_RGAO_MTC || '''' END || ',' ||
                 CASE WHEN COD_VLDC_ATTC_PRTO_SGRA IS NULL THEN 'NULL' ELSE '''' || COD_VLDC_ATTC_PRTO_SGRA || '''' END || ',' ||
                 CASE WHEN ID_VERS_PRTO_SGRA IS NULL THEN 'NULL' ELSE '''' || ID_VERS_PRTO_SGRA || '''' END || ',' ||
                 CASE WHEN COD_HASH_PRTO_SGRA IS NULL THEN 'NULL' ELSE '''' || COD_HASH_PRTO_SGRA || '''' END || ',' ||
                 CASE WHEN COD_RET_VLDC_SGRA IS NULL THEN 'NULL' ELSE '''' || COD_RET_VLDC_SGRA || '''' END || ',' ||
                 CASE WHEN COD_CRCT_TRAN IS NULL THEN 'NULL' ELSE '''' || COD_CRCT_TRAN || '''' END || ',' ||
                 CASE WHEN COD_PCM_EMS IS NULL THEN 'NULL' ELSE '''' || COD_PCM_EMS || '''' END  || ',' ||
                 '''' || COD_ORG_APRV || '''' || ',' ||
                 CASE WHEN ID_REF_BNDR IS NULL THEN 'NULL' ELSE '''' || ID_REF_BNDR || '''' END
                 || ');'        as insert_postgre
FROM
    TBSW0058
WHERE
    IND_RD_ORG = '3' and IND_STTU_TRAN = '0'
SQLEOF

    # Chama a funcao que adiciona filtros a query, baseadas em condicoes de data e hora.
    ${strFuncaoDeSelect}

    echo "/"   >> ${STR_SQL_COMMAND_ORACLE}
    echo "QUIT" >> ${STR_SQL_COMMAND_ORACLE}

        # backup do aquivo para analise deve ficar comentado em produção/homologação
        #cp ${STR_SQL_COMMAND_ORACLE} ${STR_SQL_COMMAND_ORACLE}.insert.${intHora}.${intDataHoraExtracaoLoop}.bkp

    echo $STR_LOG_FILE $STR_SCRIPT_NAME "SELECT DO ORACLE PARA GERAÇÃO DOS INSERTS" >> $STR_LOG_FILE
        cat ${STR_SQL_COMMAND_ORACLE} >> $STR_LOG_FILE

    return 0
} # Fim da funcao monta_query_oracle_tbsw0058


#-----------------------------------------------------------------------------
# Descricao...: Grava num arquivo a query (Oracle) de consulta da tabela TBSW0058.
#               Sao gerados comandos de update para invalidar com "IND_STTU_TRAN = 'X'"
#               as transacoes de pre-autorizacao pendentes no Aurora.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

monta_query_oracle_tbsw0058_confirmadas()
{
    # Por garantia, zera o arquivo que vai receber a query.
    cat /dev/null > ${STR_SQL_COMMAND_ORACLE}

    cat << SQLEOF  > ${STR_SQL_COMMAND_ORACLE}
SET HEADING OFF
SET PAGESIZE 2000
SET LINESIZE 3000
spool ${STR_SQL_COMMAND_POSTGRE}
SELECT
   'UPDATE tbsw0058 SET ind_sttu_tran =' || '''X''' ||
   ', dth_sttu_tran = CURRENT_DATE ' ||
   ' WHERE nom_fe_acqr_orgl =' || '''75POS''' ||
   ' AND ind_sttu_tran = ' || '''0'''  ||
   ' AND dat_mov_tran= ' || '''' || DAT_MOV_TRAN || ''''  ||
   ' AND num_seq_unc=' || '''' || NUM_SEQ_UNC || '''' || ';'
FROM
    TBSW0058
WHERE
    IND_RD_ORG = '3' and IND_STTU_TRAN in ('1', '3', '4')
SQLEOF


    # Chama a funcao que adiciona filtros a query, baseadas em condicoes de data e hora.
    ${strFuncaoDeUpdate}

    echo "/"   >> ${STR_SQL_COMMAND_ORACLE}
    echo "QUIT" >> ${STR_SQL_COMMAND_ORACLE}

        # backup do aquivo para analise deve ficar comentado em produção/homologação
        #cp ${STR_SQL_COMMAND_ORACLE} ${STR_SQL_COMMAND_ORACLE}.update.${intHora}.${intDataHoraExtracaoLoop}.bkp

    echo $STR_LOG_FILE $STR_SCRIPT_NAME "SELECT DO ORACLE PARA GERAÇÃO DOS UPDATES" >> $STR_LOG_FILE
        cat ${STR_SQL_COMMAND_ORACLE} >> $STR_LOG_FILE
    return 0
} # Fim da funcao monta_query_oracle_tbsw0058_confirmadas


#-----------------------------------------------------------------------------
# Descricao...: Grava num arquivo a query (ORACLE) de consulta da TBSW0058
#               com o total de transacoes de pre-autorizacao encontradas.
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

monta_query_oracle_tbsw0058_totalizacao()
{
    # Por garantia, zera o arquivo que vai receber a query.
    cat /dev/null > ${STR_SQL_COMMAND_ORACLE}

    cat << SQLEOF  > ${STR_SQL_COMMAND_ORACLE}
SET HEADING OFF
spool ${STR_SQL_COMMAND_POSTGRE}
SELECT  count(*) FROM TBSW0058
WHERE
    IND_RD_ORG = '3' and IND_STTU_TRAN = '0'
SQLEOF

    # Chama a funcao que adiciona filtros a query, baseadas em condicoes de data e hora.
    ${strFuncaoDeSelect}

    echo "/"   >> ${STR_SQL_COMMAND_ORACLE}
    echo "QUIT" >> ${STR_SQL_COMMAND_ORACLE}

        # backup do aquivo para analise deve ficar comentado em produção/homologação
        #cp ${STR_SQL_COMMAND_ORACLE} ${STR_SQL_COMMAND_ORACLE}.totalizacao.${intHora}.${intDataHoraExtracaoLoop}.bkp

    echo $STR_LOG_FILE $STR_SCRIPT_NAME "SELECT DO ORACLE PARA CONTAGEM DOS INSERTS" >> $STR_LOG_FILE
        cat ${STR_SQL_COMMAND_ORACLE} >> $STR_LOG_FILE

    return 0
} # Fim da funcao monta_query_oracle_tbsw0058_totalizacao

#-----------------------------------------------------------------------------
# Descricao...: Executa a conexao com o ORACLE, faz o SELECT das transacoes de
#               pre-autorizacao pendentes realizadas SW 7.5 e as grava num arquivo
#               que serah utilizado para inseri-las posteriormente no POSTGRE (SW 7.7).
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

extrai_regs_oracle_tbsw0058() {

    # REMOVE o arquivo de "inserts" no Oracle (se houver) para garantir
    # que n�o serao incluidos registros desatualizados na chamada ao Oracle.
    rm -f ${STR_SQL_COMMAND_POSTGRE}

    $ORACLE_HOME/bin/sqlplus ${STR_DB_USER_ORACLE}/${STR_DB_ARQPWD_ORACLE}@$STR_BD_DB_NAME_ORACLE @${STR_SQL_COMMAND_ORACLE} >> ${STR_LOG_FILE} 2>&1

    intVarErr=$?

    echo $STR_LOG_FILE $STR_SCRIPT_NAME "   Return Code da execucao do sqlplus Oracle = [${intVarErr}] " >> ${STR_LOG_FILE}

    if [ "${intVarErr}" != "0" ]; then
        echo $STR_LOG_FILE $STR_SCRIPT_NAME "   ERRO na execucao sqlplus do Oracle. Abortando execucao do script!" >> ${STR_LOG_FILE}
        exit 1
    fi

        sed -i '/rows selected/d' ${STR_SQL_COMMAND_POSTGRE}

        # backup do aquivo para analise deve ficar comentado em produção/homologação
        #cp ${STR_SQL_COMMAND_POSTGRE} ${STR_SQL_COMMAND_POSTGRE}.${EXECUCAO}.${intHora}.${intDataHoraExtracaoLoop}.bkp

    return 0

}  # fim da funcao "extrai_regs_oracle_tbsw0058"


#-----------------------------------------------------------------------------
# Descricao...: Executa a conexao com o POSTGRE (SW 7.7) e grava as transacoes de
#               pre-autorizacao pendentes previamente selecionadas no oracle (SW 7.5).
# Parametros..: Sem parametros de entrada
# Retornos....: Sem retornos
#-----------------------------------------------------------------------------

insere_regs_postgre_tbsw0058() {

#       psql "dbname='dbunica' user='$STR_DB_USER_POSTGRE' password='$STR_DB_PWD_POSTGRE' host='capt-unica-sa.cluster-cz6jwnryepdv.sa-east-1.rds.amazonaws.com'" -f "$STR_SQL_COMMAND_POSTGRE"  >> ${STR_LOG_FILE} 2>&1
        psql "dbname='$STR_BD_NAME_POSTGRE' user='$STR_DB_USER_POSTGRE' password='$STR_DB_PWD_POSTGRE' host='$STR_BD_HOST_POSTGRE'" -f "$STR_SQL_COMMAND_POSTGRE"  >> ${STR_LOG_FILE} 2>&1
     intVarErr=$?

    echo $STR_LOG_FILE $STR_SCRIPT_NAME "   Return Code da execucao do psql do Aurora = [${intVarErr}] " >>  ${STR_LOG_FILE}

    if [ "${intVarErr}" != "0" ]; then
        echo $STR_LOG_FILE $STR_SCRIPT_NAME "   ERRO na execucao do psql Aurora. Abortando execucao do script!" >>  ${STR_LOG_FILE}
        exit 1
    fi

    return 0

}  # fim da funcao "insere_regs_postgre_tbsw0058"


#############################################################################################
#               "MAIN" do script  "replic_preaut.sh"                                        #
#############################################################################################

trap finaliza_script HUP INT QUIT KILL TERM STOP

#
# Instanciando variaveis
#
STR_THIS_FILE=`basename $0`
STR_THIS_FILE_PREFIX=`basename $0 .sh`
STR_SCRIPT_NAME=${STR_THIS_FILE}
STR_CONFIG_FILE="${HOME}/site/${FE}/cfg/${STR_THIS_FILE_PREFIX}.cfg"
STR_LOG_FILE="${HOME}/site/${FE}/log/sys/$STR_THIS_FILE_PREFIX.log"

STR_SQL_COMMAND_POSTGRE="${OTMPDIR}/${STR_THIS_FILE_PREFIX}_postgre.sql"
STR_SQL_COMMAND_ORACLE="${OTMPDIR}/${STR_THIS_FILE_PREFIX}_oracle.sql"

STR_HOSTNAME_77=`hostname`

# Usuario do POS Oracle
STR_DB_USER_ORACLE=`get_db_user /online/oracle/SW75/POS`
STR_DB_ARQPWD_ORACLE=`get_db_password /online/oracle/SW75/POS`
STR_BD_DB_NAME_ORACLE=`get_db_name /online/oracle/SW75/POS`

# Usuario do POS PostgreSql
STR_DB_USER_POSTGRE=`get_db_user /online/postgresql/baseunica/${AZ}`
STR_DB_PWD_POSTGRE=`get_db_password /online/postgresql/baseunica/${AZ}`
STR_BD_NAME_POSTGRE=`get_db_name /online/postgresql/baseunica/${AZ}`
STR_BD_HOST_POSTGRE=`get_db_host /online/postgresql/baseunica/${AZ}`
EXECUCAO=0

if [ "${1}" == "" ]; then
        STR_INI_HORA=0530
else
        if [ "${1}" == "H" ]; then
                STR_TRIGGER_HORA="HORA"            # Teve que usar outra variavel senao IF -gt da erro
                STR_INI_HORA=$(date "+%H%M")       # Poe Data/Atual para Nao gerar erro no if -gt
                STR_FIM_HORA=$(date "+%H%M")       # Poe Data/Atual para Nao gerar erro no if -gt
        else
                STR_INI_HORA=${1}
        fi
fi

if [ "${2}" == "" ]; then
        STR_FIM_HORA=0545
else
        if [ "${STR_FIM_HORA}" == "" ]; then
                STR_FIM_HORA=${2}
        fi
fi

header_inicio_script

imprime_parametros

while true
do
        intHora=$(date "+%H%M")

        echo $STR_LOG_FILE $STR_SCRIPT_NAME "##### INICIANDO EXECUCAO  #####" >> $STR_LOG_FILE

        syslgsend "${STR_SCRIPT_NAME} - Aguardando nova Execucao"

        if [ "${intHora}" -gt "${STR_INI_HORA}" ] && [ "${intHora}" -lt "${STR_FIM_HORA}" ] || [ "${STR_TRIGGER_HORA}" == "HORA" ]; then
                # Obtem a data e hora atual (YYYYMMDDHHMMSS) e subtrai uma hora para poder extrair
                # as transacoes realizadas na hora anterior (ou ate a hora anterior).
                # Estah sendo usado o Perl, pois com ele eh possivel fazer aritmetica com datas de forma mais direta.

                intDataHoraExtracaoLoop=`perl -MPOSIX=strftime -e 'print strftime("%Y%m%d%H%M%S", localtime(time() - 3600))'`

                # Define a data e a hora que marcam o fim da extracao. Essa data/hora eh calculada no momento da execucao do loop.
                intDataFimExtracao=`echo ${intDataHoraExtracaoLoop} | cut -c1-8`
                intHoraHhExtracaoLoop=`echo ${intDataHoraExtracaoLoop} | cut -c9-10`
                intHoraFimExtracao=`echo ${intHoraHhExtracaoLoop}`5959

                if [ -f ${STR_CONFIG_FILE} ]
                then
                intDataArqCfg=`head -1 ${STR_CONFIG_FILE} | awk '{print $1}'`
                        intHoraArqCfg=`head -1 ${STR_CONFIG_FILE} | awk '{print $2}'`
                        export intCfgSec=`echo ${intHoraArqCfg}  | cut -c5-6`
                        export intCfgMin=`echo ${intHoraArqCfg}  | cut -c3-4`
                        export intCfgHour=`echo ${intHoraArqCfg} | cut -c1-2`
                        export intCfgDay=`echo ${intDataArqCfg}  | cut -c7-8`
                        export intCfgMon=`echo ${intDataArqCfg}  | cut -c5-6`
                        export intCfgYear=`echo ${intDataArqCfg} | cut -c1-4`

                        # No arquivo de controle fica registrada a data/hora da ultima extracao feita.
                        # intDataHoraExtracaoArqCfg, intDataExtracaoArqCfg e intHoraHhExtracaoArqCfg
                        # referem-se a proxima hora de extracao, calculada pelo arquivo de controle.
                        intDataHoraExtracaoArqCfg=`perl -MPOSIX=strftime -MTime::Local=timelocal -e 'print strftime("%Y%m%d%H%M%S", \
                                        localtime(timelocal($ENV{intCfgSec},$ENV{intCfgMin},$ENV{intCfgHour},$ENV{intCfgDay},$ENV{intCfgMon}-1,$ENV{intCfgYear})+3600)), "\n"'`
                        intDataExtracaoArqCfg=`echo ${intDataHoraExtracaoArqCfg} | cut -c1-8`
                        intHoraHhExtracaoArqCfg=`echo ${intDataHoraExtracaoArqCfg} | cut -c9-10`
                        intDataInicioExtracao=${intDataExtracaoArqCfg}
                        intHoraInicioExtracao=`echo ${intHoraHhExtracaoArqCfg}`0000

                        if [ "${intDataArqCfg}" -eq "${intDataFimExtracao}" ] && [ "${intHoraArqCfg}" -eq "${intHoraFimExtracao}" ]
                        then
                                # Nao deve fazer nada, pois a data do arquivo eh a extracao mais recente.
                                # Fazer com que a execucao das queries NAO retorne nada.
                                echo $STR_LOG_FILE $STR_SCRIPT_NAME "A data/hora da ultima extracao jah eh a mais recente. Nao ha nada a extrair agora." >> $STR_LOG_FILE
                                echo $STR_LOG_FILE $STR_SCRIPT_NAME "    (obs.: gerando condicao de query nula para nao extrair nenhum registro." >> $STR_LOG_FILE
                                strFuncaoDeSelect="add_condicao_select_vazio"
                                strFuncaoDeUpdate="add_condicao_update_vazio"
                        else
                                if [ ${intDataExtracaoArqCfg} -eq ${intDataFimExtracao} ]
                                then
                                        # As datas de extracao do arquivo e a data calculada no loop sao iguais.
                                        echo $STR_LOG_FILE $STR_SCRIPT_NAME "Extraindo registros da mesma data: [${intDataFimExtracao}]" >> $STR_LOG_FILE
                                        strFuncaoDeSelect="add_condicao_select_dia_atual"
                                        strFuncaoDeUpdate="add_condicao_update_dia_atual"
                                else
                                        # A data da ultima extracao eh diferente da data atual, entao seleciona um range maior de data/hora.
                                        echo $STR_LOG_FILE $STR_SCRIPT_NAME "Extraindo regs. em um range de datas: [${intDataInicioExtracao}] - [${intDataFimExtracao}]" >> $STR_LOG_FILE
                                        strFuncaoDeSelect="add_condicao_select_range_dias"
                                        strFuncaoDeUpdate="add_condicao_update_range_dias"
                                fi
                        fi
                else
                        # Se o arquivo ainda nao existe entao deve ser feita uma busca de TODAS as transacoes pendentes.
                        echo $STR_LOG_FILE $STR_SCRIPT_NAME "Nao foi encontrado o arquivo com a data da ultima extracao. Entao serah usada " >> $STR_LOG_FILE
                        echo $STR_LOG_FILE $STR_SCRIPT_NAME "    uma condicao de query para extrair todas as pre-autorizacoes pendentes."    >> $STR_LOG_FILE
                        strFuncaoDeSelect="add_condicao_select_geral"
                        strFuncaoDeUpdate="add_condicao_update_vazio"
                fi

                echo $STR_LOG_FILE $STR_SCRIPT_NAME "------------------------------------------------------------------" >> $STR_LOG_FILE
                echo $STR_LOG_FILE $STR_SCRIPT_NAME "Data Inicio Extracao: [${intDataInicioExtracao}]  -  Hora Inicio Extracao: [${intHoraInicioExtracao}]" >> $STR_LOG_FILE
                echo $STR_LOG_FILE $STR_SCRIPT_NAME "Data Fim Extracao...: [${intDataFimExtracao}]  -  Hora Fim Extracao...: [${intHoraFimExtracao}]" >> $STR_LOG_FILE

                # Extracao dos regs. da tabela TBSW0058 do ORACLE SW75
                echo $STR_LOG_FILE $STR_SCRIPT_NAME "Extracao dos regs. da tabela TBSW0058 do ORACLE SW75" >> $STR_LOG_FILE
                monta_query_oracle_tbsw0058
                extrai_regs_oracle_tbsw0058

                # Insercao dos regs. na tabela TBSW0058 do AURORA SW77
                echo $STR_LOG_FILE $STR_SCRIPT_NAME "Insercao dos regs. na tabela TBSW0058 do ORACLE SW75 " >> $STR_LOG_FILE
                insere_regs_postgre_tbsw0058

                # Identifica a quantidade de registros que pre-autorizacao que foram encontrados NO oracle SW75.
                monta_query_oracle_tbsw0058_totalizacao
                extrai_regs_oracle_tbsw0058
                intRegsExtraidos=`sed -n 2p  ${STR_SQL_COMMAND_POSTGRE}`
                echo $STR_LOG_FILE $STR_SCRIPT_NAME "TOTAL de transacoes PRE-AUT Pendentes extraidas do POS SW75....: ${intRegsExtraidos}" >> $STR_LOG_FILE

                # Coletando trxs. PREAUT (confirmadas, desfeitas, estornadas) na TBSW0058 do ORACLE SW75
                echo $STR_LOG_FILE $STR_SCRIPT_NAME "Coletando trxs. PREAUT (confirmadas, desfeitas, estornadas) na TBSW0058 do ORACLE SW75 " >> $STR_LOG_FILE
                monta_query_oracle_tbsw0058_confirmadas
                extrai_regs_oracle_tbsw0058

                # Marca as trxs. PREAUT (confirmadas, desfeitas, estornadas) na tbsw0058 do Auroa
                echo $STR_LOG_FILE $STR_SCRIPT_NAME "Marca as trxs. PREAUT (confirmadas, desfeitas, estornadas) na tbsw0058 do Auroa" >> $STR_LOG_FILE
                insere_regs_postgre_tbsw0058

                # Grava Data e Hora da ultima extracao no arquivo de controle, no formato "YYYYMMDD HHMMSS"
                echo "${intDataFimExtracao} ${intHoraFimExtracao}" > ${STR_CONFIG_FILE}

                if [ "${STR_TRIGGER_HORA}" == "HORA" ]; then
                        intMinutoAtual=$(date "+%M")
                        intSegundotual=$(date "+%S")
                        intVarSleep=$(( (65 - ${intMinutoAtual}) * 60 - ${intSegundotual} ))
                        echo $STR_LOG_FILE $STR_SCRIPT_NAME "intVarSleep="$intVarSleep >> $STR_LOG_FILE
                else
                        intDataAmanha=`perl -MPOSIX=strftime -e 'print strftime("%Y%m%d", localtime(time() + ( 3600 * 23 )))'`"${STR_INI_HORA}00"
                        intDataAtual=`perl -MPOSIX=strftime -e 'print strftime("%Y%m%d%H%M%S", localtime(time()))'`
                        intVarSleep=$(( ${intDataAmanha} - ${intDataAtual} ))    ## Aguardar 23 horas antes de comecar novo ciclo
                        echo $STR_LOG_FILE $STR_SCRIPT_NAME "##### De ${intDataAtual} ate ${intDataAmanha} tem ${intVarSleep} #####"
                fi
        else
                intVarSleep=600
        fi

    ###
    # Ajusta o "sleep time" para executar a rotina sempre �s hh:05:00 hs.
    # intVarSleep = [ (1 hora = 60 min) + (5 min) - (minuto atual) ] * (60 segundos) - segundo_atual
    ###

    echo $STR_LOG_FILE $STR_SCRIPT_NAME "##### AGUARDANDO PROXIMA EXEC EM ${intVarSleep} SEGUNDOS #####" >> $STR_LOG_FILE

        syslgsend "${STR_SCRIPT_NAME} - Aguardando Prox Exec em ${intVarSleep} segundos"

    sleep ${intVarSleep}

done

finaliza_script
exit 0
