# © Copyright [2016] Rede S.A.
#!/bin/ksh
#
# Fonte: SHSW089D.sh (antigo backup_logs)
# Autor: Igor Oliveira / Data: 21/08/2007
# Descricao: Limpa log e arquivos de backup
#            Os arquivos de backup vao para o diretorio $OLOGDIR/backup
# Exemplo: SHSW089D.sh FE
#          FE = HST, DBT ou CRT
#
# $Log $
# 07/08/2013 - Inclusao de tratamento para o FE-PDV no SW 75 - Davi Bariani Boin
# 31/10/2013 - Inclusao de tratamento para o FE-POS no SW 75 - Francine
# 15/05/2014 - Inclusao do backup do arquivo logtcphipdeb.log
# 12/07/2014 - Inclusão do projeto DCMM - Afinidades - ERICO MATTOS
#
####################### MODIFICAÇÕES ########################
# Autor    : ERICO MATTOS
# Data     : 2014-07-17
# Empresa  : BSI
# Descrição: DCMM - Afinidades
# ID       : XXXXX - [PROGRAMA DCMM] - SISTEMAS - PM14 - ADEQUAÇÃO APLICAÇÕES - AFINIDADES
#############################################################
# Autor    : Fabio Mazzer
# Data     : 16/02/2015
# Empresa  : Rede
# Descrição: Multicaptura ELO
# ID       : 91915 - SW Multicaptura ELO
#############################################################
# Autor    : Igor Oliveira
# Data     : 28/07/2015
# Empresa  : Stefanini
# Descrição: Inclusao dos logs para Nova Bandeira
# ID       : ID_106004 - Nova Bandeira Mastercard Itau
#############################################################
# Autor    : Igor Oliveira
# Data     : 31/08/2015
# Empresa  : Stefanini
# Descrição: Remocao dos logs do VB Beneficio
# ID       : 126251 - Desligamento Parceiro VB Beneficios
#############################################################
# Historico de alteracoes:
# Autor: Renato de Camargo
# Data : 26/Jan/2016
# Empresa: Rede
# Descrição: Preparacao do ambiente de Captura para o CTMM - Maquinas SW437 a SW443
# ID : AM 137.268
#############################################################
# Autor    : Igor Oliveira
# Data     : 15/01/2016
# Empresa  : Stefanini
# Descrição: Inclusao dos logs para Voucher Alelo
# ID       : 145448 - Multivan Alelo
#############################################################
# Autor    : Igor Oliveira
# Data     : 20/01/2016
# Empresa  : Stefanini
# Descrição: Inclusao dos logs para JCB, Bansecard, VR e Credz
# ID       : 146913 - Programa de Captura de Bandeiras
#############################################################
# Autor    : Ana Carolina Dias Silva
# Data     : 18/11/2016
# Empresa  : Rede
# Descricao: 0230_SW - Criacao de Links LOG TCP
# ID       : 181.389, AM181.394
#############################################################
# Descricao: Inclusao de LOGs TCP CRTO e DBTO
# Autor    : Renato de Camargo
# Data     : 22/11/2016
# Empresa  : Rede
#############################################################
# Autor    : Paulo A. Pieretti
# Data     : 27/03/2017
# Empresa  : Leega
# Descricao: Alteracoes feitas para adequar os nomes das funcoes do POS e PDV a inspecao de codigos.
# ID       : 30352  - AM 172.953
#############################################################
# Descricao: Correcao de Limpeza dos arquivos de acerto
# Autor    : Guilherme Sanches
# Data     : 12/09/2017
# Empresa  : Rede
#############################################################
# Descricao: Inclusao de logs do FEPOS
# Autor    : Fabio Augusto Mazzer
# Data     : 08/11/2017
# Empresa  : Rede
#############################################################
# Autor    : Ana Carolina Dias Silva
# Data     : 28/02/2018
# Empresa  : Rede
# Descrição: 0752_SW - Acerto rotina SHSW089D.sh
# ID       : BIP 221.134
##############################################################
# Autor    : Mauro Thiago da Silva
# Data     : 25/09/2018
# Empresa  : Rede
# Descrição: Inclusao TPDU INAC
# ID       : AM 228120
##############################################################
# Autor    : Eduardo De Souza
# Data     : 05/10/2018
# Empresa  : Rede
# Descrição: Inclusão log tcpip do POSIP descriptografado
# ID       : AM 225.800
##############################################################
# Autor    : Andre Morishita
# Data     : 07/02/2019
# Empresa  : Leega
# Descrição: Inclusão log tcpip do ITI
# ID       : AM 243022
##############################################################
# Autor    : Igor Oliveira
# Data     : 01/04/2019
# Empresa  : Leega
# Descrição: Inclusão log tcpip do SFORZA
# ID       : J5_2019
##############################################################
# Autor    : Romario Barbosa
# Data     : 07/06/2019
# Empresa  : Rede
# Descrição: Inclusão Backup DLSW97 DBTM
# ID       : AM 238.555
##############################################################
# Autor    : Andre Morishita
# Data     : 05/09/2019
# Empresa  : Leega
# Descrição: Inclusão Backup flsw0034_XXX
# ID       : AM 233.883
##############################################################
# Autor    : James Cooley
# Data     : 16/03/2020
# Empresa  : Rede
# Descricao: Alteracao do protocolo ftp para Sftp, utilizando o script executa_sft
# ID       : AM 262.077
##############################################################
# Autor    : Renato de Camargo
# Data     : 28/05/2020
# Empresa  : Rede
# Descricao: Alteracao arquivos do PDV
# ID       : AM 262.077
##############################################################
# Autor    : Andre Morishita
# Data     : 23/10/2020
# Empresa  : Leega
# Descrição: Inclusão Backup rdcmp
# ID       : Hub de Bandeiras
##############################################################
# Autor    : Davi Ferreira
# Data     : 17/12/2020
# Empresa  : Rede
# Descricao: Adequação para AWS (troca de bzip e compress para gzip, troca de ftp para s3 e remoção de código)
# ID       : 
##############################################################

. ${GEN_ROOT}/shell/swvars.sh

# testa o número de parâmetros. Caso seja menor que 2 (-lt => less than) entra no IF
if [ $# -lt 1 ]
then

   # Imprime o nome do script "$0" (isso eh bom para tornar um template de script) e como usá-lo
   echo "usar $0 [POS|PDV]"

   # Sai do script com código de erro 1 (falha)
   exit 1

fi


#######################
#######################
# Rotina de gravacao de log
# Parametros:
#       $1 = Caminho/nome do arquivo de log
#       $2 = Nome do script chamador da funcao
#       $3 = Mensagem de erro
# Exemplo: SHELL_LOG $SW_ROOT/tmp/arq_log.txt SHSW0010.sh "Erro ao apagar lock"
SHELL_LOG()
{
        SHLOG="$1"
        SHJOB="$2"
        SHMSG="$3"
        SHDATAHOJE=`date "+%d/%m/%Y %H:%M:%S"`
        echo "$SHDATAHOJE $SHJOB $SHMSG" >> $SHLOG
}
######################
######################
# Guarda ultimas 3000 linhas no log
# Parametros:
#       $1 = Caminho/nome do arquivo de log
# Exemplo: SALVA_LINHAS_LOG $SW_ROOT/tmp/arq_log.txt
SALVA_LINHAS_LOG()
{
        SHLOG="$1"
        if [ -f $SHLOG ]
        then
                SHTMP=$SHLOG.lixo
                tail -3000 $SHLOG > $SHTMP
                mv $SHTMP $SHLOG
        else
                cat /dev/null > $SHLOG
        fi
        chmod 664 $SHLOG
}
YesterdayDOW ()
{
    DAY=`date +%a`
    case $DAY in
        "Sun") YDAY="Sat" ;;
        "Mon") YDAY="Sun" ;;
        "Tue") YDAY="Mon" ;;
        "Wed") YDAY="Tue" ;;
        "Thu") YDAY="Wed" ;;
        "Fri") YDAY="Thu" ;;
        "Sat") YDAY="Fri" ;;
    esac

    echo $YDAY
}

ExtractWeekDay ()
{
    if [ $1 = "" ] || [ $1 = "0" ]
    then
        #Get yesterday
        WeekDay=`YesterdayDOW`
    else
        #Get extract day
        hour=`date "+%H%M"`
        echo Yesterday $SW_ROOT/GEN/bin/dateadd -D$1 -H$hour -f"%Y%m%d" -1d
        echo WeekDay   $SW_ROOT/GEN/bin/dateadd -D$Yesterday -H$hour -f"%a" +1d
        Yesterday=`$SW_ROOT/GEN/bin/dateadd -D$1 -H$hour -f"%Y%m%d" -1d`
        WeekDay=`$SW_ROOT/GEN/bin/dateadd -D$Yesterday -H$hour -f"%a" +1d`
    fi

    echo $WeekDay
}

#
# Main code begins here
#
AMBIENTE=$(/usr/local/bin/aws ssm get-parameter --name "ambiente" --region $REGION --output text | awk '{ print $7 }')

strBucketS3=s3://sw7-online-backuplog-${AMBIENTE}

MASK_LOGS=""
LOGS_POS="logtcpposmtg.log logtcppdvdialmtg.log logtcppostg.log logtcpposip.log logtcpposqh.log logtcppdvdialtg.log logtcpcielo.log logtcpgetnet.log logtcpposipdec.log logtcpposwq3.log"
LOGS_POSNMASK="logtcpposcrt.log.debug logtcpposcrtm.log.debug logtcpposcrto.log.debug logtcpposdbt.log.debug logtcpposdbtm.log.debug logtcpposdbto.log.debug logtcpposhst.log.debug logtcppospixjson.log.debug"

LOGS_PDV="logtcpinac1.log.debug"
LOGS_PDVNMASK="logtcppdvcrtjson.log.debug logtcppdvcrtmjson.log.debug logtcppdvcrtojson.log.debug logtcppdvdbtjson.log.debug logtcppdvdbtmjson.log.debug logtcppdvdbtojson.log.debug logtcppdvhstjson.log.debug"


HOSTNAME=`hostname`
LOGS_AIX="Linuxsyslg.log"
if [ $1 = "POS" ]
then
	# rcamargo - execucao do .swloadenv  do FE-POS
    . swloadenv POS > /dev/null
    MASK_LOGS=$LOGS_POS
    NMASK_LOGS=$LOGS_POSNMASK

elif [ $1 = "PDV" ]
then
    . swloadenv PDV > /dev/null
    MASK_LOGS=$LOGS_PDV
    NMASK_LOGS=$LOGS_PDVNMASK
else
   echo "usar $0 [POS|PDV]"
   exit 2
fi

# rcamargo - log do Front-End no proprio FE
LOGERR=${OLOGDIR}/sys/SHSW089D.sh.txt
SHSWNAME=SHSW089D-$1.sh

DEBUGDIR=$OLOGDIR/debug
SYSDIR=$OLOGDIR/sys
SYSMASKDIR=$OLOGDIR/sys/tcp
BACKUPDIR=$OLOGDIR/backup
BACKUPMASKDIR=$OLOGDIR/backup/tcp
echo 
echo LOGERR       =$LOGERR
echo DEBUGDIR     =$OLOGDIR/debug
echo SYSDIR       =$OLOGDIR/sys
echo SYSMASKDIR   =$OLOGDIR/sys/tcp
echo BACKUPDIR    =$OLOGDIR/backup
echo BACKUPMASKDIR=$OLOGDIR/backup/tcp
echo 

SALVA_LINHAS_LOG $LOGERR

SHELL_LOG $LOGERR $SHSWNAME "-------------------------------------------------------------------"
SHELL_LOG $LOGERR $SHSWNAME "Iniciando backup do FE-$1"

#
#  Clear debug files moving to backup dir
#

SHELL_LOG $LOGERR $SHSWNAME "Removendo todos os arquivos gz do backup"
rm -f $BACKUPDIR/*.gz
rm -f $BACKUPDIR/*.tmp
rm -f $BACKUPDIR/tcp/*

SHELL_LOG $LOGERR $SHSWNAME "Iniciando backup dos arquivos de debug"
cd $DEBUGDIR

for FILE in `ls *.debug`
do
	if [ -s $FILE ]
	then
		NEWFILE=$BACKUPDIR/$FILE.`YesterdayDOW`
       		rm $NEWFILE.gz 2> /dev/null
        	$SW_ROOT/GEN/bin/safecp $FILE $NEWFILE 2>> $LOGERR
        	chmod 644 $NEWFILE 2>> $LOGERR
        	cp $NEWFILE $NEWFILE.tmp 2>> $LOGERR
        fi
done

#echo "Mascarando arquivos de logs TCP"
SHELL_LOG $LOGERR $SHSWNAME "Mascarando arquivos de logs TCP"

# Inicio tratamento dos arquivos com dados mascarados
echo
echo  Inicio tratamento dos arquivos com dados mascarados
if [ MASK_LOGS != "" ]
then
    NET=$1

    if [ $NET = "EC" ]
    then
        NET="AVR"
    fi

    cd $SYSMASKDIR

    if [[ ! -d ${BACKUPMASKDIR} ]]
    then
        mkdir -p ${BACKUPMASKDIR}
    fi

    for FILE in $MASK_LOGS; do
        if [ -s $FILE ]
        then
            NEWFILE=$BACKUPMASKDIR/$FILE.`YesterdayDOW`
            MASKFILE=$BACKUPDIR/$FILE.`YesterdayDOW`
	    echo mascarando arquivo [$SYSMASKDIR/$FILE] para [$MASKFILE.gz]
            rm $NEWFILE.gz 2> /dev/null
            $SW_ROOT/GEN/bin/safecp $FILE $NEWFILE 2>> $LOGERR
            chmod 644 $NEWFILE 2>> $LOGERR
            PARAM=`echo $FILE | cut -f 1 -d . | sed 's/logtcp//g'`			
            cat $NEWFILE | $SW_ROOT/GEN/bin/LogReader stdin $NET $PARAM > $MASKFILE 2>> $LOGERR
            chgrp captura $MASKFILE 2>> $LOGERR
            chmod 644 $MASKFILE 2>> $LOGERR
            cp $MASKFILE $MASKFILE.tmp 2>> $LOGERR
        fi
    done
fi
# Fim tratamento dos arquivos com dados mascarados

# 0752_SW - Acerto rotina SHSW089D.sh - Backup de Cortes - ACDS - INICIO
echo
echo  Inicio tratamento dos arquivos de corte com dados mascarados
# Inicio tratamento dos arquivos de corte com dados mascarados
    for FILE_CORTE in $MASK_LOGS; do
    	FILE_CORTE=`echo $FILE_CORTE | awk -F".log" '{ print $1".corte.*.log" }'`
    	for FILE in $FILE_CORTE; do
	        if [ -s $FILE ]
	        then
	            NEWFILE=$BACKUPMASKDIR/$FILE.`YesterdayDOW`
	            MASKFILE=$BACKUPDIR/$FILE.`YesterdayDOW`
	            echo mascarando arquivo de corte[$SYSMASKDIR/$FILE] para [$MASKFILE.gz]
	            $SW_ROOT/GEN/bin/safecp $FILE $NEWFILE 2>> $LOGERR
	            chmod 644 $NEWFILE 2>> $LOGERR
		    PARAM=`echo $FILE | cut -f 1 -d . | sed 's/logtcp//g'`
		    cat $NEWFILE | $SW_ROOT/GEN/bin/LogReader stdin $NET $PARAM > $MASKFILE 2>> $LOGERR
		    chgrp captura $MASKFILE 2>> $LOGERR
		    chmod 644 $MASKFILE 2>> $LOGERR
		    cp $MASKFILE $MASKFILE.tmp 2>> $LOGERR
        	fi
	done
    done

# Fim tratamento dos arquivos de corte com dados mascarados
# 0752_SW - Acerto rotina SHSW089D.sh - Backup de Cortes - ACDS - FIM

# Inicio tratamento dos arquivos com dados Não Mascarados
echo
echo Inicio tratamento dos arquivos com dados Não Mascarados
if [ NMASK_LOGS != "" ]
then
    NET=$1

    if [ $NET = "EC" ]
    then
        NET="AVR"
    fi

    cd $SYSMASKDIR

    for FILE in $NMASK_LOGS; do
        if [ -s $FILE ]
        then
            NEWFILE=$BACKUPMASKDIR/$FILE.`YesterdayDOW`
            MASKFILE=$BACKUPDIR/$FILE.`YesterdayDOW`
	    echo compactando arquivo [$SYSMASKDIR/$FILE] para [$MASKFILE.gz]
            rm $NEWFILE.gz 2> /dev/null
            $SW_ROOT/GEN/bin/safecp $FILE $NEWFILE 2>> $LOGERR
            chmod 644 $NEWFILE 2>> $LOGERR
            PARAM=`echo $FILE | cut -f 1 -d . | sed 's/logtcp//g'`
            cat $NEWFILE > $MASKFILE 2>> $LOGERR
            cp $MASKFILE $MASKFILE.tmp 2>> $LOGERR
        fi
    done
fi
# Fim tratamento dos arquivos com dados não mascarados

#
#  Clear log files moving to backup dir
#
echo
echo "Iniciando backup dos arquivos de logs"
SHELL_LOG $LOGERR $SHSWNAME "Iniciando backup dos arquivos de logs"

cd $SYSDIR

for FILE in `ls *.log *.log.debug`
do
	if [ -s $FILE ]
	then
		NEWFILE=$BACKUPDIR/$FILE.`YesterdayDOW`
	        echo tratando arquivo [$SYSDIR/$FILE] para [$NEWFILE.gz]
		rm $NEWFILE.gz 2> /dev/null
		$SW_ROOT/GEN/bin/safecp $FILE $NEWFILE 2>> $LOGERR
		chmod 644 $NEWFILE 2>> $LOGERR
		#Inicio para tratamento para remover o PAN do AIX
		if [ $LOGS_AIX == $FILE ]
		then
			NFILE1=$NEWFILE.tmp
			grep -v "PAN" $NEWFILE > $NFILE1
			mv $NFILE1 $NEWFILE
			chmod 664 $NEWFILE 2>> $LOGERR
		fi
		#Fim para tratamento para remover o PAN do AIX
		cp $NEWFILE $NEWFILE.tmp 2>> $LOGERR
	fi
done

#  Realiza o ftp dos arquivos de log e debug para o servidor soxx608cto
echo
echo "Iniciando envio de arquivos de logs e backup para o S3"
SHELL_LOG $LOGERR $SHSWNAME "Iniciando envio de arquivos de logs e backup para o S3"

DIR_ORIG=$BACKUPDIR
FTPERR=$SW_ROOT/site/$1/log/sys/$SHSWNAME.ftperr.txt
cd $BACKUPDIR
for ARQ_ORIG in `ls *.tmp | egrep '(.debug.|.log.)'`;
do
	ARQ_TMP=$DIR_ORIG/$ARQ_ORIG
	NAME_SIZE=`expr length $ARQ_TMP `
	NAME_SIZE=`expr $NAME_SIZE - 4`
	ARQ=`echo $ARQ_TMP | cut -c 1-$NAME_SIZE `
	ARQ_DEST=$ARQ.`date +%Y%m%d`.gz
	ARQ_FTP_DEST=`echo $ARQ_DEST | awk -F'/' '{print $NF}'`
	ARQ_FTP_ORIG=`echo $ARQ | awk -F'/' '{print $NF}'`

	mv $ARQ_TMP $ARQ 2>> $LOGERR
	sleep 1

	TAMANHO_ARQ_KB=`ls -lgG $ARQ | awk '{print $3}'`
	DOIS_GB=2080000000

	if [ $TAMANHO_ARQ_KB -gt $DOIS_GB ]
	then
		QTD_ARQUIVOS=`expr $TAMANHO_ARQ_KB / $DOIS_GB + 1`
		QTD_LINHAS=`wc -l $ARQ | awk '{print $1}'`
		LINHAS_ARQ=`expr $QTD_LINHAS / $QTD_ARQUIVOS`
		LINHAS_ARQ=`expr $LINHAS_ARQ + $QTD_ARQUIVOS - 1`

		split -l $LINHAS_ARQ $ARQ $ARQ. 2>> $LOGERR

		echo rm -f $ARQ 
		rm -f $ARQ 2>> $LOGERR

		sleep 1
		#Caso ocorra o seguinte erro: $SW_ROOT/site/*/log/*/*: A file or directory in the path name does not exist.
		# Siginifica que o SO nao teve tempo o suficiente para remover o arquivo antes do ls|grep|awk abaixo ser executado
		for ARQ_SPLIT in `ls $ARQ.* |egrep -v ".Z" | egrep -v ".gz"`;
		do
			gzip $ARQ_SPLIT 2>> $LOGERR
			ARQ_FTP_ORIG=`echo $ARQ_SPLIT | awk -F'/' '{print $NF}'`
			ARQ_FTP_DEST=$ARQ_FTP_ORIG.`date +%Y%m%d`.gz
	                echo aws s3 cp $DIR_ORIG/${ARQ_FTP_ORIG}."gz" $strBucketS3/$HOSTNAME/$ARQ_FTP_DEST
	                aws s3 cp $DIR_ORIG/${ARQ_FTP_ORIG}."gz" $strBucketS3/$HOSTNAME/$ARQ_FTP_DEST >> $FTPERR
			if [ $? != 0 ]
                        then
				echo ERRO em aws s3 cp $DIR_ORIG/${ARQ_FTP_ORIG}."gz" $strBucketS3/$HOSTNAME/$ARQ_FTP_DEST
				SHELL_LOG echo ERRO em aws s3 cp $DIR_ORIG/${ARQ_FTP_ORIG}."gz" $strBucketS3/$HOSTNAME/$ARQ_FTP_DEST
				exit
			fi
        done
	else
			gzip --force $ARQ 2>> $LOGERR
			echo aws s3 cp ${ARQ_FTP_ORIG}."gz" $strBucketS3/$HOSTNAME/$ARQ_FTP_DEST
			aws s3 cp ${ARQ_FTP_ORIG}."gz" $strBucketS3/$HOSTNAME/$ARQ_FTP_DEST >> $FTPERR
			if [ $? != 0 ] 
                        then
				echo ERRO em aws s3 cp ${ARQ_FTP_ORIG}."gz" $strBucketS3/$HOSTNAME/$ARQ_FTP_DEST
				SHELL_LOG echo ERRO em aws s3 cp ${ARQ_FTP_ORIG}."gz" $strBucketS3/$HOSTNAME/$ARQ_FTP_DEST
				exit
			fi
	fi
done
SHELL_LOG $LOGERR $SHSWNAME "Processo de backup do FE-$1 finalizado!"

echo
echo $LOGERR $SHSWNAME "Limpando arquivos de corte do debug"
SHELL_LOG $LOGERR $SHSWNAME "Limpando arquivos de corte do debug"
echo cd $DEBUGDIR
cd $DEBUGDIR
echo rm -f *corte*debug
rm -f *corte*debug

echo
echo $LOGERR $SHSWNAME "Limpando arquivos de corte do sys"
SHELL_LOG $LOGERR $SHSWNAME "Limpando arquivos de corte do sys"
echo cd $SYSDIR
cd $SYSDIR
echo rm -f *corte*log
rm -f *corte*log

echo
echo $LOGERR $SHSWNAME "Limpando arquivos de corte do tcp"
SHELL_LOG $LOGERR $SHSWNAME "Limpando arquivos de corte do tcp"
echo cd $SYSMASKDIR
cd $SYSMASKDIR
echo rm -f *corte*
rm -f *corte*

echo
echo $LOGERR $SHSWNAME "Apagando arquivos de mais de 3 dias"
SHELL_LOG $LOGERR $SHSWNAME "Apagando arquivos de mais de 3 dias"

WEEKDAY=`date +'%a'`

echo cd $BACKUPDIR
cd $BACKUPDIR
case $WEEKDAY in
Mon)
echo rm *Tue* *Wed* *Thu* *Fri*
rm *Tue* *Wed* *Thu* *Fri*
;;
Tue)
echo rm *Wed* *Thu* *Fri* *Sat*
rm *Wed* *Thu* *Fri* *Sat*
;;
Wed)
echo rm *Thu* *Fri* *Sat* *Sun*
rm *Thu* *Fri* *Sat* *Sun*
;;
Thu)
echo rm *Fri* *Sat* *Sun* *Mon*
rm *Fri* *Sat* *Sun* *Mon*
;;
Fri)
echo rm *Sat* *Sun* *Mon* *Tue*
rm *Sat* *Sun* *Mon* *Tue*
;;
Sat)
echo rm *Sun* *Mon* *Tue* *Wed*
rm *Sun* *Mon* *Tue* *Wed*
;;
Sun)
echo rm *Mon* *Tue* *Wed* *Thu*
rm *Mon* *Tue* *Wed* *Thu*
;;
esac

SHELL_LOG $LOGERR $SHSWNAME "Processo de backup do FE-$1 finalizado!"
echo
echo 023_SW - Criacao de Links LOG TCP - ACDS - Inicio
# 0230_SW - Criacao de Links LOG TCP - ACDS - Inicio
SHELL_LOG $LOGERR $SHSWNAME "-------------------------------------------------------------------"
SHELL_LOG $LOGERR $SHSWNAME "Inicio da Validacao dos Links do FE-$1"
strListaArquivo=`echo "$SW_ROOT/site/"$1"/log/sys/tcp/*.debug"`
for strArquivo in `ls -tr $strListaArquivo`
do
  strLink=`echo $strArquivo | awk -F"." '{ print $1 "." $2 }' ` 
  echo criando link de $strArquivo $strLink
  if [ -e "$strLink" ] ; then
    SHELL_LOG $LOGERR $SHSWNAME "FE-$1 $strLink Existe"
  else
    SHELL_LOG $LOGERR $SHSWNAME "FE-$1 $strLink Não Existe"
    echo ln -f $strArquivo $strLink
    ln -f $strArquivo $strLink
  fi
done
SHELL_LOG $LOGERR $SHSWNAME "Fim da Validacao dos Links do FE-$1"
# 0230_SW - Criacao de Links LOG TCP - ACDS - Fim

#. fimProcesso 0
exit 0
