#! /usr/bin/ksh
##############################################################################
# Nome........: qg_get_58_PDV.sh
# Descricao...: Executa replicacao de pre-autorizacoes do BD do SW 7.5 para o
#               BD do SW 7.1
# Autor.......: Guilherme Sanches
# Data........: 30/08/2020
# Empresa.....: Rede
#
##############################################################################
# Shell Temporario para replicação das transações de pré-aut, do 7.5 no 7.1  #
##############################################################################

##############################################################################
# Nome........: replic_preaut_75.sh
# Descricao...: Executa replicacao de pre-autorizacoes do BD do SW 7.7 para o
#               BD do SW 7.5
# Autor.......: Davi Ferreira
# Data........: 27/08/2021
# Empresa.....: Leega
#
##############################################################################
# Shell Temporario para replicação das transações de pré-aut, do 7.7 no 7.5  #
##############################################################################

# Garantir que nenhum comando tenha sido substituido
# por uma funcao do mesmo nome
unset -f unalias
unalias -a

# Carrega variaveis genericas
#. ~/.profile

. swloadenv ${FE} >> /dev/null 2>&1

# funcoes genericas
. swfunc.sh

# Definicao de PATH
export OASIS_ROOT="/home/SW"

# Parametros passados por linha de comando para o shell
strParam=$@

# Nome do Script para referenciar em modo de usar
STR_SCRIPT_NAME="replic_preaut75"

while(true)
do
#
# Instanciando variaveis
#
STR_THIS_FILE=`basename $0`
STR_THIS_FILE_PREFIX=`basename $0 .sh`
STR_SCRIPT_NAME=${STR_THIS_FILE}
STR_CONFIG_FILE="${HOME}/site/${FE}/cfg/${STR_THIS_FILE_PREFIX}.cfg"
STR_LOG_FILE="${HOME}/site/${FE}/log/sys/$STR_THIS_FILE_PREFIX.log"

STR_SQL_COMMAND_POSTGRE="${OTMPDIR}/${STR_THIS_FILE_PREFIX}_postgre.sql"
STR_SQL_COMMAND_ORACLE="${OTMPDIR}/${STR_THIS_FILE_PREFIX}_oracle.sql"

STR_HOSTNAME_77=`hostname`

# Usuario do POS Oracle
STR_DB_USER_ORACLE=`get_db_user /online/oracle/SW75/POS`
STR_DB_ARQPWD_ORACLE=`get_db_password /online/oracle/SW75/POS`
STR_BD_DB_NAME_ORACLE=`get_db_name /online/oracle/SW75/POS`

# Usuario do POS PostgreSql
STR_DB_USER_POSTGRE=`get_db_user /online/postgresql/baseunica/${AZ}`
STR_DB_PWD_POSTGRE=`get_db_password /online/postgresql/baseunica/${AZ}`
STR_BD_NAME_POSTGRE=`get_db_name /online/postgresql/baseunica/${AZ}`
STR_BD_HOST_POSTGRE=`get_db_host /online/postgresql/baseunica/${AZ}`
EXECUCAO=0

DATA_EXEC_INI="`date +"%Y%m%d-%H:%M:%S"`"
echo " "
echo "LogFile: $STR_LOG_FILE" 
echo "`date +"%Y-%m-%d.%H:%M:%S"` -----------------------------------------------------------------------------" >> $STR_LOG_FILE
echo "`date +"%Y-%m-%d.%H:%M:%S"` -- Inicio. "  >> $STR_LOG_FILE
echo "`date +"%Y-%m-%d.%H:%M:%S"` -- Inicio. "

STR_DB_USER_ORACLE=`get_db_user /online/oracle/SW75/POS`
STR_DB_ARQPWD_ORACLE=`get_db_password /online/oracle/SW75/POS`
STR_BD_DB_NAME_ORACLE=`get_db_name /online/oracle/SW75/POS`

USERPDV=`get_db_user /online/postgresql/baseunica/${AZ}`
OPWDPDV=`get_db_password /online/postgresql/baseunica/${AZ}`

cat > $STR_SQL_COMMAND_POSTGRE <<EOFSQL
\pset pager off
select
' declare '
'  n int := 0; '
'  numseq int :=0; '
'  datmovtran int :=0; '
'begin '
'  select count(*),  max(num_seq_unc), max(dat_mov_tran) into n, numseq, datmovtran '
'  from TBSW0058 ' 
'  where dat_mov_tran = '  || dat_mov_tran  || '  and num_seq_unc = ' || num_seq_unc || ';'  ||
'  if n = 0 then '
'INSERT INTO TBSW0058 ( '||
'cod_aut_emsr,' ||
'cod_aut_emsr_cnvt,' ||
'cod_bndr,' ||
'cod_cndc_cptr,' ||
'cod_cpcd_term,' ||
'cod_cpcd_term_vldc_bndr,' ||
'cod_crct_tran,' ||
'cod_ctah_voch,' ||
'cod_emsr,' ||
'cod_gru_clas_ram,' ||
'cod_gru_estb,' ||
'cod_hash_prto_sgra,' ||
'cod_moed,' ||
'cod_mot_aut,' ||
'cod_mot_iso_emsr,' ||
'cod_msg_iso,' ||
'cod_mtz_estb,' ||
'cod_ntwk_id_acqr_atlz,' ||
'cod_ntwk_id_acqr_orgl,' ||
'cod_ntwk_id_issr_atlz,' ||
'cod_ntwk_id_issr_orgl,' ||
'cod_ntwk_id_rout_atlz,' ||
'cod_ntwk_id_rout_orgl,' ||
'cod_nvl_sgra,' ||
'cod_nvl_sgra_orgl,' ||
'cod_org_aprv,' ||
'cod_pais_car,' ||
'cod_pcm_ems,' ||
'cod_pcm_iso,' ||
'cod_pgm_aut,' ||
'cod_port_pres_vldc_bndr,' ||
'cod_pos_entr_modo,' ||
'cod_prod_mtc,' ||
'cod_ram_atvd,' ||
'cod_ret_vldc_sgra,' ||
'cod_rgao_mtc,' ||
'cod_serv_snha,' ||
'cod_term,' ||
'cod_term_cnfr,' ||
'cod_tip_prod_car,' ||
'cod_trk_car,' ||
'cod_ucaf,' ||
'cod_vldc_attc_prto_sgra,' ||
'dat_can_pauz,' ||
'dat_cnfr_pauz,' ||
'dat_mov_tran,' ||
'dat_mov_tran_cnfr,' ||
'dat_pauz,' ||
'dat_vld_car,' ||
'dat_vld_pauz,' ||
'dth_cnfr,' ||
'dth_gmt,' ||
'dth_ini_tran,' ||
'dth_sttu_tran,' ||
'id_ref_bndr,' ||
'id_vers_prto_sgra,' ||
'ind_da_tit_car_amzt,' ||
'ind_emsr_mtc,' ||
'ind_nvl_sgra_kmrc,' ||
'ind_rd_cptr,' ||
'ind_rd_org,' ||
'ind_rd_org_estr,' ||
'ind_sttu_tran,' ||
'ind_tran_tkn,' ||
'nom_fe_acqr_atlz,' ||
'nom_fe_acqr_orgl,' ||
'nom_fe_issr,' ||
'nom_fnts_pdv,' ||
'nom_host_acqr_atlz,' ||
'nom_host_acqr_orgl,' ||
'nom_host_issr,' ||
'nom_port_car,' ||
'nom_site_acqr_atlz,' ||
'nom_site_acqr_orgl,' ||
'nom_site_issr,' ||
'num_aut,' ||
'num_avso_aut,' ||
'num_car,' ||
'num_emsr,' ||
'num_estb,' ||
'num_estb_cnfr,' ||
'num_estb_estr,' ||
'num_id_car,' ||
'num_mot_rsps,' ||
'num_pdv_ext,' ||
'num_pdv_van,' ||
'num_rd_org,' ||
'num_ref_tran,' ||
'num_seq_unc,' ||
'num_seq_unc_cnfr,' ||
'num_stan,' ||
'num_stan_orgl,' ||
'qtd_prcl_cnfr,' ||
'tip_attc_cmc_elet,' ||
'tip_tran,' ||
'txt_da_adic_emsr,' ||
'val_cot_dlr,' ||
'val_eftv_cptr,' ||
'val_tran,' ||
'val_tran_dlr' ||
') values  ('  ||
case when cod_aut_emsr is null then 'null' else '''' || cod_aut_emsr  || '''' end || ',' ||
case when cod_aut_emsr_cnvt is null then 'null' else '''' || cod_aut_emsr_cnvt  || '''' end || ',' ||
case when cod_bndr is null then '''0''' else '''' || cod_bndr  || '''' end || ',' ||
case when cod_cndc_cptr is null then 'null' else '''' || cod_cndc_cptr  || ''''  end || ',' ||
case when cod_cpcd_term is null then ''' ''' when cod_cpcd_term = '' then ''' '''   else  '''' || cod_cpcd_term || ''''   end || ',' ||
case when cod_cpcd_term_vldc_bndr is null then 'null' else '''' || cod_cpcd_term_vldc_bndr  || ''''  end || ',' ||
case when cod_crct_tran is null then 'null' else '''' || cod_crct_tran || ''''  end || ',' ||
case when cod_ctah_voch is null then 'null' else '''' || cod_ctah_voch || ''''  end || ',' ||
case when cod_emsr is null then '''0''' else '''' || cod_emsr || ''''  end || ',' ||
case when cod_gru_clas_ram is null then '''0'''  else '''' || cod_gru_clas_ram || ''''  end || ',' ||
case when cod_gru_estb is null then '''0''' else '''' || cod_gru_estb || ''''  end || ',' ||
case when cod_hash_prto_sgra is null then 'null' else '''' || cod_hash_prto_sgra || ''''  end || ',' ||
case when cod_moed is null then ''' ''' else '''' || cod_moed || ''''  end || ',' ||
case when cod_mot_aut is null then ''' ''' when cod_mot_aut = '' then ''' '''   else  '''' || cod_mot_aut || ''''   end || ',' ||
case when cod_mot_iso_emsr is null then 'null' else '''' || cod_mot_iso_emsr || ''''  end || ',' ||
case when cod_msg_iso is null then '''0''' else '''' || cod_msg_iso || ''''  end || ',' ||
case when cod_mtz_estb is null then '''0''' else '''' || cod_mtz_estb || ''''  end || ',' ||
case when cod_ntwk_id_acqr_atlz is null then 'null' else '''' || cod_ntwk_id_acqr_atlz || ''''  end || ',' ||
case when cod_ntwk_id_acqr_orgl is null then 'null' else '''' || cod_ntwk_id_acqr_orgl || ''''  end || ',' ||
case when cod_ntwk_id_issr_atlz is null then 'null' else '''' || cod_ntwk_id_issr_atlz || ''''  end || ',' ||
case when cod_ntwk_id_issr_orgl is null then 'null' else '''' || cod_ntwk_id_issr_orgl || ''''  end || ',' ||
case when cod_ntwk_id_rout_atlz is null then 'null' else '''' || cod_ntwk_id_rout_atlz || ''''  end || ',' ||
case when cod_ntwk_id_rout_orgl is null then 'null' else '''' || cod_ntwk_id_rout_orgl || ''''  end || ',' ||
case when cod_nvl_sgra is null then ''' ''' when cod_nvl_sgra = '' then ''' '''   else  '''' || cod_nvl_sgra || ''''   end || ',' ||
case when cod_nvl_sgra_orgl is null then ''' ''' when cod_nvl_sgra_orgl = '' then ''' '''   else  '''' || cod_nvl_sgra_orgl || ''''   end || ',' ||
case when cod_org_aprv is null then ''' ''' when cod_org_aprv = '' then ''' '''   else  '''' || cod_org_aprv || ''''   end || ',' ||
case when cod_pais_car is null then ''' ''' when cod_pais_car = '' then ''' '''   else  '''' || cod_pais_car || ''''   end || ',' ||
case when cod_pcm_ems is null then 'null' else '''' || cod_pcm_ems || ''''  end || ',' ||
case when cod_pcm_iso is null then '''0''' else '''' || cod_pcm_iso || ''''  end || ',' ||
case when cod_pgm_aut is null then 'null' else '''' || cod_pgm_aut || ''''  end || ',' ||
case when cod_port_pres_vldc_bndr is null then 'null' else '''' || cod_port_pres_vldc_bndr || ''''  end || ',' ||
case when cod_pos_entr_modo is null then ''' ''' when cod_pos_entr_modo = '' then ''' '''   else  '''' || cod_pos_entr_modo || ''''   end || ',' ||
case when cod_prod_mtc is null then 'null' else '''' || cod_prod_mtc || ''''  end || ',' ||
case when cod_ram_atvd is null then '''0''' else '''' || cod_ram_atvd || ''''  end || ',' ||
case when cod_ret_vldc_sgra is null then 'null' else '''' || cod_ret_vldc_sgra || ''''  end || ',' ||
case when cod_rgao_mtc is null then 'null' else '''' || cod_rgao_mtc || ''''  end || ',' ||
case when cod_serv_snha is null then ''' ''' when cod_serv_snha = '' then ''' '''   else  '''' || cod_serv_snha || ''''   end || ',' ||
case when cod_term is null then ''' ''' when cod_term = '' then ''' '''   else  '''' || cod_term || ''''   end || ',' ||
case when cod_term_cnfr is null then 'null' else '''' || cod_term_cnfr || ''''  end || ',' ||
case when cod_tip_prod_car is null then ''' ''' when cod_tip_prod_car = '' then ''' '''   else  '''' || cod_tip_prod_car || ''''   end || ',' ||
case when cod_trk_car is null then ''' ''' when cod_trk_car = '' then ''' '''   else  '''' || cod_trk_car || ''''   end || ',' ||
case when cod_ucaf is null then 'null' else '''' || cod_ucaf || ''''  end || ',' ||
case when cod_vldc_attc_prto_sgra is null then 'null' else '''' || cod_vldc_attc_prto_sgra || ''''  end || ',' ||
case when dat_can_pauz is null then 'null' else 'TO_DATE(''' ||  dat_can_pauz  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when dat_cnfr_pauz is null then 'null' else 'TO_DATE(''' ||  dat_cnfr_pauz  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when dat_mov_tran is null then '''0''' else '''' || dat_mov_tran || ''''  end || ',' ||
case when dat_mov_tran_cnfr is null then 'null'  else  '''' || dat_mov_tran_cnfr || ''''   end || ',' ||
case when dat_pauz is null then 'null' else 'TO_DATE(''' ||  dat_pauz  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when dat_vld_car is null then 'null' else 'TO_DATE(''' ||  dat_vld_car  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when dat_vld_pauz is null then 'null' else 'TO_DATE(''' ||  dat_vld_pauz  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when dth_cnfr is null then 'null' else 'TO_DATE(''' ||  dth_cnfr  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when dth_gmt is null then 'null' else 'TO_DATE(''' ||  dth_gmt  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when dth_ini_tran is null then 'null' else 'TO_DATE(''' ||  dth_ini_tran  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when dth_sttu_tran is null then 'null' else 'TO_DATE(''' ||  dth_sttu_tran  || ''',''YYYY-MM-DD HH24:MI:SS'' )'  end || ',' ||
case when id_ref_bndr is null then 'null' when id_ref_bndr = '' then ''' '''   else  '''' || id_ref_bndr || ''''   end || ',' ||
case when id_vers_prto_sgra is null then 'null' when id_vers_prto_sgra = '' then ''' '''   else  '''' || id_vers_prto_sgra || ''''   end || ',' ||
case when ind_da_tit_car_amzt is null then ''' ''' when ind_da_tit_car_amzt = '' then ''' '''   else  '''' || ind_da_tit_car_amzt || ''''   end || ',' ||
case when ind_emsr_mtc is null then ''' ''' when ind_emsr_mtc = '' then ''' '''   else  '''' || ind_emsr_mtc || ''''   end || ',' ||
case when ind_nvl_sgra_kmrc is null then 'null' else '''' || ind_nvl_sgra_kmrc || ''''  end || ',' ||
case when ind_rd_cptr is null then 'null' else '''' || ind_rd_cptr || ''''  end || ',' ||
case when ind_rd_org is null then ''' ''' when ind_rd_org = '' then ''' '''   else  '''' || ind_rd_org || ''''   end || ',' ||
case when ind_rd_org_estr is null then 'null' else  '''' || ind_rd_org_estr || ''''   end || ',' ||
case when ind_sttu_tran is null then ''' ''' when ind_sttu_tran = '' then ''' '''   else  '''' || ind_sttu_tran || ''''   end || ',' ||
case when ind_tran_tkn is null then 'null' else '''' || ind_tran_tkn || ''''  end || ',' ||
case when nom_fe_acqr_atlz is null then 'null' else '''' || nom_fe_acqr_atlz || ''''  end || ',' ||
case when nom_fe_acqr_orgl is null then ''' ''' when nom_fe_acqr_orgl = '' then ''' '''   else  '''' || nom_fe_acqr_orgl || ''''   end || ',' ||
case when nom_fe_issr is null then 'null' else '''' || nom_fe_issr || ''''  end || ',' ||
case when nom_fnts_pdv is null then 'null' else '''' || nom_fnts_pdv || ''''  end || ',' ||
case when nom_host_acqr_atlz is null then 'null' else '''' || nom_host_acqr_atlz || ''''  end || ',' ||
case when nom_host_acqr_orgl is null then ''' ''' when nom_host_acqr_orgl = '' then ''' '''   else  '''' || nom_host_acqr_orgl || ''''   end || ',' ||
case when nom_host_issr is null then 'null' else '''' || nom_host_issr  || ''''  end || ',' ||
case when nom_port_car is null then 'null'  else  '''' || nom_port_car || ''''   end || ',' ||
case when nom_site_acqr_atlz is null then 'null' else  '''' || nom_site_acqr_atlz || ''''   end || ',' ||
case when nom_site_acqr_orgl is null then ''' ''' when nom_site_acqr_orgl = '' then ''' '''   else  '''' || nom_site_acqr_orgl || ''''   end || ',' ||
case when nom_site_issr is null then 'null' else '''' || nom_site_issr  || ''''  end || ',' ||
case when num_aut is null then  ''' ''' when num_aut = '' then ''' ''' else '''' || num_aut  || ''''  end || ',' ||
case when num_avso_aut is null then 'null' else '''' || num_avso_aut  || ''''  end || ',' ||
case when num_car is null then ''' ''' when num_car = '' then ''' ''' else '''' || num_car  || ''''  end || ',' ||
case when num_emsr is null then '''0''' else '''' || num_emsr  || ''''  end || ',' ||
case when num_estb is null then '''0''' else '''' || num_estb  || ''''  end || ',' ||
case when num_estb_cnfr is null then 'null' else '''' || num_estb_cnfr  || ''''  end || ',' ||
case when num_estb_estr is null then 'null' else '''' || num_estb_estr  || ''''  end || ',' ||
case when num_id_car is null then 'null' else '''' || num_id_car  || ''''  end || ',' ||
case when num_mot_rsps is null then 'null' else '''' || num_mot_rsps  || ''''  end || ',' ||
case when num_pdv_ext is null then 'null' else '''' || num_pdv_ext  || ''''  end || ',' ||
case when num_pdv_van is null then 'null' else '''' || num_pdv_van  || ''''  end || ',' ||
case when num_rd_org is null then '''0''' else '''' || num_rd_org  || ''''  end || ',' ||
case when num_ref_tran is null then ''' ''' when num_ref_tran = '' then ''' '''   else  '''' || num_ref_tran || ''''   end || ',' ||
case when num_seq_unc is null then '''0''' else '''' || num_seq_unc  || ''''  end || ',' ||
case when num_seq_unc_cnfr is null then 'null' else '''' || num_seq_unc_cnfr  || ''''  end || ',' ||
case when num_stan is null then '''0''' else '''' || num_stan  || ''''  end || ',' ||
case when num_stan_orgl is null then 'null' else '''' || num_stan_orgl  || ''''  end || ',' ||
case when qtd_prcl_cnfr is null then 'null' else '''' || qtd_prcl_cnfr  || ''''  end || ',' ||
case when tip_attc_cmc_elet is null then ''' ''' when tip_attc_cmc_elet = '' then ''' '''   else  '''' || tip_attc_cmc_elet || ''''   end || ',' ||
case when tip_tran is null then '''0''' else '''' || tip_tran  || ''''  end || ',' ||
case when txt_da_adic_emsr is null then 'null' else '''' || txt_da_adic_emsr  || ''''  end || ',' ||
case when val_cot_dlr is null then 'null' else '''' || val_cot_dlr  || ''''  end || ',' ||
case when val_eftv_cptr is null then 'null' else '''' || val_eftv_cptr  || ''''  end || ',' ||
case when val_tran is null then '''0''' else '''' || val_tran  || ''''  end || ',' ||
case when val_tran_dlr is null then 'null' else '''' || val_tran_dlr  || '''' end|| ');'  ||
' else DBMS_OUTPUT.put_line(''duplicada:dat_mov_tran='' || datmovtran || '', num_seq_unc='' || numseq);' 
' end if; '||
' end;/' 
as insert_into_oracle

--from tbsw0058;
from tbsw0058 where DAT_VLD_PAUZ >= CURRENT_DATE and NOM_FE_ACQR_ORGL = '77POS' AND NOM_SITE_ACQR_ORGL <> 'SW75' and IND_STTU_TRAN = '0';

 select
 'begin '
   'UPDATE tbsw0058 SET ind_sttu_tran =' || '''X''' ||
   ', dth_sttu_tran = CURRENT_DATE ' ||
   ' WHERE nom_fe_acqr_orgl =' || '''77POS''' ||
   ' AND ind_sttu_tran = ' || '''0'''  ||
   ' AND dat_mov_tran= ' || '''' || dat_mov_tran || ''''  ||
   ' AND num_seq_unc=' || '''' || num_seq_unc || '''' || ';'
   ' DBMS_OUTPUT.put_line(''updated: '' || SQL%ROWCOUNT );'
 'end;/'
 as update_into_oracle
 FROM 
    TBSW0058
 WHERE 
    IND_RD_ORG = '3' and IND_STTU_TRAN in ('1', '3', '4');
EOFSQL

rm -rf $STR_SQL_COMMAND_POSTGRE.tmp
#psql "dbname='dbunica' user='$STR_DB_USER_POSTGRE' password='$STR_DB_PWD_POSTGRE' host='capt-unica-sa.cluster-cz6jwnryepdv.sa-east-1.rds.amazonaws.com'" -f "$STR_SQL_COMMAND_POSTGRE"  >> ${STR_LOG_FILE} 2>&1
psql "dbname='dbunica' user='$STR_DB_USER_POSTGRE' password='$STR_DB_PWD_POSTGRE' host='$STR_BD_HOST_POSTGRE' " -f $STR_SQL_COMMAND_POSTGRE -o $STR_SQL_COMMAND_POSTGRE.tmp 2>> ${STR_LOG_FILE}

#DATA_EXEC_TMP=`date +"%Y-%m-%d.%H:%M:%S"`
#grep -E4 '_into_oracle' $STR_SQL_COMMAND_POSTGRE.tmp |grep -v "\-\-" |grep -v "INSERT"| grep -v "UPDATE"| tr -s '  ' '[ ]' | awk -v datetmp="$DATA_EXEC_TMP"  '{printf( "%s - %s\n",datetmp,$0)}' >> $STR_LOG_FILE


echo ' SET PAGESIZE 50000;'  > $STR_SQL_COMMAND_ORACLE
echo ' SET SERVEROUTPUT ON;'  > $STR_SQL_COMMAND_ORACLE
grep -v "insert_into_oracle" $STR_SQL_COMMAND_POSTGRE.tmp  | grep -v "update_into_oracle" | grep -Ev "^$" | grep -v "\-\-\-" | grep -v "row" | awk -F"end;/" '{if ($0 ~ /end;/) {print $1 "end;\n/"} else {print $0}}'>> $STR_SQL_COMMAND_ORACLE

echo "`date +"%Y-%m-%d.%H:%M:%S"` -" >> $STR_LOG_FILE

#Limpa cartao invalido
echo "COMMIT; " >> $STR_SQL_COMMAND_ORACLE
echo "QUIT" >> $STR_SQL_COMMAND_ORACLE

rm -rf $STR_SQL_COMMAND_ORACLE.tmp

QTD_77=`grep -i "INSERT INTO tbsw0058" $STR_SQL_COMMAND_ORACLE | wc -l`
UPD_77=`grep -i "UPDATE tbsw0058" $STR_SQL_COMMAND_ORACLE | wc -l`

#echo "`date +"%Y-%m-%d.%H:%M:%S"` - Updates selecionados:"$UPD_77
echo "`date +"%Y-%m-%d.%H:%M:%S"` - Updates selecionados: "$UPD_77 >> $STR_LOG_FILE

#echo "`date +"%Y-%m-%d.%H:%M:%S"` - Inserts selecionados:"$QTD_77
echo "`date +"%Y-%m-%d.%H:%M:%S"` - Inserts selecionados: "$QTD_77 >> $STR_LOG_FILE

#sqlplus FEPOSAPPL/pos75app@sobx105cto $STR_SQL_COMMAND_ORACLE

#echo $ORACLE_HOME/bin/sqlplus ${STR_DB_USER_ORACLE}/${STR_DB_ARQPWD_ORACLE}@$STR_BD_DB_NAME_ORACLE @${STR_SQL_COMMAND_ORACLE} 2>> ${STR_LOG_FILE}
$ORACLE_HOME/bin/sqlplus ${STR_DB_USER_ORACLE}/${STR_DB_ARQPWD_ORACLE}@$STR_BD_DB_NAME_ORACLE @${STR_SQL_COMMAND_ORACLE} > $STR_SQL_COMMAND_ORACLE.tmp
echo "Temporario: $STR_SQL_COMMAND_ORACLE.tmp" 

# Obtem codigo de retorno do binario
CODIGO_DE_ERRO=$?

# Data final da execucao do shell
DATA_EXEC_END="`date +"%Y%m%d-%H:%M:%S"`"

QTD_75_DUPLICADOS=`grep "duplicada:" $STR_SQL_COMMAND_ORACLE.tmp | wc -l`
QTD_75_UPDATED=`grep "updated: 1" $STR_SQL_COMMAND_ORACLE.tmp | wc -l`

echo "`date +"%Y-%m-%d.%H:%M:%S"` - Updates atualizados: $QTD_75_UPDATED" >> $STR_LOG_FILE
echo "`date +"%Y-%m-%d.%H:%M:%S"` - Inserts duplicados : $QTD_75_DUPLICADOS" >> $STR_LOG_FILE
DATA_EXEC_TMP=`date +"%Y-%m-%d.%H:%M:%S"`
grep "duplicada:" $STR_SQL_COMMAND_ORACLE.tmp | awk -v datetmp="$DATA_EXEC_TMP"  '{printf( "%s -     %s\n",datetmp,$0)}'>> $STR_LOG_FILE
echo "`date +"%Y-%m-%d.%H:%M:%S"` - Termino da execucao do shell: [$CODIGO_DE_ERRO]" >> $STR_LOG_FILE
echo "`date +"%Y-%m-%d.%H:%M:%S"` - Termino da execucao do shell: [$CODIGO_DE_ERRO]"
echo "`date +"%Y-%m-%d.%H:%M:%S"` - $DATA_EXEC_END - Fim." >> $STR_LOG_FILE
echo "$DATA_EXEC_END - Fim."

sleep 3600
done

#Forca saida sem erro.
exit 0
#exit $CODIGO_DE_ERRO

