import abc

class Host(abc.ABC):

    HOSTNAME = ""
    PORT = ""
    USERNAME = ""
    PASSWORD = ""

    def __init__(self, hostname='', port='', username='', password=''):
        self.HOSTNAME = hostname
        self.PORT     = port
        self.USERNAME = username
        self.PASSWORD = password

    @abc.abstractmethod
    def connect(self):
        """ Connect to the host

        Args :
            None
        Returns:
            None
        """
        pass

    @abc.abstractmethod
    def close(self):
        """ Terminate the protocol agent and close connection

        Args :
            None
        Returns:
            None
        """
        pass

    @abc.abstractmethod
    def send_to(self, src, dest):
        """ Send file to SSH Server

        Args :
            from_: local file's path to be copied to the server
            to_  : server path where the file will be stored
        Returns:
            None
        """
        pass

    @abc.abstractmethod
    def recv_from(self, src, dest):
        """ Receive file from SSH Server

        Args :
            from_: server file's path to be received
            to_  : local path where the file will be stored
        Returns:
            None
        """
        pass