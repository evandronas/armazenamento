unset -f unalias
unalias -a
sleep 4
if [ "${1}" == "" ]; then
    syslgsend "Sintax Error !!!"
    syslgsend "Example : loadTSK.sh [front end]"
    exit 0;
fi

case $1 in
        CRT)
                grep ^${1} ${GEN_ROOT}/cfg/loadTSK.cfg | grep -v CRTM | grep -v CRTO |
                awk ' {
                NUMBER=1;
                NUMBER_OF_TASKS=$2;
                STR_TASK_NAME=$3;
				
				for(i=4;i<=NF;i++){
					STR_TASK_NAME = STR_TASK_NAME " " $i
				}
				
                for (; NUMBER <= NUMBER_OF_TASKS; NUMBER++) {
                        system("usleep 1000000; mbcmd run " STR_TASK_NAME)
                }
                } '
                ;;
        DBT)
                grep ^${1} ${GEN_ROOT}/cfg/loadTSK.cfg | grep -v DBTM | grep -v DBTO |
                awk ' {
                NUMBER=1;
                NUMBER_OF_TASKS=$2;
                STR_TASK_NAME=$3;
				
				for(i=4;i<=NF;i++){
					STR_TASK_NAME = STR_TASK_NAME " " $i
				}

                for (; NUMBER <= NUMBER_OF_TASKS; NUMBER++) {
                        system("usleep 1000000; mbcmd run " STR_TASK_NAME)
                }
                } '
                ;;
        *)
		grep ^${1} ${GEN_ROOT}/cfg/loadTSK.cfg | 
		awk ' {
		NUMBER=1;
		NUMBER_OF_TASKS=$2;
		TASK_NAME=$3;
		
		for(i=4;i<=NF;i++){
			TASK_NAME = TASK_NAME " " $i
		}

		for (; NUMBER <= NUMBER_OF_TASKS; NUMBER++) {
		    system("usleep 1000000; mbcmd run " TASK_NAME)
		}
		}'
		;;
esac

. swloadenv ${1}
syslgsend "Ending loadTasks ${1}"
mbcmd kill load${1}.sh