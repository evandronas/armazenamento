#!/usr/bin/bash
    
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep region| awk '{print $3}'|sed  's/"//g'|sed 's/,//g')
PRELIMPEZA=$(aws ssm get-parameter --name "/online/limpeza/pre-limpeza" --region $REGION --output json | jq -r ".Parameter" | jq -r ".Value")
DIRLIMPEZA=$(aws ssm get-parameter --name "/online/limpeza/dir" --region $REGION --output json | jq -r ".Parameter" | jq -r ".Value")
ARQLIMPEZA=$(aws ssm get-parameter --name "/online/limpeza/arquivos" --region $REGION --output json | jq -r ".Parameter" | jq -r ".Value")
POSLIMPEZA=$(aws ssm get-parameter --name "/online/limpeza/pos-limpeza" --region $REGION --output json | jq -r ".Parameter" | jq -r ".Value")

eval ${PRELIMPEZA}

diretorios=$(echo $DIRLIMPEZA | tr "," "\n")
echo "Diretorios para limpeza: $diretorios"
arquivos=$(echo $ARQLIMPEZA | tr "," "\n")
echo "Arquivos para limpar: $arquivos"

for dir in $diretorios
do
    cd $dir
    if [ $? != 0 ]; then
        echo "Diretorio $dir nao existe."
        continue
    fi

    for arq in $arquivos
    do
        rm -vf $dir/$arq
    done

    echo "Executando limpeza dos arquivos no diretorio: [$dir] e em seus subdiretorios."
    find $dir -type f 2>/dev/null|xargs rm -vf
done

eval ${POSLIMPEZA}
