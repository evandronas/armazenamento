ps -ef | grep server.pl | grep -v grep
exit 0

