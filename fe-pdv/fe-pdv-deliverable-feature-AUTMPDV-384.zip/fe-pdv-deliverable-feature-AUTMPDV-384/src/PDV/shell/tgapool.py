#!/usr/bin/python3 -u
import random
import time
import os
import sys
import argparse
import json
import boto3
import botocore
from botocore.exceptions import ClientError
import socket

PGMPATH = os.path.basename(os.path.abspath(sys.argv[0]))
PARAMCONTROL = "/online/queues/tga"
PARAMLOCK    = "/online/queues/tga.lock"
EXIT_SUCCESS = 0
EXIT_ERROR = 1

def lock(ssm):
    ip = get_lock(ssm)
    while ip != "none":
        print(f"Parameter Store {PARAMLOCK} locked by {ip}. Waiting a second. If necessary use {PGMPATH} --unlock" )
        time.sleep(1)
        ip = get_lock(ssm)
    print("")
    instance = getlocalip()
    response = ssm.put_parameter(Name=PARAMLOCK, Value=instance, Type='String', Overwrite=True )

def unlock(ssm):
    instance = "none"
    response = ssm.put_parameter(Name=PARAMLOCK, Value=instance, Type='String', Overwrite=True )

def get_lock(ssm,decrypt=False):
    parameter = ssm.get_parameter(Name=PARAMLOCK, WithDecryption=decrypt )
    return parameter['Parameter']['Value']

def get_parameter( ssm, parameter, decrypt=False ):
    parameter = ssm.get_parameter(Name=parameter, WithDecryption=decrypt )
    return parameter['Parameter']['Value']

def update_parameter( ssm, data ):
    response = ssm.put_parameter(Name=PARAMCONTROL, Value=data, Type='String', Overwrite=True )
    return response

def getlocalip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    finally:
        s.close()
    return IP   
    
def tgapool( args, ssm ):
    jsondata = get_parameter( ssm=ssm, parameter=PARAMCONTROL, decrypt=True )
    pool_list = json.loads(jsondata)

    if( args.list ):
        
        for item in pool_list:
            if item["Instance"] == getlocalip():
                flag = "(*)"
            else:
                flag = ""
            print( item["Queue"], " -> ", item["Instance"], flag )

    if( args.num ):
        count = 0
        for item in pool_list:
            if item["Instance"].lower() == "free":
                count += 1
        print("Number of Free Queues : ", count)

    if( args.free ):
        found = False
        for item in pool_list:
            item["Instance"] = "free"
        jsondata = json.dumps( pool_list )
        update_parameter( ssm, jsondata )
        print("All Queues released")
    
    if( args.register ):
        ip = getlocalip()
        found = False
        for item in pool_list:
            queue = ""
            if item["Instance"] == ip:
                queue = item["Queue"]
                found = True
                break
            else:
                if item["Instance"].lower() == "free":
                    item["Instance"] = ip
                    queue = item["Queue"]
                    break

        jsondata = json.dumps( pool_list )
        update_parameter( ssm, jsondata )
        if found or queue != "":
            print("Queue Reserved :", queue )
            return EXIT_SUCCESS
        else:
            print(f"ERROR: No more Queues on Pool. View {PARAMCONTROL} or use {PGMPATH} --list")
            return EXIT_ERROR

    if( args.deregister ):
        found = False
        for item in pool_list:
            if item["Instance"].lower() == getlocalip() and not found:
                item["Instance"] = "free"
                print("Queue Released :", item["Queue"])
                found = True
        jsondata = json.dumps( pool_list )
        update_parameter( ssm, jsondata )
        if not found:
            print(f"WARNING: Server {getlocalip()} not registered on Pool previously" )
            return EXIT_ERROR
        else:
            return EXIT_SUCCESS

    return EXIT_SUCCESS

#
# Main Function
#
if __name__ == "__main__":
    ret = EXIT_SUCCESS

    parser = argparse.ArgumentParser(description=f'{PGMPATH} - Version 1.0')
    parser.add_argument("-r",    "--register",    help="Reserve Queue to Server",               action="store_true", required=False)
    parser.add_argument("-d",    "--deregister",  help="DeRegister/UnRegister Queue to Server", action="store_true", required=False)
    parser.add_argument("-l",    "--list",        help="List Current Queues",                   action="store_true", required=False)
    parser.add_argument("-n",    "--num",         help="Number of Free Queues",                 action="store_true", required=False)
    parser.add_argument("-f",    "--free",        help="Set All Queues as free",                action="store_true", required=False)
    parser.add_argument("-u",    "--unlock",      help="Force to Unlock ParamStore Access",     action="store_true", required=False)
    args = parser.parse_args()

    if not args.register and not args.deregister and not args.list and not args.num and not args.free and not args.unlock:
        print("No parameter found !!!")
        os.sys.exit(EXIT_ERROR)

    ssm = boto3.client('ssm', region_name=os.getenv("REGION"))

    if args.unlock:
        print( 'Previous Lock : ', get_lock(ssm))
        unlock(ssm)
        print( 'Current Lock : ', get_lock(ssm))
        os.sys.exit(ret)

    lock(ssm)
    ret = tgapool(args,ssm)
    unlock(ssm)

    os.sys.exit(ret)
