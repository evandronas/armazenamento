
echo "==========================================================================="
for PID in $(ps -ef | grep server.pl | grep -v grep | awk '{print $2}'); do
    echo "Finishing PID ${PID}"
    kill ${PID}
done
echo "==========================================================================="
exit 0

