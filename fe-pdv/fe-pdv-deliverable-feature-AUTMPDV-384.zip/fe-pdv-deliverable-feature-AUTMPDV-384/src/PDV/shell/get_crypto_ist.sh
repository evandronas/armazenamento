﻿if [[ "${1}" == "" ]]; then
	echo "Sintaxe : ${0} <SecretManagerRDS-Key>"
	exit 1
fi

TESTE=$(aws secretsmanager get-secret-value --secret-id "${1}" | jq -r ".SecretString" | jq -r '.password'|grep -i " error"|wc -l)
if [[ ${TESTE} -eq 0 ]]; then
	crypto2ist ${TESTE}
	exit 0
else
	echo "ERROR => ${TESTE}"
	exit 2
fi
