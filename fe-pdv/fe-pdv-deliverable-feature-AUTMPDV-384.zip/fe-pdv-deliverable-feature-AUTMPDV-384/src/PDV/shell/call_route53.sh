#!/bin/bash
# This script will call Route 53 Api through aws cli.
# Usage :
# sh call_route53.sh CREATE | DELETE | UPSERT
#

## VARIABLES FROM META-DATA

REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep region |awk -F\" '{print $4}')
OUTPUT_IP=$(curl -s http://169.254.169.254/latest/meta-data/local-ipv4)
ACTION=$1

## RETRIEVE VALUES FROM PARAMETER STORE

HOSTED_ZONE_ID=$(aws ssm get-parameters --name "/online/route53/POS/ptn/hosted-zone-id" --region $REGION --query "Parameters[*].{Value:Value}" --output text)
ROLE_PTN=$(aws ssm get-parameters --name "/online/route53/POS/ptn/role" --region $REGION --query "Parameters[*].{Value:Value}" --output text)
DNS_NAME=$(aws ssm get-parameters --name "/online/route53/POS/ptn/dns" --region $REGION --query "Parameters[*].{Value:Value}" --output text)

## ASSUMEROLE PTN ACCOUNT

aws sts assume-role --role-arn "$ROLE_PTN" --role-session-name "Route53Session" >> assume_role.json

sleep 2

ACCESS_KEY=$(cat assume_role.json | grep AccessKeyId | awk '{print $2}' | sed 's/"//g' | sed 's/,//g')
SECRET_ACCESS_KEY=$(cat assume_role.json | grep SecretAccessKey | awk '{print $2}' | sed 's/"//g' | sed 's/,//g')
SESSION_TOKEN=$(cat assume_role.json | grep SessionToken | awk '{print $2}' | sed 's/"//g' | sed 's/,//g')

rm -f assume_role.json

sleep 2

AWS_ACCESS_KEY_ID=$ACCESS_KEY
AWS_SECRET_ACCESS_KEY=$SECRET_ACCESS_KEY
AWS_SESSION_TOKEN=$SESSION_TOKEN

export AWS_ACCESS_KEY_ID
export AWS_SECRET_ACCESS_KEY
export AWS_SESSION_TOKEN

sleep 2

## CREATE OR DELETE RECORD ON ROUTE 53

aws route53 change-resource-record-sets --hosted-zone-id $HOSTED_ZONE_ID --change-batch '
{
  "Comment": "Testing creating a record set",
  "Changes": [
    {
      "Action": "'"$ACTION"'",
      "ResourceRecordSet": {
        "Name": "'"$DNS_NAME"'",
        "Type": "A",
        "TTL": 300,
        "ResourceRecords": [
          {
            "Value": "'"$OUTPUT_IP"'"
          }
        ]
      }
    }
  ]
}
'

sleep 2

## RECORD OUTPUT

if [ $ACTION != "DELETE" ]
then
        echo "==================================================="
        echo "The Record has been created on Route 53."
        echo "==================================================="
        aws route53 list-resource-record-sets --hosted-zone-id $HOSTED_ZONE_ID --query "ResourceRecordSets[?Name == '$DNS_NAME.']"
else
        echo "==================================================="
        echo "The Record has been deleted on Route 53."
        echo "==================================================="
fi

## REMOVE CREDENTIALS FROM THE SESSION

unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN