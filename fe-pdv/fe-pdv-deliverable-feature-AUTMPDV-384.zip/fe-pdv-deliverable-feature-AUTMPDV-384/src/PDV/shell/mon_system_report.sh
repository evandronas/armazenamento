#!/bin/ksh
#
# © Copyright [2013] REDE
# Fonte: mon_system_report.sh
# Autor: Joao Paulo Ferraz Costa / Data: 02/09/2011
# Descricao: Ferramenta para levantamento de dados sobre o sistema. Escreve 
#            escreve os dados em arquivo de texto a ser consumido pelo novo
#            sistema de monitoraç. 
#            Disponibiliza os seguintes dados:
#              - Data da coleta (AAAAMMDD);
#              - Hora da coleta (HHMMSS);
#              - Qtde. de Mail Boxes utilizados;
#              - Qtde. de Mail Boxes livres;
#              - Qtde. de Portas utilizadas;
#              - Qtde. de Portas livres;
#              - Qtde. de Buffers utilizados;
#              - Qtde. de Buffers livres;
#              - Qtde. de System Queues;
#              - Qtde. de Eventos;
#              - Qtde. de mensagens dropadas.
#
#             Ciclo de operaç: 3s.
#
#############################################################


#export HOME=/home/swadm

#cd /home/swadm

# Load Functions
. ~/GEN/shell/swvars.sh     # Carrega variaveis globais para o Sistema SW
. ~/GEN/shell/swfunc.sh              # Carrega funcoes genericas do SW
#. ${SCRIPT}/shell_func.sh               # Carrega funcoes genericas do SW


LOGERR=~/sw_web/mon_system_report.sh.txt
LOG_FILE=~/site/GEN/tmp/mon_system_report.log
SHSWNAME=mon_system_report.sh

# Gera os arquivos com permissãde leitura para o grupo "Outros"

umask o+rw

###################
# Funcoes Genericas
###################

#
# Carrega variaveis da ambiente conforme FE selecionado 
#

AMBIENTE()
{
	PARAMETRO=$1

	if [ $# != 1 ]
	then
		echo ""
		echo "======================================================================"
		echo "= ERRO : Parametro nao informado                                     ="
		echo "= Uso  : mon_system_report.sh POS|PO2|PDV|EC|HST|MCI|CRE|            ="
		echo "=                             DBT|DBTM|CRT|CRTM|CRTO|DBTO|WEB        ="	
		echo "======================================================================"
		echo ""
		exit
	fi

	if [ $PARAMETRO != POS ] && [ $PARAMETRO != PO2 ] && [ $PARAMETRO != PDV ] 	&& [ $PARAMETRO != EC ] && [ $PARAMETRO != HST ] && [ $PARAMETRO != MCI ]	&& [ $PARAMETRO != CRE ] && [ $PARAMETRO != DBT ] && [ $PARAMETRO != DBTM ]	&& [ $PARAMETRO != CRT ] && [ $PARAMETRO != CRTM ] && [ $PARAMETRO != WEB ] && [ $PARAMETRO != CRTO ] && [ $PARAMETRO != DBTO ]
	then
		echo ""
		echo "======================================================================"
		echo "= ERRO : Parametro incorreto                                         ="
		echo "= Uso  : mon_system_report.sh POS|PO2|PDV|EC|HST|MCI|CRE|            ="
		echo "=                             DBT|DBTM|CRT|CRTM|CRTO|DBTO|WEB        ="	
		echo "======================================================================"
		echo ""
		exit
	fi

	#
	# Carrega variaveis da ambiente 'acquirer'
	#

	if [ $PARAMETRO = POS ]
	then
		. swloadenv POS
	fi

	if [ $PARAMETRO = PO2 ]
	then
		. swloadenv PO2
	fi

	if [ $PARAMETRO = PDV ]
	then
		. swloadenv PDV
	fi

	if [ $PARAMETRO = EC ]
	then
		. swloadenv EC
	fi

	if [ $PARAMETRO = WEB ]
	then
		. swloadenv WEB
	fi

	#
	# Carrega variaveis da ambiente 'issuer'
	#

	if [ $PARAMETRO = HST ]
	then
		. swloadenv HST
	fi

	if [ $PARAMETRO = MCI ]
	then
		. swloadenv MCI
	fi

	if [ $PARAMETRO = CRE ]
	then
		. swloadenv CRE
	fi

	if [ $PARAMETRO = DBT ]
	then
		. swloadenv DBT
	fi

	if [ $PARAMETRO = DBTM ]
	then
		. swloadenv DBTM
	fi

	if [ $PARAMETRO = CRT ]
	then
		. swloadenv CRT
	fi

	if [ $PARAMETRO = CRTM ]
	then
		. swloadenv CRTM
	fi
	
	#
	# Tratamento do CRTO/DBTO 
	
	. swloadenv $PARAMETRO
}

GRAVALOG()
{
    echo "`date +'%d/%m/%Y %H:%M:%S'`('$LOGNAME')=>'" $1 >> $LOG_FILE
}

HEADER()
{
    SHELL_LOG $LOGERR $SHSWNAME "----------------------------------------------------"
    SHELL_LOG $LOGERR $SHSWNAME "Iniciando shell de Monitoracao do Sistema (dados).  "
    SHELL_LOG $LOGERR $SHSWNAME "----------------------------------------------------"

    GRAVALOG "-----------------------------------------------------------------"
    GRAVALOG "Iniciando shell de Monitoracao do Sistema (dados).               "
    GRAVALOG "-----------------------------------------------------------------"
}

HANDLE_SIGNAL()
{
    GRAVALOG "Finalizando processamento principal.                             "
    GRAVALOG "-----------------------------------------------------------------"
    GRAVALOG "Finalizando shell de Monitoracao do Sistema (dados).             "
    GRAVALOG "-----------------------------------------------------------------"
}

GERA_REGISTRO()
{

	#
	# Obtem dados principais
	#

	RECORD=`mbcmd usage | 
	awk '{
			if(NR == 5)
			{
				mb_box_1 = $3 
				mb_box_2 = $6
			}
			if(NR == 6)
			{
				port_1 = $2 
				port_2 = $5
			}
			if(NR == 7)
			{
				buff_1 = $3 
				buff_2 = $4
			}
			if(NR == 8)
			{
				system_queue_1 = $4
			}
			if(NR == 9)
			{
				events_1 = $2
			}
			if(NR == 10)
			{
				dropped_msg_1 = $3
			}

		}
		END {
			print mb_box_1 ";" mb_box_2 ";" port_1 ";" port_2 ";" buff_1 ";" buff_2 ";" system_queue_1 ";" events_1 ";" dropped_msg_1
		}'`
	#
	# Gera registro
	#

	#
	# Caso o IST esteja DOWN o valor de $RECORD sera apenas ";;;;;;;;"
	# Desta maneira, sera impresso com zeros.
	RECORD_TEST=`echo $RECORD | egrep -v ";;;;;;;;"`
	if [ -z "$RECORD_TEST" ]
	then
		RECORD="0;0;0;0;0;0;0;0;0"
	fi
	
	echo "$1;$RECORD"
}

OBTEM_VAL_PARAM()
{
	#Inicialmente verifica se existe o arquivo de configuracao no diretorio informado.
	if [ -f `ls $DEFAULT_PREFIX/cfg/monFlex.cfg 2> /dev/null` ]
	then
		#Visto que o arquivo foi encontrado, obtem os dados solicitados.

		# SLEEP_TIME: Intervalo de tempo que o script aguarda 
		#             para varrer o sistema e gerar novos dados.
		SLEEP_TIME=`grep "mon_Flex.sleep_time" $DEFAULT_PREFIX/cfg/monFlex.cfg | awk '{print $2}'`
		if [ -z "$SLEEP_TIME" ]
		then
			#Caso o parametro nao exista ou nao esteja configurado.
			SLEEP_TIME=3
			SHELL_LOG $LOGERR $SHSWNAME "Nao foi obtido valor para o parametro 'sleep_time'. "
			SHELL_LOG $LOGERR $SHSWNAME "Sera usado o padrao '$SLEEP_TIME'.                  "
			GRAVALOG "Nao foi obtido valor para o parametro 'sleep_time'. Serásado o valor "
			GRAVALOG "padrao '$SLEEP_TIME.'"
		else
			#O parametro foi encontrado mas precisa ser validado por ser numerico.
			if echo $SLEEP_TIME | egrep '^[0-9]+$' >/dev/null 2>&1
			then
				SHELL_LOG $LOGERR $SHSWNAME "Obtido valor para o parametro 'sleep_time': '$SLEEP_TIME'."
				GRAVALOG "Obtido valor para o parametro 'sleep_time': '$SLEEP_TIME'.      "
			else
				#Se o valor predefinido for invalido, utiliza o valor padrao.
				SHELL_LOG $LOGERR $SHSWNAME "Valor obtido invalido: '$SLEEP_TIME'.           "
				GRAVALOG "Valor obtido invalido: '$SLEEP_TIME'.                           "				
				
				SLEEP_TIME=3
				
				SHELL_LOG $LOGERR $SHSWNAME "Sera utilizado o valor padrao: '$SLEEP_TIME'.   "
				GRAVALOG "Sera utilizado o valor padrao: '$SLEEP_TIME'.                   "			
			fi
		fi
		
		# WORK_DIR: Diretorio onde serao escritos os arquivos
        #           de relatorio.		
		WORK_DIR=${HOME}/`grep "mon_Flex.report_path" $DEFAULT_PREFIX/cfg/monFlex.cfg | awk '{print $2}'`
		if [ -z "$WORK_DIR" ]
		then
			#Caso o parametro nao exista ou nao esteja configurado.
			WORK_DIR=${HOME}/sw_web/mon_flex/
			SHELL_LOG $LOGERR $SHSWNAME "Nao foi obtido valor para o parametro 'report_path'."
			SHELL_LOG $LOGERR $SHSWNAME "Sera usado o padrao '$WORK_DIR'.                    "
			GRAVALOG "Nao foi obtido valor para o parametro 'report_path'. Serásado"
			GRAVALOG "o valor padrao '$WORK_DIR.'"
		else
			#O parametro foi encontrado mas precisa ser validado se existe.
			if [ -d $WORK_DIR ]
			then
				SHELL_LOG $LOGERR $SHSWNAME "Obtido valor para o parametro 'report_path': '$WORK_DIR'."
				GRAVALOG "Obtido valor para o parametro 'report_path': '$WORK_DIR'.      "
			else
				SHELL_LOG $LOGERR $SHSWNAME "O diretorio '$WORK_DIR' nao existe. Criando     "
				GRAVALOG "O diretorio '$WORK_DIR' nao existe. Criando                "

                                mkdir -p $WORK_DIR
				
                                if [[ $? -ne 0 ]]
                                then
				    WORK_DIR=${HOME}/sw_web/mon_flex/
				
				    SHELL_LOG $LOGERR $SHSWNAME "Diretorio nao criado. Sera utilizado o diretorio padrao '$WORK_DIR'.  "
				    GRAVALOG "Diretorio nao criado. Sera utilizado o diretorio padrao '$WORK_DIR'.             "
                                fi
			fi	
		fi
	else
		#Visto que nao foi localizado arquivo de configuracao, utiliza os valores padrao.
		SLEEP_TIME=3
		WORK_DIR=${HOME}/sw_web/mon_flex/
		SHELL_LOG $LOGERR $SHSWNAME "Nao foi localizado o arquivo de configuracao no     "
		SHELL_LOG $LOGERR $SHSWNAME "caminho informado '$CFG'. Serao utilizados os valores "
		SHELL_LOG $LOGERR $SHSWNAME "padrao.                                             "

		GRAVALOG "Nao foi localizado o arquivo de configuracao no caminho informado"
		GRAVALOG "'$CFG'. Serao utilizados os valores padrao.                      "
	fi	
        if [[ ! -d $WORK_DIR/$PARAMETRO ]]
        then
            mkdir -p $WORK_DIR/$PARAMETRO
        fi
}

###########
# Principal
###########

AMBIENTE $1

# SLEEP_TIME: Intervalo de tempo que o script aguarda 
#             para varrer o sistema e gerar novos dados
SLEEP_TIME=3

trap 'HANDLE_SIGNAL;exit 0' 1 2 15

WORK_LOG=${HOME}/site/GEN/tmp
if [[ ! -d $WORK_LOG ]]
then
      mkdir -p $WORK_LOG
fi

HEADER

#
#
# Obtem os valores de trabalho do sistema do arquivo de configuracao
#
GRAVALOG "Obtendo dados de configuracao.                                   "
SHELL_LOG $LOGERR $SHSWNAME "Obtendo dados de configuracao.                      "
OBTEM_VAL_PARAM
#
# Laco de tratamento
GRAVALOG "Iniciando processamento principal.                               "
SHELL_LOG $LOGERR $SHSWNAME "Iniciando processamento principal.                  "
while true
do
	#
	# Gera data/hora do registro
	reg_date="`date +'%Y%m%d'`;`date +'%H%M%S'`"

	# 
	# Time_stamp geral da Nova Monitoracao
	TIME_STAMP=`date +'%Y%m%d'`_`date +'%H%M%S'`
	FILE_TIME_STAMP="/tmp/timestamp_"`echo $SITE`".txt"
	echo $TIME_STAMP > $FILE_TIME_STAMP

	# FILE_NAME: Nome do arquivo a ser utilizado 
	#FILE_NAME="`date +'%Y%m%d'`_`date +'%H%M%S'`_FLEX_BUFF.txt"
	FILE_NAME=""$TIME_STAMP"_FLEX_BUFF.txt";
	
	# Se o arquivo ja existe somente seta flag para adicionar
	# novo registro, senao seta flag para criar novo.
	if [ ! -f "`ls $WORK_DIR/$PARAMETRO/$FILE_NAME 2> /dev/null`" ]
	then	
		GERA_REGISTRO $reg_date > $WORK_DIR/$PARAMETRO/$FILE_NAME
	else
		GERA_REGISTRO $reg_date >> $WORK_DIR/$PARAMETRO/$FILE_NAME
	fi
	# Gregory - inclusãda geracao do mbtsk.debug
	tail -300 $OLOGDIR/debug/mbtsk.debug > $WORK_DIR/$PARAMETRO/mbtsk.debug
	#
	sleep $SLEEP_TIME
done

