#!/usr/bin/bash

err() {
  echo "[${MODULE}] ${RED}$*${RESET}" >&2
  exit 1
}

logsuccess() {
  echo "[${MODULE}] ${GREEN}$*${RESET}"
}

log() {
  echo "[${MODULE}] $*"
}

is_valid_FE()
{
	for IFE in ${VALIDFES}; do
		if [ "${IFE}" == "${1}" ]; then
			return 1
		fi
	done
	return 0
}

get_user()
{
	WHOAMI=$(whoami)
	if [ $( grep "${WHOAMI}" ${USERCONTROL} | wc -l ) -eq 0 ]; then
		echo "0"
	else
		grep "${WHOAMI}" ${USERCONTROL} | awk 'BEGIN { FS=";" }{ print $1 }'
	fi
}

get_ports()
{
	PORTFILE="${HOME}/sw-bin/cfg/swports.cfg"
	FE=${1}
	ID=$(get_user)
	# echo $ID
	PORTAINI_POS=$(grep  "^PORTIN |${ID} " ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $3}' | sed -e 's/ //g' )
	PORTAINI_PDV=$(grep  "^PORTIN |${ID} " ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $4}' | sed -e 's/ //g')
	PORTAINI_WEB=$(grep  "^PORTIN |${ID} " ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $5}' | sed -e 's/ //g')
	PORTASECURITY=$(grep "^PORTIN |${ID} " ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $6}' | sed -e 's/ //g')

	PORTAINI_CRT=$(grep  "^PORTISS |${ID} .*${FE}" ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $4}' | sed -e 's/ //g')
	PORTAINI_CRTM=$(grep "^PORTISS |${ID} .*${FE}" ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $5}' | sed -e 's/ //g')
	PORTAINI_CRTO=$(grep "^PORTISS |${ID} .*${FE}" ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $6}' | sed -e 's/ //g')
	PORTAINI_DBT=$(grep  "^PORTISS |${ID} .*${FE}" ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $7}' | sed -e 's/ //g')
	PORTAINI_DBTM=$(grep "^PORTISS |${ID} .*${FE}" ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $8}' | sed -e 's/ //g')
	PORTAINI_DBTO=$(grep "^PORTISS |${ID} .*${FE}" ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $9}' | sed -e 's/ //g')
	PORTAINI_HST=$(grep  "^PORTISS |${ID} .*${FE}" ${PORTCONTROL} | awk 'BEGIN { FS="|" } {print $10}' | sed -e 's/ //g')

# 1 - FE
# 2 - PORTNAME
# 3 - MAILBOX
# 4 - TIPO
# 5 - PORTDRIVER
# 6 - HOST
# 7 - PORTA
# 8 - DRIVER	

	if [ -f  ${PORTFILE} ]; then
		for PORTA in $(cat ${PORTFILE} | grep "^${FE}"); do
			PORTNAME=$(echo ${PORTA} | awk 'BEGIN {FS=":"} { print $2 }')
			MBNAME=$(echo ${PORTA} | awk 'BEGIN {FS=":"} { print $3 }')
			PORTTYPE=$(echo ${PORTA} | awk 'BEGIN {FS=":"} { print $4 }')
			PORTDRIVER=$(echo ${PORTA} | awk 'BEGIN {FS=":"} { print $5 }')
			HOST=$(echo ${PORTA} | awk 'BEGIN {FS=":"} { print $6 }')
			PORTNUM=$(echo ${PORTA} | awk 'BEGIN {FS=":"} { print $7 }')
			TCPIPFILE=$(echo ${PORTA} | awk 'BEGIN {FS=":"} { print $8 }')

			if [[ "${HOST}" == "@PORTSEC" ]];  then   
				HOST=${PORTASECURITY} 
			fi
				
			if [[ "${FE}" == "POS" && "${PORTNUM}" == "@PORTIN" ]]; then
				PORTNUM=${PORTAINI_POS}
				PORTAINI_POS=$((PORTAINI_POS+1))
			fi

			if [[ "${FE}" == "PDV" && "${PORTNUM}" == "@PORTIN" ]]; then
				PORTNUM=${PORTAINI_PDV}
				PORTAINI_PDV=$((PORTAINI_PDV+1))
			fi

			if [[ "${FE}" == "WEB" && "${PORTNUM}" == "@PORTIN" ]]; then
				PORTNUM=${PORTAINI_WEB}
				PORTAINI_WEB=$((PORTAINI_WEB+1))
			fi

			if [[ "${PORTNUM}" == "@PORTISS_CRT" ]];  then   
				PORTNUM=${PORTAINI_CRT} 
			fi

			if [[ "${PORTNUM}" == "@PORTISS_CRTO" ]]; then   
				PORTNUM=${PORTAINI_CRTO} 
			fi

			if [[ "${PORTNUM}" == "@PORTISS_CRTM" ]]; then   
				PORTNUM=${PORTAINI_CRTM} 
			fi

			if [[ "${PORTNUM}" == "@PORTISS_DBT" ]];  then   
				PORTNUM=${PORTAINI_DBT} 
			fi

			if [[ "${PORTNUM}" == "@PORTISS_DBTM" ]]; then   
				PORTNUM=${PORTAINI_DBTM} 
			fi

			if [[ "${PORTNUM}" == "@PORTISS_DBTO" ]]; then   
				PORTNUM=${PORTAINI_DBTO} 
			fi

			if [[ "${PORTNUM}" == "@PORTISS_HST" ]];  then   
				PORTNUM=${PORTAINI_HST} 
			fi
			
			printf "port.name  ${PORTNAME}  CurrentNode  ${MBNAME}  external  ${PORTTYPE}  <${PORTDRIVER}:${HOST}.${PORTNUM}:${TCPIPFILE}>\n\n"
		done
	else
		echo ""
	fi
}

set_my_offset()
{
	REGIONFILE="${HOME}/sw-bin/cfg/myregion.cfg"
	echo ${1} > ${REGIONFILE}
	chmod 666 ${REGIONFILE}
}

get_my_offset()
{
	REGIONFILE="${HOME}/sw-bin/cfg/myregion.cfg"
	if [ -f  ${REGIONFILE} ]; then
		cat ${REGIONFILE}
	else
		echo "0"
	fi
}

to_upper()
{
	echo ${@} | tr '[a-z]' '[A-Z]'
}

to_lower()
{
	echo ${@} | tr '[A-Z]' '[a-z]'
}

confirmYN()
{
	while true
	do
	    printf "$1 (Y/N) ? " ; read x
		case $x in
			y|Y)    return 0 ;;
			n|N)    return 1 ;;
		esac
	done
}

confirmSN()
{
	while true
	do
	    printf "$1 (S/N) ? " ; read x
		case $x in
			s|S)    return 0 ;;
			n|N)    return 1 ;;
		esac
	done
}

# Rotina de gravacao de log
# Parametros: 
#	$1 = Caminho/nome do arquivo de log
#	$2 = Nome do script chamador da funcao
#	$3 = Mensagem de erro
# Exemplo: SHELL_LOG /home/SW/tmp/arq_log.txt SHSW0010.sh "Erro ao apagar lock"
SHELL_LOG()
{
	SHLOG="$1"
	SHJOB="$2"
	SHMSG="$3"
	SHDATAHOJE=`date "+%d/%m/%Y %H:%M:%S"` 
	echo "$SHDATAHOJE $SHJOB $SHMSG" >> $SHLOG
}
#
# Obter usuario a partir de Chave do Parameter Store
# Parametros:
# $1 = Nome do Parameter Sotre do arquivo de log
#
get_db_user()
{
SECRETKEY=$(aws ssm get-parameter --name "${1}" --with-decryption --output text | awk '{ print $7 }' )
DBUSER=$(aws secretsmanager get-secret-value --secret-id "${SECRETKEY}" | jq -r ".SecretString" | jq -r '.username')
echo $DBUSER
}

#
# Obter Password a partir de Chave do Parameter Store e Secrets Manager
# Parametros:
# $1 = Nome do Parameter Sotre do arquivo de log
#
get_db_password()
{
SECRETKEY=$(aws ssm get-parameter --name "${1}" --with-decryption --output text | awk '{ print $7 }' )
PASS=$(aws secretsmanager get-secret-value --secret-id "${SECRETKEY}" | jq -r ".SecretString" | jq -r '.password')
echo $PASS
}

#
# Obter EndPoint a partir de Chave do Parameter Store e Secrets Manager
# Parametros:
# $1 = Nome do Parameter Sotre do arquivo de log
#
get_db_host()
{
SECRETKEY=$(aws ssm get-parameter --name "${1}" --with-decryption --output text | awk '{ print $7 }' )
ENDPOINT=$(aws secretsmanager get-secret-value --secret-id "${SECRETKEY}" | jq -r ".SecretString" | jq -r '.host')
echo $ENDPOINT
}

#
# Obter EndPoint a partir de Chave do Parameter Store e Secrets Manager
# Parametros:
# $1 = Nome do Parameter Sotre do arquivo de log
#
get_db_name()
{
SECRETKEY=$(aws ssm get-parameter --name "${1}" --with-decryption --output text | awk '{ print $7 }' )
ENDPOINT=$(aws secretsmanager get-secret-value --secret-id "${SECRETKEY}" | jq -r ".SecretString" | jq -r '.dbname')
echo $ENDPOINT
}

