import paramiko
import sys
import warnings

from host import Host

warnings.filterwarnings("ignore")

class Serverhost(Host):
    protocol = None

    def __init__(self, hostname, port, username):
        self.protocol = paramiko.SSHClient()
        self.protocol.load_system_host_keys()
        self.protocol.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        super().__init__(hostname, port, username)    

    def __init__(self, hostname, port, username, password):
        self.protocol = paramiko.SSHClient()
        self.protocol.load_system_host_keys()
        self.protocol.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        super().__init__(hostname, port, username, password)

    def connect(self):
        if (self.PASSWORD != '' ):
            self.protocol.connect(hostname=self.HOSTNAME,
                                username=self.USERNAME,
                                password=self.PASSWORD,
                                port=self.PORT)
        else:
            self.protocol.connect(hostname=self.HOSTNAME,
                                username=self.USERNAME,
                                port=self.PORT)

    def close(self):
        self.protocol.close()

    def cmd(self, command):
        ret = ''

        stdin, stdout, stderr = self.protocol.exec_command(command, get_pty=True)

        ret = stderr.channel.recv_exit_status()
        out = stdout.read().decode('latin-1')
        err = stderr.read().decode('latin-1')

        return ret, out, err

    def recv_from(self, src, dest):
        sftp = self.protocol.open_sftp()
        sftp.get(src,dest)
        sftp.close()

    def send_to(self, src, dest):
        sftp = self.protocol.open_sftp()
        sftp.put(src,dest)
        sftp.close()     

    def listdir(self, rdir):
        sftp = self.protocol.open_sftp()
        rfiles = sftp.listdir(rdir)

        return rfiles
