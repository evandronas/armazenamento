# wLogReader

Página para quebrar mensagens ISO da sigla SW (trechos terminal e bandeira)