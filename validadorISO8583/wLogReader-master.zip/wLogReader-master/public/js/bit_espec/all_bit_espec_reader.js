// all_bit_espec_reader.js

function all_bit_espec_reader()
{
    var bit_espec = kHTML_CBOX_DRIVER.value

    msg_break_bit = msg

    switch(bit_espec)
    {
        case kBIT_POS_DE47:
            break_bit47_pos()
            break

        case kBIT_POS_DE48:
            break_bit48_pos()
            break

        case kBIT_POS_DE55:
            genBreakBit55Puro()
            break

        case kBIT_GEN_DE55_ASCII:
            genBreakBit55Ascii()
            break

        case kBIT_GEN_DE55_EBCDIC:
            genBreakBit55Ebc()
            break

        case kBIT_DE55_VISA:
            break_bit55_visa()
            break

        default:
            alert("Opção [" + bit_espec + "] não mapeada.")
            return
    }

    all_bit_espec_display_result()
}

function all_bit_espec_display_result()
{
    // mensagem formatada
    kHTML_LABEL_MSG_FORMATTED.innerHTML = ""
    kHTML_LABEL_MSG_FORMATTED.innerHTML += get_break_line()
    kHTML_LABEL_MSG_FORMATTED.innerHTML += msg_formatted
    kHTML_LABEL_MSG_FORMATTED.innerHTML += get_break_line()
}
