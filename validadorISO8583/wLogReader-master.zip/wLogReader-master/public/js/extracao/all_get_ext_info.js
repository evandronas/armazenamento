// all_get_ext_info.js

function get_ext_info_all(cap)
{
    // console.log("get_ext_info_all [%s]", cap)

    /*
    ret_info_ext (objeto da CAP)

    array_fields        [string]    array com os objetos dos campos
    opcionais           [num]       quantidade de campos opcionais (de tras pra frente)
    */

    /*
    field (definidos na funcao generica dos campos)

    nomeBd              [string]    nome do campo na tabela do SW 7.5
    nomeBd71            [string]    nome do campo na tabela do SW 7.1
    len                 [num]       tamanho
    isFixo              [bool]      campo fixo
    isTipoReg           [bool]      indica que eh o campo do tipo de registro
    isIndicador         [bool]      indica que eh o campo do tipo de indicador
    formatMoney         [bool]      formatar o valor com a moeda
    nomeDisplay         [string]    nomeDisplay do campo
    nomeDisplayOver     [string]    nomeDisplay do campo, sobrescreve a nomeDisplay
    ignoreDescFunc      [bool]      true = ignora a funcao de descricao
    ignoreNomeDisplay   [bool]      true = ignora o nome do campo
    formatDateIn        [string]    formato da data de entrada
    formatDateOut       [string]    formato da data de saida
    formatDateInOver    [string]    formato da data de entrada, sobrescreve a formatDateIn
    formatDateOutOver   [string]    formato da data de saida, sobrescreve a formatDateOut
    */

    // cap = cap.toUpperCase()
    var info

    switch (cap)
    {
        // Financeira

        case kEXT_CAPCRED:
            info = capcred_ext_fields()
            break

        case kEXT_CAPCREDD: // 75 web
            info = capcredd_ext_fields()
            break

        case kEXT_CAPCREDAMEX:
            info = capcredamex_ext_fields()
            break

        case kEXT_CAPCREDAMEXD: // 75 web
            info = capcredamexd_ext_fields()
            break

        case kEXT_CAPCREDELO:
            info = capcredelo_ext_fields()
            break

        case kEXT_CAPCREDELOD: // 75 web
            info = capcredelod_ext_fields()
            break

        case kEXT_CAPCREDELOVAN:
            info = capcredelovan_ext_fields()
            break

        case kEXT_CAPCREDVAN:
            info = capcredvan_ext_fields()
            break

        case kEXT_CAPCREDVISA:
            info = capcredvisa_ext_fields()
            break

        case kEXT_CAPCREDVISAD: // 75 web
            info = capcredvisad_ext_fields()
            break

        case kEXT_CAPDEB:
            info = capdeb_ext_fields()
            break

        case kEXT_CAPDEBMC:
            info = capdebmc_ext_fields()
            break

        case kEXT_CAPDEBMCD:
            info = capdebmcd_ext_fields()
            break

        case kEXT_CAPDEBD: // 75 web
            info = capdebd_ext_fields()
            break

        case kEXT_CAPDEBELO:
            info = capdebelo_ext_fields()
            break

        case kEXT_CAPDEBELOD: // 75 web
            info = capdebelod_ext_fields()
            break

        case kEXT_CAPDEBELOVAN:
            info = capdebelovan_ext_fields()
            break

        case kEXT_CAPDEBVAN:
            info = capdebvan_ext_fields()
            break

        // case kEXT_CAPDEBVAN_71:
        //     info = capdebvan_ext_fields_71()
        //     break

        // case kEXT_CAPDEBVAN_75:
        //     info = capdebvan_ext_fields_75()
        //     break

        case kEXT_CAPDEBVISA:
            info = capdebvisa_ext_fields()
            break

        case kEXT_CAPDEBVISAD:
            info = capdebvisad_ext_fields()
            break

        case kEXT_CAPPRIV:
            info = cappriv_ext_fields()
            break

        case kEXT_CAPCRCUP:
            info = capcrcup_ext_fields()
            break

        // Dados Chip

        case kEXT_CAPCHFUL:
            info = capchful_ext_fields()
            break

        case kEXT_CAPCHFULAMEX:
            info = capchfulamex_ext_fields()
            break

        // case kEXT_CAPCHFULAMEX_71:
        //     info = capchfulamex_ext_fields_71()
        //     break

        // case kEXT_CAPCHFULAMEX_75:
        //     info = capchfulamex_ext_fields_75()
        //     break

        case kEXT_CAPCHFULDEB:
            info = capchfuldeb_ext_fields()
            break

        case kEXT_CAPCHFULDEBELO:
            info = capchfuldebelo_ext_fields()
            break

        case kEXT_CAPCHFULDEBVAN:
            info = capchfuldebvan_ext_fields()
            break

        case kEXT_CAPCHFULDEBVISA:
            info = capchfuldebvisa_ext_fields()
            break

        case kEXT_CAPCHFULELO:
            info = capchfulelo_ext_fields()
            break

        case kEXT_CAPCHFULVAN:
            info = capchfulvan_ext_fields()
            break

        case kEXT_CAPCHFULVISA:
            info = capchfulvisa_ext_fields()
            break

        case kEXT_CAPCHPRV:
            info = capchprv_ext_fields()
            break

        case kEXT_CAPCHUPI:
            info = capchupi_ext_fields()
            break

        case kEXT_CAPCHDEBMC:
            info = capchdebmc_ext_fields()
            break

        // Dados Adicionais

        case kEXT_EXTIATA:
            info = extiata_ext_fields()
            break

        case kEXT_SIMULCREDIARIO:
            info = simulcrediario_ext_fields()
            break

        case kEXT_TRNNEGADAS:
            info = trnnegadas_ext_fields()
            break

        case kEXT_TRNAPROVADAS:
            info = trnaprovadas_ext_fields()
            break

        case kEXT_CAPCREDQRC:
            info = capcredqrc_ext_fields()
            break

        case kEXT_CAPDEBQRC:
            info = capdebqrc_ext_fields()
            break

        case kEXT_CAPNFIN:
            info = capnfin_ext_fields()
            break

        // Servico

        case kEXT_CAPPSERV:
            info = cappserv_ext_fields()
            break

        case kEXT_CAPITI:
            info = capiti_ext_fields()
            break

        case kEXT_CAPRCRG:
            info = caprcrg_ext_fields()
            break

        case kEXT_CAPSERVRCRG:
            info = capservrcrg_ext_fields()
            break

        case kEXT_CAPPIX:
            info = cappix_ext_fields()
            break

        // Relatorio

        case kEXT_CAPCREDCONS:
            info = capcredcons_ext_fields()
            break

        case kEXT_CAPCREDCONS1:
            info = capcredcons1_ext_fields()
            break

        case kEXT_CAPCREDCONSVISA:
            info = capcredconsvisa_ext_fields()
            break

        case kEXT_CAPDEBCONS:
            info = capdebcons_ext_fields()
            break

        case kEXT_CAPDEBCONS1:
            info = capdebcons1_ext_fields()
            break

        case kEXT_CAPDEBCONSVISA:
            info = capdebconsvisa_ext_fields()
            break

        case kEXT_CAPEND:
            info = capend_ext_fields()
            break

        case kEXT_DEBFRD:
            info = debfrd_ext_fields()
            break

        case kEXT_REVAMEX:
            info = revamex_ext_fields()
            break

        // OL

        case kEXT_OLTO:
            info = olto_ext_fields()
            break
    }

    // colocar o nome da CAP no objeto
    if (info)
    {
        info.cap = cap	
    }

    return info
}
