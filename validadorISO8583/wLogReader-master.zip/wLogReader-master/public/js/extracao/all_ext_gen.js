// all_ext_gen.js

function all_ext_display_result(ret_info_ext)
{
    // mensagem formatada
    kHTML_LABEL_MSG_FORMATTED.innerHTML = ""
    kHTML_LABEL_MSG_FORMATTED.innerHTML += get_break_line()
    kHTML_LABEL_MSG_FORMATTED.innerHTML += msg_formatted
    kHTML_LABEL_MSG_FORMATTED.innerHTML += get_break_line()

    // mensagem clean
    kHTML_LABEL_MSG_CLEAN.innerHTML = ""
    if (kHTML_CB_SEM_FORMATACAO.checked)
    {
        kHTML_LABEL_MSG_CLEAN.innerHTML = "Somente os valores, sem formatação" + "<br><br>"
        kHTML_LABEL_MSG_CLEAN.innerHTML += msg_clean
        kHTML_LABEL_MSG_CLEAN.innerHTML += get_break_line()
        kHTML_LABEL_MSG_CLEAN.innerHTML += get_break_line()
    }
}
