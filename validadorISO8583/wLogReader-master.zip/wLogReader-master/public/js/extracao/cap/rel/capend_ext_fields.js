// capend_ext_fields.js

function capend_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "COD_TERM" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "DTH_INI_TRAN" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
