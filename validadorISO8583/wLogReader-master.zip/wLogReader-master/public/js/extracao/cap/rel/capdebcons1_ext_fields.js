// capdebcons1_ext_fields.js

function capdebcons1_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isFixo: true, len: 8, nomeDisplayOver: "Data Confirmação" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "TIP_TRAN", len: 4 },
            { isFixo: true, len: 3, nomeDisplayOver: "Moeda" },
            { isFixo: true, len: 10, nomeDisplayOver: "Total Transação" },
            { isFixo: true, len: 10, nomeDisplayOver: "Valor Total", formatMoney: true },
            { isFixo: true, len: 10, nomeDisplayOver: "Valor Total Taxas", formatMoney: true },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
