// revamex_ext_fields.js

function revamex_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN" },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN" },
            { nomeBd: "DTH_INI_TRAN" },
            { isFixo: true, len: 3 }, // "000"
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "COD_RAM_ATVD" },
            { nomeBd: "NUM_CAR" },
            { isFixo: true, len: 3 }, // "400"
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "VAL_TX", len: 12 },
            { nomeBd: "QTD_PRCL" },
            { nomeBd: "VAL_PRCL" },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "NUM_SEQ_CAR_VLDC_CHIP" },
            { nomeBd: "VAL_PRCL_ENTR", len: 12 },
            { nomeBd: "IND_TERM_RLCD_CHIP" },
            { nomeBd: "COD_MOT_SW" },
            { nomeBd: "COD_MOED" },
            { isFixo: true, len: 255 }, // "espacos"
            { isFixo: true, len: 1 }, // "0"
            { isFixo: true, len: 255 }, // "espacos"
            { nomeBd: "COD_CNDC_CPTR" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "NUM_STAN" },
            { nomeBd: "NUM_PDV_VAN" },
            { nomeBd: "NUM_PDV_EXT" },
            { nomeBd: "TIP_TRAN", len: 1, ignoreNomeDisplay: true },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
