// debfrd_ext_fields.js

function debfrd_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "NUM_TEL_CMDR" },
            { nomeBd: "COD_CHCK_PDV" },
            { nomeBd: "IND_PRSC_CVC_2" },
            { nomeBd: "COD_VERS_SFTW" },
            { nomeBd: "NUM_ID_PNPD" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
