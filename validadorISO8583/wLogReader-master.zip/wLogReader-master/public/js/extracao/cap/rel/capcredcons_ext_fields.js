// capcredcons_ext_fields.js

function capcredcons_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isFixo: true, len: 8, nomeDisplayOver: "Total Transação" },
            { isFixo: true, len: 13, nomeDisplayOver: "Valor Total", formatMoney: true },
            { isFixo: true, len: 11, nomeDisplayOver: "Valor Total Taxas", formatMoney: true },
            { isFixo: true, len: 8, nomeDisplayOver: "Total Transação Dólar" },
            { isFixo: true, len: 13, nomeDisplayOver: "Valor Total Dólar", formatMoney: true },
            { isFixo: true, len: 11, nomeDisplayOver: "Valor Total Taxas Dólar", formatMoney: true },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
