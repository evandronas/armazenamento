// capdebcons_ext_fields.js

function capdebcons_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isFixo: true, len: 4, nomeDisplayOver: "Tipo" },
            { isFixo: true, len: 8, nomeDisplayOver: "Total Transação" },
            { isFixo: true, len: 13, nomeDisplayOver: "Valor Total", formatMoney: true },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
