// capiti_ext_fields.js

function capiti_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN" },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN" },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "NUM_MOT_RSPS" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "TIP_TERM" },
            { nomeBd: "NUM_STAN" },
            { nomeBd: "NUM_RD_ORG" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_VERS_SIS" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "TIP_VD" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "COD_RAM_ATVD" },
            { nomeBd: "NUM_CAR" },
            { nomeBd: "COD_MOT_RSPS_EXT" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "VAL_TX" },
            { nomeBd: "VAL_COT_DLR" },
            { nomeBd: "QTD_PRCL" },
            { nomeBd: "VAL_PRCL" },
            { nomeBd: "DAT_VLD_CAR" },
            { nomeBd: "COD_MOED" },
            { nomeBd: "COD_OPER_CNFR" },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "NUM_CV" },
            { nomeBd: "VAL_TRAN_DLR" },
            { nomeBd: "IND_DA_RLCD_CHIP" },
            { nomeBd: "COD_CTGR_TRAN" },
            { nomeBd: "COD_RSPS_AVS" },
            { isFixo: true, len: 9, nomeDisplayOver: "NU_ETB_CRE" },
            { nomeBd: "VAL_PRCL_ENTR" },
            { nomeBd: "IND_TRK" },
            { nomeBd: "IND_CPTR_CVC_2" },
            { nomeBd: "COD_MOT_SW" },
            { nomeBd: "COD_RAM_MCC" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
