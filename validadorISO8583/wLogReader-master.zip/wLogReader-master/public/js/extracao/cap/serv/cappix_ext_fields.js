// cappix_ext_fields.js

function cappix_ext_fields()
{
    var info = {
        array_fields: [
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN", len: 7 },
            { nomeBd: "COD_MSG_ISO" },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "NUM_MOT_RSPS" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "TIP_TERM" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "COD_RAM_ATVD" },
            { nomeBd: "COD_MOED" },
            { nomeBd: "COD_MOT_SW" },
            { nomeBd: "COD_RAM_MCC" },
            { nomeBd: "COD_PRCR" },
            { nomeBd: "ID_RQSC_PIX" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
        separadorCampo: true,
    }

    return info
}
