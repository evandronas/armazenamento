// cappserv_ext_fields.js

function cappserv_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN" },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN" },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "NUM_MOT_RSPS" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "NUM_STAN" },
            { nomeBd: "NUM_RD_ORG" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "COD_BNDR", len: 3 },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "COD_RAM_ATVD" },
            { nomeBd: "NUM_ID_CAR" },
            { nomeBd: "NUM_CAR" },
            { nomeBd: "COD_MOT_RSPS_EXT" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "COD_PAIS_CAR" },
            { nomeBd: "COD_MOED" },
            { nomeBd: "COD_OPER_CNFR" },
            { nomeBd: "DTH_STTU_TRAN" }, // data
            { nomeBd: "DTH_INI_TRAN" }, // hora DTH_STTU_TRAN
            { nomeBd: "COD_CNDC_CPTR" },
            { nomeBd: "COD_CTGR_TRAN" },
            { nomeBd: "NUM_AUT" },
            { nomeBd: "TIP_TRAN_ORGL" },
            { nomeBd: "IND_TRK" },
            { nomeBd: "IND_CPTR_CVC_2" },
            { nomeBd: "COD_MOT_SW" },
            { nomeBd: "COD_RAM_MCC" },
            { nomeBd: "COD_SERV_SNHA" },
            { nomeBd: "DAT_CTB_TRAN" },
            { nomeBd: "TXT_DA_ADIC_EMSR" },
            { nomeBd: "IND_DA_RLCD_KMRC" },
            { nomeBd: "COD_PROD_PRCR" },
            { nomeBd: "NUM_PDDO_CMC_ELET" },
            { nomeBd: "COD_ID_DTCH" },
            { nomeBd: "NOM_FNTS_PDV" },
            { nomeBd: "COD_TIP_ORG_TRAN_WEB" },
            { nomeBd: "TIP_DTLH_TRAN" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
