// capservrcrg_ext_fields.js

function capservrcrg_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "DAT_MOV_TRAN" },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN", len: 1, ignoreNomeDisplay: true },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_SERV_TRAN" },
            { nomeBd: "NUM_PDV_ORG_TRAN" },
            { nomeBd: "COD_TERM_ORG_TRAN" },
            { nomeBd: "NUM_DDD_RCRG" },
            { nomeBd: "NUM_TEL_RCRG" },
            { nomeBd: "NUM_SEQ_UNC_OPER" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "VAL_TRAN" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
