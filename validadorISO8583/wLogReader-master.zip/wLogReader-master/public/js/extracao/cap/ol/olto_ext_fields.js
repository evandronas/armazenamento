// olto_ext_fields.js

function olto_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true, len: 2 },
            { isFixo: true, len: 10, nomeDisplayOver: "Código Empresa" },
            { isFixo: true, len: 4, nomeDisplayOver: "Sequência Fita" },
            { isFixo: true, len: 5, nomeDisplayOver: "Número Lote" },
            { isFixo: true, len: 3, nomeDisplayOver: "Seq. Reg. Dentro Lote" },
            { isFixo: true, len: 3, nomeDisplayOver: "Código Transação" },
            { isFixo: true, len: 16, nomeDisplayOver: "Número Cartão" },
            { isFixo: true, len: 15, nomeDisplayOver: "Valor Transação" },
            { isFixo: true, len: 6, nomeDisplayOver: "Data Transação" },
            { isFixo: true, len: 8, nomeDisplayOver: "Hora Transação" },
            { isFixo: true, len: 6, nomeDisplayOver: "Tipo Transação" },
            { isFixo: true, len: 2, nomeDisplayOver: "Quantidade Parcelas" },
            { isFixo: true, len: 4, nomeDisplayOver: "Validade Cartão" },
            { isFixo: true, len: 9, nomeDisplayOver: "Estabelecimento" },
            { isFixo: true, len: 3, nomeDisplayOver: "Código Moeda" },
            { isFixo: true, len: 6, nomeDisplayOver: "Código Autorização" },
            { isFixo: true, len: 2, nomeDisplayOver: "Motivo Rejeição" },
            { isFixo: true, len: 40, nomeDisplayOver: "Mensagem Rejeição" },
            { isFixo: true, len: 6, nomeDisplayOver: "Autorização Emissor" },
            { isFixo: true, len: 7, nomeDisplayOver: "NSU Sistema SW" },
            { isFixo: true, len: 15, nomeDisplayOver: "NSU Visa" },
            { isFixo: true, len: 12, nomeDisplayOver: "POS Data Code Amex" },
            { isFixo: true, len: 15, nomeDisplayOver: "TID Amex" },
            { isFixo: true, len: 3, nomeDisplayOver: "Código Produto Master" },
            { isFixo: true, len: 1, nomeDisplayOver: "Código Origem Autorização Elo" },
            { isFixo: true, len: 1, nomeDisplayOver: "Código Capacidade Terminal Elo" },
            { isFixo: true, len: 1, nomeDisplayOver: "Código Portador Presente Elo" },
            { isFixo: true, len: 6, nomeDisplayOver: "Código Processamento Emissor Elo" },
            { isFixo: true, len: 15, nomeDisplayOver: "NRID Elo" },
            { isFixo: true, len: 24, nomeDisplayOver: "Filler" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
