// capdebelod_ext_fields.js

function capdebd_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN" },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN" },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "NUM_MOT_RSPS" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "TIP_TERM" },
            { nomeBd: "NUM_STAN" },
            { nomeBd: "NUM_RD_ORG" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_VERS_SIS" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "TIP_VD" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "COD_RAM_ATVD" },
            { nomeBd: "NUM_CAR" },
            { nomeBd: "COD_MOT_RSPS_EXT" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "VAL_TX" },
            { nomeBd: "VAL_COT_DLR" },
            { nomeBd: "QTD_PRCL" },
            { nomeBd: "VAL_PRCL" },
            { nomeBd: "DAT_VLD_CAR" },
            { nomeBd: "COD_MOED" },
            { isFixo: true, len: 37 }, // Trilha "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
            { nomeBd: "NUM_BCO_DEB" },
            { nomeBd: "NUM_EMSR" },
            { nomeBd: "NUM_BCO_ESTB" },
            { nomeBd: "NUM_AGE_ESTB" },
            { nomeBd: "COD_CTA_ESTB" },
            { nomeBd: "DAT_CTB_TRAN" },
            { nomeBd: "COD_OPER_CNFR" },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "TXT_DA_ADIC_EMSR" },
            { nomeBd: "TIP_DTLH_TRAN" },
            { nomeBd: "COD_BNDR" },
            { nomeBd: "NUM_CV" },
            { nomeBd: "VAL_TRAN_DLR" },
            { isFixo: true, len: 4 }, // "    "
            { nomeBd: "NUM_SEQ_CAR_VLDC_CHIP" },
            { nomeBd: "IND_DA_RLCD_CHIP" },
            { nomeBd: "COD_CTGR_TRAN" },
            { isFixo: true, len: 1 }, // "0"
            { isFixo: true, len: 9 }, // "000000000"
            { nomeBd: "VAL_PRCL_ENTR" },
            { nomeBd: "IND_CNFR_PSTV" },
            { nomeBd: "TIP_RPSS_VAL" },
            { nomeBd: "VAL_RPSS" },
            { nomeBd: "VAL_LQDC" },
            { nomeBd: "VAL_RCD" },
            { isFixo: true, len: 1 }, // "0"
            { isFixo: true, len: 1 }, // "0"
            { isFixo: true, len: 3 }, // "000"
            { nomeBd: "PRCN_TX_RISC" },
            { nomeBd: "VAL_TX_RISC" },
            { nomeBd: "NOM_LOC_ESTB" },
            { nomeBd: "DAT_PRE_DATDO" },
            { nomeBd: "COD_RAM_MCC" },
            { nomeBd: "TIP_LQDC" },
            { nomeBd: "COD_CLI" },
            { nomeBd: "COD_DSTR" },
            { nomeBd: "COD_REF_EMSR" },
            { nomeBd: "COD_CMPM_TRAN" },
            { nomeBd: "VAL_SQUE" },
            { nomeBd: "PRCN_TX_JURO_MES" },
            { nomeBd: "QTD_CICL_CRNC_PRMR_PRCL" },
            { nomeBd: "VAL_PRCL", len: 9 },
            { isFixo: true, len: 3 }, // "000"
            { nomeBd: "PRCN_TX_JURO" },
            { isFixo: true, len: 4 }, // "0000"
            { isFixo: true, len: 5 }, // "00000"
            { isFixo: true, len: 4 }, // "0000"
            { isFixo: true, len: 11 }, // "00000000000"
            { nomeBd: "VAL_TX", len: 6 },
            { isFixo: true, len: 6 }, // "000000"
            { nomeBd: "VAL_TX", len: 6 },
            { isFixo: true, len: 6 }, // "000000"
            { isFixo: true, len: 6 }, // "000000"
            { nomeBd: "QTD_PRCL", len: 2 },
            { nomeBd: "VAL_TRAN", len: 11 },
            { nomeBd: "VAL_EFTV_APRV" },
            { isFixo: true, len: 1 }, // "S"
            { nomeBd: "COD_SERV_TRK_CAR" },
            { nomeBd: "COD_RVDA_PROD_MTC" },
            { nomeBd: "NUM_PDDO_CMC_ELET" },
            { nomeBd: "COD_ID_DTCH" },
            { nomeBd: "NOM_FNTS_PDV" },
            { nomeBd: "COD_PROD_CDST" },
            { nomeBd: "COD_GRU_CLAS_RAM" },
            { nomeBd: "IND_DA_TIT_CAR_AMZT" },
            { nomeBd: "NOM_CID_SMRC" },
            { nomeBd: "COD_PAIS_SMRC" },
            { nomeBd: "NUM_CEP_SMRC" },
            { nomeBd: "SGL_EST_SMRC" },
            { nomeBd: "DES_ENDR_SMRC" },
            { nomeBd: "ID_FACR_PGMN_BNDR" },
            { nomeBd: "COD_SMRC" },
            { nomeBd: "NUM_CNPJ_SMRC" },
            { nomeBd: "IND_PGMN_RECRRN" },
            { nomeBd: "IND_TRAN_TKN" },
            { nomeBd: "COD_NVL_SGRA_TKN" },
        ],
        opcionais: 4, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
