// capcredelovan_ext_fields.js

function capcredelovan_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN" },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN" },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "NUM_MOT_RSPS" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "TIP_TERM" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "COD_RAM_ATVD" },
            { nomeBd: "NUM_ID_CAR" },
            { nomeBd: "NUM_CAR" },
            { nomeBd: "COD_MOT_RSPS_EXT" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "VAL_TX" },
            { nomeBd: "QTD_PRCL" },
            { nomeBd: "VAL_PRCL" },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "DTH_STTU_TRAN", nomeDisplayOver: "Hora Confirmação" },
            { nomeBd: "NUM_SEQ_CAR_VLDC_CHIP" },
            { nomeBd: "IND_DA_RLCD_CHIP" },
            { nomeBd: "VAL_PRCL_ENTR" },
            { nomeBd: "IND_TERM_RLCD_CHIP" },
            { nomeBd: "COD_MOT_SW" },
            { nomeBd: "COD_MOED" },
            { nomeBd: "TXT_RLCD_CHIP" },
            { nomeBd: "COD_PGM_AUT" },
            { isFixo: true, len: 1 }, // " "
            { nomeBd: "NUM_AUT" },
            { nomeBd: "NUM_CV" },
            { nomeBd: "TXT_RLCD_CHIP" },
            { nomeBd: "COD_CNDC_CPTR", len: 16 },
            { isFixo: true, len: 1 }, // "1"
            { isFixo: true, len: 2 }, // "  "
            { nomeBd: "COD_RGAO_MTC" },
            { nomeBd: "NUM_STAN", len: 9 },
            { nomeBd: "TXT_RLCD_CHIP", len: 1 },
            { nomeBd: "TXT_INFO_CMPM_CHIP" },
            { nomeBd: "TXT_RSTD_ATLZ_CHIP", len: 10 },
            { nomeBd: "TXT_DA_ADIC_EMSR", len: 15 },
            { nomeBd: "NUM_PDV_EXT" },
            { isFixo: true, len: 1 }, // "C"
            { isFixo: true, len: 39 }, // "                                       "
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
