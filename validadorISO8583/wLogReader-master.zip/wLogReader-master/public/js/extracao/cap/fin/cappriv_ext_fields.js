// cappriv_ext_fields.js

function cappriv_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN", len: 10 },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "DTH_INI_TRAN", len: 26, nomeDisplayOver: "Data/Hora" },
            { nomeBd: "NUM_RD_ORG" },
            { nomeBd: "NUM_SEQ_UNC", len: 9 },
            { nomeBd: "NUM_RD_DEST" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "COD_EMSR", len: 5 },
            { nomeBd: "COD_MOT_ESTR_DEST" },
            { nomeBd: "COD_MOT_RSPS_DEST" },
            { nomeBd: "COD_MOT_RSPS_EXT" },
            { nomeBd: "COD_OPER_CNFR" },
            { nomeBd: "COD_OPER_ESTR" },
            { nomeBd: "COD_PCM_ISO" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "TIP_TERM" },
            { nomeBd: "NUM_STAN", len: 7 },
            { nomeBd: "COD_TRK_CAR", len: 40 },
            { nomeBd: "COD_ITEM" },
            { nomeBd: "DAT_VLD_CAR" },
            { nomeBd: "TXT_DA_ADIC_EMSR", len: 40 },
            { isFixo: true, len: 8 },
            { nomeBd: "DTH_INI_TRAN", len: 8 },
            { isFixo: true, len: 1 },
            { nomeBd: "TIP_MODO_TRAN" },
            { nomeBd: "TIP_MSG" },
            { nomeBd: "TIP_TRAN" },
            { nomeBd: "TIP_VD_SAID" },
            { nomeBd: "NUM_CAR" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "NUM_MOT_RSPS" },
            { nomeBd: "NUM_OPER_ETD" },
            { nomeBd: "QTD_PRCL" },
            { nomeBd: "COD_RAM_ATVD" },
            { nomeBd: "VAL_TRAN", len: 15 },
            { nomeBd: "QTD_CICL_CRNC_PRMR_PRCL", len: 3 },
            { nomeBd: "TIP_PLN_PGMN" },
            { nomeBd: "DAT_MOV_TRAN", len: 10 },
            { nomeBd: "TIP_TCNL", len: 5 },
            { nomeBd: "VAL_TOTL_TRAN" },
            { nomeBd: "COD_GRU_CLAS_RAM" }, // campo nao existe no SW71
        ],
        opcionais: 1, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
