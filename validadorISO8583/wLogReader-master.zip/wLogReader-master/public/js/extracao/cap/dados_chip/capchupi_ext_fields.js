// capchupi_ext_fields.js

function capchupi_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isIndicador: true },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "TXT_RLCD_CHIP" },
            { nomeBd: "COD_PGM_AUT" },
            { nomeBd: "IND_MTDO_VRFC_PORT" },
            { nomeBd: "IND_PRSC_SNHA" },
            { nomeBd: "NUM_SEQ_CAR_VLDC_CHIP" }, // campo nao existe no SW71
        ],
        opcionais: 1, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
