// capchfulelo_ext_fields.js

function capchfulelo_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isIndicador: true },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "TXT_RLCD_CHIP", len: 510 },
            { isFixo: true, len: 1 },
            { nomeBd: "TXT_RSTD_ATLZ_CHIP" },
            { nomeBd: "TXT_INFO_CMPM_CHIP" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
