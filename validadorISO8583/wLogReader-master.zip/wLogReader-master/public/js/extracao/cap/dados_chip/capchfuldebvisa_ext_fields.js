// capchfuldebvan_ext_fields.js

function capchfuldebvisa_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isIndicador: true },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "NUM_CV" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "TXT_RLCD_CHIP", len: 510 },
            { isFixo: true, len: 30 },
            { isFixo: true, len: 128 },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
