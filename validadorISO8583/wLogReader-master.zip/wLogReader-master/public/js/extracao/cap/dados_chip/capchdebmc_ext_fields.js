// capchdebmc_ext_fields.js

function capchdebmc_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isIndicador: true },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "TXT_RLCD_CHIP" },
            { nomeBd: "COD_PGM_AUT" },
            { nomeBd: "COD_NVL_SGRA" },
            { isFixo: true, len: 50 },
        ],
        opcionais: 1, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
