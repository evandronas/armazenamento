// capchfulamex_ext_fields.js

// function capchfulamex_ext_fields_75()
function capchfulamex_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isIndicador: true },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "TXT_RLCD_CHIP", len: 255 },
            { isFixo: true, len: 1 },
            { nomeBd: "IND_MTDO_VRFC_PORT" },
            { nomeBd: "IND_PRSC_SNHA" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}

function capchfulamex_ext_fields_71()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isIndicador: true },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "DAT_MOV_TRAN", len: 8, formatDateInOver: kDATA_YYYYMMDD },
            { nomeBd: "TXT_RLCD_CHIP" },
            { nomeBd: "COD_PGM_AUT" },
            { nomeBd: "IND_MTDO_VRFC_PORT" },
            { nomeBd: "IND_PRSC_SNHA" },
        ]
    }

    return info
}
