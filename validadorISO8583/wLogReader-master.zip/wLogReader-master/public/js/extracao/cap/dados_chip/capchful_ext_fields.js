// capchful_ext_fields.js

function capchful_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isIndicador: true },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "TXT_RLCD_CHIP" },
            { nomeBd: "COD_PGM_AUT" },
            { nomeBd: "IND_MTDO_VRFC_PORT" },
            { nomeBd: "IND_PRSC_SNHA" },
            { nomeBd: "COD_NVL_SGRA" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
