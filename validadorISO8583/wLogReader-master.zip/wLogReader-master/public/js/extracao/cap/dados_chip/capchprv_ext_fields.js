// capchprv_ext_fields.js

function capchprv_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { isIndicador: true },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "TXT_RLCD_CHIP", len: 510 },
            { nomeBd: "NUM_SEQ_CAR_VLDC_CHIP" },
            { nomeBd: "COD_CNDC_CPTR" },
            { isFixo: true, len: 5 },
            { nomeBd: "TXT_INFO_CMPM_CHIP" },
            { isFixo: true, len: 128 },
            { nomeBd: "COD_PGM_AUT" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
