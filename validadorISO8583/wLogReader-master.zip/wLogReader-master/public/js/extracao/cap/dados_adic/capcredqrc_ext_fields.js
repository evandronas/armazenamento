// capcredqrc_ext_fields.js

function capcredqrc_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "NUM_CAR" },
            { nomeBd: "COD_BNDR", len: 2 },
            { nomeBd: "COD_PRCR" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
