// capnfin_ext_fields.js

function capnfin_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN" },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN" },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "NUM_MOT_RSPS" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "TIP_TERM" },
            { nomeBd: "NUM_STAN" },
            { nomeBd: "NUM_RD_ORG" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_VERS_SIS" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "NUM_CAR" },
            { nomeBd: "COD_MOT_RSPS_EXT" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "NUM_CGC_CPF" },
            { nomeBd: "NUM_BCO_DEB" },
            { nomeBd: "DAT_CTB_TRAN" },
            { nomeBd: "NUM_CV" },
            { nomeBd: "NUM_CHQ" },
            { isFixo: true, len: 3 }, // "AVS"
            { isFixo: true, len: 5 }, // "00000"
            { isFixo: true, len: 3 }, // "000"
            { nomeBd: "NUM_ID_CAR" },
            { isFixo: true, len: 8 }, // "        "
            { isFixo: true, len: 1 }, // " "
            { isFixo: true, len: 8 }, // "        "
            { isFixo: true, len: 1 }, // "C"
            { isFixo: true, len: 11 }, // "00000000000"
            { isFixo: true, len: 1 }, // " "
            { isFixo: true, len: 8 }, // "        "
            { nomeBd: "NUM_RSMO_VD" },
            { nomeBd: "DAT_RSMO_VD" },
            { nomeBd: "COD_TRK_CAR" },
            { nomeBd: "NUM_TEL" },
            { nomeBd: "COD_RAM_ATVD" },
            { nomeBd: "TIP_DOC" },
            { nomeBd: "DTH_CON_TRAN" },
            { nomeBd: "DTH_CON_TRAN", len: 6, nomeDisplayOver: "Hora Consulta Transação" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
