// trnaprovadas_ext_fields.js

function trnaprovadas_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DTH_STTU_TRAN", len: 8 },
            { nomeBd: "DAT_MOV_TRAN", len: 8, nomeDisplay: "Data Movimentação" }, 
            { nomeBd: "COD_EMSR" },
            { nomeBd: "TIP_TRAN", len: 4 },
            { nomeBd: "COD_MOED" },
            { nomeBd: "QTDE_TRAN" },
            { nomeBd: "VAL_TRAN", len:10, nomeDisplay: "Valor Total" },
            { nomeBd: "VAL_TX", len: 10 }
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
