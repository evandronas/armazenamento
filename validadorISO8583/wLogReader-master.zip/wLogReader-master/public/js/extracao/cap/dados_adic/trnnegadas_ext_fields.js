// trnnegadas_ext_fields.js

function trnnegadas_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "TIP_TRAN", len: 7 },
            { nomeBd: "DES_COD_TRAN"},
            { nomeBd: "COD_TERM" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "COD_BIN_CAR" },
            { nomeBd: "COD_MOT_RSPS_EXT" },
            { nomeBd: "QTD_PRCL" },
            { nomeBd: "COD_MOT_SW" },
            { nomeBd: "DES_MOT_SW" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
