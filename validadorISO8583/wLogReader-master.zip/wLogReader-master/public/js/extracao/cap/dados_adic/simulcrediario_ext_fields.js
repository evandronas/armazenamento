// simulcrediario_ext_fields.js

function simulcrediario_ext_fields()
{
    var info = {
        array_fields: [
            { isTipoReg: true },
            { nomeBd: "DAT_MOV_TRAN", len: 8 },
            { nomeBd: "NUM_SEQ_UNC" },
            { nomeBd: "TIP_TRAN" },
            { nomeBd: "DTH_INI_TRAN" },
            { nomeBd: "NUM_MOT_RSPS" },
            { nomeBd: "TIP_TCNL" },
            { nomeBd: "NUM_ESTB" },
            { nomeBd: "COD_TERM" },
            { nomeBd: "NUM_STAN" },
            { nomeBd: "IND_STTU_TRAN" },
            { nomeBd: "COD_POS_ENTR_MODO" },
            { nomeBd: "COD_EMSR" },
            { nomeBd: "VAL_TRAN" },
            { nomeBd: "NUM_ID_CAR" },
            { nomeBd: "NUM_CAR" },
            { nomeBd: "COD_MOT_RSPS_EXT" },
            { nomeBd: "COD_AUT_EMSR" },
            { nomeBd: "COD_PAIS_CAR" },
            { nomeBd: "QTD_PRCL" },
            { nomeBd: "VAL_PRCL" },
            { nomeBd: "DTH_STTU_TRAN", len: 8 },
            { nomeBd: "DTH_STTU_TRAN" },
            { nomeBd: "NUM_CV" },
            { nomeBd: "COD_CNDC_CPTR" },
            { nomeBd: "NUM_AUT" },
            { nomeBd: "IND_TRK" },
            { nomeBd: "COD_MOT_SW" },
            { nomeBd: "COD_DSPO_NFC" },
            { nomeBd: "COD_GRU_CLAS_RAM" },
            { nomeBd: "IND_TRAN_TKN" },
            { nomeBd: "COD_NVL_SGRA_TKN" },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
