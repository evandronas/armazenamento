// all_ext_break.js

function all_ext_break(ret_info_ext)
{
    var pos = 1
    var qtde = ret_info_ext.array_fields.length
    var op = ret_info_ext.opcionais

    // mostrar tamanho total da mensagem antes
    infodisp = {
        display: true,
        nomeCampo: "Tamanho do registro: " + msg.length,
        nomeCampoIgnoreDash: true,
        newline: get_break_line(),
    }
    genDisplayInfo(infodisp)

    for (var i = 0; i < ret_info_ext.array_fields.length; i++)
    {
        var field = ret_info_ext.array_fields[i]
        // dump_obj_console(field)

        /*
        field       ->  informacoes definidas na funcao da cap
        field.info  ->  informacoes definidas na funcao de generica dos campos
        */

        if (op && qtde <= op && msg.length == 0)
        {
            nome_op = ""

            if (field.nomeBd)
                nome_op = field.nomeBd
            else if (field.isFixo)
                nome_op = "Fixo"

            // campo opcional e nao esta presente
            var infodisp = {
                display: true,
                nomeCampo: "* Campo " + nome_op + " opcional e ausente no registro *",
                nomeCampoIgnoreDash: true,
            }
            genDisplayInfo(infodisp)
        }
        else
        {
            // pegando o valor
            var val
            var len
            if (field.isTipoReg)
            {
                field.info = {
                    nomeDisplay: "Tipo Registro",
                }
                len = 1

                if (field.len)
                    len = field.len
            }
            else if (field.isIndicador)
            {
                field.info = {
                    nomeDisplay: "Indicador",
                }
                len = 1
            }
            else if (field.isFixo)
            {
                var fixo_display_name = "Fixo"
                if (field.nomeDisplayOver)
                    fixo_display_name = field.nomeDisplayOver

                field.info = {
                    nomeDisplay: fixo_display_name,
                    formatMoney: field.formatMoney,
                }
                len = field.len
            }
            else // campo normal
            {
                // pegando a informacao do campo
                field = all_ext_info_fields(field, ret_info_ext.cap)
                // dump_obj_console(field)

                if (!field.info)
                {
                    alert("Não foi possível pegar as informações sobre o campo " + field.nomeBd + " da extração.")
                    msg_formatted += "Campo " + field.nomeBd + " não mapeado." + get_break_line()
                    // console.log("qtde [%s] array.length [%s]", qtde, ret_info_ext.array_fields.length)
                    return
                }
                if (field.len)
                {
                    len = field.len
                }
                else
                {
                    len = field.info.len
                }
            }
            val = get_field_msg(len)

            if (val.length != len) // tamanho definido diferente do recebido
            {
                var msgDisplay = "O valor [" + val + "] do campo "
                if (field.isFixo)
                {
                    msgDisplay += "Fixo"
                }
                else
                {
                    msgDisplay += field.nomeBd
                }
                msgDisplay += " não tem " + len + " de tamanho, ele tem " + val.length + "."
                alert(msgDisplay)
                // alert("O valor [" + val + "] do campo " + field.nomeBd + " não tem " + len + " de tamanho, ele tem " + val.length + ".")
                return
            }

            // descricao
            var desc = undefined
            if (field.info.descFunc && !field.ignoreDescFunc)
            {
                desc = field.info.descFunc(val)
            }

            // substituindo os brancos para aparecer no html
            val = converterEspacoParaHtml(val)

            //

            var campo
            if (field.info.nomeDisplay && !field.ignoreNomeDisplay)
            {
                if (field.nomeDisplayOver)
                {
                    campo = field.nomeDisplayOver
                }
                else
                {
                    campo = field.info.nomeDisplay
                }

                if (!field.isFixo && !field.isTipoReg && !field.isIndicador)
                {
                    campo += mostrarParentese(field.nomeBd)
                }
            }
            else
            {
                campo = field.nomeBd
            }

            // ========================================================================================
            // formatacao

            var infodisp = {
                display: true,
                nomeCampo: campo,
                // nomeCampoSpace: 58,
                nomeCampoSpace: 77,
                valorFirst: padLEN(len) + " - " + padLEN(pos) + " - ",
                valorOrig: val,
                valorOrigColchete: true,
                desc: desc,
                formatMoney: field.info.formatMoney,
                // format_YYMMDD_DDMMYY: field.info.format_YYMMDD_DDMMYY,
            }

            // if (field.formatDateInOver)
            // {
            // 	infodisp.formatDateIn = field.formatDateInOver
            // }
            // else if (field.info.formatDateIn)
            // {
            // 	infodisp.formatDateIn = field.info.formatDateIn
            // }
            // if (field.formatDateOutOver)
            // {
            // 	infodisp.formatDateOut = field.formatDateOutOver
            // }
            // else if (field.info.formatDateOut)
            // {
            // 	infodisp.formatDateOut = field.info.formatDateOut
            // }

            // dump_obj_console(infodisp)
            genDisplayInfo(infodisp)

            //

            msg_clean += val + get_break_line()

            if (ret_info_ext.separadorCampo)
                get_field_msg(1)
        }

        // incrementando posicao
        pos += len
        qtde -= 1
    }

    // validacao pra verificar se foi pego todos os campos do registro
    if (msg.length > 0)
    {
        alert("Ainda há campos no registro.\n\n" + "msg: [" + msg + "]\n" + "len: " + msg.length)
        return
    }
}
