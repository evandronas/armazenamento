// all_ext_info_fields.js

function all_ext_info_fields(field, cap)
{
    var info

    switch(field.nomeBd)
    {
        case "DAT_MOV_TRAN":
            info = {
                nomeDisplay: "Data",
                len: 6,
                nomeBd71: "dt_mvm_trx",
                formatDateIn: kDATA_YYMMDD,
                formatDateOut: kDATA_DDMMYY,
            }
            break

        case "NUM_SEQ_UNC":
            info = {
                nomeDisplay: "NSU",
                len: 12,
                nomeBd71: "nu_sqn_unc_ccr",
            }
            break

        case "TIP_TRAN":
            info = {
                nomeDisplay: "Transcode",
                len: 3,
                descFunc: get_desc_transcode,
                nomeBd71: "in_tpo_trx",
            }
            break

        case "DTH_INI_TRAN":
            info = {
                nomeDisplay: "Hora",
                len: 6,
                nomeBd71: "hr_ini_trx",
            }
            break

        case "NUM_MOT_RSPS":
            info = {
                nomeDisplay: "Código Resposta",
                len: 3,
                nomeBd71: "nu_mtv_rpo",
            }
            break

        case "TIP_TCNL":
            info = {
                nomeDisplay: "Tipo Tecnologia",
                len: 4,
                nomeBd71: "in_tpo_tcn",
            }
            break

        case "NUM_ESTB":
            info = {
                nomeDisplay: "PV",
                len: 9,
                nomeBd71: "nu_etb",
            }
            break

        case "COD_TERM":
            info = {
                nomeDisplay: "Terminal",
                len: 8,
                nomeBd71: "cd_trm",
            }
            break

        case "TIP_TERM":
            info = {
                nomeDisplay: "Código Tipo Terminal",
                len: 2,
                nomeBd71: "cd_tpo_trm",
            }
            break

        case "NUM_STAN":
            info = {
                nomeDisplay: "Stan Terminal",
                len: 6,
                nomeBd71: "nu_grc_trm",
            }
            break

        case "NUM_RD_ORG":
            info = {
                nomeDisplay: "Rede Origem",
                len: 5,
                nomeBd71: "nu_rde_ori",
            }
            break

        case "IND_STTU_TRAN":
            info = {
                nomeDisplay: "Status",
                len: 1,
                descFunc: get_desc_status,
                nomeBd71: "in_sts_trx",
            }
            break

        case "COD_VERS_SIS": // 71 e 75
            info = {
                len: 8,
                nomeBd71: "cod_vers_sis",
            }
            break

        case "COD_POS_ENTR_MODO":
            info = {
                nomeDisplay: "Entry Mode",
                len: 3,
                descFunc: get_desc_entry_mode,
                nomeBd71: "pos_entry_mode",
            }
            break

        case "COD_EMSR":
            info = {
                nomeDisplay: "Código Emissor",
                len: 2,
                descFunc: get_desc_codigo_emissor,
                nomeBd71: "cd_ems",
            }
            break

        case "TIP_VD":
            info = {
                nomeDisplay: "Tipo Venda",
                len: 1,
                nomeBd71: "in_tpo_vda",
            }
            break

        case "VAL_TRAN":
            info = {
                nomeDisplay: "Valor",
                len: 13,
                formatMoney: true,
                nomeBd71: "vl_trx",
            }
            break

        case "COD_RAM_ATVD":
            info = {
                nomeDisplay: "Ramo Atividade",
                len: 5,
                nomeBd71: "nu_rmo_ati",
            }
            break

        case "NUM_CAR":
            info = {
                nomeDisplay: "Número Cartão",
                len: 19,
                nomeBd71: "nu_car",
            }
            break

        case "COD_MOT_RSPS_EXT":
            info = {
                nomeDisplay: "Código Resposta Bandeira",
                len: 3,
                nomeBd71: "cd_mtv_rpo_ete",
            }
            break

        case "COD_AUT_EMSR":
            info = {
                nomeDisplay: "Código Autorização",
                len: 9,
                nomeBd71: "nu_auz",
            }
            break

        case "NUM_ID_CAR":
            info = {
                nomeDisplay: "ICA",
                len: 11,
                nomeBd71: "nu_bin_car",
            }
            break

        case "NUM_ADM":
            info = {
                len: 3,
                nomeBd71: "nu_adm",
            }
            break

        case "VAL_TX_EMBQ":
        case "VAL_TX":
            info = {
                nomeDisplay: "Valor Taxa",
                len: 11,
                formatMoney: true,
                nomeBd71: "vl_txa",
            }
            break

        case "COD_PAIS_CAR":
            info = {
                nomeDisplay: "Código Pais Cartão",
                len: 3,
                nomeBd71: "cd_pai_car",
            }
            break

        case "VAL_COT_DLR":
            info = {
                nomeDisplay: "Valor Cotação Dólar",
                len: 9,
                formatMoney: true,
                nomeBd71: "vl_ctc_dlr",
            }
            break

        case "QTD_PRCL":
            info = {
                nomeDisplay: "Quantidade Parcelas",
                len: 3,
                nomeBd71: "nu_pca",
            }
            break

        case "VAL_PRCL":
            info = {
                nomeDisplay: "Valor Parcela",
                len: 11,
                formatMoney: true,
                nomeBd71: "vl_pca",
            }
            break

        case "COD_MOED":
            info = {
                nomeDisplay: "Código Moeda",
                len: 3,
                nomeBd71: "cd_mda",
            }
            break

        case "COD_TRK_CAR":
            info = {
                nomeDisplay: "Trilha",
                len: 37,
                nomeBd71: "cd_trl_car",
            }
            break

        case "DAT_VLD_CAR":
            info = {
                nomeDisplay: "Data Validade Cartão",
                len: 4,
                nomeBd71: "dt_vdd_car",
            }
            break

        case "NUM_BCO_DEB":
            info = {
                nomeDisplay: "Número Banco Débito",
                len: 3,
                nomeBd71: "nu_bco_deb",
            }
            break

        case "NUM_EMSR":
            info = {
                nomeDisplay: "Número Emissor",
                len: 5,
                nomeBd71: "nu_ems",
            }
            break

        case "NUM_BCO_ESTB":
            info = {
                nomeDisplay: "Número Banco Estabelecimento",
                len: 3,
                nomeBd71: "nu_bco_etb",
            }
            break

        case "NUM_AGE_ESTB":
            info = {
                nomeDisplay: "Número Agência Estabelecimento",
                len: 5,
                nomeBd71: "nu_age_etb",
            }
            break

        case "COD_CTA_ESTB":
            info = {
                nomeDisplay: "Código Conta Estabelecimento",
                len: 10,
                nomeBd71: "cd_cta_etb",
            }
            break

        case "DAT_CTB_TRAN":
            info = {
                nomeDisplay: "Data Contábil",
                len: 6,
                nomeBd71: "dt_ctb_trx",
            }
            break

        case "COD_OPER_CNFR":
            info = {
                nomeDisplay: "Código Operador Confirmação",
                len: 6,
                nomeBd71: "cd_opd_cfi",
            }
            break

        case "TXT_DA_ADIC_EMSR":
            info = {
                nomeDisplay: "Dados Adicionais",
                len: 20,
                nomeBd71: "de_adc_ete",
            }
            break

        case "TIP_DTLH_TRAN":
            info = {
                nomeDisplay: "Tipo Transação",
                len: 1,
                nomeBd71: "in_dbt_cre_ete",
            }
            break

        case "COD_BNDR":
            info = {
                nomeDisplay: "Código Bandeira",
                len: 1,
                // descFunc: get_desc_codigo_bandeira,
                nomeBd71: "cd_bnd",
            }
            break

        case "NUM_CV":
            info = {
                len: 12,
                nomeBd71: "nu_cv",
            }
            break

        case "VAL_TRAN_DLR":
            info = {
                nomeDisplay: "Valor Transação Dolar",
                len: 13,
                nomeBd71: "vl_trx_dlr",
            }
            break

        case "NUM_SEQ_CAR_VLDC_CHIP":
            info = {
                nomeDisplay: "Número Sequêncial",
                len: 3,
                nomeBd71: "cd_seq_car",
            }
            break

        case "IND_DA_RLCD_CHIP":
            info = {
                nomeDisplay: "Indicador BIT",
                len: 1,
                nomeBd71: "in_dad_rld_chi",
            }
            break

        case "COD_CTGR_TRAN":
            info = {
                len: 1,
                nomeBd71: "cd_ctg_trx",
            }
            break

        case "COD_RSPS_AVS":
            info = {
                nomeDisplay: "Código Resposta AVS",
                len: 1,
                nomeBd71: "cd_rpo_avs",
            }
            break

        case "VAL_PRCL_ENTR":
            info = {
                nomeDisplay: "Valor Entrada Parcela",
                len: 15,
                nomeBd71: "vl_pca_ent",
            }
            break

        case "IND_CNFR_PSTV":
            info = {
                nomeDisplay: "Indicador Confirmação Positiva",
                len: 1,
                nomeBd71: "in_cfi_ptv",
            }
            break

        case "TIP_RPSS_VAL":
            info = {
                nomeDisplay: "Indicativo Tarifa Taxa",
                len: 1,
                nomeBd71: "in_trf_txa_mtc",
            }
            break

        case "VAL_RPSS":
            info = {
                nomeDisplay: "Valor Tarifa Taxa Cobrada Estabelecimento",
                len: 13,
                nomeBd71: "vl_trf_txa_mtc",
            }
            break

        case "VAL_LQDC":
            info = {
                len: 13,
                nomeBd71: "vl_lqd_mtc",
            }
            break

        case "VAL_RCD":
            info = {
                nomeDisplay: "Valor Pago a Rede",
                len: 13,
                nomeBd71: "vl_rcd_mtc",
            }
            break

        case "QTD_DIA_CRNC":
            info = {
                len: 3,
                nomeBd71: "qt_dia_crn",
            }
            break

        case "IND_ID_PREV":
            info = {
                len: 3,
                nomeBd71: "in_id_prv",
            }
            break

        case "COD_PROD":
            info = {
                len: 2,
                nomeBd71: "cd_pdt",
            }
            break

        case "VAL_MN_CAR":
            info = {
                len: 11,
                nomeBd71: "vl_min_car",
            }
            break

        case "VAL_TX_EFTV":
            info = {
                len: 9,
                nomeBd71: "vl_txa_efv",
            }
            break

        case "VAL_TX_MNSL":
            info = {
                len: 9,
                nomeBd71: "vl_txa_mes",
            }
            break

        case "COD_CTR":
            info = {
                len: 11,
                nomeBd71: "cd_ctt",
            }
            break

        case "DAT_PAUZ":
            info = {
                nomeDisplay: "Data Pré-Autorização",
                len: 6,
                nomeBd71: "dt_vda_chp",
                formatDateIn: kDATA_YYMMDD,
                formatDateOut: kDATA_DDMMYY,
            }
            break

        case "COD_CRT_ECM":
            info = {
                len: 16,
                nomeBd71: "cd_crt_ecm",
            }
            break

        case "DTH_STTU_TRAN":
            info = {
                nomeDisplay: "Data Confirmação",
                len: 6,
                nomeBd71: "dt_sts_trx",
                formatDateIn: kDATA_YYMMDD,
                formatDateOut: kDATA_DDMMYY,
            }
            break

        case "COD_CNDC_CPTR":
            info = {
                nomeDisplay: "Código Condição Captura",
                len: 11,
                nomeBd71: "cd_cnd_cpt",
            }
            break

        case "COD_CNDC_CPTR_EMSR":
            info = {
                len: 12,
                nomeBd71: "cd_cnd_cpt",
            }
            break

        // case "cd_vda_bco":
        //     info = {
        //         len: 4,
        //     }
        //     break

        // case "nu_etb_cre": // 71
        // // 75 extrai zeros
        //     info = {
        //         len: 9,
        //     }
        //     break

        // case "in_tril_2":
        //     info = {
        //         len: 1,
        //     }
        //     break

        // case "in_capt_cvc2":
        //     info = {
        //         len: 1,
        //     }
        //     break

        case "COD_MOT_SW": // 75
            info = {
                nomeDisplay: "Código Motivo SW",
                len: 3,
                nomeBd71: "cd_mtv_sw",
            }
            break

        case "PRCN_TX_RISC":
            info = {
                nomeDisplay: "Taxa Risco",
                len: 13,
                nomeBd71: "tx_risc",
            }
            break

        case "VAL_TX_RISC":
            info = {
                nomeDisplay: "Valor Taxa Risco",
                len: 13,
                nomeBd71: "vl_risc",
            }
            break

        case "NOM_LOC_ESTB":
            info = {
                nomeDisplay: "Nome do Estabelecimento + Cidade + País",
                len: 40,
            }
            break

        case "DAT_PRE_DATDO":
            info = {
                nomeDisplay: "Data Pré-Datado",
                len: 6,
                nomeBd71: "dt_prdt",
                formatDateIn: kDATA_YYMMDD,
                formatDateOut: kDATA_DDMMYY,
            }
            break

        case "COD_RAM_MCC":
            info = {
                nomeDisplay: "Código Ramo MCC",
                len: 4,
                nomeBd71: "cd_rmo_mtc",
            }
            break

        case "TIP_LQDC":
            info = {
                nomeDisplay: "Indicador Tipo Liquidação",
                len: 1,
                nomeBd71: "ind_tip_lqdc",
            }
            break

        case "COD_CLI":
            info = {
                nomeDisplay: "Código Cliente",
                len: 5,
                nomeBd71: "cod_cli",
            }
            break

        case "COD_DSTR": // 75
            info = {
                nomeDisplay: "Código Distribuidor",
                len: 4,
                nomeBd71: "id_dstr",
            }
            break

        case "COD_REF_EMSR":
            info = {
                nomeDisplay: "Código Referencia Emissor",
                len: 15,
            }
            break

        case "COD_CMPM_TRAN":
            info = {
                nomeDisplay: "Sub Código Transação",
                len: 2,
                nomeBd71: "cod_cmpm_tran",
            }
            break

        case "VAL_SQUE":
            info = {
                nomeDisplay: "Valor Saque",
                len: 13,
                nomeBd71: "val_sque",
            }
            break

        case "QTD_CICL_CRNC_PRMR_PRCL":
            info = {
                nomeDisplay: "Quantidade Ciclo",
                len: 1,
                nomeBd71: "in_qtd_ccl",
            }
            break

        case "PRCN_TX_JURO":
            info = {
                nomeDisplay: "Taxa Juros",
                len: 4,
                nomeBd71: "pct_tx_juro",
            }
            break

        case "PRCN_TX_JURO_MES":
            info = {
                len: 1,
            }
            break

        case "COD_SERV_TRK_CAR":
            info = {
                nomeDisplay: "Código Serviço",
                len: 3,
                nomeBd71: "cod_serv_trk_car",
            }
            break

        case "COD_RVDA_PROD_MTC":
            info = {
                nomeDisplay: "Código Produto",
                len: 3,
                nomeBd71: "cod_rvda_prod_mtc",
            }
            break

        case "DTH_VD_TERM":
            info = {
                len: 6,
            }
            break

        case "COD_MOT_APRV_OFLN":
            info = {
                nomeDisplay: "Código Motivo Aprovado Chip",
                len: 1,
                nomeBd71: "ind_mot_aprv_chip",
            }
            break

        case "COD_DSPO_NFC":
            info = {
                nomeDisplay: "Form Factor Indicator",
                len: 8,
                nomeBd71: "cod_dspo_nfc",
            }
            break

        case "COD_PROD_CDST":
            info = {
                nomeDisplay: "Código Produto Cadastrado",
                len: 3,
            }
            break

        case "COD_EMP_ADQT":
            info = {
                nomeDisplay: "Código Empresa Adquirente",
                len: 3,
            }
            break

        case "NUM_PDV_EXT":
            info = {
                nomeDisplay: "PV Externo",
                len: 15,
            }
            break

        case "NOM_FNTS_PDV":
            info = {
                nomeDisplay: "Merchant Name",
                len: 22,
                // nomeBd71: "dba_mch_nam",
            }
            break

        // case "cd_cnd_cpt": // 71
        // case "cod_cndc_cptr": // 75
        // case "cod_cndc_cptr_emsr": // 75
        //     info = {
        //         len: 11,
        //     }
        //     switch(cap)
        //     {
        //         case kEXT_CAPDEBVISA:
        //         case kEXT_CAPDEBVISAD:
        //         case kEXT_CAPDEBELO:
        //         case kEXT_CAPDEBELOD:
        //             info.len = 12
        //             break

        //         case kEXT_CAPCHPRV:
        //             info.len = 16
        //             break
        //     }
        //     break

        case "NUM_AUT":
            info = {
                len: 5,
                nomeBd71: "nu_auz_ncl",
            }
            break

        case "COD_REF_RESTANTE":
            info = {
                len: 16,
                nomeBd71: "cd_ref_res",
            }
            break

        case "IND_TRK":
            info = {
                nomeDisplay: "Indicador Trilha",
                len: 1,
                nomeBd71: "in_trl",
            }
            break

        case "IND_CPTR_CVC_2":
            info = {
                len: 1,
                nomeBd71: "in_cap_cvc2",
            }
            break

        case "IND_TERM_RLCD_CHIP":
            info = {
                len: 1,
                nomeBd71: "in_trm_rld_chi",
            }
            break

        case "COD_PROD_MTC":
            info = {
                nomeDisplay: "Código Produto Mastercard",
                len: 3,
                nomeBd71: "cd_pdt_mtc",
            }
            break

        case "COD_RGAO_MTC":
            info = {
                len: 1,
                nomeBd71: "cd_reg_mtc",
            }
            break

        case "COD_SERV":
            info = {
                len: 1,
                nomeBd71: "cd_srv",
            }
            break

        case "COD_SERV_SNHA":
            info = {
                nomeDisplay: "Código Senha",
                len: 2,
                nomeBd71: "cod_serv_snha",
            }
            break

        case "IND_AGND_TRAN":
            info = {
                len: 1,
                nomeBd71: "ind_agnd_trx",
            }
            break

        case "TIP_ENT_PAUZ":
            info = {
                len: 3,
                nomeBd71: "cod_tip_entr_pre_aut",
            }
            break

        case "COD_CNDC_CPTR_PAUZ":
            info = {
                len: 11,
                nomeBd71: "cod_cndc_cptr_pre_aut",
            }
            break

        case "NUM_SEQ_UNC_RD_AUT":
            info = {
                len: 12,
                nomeBd71: "num_seq_unc_rd_aut",
            }
            break

        case "COD_CTAH_VOCH":
            info = {
                len: 11,
                nomeBd71: "cod_id_voch",
            }
            break

        case "IND_TERM_FATR_EXPS":
            info = {
                nomeDisplay: "Indicador Terminal Flex",
                len: 1,
            }
            break

        case "COD_SERV_CORP":
            info = {
                nomeDisplay: "Código Serviço Corporativo",
                len: 3,
                nomeBd71: "cod_serv_corp",
            }
            break

        case "NUM_CNPJ_PORT":
            info = {
                nomeDisplay: "CPNJ Portador",
                len: 15,
            }
            break

        case "COD_GRU_CLAS_RAM":
            info = {
                nomeDisplay: "Classificação Ramo",
                len: 2,
                nomeBd71: "cod_gru_clas_ram",
            }
            break

        case "IND_TRAN_TKN":
            info = {
                nomeDisplay: "Indicativo Token",
                len: 1,
                nomeBd71: "ind_tran_tkn",
            }
            break

        case "COD_NVL_SGRA_TKN":
            info = {
                nomeDisplay: "Código Nível Segurança Token",
                len: 2,
            }
            break

        case "IND_AUT":
            info = {
                len: 1,
                nomeBd71: "cod_ind_aut",
            }
            break

        case "COD_RSTD_NUM_CVC_2":
            info = {
                len: 1,
                nomeBd71: "cod_rstd_cvv2",
            }
            break

        case "COD_VLDC_EMSR":
            info = {
                len: 4,
                nomeBd71: "cod_vldc_emsr",
            }
            break

        case "IND_NVL_SGRA_KMRC":
            info = {
                nomeDisplay: "ECI",
                len: 2,
                nomeBd71: "ind_nvl_sgra_kmrc",
            }
            break

        case "IND_CAR_MLTP":
            info = {
                len: 1,
                nomeBd71: "ind_car_mltp",
            }
            break

        case "COD_CPCD_TERM":
            info = {
                nomeDisplay: "Data Code",
                len: 12,
                nomeBd71: "cod_cpcd_term",
            }
            break

        case "NUM_REF_TRAN":
            info = {
                nomeDisplay: "TID",
                len: 15,
                nomeBd71: "num_ref_tran",
            }
            break

        case "COD_ECI":
            info = {
                len: 2,
            }
            break

        case "IND_PGMN_RECRRN":
            info = {
                nomeDisplay: "Indicador Pagamento Recorrente",
                len: 1,
            }
            break

        case "NUM_PDDO_CMC_ELET":
            info = {
                len: 16,
            }
            break

        case "COD_ID_DTCH":
            info = {
                nomeDisplay: "Código ID Datacash",
                len: 20,
            }
            break

        case "COD_TIP_ORG_TRAN_WEB":
            info = {
                nomeDisplay: "Capture Source",
                len: 2,
            }
            break

        case "NUM_PDV":
            info = {
                len: 1,
            }
            break

        case "TIP_TRAN_ORGL":
            info = {
                len: 1,
            }
            break

        case "DAT_CTB_TRAN":
            info = {
                len: 6,
            }
            break

        case "IND_DA_RLCD_KMRC":
            info = {
                len: 1,
            }
            break

        case "COD_PROD_PRCR":
            info = {
                nomeDisplay: "Código Produto Parceiro",
                len: 4,
            }
            break

        case "COD_ORG_APRV":
            info = {
                nomeDisplay: "Código Origem Aprovação",
                len: 1,
                nomeBd71: "cod_orig_aprv",
            }
            break

        case "NUM_BCO_ESTB":
            info = {
                len: 3,
            }
            break

        case "VAL_EFTV_APRV":
            info = {
                nomeDisplay: "Valor Saldo Aprovado",
                len: 13,
                formatMoney: true,
            }
            break

        case "TIP_ATTC_CMC_ELET":
            info = {
                len: 2,
            }
            break

        case "IND_DA_TIT_CAR_AMZT":
            info = {
                nomeDisplay: "Indicador Credencial Armazenada",
                len: 1,
            }
            break

        case "NUM_RD_DEST":
            info = {
                len: 5,
                nomeBd71: "nu_rde_dst",
            }
            break

        case "COD_MOT_ESTR_DEST":
            info = {
                len: 2,
                nomeBd71: "cd_mtv_etn_dst",
            }
            break

        case "COD_MOT_RSPS_DEST":
            info = {
                len: 2,
                nomeBd71: "cd_mtv_rpo_dst",
            }
            break

        case "COD_OPER_ESTR":
            info = {
                len: 3,
                nomeBd71: "cd_opd_etn",
            }
            break

        case "COD_PCM_ISO":
            info = {
                len: 6,
                nomeBd71: "cd_pro",
            }
            break

        case "COD_ITEM":
            info = {
                len: 11,
                nomeBd71: "cd_itm",
            }
            break

        // case "de_adc_ems": // 71
        //     info = {
        //         len: 40,
        //     }
        //     break

        // case "hr_con_sts": // 71
        //     info = {
        //         len: 8,
        //     }
        //     break

        // case "in_cfi_etn": // 71
        //     info = {
        //         len: 1,
        //     }
        //     break

        case "TIP_MODO_TRAN":
            info = {
                len: 1,
                nomeBd71: "in_mod_trx",
            }
            break

        case "TIP_MSG":
            info = {
                len: 1,
                nomeBd71: "in_tpo_msg",
            }
            break

        case "TIP_VD_SAID":
            info = {
                len: 2,
                nomeBd71: "in_tpo_vda_sda",
            }
            break

        case "NUM_OPER_ETD":
            info = {
                len: 7,
                nomeBd71: "nu_opd_etn",
            }
            break

        case "TIP_PLN_PGMN":
            info = {
                len: 3,
                nomeBd71: "in_pln_pgt",
            }
            break

        case "VAL_TOTL_TRAN":
            info = {
                len: 15,
                nomeBd71: "vl_tot_trx",
            }
            break

        case "DAT_LQDC_EMSR":
            info = {
                len: 4,
                nomeBd71: "dat_lqdc_emsr",
            }
            break

        case "DTH_TRAN_EMSR":
            info = {
                nomeDisplay: "Data",
                len: 8,
                nomeBd71: "dat_mov_tran_emsr",
            }
            break

        case "COD_RSPS_DTLH_EMSR":
            info = {
                len: 4,
                nomeBd71: "cod_rsps_dtlh_emsr",
            }
            break

        case "COD_ISTT_ACQR":
            info = {
                len: 11,
                nomeBd71: "cod_istt_acqr",
            }
            break

        case "COD_ISTT_FRWD":
            info = {
                len: 11,
                nomeBd71: "cod_istt_frwd",
            }
            break

        case "COD_PGM_AUT":
            info = {
                nomeDisplay: "Código Autorização",
                len: 1,
                nomeBd71: "cod_pgm_aut",
            }
            break

        case "IND_MTDO_VRFC_PORT":
            info = {
                nomeDisplay: "Método Verificador Portador",
                len: 1,
                nomeBd71: "ind_mtdo_vrfc_port",
            }
            break

        case "IND_PRSC_SNHA":
            info = {
                nomeDisplay: "Indicador senha presente",
                len: 1,
                nomeBd71: "ind_prsc_snha",
            }
            break

        case "COD_NVL_SGRA":
            info = {
                nomeDisplay: "Código Nível Segurança",
                len: 3,
            }
            break

        // case "sli_field": // 71
        //     info = {
        //         len: 3,
        //     }
        //     break

        // case "nu_sqn_unc_ccr_dbt": // 71
        //     info = {
        //         len: 12,
        //     }
        //     break

        case "NOM_PORT_CAR":
            info = {
                len: 45,
                nomeBd71: "nom_port",
            }
            break

        case "TXT_INFO_CMPM_CHIP":
            info = {
                len: 128,
                nomeBd71: "des_info_cmpm_chip",
            }
            break

        case "TXT_RSTD_ATLZ_CHIP":
            info = {
                len: 30,
                nomeBd71: "des_rstd_atlz_chip",
            }
            break

        // case "filler_sec_gen_ac": // 71
        //     info = {
        //         len: 128,
        //     }
        //     break

        case "NOM_PSSR_1":
            info = {
                nomeDisplay: "Nome Passageiro 1",
                len: 40,
            }
            break

        case "NOM_PSSR_2":
        case "NOM_PSSR_3":
        case "NOM_PSSR_4":
            info = {
                nomeDisplay: "Nome do Passageiro " + field.nomeBd.replace("NOM_PSSR_", ""),
                len: 26,
            }
            break

        case "TXT_DOC_PSSR_1":
        case "TXT_DOC_PSSR_2":
        case "TXT_DOC_PSSR_3":
        case "TXT_DOC_PSSR_4":
            info = {
                nomeDisplay: "Ticket Number " + field.nomeBd.replace("TXT_DOC_PSSR_", ""),
                len: 11,
            }
            break

        case "COD_IATA_ETD":
            info = {
                len: 8,
            }
            break

        // case "nu_sqn_unc_ori":
        //     info = {
        //         nome: "NSU Original",
        //         len: 9,
        //     }
        //     break

        case "DES_TX_ADIC_CMPN_AER": // 75
            info = {
                nomeDisplay: "Taxas Serviços",
                len: 84,
            }
            break

        case "COD_RET_VLDC_SGRA":
            info = {
                nomeDisplay: "Código Validação CVC2",
                len: 1,
            }
            break

        case "ID_VERS_PRTO_SGRA":
            info = {
                len: 1,
            }
            break

        case "COD_HASH_PRTO_SGRA":
            info = {
                nomeDisplay: "Código Hash Protocolo Segurança",
                len: 36,
            }
            break

        case "TXT_RLCD_CHIP":
            info = {
                nomeDisplay: "Dados Chip",
                len: 255,
            }
            break

        case "COD_VLDC_ATTC_PRTO_SGRA":
            info = {
                nomeDisplay: "Código Validação Autenticação Protocolo Segurança",
                len: 1,
            }
            break

        case "COD_UCAF":
            info = {
                nomeDisplay: "CAVV",
                len: 42,
            }
            break

        case "NOM_CID_SMRC":
            info = {
                nomeDisplay: "Marketplace Cidade",
                len: 13,
                nomeBd71: "nom_cid_smrc",
            }
            break

        case "COD_PAIS_SMRC":
            info = {
                nomeDisplay: "Marketplace País",
                len: 3,
                nomeBd71: "cod_pais_smrc",
            }
            break

        case "NUM_CEP_SMRC":
            info = {
                nomeDisplay: "Marketplace CEP",
                len: 10,
                nomeBd71: "num_cep_smrc",
            }
            break

        case "SGL_EST_SMRC":
            info = {
                nomeDisplay: "Marketplace Estado",
                len: 3,
                nomeBd71: "sgl_est_smrc",
            }
            break

        case "DES_ENDR_SMRC":
            info = {
                nomeDisplay: "Marketplace Endereço",
                len: 48,
                nomeBd71: "des_endr_smrc",
            }
            break

        case "ID_FACR_PGMN_BNDR":
            info = {
                nomeDisplay: "Marketplace ID Facilitador",
                len: 11,
                nomeBd71: "id_facr_pgmn_bndr",
            }
            break

        case "COD_SMRC":
            info = {
                nomeDisplay: "Marketplace ID SubMerchant",
                len: 15,
                nomeBd71: "cod_smrc",
            }
            break

        case "NUM_CNPJ_SMRC":
            info = {
                nomeDisplay: "Marketplace CNPJ",
                len: 15,
                nomeBd71: "num_cnpj_smrc",
            }
            break

        case "COD_CPCD_TERM_VLDC_BNDR":
            info = {
                nomeDisplay: "Código Capacidade Terminal",
                len: 1,
                nomeBd71: "cod_cpcd_term_vldc_bndr",
            }
            break

        case "COD_PORT_PRES_VLDC_BNDR":
            info = {
                nomeDisplay: "Código Presença Portador",
                len: 1,
                nomeBd71: "cod_port_pres_vldc_bndr",
            }
            break

        case "COD_BIN_CAR":
            info = {
                nomeDisplay: "BIN cartão",
                len: 6,
                nomeBd71: "NA",
            }
            break

        case "DES_COD_TRAN":
            info = {
                nomeDisplay: "Descrição Tipo Transação",
                len: 50,
                nomeBd71: "des_cod_trx",
            }
            break

        case "DES_MOT_SW":
            info = {
                nomeDisplay: "Descrição Motivo SW",
                len: 100,
                nomeBd71: "des_mtv_sw",
            }
            break

        case "QTDE_TRAN":
            info = {
                nomeDisplay: "Quantidade Transação",
                len: 10,
                nomeBd71: "vl_trx",
            }
            break

        case "COD_PRCR":
            info = {
                nomeDisplay: "Código Parceiro",
                len: 5,
            }
            break

        case "NUM_CGC_CPF":
            info = {
                len: 15,
                nomeBd71: "nu_cgc_cpf",
            }
            break

        case "NUM_CHQ":
            info = {
                nomeDisplay: "Número Cheque",
                len: 12,
                nomeBd71: "nu_chq",
            }
            break

        case "NUM_RSMO_VD":
            info = {
                nomeDisplay: "Número Resumo Venda",
                len: 9,
                nomeBd71: "nu_rv",
            }
            break

        case "DAT_RSMO_VD":
            info = {
                nomeDisplay: "Data Resumo Venda",
                len: 6,
                nomeBd71: "dt_rv",
            }
            break

        case "NUM_TEL":
            info = {
                nomeDisplay: "Número Telefone",
                len: 12,
                nomeBd71: "nu_tel",
            }
            break

        case "TIP_DOC":
            info = {
                nomeDisplay: "Tipo Documento",
                len: 1,
                nomeBd71: "tp_doc",
            }
            break

        case "DTH_CON_TRAN":
            info = {
                nomeDisplay: "Data Consulta Transação",
                len: 8,
                nomeBd71: "dt_cns_trx",
            }
            break

        case "COD_REF_CTA_PGMN":
            info = {
                len: 29,
            }
            break

        case "COD_SLCT_TKN":
            info = {
                len: 11,
            }
            break

        case "NUM_PDV_ORG_TRAN":
            info = {
                len: 9,
            }
            break

        case "COD_TERM_ORG_TRAN":
            info = {
                len: 8,
            }
            break

        case "COD_SERV_TRAN":
            info = {
                len: 3,
            }
            break

        case "NUM_DDD_RCRG":
            info = {
                len: 4,
            }
            break

        case "NUM_TEL_RCRG":
            info = {
                len: 9,
            }
            break

        case "NUM_SEQ_UNC_OPER":
            info = {
                len: 9,
            }
            break

        case "NUM_PDV_VAN":
            info = {
                nomeDisplay: "PV Van",
                len: 15,
            }
            break

        case "NUM_TEL_CMDR":
            info = {
                len: 16,
            }
            break

        case "COD_CHCK_PDV":
            info = {
                len: 8,
            }
            break

        case "IND_PRSC_CVC_2":
            info = {
                len: 1,
            }
            break

        case "COD_VERS_SFTW":
            info = {
                len: 5,
            }
            break

        case "NUM_ID_PNPD":
            info = {
                len: 32,
            }
            break

        case "COD_MSG_ISO":
            info = {
                nomeDisplay: "Código Mensagem ISO",
                len: 4,
            }
            break

        case "ID_RQSC_PIX":
            info = {
                nomeDisplay: "Request ID",
                len: 25,
            }
            break

        case "COD_REF_CTA_PGMN":
            info = {
                nomeDisplay: "Código Referência Conta Pagamento",
                len: 29,
            }
            break

        case "COD_SLCT_TKN":
            info = {
                nomeDisplay: "Código Solicitação Token",
                len: 11,
            }
            break

        case "COD_CRCT_TRAN":
            info = {
                nomeDisplay: "Código Característica Transação",
                len: 2,
            }
            break

        case "COD_ID_CART_DGTL":
            info = {
                nomeDisplay: "Código Identificador Carteira Digital",
                len: 10,
            }
            break

        case "COD_PCM_EMS":
            info = {
                nomeDisplay: "Código Processamento Emissor",
                len: 6,
            }
            break

        case "ID_REF_BNDR":
            info = {
                nomeDisplay: "NRID",
                len: 15,
            }
            break

        case "VLR_MOED_ESTN":
            info = {
                nomeDisplay: "Valor Moeda Estrangeira",
                len: 15,
            }
            break

        case "COD_MOED_ESTN":
            info = {
                nomeDisplay: "Código Moeda Estrangeira",
                len: 3,
            }
            break

        case "PCT_TX_MKP":
            info = {
                nomeDisplay: "Taxa Markup",
                len: 5,
            }
            break

        case "VAL_TX_CONV_MOED":
            info = {
                nomeDisplay: "Valor Taxa Conversão Moeda",
                len: 8,
            }
            break

        case "NUM_SEQ_UNC_PAUZ":
            info = {
                nomeDisplay: "NSU Pré-Autorização",
                len: 12,
            }
            break

        case "NUM_ESTB_PAUZ":
            info = {
                nomeDisplay: "PV Pré-Autorização",
                len: 9,
            }
            break

        case "COD_TERM_PAUZ":
            info = {
                nomeDisplay: "Terminal Pré-Autorização",
                len: 8,
            }
            break
            
            
        case "COD_RSPS_ADIC_TKN":
            info = {
                nomeDisplay: "Cod. Resposta Adicional Token",
                len: 1,
            }
            break

        case "COD_TIP_OPE_CART_DGTL":
            info = {
                nomeDisplay: "Tipo de Operação Carteira Digital",
                len: 2,
            }
            break

        case "COD_TIP_DOC_CART_DGTL":
            info = {
                nomeDisplay: "Tipo de Documento Carteira Digital",
                len: 2,
            }
            break

        case "NUM_CNPJ_CPF_CART_DGTL":
            info = {
                nomeDisplay: "CPF/CNPJ - Carteira Digital",
                len: 14,
            }
            break
            
        // default:
        //     break
    }

    if (info)
    {
        field.info = info
    }

    return field
}
