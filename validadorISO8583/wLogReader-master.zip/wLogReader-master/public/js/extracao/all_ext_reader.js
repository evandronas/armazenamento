// all_ext_reader.js

function all_ext_reader()
{
    var ext_info = get_ext_info_all(kHTML_CBOX_DRIVER.value)
    // dump_obj(ret_info_ext)

    if (!ext_info)
    {
        alert("Não foi possível pegar as informações da extração.")
        return
    }

    // ====================================================================================================
    // validacoes das informacoes

    // layout da extracao
    if (!ext_info.array_fields)
    {
        alert("Não foi definido o layout da extração.")
        return
    }

    // ====================================================================================================

    // chamando funcao para quebrar o registro
    all_ext_break(ext_info)

    all_ext_display_result(ext_info)
}
