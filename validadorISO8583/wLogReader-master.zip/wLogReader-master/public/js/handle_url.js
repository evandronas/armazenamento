// handle_url.js

function handleUrl()
{
    /*
    Parametros e valores validos

    tipo        = acq | iss | ext | out | bit
    fe          = pos71 | pos75 | pdv71 | pdv75 | web
    drv         = [ mtg | tg | ip ]
                  [ protom | inac | ip ]
                  [ ec | ec tpdu | ol ]
    bndr        = alelo | amex | diners | jcb | elo | hv | iti | master | multifull | multivan | pl | ticket | visa | voucher | wq3
    */

    var url = document.URL
    var index = url.indexOf("?")

    // console.log("URL [%s]", url)
    // console.log("index [%s]", index)

    if (index >= 0)
    {
        var urlParams = url.substring(index + 1)
        var arrParams = urlParams.split("&")

        // console.log("URL Params [%s]", urlParams)

        var objparam = {}
        for(var i = 0; i < arrParams.length; i++)
        {
            // console.log("handleUrl() => param [%s]", arrParams[i])
            parseUrlParams(arrParams[i], objparam)
        }

        // dump_obj_console(objparam)
        handleParamObject(objparam)
        kHTML_BT_GO.focus()
    }
}

function parseUrlParams(param, objparam)
{
    var split = param.split("=")

    if (split.length != 2)
        return

    var p1 = split[0].toLowerCase()
    var p2 = split[1].toLowerCase()
    // console.log("param [%s] p1 [%s] p2 [%s]", param, p1, p2)

    if (p1 == kURL_PARAM_CAP)
    {
        objparam[p1] = p2
    }
    else if (validUrlParam(p1) && validUrlParam(p2))
    {
        objparam[p1] = p2
    }
}

function handleParamObject(objparam)
{
    // tipo
    if (kURL_PARAM_TIPO in objparam)
    {
        switch(objparam[kURL_PARAM_TIPO])
        {
            case kURL_VALOR_TIPO_ACQ:
                kHTML_RB_ACQ.checked = true
                handle_rb_acq()
                break

            case kURL_VALOR_TIPO_ISS:
                kHTML_RB_ISS.checked = true
                handle_rb_iss()
                break

            case kURL_VALOR_TIPO_EXT:
                kHTML_RB_EXT.checked = true
                handle_rb_ext()
                break

            case kURL_VALOR_TIPO_OUT:
                kHTML_RB_OUT.checked = true
                handle_rb_out()
                break

            case kURL_VALOR_TIPO_BIT:
                kHTML_RB_BIT.checked = true
                handle_rb_bit()
                break
        }
    }

    // fe
    if (kURL_PARAM_FE in objparam)
    {
        switch(objparam[kURL_PARAM_FE])
        {
            case kURL_VALOR_FE_POS71:
                kHTML_CBOX_FE.value = kFE_POS71
                handle_cbox_fe_changed()
                break

            case kURL_VALOR_FE_POS75:
                kHTML_CBOX_FE.value = kFE_POS75
                handle_cbox_fe_changed()
                break

            case kURL_VALOR_FE_PDV71:
                kHTML_CBOX_FE.value = kFE_PDV71
                handle_cbox_fe_changed()
                break

            case kURL_VALOR_FE_PDV75:
                kHTML_CBOX_FE.value = kFE_PDV75
                handle_cbox_fe_changed()
                break

            case kURL_VALOR_FE_WEB:
                kHTML_CBOX_FE.value = kFE_WEB
                handle_cbox_fe_changed()
                break
        }
    }

    // drv
    if (kURL_PARAM_DRV in objparam)
    {
        switch(objparam[kURL_PARAM_DRV])
        {
            case kURL_VALOR_DRV_MTG:
                kHTML_CBOX_DRIVER.value = kDRV_POS_MEGANAC
                break

            case kURL_VALOR_DRV_TG:
                kHTML_CBOX_DRIVER.value = kDRV_POS_NAC
                break

            case kURL_VALOR_DRV_TAPONPHONE:
                kHTML_CBOX_DRIVER.value = kDRV_POS_TAPONPHONE
                break

            case kURL_VALOR_DRV_PROTOM:
                kHTML_CBOX_DRIVER.value = kDRV_PDV_PROTOM
                break

            case kURL_VALOR_DRV_INAC:
                kHTML_CBOX_DRIVER.value = kDRV_PDV_INTELLINAC
                break

            case kURL_VALOR_DRV_IP:
                kHTML_CBOX_DRIVER.value = kDRV_PDV_IP
                break

            case kURL_VALOR_DRV_EC:
                kHTML_CBOX_DRIVER.value = kDRV_WEB_EC
                break

            case kURL_VALOR_DRV_EC_TPDU:
                kHTML_CBOX_DRIVER.value = kDRV_WEB_EC_TPDU
                break

            case kURL_VALOR_DRV_OL:
                kHTML_CBOX_DRIVER.value = kDRV_WEB_OL
                break

            // default:
            //     kHTML_CBOX_DRIVER.value = p2.toUpperCase()
            //     break
        }
    }

    // bndr
    if (kURL_PARAM_BNDR in objparam)
    {
        switch(objparam[kURL_PARAM_BNDR])
        {
            case kURL_VALOR_BNDR_ALELO:
                kHTML_CBOX_DRIVER.value = kBNDR_ALELO
                break

            // case "amex":
            case kURL_VALOR_BNDR_AMEXFULL:
                kHTML_CBOX_DRIVER.value = kBNDR_AMEXFULL
                break

            case kURL_VALOR_BNDR_DINERS:
            case kURL_VALOR_BNDR_JCB:
                kHTML_CBOX_DRIVER.value = kBNDR_DINERS
                break

            // case "elo":
            case kURL_VALOR_BNDR_ELOFULL:
                kHTML_CBOX_DRIVER.value = kBNDR_ELOFULL
                break

            case kURL_VALOR_BNDR_HV:
                kHTML_CBOX_DRIVER.value = kBNDR_HV
                break

            case kURL_VALOR_BNDR_ITI:
                kHTML_CBOX_DRIVER.value = kBNDR_ITI
                break

            // case "master":
            case kURL_VALOR_BNDR_MASTERCARD:
                kHTML_CBOX_DRIVER.value = kBNDR_MASTER
                break

            // case "multifull":
            case kURL_VALOR_BNDR_MULTIBANDEIRAFULL:
                kHTML_CBOX_DRIVER.value = kBNDR_MULTIBNDRFULL
                break

            // case "multivan":
            case kURL_VALOR_BNDR_MULTIBANDEIRAVAN:
                kHTML_CBOX_DRIVER.value = kBNDR_MULTIBNDRVAN
                break

            // case "pl":
            case kURL_VALOR_BNDR_PRIVATELABEL:
                kHTML_CBOX_DRIVER.value = kBNDR_PRIVATELABEL
                break

            case kURL_VALOR_BNDR_TICKET:
                kHTML_CBOX_DRIVER.value = kBNDR_TICKET
                break

            case kURL_VALOR_BNDR_VISA:
                kHTML_CBOX_DRIVER.value = kBNDR_VISA
                break

            case kURL_VALOR_BNDR_VOUCHER:
                kHTML_CBOX_DRIVER.value = kBNDR_VOUCHER
                break

            case kURL_VALOR_BNDR_WQ3:
                kHTML_CBOX_DRIVER.value = kBNDR_WQ3
                break
        }
    }

    // cap
    if (kURL_PARAM_CAP in objparam)
    {
        switch(objparam[kURL_PARAM_CAP])
        {
            case kURL_VALOR_CAP_EXTIATA:
                kHTML_CBOX_DRIVER.value = kEXT_EXTIATA
                break

            case kURL_VALOR_CAP_SIMULCREDIARIO:
                kHTML_CBOX_DRIVER.value = kEXT_SIMULCREDIARIO
                break

            case kURL_VALOR_CAP_OLTO:
                kHTML_CBOX_DRIVER.value = kEXT_OLTO
                break

            default:
                kHTML_CBOX_DRIVER.value = objparam[kURL_PARAM_CAP].toUpperCase()
                break
        }
    }

    // outros
    if (kURL_PARAM_OUTROS in objparam)
    {
        switch(objparam[kURL_PARAM_OUTROS])
        {
            case kURL_VALOR_OUT_FEINTERFCR:
                kHTML_CBOX_DRIVER.value = kOUT_FEINTERF_CR
                break

            case kURL_VALOR_OUT_FEINTERFDB:
                kHTML_CBOX_DRIVER.value = kOUT_FEINTERF_DB
                break

            case kURL_VALOR_OUT_FEINTERFB:
                kHTML_CBOX_DRIVER.value = kOUT_FEINTERF_B
                break

            case kURL_VALOR_OUT_SWREPLIC:
                kHTML_CBOX_DRIVER.value = kOUT_SWREPLIC
                break

            case kURL_VALOR_OUT_NUNTIUS:
                kHTML_CBOX_DRIVER.value = kOUT_NUNTIUS
                break
        }
    }

    // sem header
    if (kURL_PARAM_SEMHEADER in objparam)
    {
        switch(objparam[kURL_PARAM_SEMHEADER])
        {
            case "true":
                kHTML_CB_SEM_HEADER.checked = true
                break
        }
    }

    // sem formatacao
    if (kURL_PARAM_SEMFORMATACAO in objparam || kURL_PARAM_SEMFMT in objparam)
    {
        switch(objparam[kURL_PARAM_SEMFORMATACAO])
        {
            case "true":
                kHTML_CB_SEM_FORMATACAO.checked = true
                break

            default:
                switch(objparam[kURL_PARAM_SEMFMT])
                {
                    case "true":
                        kHTML_CB_SEM_FORMATACAO.checked = true
                        break
                }
                break
        }
    }
}

function updateUrl(value)
{
    var p1
    var p2
    var aux

    switch(value)
    {
        case kURL_PARAM_TIPO:
            p1 = value
            if (kHTML_RB_ACQ.checked)
                p2 = kURL_VALOR_TIPO_ACQ
            else if (kHTML_RB_ISS.checked)
                p2 = kURL_VALOR_TIPO_ISS
            else if (kHTML_RB_EXT.checked)
                p2 = kURL_VALOR_TIPO_EXT
            else if (kHTML_RB_OUT.checked)
                p2 = kURL_VALOR_TIPO_OUT
            break

        case kURL_PARAM_FE:
            p1 = value
            aux = kHTML_CBOX_FE.value
            switch(aux)
            {
                case kFE_POS71:
                    p2 = kURL_VALOR_FE_POS71
                    break

                case kFE_POS75:
                    p2 = kURL_VALOR_FE_POS75
                    break

                case kFE_PDV71:
                    p2 = kURL_VALOR_FE_PDV71
                    break

                case kFE_PDV75:
                    p2 = kURL_VALOR_FE_PDV75
                    break

                case kFE_WEB:
                    p2 = kURL_VALOR_FE_WEB
                    break
            }
            break

        case kURL_PARAM_DRV:
            p1 = value
            aux = kHTML_CBOX_DRIVER.value
            switch(aux)
            {
                // pos
                case kDRV_POS_MEGANAC:
                    p2 = kURL_VALOR_DRV_MTG
                    break

                case kDRV_POS_NAC:
                    p2 = kURL_VALOR_DRV_TG
                    break

                case kDRV_POS_TAPONPHONE:
                    p2 = kURL_VALOR_DRV_TAPONPHONE
                    break

                // pdv
                case kDRV_PDV_PROTOM:
                    p2 = kURL_VALOR_DRV_PROTOM
                    break

                case kDRV_PDV_INTELLINAC:
                    p2 = kURL_VALOR_DRV_INAC
                    break

                case kDRV_PDV_QH:
                    p2 = kURL_VALOR_DRV_QH
                    break

                // pos/pdv
                case kDRV_POS_POSIP:
                case kDRV_PDV_IP:
                case kDRV_POS_POSIP_MEGANAC:
                    p2 = kURL_VALOR_DRV_IP
                    break

                // web
                case kDRV_WEB_EC:
                    p2 = kURL_VALOR_DRV_EC
                    break

                case kDRV_WEB_EC_TPDU:
                    p2 = kURL_VALOR_DRV_EC_TPDU
                    break

                case kDRV_WEB_OL:
                    p2 = kURL_VALOR_DRV_OL
                    break
            }
            break

        case kURL_PARAM_BNDR:
            p1 = value
            aux = kHTML_CBOX_DRIVER.value
            switch(aux)
            {
                case kBNDR_DINERS:
                    p2 = kURL_VALOR_BNDR_DINERS
                    break

                default:
                    p2 = removerEspaco(aux).toLowerCase()
                    break
            }
            break

        case kURL_PARAM_CAP:
            p1 = value
            aux = kHTML_CBOX_DRIVER.value
            switch(aux)
            {
                // case kEXT_CAPCHFULAMEX_71:
                // case kEXT_CAPCHFULAMEX_71:
                //     p2 = kEXT_CAPCHFULAMEX.toLowerCase()
                //     break

                // case kEXT_CAPDEBVAN_71:
                // case kEXT_CAPDEBVAN_75:
                //     p2 = kEXT_CAPDEBVAN.toLowerCase()
                //     break

                default:
                    p2 = removerEspaco(aux).toLowerCase()
                    break
            }
            break

        case kURL_PARAM_OUTROS:
            p1 = value
            aux = kHTML_CBOX_DRIVER.value
            switch(aux)
            {
                case kOUT_FEINTERF_CR:
                    p2 = kURL_VALOR_OUT_FEINTERFCR
                    break

                case kOUT_FEINTERF_DB:
                    p2 = kURL_VALOR_OUT_FEINTERFDB
                    break

                case kOUT_FEINTERF_B:
                    p2 = kURL_VALOR_OUT_FEINTERFB
                    break

                case kOUT_SWREPLIC:
                    p2 = kURL_VALOR_OUT_SWREPLIC
                    break

                case kOUT_NUNTIUS:
                    p2 = kURL_VALOR_OUT_NUNTIUS
                    break
            }
            break

        case kURL_PARAM_SEMHEADER:
            p1 = value
            if (kHTML_CB_SEM_HEADER.checked)
            {
                p2 = "true"
            }
            else
            {
                p2 = "false"
            }
            break

        case kURL_PARAM_SEMFMT:
            p1 = value
            if (kHTML_CB_SEM_FORMATACAO.checked)
            {
                p2 = "true"
            }
            else
            {
                p2 = "false"
            }
            break

        default:
            p1 = undefined
            p2 = undefined
            break
    }

    if (p1 && p2)
    {
        appendToUrl(value, p1 + "=" + p2)
    }
}

function appendToUrl(value, param)
{
    // console.log("appendToUrl [%s]", param)

    var url = document.URL
    var newUrl
    var index = url.indexOf("?")

    if (index < 0) // nao tem nenhum parametro
    {
        // console.log("if index < 0")
        newUrl = url + "?" + param
    }
    else // ja tem parametro
    {
        // console.log("else index < 0")
        var index2 = url.indexOf(value + "=")
        if (index2 < 0) // esse parametro ainda nao existe na url
        {
            // console.log("if index2 < 0")
            newUrl = url + "&" + param
        }
        else // parametro ja existe na url, entao precisa remover ele em diante e adicionar novamente
        {
            // console.log("else index2 < 0")
            // console.log("url antes do param [%s]", url.substring(0, index2))
            if (param == "semheader=false" || param == "semfmt=false" || param == "semformatacao=false")
            {
                newUrl = url.substring(0, index2 - 1)
            }
            else
            {
                newUrl = url.substring(0, index2) + param
            }
        }
    }

    addToUrl(newUrl)
}

function addToUrl(url)
{
    if (history.pushState)
    {
        window.history.pushState({path: url}, "", url)
    }
}

function cleanUrl()
{
    var url = window.location.protocol + "//" + window.location.host + window.location.pathname

    if (history.pushState)
    {
        // console.log("pushState")
        window.history.pushState({path: url}, "", url)
    }
}

function validUrlParam(value)
{
    var ret = false

    switch(value)
    {
        // param
        case kURL_PARAM_TIPO:
        case kURL_PARAM_FE:
        case kURL_PARAM_DRV:
        case kURL_PARAM_BNDR:
        case kURL_PARAM_CAP:
        case kURL_PARAM_SEMHEADER:
        case kURL_PARAM_SEMFMT:
        case kURL_PARAM_SEMFORMATACAO:
            ret = true
            break

        // tipo
        case kURL_VALOR_TIPO_ACQ:
        case kURL_VALOR_TIPO_ISS:
        case kURL_VALOR_TIPO_EXT:
        case kURL_VALOR_TIPO_OUT:
        case kURL_VALOR_TIPO_BIT:
            ret = true
            break

        // fe
        case kURL_VALOR_FE_POS71:
        case kURL_VALOR_FE_POS75:
        case kURL_VALOR_FE_PDV71:
        case kURL_VALOR_FE_PDV75:
        case kURL_VALOR_FE_WEB:
            ret = true
            break

        // drv
        case kURL_VALOR_DRV_MTG:
        case kURL_VALOR_DRV_TG:
        case kURL_VALOR_DRV_IP:
        case kURL_VALOR_DRV_TAPONPHONE:
        case kURL_VALOR_DRV_PROTOM:
        case kURL_VALOR_DRV_INAC:
        case kURL_VALOR_DRV_QH:
        case kURL_VALOR_DRV_EC:
        case kURL_VALOR_DRV_EC_TPDU:
        case kURL_VALOR_DRV_OL:
            ret = true
            break

        // bndr
        case kURL_VALOR_BNDR_ALELO:
        case kURL_VALOR_BNDR_AMEXFULL:
        case kURL_VALOR_BNDR_DINERS:
        case kURL_VALOR_BNDR_JCB:
        case kURL_VALOR_BNDR_ELOFULL:
        case kURL_VALOR_BNDR_HV:
        case kURL_VALOR_BNDR_ITI:
        case kURL_VALOR_BNDR_MASTERCARD:
        case kURL_VALOR_BNDR_MULTIBANDEIRAFULL:
        case kURL_VALOR_BNDR_MULTIBANDEIRAVAN:
        case kURL_VALOR_BNDR_PRIVATELABEL:
        case kURL_VALOR_BNDR_TICKET:
        case kURL_VALOR_BNDR_VISA:
        case kURL_VALOR_BNDR_VOUCHER:
        case kURL_VALOR_BNDR_WQ3:
            ret = true
            break

        // cap

        // swreplic
        case kURL_VALOR_OUT_FEINTERFCR:
        case kURL_VALOR_OUT_FEINTERFDB:
        case kURL_VALOR_OUT_FEINTERFB:
        case kURL_VALOR_OUT_SWREPLIC:
        case kURL_VALOR_OUT_NUNTIUS:
            ret = true
            break

        case "true":
            ret = true
            break
    }

    // console.log("validUrlParam() => param [%s] ret [%s]", value, ret)
    return ret
}

function findParamInUrl(param)
{
    /*
        objeto de retorno
            param -> no do parametro para procurar na url
            ret   -> true = retorna o parametro e o valor (ex.: "semheader=true")
                     false/undefined = retorna "true" se param existe e "false" se nao existe
    */

    var obj = {
        ret: false
    }
    var url = document.URL
    var index = url.indexOf(param)

    if (index >= 0) // achou param
    {
        obj.ret = true
        // console.log("indexOf [%s] is [%s]", param, index)
        var index2 = url.indexOf("?")

        if (index2 >= 0)
        {
            var paramsUrl = url.substring(index2 + 1)
            // console.log("params [%s]", paramsUrl)

            var paramsUrlSplit = paramsUrl.split("&")

            for (var i = 0; i < paramsUrlSplit.length; i++)
            {
                const element = paramsUrlSplit[i]
                // console.log("element [%s]", element)

                if (element.indexOf(param) >= 0)
                {
                    obj.param = element
                    // console.log("achou!! eh o param [%s]", element)
                }
            }
        }
    }

    // console.log("url [%s] index [%s] ret [%s]", url, index, index >= 0)
    // dump_obj_console(obj)
    return obj
}
