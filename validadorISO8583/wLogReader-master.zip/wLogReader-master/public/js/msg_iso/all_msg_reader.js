// all_msg_reader.js

function all_msg_reader()
{
    /*
    ====================================================================================================
    pegar as informacoes da mensagem

    a funcao ira retornar um objeto com as informacoes
    ====================================================================================================
    */

    var msg_info = get_msg_info_all(kHTML_RB_ACQ.checked, kHTML_RB_ISS.checked, kHTML_CBOX_FE.value, kHTML_CBOX_DRIVER.value)
    // dump_obj_console(msg_info)

    if (!msg_info)
    {
        alert("Não foi possível pegar as informações da mensagem.")
        return
    }

    // ====================================================================================================
    // pegando o header

    var header
    if (!kHTML_CB_SEM_HEADER.checked) // vai pegar o header somente se o checkbox nao estiver selecionado
    {
        if (!msg_info.get_header)
        {
            alert("Não foi definida a função para pegar o header da mensagem.")
            return
        }

        var r
        if (msg_info.isPOS)
        {
            r = msg_info.get_header(kHTML_CBOX_FE.value, kHTML_CBOX_DRIVER.value)
        }
        else if (msg_info.isPDV)
        {
            r = msg_info.get_header(kHTML_CBOX_FE.value, kHTML_CBOX_DRIVER.value)
        }
        else
        {
            if (!msg_info.header_len)
            {
                alert("Não foi definido o tamanho do header da mensagem.")
                return
            }

            r = msg_info.get_header(msg_info)
        }
        // dump_obj(r)

        if (r.ret)
        {
            header = r.header

            if (r.header_clean)
            {
                msg_clean += r.header_clean
                msg_clean += get_break_line()
            }
        }
        else
        {
            alert("Mensagem inválida. Não foi possível pegar o header da mensagem.")
            return
        }
    }
    // console.log("header [%s]", header)

    // ====================================================================================================
    // pegando o msgtype

    var len_mti = 4
    var msgtype = {}

    if (!msg_info.formatoMTI)
    {
        alert("O formato do MTI não foi definido.")
        return
    }

    if (msg_info.formatoMTI != kFMT_BCD)
    {
        len_mti *= 2
    }

    msgtype.msg = get_field_msg(len_mti)

    if (msg_info.formatoMTI == kFMT_HEXA)
    {
        msgtype.conv = hex2a(msgtype.msg)
    }
    else if (msg_info.formatoMTI == kFMT_EBC)
    {
        msgtype.conv = conv_ebc2a(msgtype.msg)
    }

    if (msgtype.conv)
    {
        msgtype.conv = mostrarColchete(msgtype.conv)
    }
    // dump_obj_console(msgtype)

    if (msgtype.msg)
    {
        msg_clean += msgtype.msg + get_break_line()
    }

    // ====================================================================================================
    // pegando o bitmap

    var len_bitmap = 16
    var bitmap = {}
    bitmap.is_segundo_bitmap_on = false

    if (!msg_info.formatoBitmap)
    {
        alert("O formato do bitmap não foi definido.")
        return
    }

    if (msg_info.formatoBitmap == kFMT_EBC || msg_info.bitmapHexaConv)
    {
        len_bitmap *= 2
    }

    var bitmap_msg = get_field_msg(len_bitmap)
    bitmap.orig = bitmap_msg
    bitmap.hexa = bitmap_msg

    if (msg_info.formatoBitmap == kFMT_EBC)
    {
        bitmap.hexa = conv_ebc2a(bitmap_msg)
    }
    else if (msg_info.bitmapHexaConv)
    {
        bitmap.hexa = hex2a(bitmap_msg)
    }

    bitmap.bin = bitmap_hex2bin(bitmap.hexa) // transformando para binario

    if (bitmap.bin.substr(0, 1) == "1") // segundo bitmap presente
    {
        bitmap.is_segundo_bitmap_on = true
        bitmap_msg = get_field_msg(len_bitmap)
        bitmap.orig += bitmap_msg

        if (msg_info.formatoBitmap == kFMT_EBC)
        {
            bitmap.hexa += conv_ebc2a(bitmap_msg)
        }
        else if (msg_info.bitmapHexaConv)
        {
            bitmap.hexa += hex2a(bitmap_msg)
        }
        else
        {
            bitmap.hexa += bitmap_msg
        }

        bitmap.bin = bitmap_hex2bin(bitmap.hexa)
    }

    // bitmap formatado
    bitmap.formatted = bitmap2formatted(bitmap.bin)
    // dump_obj_console(bitmap)

    msg_clean += bitmap.orig + get_break_line()

    // ====================================================================================================
    // loop pelos bits

    var i_len = 64
    if (bitmap.is_segundo_bitmap_on)
    {
        i_len = 128
    }

    var bit
    var bit_info
    for (var i = 0; i < i_len; i++) // verificando primeiro bitmap
    {
        var bit_bin = bitmap.bin.substr(i, 1) // flag pra ver se o DE esta ligado

        if (bit_bin == 1) // bit presente
        {
            if (i > 0) // ignorar o bit 1 do bitmap
            {
                // "zerando"
                bit_info = undefined

                // pegando o numero do DE
                bit = i + 1

                // pegando informacoes do bit se a funcao especifica foi definida
                if (msg_info.get_bit_info)
                {
                    bit_info = msg_info.get_bit_info(bit)
                }

                if (!bit_info) // se nao encontrou o DE no metodo especifico, procurar no generico
                {
                    bit_info = get_bit_gen_iso_v0(bit)
                }

                if (bit_info) // DE mapeado
                {
                    if (all_msg_break(bit, bit_info, msg_info) < 0)
                    {
                        // encontrou algum erro pra quebrar o DE
                        display_result_all(msg_info, header, bitmap, msgtype)
                        return
                    }
                }
                else // DE nao mapeado
                {
                    alert("ERRO - DE " + bit + " não mapeado")
                    break
                }
            }
        }
    }

    display_result_all(msg_info, header, bitmap, msgtype)
}
