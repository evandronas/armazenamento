// all_gen.js

function display_result_all(ret_info_msg, header, bitmap, msgtype)
{
    // mensagem formatted
    kHTML_LABEL_MSG_FORMATTED.innerHTML = ""

    // header
    if (header)
    {
        kHTML_LABEL_MSG_FORMATTED.innerHTML += header + get_break_line()
    }

    // bitmap
    if (bitmap.ebc)
    {
        kHTML_LABEL_MSG_FORMATTED.innerHTML += "Bitmap EBCDIC - " + bitmap.ebc + get_break_line()
    }
    kHTML_LABEL_MSG_FORMATTED.innerHTML += "Bitmap Hexa - " + bitmap.hexa + get_break_line()
    kHTML_LABEL_MSG_FORMATTED.innerHTML += "Bitmap - " + bitmap.formatted + get_break_line()

    kHTML_LABEL_MSG_FORMATTED.innerHTML += get_break_line()

    // msgtype
    var msgtype_conv = ""
    if (msgtype.conv)
    {
        msgtype_conv = msgtype.conv
    }
    kHTML_LABEL_MSG_FORMATTED.innerHTML += "MsgType: " + msgtype.msg + msgtype_conv + get_break_line()

    kHTML_LABEL_MSG_FORMATTED.innerHTML += get_break_line()
    kHTML_LABEL_MSG_FORMATTED.innerHTML += msg_formatted
    kHTML_LABEL_MSG_FORMATTED.innerHTML += get_break_line()

    // mensagem clean
    kHTML_LABEL_MSG_CLEAN.innerHTML = ""
    if (kHTML_CB_SEM_FORMATACAO.checked)
    {
        kHTML_LABEL_MSG_CLEAN.innerHTML = "Somente os valores, sem formatação" + "<br><br>"
        kHTML_LABEL_MSG_CLEAN.innerHTML += msg_clean
        kHTML_LABEL_MSG_CLEAN.innerHTML += get_break_line()
        kHTML_LABEL_MSG_CLEAN.innerHTML += get_break_line()
    }
}

function get_header_gen(msg_info)
{
    var info
    var header_len = msg_info.header_len

    var header = get_field_msg(header_len)

    if (header)
    {
        var header_formatted = ""
        // header_formatted += "Header - " + header + get_break_line()
        header_formatted += "Header - " + header

        if (msg_info.headerIsoLen)
        {
            header_formatted += mostrarColchete(parseInt(header, 16))
        }
        header_formatted += get_break_line()

        info = {
            ret: true,
            header: header_formatted,
            header_clean: header,
        }
    }
    else
    {
        info = { ret: false }
    }

    return info
}
