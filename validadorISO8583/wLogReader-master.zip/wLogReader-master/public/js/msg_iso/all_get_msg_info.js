// all_get_msg_info.js

function get_msg_info_all(acq, iss, front_end, driver)
{
    /*
    Propriedades do objeto de retorno

    formato             [string]    formato do mensagem (HEXA, EBC ou BCD) - o formato do DE sobreescreve esse formato
    formatoMTI          [string]    formato do message type indicator (HEXA, EBC ou BCD)
    formatoBitmap       [string]    formato do bitmap (HEXA ou EBC)
    bitmapHexaConv      [bool]      true = realiza conversao do bitmap de hexa
    bitmap_len          [num]       tamanho do bitmap -> Ex.: f23c4601a8e18208 = len 16 | f23c4601a8e182080000000000010000 = len = 32
    isPOS               [bool]      indica se a mensagem eh do terminal POS
    isPDV               [bool]      indica se a mensagem eh do terminal PDV
    get_bit_info        [string]    nome para a funcao onde esta a definicao dos bits da mensagem
    get_header          [string]    nome para a funcao que quebra o header (get_header_gen eh a funcao generica, precisa apenas da propriedade header_len)
    header_len          [num]       tamnho do header (usado para a funcao get_header_gen)
    headerIsoLen        [bool]      indica se o header eh o tamanho da mensagem e faz a conversao
    versao_iso          [num]       versao da iso
    */

    var info

    if (acq) // acquirer
    {
        switch (front_end)
        {
            case kFE_POS71:
                info = {
                    isPOS: true,
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_BCD,
                    formatoBitmap: kFMT_HEXA,
                    get_bit_info: get_bit_pos,
                    get_header: get_header_pos,
                }
                break

            case kFE_POS75:
                info = {
                    isPOS: true,
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_BCD,
                    formatoBitmap: kFMT_HEXA,
                    get_bit_info: get_bit_pos,
                    get_header: get_header_pos,
                    headerIsoLen: true,
                }
                break

            case kFE_PDV71:
                info = {
                    isPDV: true,
                    formato: kFMT_EBC,
                    formatoMTI: kFMT_EBC,
                    formatoBitmap: kFMT_EBC,
                    get_bit_info: get_bit_pdv,
                    get_header: get_header_pdv,
                }
                break

            case kFE_PDV75:
                info = {
                    isPDV: true,
                    formato: kFMT_EBC,
                    formatoMTI: kFMT_EBC,
                    formatoBitmap: kFMT_EBC,
                    get_bit_info: get_bit_pdv,
                    get_header: get_header_pdv,
                    headerIsoLen: true,
                }
                break

            case kFE_WEB:
                switch (driver)
                {
                    case kDRV_WEB_EC:
                        info = {
                            isWEB: true,
                            formato: kFMT_EBC,
                            formatoMTI: kFMT_EBC,
                            formatoBitmap: kFMT_EBC,
                            get_bit_info: get_bit_web,
                            get_header: get_header_gen,
                            header_len: 4,
                            headerIsoLen: true,
                        }
                        break

                    case kDRV_WEB_EC_TPDU:
                        info = {
                            isWEB: true,
                            formato: kFMT_EBC,
                            formatoMTI: kFMT_EBC,
                            formatoBitmap: kFMT_EBC,
                            get_bit_info: get_bit_web,
                            get_header: get_header_web,
                            header_len: 4,
                            headerIsoLen: true,
                        }
                        break

                    case kDRV_WEB_OL:
                        info = {
                            isOL: true,
                            formato: kFMT_EBC,
                            formatoMTI: kFMT_EBC,
                            formatoBitmap: kFMT_EBC,
                            get_bit_info: get_bit_ol,
                            get_header: get_header_gen,
                            header_len: 8,
                        }
                        break
                }
                break
        }
    }
    else if (iss) // issuer
    {
        switch (driver)
        {
            case kBNDR_ALELO:
                info = {
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_HEXA,
                    formatoBitmap: kFMT_HEXA,
                    bitmapHexaConv: true,
                    get_bit_info: get_bit_alelo,
                    get_header: get_header_gen,
                    header_len: 14,
                }
                break

            case kBNDR_AMEXFULL:
                info = {
                    formato: kFMT_EBC,
                    formatoMTI: kFMT_EBC,
                    formatoBitmap: kFMT_HEXA,
                    get_bit_info: get_bit_amexfull,
                    get_header: get_header_gen,
                    header_len: 4,
                }
                break

            case kBNDR_DINERS:
                info = {
                    formato: kFMT_EBC,
                    formatoMTI: kFMT_EBC,
                    formatoBitmap: kFMT_HEXA,
                    get_bit_info: get_bit_diners,
                    get_header: get_header_gen,
                    header_len: 8,
                }
                break

            case kBNDR_ELOFULL:
                info = {
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_HEXA,
                    formatoBitmap: kFMT_HEXA,
                    bitmapHexaConv: true,
                    get_bit_info: get_bit_elofull,
                    get_header: get_header_gen,
                    header_len: 14,
                }
                break

            case kBNDR_ITI:
                info = {
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_HEXA,
                    formatoBitmap: kFMT_HEXA,
                    bitmapHexaConv: true,
                    get_bit_info: get_bit_iti,
                    get_header: get_header_gen,
                    header_len: 8,
                }
                break

            case kBNDR_HV:
                info = {
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_HEXA,
                    formatoBitmap: kFMT_HEXA,
                    bitmapHexaConv: true,
                    get_bit_info: get_bit_hv,
                    get_header: get_header_gen,
                    header_len: 8,
                }
                break

            case kBNDR_MASTER:
                info = {
                    formato: kFMT_EBC,
                    formatoMTI: kFMT_EBC,
                    formatoBitmap: kFMT_HEXA,
                    get_bit_info: get_bit_mastercard,
                    get_header: get_header_gen,
                    header_len: 4,
                }
                break

            case kBNDR_MULTIBNDRFULL:
                info = {
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_HEXA,
                    formatoBitmap: kFMT_HEXA,
                    bitmapHexaConv: true,
                    get_bit_info: get_bit_multibndr_full,
                    get_header: get_header_gen,
                    header_len: 4,
                }
                break

            case kBNDR_MULTIBNDRVAN:
                info = {
                    formato: kFMT_EBC,
                    formatoMTI: kFMT_EBC,
                    formatoBitmap: kFMT_HEXA,
                    get_bit_info: get_bit_multibndr_van,
                    get_header: get_header_gen,
                    header_len: 8,
                }
                break

            case kBNDR_PRIVATELABEL:
                info = {
                    formato: kFMT_EBC,
                    formatoMTI: kFMT_EBC,
                    formatoBitmap: kFMT_EBC,
                    get_bit_info: get_bit_privatelabel,
                    get_header: get_header_gen,
                    header_len: 8,
                }
                break

            case kBNDR_TICKET:
                info = {
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_HEXA,
                    formatoBitmap: kFMT_HEXA,
                    bitmapHexaConv: true,
                    get_bit_info: get_bit_ticket,
                    get_header: get_header_gen,
                    header_len: 8,
                }
                break

            case kBNDR_VISA:
                info = {
                    isVISA: true,
                    formato: kFMT_EBC,
                    formatoMTI: kFMT_BCD,
                    formatoBitmap: kFMT_HEXA,
                    get_bit_info: get_bit_visa,
                    get_header: get_header_visa,
                    header_len: 52,
                }
                break

            case kBNDR_VOUCHER:
                info = {
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_HEXA,
                    formatoBitmap: kFMT_HEXA,
                    bitmapHexaConv: true,
                    get_bit_info: get_bit_voucher,
                    get_header: get_header_gen,
                    header_len: 8,
                }
                break

            case kBNDR_WQ3:
                info = {
                    formato: kFMT_HEXA,
                    formatoMTI: kFMT_HEXA,
                    formatoBitmap: kFMT_HEXA,
                    bitmapHexaConv: true,
                    get_bit_info: get_bit_wq3,
                    get_header: get_header_gen,
                    header_len: 8,
                }
                break
        }
    }

    return info
}
