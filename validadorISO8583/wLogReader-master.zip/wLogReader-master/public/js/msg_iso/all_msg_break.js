// all_msg_break.js

function all_msg_break(bit, bit_info, msg_info)
{
    switch (bit_info.tipo)
    {
        case kFixo: // posicoes fixas

            if (bit_info.len)
            {
                var bit_len = bit_info.len
                if (msg_info.formato == kFMT_HEXA || msg_info.formato == kFMT_EBC)
                {
                    if (bit_info.formato != kFMT_BCD && bit_info.formato != kFMT_BIN)
                    {
                        bit_len *= 2
                    }
                }
            }
            else
            {
                alert("ERRO - Não foi definido o tamanho do DE" + bit + ".")
                return -1
            }
            // console.log("Fixo - bit [%s] bit_len [%s]", bit, bit_len)

            // ====================================================================================

            var val = get_field_msg(bit_len)
            // if (val.length != bit_len)
            // {
            // 	alert("O tamanho do conteúdo do DE" + bit + " não é igual ao tamanho especificado.")
            // 	return -1
            // }

            // ====================================================================================

            var val_conv = ""
            if (bit_info.formatMoney) // mostrar o valor da transacao formatado
            {
                var val_aux = val
                if (msg_info.formato == kFMT_EBC)
                {
                    if (bit_info.formato != kFMT_BCD)
                    {
                        val_aux = conv_ebc2a(val)
                    }
                }
                else if (msg_info.formato == kFMT_HEXA)
                {
                    if (bit_info.formato != kFMT_BCD)
                    {
                        val_aux = hex2a(val)
                    }
                }
                val_conv = mostrarColchete(formatMoney(val_aux))
            }
            else if (bit_info.formatBIT42) // PDV
            {
                var val_conv_bit42 = conv_ebc2a(val)
                val_conv = mostrarColchete(val_conv_bit42) + mostrarColchete(format_bit42_PDV(val_conv_bit42))
            }
            else if (bit_info.custom_format)
            {
                val_conv = bit_info.custom_format(val)
            }
            else if (msg_info.formato == kFMT_HEXA)
            {
                if (bit_info.formato != kFMT_BCD && bit_info.formato != kFMT_BIN)
                {
                    if (!bit_info.nao_conv)
                    {
                        val_conv = mostrarColchete(hex2a(val))
                    }
                }
            }
            else if (msg_info.formato == kFMT_EBC)
            {
                if (bit_info.formato != kFMT_BCD && bit_info.formato != kFMT_BIN)
                {
                    if (!bit_info.nao_conv)
                    {
                        val_conv = mostrarColchete(conv_ebc2a(val))
                    }
                }
            }
            val_conv = converterEspacoParaHtml(val_conv)

            // ====================================================================================

            msg_formatted += "DE " + padDE(bit) + " - " + "F" + padLEN(bit_info.len) + " - " + val + val_conv
            msg_clean += val + get_break_line()

            break

        // case kLvar:
        // 	break

        case kLLvar: // posicoes ate 99 (LLVAR)

            var llvar_len = 2

            if (msg_info.isPOS)
            {
                llvar_len = 2
            }
            else if (msg_info.isVISA)
            {
                llvar_len = 2
            }
            else if ((msg_info.formato == kFMT_HEXA || msg_info.formato == kFMT_EBC) && bit_info.formato != kFMT_BCD)
            {
                llvar_len *= 2
            }

            // ====================================================================================

            var len_bit = get_field_msg(llvar_len)
            var len_bit_orig = len_bit

            if (msg_info.formato == kFMT_EBC)
            {
                if (msg_info.isVISA)
                {
                    len_bit = parseInt(len_bit, 16)
                }
                else
                {
                    len_bit = conv_ebc2a(len_bit)
                }
            }
            else if (msg_info.formato == kFMT_HEXA && !msg_info.isPOS)
            {
                if (bit_info.formato != kFMT_BCD)
                {
                    len_bit = hex2a(len_bit)
                }
            }
            len_bit = parseInt(len_bit, 10)

            // Tratamento DE35 POS - quando o tamanho nao for par, adiciona um
            if ((msg_info.isPOS || msg_info.isVISA) && (bit == 2 || bit == 35) && (len_bit % 2) != 0)
            {
                len_bit += 1
            }

            var len_bit_aux = len_bit
            if ((msg_info.isPOS || msg_info.isVISA) && bit == 35 && len_bit == 37) // somando 1 pra pegar o "f" que vem no final da trilha 2 somente para POS
            {
                len_bit_aux += 1
            }

            if (msg_info.formato == kFMT_HEXA || msg_info.formato == kFMT_EBC)
            {
                if (bit_info.formato != kFMT_BCD && bit_info.formato != kFMT_BIN)
                {
                    len_bit_aux *= 2
                }
            }

            // ====================================================================================

            var val = get_field_msg(len_bit_aux)

            if (msg_info.isVISA && ((bit == 2 && len_bit_aux == 15) || (bit == 35 && len_bit_aux == 35))) // quando o cartao da Visa tem 15 posicoes, ele nao pega o DE direito
            {
                val += get_field_msg(1)
            }

            // if (val.length != len_bit_aux)
            // if (val.length != len_bit_aux && !((bit == 2 && len_bit_aux == 15) || (bit == 35 && len_bit_aux == 35)))
            // {
            //     alert("ERRO - O tamanho do conteúdo do DE" + bit + " não é igual ao tamanho " + len_bit_aux + " que está na mensagem.")
            //     return -1
            // }

            // ====================================================================================

            var val_conv = ""
            if (msg_info.formato == kFMT_HEXA)
            {
                if (bit_info.formato != kFMT_BCD && bit_info.formato != kFMT_BIN)
                {
                    if (!bit_info.nao_conv) // se for true, nao realiza a conversao
                    {
                        val_conv = mostrarColchete(hex2a(val))
                    }
                }
            }
            else if (msg_info.formato == kFMT_EBC)
            {
                if (bit_info.formato != kFMT_BCD)
                {
                    if (!bit_info.nao_conv) // se for true, nao realiza a conversao
                    {
                        val_conv = mostrarColchete(conv_ebc2a(val))
                    }
                }
            }
            val_conv = converterEspacoParaHtml(val_conv)

            // ====================================================================================

            msg_formatted += "DE " + padDE(bit) + " - " + "V" + padLEN(len_bit) + " - " + val + val_conv + get_break_line()
            // msg_clean += len_bit_orig + "-" + val + get_break_line()
            msg_clean += len_bit_orig + val + get_break_line()

            break

        case kLLLvar: // posicoes ate 999 (LLLVAR)

            var lllvar_len = 3

            if (msg_info.isPOS)
            {
                lllvar_len = 4
            }
            else if (msg_info.isVISA)
            {
                lllvar_len = 2
            }
            else if ((msg_info.formato == kFMT_HEXA || msg_info.formato == kFMT_EBC) && bit_info.formato != kFMT_BCD)
            {
                lllvar_len *= 2
            }

            // ====================================================================================

            var len_bit = get_field_msg(lllvar_len)
            var len_bit_orig = len_bit

            if (msg_info.formato == kFMT_EBC) // converter o tamanho do bit de ebcdic
            {
                if (msg_info.isVISA)
                {
                    len_bit = parseInt(len_bit, 16)
                }
                else
                {
                    len_bit = conv_ebc2a(len_bit)
                }
            }
            else if (msg_info.formato == kFMT_HEXA && !msg_info.isPOS)
            {
                if (bit_info.formato != kFMT_BCD)
                {
                    len_bit = hex2a(len_bit)
                }
            }

            len_bit = parseInt(len_bit, 10)
            var len_bit_aux = len_bit * 2

            // ====================================================================================

            var val = get_field_msg(len_bit_aux)

            // ====================================================================================

            var val_conv = ""
            if (msg_info.formato == kFMT_HEXA)
            {
                if (bit_info.formato != kFMT_BCD)
                {
                    if (!bit_info.nao_conv)
                    {
                        val_conv = mostrarColchete(hex2a(val))
                    }
                }
            }
            else if (msg_info.formato == kFMT_EBC)
            {
                if (bit_info.formato != kFMT_BCD)
                {
                    if (!bit_info.nao_conv)
                    {
                        val_conv = mostrarColchete(conv_ebc2a(val))
                    }
                }
            }
            val_conv = converterEspacoParaHtml(val_conv)

            // ====================================================================================

            msg_formatted += "DE " + padDE(bit) + " - " + "V" + padLEN(len_bit) + " - " + val + val_conv + get_break_line()
            // msg_clean += len_bit_orig + "-" + val + get_break_line()
            msg_clean += len_bit_orig + val + get_break_line()

            break

        default:
            alert("ERRO - O tipo " + bit_info.tipo + " do DE " + bit + " é inválido.")
            return -1
    }

    // ====================================================================================

    // verificar se o bit tem funcao especifica para quebrar

    if (bit_info.break_bit_func) // se tiver a funcao definida, chama
    {
        msg_break_bit = val
        if (bit_info.tipo == kFixo)
            fill_break_line()

        if (bit_info.paramArray)
        {
            return bit_info.break_bit_func(bit_info.paramArray)
        }
        else
        {
            return bit_info.break_bit_func()
        }
    }
    else if (bit_info.break_bit_func_inline) // funcao para quebrar que coloca o valor na mesma linha
    {
        msg_break_bit = val
        var ret = bit_info.break_bit_func_inline()
        fill_break_line()
        return ret
    }
    else
    {
        if (bit_info.tipo == kFixo)
            fill_break_line()
        // os outros tipos ainda tem o <br> no final da linha
    }

    return 0
}
