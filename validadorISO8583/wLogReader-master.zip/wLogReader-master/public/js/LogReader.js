// LogReader.js

function read_main()
{
    // var dt = "190126"
    // formatDate(dt, kDATA_YYMMDD, kDATA_DDMMYY)

    // return

    // limpando as variaveis
    msg = ""
    msg_formatted = ""
    msg_clean = ""
    msg_break_bit = ""
    msg_break_aux = ""

    // ====================================================================================================
    // VALIDAR AS ENTRADAS
    // ====================================================================================================

    // Radio Buttons
    if (!kHTML_RB_ACQ.checked && !kHTML_RB_ISS.checked && !kHTML_RB_EXT.checked && !kHTML_RB_OUT.checked && !kHTML_RB_BIT.checked)
    {
        alert("Favor selecionar uma opção.")
        kHTML_RB_ACQ.focus()
        return
    }

    // Radio Buttons - Acquirer
    if (kHTML_RB_ACQ.checked)
    {
        // Front-End
        if (kHTML_CBOX_FE.selectedIndex == -1)
        {
            alert("Favor selecionar o Front-End.")
            kHTML_CBOX_FE.focus()
            return
        }

        // Driver
        if ((kHTML_CBOX_DRIVER.selectedIndex == -1 && kHTML_CBOX_FE.value == kFE_WEB) || (kHTML_CBOX_DRIVER.selectedIndex == -1 && !kHTML_CB_SEM_HEADER.checked))
        {
            alert("Favor selecionar o Tipo.")
            kHTML_CBOX_DRIVER.focus()
            return
        }
    }

    // Radio Buttons - Issuer
    if (kHTML_RB_ISS.checked)
    {
        // Bandeira
        if (kHTML_CBOX_DRIVER.selectedIndex == -1)
        {
            alert("Favor selecionar a Bandeira.")
            kHTML_CBOX_DRIVER.focus()
            return
        }
    }

    // Radio Buttons - Extracao
    if (kHTML_RB_EXT.checked)
    {
        if (kHTML_CBOX_DRIVER.selectedIndex == -1)
        {
            alert("Favor selecionar a CAP.")
            kHTML_CBOX_DRIVER.focus()
            return
        }
    }

    // Radio Buttons - Outros
    // Radio Buttons - BIT
    if (kHTML_RB_OUT.checked || kHTML_RB_BIT.checked)
    {
        if (kHTML_CBOX_DRIVER.selectedIndex == -1)
        {
            alert("Favor selecionar uma opção.")
            kHTML_CBOX_DRIVER.focus()
            return
        }
    }

    // Text Area
    if (kHTML_TEXTAREA_MSG.value == "")
    {
        alert("Não há nenhuma mensagem ou registro.")
        kHTML_TEXTAREA_MSG.focus()
        return
    }

    // ====================================================================================================
    // COMECANDO A TRATAR A MENSAGEM
    // ====================================================================================================

    // mudar o nome da pagina para o que foi escolhido
    mudarNomePagina(false)

    // recuperar o texto digitado
    msg = kHTML_TEXTAREA_MSG.value

    // funcao principal para ler as mensagens
    if (kHTML_RB_ACQ.checked || kHTML_RB_ISS.checked) // eh iso
    {
        all_msg_reader()
    }
    else if (kHTML_RB_EXT.checked) // eh extracao
    {
        all_ext_reader()
    }
    else if (kHTML_RB_OUT.checked) // eh outros
    {
        all_out_reader()
    }
    else if (kHTML_RB_BIT.checked) // eh bit
    {
        all_bit_espec_reader()
    }
    else
    {
        alert("Opção selecionada inválida.")
        return
    }
}
