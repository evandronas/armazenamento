// multibndr_van_bit90_break.js

function break_bit90_multibndr_van()
{
    var obj = {
        formato: kFMT_EBC,
        campos: [
            {
                nome: kDE90_MSGTYPE,
                len: 4,
            },
            {
                nome: kDE90_STAN,
                len: 6,
            },
            {
                nome: kDE90_DATA,
                len: 4,
            },
            {
                nome: kDE90_HORA,
                len: 6,
            },
            {
                nome: kDE90_IDENT_ACQ,
                len: 11,
            },
            {
                nome: kDE90_RES,
                len: 11,
            }
        ],
        space: 44,
    }
    gen_bit90_break2(obj)
}
