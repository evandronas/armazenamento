// multibndr_van_bit_info.js

function get_bit_multibndr_van(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 48:
            info.break_bit_func = break_bit48_multibndr_van
            break

        case 52:
            delete info.nao_conv
            break

        case 55:
            info.break_bit_func = genBreakBit55Ebc
            break

        case 90:
            info.break_bit_func = break_bit90_multibndr_van
            break
    }

    return info
}
