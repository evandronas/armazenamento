// multibndr_van_bit48_break.js

function break_bit48_multibndr_van()
{
    var qtde_tab = 16
    var space = 32

    var len
    var valor_orig
    var infodisp

    //
    len = 3
    valor_orig = get_field_break_bit(len * 2)
    infodisp = { display: true, qtdeTab: qtde_tab, nomeCampo: "Identificação da Transação" + mostrarParentese(len), nomeCampoSpace: space, valorOrig: valor_orig, convEbc: true, descFunc: break_bit48_multibndr_van_ident_tran }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_bit(len * 2)
    infodisp = { display: true, qtdeTab: qtde_tab, nomeCampo: "Dados do Estabelecimento" + mostrarParentese(len), nomeCampoSpace: space, valorOrig: valor_orig, convEbc: true, descFunc: break_bit48_multibndr_van_dados_estab }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    infodisp = { display: true, qtdeTab: qtde_tab, nomeCampo: "Opera em Dólar" + mostrarParentese(len), nomeCampoSpace: space, valorOrig: valor_orig, convEbc: true, descFunc: break_bit48_multibndr_van_opera_dolar }
    genDisplayInfo(infodisp)

    //
    len = 5
    valor_orig = get_field_break_bit(len * 2)
    infodisp = { display: true, qtdeTab: qtde_tab, nomeCampo: "Ramo de Atividade" + mostrarParentese(len), nomeCampoSpace: space, valorOrig: valor_orig, convEbc: true }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    infodisp = { display: true, qtdeTab: qtde_tab, nomeCampo: "Modo de Operação" + mostrarParentese(len), nomeCampoSpace: space, valorOrig: valor_orig, convEbc: true, descFunc: break_bit48_multibndr_van_modo_operacao }
    genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_bit(len * 2)
    infodisp = { display: true, qtdeTab: qtde_tab, nomeCampo: "CVC2" + mostrarParentese(len), nomeCampoSpace: space, valorOrig: valor_orig, convEbc: true }
    genDisplayInfo(infodisp)
}

function break_bit48_multibndr_van_ident_tran(valor)
{
    var desc

    switch (valor)
    {
        case "005":
            desc = "Consulta AVS"
            break

        case "020":
            desc = "Pré-Autorização"
            break

        case "101":
            desc = "Autorização de Crédito à vista"
            break

        case "102":
            desc = "Autorização de Crédito parcelado com juros"
            break

        case "103":
            desc = "Autorização de Crédito parcelado sem juros"
            break

        case "105":
            desc = "Autorização IATA à vista"
            break

        case "107":
            desc = "Autorização IATA parcelada sem juros"
            break

        case "111":
            desc = "Autorização de Crédito à vista Autenticada pelo Emissor e Bandeira (Komerci)"
            break

        case "112":
            desc = "Autorização de Crédito parcelado com juros Autenticada pelo Emissor e Bandeira (Komerci)"
            break

        case "113":
            desc = "Autorização de Crédito parcelado sem juros Autenticada pelo Emissor e Bandeira (Komerci)"
            break

        case "115":
            desc = "Autorização IATA à vista Autenticada pelo Emissor e Bandeira (Komerci)"
            break

        case "117":
            desc = "Autorização IATA parcelada sem juros Autenticada pelo Emissor e Bandeira (Komerci)"
            break
    }

    return desc
}

function break_bit48_multibndr_van_dados_estab(valor)
{
    var desc

    switch (valor)
    {
        case "84":
        case "85":
        case "86":
            desc = "By Phone"
            break

        case "91":
            desc = "POS"
            break

        case "93":
            desc = "PDV Dedicado/Discado"
            break
    }

    return desc
}

function break_bit48_multibndr_van_opera_dolar(valor)
{
    var desc

    switch (valor)
    {
        case " ":
            desc = "Não"
            break

        case "1":
            desc = "Sim"
            break
    }

    return desc
}

function break_bit48_multibndr_van_modo_operacao(valor)
{
    var desc

    switch (valor)
    {
        case "0":
            desc = "Produção"
            break

        case "1":
            desc = "Demonstração"
            break

        case "2":
            desc = "Piloto"
            break
    }

    return desc
}
