// hv_bit62_break.js

function break_bit62_hv()
{
    var len
    var tamanhoSubcampo

    len = 3
    tamanhoSubcampo = get_field_break_bit(len*2)
    subcampo = get_field_break_bit(hex2a(tamanhoSubcampo)*2)

    subcampo = hex2a(subcampo)

    var tipoSubcampo = subcampo.substr(0, 2)
    subcampo = subcampo.substring(2)

    if(tipoSubcampo == "03")
        hv_bit62_subcampo03_break(subcampo)

}

function hv_bit62_subcampo03_break(subcampo03)
{
    var info = hv_bit62_subfield03_layout()

    var infodisp
    var valor
    var pos = 1

    for (var i = 0; i < info.array_fields.length; i++)
    {
        var field = info.array_fields[i]

        valor = subcampo03.substr(0, field.len)
        subcampo03 = subcampo03.substring(field.len)

        var desc = undefined
        if (field.descFunc)
        {
            desc = field.descFunc(valor)
        }

        infodisp = {
            display: true,
            nomeCampoSpace: 35,
            nomeCampo: field.nome,
            valorFirst: padLEN(field.len) + " - " + padLEN(pos) + " - ",
            valorOrig: valor,
            valorOrigColchete: true,
            desc: desc,
            formatMoney: field.formatMoney,
            qtdeTabL1: true,
        }
        genDisplayInfo(infodisp)

        pos += field.len
    }
}