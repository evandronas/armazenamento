//hv_bit62_subfield03_layout.js

/*
Propriedades

nome                    [string]    nome do campo
len                     [num]       tamanho do campo
descFunc                [string]    nome da funcao para pegar a descricao. A funcao deve retornar uma string
formatMoney             [bool]      formatar o valor com a moeda
*/

function hv_bit62_subfield03_layout()
{
    var info = {
        array_fields: [
            { nome: "Tipo de pagamento", len: 1 },
            { nome: "Codigo de barras da conta", len: 44 },
            { nome: "Vencimento", len: 8 },
            { nome: "Modo de entrada codigo de barras", len: 1 },
            { nome: "Valor dos descontos (centavos)", len: 12 },
            { nome: "Valor dos acrecimos (centavos)", len: 12 },
            { nome: "CPF Pagador", len: 14 },
            { nome: "Data Nascimento Pagador", len: 8 },
        ],
    }

    return info
}
