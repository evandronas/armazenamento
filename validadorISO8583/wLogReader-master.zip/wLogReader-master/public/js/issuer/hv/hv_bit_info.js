// hv_bit_info.js

function get_bit_hv(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 3:
            info.formato = kFMT_HEXA
            break

        case 4:
            info.formato = kFMT_HEXA
            break

        case 7:
            info.formato = kFMT_HEXA
            break

        case 11:
            info.formato = kFMT_HEXA
            break

        case 12:
            info.formato = kFMT_HEXA
            break

        case 13:
            info.formato = kFMT_HEXA
            break

        case 15:
            info.formato = kFMT_HEXA
            break

        case 32:
            info.formato = kFMT_HEXA
            break

        case 41:
            info.formato = kFMT_HEXA
            break

        case 42:
            info.formato = kFMT_HEXA
            break

        case 62:
            info.formato = kFMT_HEXA
            info.break_bit_func = break_bit62_hv
            break

        case 120:
            info.formato = kFMT_HEXA
            break
    }

    return info
}
