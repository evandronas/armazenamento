// visa_break.js

// DE 22

function break_bit22_visa()
{
    var space = 35

    var len
    var valor
    var infodisp

    //
    len = 2
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "PAN and Date Entry Mode (1-2) (2)",
        nomeCampoSpace: space,
        valorOrig: valor,
        descFunc: break_bit22_visa_pan_entrymode,
    }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "PIN Entry Capability (3-3) (1)",
        nomeCampoSpace: space,
        valorOrig: valor,
        descFunc: break_bit22_visa_pin,
    }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Unused (4-4) (1)",
        nomeCampoSpace: space,
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)
}

// DE 43

function break_bit43_visa()
{
    var space = 22

    var len
    var valor
    // var valor_conv
    var infodisp

    //
    len = 25
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Nome Estabelecimento",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 13
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Cidade",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "País",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}

// DE 44

function break_bit44_visa()
{
    var space = 17

    var len
    var valor
    var infodisp

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.1",
        nomeCampoSpace: space,
        nome: "Response Source/Reason Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.2",
        nomeCampoSpace: space,
        nome: "Address Verification Result Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.3 Reserved",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.4 Reserved",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.5",
        nomeCampoSpace: space,
        nome: "CVV/iCVV Results Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.6",
        nomeCampoSpace: space,
        nome: "PACM Diversion-Level Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.7",
        nomeCampoSpace: space,
        nome: "PACM Diversion Reason Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.8",
        nomeCampoSpace: space,
        nome: "Card Authentication Results Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.9 Reserved",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.10",
        nomeCampoSpace: space,
        nome: "CVV2 Result Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.11",
        nomeCampoSpace: space,
        nome: "Original Response Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.12",
        nomeCampoSpace: space,
        nome: "Check Settlement Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.13",
        nomeCampoSpace: space,
        nome: "CAVV Results Code",
        valorOrig: valor,
        convEbc: true,
        descFunc: get_info_bit44_visa_13,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.14",
        nomeCampoSpace: space,
        nome: "Response Reason Code",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 4
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.15",
        nomeCampoSpace: space,
        nome: "Primary Account Number, Last Four Digits for Receipt",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 4
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE44.16",
        nomeCampoSpace: space,
        nome: "CVM Requirement for PIN-less",
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}

// DE 48

function break_bit48_visa()
{
    var len = 3
    var aux = get_field_break_bit(len * 2)
    var aux_conv = conv_ebc2a(aux)

    if (aux_conv == "*73")
    {
        break_bit48_visa_dadosPcj()
    }

    return 0
}

function break_bit48_visa_dadosPcj()
{
    var space = 20

    var len
    var valor
    var infodisp

    //
    len = 3
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "TBD",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "TBD",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "TBD",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "TBD",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "TBD",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "TBD",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 8
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Valor Total",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
        formatMoney: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 6
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "TDB",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Quantidade Parcela",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 5
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Encargo Mensal",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
        formatPct: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CET Anual",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
        formatPct: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Valor da Parcela",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
        formatMoney: true,
    }
    genDisplayInfo(infodisp)
}

// DE 54

function break_bit54_visa()
{
    var info
    var space = 14

    var account_type = get_field_break_bit(2 * 2)
    info = {
        display: true,
        qtdeTabL1: true,
        // qtdeTab: 16,
        nomeCampo: "Account Type",
        nomeCampoSpace: space,
        valorOrig: account_type,
        convEbc: true,
    }
    genDisplayInfo(info)

    var amount_type = get_field_break_bit(2 * 2)
    info = {
        display: true,
        qtdeTabL1: true,
        // qtdeTab: 16,
        nomeCampo: "Amount Type",
        nomeCampoSpace: space,
        valorOrig: amount_type,
        convEbc: true,
    }
    genDisplayInfo(info)

    var currency_code = get_field_break_bit(3 * 2)
    info = {
        display: true,
        qtdeTabL1: true,
        // qtdeTab: 16,
        nomeCampo: "Currency Code",
        nomeCampoSpace: space,
        valorOrig: currency_code,
        convEbc: true,
    }
    genDisplayInfo(info)

    var amount_sign = get_field_break_bit(1 * 2)
    info = {
        display: true,
        qtdeTabL1: true,
        // qtdeTab: 16,
        nomeCampo: "Amount Sign",
        nomeCampoSpace: space,
        valorOrig: amount_sign,
        convEbc: true,
    }
    genDisplayInfo(info)

    var amount = get_field_break_bit(12 * 2)
    info = {
        display: true,
        qtdeTabL1: true,
        // qtdeTab: 16,
        nomeCampo: "Amount (Saldo)",
        nomeCampoSpace: space,
        valorOrig: amount,
        convEbc: true,
        formatMoney: true,
    }
    genDisplayInfo(info)
}

// DE 55

function break_bit55_visa()
{
    // console.log("break_bit55_visa() - msg_break_bit [%s]", msg_break_bit)

    // Dataset ID
    var dataset_id = get_field_break_bit(1 * 2)
    // console.log("break_bit55_visa() - dataset_id [%s]", dataset_id)

    // Dataset length
    var dataset_len_orig = get_field_break_bit(2 * 2)
    var dataset_len_conv = parseInt(dataset_len_orig, 16)
    // console.log("break_bit55_visa() - dataset_len_orig [%s]", dataset_len_orig)
    // console.log("break_bit55_visa() - dataset_len_conv [%s]", dataset_len_conv)

    // Dataset value
    var dataset_value = get_field_break_bit(dataset_len_conv * 2)
    // console.log("break_bit55_visa() - dataset_value [%s]", dataset_value)

    var infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Dataset ID " + dataset_id,
        // nomeCampoSpace: space,
        valorConv: dataset_value,
        lenV: dataset_len_conv,
        padLen: true,
    }
    genDisplayInfo(infodisp)

    // voltar conteudo do DE55 para msg_break_bit, para a funcao genBreakBit55Puro conseguir quebrar
    // console.log("break_bit55_visa() - msg_break_bit antes [%s]", msg_break_bit)
    msg_break_bit = dataset_value
    // console.log("break_bit55_visa() - msg_break_bit depois atribuicao [%s]", msg_break_bit)
    genBreakBit55Puro(39)
    // console.log("break_bit55_visa() - msg_break_bit depois break [%s]", msg_break_bit)
}

// DE 56

function break_bit56_visa()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTagDiff: 2,
        ignoreTagConv: true,
        lenLengthFormato: kFMT_HEXA_BASE16,
        lenLengthDiff: 4,
        infoFunc: break_bit56_visa_info,
        nomeCampo: "Dataset ID",
        qtdeTab: 16,
        padLen: true,
    }
    genTLVBreak(tlvinfo)

    return 0
}

function break_bit56_visa_subcampo01()
{
    msg_break_bit = msg_break_aux

    var tlvinfo = {
        formato: kFMT_EBC,
        lenTagDiff: 2,
        ignoreTagConv: true,
        lenLengthFormato: kFMT_HEXA_BASE16,
        lenLengthDiff: 2,
        infoFunc: break_bit56_visa_subcampo01_info,
        nomeCampo: "Tag",
        qtdeTab: 39,
        padLen: true,
    }
    genTLVBreak(tlvinfo)

    return 0
}

// DE 60

function break_bit60_visa()
{
    var space = 9

    var len
    var valor
    var infodisp

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.1",
        nomeCampoSpace: space,
        nome: "Terminal Type",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.2",
        nomeCampoSpace: space,
        nome: "Terminal Entry Capability",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.3",
        nomeCampoSpace: space,
        nome: "Chip Condition Code",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.4",
        nomeCampoSpace: space,
        nome: "Special Condition Indicator",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 2
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.5",
        nomeCampoSpace: space,
        nome: "Merchant Group Indicator",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.6",
        nomeCampoSpace: space,
        nome: "Chip Transaction Indicator",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.7",
        nomeCampoSpace: space,
        nome: "Chip Card Authentication Reliability Indicator",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 2
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.8",
        nomeCampoSpace: space,
        nome: "Mail/Phone/Electronic Commerce and Payment Indicator",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.9",
        nomeCampoSpace: space,
        nome: "Cardholder ID Method Indicator",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 0)
        return 0

    //
    len = 1
    valor = get_field_break_bit(len)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "DE60.10",
        nomeCampoSpace: space,
        nome: "Additional Authorization Indicators",
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)
}

// DE 90

function break_bit90_visa()
{
    var obj = {
        formato: kFMT_BCD,
        campos: [
            {
                nome: kDE90_MSGTYPE,
                len: 2,
            },
            {
                nome: kDE90_STAN,
                len: 3,
            },
            {
                nome: kDE90_DATA,
                len: 2,
            },
            {
                nome: kDE90_HORA,
                len: 3,
            },
            {
                nome: kDE90_IDENT_ACQ,
                len: 6,
            },
            {
                nome: "Forwarding Institution",
                len: 6,
            }
        ],
        space: 43,
    }
    gen_bit90_break2(obj)
}

// DE 104

function break_bit104_visa()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTagDiff: 2,
        ignoreTagConv: true,
        lenLengthFormato: kFMT_HEXA_BASE16,
        lenLengthDiff: 4,
        infoFunc: break_bit104_visa_info,
        nomeCampo: "Dataset ID",
        qtdeTab: 16,
        padLen: true,
    }
    genTLVBreak(tlvinfo)

    return 0
}

function break_bit104_visa_subcampo5d()
{
    var qtde_tab = 39
    var info

    while(msg_break_aux.length != 0)
    {
        // tag
        var tag_id_orig = get_field_break_aux(2)
        // console.log("tag [%s]", tag_id_orig)

        // tamanho
        var tag_len_orig = get_field_break_aux(2)
        var tag_len_conv = parseInt(tag_len_orig, 10)
        // console.log("len orig [%s] len conv [%s]", tag_len_orig, tag_len_conv)

        // conteudo
        var tag_valor_orig = get_field_break_aux(tag_len_conv * 2)
        // console.log("conteudo [%s]", tag_valor_orig)

        var tag_info = break_bit104_visa_subcampo5d_info(tag_id_orig)

        //

        info = {
            display: true,
            qtdeTab: qtde_tab,
            nomeCampo: "TAG " + tag_id_orig,
            valorOrig: tag_valor_orig,
            lenV: tag_len_orig,
        }
        info["nome"] = tag_info["nome"]
        info["formatMoney"] = tag_info["formatMoney"]
        info["formatPct"] = tag_info["formatPct"]
        info["convEbc"] = tag_info["convEbc"]

        genDisplayInfo(info)
    }
}

function break_bit104_visa_subcampo56()
{
    var qtde_tab = 39
    var info

    while(msg_break_aux.length != 0)
    {
        // tag
        var tag_id_orig = get_field_break_aux(2)
        // console.log("tag [%s]", tag_id_orig)

        // tamanho
        var tag_len_orig = get_field_break_aux(2)
        var tag_len_conv = parseInt(tag_len_orig, 16)
        // console.log("len orig [%s] len conv [%s]", tag_len_orig, tag_len_conv)

        // conteudo
        var tag_valor_orig = get_field_break_aux(tag_len_conv * 2)
        // console.log("conteudo [%s]", tag_valor_orig)

        var tag_info = break_bit104_visa_subcampo56_info(tag_id_orig)

        //

        info = {
            display: true,
            qtdeTab: qtde_tab,
            nomeCampo: "TAG " + tag_id_orig,
            valorOrig: tag_valor_orig,
            lenV: tag_len_conv,
            convEbc: true,
        }
        info["nome"] = tag_info["nome"]
        info["formatMoney"] = tag_info["formatMoney"]
        info["formatPct"] = tag_info["formatPct"]
        // info["convEbc"] = tag_info["convEbc"]

        genDisplayInfo(info)




    }
}

function break_bit104_visa_subcampo57()
{
    var qtde_tab = 39
    var info

    while(msg_break_aux.length != 0)
    {
        // tag
        var tag_id_orig = get_field_break_aux(2)
        // console.log("tag [%s]", tag_id_orig)

        // tamanho
        var tag_len_orig = get_field_break_aux(2)
        var tag_len_conv = parseInt(tag_len_orig, 16)
        // console.log("len orig [%s] len conv [%s]", tag_len_orig, tag_len_conv)

        // conteudo
        var tag_valor_orig = get_field_break_aux(tag_len_conv * 2)
        // console.log("conteudo [%s]", tag_valor_orig)

        var tag_info = break_bit104_visa_subcampo57_info(tag_id_orig)

        //

        info = {
            display: true,
            qtdeTab: qtde_tab,
            nomeCampo: "TAG " + tag_id_orig,
            valorOrig: tag_valor_orig,
            lenV: tag_len_conv,
            convEbc: true,
        }
        info["nome"] = tag_info["nome"]
        info["formatMoney"] = tag_info["formatMoney"]
        info["formatPct"] = tag_info["formatPct"]
        // info["convEbc"] = tag_info["convEbc"]

        genDisplayInfo(info)
    }
}
function break_bit104_visa_subcampo63()
{
    var qtde_tab = 39
    var info

    while(msg_break_aux.length != 0)
    {
        // tag
        var tag_id_orig = get_field_break_aux(2)
        // console.log("tag [%s]", tag_id_orig)

        // tamanho
        var tag_len_orig = get_field_break_aux(2)
        var tag_len_conv = parseInt(tag_len_orig, 16)
        // console.log("len orig [%s] len conv [%s]", tag_len_orig, tag_len_conv)

        // conteudo
        var tag_valor_orig = get_field_break_aux(tag_len_conv * 2)
        // console.log("conteudo [%s]", tag_valor_orig)

        var tag_info = break_bit104_visa_subcampo63_info(tag_id_orig)

        //

        info = {
            display: true,
            qtdeTab: qtde_tab,
            nomeCampo: "TAG " + tag_id_orig,
            valorOrig: tag_valor_orig,
            lenV: tag_len_conv,
            convEbc: true,
        }
        info["nome"] = tag_info["nome"]
        info["formatMoney"] = tag_info["formatMoney"]
        info["formatPct"] = tag_info["formatPct"]
        // info["convEbc"] = tag_info["convEbc"]

        genDisplayInfo(info)
    }
}
// DE 117

function break_bit117_visa()
{
    // console.log("break_bit117_visa() - msg_break_bit [%s]", msg_break_bit)
    var info
    var space = 14

    var country_code_orig = get_field_break_bit(3 * 2) // 3 primeiras posicoes
    info = {
        display: true,
        qtdeTabL1: true,
        // qtdeTab: 16,
        nomeCampo: "Country Code",
        nomeCampoSpace: space,
        valorOrig: country_code_orig,
        convEbc: true,
    }
    genDisplayInfo(info)

    var cnpj_orig = get_field_break_bit() // a partir da 4 posicao
    info = {
        display: true,
        qtdeTab: 16,
        nomeCampo: "CNPJ",
        nomeCampoSpace: space,
        valorOrig: cnpj_orig,
        convEbc: true,
    }
    genDisplayInfo(info)
}

// DE 123

function break_bit123_visa()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTagDiff: 2,
        ignoreTagConv: true,
        lenLengthFormato: kFMT_HEXA_BASE16,
        lenLengthDiff: 4,
        infoFunc: break_bit123_visa_info,
        nomeCampo: "Dataset ID",
        qtdeTab: 16,
        padLen: true,
    }
    genTLVBreak(tlvinfo)

    return 0
}

function break_bit123_visa_subcampo68()
{
    msg_break_bit = msg_break_aux

    var tlvinfo = {
        formato: kFMT_EBC,
        lenTagDiff: 2,
        ignoreTagConv: true,
        lenLengthFormato: kFMT_HEXA_BASE16,
        lenLengthDiff: 2,
        infoFunc: break_bit123_visa_subcampo68_info,
        nomeCampo: "Tag",
        qtdeTab: 39,
        padLen: true,
    }
    genTLVBreak(tlvinfo)

    return 0
}

// DE 126

function break_bit126_visa_field10()
{
    // console.log("break_bit126_visa_field10()")
    // console.log(msg_break_aux)

    var space = 20
    var qtde_tab = 37

    var len
    var valor
    var infodisp

    //
    len = 1
    valor = get_field_break_aux(len * 2)
    infodisp = {
        qtdeTab: qtde_tab,
        nomeCampo: "Presence Indicator",
        nomeCampoSpace: space,
        valorOrig: valor,
        descFunc: break_bit126_visa_field10_presenceIndicator_desc,
        convEbc: true,
    }
    msg_formatted_visa += genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_aux(len * 2)
    infodisp = {
        qtdeTab: qtde_tab,
        nomeCampo: "Response Type",
        nomeCampoSpace: space,
        valorOrig: valor,
        descFunc: break_bit126_visa_field10_responseType_desc,
        convEbc: true,
    }
    msg_formatted_visa += genDisplayInfo(infodisp)

    //
    len = 4
    valor = get_field_break_aux(len * 2)
    infodisp = {
        qtdeTab: qtde_tab,
        nomeCampo: "CVV2 Value",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    msg_formatted_visa += genDisplayInfo(infodisp)
}
