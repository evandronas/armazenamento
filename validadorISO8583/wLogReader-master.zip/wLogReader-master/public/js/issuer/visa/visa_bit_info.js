// visa_bit_info.js

function get_bit_visa(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 2:
            info.formato = kFMT_BCD
            break

        case 3:
            info.formato = kFMT_BCD
            break

        case 4:
            info.formato = kFMT_BCD
            break

        case 7:
            info.formato = kFMT_BCD
            break

        case 11:
            info.formato = kFMT_BCD
            break

        case 13:
            info.formato = kFMT_BCD
            break

        case 14:
            info.formato = kFMT_BCD
            break

        case 15:
            info.len = 2
            // info.nao_conv = true
            break

        case 18:
            info.formato = kFMT_BCD
            break

        case 19:
            info.len = 4
            info.formato = kFMT_BCD
            break

        case 22:
            info.len = 4
            info.formato = kFMT_BCD
            info.break_bit_func = break_bit22_visa
            break

        case 23:
            info.len = 4
            info.formato = kFMT_BCD
            break

        case 25:
            info.formato = kFMT_BCD
            break

        case 28:
            info.len = 9
            break

        case 32:
            info.formato = kFMT_BCD
            break

        case 35:
            info.formato = kFMT_BCD
            break

        case 43:
            info.break_bit_func = break_bit43_visa
            break

        case 44:
            info.break_bit_func = break_bit44_visa
            break

        case 48:
            info.break_bit_func = break_bit48_visa
            break

        case 49:
            info.len = 4
            info.formato = kFMT_BCD
            break

        case 52:
            info.formato = kFMT_BIN
            break

        case 53:
            info.formato = kFMT_BCD
            break

        case 54:
            info.break_bit_func = break_bit54_visa
            break

        case 55:
            info.nao_conv = true
            info.break_bit_func = break_bit55_visa
            break

        case 56:
            info.nao_conv = true
            info.break_bit_func = break_bit56_visa
            break

        case 60:
            info.formato = kFMT_BCD
            info.break_bit_func = break_bit60_visa
            break

        case 62:
            info.formato = kFMT_BCD
            info.break_bit_func = break_bit62_visa
            break

        case 63:
            info.formato = kFMT_BCD
            info.break_bit_func = break_bit63_visa
            break

        case 90:
            info.formato = kFMT_BCD
            // info.nao_conv = true
            info.break_bit_func = break_bit90_visa
            break

        case 104:
            info.formato = kFMT_BCD
            info.break_bit_func = break_bit104_visa
            break

        case 117:
            info.break_bit_func = break_bit117_visa
            break

        case 123:
            info.nao_conv = true
            info.break_bit_func = break_bit123_visa
            break

        case 126:
            info.nao_conv = true
            info.break_bit_func = break_bit126_visa
            break
    }

    return info
}
