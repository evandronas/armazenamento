// visa_get_header.js

function get_header_visa(msg_info)
{
    var info
    var header_len = msg_info.header_len
    var reject = false

    var header = get_field_msg(header_len)
    var aux_header = header.substr(8, 2)
    var aux_header_int = parseInt(aux_header, 16)

    // console.log("get_header_visa - header [%s] aux_header [%s] aux_header_int [%s]", header, aux_header, aux_header_int)

    var reject_error
    if (aux_header_int == 26)
    {
        reject = true
        header += get_field_msg(header_len)
        reject_error = header.substr(56, 4)
    }

    if (header)
    {
        var header_formatted = ""
        header_formatted += "Header - " + header + "<br>"

        if (reject)
        {
            var reject_error_desc = get_header_visa_reject_error_desc(reject_error)
            header_formatted += "Reject Error: " + reject_error

            if (reject_error_desc)
            {
                header_formatted += " = " + reject_error_desc
            }

            header_formatted += "<br>"
        }

        info = {
            ret: true,
            header: header_formatted,
            header_clean: header,
        }
    }

    return info
}

function get_header_visa_reject_error_desc(value)
{
    var desc

    switch(value)
    {
        case "0024":
            desc = "Invalid length (track data too long)"
            break

        case "0027":
            desc = "Invalid track data"
            break

        case "0106":
            desc = "Invalid value"
            break

        case "0142":
            desc = "Magnetic stripe data missing when field 22 = 90 or 91"
            break

        case "0291":
            desc = "Field missing"
            break

        case "0521":
            desc = "Track 2 account number is missing or does not agree with field 2"
            break
    }

    return desc
}
