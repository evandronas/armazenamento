// visa_bit_break_bitmapped.js

function break_bit62_visa()
{
    break_bit_visa_bitmapped(62)
}

function break_bit63_visa()
{
    break_bit_visa_bitmapped(63, 3)
}

function break_bit126_visa()
{
    break_bit_visa_bitmapped(126)
}
