// visa_info.js

// DE 22

function break_bit22_visa_pan_entrymode(valor)
{
    var desc

    switch (valor)
    {
        case "00":
            desc = "Unknown or terminal not used"
            break

        case "01":
            desc = "Manual key entry"
            break

        case "02":
            desc = "Magnetic stripe read"
            break

        case "03":
            desc = "Optical code"
            break

        case "04":
            desc = "Reserved for future use"
            break

        case "05":
            desc = "Integrated circuit card read"
            break

        case "06":
            desc = "Reserved for future use"
            break

        case "07":
            desc = "Contactless payment using VSDC chip rules"
            break

        case "10":
            desc = "Credential on file"
            break

        case "90":
            desc = "Magnetic stripe read and exact content of Track 1 or Track 2 included"
            break

        case "91":
            desc = "Contactless payment using magnetic stripe data rules"
            break

        case "95":
            desc = "Integrated circuit card"
            break

        case "96":
            desc = "Stored value from pre-registered checkout service"
            break
    }

    return desc
}

function break_bit22_visa_pin(valor)
{
    var desc

    switch (valor)
    {
        case "0":
            desc = "Unknown"
            break

        case "1":
            desc = "Terminal can accept PINs"
            break

        case "2":
            desc = "Terminal cannot accept PINs"
            break

        case "8":
            desc = "Terminal PIN pad down"
            break

        case "9":
            desc = "Reserved for future use"
            break
    }

    return desc
}

// DE 44

function get_info_bit44_visa_13(valor)
{
    var nome

    switch (valor.toUpperCase())
    {
        case " ":
            nome = "CAVV not present"
            break

        case "0":
            nome = "CAVV authentication results invalid"
            break

        case "1":
            nome = "CAVV failed validation—authentication"
            break

        case "B":
            nome = "CAVV passed validation—information only, no liability shift"
            break
    }

    return nome
}

// DE 56

function break_bit56_visa_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "01":
            info = {
                nome: "Account Data",
                nao_conv: true,
                breakFunc: break_bit56_visa_subcampo01,
            }
            break
    }

    return info
}

function break_bit56_visa_subcampo01_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "01":
            info = {
                nome: "Payment Account Reference",
            }
            break
    }

    return info
}

// DE 62

function get_info_bit62_visa(subfield)
{
    var info

    switch (subfield)
    {
        case 1:
            info = {
                nome: "Authorization Characteristics Indicator",
                tipo: kFixo,
                len: 1,
                formato: kFMT_EBC,
            }
            break

        case 2:
            info = {
                nome: "Transaction Identifier",
                tipo: kFixo,
                len: 8,
                formato: kFMT_BCD,
            }
            break

        case 3:
            info = {
                nome: "Validation Code",
                tipo: kFixo,
                len: 4,
                formato: kFMT_EBC,
            }
            break

        case 4:
            info = {
                nome: "Market-Specific Data Identifier",
                tipo: kFixo,
                len: 1,
                formato: kFMT_EBC,
            }
            break

        case 5:
            info = {
                nome: "Duration",
                tipo: kFixo,
                len: 1,
                formato: kFMT_BCD,
            }
            break

        case 6:
            info = {
                nome: "Prestigious Property Indicator",
                tipo: kFixo,
                len: 1,
                formato: kFMT_EBC,
            }
            break

        case 20:
            info = {
                nome: "Merchant Verification Value",
                tipo: kFixo,
                len: 5,
                formato: kFMT_HEXA,
            }
            break
    }

    return info
}

// DE 63

function get_info_bit63_visa(subfield)
{
    var info

    switch (subfield)
    {
        case 1:
            info = {
                nome: "Network Identification Code",
                tipo: kFixo,
                len: 2,
                formato: kFMT_BCD,
            }
            break

        case 2:
            info = {
                nome: "Time (Preauth Time Limit)",
                tipo: kFixo,
                len: 2,
                formato: kFMT_BCD,
            }
            break

        case 3:
            info = {
                nome: "Message Reason Code",
                tipo: kFixo,
                len: 2,
                formato: kFMT_BCD,
            }
            break

        case 4:
            info = {
                nome: "STIP/Switch Reason Code",
                tipo: kFixo,
                len: 2,
                formato: kFMT_BCD,
            }
            break
    }

    return info
}

// DE 104

function break_bit104_visa_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "5D":
            info = {
                nome: "Dados Crediário",
                nao_conv: true,
                breakFunc: break_bit104_visa_subcampo5d,
                // breakTLV: true,
            }
            break

        case "56":
            info = {
                nome: "Payment Facilitator Data",
                breakFunc: break_bit104_visa_subcampo56,
            }
            break

        case "57":
            info = {
                nome: "Business Application Identifier",
                breakFunc: break_bit104_visa_subcampo57,
            }
            break

        case "63":
            info = {
                nome: "SDWO (CPF/CNPJ)",
                breakFunc: break_bit104_visa_subcampo63,
            }
            break    
        }

    return info
}

function break_bit104_visa_subcampo5d_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "01":
            info = {
                nome: "Valor Total",
                formatMoney: true,
            }
            break

        case "02":
            info = {
                nome: "Moeda",
            }
            break

        case "03":
            info = {
                nome: "Quantidade de Parcelas",
            }
            break

        case "04":
            info = {
                nome: "Valor da Parcela",
                formatMoney: true,
            }
            break

        case "05":
            break

        case "06":
            info = {
                nome: "Frequência das Parcelas",
                convEbc: true,
            }
            break

        case "07":
            info = {
                nome: "Data da Primeira Parcela",
            }
            break

        case "08":
            info = {
                nome: "Valor Total Financiado",
                formatMoney: true,
            }
            break

        case "09":
            info = {
                nome: "Porcentagem do Valor Solicitado",
                formatPct: true,
            }
            break

        case "0A":
            info = {
                nome: "Despesas Totais",
                formatMoney: true,
            }
            break

        case "0B":
            info = {
                nome: "Porcentagem de Despesas Totais",
                formatPct: true,
            }
            break

        case "0C":
            info = {
                nome: "Total de Tarifas",
                formatMoney: true,
            }
            break

        case "0D":
            info = {
                nome: "Porcentagem de Tarifas",
                formatPct: true,
            }
            break

        case "0E":
            info = {
                nome: "Total de Tributos",
                formatMoney: true,
            }
            break

        case "0F":
            info = {
                nome: "Porcentagem de Tributos",
                formatPct: true,
            }
            break

        case "10":
            info = {
                nome: "Total de Seguro",
                formatMoney: true,
            }
            break

        case "11":
            info = {
                nome: "Porcentagem de Seguro",
                formatPct: true,
            }
            break

        case "12":
            info = {
                nome: "Total de Outros Custos",
                formatMoney: true,
            }
            break

        case "13":
            info = {
                nome: "Porcentagem de Outros Custos",
                formatPct: true,
            }
            break

        case "14":
            info = {
                nome: "Taxa de Juros Mensal",
                formatPct: true,
            }
            break

        case "15":
            info = {
                nome: "Taxa de Juros Anual",
                formatPct: true,
            }
            break

        case "16":
            info = {
                nome: "CET Anual",
                formatPct: true,
            }
            break

        case "17":
            info = {
                nome: "Tipo de Parcelado",
            }
            break
    }

    return info
}

function break_bit104_visa_subcampo56_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "01":
            info = {
                nome: "Payment Facilitator ID",
            }
            break

        case "02":
            info = {
                nome: "Sub-Merchant ID",
            }
            break

        case "03":
            info = {
                nome: "Independent Sales Organization ID",
            }
            break
    }

    return info
}
function break_bit104_visa_subcampo57_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "01":
            info = {
                nome: "BAI",
            }
            break
    }

    return info
}
function break_bit104_visa_subcampo63_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "05":
            info = {
                nome: "CNPJ",
            }
            break

        case "06":
            info = {
                nome: "CPF",
            }
            break
    }

    return info
}

// DE 123

function break_bit123_visa_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "68":
            info = {
                nome: "Token Data",
                nao_conv: true,
                breakFunc: break_bit123_visa_subcampo68,
            }
            break
    }

    return info
}

function break_bit123_visa_subcampo68_info(valor)
{
    var info = {}

    valor = valor.toUpperCase()

    switch(valor)
    {
        case "02":
            info = {
                nome: "Token Assurance Level",
            }
            break

        case "03":
            info = {
                nome: "Token Requestor ID",
            }
            break

        case "04":
            info = {
                nome: "Primary Account Number, Account Range",
            }
            break
    }

    return info
}

// DE 126

function get_info_bit126_visa(subfield)
{
    var info

    switch (subfield)
    {
        case 8:
            info = {
                nome: "Transaction ID (XID)",
                tipo: kFixo,
                len: 20,
                formato: kFMT_BIN,
                nao_conv: true,
            }
            break

        case 9:
            info = {
                nome: "CAVV Data",
                tipo: kFixo,
                len: 20,
                formato: kFMT_BIN,
                nao_conv: true,
            }
            break

        case 10:
            info = {
                nome: "CVV2 Authorization Request Data",
                tipo: kFixo,
                len: 6,
                formato: kFMT_EBC,
                breakFunc: break_bit126_visa_field10,
            }
            break

        case 13:
            info = {
                nome: "POS Environment",
                tipo: kFixo,
                len: 1,
                formato: kFMT_EBC,
            }
            break

        case 18:
            info = {
                nome: "Agent Unique Account Result",
                tipo: kFixo,
                len: 12,
                formato: kFMT_EBC,
            }
            break

        case 20:
            info = {
                nome: "3-D Secure Indicator",
                tipo: kFixo,
                len: 1,
                formato: kFMT_EBC,
            }
            break
    }

    return info
}

function break_bit126_visa_field10_presenceIndicator_desc(value)
{
    var desc

    switch(value)
    {
        case "0":
            desc = "CVV2 value not provided"
            break

        case "1":
            desc = "CVV2 value is present"
            break

        case "2":
            desc = "CVV2 value is on the card but is illegible"
            break

        case "9":
            desc = "No CVV2 value on card"
            break
    }

    return desc
}

function break_bit126_visa_field10_responseType_desc(value)
{
    var desc

    switch(value)
    {
        case "0":
            desc = "Only the normal response code in field 39 should be returned"
            break

        case "1":
            desc = "The normal response code in field 39 and the CVV2 result in field 44.10 should be returned"
            break
    }

    return desc
}
