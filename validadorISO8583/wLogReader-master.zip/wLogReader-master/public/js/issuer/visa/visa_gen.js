// visa_gen.js

var msg_formatted_visa

function break_bit_visa_bitmapped(bit_visa, bitmap_len)
{
    // console.log("======================================================")
    // console.log("break_bit_visa_bitmapped - inicio - bit [%d]", bit_visa)
    // console.log(msg_break_bit)

    // limpando
    msg_formatted_visa = ""

    if (bitmap_len == undefined)
    {
        bitmap_len = 8 * 2
    }
    else
    {
        bitmap_len = bitmap_len * 2
    }

    // bitmap
    var bitmap = {}
    bitmap.hexa = get_field_break_bit(bitmap_len)
    // console.log("bitmap hexa [%s]", bitmap.hexa)
    // console.log(msg_break_bit)

    bitmap.bin = bitmap_hex2bin(bitmap.hexa)
    // console.log("bitmap bin [%s]", bitmap.bin)

    bitmap.formatted = bitmap2formatted(bitmap.bin, true)
    // console.log("bitmap formatted [%s]", bitmap.formatted)

    //

    var bit
    var bit_info
    var i_len = 128
    for (var i = 0; i < i_len; i++)
    {
        var bit_bin = bitmap.bin.substr(i, 1)

        if (bit_bin == 1)
        {
            bit = i + 1

            switch(bit_visa)
            {
                case 62:
                    bit_info = get_info_bit62_visa(bit)
                    break

                case 63:
                    bit_info = get_info_bit63_visa(bit)
                    break

                case 126:
                    bit_info = get_info_bit126_visa(bit)
                    break
            }

            if (bit_info)
            {
                if (break_bit_visa_subfield_bitmapped(bit, bit_info, bit_visa) < 0)
                {
                    // encontrou algum erro
                    display_result_bit_visa_bitmapped(bitmap)
                    return
                }
            }
            else
            {
                alert("Não foi possível pegar as informações do subfield " + bit + " do DE " + bit_visa + ".")
                display_result_bit_visa_bitmapped(bitmap)
                return
            }
        }
    }

    display_result_bit_visa_bitmapped(bitmap)
    // console.log("break_bit_visa_bitmapped - fim - bit [%d]", bit_visa)
}

function break_bit_visa_subfield_bitmapped(bit, bit_info, bit_visa)
{
    // console.log("break_bit_visa_subfield_bitmapped - inicio")
    // console.log("bit [%s] bit_info [%s]", bit, bit_info)

    switch (bit_info.tipo)
    {
        case kFixo:
            if (bit_info.len)
            {
                var bit_len = bit_info.len
                bit_len *= 2
            }
            else
            {
                alert("ERRO - Não foi definido o tamanho do subfield " + bit + " do DE " + bit_visa + ".")
                return -1
            }

            // pegando da mensagem
            var val = get_field_break_bit(bit_len)
            if (val.length != bit_len)
            {
                var msg = "ERRO - O tamanho do conteúdo do subfield " + bit + " do DE " + bit_visa + " não é igual ao tamanho especificado." + "\n"
                msg += "len especificado [" + bit_len + "] len conteúdo [" + val.length + "] conteúdo [" + val + "]."
                alert(msg)
                return -1
            }

            // convertendo
            var val_conv = ""
            if (bit_info.formato != kFMT_BCD)
            {
                if (!bit_info.nao_conv)
                {
                    val_conv  = mostrarColchete(conv_ebc2a(val))
                }
            }

            // atualizar a mensagem formatada
            msg_formatted_visa += get_html_spaces(16)
            msg_formatted_visa += "Subfield " + padSubfield(bit) + " - " + "Fixo" + " - " + val + val_conv

            if (bit_info.nome)
            {
                msg_formatted_visa += " (" + bit_info.nome + ")"
            }

            msg_formatted_visa += "<br>"

            if (bit_info.breakFunc)
            {
                msg_break_aux = val
                bit_info.breakFunc()
            }
            break

        case kLvar:
            break

        case kLLvar:
            break

        case kLLLvar:
            break

        default:
            return -1
    }

    // console.log("break_bit_visa_subfield_bitmapped - fim")
    return 0
}

function display_result_bit_visa_bitmapped(bitmap)
{
    fill_html_spaces()
    msg_formatted += "Bitmap Hexa" + " - " + bitmap.hexa + "<br>"
    fill_html_spaces()
    msg_formatted += "Bitmap Subfields" + " - " + bitmap.formatted + "<br>"

    //

    msg_formatted += msg_formatted_visa
}
