// break_bit48_wq3_info.js

/*
Propriedades do objeto de retorno

tipo            [string]    nome do tipo da tag (Fixo, Lvar, LLvar ou LLLvar)
nome            [string]    nome da tag
len             [int]       tamanho da tag
hasLen          [bool]      true = indica que a tag tem o tamanho | false/undefined = nao tem tamanho
breakFuncDesc   [string]    nome da funcao para quebrar a tag inline (desc)
breakFunc       [string]    nome da funcao para quebrar a tag em nova linha
formato         [string]    formato da tag (HEXA, EBC ou BCD) - o formato do DE sobreescreve esse formato
isLenHexa       [bool]      true = indica que o tamanho da tag esta em hexa
*/

function break_bit48_wq3_info(tag)
{
    var info

    tag = tag.toUpperCase()

    switch (tag)
    {
        case "01":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Identificação da transação",
                len: 4,
                breakFuncDesc: break_bit48_wq3_tag01,
            }
            break

        case "04":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Quantidade Parcelas",
                len: 2,
            }
            break

        case "3B":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Cardholder Name",
            }
            break

        case "40":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Contador de Pooling",
                len: 2,
            }
            break

        case "41":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Stan da Solicitação do QR Code",
                len: 6,
            }
            break

        case "42":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Data Geração QR Code",
            }
            break

        case "43":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "CNPJ",
            }
            break

        case "45":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Nome Fantasia",
            }
            break

        case "46":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Cidade",
            }
            break

        case "47":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Modalidade",
            }
            break

        case "49":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Código de Autorização Offline",
            }
            break

        case "4A":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Identificação QRCode Financeira",
            }
            break

        case "4B":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                len: 6,
                nome: "Stan Financeira",
            }
            break

        case "50":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Telefone do Comprador",
            }
            break

        case "51":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Nome do Comprador",
            }
            break

        case "52":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Data Pagamento ITI",
            }
            break

        case "53":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Hora Pagamento ITI",
            }
            break

        case "54":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "CPF/CNPJ do portador (PV+ESTAB+CPF/CNPJ)",
            }
            break

        case "55":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Número Pedido ITI",
            }
            break

        case "56":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Identificação Transação QRCode",
            }
            break

        case "57":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Cartão Mascarado",
            }
            break

        case "58":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "NSU Transação Financeira",
            }
            break
    }

    return info
}
