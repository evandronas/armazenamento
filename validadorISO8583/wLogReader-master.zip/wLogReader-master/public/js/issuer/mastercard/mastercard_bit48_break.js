// mastercard_bit48_break.js

function break_bit48_mastercard()
{
    // pegar tcc
    break_bit48_mastercard_tcc()

    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 2,
        infoFunc: break_bit48_mastercard_info,
        nomeCampo: "Subelement",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}

function break_bit48_mastercard_tcc()
{
    // transaction category code (TCC)
    var nome = "Terminal Category Code"
    var len = 1
    var valor = get_field_break_bit(len * 2)
    var valor_conv = conv_ebc2a(valor)
    var desc

    switch(valor_conv.toUpperCase())
    {
        case "A":
            desc = "Auto/Vehicle Rental"
            break

        case "C":
            desc = "Cash Disbursement"
            break

        case "F":
            desc = "Restaurant"
            break

        case "H":
            desc = "Hotel/Motel"
            break

        case "O":
            desc = "Hospitalization, College"
            break

        case "P":
            desc = "Payment Transaction"
            break

        case "R":
            desc = "Retail Sale"
            break

        case "T":
            desc = "Phone, Mail, or Electronic Commerce Order"
            break

        case "U":
            desc = "Unique"
            break

        case "X":
            desc = "Airline and Other Transportation Services"
            break

        case "Z":
            desc = "ATM Cash Disbursement"
            break

        // default:
        //     desc = kMSG_ERRO_VALOR_NAO_MAPEADO
        //     break
    }

    fill_html_spaces()
    msg_formatted += nome + " - " + valor + " [" + valor_conv + "]"

    if (desc)
    {
        msg_formatted += " = " + desc
    }

    fill_break_line()
}

function break_bit48_mastercard_subelemento20(subcampo_info)
{
    var valor = get_field_break_aux()
    var valor_conv = conv_ebc2a(valor)
    var desc

    switch(valor_conv)
    {
        case "P":
            desc = "Online PIN verification"
            break

        case "S":
            desc = "Can signify signature, “Offline PIN verification” (for chip transactions), “M-PIN” (for Mobile Device with PIN entry capability) or “No CVM used”"
            break
    }

    if (desc)
    {
        subcampo_info.desc = desc
    }

    return subcampo_info
}

function break_bit48_mastercard_subelemento42_subcampo01()
{
    var qtdeTab = 40

    var len
    var valor
    var valor_conv
    var desc
    var infodisp

    // subfield 1
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch (parseInt(valor_conv))
    {
        case 0:
            desc = "Reserved for existing MasterCard Europe/Visa definitions"
            break

        case 1:
            desc = "Reserved for future use"
            break

        case 2:
            desc = "Channel"
            break

        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
            desc = "Reserved for future use"
            break

        case 9:
            desc = "None (no security protocol)"
            break

        default:
            // desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
        nome: "Security Protocol",
    }
    genDisplayInfo(infodisp)

    // subfield 2
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(parseInt(valor_conv))
    {
        case 0:
            desc = "Reserved for future use"
            break

        case 1:
            desc = "eCommerce / SecureCode"
            break

        case 2:
            desc = "Processed through MasterPass"
            break

        case 3:
            desc = "Reserved for future use"
            break

        case 4:
            desc = "Digital Secure Remote Payment (DSRP) with UCAF data"
            break

        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
            desc = "Reserved for future use"
            break

        default:
            // desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
        nome: "Cardholder Authentication",
    }
    genDisplayInfo(infodisp)

    // subfield 3
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(parseInt(valor_conv))
    {
        case 0:
            desc = "UCAF data collection is not supported by the merchant or a SecureCode merchant has chosen not to undertake SecureCode on this transaction"
            break

        case 1:
            // desc = "UCAF data collection is supported by the merchant, and UCAF data must be present (DE 48, subelement 43 must be present and contain an attempt AAV for MasterCard SecureCode)"
            desc = "UCAF data collection is supported by the merchant, and UCAF data must be present"
            break

        case 2:
            // desc = "UCAF data collection is supported by the merchant, and UCAF data must be present (DE 48, subelement 43 must contain a fully authenticated AAV)"
            desc = "UCAF data collection is supported by the merchant, and UCAF data must be present"
            break

        case 3:
            desc = "UCAF data collection is supported by the merchant, and UCAF (MasterCard assigned Static Accountholder Authentication Value) data must be present"
            break

        case 4:
            desc = "Reserved for future use"
            break

        case 5:
            desc = "Issuer Risk Based Decisioning"
            break

        case 6:
            desc = "Merchant Risk Based Decisioning"
            break

        case 7:
            desc = "Partial shipment or recurring payment. Liability will depend on the original UCAF values provided and matching with the initial transaction"
            break

        case 8:
        case 9:
            desc = "Reserved for future use"
            break

        default:
            // desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
        nome: "UCAF Collection Indicator",
    }
    genDisplayInfo(infodisp)
}

function break_bit48_mastercard_subelemento61()
{
    var qtdeTab = 38

    var len
    var valor
    var valor_conv
    var desc
    var infodisp

    // subfield 1
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch (parseInt(valor_conv))
    {
        case 0:
            desc = "Merchant terminal does not support receipt of partial approvals"
            break

        case 1:
            desc = "Merchant terminal supports receipt of partial approvals"
            break

        default:
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
        nome: "Partial Approval Terminal Support Indicator",
    }
    genDisplayInfo(infodisp)

    // subfield 2
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch (parseInt(valor_conv))
    {
        case 0:
            desc = "Merchant terminal does not support receipt of purchase only approvals"
            break

        case 1:
            desc = "Merchant terminal supports receipt of purchase only approvals"
            break

        default:
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
        nome: "Purchase Amount Only Terminal Support Indicator",
    }
    genDisplayInfo(infodisp)

    // subfield 3
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch (parseInt(valor_conv))
    {
        case 0:
            desc = "Merchant terminal did not verify the purchased items against an Inventory Information Approval System (IIAS)"
            break

        case 1:
            desc = "Merchant terminal verified the purchased items against an Inventory Information Approval System (IIAS)"
            break

        case 2:
            desc = "Merchant terminal verified the purchased items against an Inventory Information Approval System (IIAS)"
            break

        case 4:
            desc = "Merchant terminal verified the purchased items against an Inventory Information Approval System (IIAS)"
            break

        default:
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
        nome: "Real-time Substantiation Indicator",
    }
    genDisplayInfo(infodisp)

    // subfield 4
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch (parseInt(valor_conv))
    {
        case 0:
            desc = "No action required"
            break

        case 1:
            desc = "Transaction to be scored"
            break

        default:
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
        nome: "Merchant Transaction Fraud Scoring Indicator",
    }
    genDisplayInfo(infodisp)

    // subfield 5
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch (parseInt(valor_conv))
    {
        case 0:
            desc = "Normal Authorization/Undefined Finality"
            break

        case 1:
            desc = "Final Authorization"
            break

        default:
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
        nome: "Final Authorization Indicator",
    }
    genDisplayInfo(infodisp)
}

function break_bit48_mastercard_subelemento84(subcampo_info)
{
    var valor = get_field_break_aux()
    var valor_conv = conv_ebc2a(valor)
    var desc

    switch(valor_conv)
    {
        case "01":
            desc = "New account information available"
            break

        case "02":
            desc = "Cannot approve at this time, try again later"
            break

        case "03":
            desc = "Do not try again"
            break

        case "04":
            desc = "Token requirements not fulfilled for this token type"
            break

        case "21":
            desc = "Recurring Payment Cancellation Service"
            break
    }

    if (desc)
    {
        subcampo_info.desc = desc
    }

    return subcampo_info
}

function break_bit48_mastercard_subelemento87(subcampo_info)
{
    var valor = get_field_break_aux(2)
    var valor_conv = conv_ebc2a(valor)
    var desc

    switch(valor_conv)
    {
        // CVC 1

        case "Y":
            desc = "Invalid CVC 1"
            break

        // CVC 2

        case "M":
            desc = "Valid CVC 2 (match)"
            break

        case "N":
            desc = "Invalid CVC 2 (non-match)"
            break

        case "P":
            desc = "CVC 2 not processed (issuer temporarily unavailable)"
            break

        case "U":
            desc = "CVC 2 Unverified—MasterCard Use Only"
            break

        // CVC 3

        case "E":
            desc = "Length of unpredictable number was not a valid length"
            break

        case "P":
            desc = "Unable to process"
            break
    }

    if (desc)
    {
        subcampo_info.desc = desc
    }

    return subcampo_info
}
