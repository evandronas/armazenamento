// mastercard_bit_info.js

function get_bit_mastercard(bit)
{
    var info;

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 43:
            info.break_bit_func = gen_bit43_break_ebc
            break

        case 45:
            info.nao_conv = true
            break

        case 48:
            info.break_bit_func = break_bit48_mastercard
            break

        case 52:
            info.len = 8
            break

        case 55:
            info.nao_conv = true
            info.break_bit_func = genBreakBit55Puro
            break

        case 56:
            info.nao_conv = true
            info.break_bit_func = break_bit56_mastercard
            break

        case 61:
            info.break_bit_func = break_bit61_mastercard
            break

        case 90:
            info.break_bit_func = break_bit90_mastercard
            break

        case 104:
            info.break_bit_func = break_bit104_mastercard
            break

        case 112:
            info.break_bit_func = break_bit112_mastercard
            break

        case 124:
            info.break_bit_func = break_bit124_mastercard
            break
    }

    return info
}
