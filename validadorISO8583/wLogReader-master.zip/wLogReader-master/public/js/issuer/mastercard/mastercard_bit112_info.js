// mastercard_bit112_break.js

function break_bit112_mastercard_info(subelemento, subcampo)
{
    var info

    switch(subelemento)
    {
        case "001":
            info = {
                nome: "Installment Payment Data",
                breakFunc: break_bit112_mastercard_subelemento001,
            }
            break

        case "002":
            info = {
                nome: "Installment Payment Response Data",
            }
            break

        case "013":
        case "014":
        case "015":
            info = {
                nome: "Dados Crediário",
                breakFunc: break_bit112_mastercard_crediario,
            }
            break

        case "019":
            info = {
                nome: "Original Purchase Amount",
                formatMoney: true,
            }
            break

        case "029":
            info = {
                nome: "CNPJ",
            }
            break
    }

    return info
}
