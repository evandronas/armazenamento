// mastercard_break.js

// DE90

function break_bit90_mastercard()
{
    var obj = {
        formato: kFMT_EBC,
        campos: [
            {
                nome: "Subfield 1: Original Message Type Identifier",
                len: 4,
            },
            {
                nome: "Subfield 2: Original DE 11 (Systems Trace Audit Number)",
                len: 6,
            },
            {
                nome: "Subfield 3: Original DE 7 (Transmission Date and Time)",
                len: 10,
            },
            {
                nome: "Subfield 4: Original DE 32 (Acquiring Institution ID Code)",
                len: 11,
            },
            {
                nome: "Subfield 5: Original DE 33 (Forwarding Institution ID Code)",
                len: 11,
            },
        ],
        space: 72,
    }
    gen_bit90_break2(obj)
}

// DE104

function break_bit104_mastercard()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 3,
        infoFunc: break_bit104_mastercard_info,
        nomeCampo: "Subelement",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}
