// mastercard_bit56_break.js

function break_bit56_mastercard()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 2,
        infoFunc: break_bit56_mastercard_info,
        nomeCampo: "Subelement",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}
