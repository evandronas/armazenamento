// mastercard_info.js

// DE 104

function break_bit104_mastercard_info(subelemento, subcampo)
{
    var info

    switch(subelemento)
    {
        case "001":
            info = {
                nome: "??",
            }
            break
    }

    return info
}
