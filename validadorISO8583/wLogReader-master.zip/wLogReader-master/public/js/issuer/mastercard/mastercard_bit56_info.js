// mastercard_bit56_info.js

function break_bit56_mastercard_info(subelemento, subcampo)
{
    var info

    switch(subelemento)
    {
        case "01":
            if (subcampo)
            {
                switch(subcampo)
                {
                    case "01":
                        info = {
                            nome: "Payment Account Reference (PAR)",
                        }
                        break
                }
            }
            else
            {
                info = {
                    nome: "Payment Account Data",
                    breakTLV: true,
                }
            }
            break
    }

    return info
}
