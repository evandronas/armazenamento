// mastercard_bit112_break.js

function break_bit112_mastercard()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 3,
        infoFunc: break_bit112_mastercard_info,
        nomeCampo: "Subelement",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}

function break_bit112_mastercard_subelemento001()
{
    var qtdeTab = 40
    var nomeCampoSpace = 20

    var len
    var valor
    var valor_conv
    var infodisp

    // Parcelas plan type - n2
    len = 2
    valor = get_field_break_aux(len * 2)
    valor_conv = conv_ebc2a(valor)
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        nomeCampo: "Plan Type",
        nomeCampoSpace: nomeCampoSpace,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: mastercard_desc_plan_type(valor_conv),
    }
    genDisplayInfo(infodisp)

    // The total number of Parcelas - n2
    len = 2
    valor = get_field_break_aux(len * 2)
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        nomeCampo: "Quantidade Parcelas",
        nomeCampoSpace: nomeCampoSpace,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}

function break_bit112_mastercard_subelement002(subelemento_info)
{
    // console.log("break_bit112_mastercard_subelement001 - msg_break_aux [%s]", msg_break_aux)
    var qtdeTab = 40
    var nomeCampoSpace = 23

    var nome
    var len
    var valor
    var valor_conv
    var desc
    var infodisp
    var formatted = ""

    if ((msg_break_aux.length / 2) == 32) // Format 1: Issuer-Financed Parcelas transactions in the Authorization Request Response/0110
    {
        // Parcelas plan type - n2
        nome = "Plan Type"
        len = 2
        valor = get_field_break_aux(len * 2)
        valor_conv = conv_ebc2a(valor)
        desc = mastercard_desc_plan_type(valor_conv)
        infodisp = {
            qtdeTab: qtdeTab,
            nomeCampo: nome,
            nomeCampoSpace: nomeCampoSpace,
            valorOrig: valor,
            valorConv: valor_conv,
            desc: desc
        }
        formatted += genDisplayInfo(infodisp)

        // The total number of Parcelas - n2
        nome = "Quantidade Parcelas"
        len = 2
        valor = get_field_break_aux(len * 2)
        valor_conv = conv_ebc2a(valor)
        infodisp = {
            qtdeTab: qtdeTab,
            nomeCampo: nome,
            nomeCampoSpace: nomeCampoSpace,
            valorOrig: valor,
            valorConv: valor_conv,
        }
        formatted += genDisplayInfo(infodisp)

        // Parcelas (or installment) amount issuer calculates - n12
        nome = "Valor Parcela"
        len = 12
        valor = get_field_break_aux(len * 2)
        valor_conv = conv_ebc2a(valor)
        infodisp = {
            qtdeTab: qtdeTab,
            nomeCampo: nome,
            nomeCampoSpace: nomeCampoSpace,
            valorOrig: valor,
            valorConv: valor_conv,
            formatMoney: true,
        }
        formatted += genDisplayInfo(infodisp)

        // Transaction total amount issuer calculates - n12
        nome = "Valor Total Financiado"
        len = 12
        valor = get_field_break_aux(len * 2)
        valor_conv = conv_ebc2a(valor)
        infodisp = {
            qtdeTab: qtdeTab,
            nomeCampo: nome,
            nomeCampoSpace: nomeCampoSpace,
            valorOrig: valor,
            valorConv: valor_conv,
            formatMoney: true,
        }
        formatted += genDisplayInfo(infodisp)

        // Monthly interest rate issuer calculates - n4
        nome = "Encargo Mensal"
        len = 4
        valor = get_field_break_aux(len * 2)
        valor_conv = conv_ebc2a(valor)
        infodisp = {
            qtdeTab: qtdeTab,
            nomeCampo: nome,
            nomeCampoSpace: nomeCampoSpace,
            valorOrig: valor,
            valorConv: valor_conv,
            formatPct: true,
        }
        formatted += genDisplayInfo(infodisp)

        //

        subelemento_info.newline = formatted

        return subelemento_info
    }
}

function break_bit112_mastercard_crediario()
{
    var nome
    var len
    var valor
    var valor_conv
    var formatted = ""

    // Installment Plan Type/Tipo de Plano Parcelado - n2
    len = 2
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Installment Plan Type/Tipo de Plano Parcelado",
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Total Number of Installments/Qtde de Parcelas - n2
    len = 2
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Total Number of Installments/Quantidade de Parcelas",
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Installment Amount/Valor da Parcela - n12
    len = 12
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Installment Amount/Valor da Parcela",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Total Amount/Valor Total - n12
    len = 12
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Total Amount/Valor Total",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Monthly Interest Rate/Taxa de Juros Mensal - n4
    len = 4
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Monthly Interest Rate/Taxa de Juros Mensal",
        formatPct: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Annual Interest Rate/Taxa de Juros Anual - n5
    len = 5
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Annual Interest Rate/Taxa de Juros Anual",
        formatPct: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Monthly Total Effective Cost (CET)/CET Mensal - n12
    len = 12
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Monthly Total Effective Cost/CET Mensal",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Annual Total Effective Cost (CET)/CET Anual - n12
    len = 12
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Annual Total Effective Cost/CET Anual",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Date of First Installment/Data da Primeira Pacela - n6
    len = 6
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Date of First Installment/Data da Primeira Pacela",
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Taxes/Impostos - n7
    len = 7
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Taxes/Impostos",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // % Taxes of Total Amount/% de Impostos sobre o Valor Total - n4
    len = 4
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "% Taxes of Total Amount/% de Impostos sobre o Valor Total",
        formatPct: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Fee/Tarifas - n7
    len = 7
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Fee/Tarifas",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // % Fee of Total Amount/% de Tarifas sobre o Valor Total - n4
    len = 4
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "% Fee of Total Amount/% de Tarifas sobre o Valor Total",
        formatPct: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Insurance/Seguro - n7
    len = 7
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Insurance/Seguro",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // % Insurance of Total Amount/% de Seguro sobre o Valor Total - n4
    len = 4
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "% Insurance of Total Amount/% de Seguro sobre o Valor Total",
        formatPct: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Other/Outros - n7
    len = 7
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Other/Outros",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // % Other of Total Amount/% de Outros sobre o Valor Total - n4
    len = 4
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "% Other of Total Amount/% de Outros sobre o Valor Total",
        formatPct: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // Total Amount to Merchant/Valor Total para o Estabelecimento - n12
    len = 12
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "Total Amount to Merchant/Valor Total para o Estabelecimento",
        formatMoney: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // % Amount to Merchant of Total Amount/% do Estabelecimento sobre o Valor Total - n4
    len = 4
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "% Amount to Merchant of Total Amount/% do Estab sobre o Valor Total",
        formatPct: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))

    // % Total Effect Cost/% de Efeito de Custo Total - n4
    len = 4
    valor = get_field_break_aux(len * 2)
    infodisp = {
        valorOrig: valor,
        convEbc: true,
        nomeCampo: "% Total Effect Cost/% de Efeito de Custo Total",
        formatPct: true,
    }
    genDisplayInfo(genDisplayInfo(mergeObject(break_bit112_mastercard_crediario_infodisp(), infodisp)))
}

function break_bit112_mastercard_crediario_infodisp()
{
    var obj = {
        display: true,
        qtdeTab: 20,
        nomeCampoSpace: 70,
    }

    return obj
}
