// mastercard_gen.js

function mastercard_desc_plan_type(value)
{
    var desc

    switch(value)
    {
        case "20":
            desc = "Issuer-financed"
            break

        case "21":
            desc = "Merchant-financed"
            break

        case "25":
            desc = "Crediário"
            break
    }

    return desc
}
