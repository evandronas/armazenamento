// mastercard_bit61_break.js

function break_bit61_mastercard()
{
    var nome
    var len
    var valor
    var valor_conv
    var desc

    // Subfield 01: POS Terminal Attendance - n1
    nome = "Subfield 01: POS Terminal Attendance"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "Attended Terminal"
            break

        case "1":
            desc = "Unattended terminal (cardholder-activated terminal [CAT], home PC, mobile phone, PDA)"
            break

        case "2":
            desc = "No terminal used (voice/audio response unit [ARU] authorization)"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 02: Reserved for Future Use - n1
    nome = "Subfield 02: Reserved for Future Use"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    desc = undefined
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 03: POS Terminal Location - n1
    nome = "Subfield 03: POS Terminal Location"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "On premises of card acceptor facility"
            break

        case "1":
            desc = "Off premises of card acceptor facility (merchant terminal—remote location)"
            break

        case "2":
            desc = "Off premises of card acceptor facility (cardholder terminal including home PC, mobile phone, PDA)"
            break

        case "3":
            desc = "No terminal used (voice/ARU authorization)"
            break

        case "4":
            desc = "On premises of card acceptor facility (cardholder terminal including home PC, mobile phone, PDA)"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 04: POS Cardholder Presence - n1
    nome = "Subfield 04: POS Cardholder Presence"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "Cardholder present"
            break

        case "1":
            desc = "Cardholder not present, unspecified"
            break

        case "2":
            desc = "Mail/facsimile order"
            break

        case "3":
            desc = "Phone/ARU order"
            break

        case "4":
            desc = "Standing order/recurring transactions"
            break

        case "5":
            desc = "Electronic order (home PC, Internet, mobile phone, PDA)"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 05: POS Card Presence - n1
    nome = "Subfield 05: POS Card Presence"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "Card present"
            break

        case "1":
            desc = "Card not present"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 06: POS Card Capture Capabilities - n1
    nome = "Subfield 06: POS Card Capture Capabilities"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "Terminal/operator has no card capture capability"
            break

        case "1":
            desc = "Terminal/operator has card capture capability"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 07: POS Transaction Status - n1
    nome = "Subfield 07: POS Transaction Status"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "Normal request (original presentment)"
            break

        case "2":
            desc = "SecureCode Phone Order"
            break

        case "3":
            desc = "ATM Installment Inquiry"
            break

        case "4":
            desc = "Preauthorized request"
            break

        case "6":
            desc = "ATC Update"
            break

        case "8":
            desc = "Account Status Inquiry Service"
            break

        case "9":
            desc = "Tokenization Request/Notification"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 08: POS Transaction Security - n1
    nome = "Subfield 08: POS Transaction Security"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "No security concern"
            break

        case "1":
            desc = "Suspected fraud (merchant suspicious—code 10)"
            break

        case "2":
            desc = "ID verified"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 09: Reserved for Future Use - n1
    nome = "Subfield 09: Reserved for Future Use"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    desc = undefined
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 10: Cardholder-Activated Terminal Level - n1
    nome = "Subfield 10: Cardholder-Activated Terminal Level"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "Not a CAT transaction"
            break

        case "1":
            desc = "Authorized Level 1 CAT: Automated dispensing machine with PIN"
            break

        case "2":
            desc = "Authorized Level 2 CAT: Self-service terminal"
            break

        case "3":
            desc = "Authorized Level 3 CAT: Limited-amount terminal"
            break

        case "4":
            desc = "Authorized Level 4 CAT: In-flight commerce"
            break

        case "5":
            desc = "Reserved"
            break

        case "6":
            desc = "Authorized Level 6 CAT: Electronic commerce"
            break

        case "7":
            desc = "Authorized Level 7 CAT: Transponder transaction"
            break

        case "8":
            desc = "Reserved for future use"
            break

        case "9":
            desc = "MPOS Acceptance Device"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 11: POS Card Data Terminal Input Capability Indicator - n1
    nome = "Subfield 11: POS Card Data Terminal Input Capability Indicator"
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    switch(valor_conv)
    {
        case "0":
            desc = "Unknown or unspecified"
            break

        case "1":
            desc = "No terminal used (voice/ARU authorization)"
            break

        case "2":
            desc = "Magnetic stripe reader only"
            break

        case "3":
            desc = "Contactless M/Chip (Proximity Chip)"
            break

        case "4":
            desc = "Contactless Magnetic Stripe (Proximity Chip) only"
            break

        case "5":
            desc = "EMV specification and magnetic stripe reader"
            break

        case "6":
            desc = "Key entry only"
            break

        case "7":
            desc = "Magnetic stripe reader and key entry"
            break

        case "8":
            desc = "EMV specification, magnetic stripe reader and key entry"
            break

        case "9":
            desc = "EMV specification only"
            break

        default:
            desc = "Valor não mapeado"
            break
    }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 12: POS Authorization Life Cycle - n2
    nome = "Subfield 12: POS Authorization Life Cycle"
    len = 2
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    desc = undefined
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 13: POS Country Code - n3
    nome = "Subfield 13: POS Country Code"
    len = 3
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    desc = undefined
    // switch(valor_conv)
    // {
    //     case "0":
    //         desc = "No security concern"
    //         break

    //     case "1":
    //         desc = "Suspected fraud (merchant suspicious—code 10)"
    //         break

    //     case "2":
    //         desc = "ID verified"
    //         break

    //     default:
    //         desc = "Valor não mapeado"
    //         break
    // }
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)

    // Subfield 14: POS Postal Code - ans10
    nome = "Subfield 14: POS Postal Code"
    len = 10
    valor = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor)
    desc = undefined
    // console.log("%s - valor [%s] valor conv [%s] desc [%s]", nome, valor, valor_conv, desc)
    display_bit61_mastercard(nome, len, valor, valor_conv, desc)
}

function display_bit61_mastercard(nome, len, valor, valor_conv, desc)
{
    fill_html_spaces(16)
    msg_formatted += padEXT(nome, 63) +  " - " + valor + " [" + valor_conv + "]"

    if (desc)
    {
        msg_formatted += " = " + desc
    }

    msg_formatted += "<br>"
}
