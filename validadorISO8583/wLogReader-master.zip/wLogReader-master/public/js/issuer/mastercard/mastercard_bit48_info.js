// mastercard_bit48_info.js

function break_bit48_mastercard_info(subelemento, subcampo)
{
    var info

    switch(subelemento)
    {
        case "20":
            info = {
                nome: "Cardholder Verification Method",
                descFunc: break_bit48_mastercard_subelemento20,
            }
            break

        case "21":
            if (subcampo)
            {
                switch(subcampo)
                {
                    case "01":
                        info = {
                            nome: "mPOS Acceptance Device Type",
                        }
                        break
                }
            }
            else
            {
                info = {
                    nome: "Acceptance Data",
                    breakTLV: true,
                }
            }
            break

        case "33":
            if (subcampo)
            {
                switch(subcampo)
                {
                    case "01":
                        info = {
                            nome: "Account Number Indicator",
                        }
                        break

                    case "02":
                        info = {
                            nome: "Account Number",
                        }
                        break

                    case "03":
                        info = {
                            nome: "Expiration Date",
                        }
                        break

                    case "04":
                        info = {
                            nome: "Product Code",
                        }
                        break

                    case "05":
                        info = {
                            nome: "Token Assurance Level",
                        }
                        break

                    case "06":
                        info = {
                            nome: "Token Requestor ID",
                        }
                        break

                    case "07":
                        info = {
                            nome: "Primary Account Number, Account Range",
                        }
                        break
                }
            }
            else
            {
                info = {
                    nome: "PAN Mapping File Information",
                    breakTLV: true,
                }
            }
            break

        case "37":
            if (subcampo)
            {
                switch(subcampo)
                {
                    case "01":
                        info = {
                            nome: "Payment Facilitator ID",
                        }
                        break

                    case "02":
                        info = {
                            nome: "Independent Sales Organization ID",
                        }
                        break

                    case "03":
                        info = {
                            nome: "Sub-Merchant ID",
                        }
                        break
                }
            }
            else
            {
                info = {
                    nome: "Additional Merchant Data",
                    breakTLV: true,
                }
            }
            break

        case "42":
            if (subcampo)
            {
                switch(subcampo)
                {
                    case "01":
                        info = {
                            nome: "Electronic Commerce Security Level Indicator and UCAF Collection Indicator",
                            breakFunc: break_bit48_mastercard_subelemento42_subcampo01,
                        }
                        break
                }
            }
            else
                info = {
                    nome: "Electronic Commerce Indicators",
                    breakTLV: true,
                }
            break

        case "61":
            info = {
                nome: "POS Data Extended Condition Codes",
                breakFunc: break_bit48_mastercard_subelemento61,
            }
            break

        case "63":
            info = {
                nome: "Trace ID",
            }
            break

        case "66":
            if (subcampo)
            {
                switch(subcampo)
                {
                    case "01":
                        info = {
                            nome: "Program Protocol",
                        }
                        break

                    case "02":
                        info = {
                            nome: "Directory Server Transaction ID",
                        }
                        break
                }
            }
            else
            {
                info = {
                    nome: "Authentication Data",
                    breakTLV: true,
                }
            }
            break

        case "80":
            info = {
                nome: "PIN Service Code",
            }
            break

        case "84":
            info = {
                nome: "Merchant Advice Code",
                descFunc: break_bit48_mastercard_subelemento84,
            }
            break

        case "87":
            info = {
                nome: "Card Validation Code Result",
                descFunc: break_bit48_mastercard_subelemento87,
            }
            break

        case "92":
            info = {
                nome: "CVC2",
            }
            break

        case "95":
            info = {
                nome: "MasterCard Promotion Code",
            }
            break
    }

    return info
}
