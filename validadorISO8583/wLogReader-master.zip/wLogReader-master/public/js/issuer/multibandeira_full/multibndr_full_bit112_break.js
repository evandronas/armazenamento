// multibndr_full_bit112_break.js

function break_bit112_multibndr_full()
{
    while(msg_break_bit.length != 0)
    {
        // pegando o identificador do subcampo
        var subcampo_id_orig = get_field_break_bit(6)
        var subcampo_id_conv = hex2a(subcampo_id_orig)
        // console.log('identificador - subcampo_id_orig [%s] subcampo_id_conv [%s]', subcampo_id_orig, subcampo_id_conv)

        // pegando o tamanho do subcampo
        var subcampo_len_orig = get_field_break_bit(6)
        var subcampo_len_string = hex2a(subcampo_len_orig)
        var subcampo_len_conv = parseInt(subcampo_len_string, 10)
        var subcampo_len_aux = subcampo_len_conv * 2
        // console.log('tamanho - subcampo_len_orig [%s] subcampo_len_string [%s] subcampo_len_conv [%d]', subcampo_len_orig, subcampo_len_string, subcampo_len_conv)

        // pegando o conteudo do subcampo
        var subcampo_valor_orig = get_field_break_bit(subcampo_len_aux)
        var subcampo_valor_conv = hex2a(subcampo_valor_orig)

        // pegando informacao do subcampo
        var subcampo_info = break_bit112_multibndr_info(subcampo_id_conv)

        if (subcampo_info.break_func)
        {
            msg_break_aux = subcampo_valor_orig
            subcampo_info = subcampo_info.break_func(subcampo_info)
        }

        //

        fill_html_spaces()
        msg_formatted += "Subcampo " + subcampo_id_conv + " - " + "V" + subcampo_len_string + " - " + subcampo_valor_orig + " [" + subcampo_valor_conv + "]"

        // se o valor for pra colocar na mesma linha, estara na propriedade inline
        if (subcampo_info.inline)
        {
            msg_formatted += " = " + subcampo_info.inline
        }

        if (subcampo_info.nome)
        {
            msg_formatted += mostrarParentese(subcampo_info.nome)
        }

        // se o valor for pra colocar em outra linha, estara na propriedade newline
        if (subcampo_info.newline)
        {
            fill_break_line()
            msg_formatted += subcampo_info.newline
        }
        else
        {
            fill_break_line()
        }
    }

    return 0
}
