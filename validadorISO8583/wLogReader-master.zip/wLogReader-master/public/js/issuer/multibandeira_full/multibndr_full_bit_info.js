// multibndr_full_bit_info.js

function get_bit_multibndr_full(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 29:
            info.len = 9
            break

        case 39:
            info.break_bit_func_inline = break_bit39_multibndr_full
            break

        case 48:
            info.break_bit_func = break_bit48_multibndr_full
            break

        case 55:
            info.break_bit_func = genBreakBit55Ascii
            break

        case 61:
            info.break_bit_func = break_bit61_multibndr_full
            break

        case 90:
            info.break_bit_func = break_bit90_multibndr_full
            break

        case 112:
            info.break_bit_func = break_bit112_multibndr_full
            break
    }

    return info
}
