// multibndr_full_bit61_break.js

function break_bit61_multibndr_full()
{
    var nome
    var len
    var valor
    var valor_conv
    var desc

    // Atendimento do terminal
    len = 1
    nome = "Atendimento do Terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Terminal Atendido"
            break

        case 1:
            desc = "Terminal Não Atendido"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Uso reservado
    len = 1
    nome = "Uso Reservado"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    desc = undefined
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Localizacao do terminal
    len = 1
    nome = "Localização do Terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Fácil para o acquirer"
            break

        case 2:
            desc = "Fora do estabelecimento de aceitação de cartão"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Presenca do portador
    len = 1
    nome = "Presença do Portador"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Portador presente"
            break

        case 1:
            desc = "Portador não presente"
            break

        case 5:
            desc = "Pedido eletrônico"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Presenca do cartao
    len = 1
    nome = "Presença do Cartão"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Cartão presente"
            break

        case 1:
            desc = "Cartão não presente"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Capacidade de captura do cartao
    len = 1
    nome = "Capacidade de Captura do Cartão"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Terminal não tem capacidade de captura do cartão"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Proposito da transacao
    len = 1
    nome = "Proposito da Transacao"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Pedido autorização normal"
            break

        case 3:
            desc = "Consulta parcelamento"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Seguranca do terminal
    len = 1
    nome = "Segurança do Terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Seguro"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Uso reservado
    len = 1
    nome = "Uso Reservado"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    desc = undefined
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Interacao do portador com o terminal
    len = 1
    nome = "Interação do portador com o terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Transação não CAT"
            break

        case 6:
            desc = "Comércio Eletrônico"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Capacidade de entrada dos dados do cartao
    len = 1
    nome = "Capacidade de entrada dos dados do cartão"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Desconhecido"
            break

        case 1:
            desc = "Autorização por URA"
            break

        case 2:
            desc = "Leitura de trilha"
            break

        case 5:
            desc = "Leitura de trilha e chip"
            break

        case 7:
            desc = "Magnetic stripe reader and key entry"
            break

        case 8:
            desc = "Magnetic stripe reader, key entry and EMV"
            break

        case 9:
            desc = "EMV"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Ciclo de vida da autorizacao
    len = 2
    nome = "Ciclo de vida da autorização"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    desc = undefined
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // Codigo do Pais do terminal
    len = 3
    nome = "Código do Pais do terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 76:
            desc = "Brasil"
            break

        default:
            desc = "Valor desconhecido"
            break
    }
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)


    // CEP
    len = 10
    nome = "CEP"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    desc = undefined
    formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)
}

function formatar_campo_bit61_multibndr_full(nome, len, valor, valor_conv, desc)
{
    fill_html_spaces()
    // msg_formatted += nome +  " - " + valor + " [" + valor_conv + "]"
    msg_formatted += padEXT(nome, 41) +  " - " + valor + " [" + valor_conv + "]"

    if (desc)
    {
        msg_formatted += " = " + desc
    }

    msg_formatted += "<br>"
}
