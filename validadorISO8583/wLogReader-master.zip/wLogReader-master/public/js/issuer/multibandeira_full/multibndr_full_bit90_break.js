// multibndr_full_bit90_break.js

function break_bit90_multibndr_full()
{
    var len
    var nome
    var valor
    var valor_conv

    // msgtype da original
    len = 4
    nome = "MsgType"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    formatar_campo_bit90(nome, valor, valor_conv)


    // stan da original
    len = 6
    nome = "Stan"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    formatar_campo_bit90(nome, valor, valor_conv)


    // DE07 da original
    len = 10
    nome = "DE07 Data e Hora GMT"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    formatar_campo_bit90(nome, valor, valor_conv)


    // Identificacao Acquirer
    len = 11
    nome = "DE32 Identificacao Acquirer"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    formatar_campo_bit90(nome, valor, valor_conv)


    // Identificacao Bandeira
    len = 11
    nome = "DE33 Identificacao Bandeira"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    formatar_campo_bit90(nome, valor, valor_conv)
}

function formatar_campo_bit90(nome, valor, valor_conv)
{
    fill_html_spaces()
    // msg_formatted += nome +  " - " + valor + " [" + valor_conv + "]"
    msg_formatted += padEXT(nome, 35) + " - " + valor + " [" + valor_conv + "]" + "<br>"
}
