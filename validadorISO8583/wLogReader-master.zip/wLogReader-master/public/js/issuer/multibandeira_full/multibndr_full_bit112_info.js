// multibndr_full_bit112_info.js

function break_bit112_multibndr_info(subcampo)
{
    var info = {}

    switch (subcampo)
    {
        case "001":
            info = {
                nome: "Plano de Parcelamento",
                break_func: break_bit112_multibndr_info_subcampo001,
            }
            break

        case "002":
            info = {
                nome: "Plano de Parcelamento",
                break_func: break_bit112_multibndr_info_subcampo002,
            }
            break

        case "003":
            info = {
                nome: "Juros e CET",
                break_func: break_bit112_multibndr_info_subcampo003,
            }
            break
    }

    return info
}

function break_bit112_multibndr_info_tipoparcelamento(valor)
{
    var desc

    switch (valor)
    {
        case "20":
            desc = "Parcelado Com Juros"
            break

        case "21":
            desc = "Parcelado Sem Juros"
            break
    }

    return desc
}

function break_bit112_multibndr_info_subcampo001(subcampo_info)
{
    var qtde_tab = 38
    var space = 22
    var info_display
    var valor_orig
    var valor_conv
    var desc
    var formatted = ""

    // tipo do parcelamento
    valor_orig = get_field_break_aux(4)
    valor_conv = hex2a(valor_orig)
    desc = break_bit112_multibndr_info_tipoparcelamento(valor_conv)
    info_display = {
        qtdeTab: qtde_tab,
        nomeCampo: "Tipo",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    formatted += genDisplayInfo(info_display)

    // quantidade de parcelas
    valor_orig = get_field_break_aux(4)
    valor_conv = hex2a(valor_orig)
    info_display = {
        qtdeTab: qtde_tab,
        nomeCampo: "Quantidade de Parcelas",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
    }
    formatted += genDisplayInfo(info_display)

    //

    subcampo_info.newline = formatted

    return subcampo_info
}

function break_bit112_multibndr_info_subcampo002(subcampo_info)
{
    var qtde_tab = 38
    var space = 22
    var info_display
    var len
    var valor_orig
    var valor_conv
    var desc
    var formatted = ""

    // tipo do parcelamento
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor_orig)
    desc = break_bit112_multibndr_info_tipoparcelamento(valor_conv)
    info_display = {
        qtdeTab: qtde_tab,
        nomeCampo: "Tipo",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    formatted += genDisplayInfo(info_display)

    // quantidade de parcelas
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor_orig)
    info_display = {
        qtdeTab: qtde_tab,
        nomeCampo: "Quantidade de Parcelas",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
    }
    formatted += genDisplayInfo(info_display)

    // valor da parcela
    len = 12
    valor_orig = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor_orig)
    info_display = {
        qtdeTab: qtde_tab,
        nomeCampo: "Valor das Parcelas",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(info_display)

    // valor total
    len = 12
    valor_orig = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor_orig)
    info_display = {
        qtdeTab: qtde_tab,
        nomeCampo: "Valor Total",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(info_display)

    //

    subcampo_info.newline = formatted

    return subcampo_info
}

function break_bit112_multibndr_info_subcampo003(subcampo_info)
{
    var qtde_tab = 38
    var space = 14
    var info_display
    var len
    var valor_orig
    var valor_conv
    var formatted = ""

    // taxa de juros
    len = 4
    valor_orig = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor_orig)
    info_display = {
        qtdeTab: qtde_tab,
        nomeCampo: "Taxa de Juros",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        formatPct: true,
    }
    formatted += genDisplayInfo(info_display)

    // cet
    len = 6
    valor_orig = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor_orig)
    info_display = {
        qtdeTab: qtde_tab,
        nomeCampo: "CET",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        formatPct: true,
    }
    formatted += genDisplayInfo(info_display)

    //

    subcampo_info.newline = formatted

    return subcampo_info
}
