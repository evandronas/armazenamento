// multibndr_full_bit39_break.js

function break_bit39_multibndr_full()
{
    var desc
    var valor = get_field_break_bit()
    var valor_conv = hex2a(valor)

    switch (valor_conv)
    {
        case "00":
            desc = "Approved"
            break

        case "01":
            desc = "Refer to card issuer"
            break

        case "03":
            desc = "Invalid merchant"
            break

        case "04":
            desc = "Capture card"
            break

        case "05":
            desc = "Do not honor"
            break

        case "08":
            desc = "Honor with ID"
            break

        case "12":
            desc = "Invalid transaction"
            break

        case "13":
            desc = "Invalid amount"
            break

        case "14":
            desc = "Invalid card number"
            break

        case "15":
            desc = "Invalid issuer"
            break

        case "30":
            desc = "Format error"
            break

        case "41":
            desc = "Lost card"
            break

        case "43":
            desc = "Stolen card"
            break

        case "51":
            desc = "Insufficient funds"
            break

        case "54":
            desc = "Expired card"
            break

        case "55":
            desc = "Invalid PIN"
            break

        case "57":
            desc = "Transaction not permitted to issuer/cardholder"
            break

        case "58":
            desc = "Transaction not permitted to acquirer/terminal"
            break

        case "61":
            desc = "Exceeds withdrawal amount limit"
            break

        case "62":
            desc = "Restricted card"
            break

        case "63":
            desc = "Security violation"
            break

        case "65":
            desc = "Exceeds withdrawal count limit"
            break

        case "70":
            desc = "Contact Card Issuer"
            break

        case "71":
            desc = "PIN Not Changed"
            break

        case "75":
            desc = "Allowable number of PIN tries exceeded"
            break

        case "76":
            desc = "Invalid/nonexistent “To Account” specified"
            break

        case "77":
            desc = "Invalid/nonexistent “From Account” specified"
            break

        case "78":
            desc = "Invalid/nonexistent account specified"
            break

        case "84":
            desc = "Invalid Authorization Life Cycle"
            break

        case "85":
            desc = "Not declined"
            break

        case "86":
            desc = "PIN Validation not possible"
            break

        case "87":
            desc = "Purchase Amount Only, No Cash Back Allowed"
            break

        case "88":
            desc = "Cryptographic failure"
            break

        case "89":
            desc = "Unacceptable PIN—Transaction Declined—Retry"
            break

        case "91":
            desc = "Authorization System or issuer system inoperative"
            break

        case "92":
            desc = "Unable to route transaction"
            break

        case "94":
            desc = "Duplicate transmission detected"
            break

        case "96":
            desc = "System error"
            break
    }

    msg_formatted += " = " + desc

    return 0
}
