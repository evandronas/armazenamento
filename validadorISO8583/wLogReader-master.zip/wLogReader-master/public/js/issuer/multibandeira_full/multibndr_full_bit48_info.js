// multibndr_full_bit48_info.js

function break_bit48_multibndr_info(subcampo)
{
    var info = {}

    switch (subcampo)
    {
        case "01":
            info = {
                nome: "Identificação da Transação",
                break_func: break_bit48_multibndr_info_subcampo001,
            }
            break

        case "02":
            info = {
                nome: "CVC2"
            }
            break

        case "03":
            info = {
                nome: "Validação CVC2",
                break_func: break_bit48_multibndr_info_subcampo003,
            }
            break

        case "04":
            info = {
                nome: "Validação PIN",
                break_func: break_bit48_multibndr_info_subcampo004,
            }
            break
    }

    return info
}

function break_bit48_multibndr_info_subcampo001(subcampo_info)
{
    var valor_orig = get_field_break_aux()
    var valor_conv = hex2a(valor_orig)
    var desc

    switch (valor_conv)
    {
        case "011":
            desc = "Pré-Autorização À Vista/Parcelada"
            break

        case "101":
            desc = "Crédito Rotativo"
            break

        case "102":
            desc = "Parcelado Com Juros"
            break

        case "103":
            desc = "Parcelado Sem Juros"
            break

        case "104":
            desc = "IATA À Vista"
            break

        case "105":
            desc = "IATA Parcelado Sem Juros"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    //

    subcampo_info.inline = desc

    return subcampo_info
}

function break_bit48_multibndr_info_subcampo003(subcampo_info)
{
    var valor_orig = get_field_break_aux()
    var valor_conv = hex2a(valor_orig)
    var desc

    switch (valor_conv)
    {
        case "M":
            desc = "CVC2 OK"
            break

        case "N":
            desc = "CVC2 inválido"
            break

        case "P":
            desc = "Emissor não pôde processar o CVC2"
            break

        case "U":
            desc = "Emissor não suporta CVC2"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    //

    subcampo_info.inline = desc

    return subcampo_info
}

function break_bit48_multibndr_info_subcampo004(subcampo_info)
{
    var valor_orig = get_field_break_aux()
    var valor_conv = hex2a(valor_orig)
    var desc

    switch (valor_conv)
    {
        case "PV":
            desc = "Emissor validou o PIN com sucesso"
            break

        case "PI":
            desc = "Emissor não pôde avaliar o PIN (PIN inválido)"
            break

        case "TI":
            desc = "Emissor não pode converter o PIN"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    //

    subcampo_info.inline = desc

    return subcampo_info
}
