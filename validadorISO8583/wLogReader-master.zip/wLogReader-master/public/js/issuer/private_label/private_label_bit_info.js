// privatelabel_bit_info.js

function get_bit_privatelabel(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 55:
            info.break_bit_func = genBreakBit55Ebc
            break

        case 62:
            info.break_bit_func = break_bit62_privatelabel
            break
    }

    return info
}
