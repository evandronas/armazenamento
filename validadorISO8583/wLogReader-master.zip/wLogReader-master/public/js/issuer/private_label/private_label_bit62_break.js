// private_label_bit62_break.js

function break_bit62_privatelabel()
{
    if (msg_break_bit.length == 16) // gamb pra ver se eh o DE62 da ida
    {
        break_bit62_privatelabel_req()
    }

    return 0
}

function break_bit62_privatelabel_req()
{
    var space = 26

    var len
    var valor
    var infodisp

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Indicador",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Número de Parcelas",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Plano de Pagamento",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Número de Ciclos a Pular",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}
