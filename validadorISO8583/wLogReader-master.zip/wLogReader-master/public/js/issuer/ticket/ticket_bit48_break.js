// break_bit48_ticket.js

function break_bit48_ticket()
{
    var info_identificacao = get_field_break_bit(14)
    msg_formatted += get_html_spaces(16) + hex2a(info_identificacao) + get_break_line()

    var tlvinfo = {
        formato: kFMT_HEXA,
        lenTL: 4,
        infoFunc: break_bit48_ticket_info,
        nomeCampo: "ID",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)
}

function break_bit48_ticket_id19(tag_info)
{
    var desc

    switch (hex2a(msg_break_aux))
    {
        case "0":
            desc = "Não"
            break

        case "1":
            desc = "Sim"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit48_ticket_id21(tag_info)
{
    var desc

    switch (hex2a(msg_break_aux))
    {
        case "00":
            desc = "Total"
            break

        case "01":
            desc = "Parcial"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit48_ticket_id32(tag_info)
{
    var desc

    switch (hex2a(msg_break_aux))
    {
        case "04":
            desc = "POS"
            break

        case "05":
            desc = "PDV"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit48_ticket_id51(tag_info)
{
    var desc

    switch (hex2a(msg_break_aux))
    {
        case "007":
            desc = "Chave ZPK Estática"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit48_ticket_id79(tag_info)
{
    var desc

    switch (hex2a(msg_break_aux))
    {
        case "002":
            desc = "3DES"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}
