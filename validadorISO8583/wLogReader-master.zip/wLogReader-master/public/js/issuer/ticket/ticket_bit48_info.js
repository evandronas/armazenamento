// ticket_bit48_info.js

function break_bit48_ticket_info(id)
{
    var info

    switch(id)
    {
        case "0019":
            info = {
                nome: "Indicação PDV Apto Aprovação Saldo Dispoível",
                descFunc: break_bit48_ticket_id19,
            }
            break

        case "0021":
            info = {
                nome: "Indicação Tipo Aprovação",
                descFunc: break_bit48_ticket_id21,
            }
            break

        case "0032":
            info = {
                nome: "Código Tecnologia",
                descFunc: break_bit48_ticket_id32,
            }
            break

        case "0033":
            info = {
                nome: "Situação Transação Compra Off-line",
            }
            break

        case "0038":
            info = {
                nome: "PIN Block Senha Atual (Troca de Senha)",
            }
            break

        case "0039":
            info = {
                nome: "PIN Block Senha Nova (Troca de Senha)",
            }
            break

        case "0040":
            info = {
                nome: "Versão Interface Mensagens",
            }
            break

        case "0047":
            info = {
                nome: "PIN Block Confirmação Senha Nova (Troca de Senha)",
            }
            break

        case "0048":
            info = {
                nome: "NSU Terminal Venda Off-line",
            }
            break

        case "0049":
            info = {
                nome: "Data Terminal Venda Off-line",
            }
            break

        case "0050":
            info = {
                nome: "Hora Terminal Venda Off-line",
            }
            break

        case "0051":
            info = {
                nome: "Tratamento PIN Block",
                descFunc: break_bit48_ticket_id51,
            }
            break

        case "0056":
            info = {
                nome: "Cardholder Name Extended",
            }
            break

        case "0078":
            info = {
                nome: "Expoente Moeda",
            }
            break

        case "0079":
            info = {
                nome: "Tipo Criptografia Utilizada na Senha",
                descFunc: break_bit48_ticket_id79,
            }
            break

        case "0125":
            info = {
                nome: "Issuer Scripts Results",
            }
            break
    }

    return info
}
