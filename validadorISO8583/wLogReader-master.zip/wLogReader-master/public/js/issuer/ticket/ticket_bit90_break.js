// break_bit90_ticket.js

function break_bit90_ticket()
{
    var space = 50

    var pos = 0
    var len
    var value
    var infodisp

    //
    len = 4
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "MsgType Transação Original" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    //
    len = 6
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código Autorização Transação Original" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    //
    len = 10
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Data e Hora Transação Original" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    //
    len = 12
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "NSU Transação Original" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    //
    len = 10
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Zeros" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len
}
