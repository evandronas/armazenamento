// elofull_gen.js

function elofull_desc_tipo_financiamento(valor)
{
    var desc

    switch(valor)
    {
        case "1":
            desc = "Sem Juros"
            break

        case "2":
            desc = "Com Juros/Crediário no Crédito"
            break

        case "3":
            desc = "Crediário no Débito"
            break
    }

    return desc
}
