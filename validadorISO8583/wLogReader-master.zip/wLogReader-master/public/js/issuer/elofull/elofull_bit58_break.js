// elofull_bit58_break.js

function break_bit58_elofull()
{
    var qtdeTab = 16
    var space = 17

    var len
    var value
    var infodisp

    // endereco - 22
    len = 22
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        nomeCampo: "Endereço da Rua",
        nomeCampoSpace: space,
        valorOrig: value,
        convHexa: true,
    }
    genDisplayInfo(infodisp)

    // cep - 9
    if (msg_break_bit.length > 0)
    {
        len = 9
        value = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdeTab,
            nomeCampo: "CEP",
            nomeCampoSpace: space,
            valorOrig: value,
            convHexa: true,
        }
        genDisplayInfo(infodisp)
    }

    // codigo do pais - 3
    if (msg_break_bit.length > 0)
    {
        len = 3
        value = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdeTab,
            nomeCampo: "Código do País",
            nomeCampoSpace: space,
            valorOrig: value,
            convHexa: true,
        }
        genDisplayInfo(infodisp)
    }
}
