// elofull_bit60_break.js

function break_bit60_elofull()
{
    var nome
    var len
    var valor
    var valor_conv
    var desc

    // 1 - Tipo de Terminal
    len = 1
    nome = "Posição 01: Tipo de Terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Terminal com atendimento (EC possui operador para o terminal)"
            break

        case 1:
            desc = "Terminal com autoatendimento (Ex.: Vending Machines)"
            break

        case 2:
            desc = "Sem Terminal (Ex.: URA/Voz/e-Commerce)"
            break

        case 3:
            desc = "Celular (Mobile)"
            break

        case 9:
            desc = "Desconhecido"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 2 - Reservado
    len = 1
    nome = "Posição 02: Reservado"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    desc = undefined
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 3 - Indicador de Localizacao do Terminal
    len = 1
    nome = "Posição 03: Indicador de Localização do Terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "No estabelecimento comercial"
            break

        case 1:
            desc = "Fora estabelecimento comercial (terminal remoto)"
            break

        case 2:
            desc = "Junto ao portador (Ex.: PC nos casos de e-Commerce)"
            break

        case 3:
            desc = "Sem Terminal (Ex.: Voz/URA)"
            break

        case 9:
            desc = "Desconhecido"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 4 - Indicador de presenca do Portador
    len = 1
    nome = "Posição 04: Indicador de Presença do Portador"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(valor_conv)
    {
        case '0':
            desc = "Portador está presente"
            break

        case '1':
            desc = "Portador não presente, não especificado"
            break

        case '2':
            desc = "Portador não presente, Mail/FAX Order"
            break

        case '3':
            desc = "Portador não presente, Telephone Order"
            break

        case '4':
            desc = "Portador não presente, Standing Order/Pagamento recorrente"
            break

        case '5':
            desc = "Eletronic Order (Ex.: e-Commerce)"
            break

        case 'T':
            desc = "Discover Pay Button"
            break

        case '9':
            desc = "Desconhecido"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 5 - Indicador de Presenca do cartao
    len = 1
    nome = "Posição 05: Indicador de Presença do Cartão"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Cartão presente"
            break

        case 1:
            desc = "Cartão não presente"
            break

        case 9:
            desc = "Desconhecido"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 6 - Indicador de Capacidade de captura do cartao
    len = 1
    nome = "Posição 06: Indicador de Capacidade de Captura do Cartão"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Terminal (POS)/Operador não tem capacidade de captura de cartão"
            break

        case 1:
            desc = "Terminal (POS)/Operador tem capacidade de captura de cartão"
            break

        case 9:
            desc = "Desconhecido"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 7 - Indicador de Status da transacao
    len = 1
    nome = "Posição 07: Indicador de Status da Transação"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(valor_conv)
    {
        case '0':
            desc = "Solicitação normal (apresentação original)"
            break

        case '4':
            desc = "Solicitação de pré-autorização"
            break

        case 'P':
            desc = "Envio Dividido/Parcial (Ex.: Envio mediante disponibilidade)"
            break

        case 'R':
            desc = "Pagamento Recorrente"
            break

        case 'A':
            desc = "Re-autorização do valor total (Ex.: após expiração do prazo de Liquidação)"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 8 - Indicador de Seguranca do terminal
    len = 1
    nome = "Posição 08: Indicador de Segurança do Terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "Não há suspeita"
            break

        case 1:
            desc = "Existe suspeita de fraude por parte do EC"
            break

        case 2:
            desc = "Foram verificados os documentos do portador"
            break

        case 9:
            desc = "Desconhecido"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 9 - Reservado
    len = 1
    nome = "Posição 09: Reservado"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    desc = undefined
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 10 - Tipo do POS do Terminal
    len = 1
    nome = "Posição 10: Tipo do POS do Terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(valor_conv)
    {
        case 'M':
            desc = "POS Mobile"
            break

        case 'P':
            desc = "POS"
            break

        case 'T':
            desc = "TEF"
            break

        case '0':
            desc = "Não especificado"
            break

        case '9':
            desc = "Desconhecido"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 11 - Capacidade de entrada do Terminal
    len = 1
    nome = "Posição 11: Capacidade de entrada do Terminal"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)

    switch(valor_conv)
    {
        case '0':
            desc = "Indefinido"
            break

        case '1':
            desc = "Sem Terminal (URA/Voz)"
            break

        case '2':
            desc = "Leitor de trilha magnética"
            break

        case '3':
            desc = "Leitor de código de barras"
            break

        case '4':
            desc = "Leitor OCR"
            break

        case '5':
            desc = "Leitor de CHIP"
            break

        case '6':
            desc = "Digitado"
            break

        case '7':
            desc = "Leitor de trilha e digitado"
            break

        case 'C':
            desc = "Radio Frequency Identification (RFID) – CHIP (Contactless)"
            break

        case 'H':
            desc = "Hibrido – CHIP e Contactless"
            break

        case 'R':
            desc = "Radio Frequency Identification (RFID) – Trilha Magnética"
            break

        case 'S':
            desc = "Secure Eletronic Transaction (SET) com certificado"
            break

        case 'T':
            desc = "Secure Eletronic Transaction (SET) sem certificado"
            break

        case 'U':
            desc = "Channel-encrypted Eletronic Commerce Transaction (SSL)"
            break

        case 'V':
            desc = "Non-secure Eletronic Commerce Transaction"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    display_bit60_elofull(nome, len, valor, valor_conv, desc)


    // 12-13 - Reservado
    len = 2
    nome = "Posição 12/13: Reservado"
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    desc = undefined
    display_bit60_elofull(nome, len, valor, valor_conv, desc)
}

function display_bit60_elofull(nome, len, valor, valor_conv, desc)
{
    fill_html_spaces()
    msg_formatted += padEXT(nome, 58) +  " - " + valor + " [" + valor_conv + "]"

    if (desc)
    {
        msg_formatted += " = " + desc
    }

    msg_formatted += "<br>"
}
