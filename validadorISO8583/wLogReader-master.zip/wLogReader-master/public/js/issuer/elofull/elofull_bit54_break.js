// elofull_bit54_break.js

function break_bit54_elofull()
{
    while(msg_break_bit.length != 0)
    {
        var nome
        var tag_len

        // tipo de conta

        tag_len = 2
        var tipo_conta = get_field_break_bit(tag_len * 2)
        var tipo_conta_conv = hex2a(tipo_conta)
        // console.log("tipo conta [%s] tipo conta conv [%s]", tipo_conta, tipo_conta_conv)

        // tipo de valor
        tag_len = 2
        var tipo_valor = get_field_break_bit(tag_len * 2)
        var tipo_valor_conv = hex2a(tipo_valor)
        var desc_tipo_valor
        switch (tipo_valor_conv)
        {
            case "02":
                desc_tipo_valor = "Saldo Disponivel"
                break

            case "56":
                desc_tipo_valor = "Valor Original"
                break

            case "64":
                desc_tipo_valor = "Valor de Entrada"
                break

            case "98":
                desc_tipo_valor = "Taxa de Embarque"
                break

            default:
                desc_tipo_valor = "Valor não mapeado"
                break
        }
        // console.log("tipo valor [%s] tipo valor conv [%s] desc [%s]", tipo_valor, tipo_valor_conv, desc_tipo_valor)

        // codigo da moeda
        tag_len = 3
        var cod_moeda = get_field_break_bit(tag_len * 2)
        var cod_moeda_conv = hex2a(cod_moeda)
        // console.log("codigo moeda [%s] codigo moeda conv [%s]", cod_moeda, cod_moeda_conv)

        // tipo da transacao
        tag_len = 1
        var tipo_tran = get_field_break_bit(tag_len * 2)
        var tipo_tran_conv = hex2a(tipo_tran)
        var desc_tipo_tran
        switch (tipo_tran_conv)
        {
            case "C":
                // desc_tipo_tran = "Crédito"
                desc_tipo_tran = "Credit (+ Amount)"
                break

            case "D":
                // desc_tipo_tran = "Débito"
                desc_tipo_tran = "Debit (- Amount)"
                break

            default:
                desc_tipo_tran = "Valor não mapeado"
                break
        }
        // console.log("tipo tran [%s] tipo tran conv [%s] desc [%s]", tipo_tran, tipo_tran_conv, desc_tipo_tran)

        // valor de saldo
        tag_len = 12
        var valor_saldo = get_field_break_bit(tag_len * 2)
        var valor_saldo_conv = hex2a(valor_saldo)
        var valor_saldo_money = formatMoney(valor_saldo_conv)
        // console.log("valor saldo [%s] valor saldo conv [%s] valor saldo money [%s]", valor_saldo, valor_saldo_conv, valor_saldo_money)

        //

        fill_html_spaces()
        msg_formatted += desc_tipo_valor + "<br>"

        display_bit54_elofull(20, "Tipo de Conta", tipo_conta, tipo_conta_conv)
        display_bit54_elofull(20, "Tipo de Valor", tipo_valor, tipo_valor_conv, desc_tipo_valor)
        display_bit54_elofull(20, "Código da Moeda", cod_moeda, cod_moeda_conv)
        display_bit54_elofull(20, "Tipo de Transação", tipo_tran, tipo_tran_conv, desc_tipo_tran)
        display_bit54_elofull(20, "Valor", valor_saldo, valor_saldo_money)
    }
}

function display_bit54_elofull(qtde_tab, nome, valor, valor_conv, desc)
{
    fill_html_spaces(qtde_tab)
    msg_formatted += padEXT(nome, 18) + " - " + valor + " [" + valor_conv + "]"

    if (desc)
    {
        msg_formatted += " = " + desc
    }

    fill_break_line()
}
