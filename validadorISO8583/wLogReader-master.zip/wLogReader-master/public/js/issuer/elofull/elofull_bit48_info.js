// elofull_bit48_info.js

function break_bit48_elofull_info(tipo_subcampo, val_subcampo)
{
    // Parametros de entrada
    // tipo_subcampo        - nome do subcampo em hexa
    // cont_subcampo        - valor do subcampo em hexa

    var info
    var tipo_subcampo_conv = hex2a(tipo_subcampo)
    var val_subcampo_conv = hex2a(val_subcampo)

    switch (tipo_subcampo_conv)
    {
        case "CNP":
            info = {
                nome: "CNPJ/CPF",
            }
            break

        case "CDT":
            info = {
                nome: "Cinco dígitos trilha 1",
            }
            break

        case "PRD":
            info = {
                nome: "Produto",
                break_func: break_bit48_elofull_info_PRD,
            }
            break

        case "RSP":
            info = {
                nome: "Origem Resposta Autorização",
                break_func: break_bit48_elofull_info_RSP,
            }
            break

        case "VPR":
        case "SVA":
        case "SVB":
            info = {
                nome: "Informações PCJ/Crediário",
                break_func: break_bit48_elofull_info_VPR_SVA_SVB,
            }
            break

        case "VPP":
        case "SPA":
        case "SPB":
            info = {
                nome: "Informações PCJ/Crediário",
                break_func: break_bit48_elofull_info_VPP_SPA_SPB,
            }
            break

        case "VPS":
            info = {
                nome: "Venda Parcelada",
                break_func: break_bit48_elofull_info_VPS,
            }
            break

        case "PRE":
            info = {
                nome: "Indicador Pré-Autorização",
                break_func: break_bit48_elofull_info_PRE,
            }
            break

        case "BAN":
            info = {
                nome: "NRID",
                break_func: break_bit48_elofull_info_BAN,
            }
            break
    }

    return info
}
