// elofull_bit126_break.js

function break_bit126_elofull()
{
    var space = 15

    var len
    var valor
    var valor_conv
    var desc
    var infodisp

    // Identificador
    len = 1
    valor = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor)
    switch(parseInt(valor_conv, 10))
    {
        case 0:
            desc = "O valor do CVE2 é deliberadamente ignorado ou não fornecido pelo Estabelecimento Comercial"
            break

        case 1:
            desc = "O valor do CVE2 está presente"
            break

        case 2:
            desc = "O valor do CVE2 está no cartão, mas ilegível"
            break

        case 9:
            desc = "O portador alega que não há CVE2 impresso no cartão"
            break

        default:
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificador",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // CVC2
    len = 4
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CVC2",
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
}
