// break_bit62_elofull.js

function break_bit62_elofull()
{
    // console.log("break_bit62_elofull")
    while(msg_break_bit.length != 0)
    {
        // pegando o "*"
        var separador = get_field_break_bit(2)
        // console.log('separador - ' + separador)

        // pegando o tipo de subcampo
        var tipo_subcampo = get_field_break_bit(6)
        var tipo_subcampo_conv = hex2a(tipo_subcampo)

        // pegando o tamanho do subcampo
        var len_subcampo_hexa = get_field_break_bit(6)
        var len_subcampo_conv = hex2a(len_subcampo_hexa)
        var len_subcampo = parseInt(len_subcampo_conv, 10)

        // pegando o conteudo do subcampo
        var val_subcampo = get_field_break_bit(len_subcampo * 2)
        var val_subcampo_conv = hex2a(val_subcampo)

        //

        // pegando informacao do subcampo
        var subcampo_info = break_bit62_elofull_info(tipo_subcampo, val_subcampo)

        if (subcampo_info)
        {
            if (subcampo_info.break_func)
            {
                msg_break_aux = val_subcampo
                subcampo_info = subcampo_info.break_func(subcampo_info)
            }
        }

        //

        fill_html_spaces()
        msg_formatted += tipo_subcampo_conv + " - " + "V" + len_subcampo_conv + " - " + val_subcampo

        if (subcampo_info && !subcampo_info.nao_conv)
        {
            msg_formatted += mostrarColchete(val_subcampo_conv)
        }

        // // se o valor for pra colocar na mesma linha, estara na propriedade inline
        if (subcampo_info && subcampo_info.inline)
        {
            msg_formatted += " = " + subcampo_info.inline
        }

        // nome do subcampo
        if (subcampo_info && subcampo_info.nome)
        {
            msg_formatted += " (" + subcampo_info.nome + ")"
        }

        // se o valor for pra colocar em outra linha, estara na propriedade newline
        if (subcampo_info && subcampo_info.newline)
        {
            fill_break_line()
            msg_formatted += subcampo_info.newline
        }
        else
        {
            fill_break_line()
        }
    }
}
