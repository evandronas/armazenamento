// elofull_bit122_break.js

function break_bit122_elofull()
{
    var space = 31

    var len
    var valor
    // var valor_conv
    var infodisp

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    var tipo_aut = hex2a(valor)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Tipo de Autenticação (1-2) (2)",
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
        descFunc: break_bit122_elofull_tipo_autenticacao,
    }
    genDisplayInfo(infodisp)

    //
    len = 40
    valor = get_field_break_bit(len * 2)
    msg_break_aux = valor
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CAVV (3-42) (40)",
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)

    space = 48
    var qtdetab = 50
    if (tipo_aut == "02")
    {
        // ainda nao tem exemplo
    }
    else if (tipo_aut == "03")
    {
        //
        len = 4
        valor = get_field_break_aux(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdetab,
            nomeCampo: "ATC (3-6)" + mostrarParentese(len),
            nomeCampoSpace: space,
            valorOrig: valor,
            convHexa: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 2
        valor = get_field_break_aux(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdetab,
            nomeCampo: "Indicador de chave do CAVV (7-8)" + mostrarParentese(len),
            nomeCampoSpace: space,
            valorOrig: valor,
            convHexa: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 4
        valor = get_field_break_aux(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdetab,
            nomeCampo: "CVV2 Output (9-12)" + mostrarParentese(len),
            nomeCampoSpace: space,
            valorOrig: valor,
            convHexa: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 4
        valor = get_field_break_aux(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdetab,
            nomeCampo: "Número Imprevisível (13-16)" + mostrarParentese(len),
            nomeCampoSpace: space,
            valorOrig: valor,
            convHexa: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 16
        valor = get_field_break_aux(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdetab,
            nomeCampo: "Número de Rastreio da Autenticação (17-32)" + mostrarParentese(len),
            nomeCampoSpace: space,
            valorOrig: valor,
            convHexa: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 1
        valor = get_field_break_aux(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdetab,
            nomeCampo: "Ação da Versão (33-33)" + mostrarParentese(len),
            nomeCampoSpace: space,
            valorOrig: valor,
            convHexa: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 1
        valor = get_field_break_aux(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdetab,
            nomeCampo: "Ação de Autenticação (34-34)" + mostrarParentese(len),
            nomeCampoSpace: space,
            valorOrig: valor,
            convHexa: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 8
        valor = get_field_break_aux(len * 2)
        infodisp = {
            display: true,
            qtdeTab: qtdetab,
            nomeCampo: "RUF (35-42)" + mostrarParentese(len),
            nomeCampoSpace: space,
            valorOrig: valor,
            convHexa: true,
        }
        genDisplayInfo(infodisp)   
    }
}

function break_bit122_elofull_tipo_autenticacao(value)
{
    var desc

    switch (value)
    {
        case "02":
            desc = "Programa 3D-Secure Elo"
            break

        case "03":
            desc = "Autenticação In-App"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}
