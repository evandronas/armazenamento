// elofull_bit56_break.js

function break_bit56_elofull()
{
    while(msg_break_bit.length != 0)
    {
        // tag
        var tag_id = get_field_break_bit(2)
        // console.log("tag [%s]", tag_id)

        // len
        var tag_len = get_field_break_bit(4)
        var tag_len_conv = parseInt(tag_len, 16)
        // console.log("tag_len [%s] tag_len_conv [%s]", tag_len, tag_len_conv)

        // value
        var tag_value = get_field_break_bit(tag_len_conv * 2)
        // console.log("tag value [%s]", tag_value)

        //

        var tag_info = break_bit56_elofull_info(tag_id)

        if (tag_info.break_func)
        {
            msg_break_aux = tag_value
            tag_info = tag_info.break_func(tag_info)
        }

        //

        fill_html_spaces()
        msg_formatted += "TAG " + tag_id + " - " + "V" + tag_len_conv + " - " + tag_value

        // se o valor for pra colocar na mesma linha, estara na propriedade inline
        if (tag_info.inline)
        {
            msg_formatted += " = " + tag_info.inline
        }

        // nome do subcampo
        if (tag_info.nome)
        {
            msg_formatted += mostrarParentese(tag_info.nome)
        }

        // se o valor for pra colocar em outra linha, estara na propriedade newline
        if (tag_info.newline)
        {
            fill_break_line()
            msg_formatted += tag_info.newline
        }
        else
        {
            fill_break_line()
        }
    }
}

function break_bit56_elofull_tag01(info)
{
    var display = ""

    while(msg_break_aux.length != 0)
    {
        // tag
        var tag_id = get_field_break_aux(2)
        // console.log("tag [%s]", tag_id)

        // len
        var tag_len = get_field_break_aux(2)
        var tag_len_conv = parseInt(tag_len, 16)
        // console.log("tag_len [%s] tag_len_conv [%s]", tag_len, tag_len_conv)

        // value
        var tag_value = get_field_break_aux(tag_len_conv * 2)
        var tag_value_conv = hex2a(tag_value)
        // console.log("tag value [%s]", tag_value)

        //

        var tag_info = break_bit56_elofull_tag01_info(tag_id)

        //

        var dinfo = {
            qtdeTab: 31,
            nomeCampo: "TAG " + tag_id,
            lenV: tag_len_conv,
            valorOrig: tag_value,
            valorConv: tag_value_conv,
            nome: tag_info.nome,
        }
        display += genDisplayInfo(dinfo)
    }

    info.newline = display

    return info
}
