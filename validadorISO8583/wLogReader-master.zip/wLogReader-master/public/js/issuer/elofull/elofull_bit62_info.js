// elofull_bit62_info.js

function break_bit62_elofull_info(tipo_subcampo, val_subcampo)
{
    // Parametros de entrada
    // tipo_subcampo        - nome do subcampo em hexa
    // cont_subcampo        - valor do subcampo em hexa

    var info
    var tipo_subcampo_conv = hex2a(tipo_subcampo)
    var val_subcampo_conv = hex2a(val_subcampo)

    switch (tipo_subcampo_conv)
    {
        case "TID": // 1
            info = {
                nome: "Dados do TID",
            }
            break

        case "DCA": // 2
            info = {
                nome: "Dados do Código de Autenticação",
            }
            break

        case "RVA": // 3
            info = {
                nome: "Resultado de validação de código de autenticação",
            }
            break

        case "TPJ": // 4
            info = {
                nome: "CNPJ do Comprador",
            }
            break

        case "TPF": // 5
            info = {
                nome: "CPF do Comprador",
            }
            break

        case "ECI": // 6
            info = {
                nome: "Indicador de Comércio Eletrônico",
                break_func: break_bit62_elofull_info_ECI,
            }
            break

        case "CAE": // 7
            info = {
                nome: "Código de Autorização Elo Comércio Eletrônico (CAEE)",
                nao_conv: true,
            }
            break
    }

    return info
}

function break_bit62_elofull_info_ECI(info)
{
    var desc
    var valor_conv = hex2a(msg_break_aux)

    switch (valor_conv)
    {
        case "00":
            desc = "Desconhecido/Não Especificado/Loja não participa do programa"
            break

        case "01":
            desc = "Transação não é uma transação de e-commerce"
            break

        case "04":
            desc = "Transação com autenticação In App"
            break

        case "05":
            desc = "Transação Autenticada"
            break

        case "06":
            desc = "Transação Não Autenticada (Estabelecimento participa do programa mas o cartão ou emissor não participam do programa)"
            break

        case "07":
            desc = "Transação Não Autenticada, mas com proteção de dados mas não pelo Compra Segura Elo (Estabelecimento não participa do programa)"
            break
    }

    if (desc)
    {
        info.inline = desc
    }

    return info
}
