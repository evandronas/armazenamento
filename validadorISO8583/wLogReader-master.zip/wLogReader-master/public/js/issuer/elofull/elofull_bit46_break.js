// elofull_bit46_break.js

function break_bit46_elofull()
{
    if ((msg_break_bit.length / 2) == 28)
    {
        break_bit46_elofull_layout2()
    }
}

function break_bit46_elofull_layout2()
{
    var space = 72
    var pos = 0

    // RUF
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "RUF " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Código de resultado CVE2
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código de resultado CVE2 " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Fonte da autorização
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Fonte da autorização " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Limite Floor/Stand-in
    len = 4
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Limite Floor/Stand-in " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Campo com erro
    len = 3
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Campo com erro " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // RUF
    len = 3
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "RUF " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Código de resultado CVE/DCVE/iCVE
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código de resultado CVE/DCVE/iCVE " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Código de resultado do criptograma
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código de resultado do criptograma " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Código de resultado do Terminal Verification Results (TVR)
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código de resultado do Terminal Verification Results (TVR) " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Código de resultado do Card Verification Results (CVR)
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código de resultado do Card Verification Results (CVR) " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // RUF
    len = 10
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "RUF " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    // Código de Resposta do CAVV
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código de Resposta do CAVV " + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        convHexa: true,
    }
    genDisplayInfo(infodisp)
    pos += len
}
