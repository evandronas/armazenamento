// elofull_bit56_info.js

function break_bit56_elofull_info(tag_id)
{
    var info = {}

    switch(tag_id)
    {
        case "01":
            info = {
                break_func: break_bit56_elofull_tag01,
            }
            break
    }

    return info
}

function break_bit56_elofull_tag01_info(tag_id)
{
    var info = {}

    switch(tag_id)
    {
        case "01":
            info = {
                nome: "Payment Account Reference (PAR)"
            }
            break
    }

    return info
}
