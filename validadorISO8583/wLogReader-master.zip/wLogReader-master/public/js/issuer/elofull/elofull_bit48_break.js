// break_bit48_elofull.js

function break_bit48_elofull()
{
    while(msg_break_bit.length != 0)
    {
        // pegando o "*"
        var separador = get_field_break_bit(2)
        // console.log('separador - ' + separador)

        // pegando o tipo de subcampo
        var tipo_subcampo = get_field_break_bit(6)
        var tipo_subcampo_conv = hex2a(tipo_subcampo)

        // pegando o tamanho do subcampo
        var len_subcampo_hexa = get_field_break_bit(6)
        var len_subcampo_conv = hex2a(len_subcampo_hexa)
        var len_subcampo = parseInt(len_subcampo_conv, 10)

        // pegando o conteudo do subcampo
        var val_subcampo = get_field_break_bit(len_subcampo * 2)
        var val_subcampo_conv = mostrarColchete(hex2a(val_subcampo))

        //

        // pegando informacao do subcampo
        var subcampo_info = break_bit48_elofull_info(tipo_subcampo, val_subcampo)

        if (subcampo_info)
        {
            if (subcampo_info.break_func)
            {
                msg_break_aux = val_subcampo
                subcampo_info = subcampo_info.break_func(subcampo_info)
            }
        }

        //

        fill_html_spaces()
        msg_formatted += tipo_subcampo_conv + " - " + "V" + len_subcampo_conv + " - " + val_subcampo + val_subcampo_conv

        // se o valor for pra colocar na mesma linha, estara na propriedade inline
        if (subcampo_info && subcampo_info.inline)
        {
            msg_formatted += " = " + subcampo_info.inline
        }

        // nome do subcampo
        if (subcampo_info && subcampo_info.nome)
        {
            msg_formatted += " (" + subcampo_info.nome + ")"
        }

        // se o valor for pra colocar em outra linha, estara na propriedade newline
        if (subcampo_info && subcampo_info.newline)
        {
            fill_break_line()
            msg_formatted += subcampo_info.newline
        }
        else
        {
            fill_break_line()
        }
    }
}

function break_bit48_elofull_info_PRD(info)
{
    var desc
    var valor_conv = hex2a(msg_break_aux)

    switch (valor_conv)
    {
        case "070":
            desc = "Crédito"
            break

        case "071":
            desc = "Débito À Vista"
            break

        case "072":
            desc = "PSJ"
            break

        case "330":
            desc = "Crediário no Crédito"
            break

        case "377":
            desc = "Carnê e Fatura"
            break
    }

    if (desc)
    {
        info.inline = desc
    }

    return info
}

function break_bit48_elofull_info_RSP(info)
{
    var desc
    var valor_conv = hex2a(msg_break_aux)

    switch (valor_conv)
    {
        case "0":
            desc = "Elo"
            break

        case "1":
            desc = "Emissor"
            break

        case "2":
            desc = "Stand in Elo"
            break

        case "3":
            desc = "Elo Áquila"
            break
    }

    if (desc)
    {
        info.inline = desc
    }

    return info
}

function break_bit48_elofull_info_VPR_SVA_SVB(info)
{
    var qtdeTab = 29
    var space = 38

    var len
    var valor
    var valor_conv
    var formatted = ""

    //
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Tipo de Financiamento",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: elofull_desc_tipo_financiamento(valor_conv)
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Valor da Tarifa",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Valor dos Tributos",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Valor dos Seguros",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Valor do Pagamento a Terceiros",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Valor dos Pagamentos de Registros",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 8
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Valor Total calculado pelo Emissor",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 6
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Data de Pagamento da Primeira Parcela",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Quantidade de Parcelas",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 5
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Taxa Mensal de Juros",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatPct: true,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Taxa de Juros Anualizada (CET)",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatPct: true,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Valor da Parcela",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatMoney: true,
    }
    formatted += genDisplayInfo(infodisp)

    //

    info.newline = formatted

    return info
}

function break_bit48_elofull_info_VPP_SPA_SPB(info)
{
    var qtdeTab = 29
    var space = 44

    var len
    var valor
    var valor_conv
    var formatted = ""

    //
    len = 1
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Tipo de Financiamento",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        desc: elofull_desc_tipo_financiamento(valor_conv)
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 3
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Percentual do Valor da Tarifa",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatPct: true,
        // lenDecimal: 1,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 3
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Percentual do Valor dos Tributos",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatPct: true,
        // lenDecimal: 1,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 3
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Percentual do Valor dos Seguros",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatPct: true,
        // lenDecimal: 1,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 3
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Percentual de Outras Despesas",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatPct: true,
        // lenDecimal: 1,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 3
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Percentual da Soma das Despesas Vinculadas",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatPct: true,
        // lenDecimal: 1,
    }
    formatted += genDisplayInfo(infodisp)

    //
    len = 4
    valor = get_field_break_aux(len * 2)
    valor_conv = hex2a(valor)
    infodisp = {
        qtdeTab: qtdeTab,
        nomeCampo: "Percentual do Valor Liberado ao Vendedor",
        nomeCampoSpace: space,
        valorOrig: valor,
        valorConv: valor_conv,
        formatPct: true,
        // lenDecimal: 1,
    }
    formatted += genDisplayInfo(infodisp)

    //

    info.newline = formatted

    return info
}

function break_bit48_elofull_info_VPS(info)
{
    // console.log("break_bit48_elofull_info_VPS")
    // console.log("msg_break_aux [%s] len [%s]", msg_break_aux, msg_break_aux.length)

    var qtdeTab = 29
    var space = 44

    var len
    var valor
    var valor_conv
    var formatted = ""

    if ((msg_break_aux.length / 2) == 3)
    {
        space = 24
        //
        len = 1
        valor = get_field_break_aux(len * 2)
        valor_conv = hex2a(valor)
        infodisp = {
            qtdeTab: qtdeTab,
            nomeCampo: "Tipo de Financiamento",
            nomeCampoSpace: space,
            valorOrig: valor,
            valorConv: valor_conv,
            desc: elofull_desc_tipo_financiamento(valor_conv)
        }
        formatted += genDisplayInfo(infodisp)

        //
        len = 2
        valor = get_field_break_aux(len * 2)
        valor_conv = hex2a(valor)
        infodisp = {
            qtdeTab: qtdeTab,
            nomeCampo: "Quantidade de Parcelas",
            nomeCampoSpace: space,
            valorOrig: valor,
            valorConv: valor_conv,
        }
        formatted += genDisplayInfo(infodisp)

        //

        info.newline = formatted
    }

    return info
}

function break_bit48_elofull_info_PRE(info)
{
    var desc
    var valor_conv = hex2a(msg_break_aux)

    switch (valor_conv)
    {
        case "01":
            desc = "Solicitação Inicial de pré-autorização"
            break

        case "02":
            desc = "Solicitação de Incremento de Valor"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    if (desc)
    {
        info.inline = desc
    }

    return info
}

function break_bit48_elofull_info_BAN(info)
{
    var nrid_orig = msg_break_aux.substr(20, 30)
    var nrid_conv = hex2a(nrid_orig)
    // console.log("break_bit48_elofull_info_BAN() - nrid_orig [%s] nrid_conv [%s]", nrid_orig, nrid_conv)

    nrid_formatted = get_html_spaces(29) + "NRID: " + nrid_orig + mostrarColchete(nrid_conv) + get_break_line()

    info.newline = nrid_formatted

    return info
}
