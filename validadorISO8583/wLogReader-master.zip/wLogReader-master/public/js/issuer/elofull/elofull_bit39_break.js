// elofull_bit39_break.js

function break_bit39_elofull()
{
    var desc
    var valor = get_field_break_bit()
    var valor_conv = hex2a(valor)

    switch (valor_conv)
    {
        case "00":
            desc = "Aprovada"
            break

        case "01":
            desc = "Consultar Adquirente – Referida"
            break

        case "02":
            desc = "Consultar Adquirente - Referida especial"
            break

        case "03":
            desc = "Erro no cadastramento do código do estabelecimento no arquivo de configuração"
            break

        case "04":
            desc = "Transação Negada, Refazer a transação. Persistindo entrar em contato com a Cielo"
            break

        case "05":
            desc = "Transação negada - Genérica, Refazer a transação. Persistindo entrar em contato com a Cielo"
            break

        case "06":
            desc = "Consultar Adquirente, Refazer a transação. Persistindo entrar em contato com a Cielo"
            break

        case "07":
            desc = "Transação negada - Reter cartão - Condições especiais"
            break

        case "10":
            desc = "Transação com Aprovação Parcial"
            break

        case "12":
            desc = "Transação Inválida, Refazer a transação. Persistindo confirmar com a Cielo se ela está apta a executar a transação"
            break

        case "13":
            desc = "Valor da transação Inválida. Refazer a transação confirmando os dados informados. Persistindo entrar em contato com a Cielo"
            break

        case "14":
            desc = "Cartão inválido. O cartão não compatível com Cielo ou problema na leitora de cartão magnético"
            break

        case "19":
            desc = "A Cielo não pode autorizar transações neste momento, Refazer a transação. Persistindo entrar em contato com a Cielo"
            break

        case "23":
            desc = "Valor da prestação inválido, fora do permitido pelo Emissor"
            break

        case "28":
            desc = "Consulte adquirente - Arquivo temporariamente indisponível"
            break

        case "30":
            desc = "Erro de formato em algum campo específico. *Vide detalhe do campo no bit 48"
            break

        case "41":
            desc = "Transação negada – Problema cartão, Persistindo entrar em contato com a Cielo"
            break

        case "43":
            desc = "Transação negada – Problema cartão, Persistindo entrar em contato com a Cielo"
            break

        case "51":
            desc = "Saldo insuficiente. O saldo do cliente ou limite de crédito não é suficiente para efetuar o pagamento solicitado"
            break

        case "53":
            desc = "Cartão Poupança inválido, Verificar cartão. Persistindo entrar em contato com a Cielo"
            break

        case "54":
            desc = "Cartão vencido. O cartão está com a data de validade vencida"
            break

        case "55":
            desc = "Senha inválida. A senha digitada pelo cliente não confere"
            break

        case "57":
            desc = "Transação não permitida para este cartão, Persistindo entrar em contato com a Cielo"
            break

        case "58":
            desc = "Cliente não possui contrato junto ao emissor para operação com o produto"
            break

        case "59":
            desc = "Valor acima do máximo permitido pelo emissor"
            break

        case "60":
            desc = "Erro Genérico. Problema na mensagem da aplicação"
            break

        case "61":
            desc = "Elo negou a autorização. Excedeu limite para a atividade na Elo e o Banco emissor está fora do ar ou não respondeu a tempo"
            break

        case "62":
            desc = "Transação negada - cartão restrito - Doméstico"
            break

        case "63":
            desc = "Transação negada - Violação de Segurança"
            break

        case "64":
            desc = "Valor abaixo do mínimo permitido pelo emissor"
            break

        case "74":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "75":
            desc = "Senha bloqueada. Foi excedido o número de tentativas de digitação da senha"
            break

        case "78":
            desc = "Cartão novo não desbloqueado pelo portador junto ao emissor"
            break

        case "81":
            desc = "Inicializar o POS"
            break

        case "82":
            desc = "Cartão inválido"
            break

        case "85":
            desc = "Inicializar o POS"
            break

        case "86":
            desc = "Inicializar o POS"
            break

        case "90":
            desc = "Erro na criptografia dukpt, contate help desk Cielo"
            break

        case "91":
            desc = "Instituição temporariamente fora do ar. A instituição que autoriza a transação não pode atender no momento"
            break

        case "93":
            desc = "Transação negada - Violação de regras da Cielo"
            break

        case "96":
            desc = "Consulte Adquirente - Falha no sistema da Cielo"
            break

        case "97":
            desc = "Valor não permitido para esta transação"
            break

        case "AC":
            desc = "Cartão de Débito sendo usado como crédito, Utilize a função de débito"
            break

        case "AD":
            desc = "Verifique se os campos obriga senha e solicita password estão habilitados"
            break

        case "AF":
            desc = "Realize a transação novamente e se persistir abra o evento 2534 na Cielo"
            break

        case "AL":
            desc = "Banco não opera com produtos: PC Conectado, Troco Fácil"
            break

        case "B8":
            desc = "Via do cartão inválida"
            break

        case "BD":
            desc = "Realize a transação novamente e se persistir abra o evento 2534 na Cielo"
            break

        case "BE":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "BI":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "BL":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "BM":
            desc = "Precisamos identificar se o problema está na leitora ou no cartão, devemos realizar procedimentos para Leitora"
            break

        case "BN":
            desc = "Cartão Bloqueado, Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "BO":
            desc = "Realize a transação novamente e se persistir abra o evento 2534 na Cielo"
            break

        case "BP":
            desc = "Portador deverá consultar o emissor e informar o código"
            break

        case "BQ":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "BT":
            desc = "Problemas com Saldo, Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "BW":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "CF":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "CG":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "EA":
            desc = "Não houve habilitação da parcela"
            break

        case "EB":
            desc = "Excedeu a quantidade máxima de parcelas - cdc"
            break

        case "EE":
            desc = "Quantidade de Parcelas Inválida, fora do padrão do produto"
            break

        case "EG":
            desc = "Valor da primeira parcela inválida"
            break

        case "EH":
            desc = "Valor informado inválido"
            break

        case "EI":
            desc = "Venceu a data de pagamento da primeira parcela"
            break

        case "EJ":
            desc = "Excedeu limite de pré-datado"
            break

        case "EK":
            desc = "Produto não habilitado no estabelecimento comercial"
            break

        case "FC":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro e abrir o 2534 na Cielo"
            break

        case "FM":
            desc = "Verificação da obrigatoriedade da utilização de chip"
            break

        case "HJ":
            desc = "Portador deverá ligar para a central de atendimento"
            break

        // case "KA":
        //     desc = "??"
        //     break

        // case "KB":
        //     desc = "??"
        //     break

        // case "KE":
        //     desc = "??"
        //     break

        case "M1":
            desc = "Financiamento não aprovado - Projeto Agro conta corrente"
            break

        case "N7":
            desc = "Código de segurança inválido"
            break

        case "P1":
            desc = "Alcançou o número máximo de pré-autorização"
            break

        case "P2":
            desc = "Pré Autorização Pendente"
            break

        case "P3":
            desc = "Pré Autorização não pode ser cancelada, já foi consumida"
            break

        case "P4":
            desc = "Para Pré Autorização, o cancelamento só pode ser feito no mesmo dia"
            break

        case "R1":
            desc = "Não Autorizada – Transação recorrente"
            break

        case "RT":
            desc = "Portador deverá consultar o emissor, informando a mensagem de erro"
            break

        case "T1":
            desc = "Saque não permitido"
            break

        case "U3":
            desc = "Formatação da mensagem ou tipo de transação inválido"
            break

        case "Z1":
            desc = "Negada Off-line sem interferência do emissor"
            break

        case "Z3":
            desc = "Negada Off-line"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    msg_formatted += " = " + desc

    return 0
}
