// elpfull_bit_info.js

function get_bit_elofull(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 39:
            info.break_bit_func_inline = break_bit39_elofull
            break

        case 46:
            info.break_bit_func = break_bit46_elofull
            break

        case 48:
            info.break_bit_func = break_bit48_elofull
            break

        case 52:
            info.len = 8
            break

        case 54:
            info.break_bit_func = break_bit54_elofull
            break

        case 55:
            info.nao_conv = true
            info.break_bit_func = genBreakBit55Puro
            break

        case 56:
            info.nao_conv = true
            info.break_bit_func = break_bit56_elofull
            break

        case 58:
            info.break_bit_func = break_bit58_elofull
            break

        case 60:
            info.break_bit_func = break_bit60_elofull
            break

        case 62:
            info.break_bit_func = break_bit62_elofull
            break

        case 90:
            info.break_bit_func = gen_bit90_break_hexa
            info.paramArray = ["mti", "stan", "hora", "data", "codaut", "filler"]
            break

        case 122:
            info.break_bit_func = break_bit122_elofull
            break

        case 126:
            info.break_bit_func = break_bit126_elofull
            break
    }

    return info
}
