// voucher_bit90_break.js

function break_bit90_voucher()
{
    var obj = {
        formato: kFMT_HEXA,
        campos: [
            {
                nome: kDE90_MSGTYPE,
                len: 4,
            },
            {
                nome: kDE90_STAN,
                len: 6,
            },
            {
                nome: kDE90_DATA,
                len: 4,
            },
            {
                nome: kDE90_HORA,
                len: 6,
            },
            {
                nome: kDE90_IDENT_ACQ,
                len: 8,
            },
            {
                nome: kDE90_RES,
                len: 14,
            }
        ],
        space: 43,
    }
    gen_bit90_break2(obj)
}
