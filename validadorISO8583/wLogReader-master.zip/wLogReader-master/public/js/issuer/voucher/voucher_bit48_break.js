// break_bit48_voucher.js

function break_bit48_voucher()
{
    // objetivo é quebrar o DE48 com as informações do frota
    // console.log("break_bit48_voucher - inicio")
    // console.log("msg_break_bit length [%d]", msg_break_bit.length)

    if (msg_break_bit.length != 82) // tamanho normal - 41 (vezes 2)
    {
        console.log("break_bit48_voucher - tamanho do DE48 diferente de 82 - [%d]", msg_break_bit.length)
        return
    }

    while(msg_break_bit.length != 0)
    {
        // pegando o identificador 309
        var identificador = get_field_break_bit(6)
        var identificador_conv = hex2a(identificador)
        // console.log("identificador [%s] identificador conv [%s]", identificador, identificador_conv)
        formatar_bit48_voucher("Identificador", identificador, identificador_conv)

        // codigo do veiculo
        var cod_veiculo = get_field_break_bit(16)
        var cod_veiculo_conv = hex2a(cod_veiculo)
        // console.log("codigo veiculo [%s] codigo veiculo conv [%s]", cod_veiculo, cod_veiculo_conv)
        formatar_bit48_voucher("Código do Veículo", cod_veiculo, cod_veiculo_conv)

        // codigo do condutor
        var cod_condutor = get_field_break_bit(16)
        var cod_condutor_conv = hex2a(cod_condutor)
        // console.log("codigo condutor [%s] codigo condutor conv [%s]", cod_condutor, cod_condutor_conv)
        formatar_bit48_voucher("Código do Condutor", cod_condutor, cod_condutor_conv)

        // codigo do servico
        var cod_servico = get_field_break_bit(4)
        var cod_servico_conv = hex2a(cod_servico)
        // console.log("codigo servico [%s] codigo servico conv [%s]", cod_servico, cod_servico_conv)
        formatar_bit48_voucher("Código do Serviço", cod_servico, cod_servico_conv)

        // codigo do produto
        var cod_produto = get_field_break_bit(4)
        var cod_produto_conv = hex2a(cod_produto)
        // console.log("codigo produto [%s] codigo produto conv [%s]", cod_produto, cod_produto_conv)
        formatar_bit48_voucher("Código do Produto", cod_produto, cod_produto_conv)

        // litragem / QTD
        var litragem = get_field_break_bit(16)
        var litragem_conv = hex2a(litragem)
        // console.log("litragem [%s] litragem conv [%s]", litragem, litragem_conv)
        formatar_bit48_voucher("Litragem/QTD", litragem, litragem_conv)

        // kilometragem
        var km = get_field_break_bit(20)
        var km_conv = hex2a(km)
        // console.log("km [%s] km conv [%s]", km, km_conv)
        formatar_bit48_voucher("Kilometragem", km, km_conv)
    }
}

function formatar_bit48_voucher(nome, valor_hexa, valor_conv)
{
    fill_html_spaces()
    msg_formatted += padEXT(nome, 18) + " - " + valor_hexa + " [" + valor_conv + "]" + "<br>"
}
