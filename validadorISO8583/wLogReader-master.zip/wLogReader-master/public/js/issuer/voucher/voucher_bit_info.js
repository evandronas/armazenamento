// voucher_bit_info.js

function get_bit_voucher(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 42:
            info.custom_format = format_bit42_voucher
            break

        case 48:
            info.break_bit_func = break_bit48_voucher
            break

        case 55:
            info.break_bit_func = genBreakBit55Ascii
            break

        case 61:
            info.nao_conv = true
            break

        case 90:
            info.break_bit_func = break_bit90_voucher
            break
    }

    return info
}
