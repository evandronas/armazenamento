// voucher_break.js

// DE42

function format_bit42_voucher(value)
{
    var ret = ""
    // DE completo
    var pv_full = hex2a(value)

    // pegando o pv
    var pv = pv_full.substr(4, 9)

    ret = mostrarColchete(pv_full) + mostrarColchete("Estabelecimento " + pv)

    return ret
}
