// amexfull_bit60_break.js

function break_bit60_amexfull()
{
    var qtdeTab = 16
    var space = 62

    var len
    var value
    var infodisp

    // Market Specific Data/Additional Authorization Data Indicator
    len = 2
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        nomeCampo: "Market Specific Data/Additional Authorization Data Indicator",
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    // Additional Authorization Data
    len = 3
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        nomeCampo: "Additional Authorization Data",
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    var bitmap = {}

    // Bitmap Hexa
    len = 4
    bitmap.hexa = get_field_break_bit(len * 2)
    bitmap.bin = bitmap_hex2bin(bitmap.hexa)
    bitmap.formatted = bitmap2formatted(bitmap.bin, true)
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        nomeCampo: "Bitmap Hexa",
        nomeCampoSpace: 0,
        valorOrig: bitmap.hexa,
    }
    genDisplayInfo(infodisp)

    // Bitmap Subfields
    infodisp = {
        display: true,
        qtdeTab: qtdeTab,
        nomeCampo: "Bitmap Subfields",
        nomeCampoSpace: 0,
        valorOrig: bitmap.formatted,
    }
    genDisplayInfo(infodisp)

    // dump_obj_console(bitmap)

    //

    var bit
    var bit_bin
    var i_len = 32
    for (var i = 0; i < i_len; i++)
    {
        var bit_bin = bitmap.bin.substr(i, 1)

        if (bit_bin == 1)
        {
            bit = i + 1

            // console.log("bit_bin [%s] bit [%s]", bit_bin, bit)

            bit_info = get_info_bit60_amexfull(bit)
            // dump_obj_console(bit_info)

            if (!bit_info.tipo)
            {
                alert("Não foi possível pegar as informações do subfield " + bit + " do DE 60.")
                return
            }

            switch (bit_info.tipo)
            {
                case kFixo:
                    if (bit_info.len)
                    {
                        var bit_len = bit_info.len

                        if (bit_info.vezes2)
                            bit_len = bit_info.len * 2
                    }
                    else
                    {
                        alert("ERRO - Não foi definido o tamanho do subfield " + subfield + " do DE " + bit + ".")
                        return -1
                    }

                    // pegando da mensagem
                    var val = get_field_break_bit(bit_len)
                    if (val.length != bit_len)
                    {
                        var msg = "ERRO - O tamanho do conteúdo do subfield " + subfield + " do DE " + bit + " não é igual ao tamanho especificado." + "\n"
                        msg += "len especificado [" + bit_len + "] len conteúdo [" + val.length + "] conteúdo [" + val + "]."
                        alert(msg)
                        return -1
                    }

                    //

                    infodisp = {
                        display: true,
                        qtdeTab: qtdeTab,
                        nomeCampo: "Subfield " + padSubfield(bit),
                        // nomeCampoSpace: 0,
                        lenFixo: true,
                        valorOrig: val,
                        convEbc: !bit_info.nao_conv,
                        nome: bit_info.nome,
                    }
                    genDisplayInfo(infodisp)
                    break

                case kLvar:
                    break

                case kLLvar:
                    break

                case kLLLvar:
                    break

                default:
                    return
            }
        }
    }
}
