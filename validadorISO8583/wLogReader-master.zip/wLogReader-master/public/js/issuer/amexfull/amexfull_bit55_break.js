// amexfull_bit55_break.js

function break_bit55_amexfull()
{
    var tag_len
    var tag_value
    var tag_nome
    var tag_info

    // AGNS
    tag_len = 4
    var valor_agns = get_field_break_bit(tag_len * 2)
    var valor_agns_conv = conv_ebc2a(valor_agns)

    fill_html_spaces()
    msg_formatted += "Header Version Name - " + valor_agns + " [" + valor_agns_conv + "]" + "<br>"

    // fixo 0001
    tag_len = 4
    var valor_0001 = get_field_break_bit(tag_len)

    fill_html_spaces()
    msg_formatted += "Header Version Number - " + valor_0001 + "<br>"

    if (msg_break_bit.length == 22) // DE55 na response
    {
        fill_html_spaces()
        msg_formatted += get_field_break_bit() + "<br>"
    }
    else // DE55 na request
    {
        // 9F26
        tag_len = 8
        nome_tag = "9F26"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 9F10
        nome_tag = "9F10"
        tag_info = get_info_bit55(nome_tag)
        var len_tag_9f10_string = get_field_break_bit(2)
        var len_tag_9f10 = parseInt(len_tag_9f10_string, 16)
        tag_value = get_field_break_bit(len_tag_9f10 * 2)
        display_bit55_amexfull(nome_tag, len_tag_9f10, tag_value, tag_info)

        // 9F37
        tag_len = 4
        nome_tag = "9F37"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 9F36
        tag_len = 2
        nome_tag = "9F36"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 95
        tag_len = 5
        nome_tag = "95"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 9A
        tag_len = 3
        nome_tag = "9A"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 9C
        tag_len = 1
        nome_tag = "9C"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 9F02
        tag_len = 6
        nome_tag = "9F02"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 5F2A
        tag_len = 2
        nome_tag = "5F2A"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 9F1A
        tag_len = 2
        nome_tag = "9F1A"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 82
        tag_len = 2
        nome_tag = "82"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 9F03
        tag_len = 6
        nome_tag = "9F03"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 5F34
        tag_len = 1
        nome_tag = "5F34"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)

        // 9F27
        tag_len = 1
        nome_tag = "9F27"
        tag_info = get_info_bit55(nome_tag)
        tag_value = get_field_break_bit(tag_len * 2)
        display_bit55_amexfull(nome_tag, undefined, tag_value, tag_info)
    }

    return 0
}

function display_bit55_amexfull(tag, tag_len, tag_value, tag_info)
{
    var tag_len_formatada
    if (tag_len) // nao eh undefined
    {
        tag_len_formatada = "V" + padLEN(tag_len)
    }
    else
    {
        tag_len_formatada = get_html_spaces(4)
    }

    fill_html_spaces()
    msg_formatted += "TAG " + padTAGBIT55(tag) + " - " + tag_len_formatada + " - " + tag_value + " (" + tag_info.nome + ")" + "<br>";
}
