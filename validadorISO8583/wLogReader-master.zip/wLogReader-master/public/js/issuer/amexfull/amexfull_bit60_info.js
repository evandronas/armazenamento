// amexfull_bit60_info.js

function get_info_bit60_amexfull(subfield)
{
    var info = {}

    switch(subfield)
    {
        case 2:
            info = {
                nome: "Seller ID - Marketplace ID SubMerchant",
                tipo: kFixo,
                len: 20,
                vezes2: true,
            }
            break
    }

    return info
}
