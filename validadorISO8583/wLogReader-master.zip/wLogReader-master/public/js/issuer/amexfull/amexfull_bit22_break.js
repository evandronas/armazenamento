// amexfull_bit22_break.js

function break_bit22_amexfull()
{
    // posicoes 1 ate 12
    for (var i = 1; i <= 12; i++)
    {
        // pegando valor
        var valor_orig = get_field_break_bit(2)
        var valor_conv = conv_ebc2a(valor_orig)

        // pegando informacao da posicao
        var pos_info = get_info_bit22_amexfull(i, valor_conv)
        if (!pos_info)
        {
            alert("ERRO - Não foi possível recuperar a informação da posição " + i + " do DE22.")
            return 0
        }

        //

        // fill_html_spaces()
        // msg_formatted += "Posição " + pad(i, 2) + ": " + valor_orig + mostrarColchete(valor_conv) + " = " + pos_info.nome + "<br>"
        var infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Posição " + pad(i, 2) + ": ",
            nomeCampoIgnoreDash: true,
            valorOrig: valor_orig,
            valorConv: valor_conv,
            desc: pos_info.nome,
        }
        genDisplayInfo(infodisp)
    }

    return 0
}
