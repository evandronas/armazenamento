// amexfull_bit61_break.js

function break_bit61_amexfull()
{
    var space = 30

    var len
    var valor
    var desc
    var infodisp

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Primary ID",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 3
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Secondary ID",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    // ECI
    len = 2
    valor = get_field_break_bit(len * 2)
    switch(conv_ebc2a(valor))
    {
        case "05":
            desc = "Authenticated with AEVV"
            break

        case "06":
            desc = "Attempted with AEVV"
            break

        case "07":
            desc = "Not Authenticated"
            break

        default:
            desc = undefined
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "ECI",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    if (msg_break_bit.length == 48) // AEVV
    {
        //
        len = 4
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "AEVV ID",
            nomeCampoSpace: space,
            valorOrig: valor,
            convEbc: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 20
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "AEVV",
            nomeCampoSpace: space,
            valorOrig: valor,
        }
        genDisplayInfo(infodisp)
    }
    else if (msg_break_bit.length == 46) // XID
    {
        //
        len = 3
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "SafeKey Transaction ID",
            nomeCampoSpace: space,
            valorOrig: valor,
            // convEbc: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 20
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "SafeKey Transaction ID Value",
            nomeCampoSpace: space,
            valorOrig: valor,
            convEbc: true,
        }
        genDisplayInfo(infodisp)
    }
}
