// amexfull_bit22_info.js

function get_info_bit22_amexfull(pos, val)
{
    var info

    val = val.toUpperCase()

    switch (pos)
    {
        case 1: // posicao 1
            switch (val)
            {
                case "0":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "1":
                    info = {
                        nome: "E-Commerce, AVR ou TO",
                    }
                    break

                case "2": // nao temos terminais que apenas passam tarja
                case "3":
                case "4":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "5":
                    info = {
                        nome: "Todos os terminais com exceção de E-Commerce, AVR e TO",
                    }
                    break

                case "6": // nao temos terminais que somente passam digitada
                case "7":
                case "8":
                case "9":
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 2: // posicao 2
            switch (val)
            {
                case "0":
                    info = {
                        nome: "E-Commerce, AVR ou TO",
                    }
                    break

                case "1":
                    info = {
                        nome: "Todos os terminais com exceção de E-Commerce, AVR e TO",
                    }
                    break

                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 3: // posicao 3
            switch (val)
            {
                case "0":
                    info = {
                        nome: "E-Commerce, AVR ou TO",
                    }
                    break

                case "1":
                    info = {
                        nome: "Todos os terminais com exceção de E-Commerce, AVR e TO",
                    }
                    break

                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 4: // posicao 4
            switch (val)
            {
                case "0":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "1":
                    info = {
                        nome: "Terminais POS e PDV",
                    }
                    break

                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "9":
                    info = {
                        nome: "E-Commerce - Unknown Delivery",
                    }
                    break

                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "S":
                    info = {
                        nome: "E-Commerce - Digital Delivery",
                    }
                    break

                case "T":
                    info = {
                        nome: "E-Commerce - Physical Delivery",
                    }
                    break

                case "U":
                case "V":
                case "W":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "X":
                    info = {
                        nome: "Transação NFC",
                    }
                    break

                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 5: // posicao 5
            switch (val)
            {
                case "0":
                    info = {
                        nome: "Todos os terminais com exceção de E-Commerce",
                    }
                    break

                case "1":
                    info = {
                        nome: "AVR ou TO",
                    }
                    break

                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9": // nao sabemos quando eh transacao recorrente, desta forma nunca enviaremos este campo
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "S":
                    info = {
                        nome: "E-Commerce",
                    }
                    break

                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 6: // posicao 6
            switch (val)
            {
                case "0":
                    info = {
                        nome: "E-Commerce, AVR, TO ou transação digitada",
                    }
                    break

                case "1":
                    info = {
                        nome: "Todos os terminais com exceção de E-Commerce, AVR e TO",
                    }
                    break

                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9": // nao sabemos quando eh transacao recorrente, desta forma nunca enviaremos este campo
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "X":
                    info = {
                        nome: "Transação NFC e Tag 82 do chip com valor igual a 0",
                    }
                    break

                case "Y":
                    info = {
                        nome: "Digital Waller e Tag 82 do chip com valor igual a 1",
                    }
                    break

                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 7: // posicao 7
            switch (val)
            {
                case "0":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "1":
                    info = {
                        nome: "E-Commerce, AVR ou TO",
                    }
                    break

                case "2":
                    info = {
                        nome: "DE22 igual a 02x (Magnética) e não tem CVC2",
                    }
                    break

                case "3":
                case "4":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "5":
                    info = {
                        nome: "DE22 igual a 05x (Chip)",
                    }
                    break

                case "6":
                    info = {
                        nome: "DE22 igual a 01x (Digitada) e não tem CVC2",
                    }
                    break

                case "7":
                case "8":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "9":
                    info = {
                        nome: "DE22 igual a 801 (Fallback Magnético)",
                    }
                    break

                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "S":
                    info = {
                        nome: "DE22 igual a 01x (Digitada) e tem CVC2",
                    }
                    break

                case "T":
                case "U":
                case "V":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "W":
                    info = {
                        nome: "DE22 igual a 02x (Magnética) e tem CVC2",
                    }
                    break

                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 8: // posicao 8
            switch (val)
            {
                case "0":
                    info = {
                        nome: "E-Commerce, AVR ou TO",
                    }
                    break

                case "1":
                    info = {
                        nome: "Transação com senha",
                    }
                    break

                case "2":
                case "3":
                case "4":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "5":
                    info = {
                        nome: "Transação com autenticação por assinatura",
                    }
                    break

                case "6":
                case "7":
                case "8":
                case "9":
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 9: // posicao 9
            switch (val)
            {
                case "0":
                    info = {
                        nome: "E-Commerce, AVR ou TO",
                    }
                    break

                case "1":
                    info = {
                        nome: "Transação com chip e senha offline",
                    }
                    break

                case "2":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "3":
                    info = {
                        nome: "Transação com senha online",
                    }
                    break

                case "4":
                    info = {
                        nome: "Transação com autenticação por assinatura, mesmo se chip",
                    }
                    break

                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 10: // posicao 10
            switch (val)
            {
                case "0":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "1":
                    info = {
                        nome: "E-Commerce, AVR ou TO",
                    }
                    break

                case "2":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "3":
                    info = {
                        nome: "Todos os terminais com exceção de E-Commerce, AVR e TO",
                    }
                    break

                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 11: // posicao 11
            switch (val)
            {
                case "0":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "1":
                    info = {
                        nome: "E-Commerce",
                    }
                    break

                case "2":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "3":
                    info = {
                        nome: "Terminal Low Cost",
                    }
                    break

                case "4":
                    info = {
                        nome: "Todos os terminais com exceção de E-Commerce e Low Cost",
                    }
                    break

                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                case "A":
                case "B":
                case "C":
                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break

        case 12: // posicao 12
            switch (val)
            {
                case "0":
                    info = {
                        nome: "E-Commerce, AVR ou TO",
                    }
                    break

                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                case "A":
                case "B":
                    info = {
                        nome: "N/A",
                    }
                    break

                case "C":
                    info = {
                        nome: "Terminais POS e PDV",
                    }
                    break

                case "D":
                case "E":
                case "F":
                case "G":
                case "H":
                case "I":
                case "J":
                case "K":
                case "L":
                case "M":
                case "N":
                case "O":
                case "P":
                case "Q":
                case "R":
                case "S":
                case "T":
                case "U":
                case "V":
                case "W":
                case "X":
                case "Y":
                case "Z":
                    info = {
                        nome: "N/A",
                    }
                    break
            }
            break
    }

    return info
}
