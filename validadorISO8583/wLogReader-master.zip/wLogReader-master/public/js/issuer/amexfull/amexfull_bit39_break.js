// amexfull_bit39_break.js

function break_bit39_amexfull()
{
    var desc
    var valor = get_field_break_bit()
    var valor_conv = conv_ebc2a(valor)

    switch (valor_conv)
    {
        case "000":
            desc = "Aprovada"
            break

        case "001":
            desc = "Approve with ID"
            break

        case "002":
            desc = "Prepaid Card Partial Authorization"
            break

        case "100":
            desc = "Deny"
            break

        case "101":
            desc = "Expired Card/Invalid Expiration Date"
            break

        case "106":
            desc = "PIN tries exceeded"
            break

        case "107":
            desc = "Please call Issuer"
            break

        case "109":
            desc = "Invalid Service Establishment"
            break

        case "110":
            desc = "Invalid amount"
            break

        case "111":
            desc = "Invalid account"
            break

        case "115":
            desc = "Requested function not supported"
            break

        case "117":
            desc = "Incorrect PIN"
            break

        case "122":
            desc = "Invalid Keyed Printed Card Security Code (PCSC)"
            break

        case "180":
            desc = "Invalid ARQC"
            break

        case "181":
            desc = "Format error"
            break

        case "191":
            desc = "Voice Referral"
            break

        case "200":
            desc = "Deny pick up Card"
            break

        case "911":
            desc = "Card Issuer timed out"
            break

        case "912":
            desc = "Host unavailable"
            break
    }

    msg_formatted += " = " + desc

    return 0
}
