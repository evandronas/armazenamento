// amexfull_bit56_break.js

function break_bit56_amexfull()
{
    var space = 38

    var len
    var valor
    var infodisp

    // message type
    len = 4
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Message Type",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    // stan
    len = 6
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Stan (DE11)",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    // data e hora
    len = 12
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Data e Hora (DE07)",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    // acquiring institution id code
    len = parseInt(conv_ebc2a(get_field_break_bit(2 * 2)))
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Acquiring Institution ID Code (DE32)",
        nomeCampoSpace: space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}
