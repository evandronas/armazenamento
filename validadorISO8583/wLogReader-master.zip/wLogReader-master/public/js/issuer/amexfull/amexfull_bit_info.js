// amexfull_bit_info.js

function get_bit_amexfull(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 7:
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 12:
            info.len = 12
            break

        case 13:
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 22:
            info.len = 12
            info.break_bit_func = break_bit22_amexfull
            break

        case 25:
            info.len = 4
            break

        case 26:
            info.len = 4
            break

        case 31:
            info.tipo = kLLvar
            break

        case 39:
            info.len = 3
            info.break_bit_func_inline = break_bit39_amexfull
            break

        case 43:
            info.tipo = kLLvar
            break

        // case 45:
        //     info = {
        //         ret: true,
        //         tipo: kLLvar,
        //     }
        //     break

        case 52:
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 53:
            info.tipo = kLLvar
            break

        case 55:
            info.nao_conv = true
            info.break_bit_func = break_bit55_amexfull
            break

        case 56:
            info.tipo = kLLvar
            info.break_bit_func = break_bit56_amexfull
            break

        case 60:
            info.break_bit_func = break_bit60_amexfull
            info.nao_conv = true
            break

        case 61:
            info.break_bit_func = break_bit61_amexfull
            info.nao_conv = true
            break
    }

    return info
}
