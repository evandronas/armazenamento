// alelo_bit_info.js

function get_bit_alelo(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        // case 7: // Data e hora
        //     info = {
        //         tipo: kFixo,
        //         len: 10,
        //     }
        //     break

        case 12:
            info.len = 12
            break

        // case 13: // data da transacao
        //     info = {
        //         tipo: kFixo,
        //         len: 4,
        //     }
        //     break

        case 22:
            info.len = 12
            break

        // case 25:
        //     info = get_bit_gen_iso_v0(bit)
        //     info.len = 4
        //     break

        // case 26:
        //     info = get_bit_gen_iso_v0(bit)
        //     info.len = 4
        //     break

        case 39:
            info.len = 3
            break

        case 43:
            info.tipo = kLLvar
            break

        // case 45: // trilha 1
        //     info = {
        //         ret: true,
        //         tipo: kLLvar,
        //     }
        //     break

        case 52:
            info.len = 8
            break

        case 53:
            info.tipo = kLLvar
            info.nao_conv = true
            break

        case 55:
            info = get_bit_gen_iso_v0(bit)
            info.nao_conv = true
            info.break_bit_func = genBreakBit55Puro
            break

        case 64:
            info = get_bit_gen_iso_v0(bit)
            info.formato = kFMT_BIN
            break
    }

    return info
}
