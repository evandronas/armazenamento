// pos_bit48_tag.js

/*
Propriedades do objeto de retorno

tipo            [string]    nome do tipo da tag (Fixo, Lvar, LLvar ou LLLvar)
nome            [string]    nome da tag
len             [int]       tamanho da tag
hasLen          [bool]      true = indica que a tag tem o tamanho | false/undefined = nao tem tamanho
breakFuncDesc   [string]    nome da funcao para quebrar a tag inline (desc)
breakFunc       [string]    nome da funcao para quebrar a tag em nova linha
formato         [string]    formato da tag (HEXA, EBC ou BCD) - o formato do DE sobreescreve esse formato
isLenHexa       [bool]      true = indica que o tamanho da tag esta em hexa
*/

function break_bit48_iti_info(tag)
{
    var info

    tag = tag.toUpperCase()

    switch (tag)
    {
        case "40":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Contador de Pooling",
                len: 2,
            }
            break

        case "41":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Stan da Solicitação do QR Code",
                len: 6,
            }
            break

        case "42":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Data Geração QR Code",
            }
            break

        case "43":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "CNPJ",
            }
            break

        case "50":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Telefone do Comprador",
            }
            break

        case "51":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Nome do Comprador",
            }
            break

        case "52":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Data Pagamento ITI",
            }
            break

        case "53":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Hora Pagamento ITI",
            }
            break

        case "54":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "CPF/CNPJ do portador (PV+ESTAB+CPF/CNPJ)",
            }
            break

        case "55":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Número Pedido ITI",
            }
            break
    }

    return info
}
