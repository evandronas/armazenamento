// break_bit48_iti.js

function break_bit48_iti()
{
    var infodisp

    while(msg_break_bit.length != 0)
    {
        // pegando a tag
        var tag_id_orig = get_field_break_bit(4)
        var tag_id_conv = hex2a(tag_id_orig)
        // console.log("tag_id_orig [%s]", tag_id_orig)

        // pegando informacoes da tag
        var tag_info = break_bit48_iti_info(tag_id_conv)
        dump_obj_console(tag_info)
        if (!tag_info)
        {
            alert("Não foi definido as informações da tag " + tag_id_conv + " do DE48.")
            return 0
        }

        switch(tag_info.tipo)
        {
            case kFixo:

                if (tag_info.len)
                {
                    var bit_len = tag_info.len
                    if (tag_info.formato == kFMT_HEXA)
                    {
                        bit_len *= 2
                    }
                }
                else
                {
                    alert("ERRO - Não foi definido o tamanho da TAG " + tag_id_conv + ".")
                    return 0
                }

                var tag_value_orig = get_field_break_bit(bit_len)
                var tag_value_conv = undefined
                if (tag_info.formato == kFMT_HEXA)
                {
                    tag_value_conv = hex2a(tag_value_orig)
                }

                infodisp = {
                    display: true,
                    qtdeTabL1: true,
                    nomeCampo: "TAG" + " " + tag_id_conv,
                    lenFixo: true,
                    valorOrig: tag_value_orig,
                    valorConv: tag_value_conv,
                    nome: tag_info.nome,
                }

                break

            case kLvar:

                var lvar_len = 1

                var tag_len_orig = get_field_break_bit(lvar_len)
                var tag_len_conv = hex2a(tag_len_orig)
                var tag_len_int = parseInt(tag_len_conv)
                var tag_len_aux = tag_len_int * 2


                var tag_value_orig = get_field_break_bit(tag_len_aux)
                var tag_value_conv = undefined
                if (tag_info.formato == kFMT_HEXA)
                {
                    tag_value_conv = hex2a(tag_value_orig)
                }

                infodisp = {
                    display: true,
                    qtdeTabL1: true,
                    nomeCampo: "TAG" + " " + tag_id_conv,
                    lenV: tag_len_int,
                    padLen: true,
                    valorOrig: tag_value_orig,
                    valorConv: tag_value_conv,
                    nome: tag_info.nome,
                }
                break

            case kLLvar:

                var llvar_len = 2

                var tag_len_orig = get_field_break_bit(llvar_len)
                var tag_len_conv = hex2a(tag_len_orig)
                var tag_len_int = parseInt(tag_len_conv)
                var tag_len_aux = tag_len_int * 2

                var tag_value_orig = get_field_break_bit(tag_len_aux)
                var tag_value_conv = undefined
                if (tag_info.formato == kFMT_HEXA)
                {
                    tag_value_conv = hex2a(tag_value_orig)
                }

                infodisp = {
                    display: true,
                    qtdeTabL1: true,
                    nomeCampo: "TAG" + " " + tag_id_conv,
                    lenV: tag_len_int,
                    padLen: true,
                    valorOrig: tag_value_orig,
                    valorConv: tag_value_conv,
                    nome: tag_info.nome,
                }

                break

            case kLLLvar:

                var lllvar_len = 3

                var tag_len_orig = get_field_break_bit(lllvar_len * 2)
                var tag_len_conv = hex2a(tag_len_orig)
                var tag_len_int = parseInt(tag_len_conv)
                var tag_len_aux = tag_len_int * 2

                var tag_value_orig = get_field_break_bit(tag_len_aux)
                var tag_value_conv = undefined
                if (tag_info.formato == kFMT_HEXA)
                {
                    tag_value_conv = hex2a(tag_value_orig)
                }

                infodisp = {
                    display: true,
                    qtdeTabL1: true,
                    nomeCampo: "TAG" + " " + tag_id_conv,
                    lenV: tag_len_int,
                    padLen: true,
                    valorOrig: tag_value_orig,
                    valorConv: tag_value_conv,
                    nome: tag_info.nome,
                }

                break
        }

        if (tag_info.breakFuncDesc)
        {
            msg_break_aux = tag_value_orig

            tag_info = tag_info.breakFuncDesc(tag_info)
            infodisp.desc = tag_info.desc
        }
        else if (tag_info.breakFunc)
        {
            msg_break_aux = tag_value_orig

            tag_info = tag_info.breakFunc(tag_info)
            infodisp.newline = tag_info.newline
        }

        genDisplayInfo(infodisp)
    }

    return 0
}
