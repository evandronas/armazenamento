// diners_break.js

// DE 48

function break_bit48_diners()
{
    var valor
    var valor_conv
    var desc

    while(msg_break_bit.length != 0)
    {
        // identificacao da transacao - n3
        valor = get_field_break_bit(6)
        valor_conv = conv_ebc2a(valor)
        desc = diners_bit48_info_identtxn(valor_conv)
        formatar_bit48_diners("Identificador da Transação", valor, valor_conv, desc)

        // dados do estabelecimento - identificacao da tecnologia - an2
        valor = get_field_break_bit(4)
        valor_conv = conv_ebc2a(valor)
        desc = diners_bit48_info_identtcn(valor_conv)
        formatar_bit48_diners("Identificação da Tecnologia", valor, valor_conv, desc)

        // dados do estabelecimento - opera em US$ - an1
        valor = get_field_break_bit(2)
        valor_conv = conv_ebc2a(valor)
        desc = diners_bit48_info_operadolar(valor_conv)
        formatar_bit48_diners("Opera em US$", valor, valor_conv, desc)

        // dados do estabelecimento - ramo de atividade - n5
        valor = get_field_break_bit(10)
        valor_conv = conv_ebc2a(valor)
        formatar_bit48_diners("Ramo de Atividade", valor, valor_conv)

        // dados do estabelecimento - modo de operacao - n1
        valor = get_field_break_bit(2)
        valor_conv = conv_ebc2a(valor)
        desc = diners_bit48_info_modooperacao(valor_conv)
        formatar_bit48_diners("Modo de Operação", valor, valor_conv, desc)

        // dados adicionais da transacao - CVC2 - an3
        valor = get_field_break_bit(6)
        valor_conv = conv_ebc2a(valor)
        formatar_bit48_diners("CVC2", valor, valor_conv)

        if (msg_break_bit.length == 0)
            break

        // dados adicionais da transacao - taxa de embarque - n12
        valor = get_field_break_bit(24)
        valor_conv = conv_ebc2a(valor)
        desc = formatMoney(valor_conv)
        formatar_bit48_diners("Taxa de Embarque", valor, valor_conv,desc)

        // dados adicionais da transacao - valor da entrada - n12
        valor = get_field_break_bit(24)
        valor_conv = conv_ebc2a(valor)
        desc = formatMoney(valor_conv)
        formatar_bit48_diners("Valor da Entrada", valor, valor_conv, desc)
    }
}

function formatar_bit48_diners(nome, valor_ebc, valor_conv, desc)
{
    fill_html_spaces()
    msg_formatted += padEXT(nome, 30) + " - " + valor_ebc + " [" + valor_conv + "]"

    if (desc)
    {
        msg_formatted += " = " + desc
    }

    msg_formatted += "<br>"
}

// DE 90

function break_bit90_diners()
{
    var obj = {
        formato: kFMT_EBC,
        campos: [
            {
                nome: kDE90_MSGTYPE,
                len: 4,
            },
            {
                nome: kDE90_STAN,
                len: 6,
            },
            {
                nome: kDE90_DATA,
                len: 4,
            },
            {
                nome: kDE90_HORA,
                len: 6,
            },
            {
                nome: kDE90_IDENT_ACQ,
                len: 11,
            },
            {
                nome: "Forwarding Institution",
                len: 11,
            }
        ],
        space: 43,
    }
    gen_bit90_break2(obj)
}
