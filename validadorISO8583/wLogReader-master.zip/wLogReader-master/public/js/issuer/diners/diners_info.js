// diners_info.js

// DE 48

function diners_bit48_info_identtxn(valor_conv)
{
    var desc

    switch (valor_conv)
    {
        case "020":
            desc = "Pré-Autorização"
            break

        case "101":
            desc = "Autorização de Crédito à vista"
            break

        case "102":
            desc = "Autorização de Crédito parcelado com juros"
            break

        case "103":
            desc = "Autorização de Crédito parcelado sem juros"
            break

        case "105":
            desc = "Autorização IATA à vista"
            break

        case "107":
            desc = "Autorização IATA parcelada sem juros"
            break

        default:
            desc = "Valor desconhecido"
            break
    }

    return desc
}

function diners_bit48_info_identtcn(valor_conv)
{
    var desc

    switch (valor_conv)
    {
        case "84":
        case "85":
        case "86":
            desc = "AVR"
            break

        case "91":
            desc = "POS"
            break

        case "93":
            desc = "PDV/E-Commerce"
            break

        default:
            desc = "Valor desconhecido"
            break
    }

    return desc
}

function diners_bit48_info_operadolar(valor_conv)
{
    var desc

    switch (valor_conv)
    {
        case "1":
            desc = "Sim"
            break

        case " ":
            desc = "Não"
            break

        default:
            desc = "Valor desconhecido"
            break
    }

    return desc
}

function diners_bit48_info_modooperacao(valor_conv)
{
    var desc

    switch (valor_conv)
    {
        case "0":
            desc = "Produção"
            break

        case "1":
            desc = "Demonstração"
            break

        case "2":
            desc = "Piloto"
            break

        default:
            desc = "Valor desconhecido"
            break
    }

    return desc
}
