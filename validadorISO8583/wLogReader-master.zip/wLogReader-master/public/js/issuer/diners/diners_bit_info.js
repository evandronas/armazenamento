// diners_bit_info.js

function get_bit_diners(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 48:
            info.break_bit_func = break_bit48_diners
            break

        case 52:
            info.len = 8
            break

        case 55:
            info.nao_conv = true
            info.break_bit_func = genBreakBit55Puro
            break

        case 90:
            info.break_bit_func = break_bit90_diners
            break
    }

    return info
}
