// ol_bit48_break.js

function break_bit48_ol()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 3,
        infoFunc: break_bit48_ol_info,
        nomeCampo: "TAG",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)
}
