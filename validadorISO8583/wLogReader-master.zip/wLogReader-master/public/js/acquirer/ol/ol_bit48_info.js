// ol_bit48_info.js

function break_bit48_ol_info(tag)
{
    var info

    switch (tag)
    {
        case "001":
            info = {
                nome: "Identificação Operador",
            }
            break

        case "002":
            info = {
                nome: "Código 10",
            }
            break

        case "003":
            info = {
                nome: "CVC2",
            }
            break

        case "004":
            info = {
                nome: "DDD e Telefone do estabelecimento solicitante",
            }
            break

        case "005":
            info = {
                nome: "Identificação Transação",
            }
            break

        case "006":
            info = {
                nome: "POS Data Code",
            }
            break

        case "007":
            info = {
                nome: "TID",
            }
            break

        case "008":
            info = {
                nome: "Origem Aprovação Bandeira",
            }
            break

        case "009":
            info = {
                nome: "Código Produto Mastercard",
            }
            break

        case "010":
            info = {
                nome: "Indicador Presença Portador",
            }
            break

        case "011":
            info = {
                nome: "Capacidade Entrada Terminal",
            }
            break

        case "012":
            info = {
                nome: "Código Processamento Emissor",
            }
            break

        case "013":
            info = {
                nome: "NRID",
            }
            break
    }

    return info
}
