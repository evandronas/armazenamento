// ol_bit_info.js

function get_bit_ol(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 48:
            info.break_bit_func = break_bit48_ol
            break
    }

    return info
}
