// web_bit104_info.js

// DE104

function break_bit104_web_info(subelemento, subcampo)
{
    var info

    switch (subelemento)
    {
        case "01":
            info = {
                nome: "Token",
            }
            break
    }

    return info
}
