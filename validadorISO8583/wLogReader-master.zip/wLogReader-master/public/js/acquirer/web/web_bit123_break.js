// web_bit123_break.js

function break_bit123_web()
{
    var i = 1
    var posi = 0
    var infodisp

    while(msg_break_bit.length != 0)
    {
        // pegando informacoes do campo
        var campo = break_bit123_web_info(i)
        if (!campo)
        {
            // se nao achar as informacoes sobre o campo, para de quebrar o bit
            // alert("Não foi possível pegar as informações do campo " + i + " do DE123.")
            return 0
        }

        var bit_len
        if (campo.len)
        {
            bit_len = campo.len * 2
        }
        else
        {
            alert("ERRO - Não foi definido o tamanho do campo " + i + " do DE123.")
            return -1
        }

        // pegando o conteudo do campo
        var valor = get_field_break_bit(bit_len)
        if (valor.length != bit_len)
        {
            alert("ERRO - O tamanho do conteúdo do campo " + campo.nome + " não é igual ao tamanho especificado.")
            return -1
        }

        //

        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: campo.nome + mostrarParentese((posi + 1) + "-" + (posi + campo.len)) + mostrarParentese(campo.len),
            nomeCampoSpace: 52,
            valorOrig: valor,
            convEbc: true,
        }
        genDisplayInfo(infodisp)

        //

        i += 1
        posi += campo.len
    }

    return 0
}

function display_bit123_web(nome, valor, valor_conv, desc)
{
    fill_html_spaces()
    msg_formatted += padEXT(nome, 35) + " - " + valor + " [" + converterEspacoParaHtml(valor_conv) + "]"

    if (desc)
    {
        msg_formatted += " = " + desc
    }

    fill_break_line()
}
