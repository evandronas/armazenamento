// web_bit121_break.js

function break_bit121_web()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 2,
        infoFunc: break_bit121_web_info,
        nomeCampo: "TAG",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}
