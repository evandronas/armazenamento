// web_bit124_break.js

function break_bit124_web()
{
    var space = 44

    var pos = 0
    var len
    var value
    var infodisp

    //
    len = 20
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "TID" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    //
    len = 4
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Score" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
    pos += len

    //
    len = 1
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Recurring Transaction Flag" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
        descFunc: break_bit124_web_recurring_desc,
    }
    genDisplayInfo(infodisp)
    pos += len

    //
    len = 1
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Split Shipment Transaction Flag" + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
    pos += len
}

function break_bit124_web_recurring_desc(value)
{
    var desc

    switch (value)
    {
        case "0":
            desc = "Not Recurring Transaction"
            break

        case "1":
            desc = "Recurring Transaction"
            break
    }

    return desc
}
