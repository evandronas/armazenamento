// web_bit_info.js

function get_bit_web(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 43:
            info.break_bit_func = gen_bit43_break_ebc
            break

        case 48:
            info.nao_conv = true
            info.break_bit_func = break_bit48_web
            break

        case 90:
            info.break_bit_func = gen_bit90_break_ebc
            info.paramArray = ["mti", "stan", "data", "hora", "filler"]
            break

        case 104:
            info.break_bit_func = break_bit104_web
            break

        case 120:
            info.break_bit_func = break_bit120_web
            break

        case 121:
            info.break_bit_func = break_bit121_web
            break

        case 123:
            info.nao_conv = true // fazendo a conversao, poluiu muito a tela
            info.break_bit_func = break_bit123_web
            break

        case 124:
            info.break_bit_func = break_bit124_web
            break

        case 128:
            info.tipo = kFixo
            info.len = 2
            info.break_bit_func_inline = break_bit128_web
            break
    }

    return info
}
