// web_bit48_break.js

function break_bit48_web()
{
    // pegando tcc
    break_bit48_web_tcc()

    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 2,
        infoFunc: break_bit48_web_info,
        nomeCampo: "Subelement",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}

function break_bit48_web_tcc()
{
    // transaction category code (TCC)
    var len = 1
    var valor = get_field_break_bit(len * 2)
    var valor_conv = conv_ebc2a(valor)
    var desc

    switch(valor_conv.toUpperCase())
    {
        case "A":
            desc = "Auto/Vehicle Rental"
            break

        case "C":
            desc = "Cash Disbursement"
            break

        case "F":
            desc = "Restaurant"
            break

        case "H":
            desc = "Hotel/Motel"
            break

        case "O":
            desc = "Hospitalization, College"
            break

        case "P":
            desc = "Payment Transaction"
            break

        case "R":
            desc = "Retail Sale"
            break

        case "T":
            desc = "Phone, Mail, or Electronic Commerce Order"
            break

        case "U":
            desc = "Unique"
            break

        case "X":
            desc = "Airline and Other Transportation Services"
            break

        case "Z":
            desc = "ATM Cash Disbursement"
            break

        case " ":
            desc = "Space: Authorization System perform the TCC assignment"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    var infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Terminal Category Code",
        valorOrig: valor,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)
}
