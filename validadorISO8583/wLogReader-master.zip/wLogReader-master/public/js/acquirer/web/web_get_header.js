// web_get_header.js

function get_header_web()
{
    var info = {}

    info.len_msg_pos75 = get_field_msg(4)

    var header = get_field_msg(10)
    info.header = header

    // pegando o tipo
    info.header_tipo = header.substr(0, 2)

    // NII destino
    info.header_nii_destino = header.substr(2, 4)

    // NII origem
    info.header_nii_origem = header.substr(6, 4)


    // formatando o header para retornar
    var header_formatted = ""

    info.header = info.len_msg_pos75 + info.header
    header_formatted += "Tamanho Mensagem ISO - " + info.len_msg_pos75 + " [" + parseInt(info.len_msg_pos75, 16) + "]" + get_break_line()
    header_formatted += "Header - " + info.header + get_break_line()
    header_formatted += "Tipo - " + info.header_tipo + get_break_line()
    header_formatted += "NII Destino - " + info.header_nii_destino + get_break_line()
    header_formatted += "NII Origem - " + info.header_nii_origem + get_break_line()

    // criando o objeto de retorno
    var ret_info = {
        ret: true,
        header: header_formatted,
        header_clean: info.header,
    }

    return ret_info
}
