// web_bit120_break.js

function break_bit120_web()
{
    var space = 37
    var len
    var value
    var infodisp

    //
    len = 12
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CEP" + mostrarParentese("1-12") + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 46
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Endereço" + mostrarParentese("13-58") + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 6
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Endereço - Número" + mostrarParentese("59-64") + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 19
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Endereço - Complemento" + mostrarParentese("65-83") + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 12
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CPF" + mostrarParentese("84-95") + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: value,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}
