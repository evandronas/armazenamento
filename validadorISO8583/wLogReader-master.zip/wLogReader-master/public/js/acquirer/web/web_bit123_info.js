// web_bit123_info.js

/*
Propriedades do objeto com as informacoes do campo DE123 WEB

nome            [string]    nome do campo
len             [num]       tamanho do DE quando eh fixo
*/

function break_bit123_web_info(field)
{
    var info

    switch (field)
    {
        case 1:  // Membership number of the merchant (distributor) - MULTIPV (1 - 9)
            info = {
                nome: "Membership number of the merchant",
                len: 9,
            }
            break

        case 2:  // Order Number (10 - 26)
            info = {
                nome: "Número do Pedido",
                len: 17,
            }
            break

        case 3:  // Only Airline Companies -> Ticket Number (27 - 41)
            info = {
                // nome: "Only Airline Companies -> Ticket Number",
                nome: "Ticket Number 1",
                len: 15,
            }
            break

        case 4:  // Airline Companies _ Name of Main Passenger. Other Areas _ Free Text to be entered (42 - 68)
            info = {
                // nome: "Airline Companies -> Name of Main Passenger",
                nome: "Nome do Passageiro 1",
                len: 27,
            }
            break

        case 5:  // Only Airline Companies _ Ticket Number (69 - 83)
            info = {
                // nome: "Only Airline Companies -> Ticket Number",
                nome: "Ticket Number 2",
                len: 15,
            }
            break

        case 6:  // Only Airline Companies _ Passenger Name (84 - 110)
            info = {
                // nome: "Only Airline Companies -> Passenger Name",
                nome: "Nome do Passageiro 2",
                len: 27,
            }
            break

        case 7:  // Only Airline Companies _ Ticket Number (111 - 125)
            info = {
                // nome: "Only Airline Companies -> Ticket Number",
                nome: "Ticket Number 3",
                len: 15,
            }
            break

        case 8:  // Only Airline Companies _ Passenger Name (126 - 152)
            info = {
                // nome: "Only Airline Companies -> Passenger Name",
                nome: "Nome do Passageiro 3",
                len: 27,
            }
            break

        case 9:  // Only Airline Companies _ Ticket Number (153 - 167)
            info = {
                // nome: "Only Airline Companies -> Ticket Number",
                nome: "Ticket Number 4",
                len: 15,
            }
            break

        case 10:  // Only Airline Companies _ Passenger Name (168 - 194)
            info = {
                // nome: "Only Airline Companies -> Passenger Name",
                nome: "Nome do Passageiro 4",
                len: 27,
            }
            break

        case 11:  // Only Airline Companies _ Ticket Number (195 - 209)
            info = {
                // nome: "Only Airline Companies -> Ticket Number",
                nome: "Ticket Number 5",
                len: 15,
            }
            break

        case 12:  // Only Airline Companies _ Passenger Name (210 - 236)
            info = {
                // nome: "Only Airline Companies -> Passenger Name",
                nome: "Nome do Passageiro 5",
                len: 27,
            }
            break

        case 13:  // Verification Code (237 - 262)
            info = {
                nome: "Verification Code",
                len: 26,
            }
            break

        case 14:  // Address to return transaction data (263 - 413)
            info = {
                nome: "Address to return transaction data",
                len: 151,
            }
            break

        case 15:  // Number of IATA Code (Exclusive to Airline Companies) (414 - 422)
            info = {
                // nome: "Number of IATA Code (Exclusive to Airline Companies)",
                nome: "IATA Code",
                len: 9,
            }
            break

        case 16:  // Transaction Boarding Tax (Exclusive to Airline Companies) (423 - 438)
            info = {
                // nome: "Transaction Boarding Tax (Exclusive to Airline Companies)",
                nome: "Taxa de Embarque",
                len: 16,
            }
            break

        case 17:  // DBA - Merchant Description Identifier (439 - 451)
            info = {
                // nome: "DBA - Merchant Description Identifier",
                nome: "Merchant Description Identifier",
                len: 13,
            }
            break

        case 18:  // CardHolder Name (452 - 482)
            info = {
                nome: "CardHolder Name",
                len: 31,
            }
            break

        case 19:  // Flag to store a transaction who indicate a already stored credential (483 - 483)
            info = {
                // nome: "Flag to store a transaction who indicate a already stored credential",
                nome: "Credencial Armazenada",
                len: 1,
            }
            break

        case 20:
            info = {
                nome: "Taxas de Serviço Cia Aérea",
                len: 84,
            }
            break
    }

    return info
}
