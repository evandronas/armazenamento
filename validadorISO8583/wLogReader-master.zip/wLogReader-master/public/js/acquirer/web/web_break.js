// web_break.js

// DE 104

function break_bit104_web()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 2,
        infoFunc: break_bit104_web_info,
        nomeCampo: "Subelement",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}

// DE 128

function break_bit128_web()
{
    var valor = get_field_break_bit()

    msg_formatted += " = " + get_desc_capture_source_web(conv_ebc2a(valor))

    return 0
}
