// web_bit48_info.js

function break_bit48_web_info(subelemento, subcampo)
{
    var info

    switch (subelemento)
    {
        case "37":
            if (subcampo)
            {
                switch (subcampo)
                {
                    case "01":
                        info = {
                            nome: "Marketplace - ID Facilitador"
                        }
                        break

                    case "02":
                        info = {
                            nome: "Independent Sales Organization ID",
                        }
                        break

                    case "03":
                        info = {
                            nome: "Marketplace - ID Submerchant",
                        }
                        break
                }
            }
            else
            {
                info = {
                    nome: "Additional Merchant Data",
                    breakTLV: true,
                }
            }
            break

        case "42":
            if (subcampo)
            {
                switch (subcampo)
                {
                    case "01":
                        info = {
                            nome: "Electronic Commerce Security Level Indicator and UCAF Collection Indicator",
                            breakFunc: break_bit48_mastercard_subelemento42_subcampo01,
                        }
                        break

                    case "03":
                        info = {
                            nome: "Merchant Original ECI",
                        }
                        break
                }
            }
            else
            {
                info = {
                    nome: "Electronic Commerce Indicators",
                    breakTLV: true,
                }
            }
            break

        case "43":
            info = {
                nome: "Universal Cardholder Authentication Field (UCAF)",
                nao_conv: true,
            }
            break

        case "44":
            info = {
                nome: "Visa 3-D Secure Electronic Commerce Transaction Identifier (XID)",
                nao_conv: true,
            }
            break

        case "66":
            if (subcampo)
            {
                switch (subcampo)
                {
                    case "01":
                        info = {
                            nome: "3DS Indicator",
                        }
                        break

                    case "02":
                        info = {
                            nome: "Directory Server Transaction ID",
                        }
                        break
                }
            }
            else
            {
                info = {
                    nome: "3DS 2.0 ThreeDIndicator",
                    nao_conv: true,
                    breakTLV: true,
                }
            }
            break

        case "92":
            info = {
                nome: "CVC2",
            }
            break
    }

    return info
}
