// web_bit_info.js

function break_bit121_web_info(value)
{
    var info = {}

    switch(value)
    {
        case "01":
            info = {
                nome: "Marketplace - Endereço",
            }
            break

        case "02":
            info = {
                nome: "Marketplace - Cidade",
            }
            break

        case "03":
            info = {
                nome: "Marketplace - Estado",
            }
            break

        case "04":
            info = {
                nome: "Marketplace - País",
            }
            break

        case "05":
            info = {
                nome: "Marketplace - CEP",
            }
            break

        case "06":
            info = {
                nome: "Marketplace - CNPJ",
            }
            break

        case "07":
            info = {
                nome: "TID",
            }
            break

        case "08":
            info = {
                nome: "Código Característica",
            }
            break

        case "09":
            info = {
                nome: "Código MVV/Wallet ID",
            }
            break

        case "10":
            info = {
                nome: "Score Antifraude",
            }
            break

        case "11":
            info = {
                nome: "Código Parceiro",
            }
            break

        case "12":
            info = {
                nome: "Código Produto",
            }
            break

        case "13":
            info = {
                nome: "External Action Id",
            }
            break

        case "14":
            info = {
                nome: "Token Assurance Method",
            }
            break

        case "15":
            info = {
                nome: "Merchant Advice Code",
            }
            break
    }

    return info
}
