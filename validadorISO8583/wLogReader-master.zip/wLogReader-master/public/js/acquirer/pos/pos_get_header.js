// pos_get_header.js

// ================================================================================================
// PROPRIEDADES DO RETORNO
// ================================================================================================
// ret      - true 	= header obtido com sucesso
//          - false	= header obtido sem sucesso
// header   - objeto com os dados do header quebrados
// valor    - valor no header, se sucesso
// msg      - mensagem atualizada sem o header, se sucesso
//

function get_header_pos(pos, tipo)
{
    var info = {}

    if (pos == kFE_POS75 && tipo != kDRV_POS_POSIP && tipo != kDRV_POS_POSIP_MEGANAC && tipo != kDRV_POS_TAPONPHONE)
    {
        info.len_msg_pos75 = get_field_msg(4)
    }

    switch (tipo)
    {
        case kDRV_POS_MEGANAC:
            var len_header_meganac_req = 42 // len header request
            var len_header_meganac_res = 10 // len header response
            var isReq = true
            var isRes = false
            var msgtype
            var ret_valid_msgtype
            var ret

            // pegando o msgtype depois do header para validar
            msgtype = msg.substr(len_header_meganac_req, 4)
            ret_valid_msgtype = validMsgType(msgtype)

            if (ret_valid_msgtype < 0) // msg nao eh de request, deve ser de response
            {
                msgtype = msg.substr(len_header_meganac_res, 4)
                ret_valid_msgtype = validMsgType(msgtype)

                if (ret_valid_msgtype < 0)
                {
                    info = { ret: false }

                    return info
                }

                isReq = false
                isRes = true
            }

            // console.log("MegaNAC - isReq [%s] isRes [%s]", isReq, isRes)

            if (isReq) // request
            {
                // layout do header
                // 60                       - Aplicacao POS             - 1 byte
                // XXXX                     - NII destino               - 2 bytes
                // XXXX                     - NII origem                - 2 bytes
                // XXXXXXXXXXXXXXXX         - Telefone origem           - 8 bytes
                // XXXXXXXXXXXXXXXX         - Telefone destino          - 8 bytes

                var header = get_field_msg(len_header_meganac_req)
                info.header = header

                // pegando o tipo
                info.header_tipo = header.substr(0, 2)

                // NII destino
                info.header_nii_destino = header.substr(2, 4)

                // NII origem
                info.header_nii_origem = header.substr(6, 4)

                // Telefone origem
                info.header_tel_origem = header.substr(10, 16)

                // Telefone destino
                info.header_tel_destino = header.substr(26, 16)
            }
            else if (isRes) // eh a mensagem de response
            {
                // layout do header
                // 60                           - Aplicacao POS             - 1 byte
                // XXXX                         - NII destino               - 2 bytes
                // XXXX                         - NII origem                - 2 bytes

                var header = get_field_msg(len_header_meganac_res)
                info.header = header

                // pegando o tipo
                info.header_tipo = header.substr(0, 2)

                // NII destino
                info.header_nii_destino = header.substr(2, 4)

                // NII origem
                info.header_nii_origem = header.substr(6, 4)
            }

            break

        case kDRV_POS_NAC:
            // layout do header
            // 60                           - Aplicacao POS             - 1 byte
            // XXXX                         - NII destino               - 2 bytes
            // XXXX                         - NII origem                - 2 bytes

            var len_header_nac = 10

            var header = get_field_msg(len_header_nac)
            info.header = header

            // pegando o tipo
            info.header_tipo = header.substr(0, 2)

            // NII destino
            info.header_nii_destino = header.substr(2, 4)

            // NII origem
            info.header_nii_origem = header.substr(6, 4)

            break

        case kDRV_POS_POSIP:       
            var len_header_posip_req = 34 // len header request
            var len_header_posip_res = 10 // len header response
            var isReq = true
            var isRes = false
            var msgtype
            var ind_cript_salt = ""
            
            
            // SALT
            ind_cript_salt = msg.substr(12,2)
            if ( ind_cript_salt == "05" || ind_cript_salt == "06" ) 
            {
                len_header_posip_req = 66;
            }
            else
             {
                len_header_posip_req = 34;
             }   

            //console.log("Roma - msgtype [%s] isReq [%s]", msgtype, isReq)

            // pegando o msgtype depois do header para validar
            msgtype = msg.substr(len_header_posip_req, 4)

            if (validMsgType(msgtype) < 0) // msg nao eh de request, deve ser de response
            {
                msgtype = msg.substr(len_header_posip_res, 4)

                if (validMsgType(msgtype) < 0)
                {
                    len_header_posip_res = 74 ;
                    msgtype = msg.substr(len_header_posip_res, 4)
                   
                    if (validMsgType(msgtype) < 0)
                    {
                    
                        info = { ret: false }
                        return info
                    }
                }

                isReq = false
                isRes = true
            }

            // console.log("MegaNAC - isReq [%s] isRes [%s]", isReq, isRes)

            if (isReq) // request
            {
                // layout do header
                // 60                       - Aplicacao POS                 - 1 byte
                // XXXX                     - NII destino                   - 2 bytes
                // XXXX                     - NII origem                    - 2 bytes
                // XXXX                     - Indicador de Criptografia     - 2 bytes
                // XXXXXXXXXXXXXXXX         - KSN                           - 10 bytes

                var header = get_field_msg(len_header_posip_req)
                info.header = header

                // pegando o tipo
                info.header_tipo = header.substr(0, 2)

                // NII destino
                info.header_nii_destino = header.substr(2, 4)

                // NII origem
                info.header_nii_origem = header.substr(6, 4)

                // Indicador de Criptografia
                info.ind_cripto = header.substr(10, 4)
                info.ind_cripto_desc = describe_ind_cripto(info.ind_cripto)

                // KSN
                info.ksn = header.substr(14, 20)

                
                if ( info.ind_cripto.substr(2,2) == "05" || info.ind_cripto.substr(2,2) == "06" ) 
                    info.salt = header.substr(34, 32);
                else
                    info.salt = "";
                //console.log("Roma - msgtype [%s] info.salt [%s]", msgtype, info.salt)
                

                
            }
            else if (isRes) // eh a mensagem de response
            {
                // layout do header
                // 60                           - Aplicacao POS             - 1 byte
                // XXXX                         - NII destino               - 2 bytes
                // XXXX                         - NII origem                - 2 bytes

                var header = get_field_msg(len_header_posip_res)
                info.header = header

                // pegando o tipo
                info.header_tipo = header.substr(0, 2)

                // NII destino
                info.header_nii_destino = header.substr(2, 4)

                // NII origem
                info.header_nii_origem = header.substr(6, 4)

                // HASH
                if ( len_header_posip_res == 74 )
                {
                    info.header_hash = header.substr(10,64);
                } else
                {
                    info.header_hash = "";
                }

                
            }

            break

        case kDRV_POS_POSIP_MEGANAC:
            var len_header_posip_meganac_req = 66 // len header request
            var len_header_posip_meganac_res = 10 // len header response
            var isReq = true
            var isRes = false
            var msgtype
            var ret_valid_msgtype
            var ret

            // pegando o msgtype depois do header para validar
            msgtype = msg.substr(len_header_posip_meganac_req, 4)
            ret_valid_msgtype = validMsgType(msgtype)

            if (ret_valid_msgtype < 0) // msg nao eh de request, deve ser de response
            {
                msgtype = msg.substr(len_header_posip_meganac_res, 4)
                ret_valid_msgtype = validMsgType(msgtype)

                if (ret_valid_msgtype < 0)
                {
                    info = { ret: false }

                    return info
                }

                isReq = false
                isRes = true
            }

            // console.log("POSIP-MegaNAC - isReq [%s] isRes [%s]", isReq, isRes)

            if (isReq) // request
            {
                // layout do header
                // 60                       - Aplicacao POS             - 1 byte
                // XXXX                     - NII destino               - 2 bytes
                // XXXX                     - NII origem                - 2 bytes
                // XXXXXXXXXXXXXXXX         - Telefone origem           - 8 bytes
                // XXXXXXXXXXXXXXXX         - Telefone destino          - 8 bytes
                // XXXX                     - Indicador de Criptografia - 2 bytes
                // XXXXXXXXXXXXXXXXXXXX     - KSN                       - 10 bytes

                var header = get_field_msg(len_header_posip_meganac_req)
                info.header = header

                // pegando o tipo
                info.header_tipo = header.substr(0, 2)

                // NII destino
                info.header_nii_destino = header.substr(2, 4)

                // NII origem
                info.header_nii_origem = header.substr(6, 4)

                // Telefone origem
                info.header_tel_origem = header.substr(10, 16)

                // Telefone destino
                info.header_tel_destino = header.substr(26, 16)

                // Indicador de Criptografia
                info.ind_cripto = header.substr(42, 4)
                info.ind_cripto_desc = describe_ind_cripto(info.ind_cripto)

                // KSN
                info.ksn = header.substr(46, 20)
            }
            else if (isRes) // eh a mensagem de response
            {
                // layout do header
                // 60                           - Aplicacao POS             - 1 byte
                // XXXX                         - NII destino               - 2 bytes
                // XXXX                         - NII origem                - 2 bytes

                var header = get_field_msg(len_header_posip_meganac_res)
                info.header = header

                // pegando o tipo
                info.header_tipo = header.substr(0, 2)

                // NII destino
                info.header_nii_destino = header.substr(2, 4)

                // NII origem
                info.header_nii_origem = header.substr(6, 4)
            }

            break

        case kDRV_POS_TAPONPHONE:
            var len_header_req = 70 // len header request
            var len_header_res = 74 // len header response
            var isReq = true
            var isRes = false
            var msgtype
            var ind_cript_salt = ""

            // pegando o msgtype depois do header para validar
            msgtype = msg.substr(len_header_req, 4)

            if (validMsgType(msgtype) < 0) // msg nao eh de request, deve ser de response
            {
                msgtype = msg.substr(len_header_res, 4)

                if (validMsgType(msgtype) < 0)
                {
                    info = { ret: false }
                    return info
                }

                isReq = false
                isRes = true
            }

            if (isReq) // request
            {
                // layout do header
                // 60                       - Aplicacao POS                 - 1 byte
                // XXXX                     - NII destino                   - 2 bytes
                // XXXX                     - NII origem                    - 2 bytes
                // XXXX                     - Indicador de Criptografia     - 2 bytes
                // XXXXXXXXXXXXXXXXXXXXXXXX - KSN                           - 12 bytes
                // XXXXXXXXXXXXXXXX         - Salt                          - 16 bytes

                var header = get_field_msg(len_header_req)
                info.header = header

                // pegando o tipo
                info.header_tipo = header.substr(0, 2)

                // NII destino
                info.header_nii_destino = header.substr(2, 4)

                // NII origem
                info.header_nii_origem = header.substr(6, 4)

                // Indicador de Criptografia
                info.ind_cripto = header.substr(10, 4)
                info.ind_cripto_desc = describe_ind_cripto(info.ind_cripto)

                // KSN
                info.ksn = header.substr(14, 24)

                // Salt
                info.salt = header.substr(38, 32);
            }
            else if (isRes) // eh a mensagem de response
            {
                // layout do header
                // 60                               - Aplicacao POS             - 1 byte
                // XXXX                             - NII destino               - 2 bytes
                // XXXX                             - NII origem                - 2 bytes
                // XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX - Hash                      - 32 bytes

                var header = get_field_msg(len_header_res)
                info.header = header

                // pegando o tipo
                info.header_tipo = header.substr(0, 2)

                // NII destino
                info.header_nii_destino = header.substr(2, 4)

                // NII origem
                info.header_nii_origem = header.substr(6, 4)

                // Hash
                info.header_hash = header.substr(10,64);
            }
    }

    // formatando o header para retornar
    var header_formatted = ""
    if (info.len_msg_pos75)
    {
        info.header = info.len_msg_pos75 + info.header
        header_formatted += "Tamanho Mensagem ISO - " + info.len_msg_pos75 + " [" + parseInt(info.len_msg_pos75, 16) + "]" + "<br>"
    }
    header_formatted += "Header - " + info.header + "<br>"
    header_formatted += "Tipo - " + info.header_tipo + "<br>"
    header_formatted += "NII Destino - " + info.header_nii_destino + "<br>"
    header_formatted += "NII Origem - " + info.header_nii_origem + "<br>"
    if (info.header_hash)
    {
        header_formatted += "Hash - " + info.header_hash + "<br>"
    }

    if (info.header_tel_origem)
    {
        header_formatted += "Telefone Origem - " + info.header_tel_origem + "<br>"
    }
    if (info.header_tel_destino)
    {
        header_formatted += "Telefone Destino - " + info.header_tel_destino + "<br>"
    }
    if (info.ind_cripto)
    {
        header_formatted += "Indicativo de Criptografia - " + info.ind_cripto + " = " + info.ind_cripto_desc + "<br>"
    }
    if (info.ksn)
    {
        header_formatted += "KSN - " + info.ksn + "<br>"
    }
    if (info.salt)
    {
        header_formatted += "SALT - " + info.salt + "<br>"
    }    

    // criando o objeto de retorno
    var ret_info = {
        ret: true,
        header: header_formatted,
        header_clean: info.header,
    }

    return ret_info
}

function describe_ind_cripto(ind_cripto)
{
    var desc
    switch(ind_cripto.substr(2,2))
    {
        case "01":
            desc = "criptografia DUKPT 3DES - Terminais 1.0"
            break

        case "02":
            desc = "criptografia DUKPT 3DES - Terminais 2.0"
            break

        case "05":
            desc = "criptografia DUKPT 3DES - Terminais 1.0 - com SALT" 
            break

        case "06":
            desc = "criptografia DUKPT 3DES - Terminais 2.0 - com SALT" 
            break

        case "07":
            desc = "criptografia DUKPT AES - Terminais Tap on Phone" 
            break

        default:
            desc = "reservado para uso futuro"
            break
    }
    return desc
}
