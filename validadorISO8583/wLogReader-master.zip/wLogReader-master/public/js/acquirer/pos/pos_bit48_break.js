// break_bit48_pos.js

function break_bit48_pos()
{
    // pegando o 54
    var bit48_54 = get_field_break_bit(2)

    fill_html_spaces()
    msg_formatted += bit48_54 + get_break_line()

    //

    var infodisp

    while(msg_break_bit.length != 0)
    {
        // pegando a tag
        var tag_id_orig = get_field_break_bit(2)
        // console.log("tag_id_orig [%s]", tag_id_orig)

        // pegando informacoes da tag
        var tag_info = break_bit48_pos_info(tag_id_orig)
        // dump_obj_console(tag_info)
        if (!tag_info)
        {
            alert("Não foi definido as informações da tag " + tag_id_orig + " do DE48.")
            return 0
        }

        if(tag_info.isNoValue)
        {
            infodisp = {
                display: true,
                qtdeTabL1: true,
                nomeCampo: "TAG" + " " + tag_id_orig,
                lenFixo: true,
                nome: tag_info.nome,
            }	
        }

        switch(tag_info.tipo)
        {
            case kFixo:

                if (tag_info.len)
                {
                    var bit_len = tag_info.len
                    if (tag_info.formato == kFMT_HEXA)
                    {
                        bit_len *= 2
                    }
                }
                else
                {
                    alert("ERRO - Não foi definido o tamanho da TAG " + tag_id_orig + ".")
                    return 0
                }

                var tag_value_orig = get_field_break_bit(bit_len)
                var tag_value_conv = undefined
                if (tag_info.formato == kFMT_HEXA)
                {
                    tag_value_conv = hex2a(tag_value_orig)
                }

                infodisp = {
                    display: true,
                    qtdeTabL1: true,
                    nomeCampo: "TAG" + " " + tag_id_orig,
                    lenFixo: true,
                    valorOrig: tag_value_orig,
                    valorConv: tag_value_conv,
                    nome: tag_info.nome,
                }

                break

            case kLvar:
                break

            case kLLvar:

                var llvar_len = 2

                var tag_len_orig = get_field_break_bit(llvar_len)
                var tag_len_int = parseInt(tag_len_orig)
                var tag_len_aux = tag_len_int * 2

                var tag_value_orig = get_field_break_bit(tag_len_aux)
                var tag_value_conv = undefined
                if (tag_info.formato == kFMT_HEXA)
                {
                    tag_value_conv = hex2a(tag_value_orig)
                }

                infodisp = {
                    display: true,
                    qtdeTabL1: true,
                    nomeCampo: "TAG" + " " + tag_id_orig,
                    lenV: tag_len_int,
                    padLen: true,
                    valorOrig: tag_value_orig,
                    valorConv: tag_value_conv,
                    nome: tag_info.nome,
                }

                break

            case kLLLvar:

                var lllvar_len = 4

                var tag_len_orig = get_field_break_bit(lllvar_len)
                var tag_len_conv
                if (tag_info.isLenHexa)
                {
                    tag_len_conv = hex2a(tag_len_orig)
                }
                else
                {
                    tag_len_conv = tag_len_orig
                }
                var tag_len_int = parseInt(tag_len_conv)
                var tag_len_aux = tag_len_int
                if (tag_info.lenRaw)
                {
                    tag_len_aux = tag_len_int
                }
                else if (tag_info.formato == kFMT_HEXA || tag_info.formato == kFMT_BCD || tag_info.formato == kFMT_BIN)
                {
                    tag_len_aux = tag_len_int * 2
                }
                if (tag_info.formato == kFMT_BCD && (tag_len_aux % 2) != 0)
                {
                    tag_len_aux += 1
                }

                var tag_value_orig = get_field_break_bit(tag_len_aux)
                var tag_value_conv = undefined
                if (tag_info.formato == kFMT_HEXA)
                {
                    tag_value_conv = hex2a(tag_value_orig)
                }

                infodisp = {
                    display: true,
                    qtdeTabL1: true,
                    nomeCampo: "TAG" + " " + tag_id_orig,
                    lenV: tag_len_int,
                    padLen: true,
                    valorOrig: tag_value_orig,
                    valorConv: tag_value_conv,
                    nome: tag_info.nome,
                }

                break
        }

        if (tag_info.breakFuncDesc)
        {
            msg_break_aux = tag_value_orig

            tag_info = tag_info.breakFuncDesc(tag_info)
            infodisp.desc = tag_info.desc
        }
        else if (tag_info.breakFunc)
        {
            msg_break_aux = tag_value_orig

            tag_info = tag_info.breakFunc(tag_info)
            infodisp.newline = tag_info.newline
        }

        genDisplayInfo(infodisp)
    }

    return 0
}

function break_bit48_pos_tag01(tag_info)
{
    var desc
    var valor = get_field_break_aux()

    switch (valor)
    {
        // Mensagens 0100/0110

        case "0006":
            desc = "Consulta SERASA"
            break

        case "0007":
            desc = "Consulta Private Label - Venda"
            break

        case "0008":
            desc = "Consulta DCC"
            break

        case "0020":
            desc = "Pré-Autorização"
            break

        case "0353":
            desc = "Simulação Crediário (Antigo)"
            break

        case "0359":
            desc = "Simulação Crediário (Novo)"
            break

        case "0361":
            desc = "Consulta Pré-Autorização"
            break

        case "0490":
            desc = "Solicitação de QRCode Venda"
            break

        case "0491":
            desc = "Solicitação de QRCode Estorno"
            break

        case "0500":
            desc = "Comprovante Digital de Pagamento"
            break

        case "0600":
            desc = "Relatório Digital"
            break

        // Mensagens 0200/0210/0202

        case "0301":
            desc = "Débito à vista"
            break

        case '0306':
            desc = "Venda com cartão de Voucher"
            break

        case "0309":
            desc = "Venda com cartão de Voucher Frota"
            break

        case "0315":
            desc = "Débito à vista Recarga de Celular"
            break

        case "0316":
            desc = "Débito à vista Corban"
            break

        case "0350":
            desc = "Venda Crédito rotativo"
            break

        case "0351":
            desc = "Venda Crédito Parcelado com Juros"
            break

        case "0352":
            desc = "Venda Crédito Parcelado sem Juros"
            break

        case "0354":
            desc = "Contratação Crediário (Antigo)"
            break

        case "0355":
            desc = "Venda Crédito rotativo Recarga de Celular pré-pago"
            break

        case "0360":
            desc = "Contratação Crediário (Novo)"
            break

        case "0381":
            desc = "Venda Private Label"
            break

        case "0473":
            desc = "Venda dinheiro Corban"
            break

        // Mensagens 0220/0230

        case "0450":
            desc = "Captura rotativo - transação autorizada por telefone"
            break

        case '0451':
            desc = "Captura parcelada com juros - transação autorizada por telefone"
            break

        case "0452":
            desc = "Captura parcelada sem juros - transação autorizada por telefone"
            break

        case "0454":
            desc = "Confirmação de pré-autorização - rotativo"
            break

        case "0455":
            desc = "Confirmação de pré-autorização - parcelada sem juros"
            break

        case "0457":
            desc = "Venda crédito rotativo Offline com Smart Card"
            break

        case "0458":
            desc = "Venda Voucher Offline com Smart Card"
            break

        case "0459":
            desc = "Venda Voucher Frota Offline com Smart Card"
            break

        // Mensagens 0500/0510

        case "0501":
            desc = "Finalização"
            break

        case '0502':
            desc = "Resumo de Vendas"
            break

        // Mensagens 1624/1634

        case "0601":
            desc = "Confirmação de Antecipação RAV"
            break

        case '0602':
            desc = "Senha/Sonda RAV"
            break

        case "0603":
            desc = "Saldo RAV"
            break

        case "0604":
            desc = "Contratação RAV Automático"
            break

        case "0605":
            desc = "Resgate de senha RAV"
            break

        case "0606":
            desc = "Consulta RAV automático"
            break

        // Mensagens 0800/0810

        case "0801":
            desc = "Baixa de Ocorrência Técnica"
            break

        case '0802':
            desc = "Teste de Comunicação"
            break

        case "0803":
            desc = "Fim de auto-inicialização"
            break

        case "0804":
            desc = "Fim de autocarga"
            break

        case "0805":
            desc = "Estatística"
            break

        case "0807":
            desc = "Toaki"
            break

        case "0808":
            desc = "Telemetria"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit48_pos_tag03(tag_info)
{
    var valor = get_field_break_aux()
    var valor_conv = hex2a(valor)

    tag_info.desc = get_desc_ind_crypto(valor_conv)

    return tag_info
}

function break_bit48_pos_tag16(tag_info)
{
    var space = 24

    var formatted = ""
    var infodisp

    // quantidade de ocorrencias
    var qtde_ocor_string = get_field_break_aux(2)
    var qtde_ocor = parseInt(qtde_ocor_string, 10)
    infodisp = { qtdeTab: 32, nomeCampo: "Quantidade de Ocorrências", valorOrig: qtde_ocor_string, }
    formatted += genDisplayInfo(infodisp)

    var qtde_tab = 36
    for (var i = 1; i <= qtde_ocor; i++)
    {
        // console.log("i [%s]", i)
        if (i > 1)
        {
            formatted += get_break_line()
        }

        // qtde parcelas - n2
        var qtde_parcelas = get_field_break_aux(2)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "Quantidade de Parcelas", nomeCampoSpace: space, valorOrig: qtde_parcelas, }
        formatted += genDisplayInfo(infodisp)

        // encargos mensais - n7
        var enc_mensais = get_field_break_aux(8)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "Encargos Mensais", nomeCampoSpace: space, valorOrig: enc_mensais, formatPct: true, }
        formatted += genDisplayInfo(infodisp)

        // cet anual - n12
        var cet_anual = get_field_break_aux(12)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "CET Anual", nomeCampoSpace: space, valorOrig: cet_anual, formatPct: true, }
        formatted += genDisplayInfo(infodisp)

        // valor parcela - n12
        var val_parc = get_field_break_aux(12)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "Valor da Parcela", nomeCampoSpace: space, valorOrig: val_parc, formatMoney: true, }
        formatted += genDisplayInfo(infodisp)

        // valor total - n12
        var val_total = get_field_break_aux(12)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "Valor Total", nomeCampoSpace: space, valorOrig: val_total, formatMoney: true, }
        formatted += genDisplayInfo(infodisp)

        // iof - n12
        var iof = get_field_break_aux(12)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "IOF", nomeCampoSpace: space, valorOrig: iof, formatPct: true, }
        formatted += genDisplayInfo(infodisp)

        // encargos anuais - n7
        var enc_anuais = get_field_break_aux(8)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "Encargos Anuais", nomeCampoSpace: space, valorOrig: enc_anuais, formatPct: true, }
        formatted += genDisplayInfo(infodisp)
    }

    tag_info.newline = formatted

    return tag_info
}

function break_bit48_pos_tag47(tag_info)
{
    var desc
    var valor = get_field_break_aux()

    switch (hex2a(valor))
    {
        case "0002":
            desc = "Crédito À Vista"
            break

        case "0004":
            desc = "Crédito Parcelado Sem Juros"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit48_pos_tag4F(tag_info)
{
    var desc
    var valor = get_field_break_aux()

    switch (hex2a(valor))
    {
        case "0":
            desc = "Aceita Somente Padrão Inicial Definido na Fase 1"
            break

        case "1":
            desc = "Genérico (inclusive BR Code)"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit48_pos_tag55(tag_info)
{
    var qtde_tab = 32
    var space = 22

    var len
    var valor_orig
    var display = ""
    var infodisp

    //
    len = 8
    valor_orig = get_field_break_aux(len)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Código do Veículo", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 8
    valor_orig = get_field_break_aux(len)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Código do Condutor", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Tipo do Serviço", nomeCampoSpace: space, valorOrig: valor_orig, descFunc: break_bit48_pos_tag55_tipo_servico, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Código do Combustível", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 8
    valor_orig = get_field_break_aux(len)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Litragem", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 10
    valor_orig = get_field_break_aux(len)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Quilometragem", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //

    tag_info.newline = display

    return tag_info
}

function break_bit48_pos_tag55_tipo_servico(valor)
{
    var desc

    switch (valor)
    {
        case "01":
            desc = "Abastecimento"
            break

        case "02":
            desc = "Troca de Óleo"
            break

        case "03":
            desc = "Lavagem"
            break

        case "04":
            desc = "Pedágio"
            break

        case "05":
            desc = "Outros"
            break
    }

    return desc
}

function break_bit48_pos_tag60(tag_info)
{
    var desc
    var valor = get_field_break_aux()

    switch (valor)
    {
        case "00":
            desc = "Sem envio de consulta (cartões identificados como nacionais, cartões digitados, pré-aut parcelada, etc)"
            break

        case "01":
            desc = "Houve oferta, cardholder não aceitou"
            break

        case "02":
            desc = "Houve oferta, cardholder aceito"
            break

        case "03":
            desc = "Consulta com retorno NÃO ELEGÍVEL - DE39 diferente de 00"
            break

        case "04":
            desc = "Consulta não concluída - erro de comunicação"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit48_pos_tag85(tag_info)
{
    var qtde_tab = 32
    var space = 18

    var len
    var valor_orig
    var display = ""
    var infodisp

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "STATUS RES", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSTATUS", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMMIN", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMMOUT", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMLU", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMREDIALS", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMCERR", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMTOUT", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMRTOUT", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMReTxC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QTRANPERDI", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QMENSERR", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "HERR", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QDESF", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QTECRESTART", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMNAS", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMTelecarga", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMPTRAN", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSTRAN", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMPREDIAL", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSREDIAL", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMCRDERR", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMLOP", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMOFFL", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMCRDREADS", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 4
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CÓDIGOPABX", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMLOS", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSEPIN", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMNAP", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMRESV", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMID", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMPINPAD", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 11
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMVERSION", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMLINPRNT", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NFALLBACK", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "TP-DISCAGEM", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "TP-CONEXÃO", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Unused", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 12
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "FONE-INIC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 12
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "FONE-PRIM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 12
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "FONE-SECUND", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "TMP-CONEXÃO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "TMP-OPERADOR", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "TMP-TRANSAÇÃO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NPINERRO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NTRNCANC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NCRTBLOQ", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NOFFLINE", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 13
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "ID_PINPAD", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 6
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Versão PINPAD", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 9
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Versão Gerenciador", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMCVCliente", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMCVEstab", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMCVAmbos", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMCVNenhum", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMCVGeral", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //

    tag_info.newline = display

    return tag_info
}

function break_bit48_pos_tag90(tag_info)
{
    var qtde_tab = 32
    var space = 18

    var len
    var valor_orig
    var display = ""
    var infodisp

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRATTACH", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "MQSINAL", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRPPP", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRDHCP", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRTCP1", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRTCP2", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRGPRS", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QFBACKGSM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QBER", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRMOOEM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMFINA", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRSIMCARD", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CONFFBACKGSM", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMPTRANGPRS", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMPTRANGSM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMDESF", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSTRANGPRS", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSTRANGSM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSQMUP", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSQMIN", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMSQMDOWN", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMERROR", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMQATTACH", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "TMATTACH", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMIDLEQATTACH", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "QERRIDLEATTACH", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "MQBATERIA", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMADM", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "SLOT", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CGI LAC", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CGI CI", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "ERRGEMOVEL", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "ERRCONTSESS", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NMTO", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CME", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 5
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //

    tag_info.newline = display

    return tag_info
}

function break_bit48_pos_tag91(tag_info)
{
    var qtde_tab = 32
    var space = 18

    var len
    var valor_orig
    var display = ""
    var infodisp

    //
    len = 26
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "NSERIESIM", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 10
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "OPERADORA", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 6
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "IP_DEST_P", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "PORTA_DEST_P", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "DIAL_ATTEMPT_P", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 6
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "IP_DEST_S", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "PORTA_DEST_S", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "DIAL_ATTEMPT_S", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 25
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "APN_CONF", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 25
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "MODCHI", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 1
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "SLOT", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //
    len = 8
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "MSISDN", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 8
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "IMEI", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "Reservado", nomeCampoSpace: space, valorOrig: valor_orig, convHexa: true, }
    display += genDisplayInfo(infodisp)

    //

    tag_info.newline = display

    return tag_info
}

function break_bit48_pos_tag95(tag_info)
{
    var qtde_tab = 32
    var space = 18

    var len
    var valor_orig
    var display = ""

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICTTOTOK", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIITTOTOK", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIQTTCOK", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIQTINOK", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFCOM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFCOM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFTO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFTO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFMI", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFMI", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFID", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFID", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFLC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFLC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFCE", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFCE", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFLUSO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFLUSO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFSTOM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFSTOM", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFLO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFLO", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFNA", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFNA", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFAT", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFAT", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICQTFTC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 2
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIQTFTC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CICTCONEC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 3
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIITCONEC", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 12
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CINUMTEL", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //
    len = 6
    valor_orig = get_field_break_aux(len * 2)
    infodisp = { qtdeTab: qtde_tab, nomeCampo: "CIIP", nomeCampoSpace: space, valorOrig: valor_orig, }
    display += genDisplayInfo(infodisp)

    //

    tag_info.newline = display

    return tag_info
}
