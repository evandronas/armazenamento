// pos_bit56_break.js

function break_bit56_pos()
{
    var tlvinfo = {
        formato: kFMT_HEXA,
        lenTagDiff: 2,
        ignoreTagConv: true,
        lenLengthDiff: 4,
        ignoreLenConv: true,
        padLen: true,
        infoFunc: break_bit56_pos_info,
        nomeCampo: "TAG",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0

    // while(msg_break_bit.length != 0)
    // {
    //     // pegando a tag
    //     var tag_id_orig = get_field_break_bit(2)
        
    //     // pegando informacoes da tag
    //     var tag_info = break_bit56_pos_info(tag_id_orig)

    //     // pegando o tamanho da tag
    //     var tag_len_orig = get_field_break_bit(4)
    //     var tag_len_conv = parseInt(tag_len_orig, 10) // transformando pra numero - usando radix 10

    //     // pegando o conteudo da tag
    //     var tag_valor
    //     if (tag_info.vezes2)
    //     {
    //         tag_valor = get_field_break_bit(tag_len_conv * 2)
    //     }
    //     else
    //     {
    //         tag_valor = get_field_break_bit(tag_len_conv)	
    //     }

    //     // convertendo
    //     var tag_valor_conv = ""
    //     if (tag_info.hex2a) // mostrar tambem o valor convertido
    //     {
    //         tag_valor_conv = mostrarColchete(hex2a(tag_valor))
    //         tag_valor_conv = converterEspacoParaHtml(tag_valor_conv)
    //     }

    //     //

    //     fill_html_spaces()
    //     msg_formatted += "TAG " + tag_id_orig + " - " + "V" + padLEN(tag_len_conv) + " - " + tag_valor + tag_valor_conv

    //     if (tag_info.nome)
    //     {
    //         msg_formatted += mostrarParentese(tag_info.nome)
    //     }

    //     fill_break_line()
    // }
}
