// break_bit47_pos.js

function break_bit47_pos()
{
    var tlvinfo = {
        formato: kFMT_HEXA,
        lenTagDiff: 2,
        ignoreTagConv: true,
        lenLengthDiff: 4,
        ignoreLenConv: true,
        padLen: true,
        infoFunc: break_bit47_pos_info,
        nomeCampo: "TAG",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}

function break_bit47_pos_tag04() // cvm
{
    genBreakCvm(kDEF_POS)
}

function break_bit47_pos_tag10() // ksn
{
    genBreakKsn(kDEF_POS)
}

function break_bit47_pos_tag3D()
{
    var valor
    var infodisp

    // quantidade de ocorrencias
    valor = get_field_break_aux(2)
    var qtde_ocor = parseInt(valor, 10)
    infodisp = {
        display: true,
        qtdeTab: 32,
        nomeCampo: "Quantidade de Ocorrências",
        nomeCampoSpace: 22,
        valorOrig: valor,
    }
    genDisplayInfo(infodisp)
    // console.log("valor [%s] qtde ocor [%s]", valor, qtde_ocor)

    var qtdeTab = 36
    var space = 24
    for (var i = 1; i <= qtde_ocor; i++)
    {
        // console.log("i [%s]", i)
        if (i > 1)
        {
            fill_break_line()
        }

        // valor - n12
        valor = get_field_break_aux(12)
        infodisp = {
            display: true,
            qtdeTab: qtdeTab,
            nomeCampo: "Valor",
            nomeCampoSpace: space,
            valorOrig: valor,
            formatMoney: true,
        }
        genDisplayInfo(infodisp)

        // quantidade de parcelas - n2
        valor = get_field_break_aux(2)
        infodisp = {
            display: true,
            qtdeTab: qtdeTab,
            nomeCampo: "Quantidade de Parcelas",
            nomeCampoSpace: space,
            valorOrig: valor,
        }
        genDisplayInfo(infodisp)

        // data - n8
        valor = get_field_break_aux(8)
        infodisp = {
            display: true,
            qtdeTab: qtdeTab,
            nomeCampo: "Data",
            nomeCampoSpace: space,
            valorOrig: valor,
        }
        genDisplayInfo(infodisp)

        // nsu - n12
        valor = get_field_break_aux(12)
        infodisp = {
            display: true,
            qtdeTab: qtdeTab,
            nomeCampo: "NSU",
            nomeCampoSpace: space,
            valorOrig: valor,
        }
        genDisplayInfo(infodisp)
    }
}
