// pos_bit57_break.js

function break_bit57_pos() {
    var infodisp
    while (msg_break_bit.length != 0) {
        // pegando a tag
        var tag_id_orig = get_field_break_bit(2)
        // console.log("tag_id_orig [%s]", tag_id_orig)

        // pegando informacoes da tag
        var tag_info = break_bit57_pos_info(tag_id_orig)
        //dump_obj_console(tag_info)
        if (!tag_info) {
            alert("Não foi definido as informações da tag " + tag_id_orig + " do DE48.")
            return 0
        }

        var tag_len_orig = undefined

        switch (tag_info.tipo) {
            case kLLvar:

                var llvar_len = 2
                tag_len_orig = get_field_break_bit(llvar_len)

                break

            case kLLLvar:

                var lllvar_len = 4
                tag_len_orig = get_field_break_bit(lllvar_len)

                break
        }

        var tag_len_int = parseInt(tag_len_orig)

        var tag_value_orig = get_field_break_bit(tag_len_int * 2)

        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "TAG" + " " + tag_id_orig,
            lenV: tag_len_int,
            padLen: true,
            valorOrig: tag_value_orig,
            nome: tag_info.nome,
        }

        if (!tag_info.nao_conv) {
            var tag_value_conv = hex2a(tag_value_orig)
            infodisp.valorConv = tag_value_conv
        }

        if (tag_info.breakFuncDesc) {
            console.log("tag_info.breakFuncDesc")
            msg_break_aux = tag_value_orig

            tag_info = tag_info.breakFuncDesc(tag_info)
            infodisp.desc = tag_info.desc
        }
        else if (tag_info.breakFunc) {
            console.log("tag_info.breakFunc")
            msg_break_aux = tag_value_orig

            tag_info = tag_info.breakFunc(tag_info)
            infodisp.newline = tag_info.newline
        }

        genDisplayInfo(infodisp)
    }

    return 0
}

function break_bit57_tag42(tag_info) {
    var qtde_tab = 32
    var space = 22

    var len = 6
    var tam_campo
    var valor_orig
    var valor_conv
    var display = ""
    var infodisp

    // ID Carteira
    tam_campo = parseInt(hex2a(get_field_break_aux(len)))
    if (tam_campo > 0) {
        valor_orig = get_field_break_aux(tam_campo * 2)
        valor_conv = hex2a(valor_orig)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "ID Carteira", nomeCampoSpace: space, valorOrig: valor_orig, valorConv: valor_conv, }
        display += genDisplayInfo(infodisp)
    }

    // Email
    tam_campo = parseInt(hex2a(get_field_break_aux(len)))
    if (tam_campo > 0) {
        valor_orig = get_field_break_aux(tam_campo * 2)
        valor_conv = hex2a(valor_orig)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "Email", nomeCampoSpace: space, valorOrig: valor_orig, valorConv: valor_conv, }
        display += genDisplayInfo(infodisp)
    }

    // Telefone
    tam_campo = parseInt(hex2a(get_field_break_aux(len)))
    if (tam_campo > 0) {
        valor_orig = get_field_break_aux(tam_campo * 2)
        valor_conv = hex2a(valor_orig)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "Telefone", nomeCampoSpace: space, valorOrig: valor_orig, valorConv: valor_conv, }
        display += genDisplayInfo(infodisp)
    }

    // Numero Aleatorio
    tam_campo = parseInt(hex2a(get_field_break_aux(len)))
    if (tam_campo > 0) {
        valor_orig = get_field_break_aux(tam_campo * 2)
        valor_conv = hex2a(valor_orig)
        infodisp = { qtdeTab: qtde_tab, nomeCampo: "Numero Aleatório", nomeCampoSpace: space, valorOrig: valor_orig, valorConv: valor_conv, }
        display += genDisplayInfo(infodisp)
    }

    tag_info.newline = display

    return tag_info
}
