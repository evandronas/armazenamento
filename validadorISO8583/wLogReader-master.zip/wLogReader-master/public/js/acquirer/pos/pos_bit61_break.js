// pos_bit61_break.js

function break_bit61_pos()
{
    var space = 63   
    
    var len
    var valor_orig
    var valor_conv
    var desc
    var infodisp

    // posicao 1 - POS Terminal Attendance Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Attended terminal"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 01: POS Terminal Attendance Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 2 - POS Terminal Operator Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "no longer used"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 02: POS Terminal Operator Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 3 - POS Terminal Location Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "On premises of card acceptor facility"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 03: POS Terminal Location Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 4 - POS Cardholder Presence Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Cardholder Present"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 04: POS Cardholder Presence Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 5 - POS Card Presence Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Cardholder Present"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 05: POS Card Presence Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 6 - POS Card Capture Capabilities Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Terminal/operator has no card capture capability"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 06: POS Card Capture Capabilities Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 7 - POS Transaction Status Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Normal request (original presentment)"
            break

        case "4":
            desc = "Preauthorized request"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 07: POS Transaction Status Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 8 - POS Transaction Security Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "No security concern"
            break

        case "1":
            desc = "Suspected fraud (merchant suspicious - code 10)"
            break

        case "2":
            desc = "identification verified"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 08: POS Transaction Security Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 9 - POS Transaction Routing Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "no longer used"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 09: POS Transaction Routing Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 10 - Cardholder-Activated Terminal Level Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Not a CAT transaction"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 10: Cardholder-Activated Terminal Level Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 11 - POS Card Data Terminal Input Capability Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Unknown Or Unspecified"
            break

        case "1":
            desc = "No Terminal Used"
            break

        case "2":
            desc = "Magnetic Stripe Reader"
            break

        case "3":
            desc = "Contactless M/Chip / qVSDC / MagStripe / MSD"
            break

        case "4":
            desc = ""
            break

        case "5":
            desc = ""
            break

        case "6":
            desc = "Key entry only"
            break

        case "7":
            desc = "Magnetic stripe reader and key entry"
            break

        case "8":
            desc = "Magnetic stripe reader, key entry and EMV - compatible ICC reader"
            break

        case "9":
            desc = "EMV compatible ICC reader"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 11: POS Card Data Terminal Input Capability Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 12/13 - Authorization Life Cycle
    len = 2
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    switch(valor_conv)
    {
        case "00":
            desc = "reserved for future use"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 12/13: Authorization Life Cycle",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 14/15/16 - POS Country Code
    len = 3
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = hex2a(valor_orig)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 14/15/16: POS Country Code",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
    }
    genDisplayInfo(infodisp)
}

function display_bit61_pos(nome, valor, valor_conv, desc)
{
    fill_html_spaces()
    msg_formatted += padEXT(nome, 63) +  " - " + valor + " [" + valor_conv + "]"

    if (desc)
    {
        msg_formatted += " = " + desc
    }

    fill_break_line()
}
