﻿// pos_bit48_tag.js

/*
Propriedades do objeto de retorno

tipo            [string]    nome do tipo da tag (Fixo, Lvar, LLvar ou LLLvar)
nome            [string]    nome da tag
len             [int]       tamanho da tag
hasLen          [bool]      true = indica que a tag tem o tamanho | false/undefined = nao tem tamanho
breakFuncDesc   [string]    nome da funcao para quebrar a tag inline (desc)
breakFunc       [string]    nome da funcao para quebrar a tag em nova linha
formato         [string]    formato da tag (HEXA, EBC ou BCD) - o formato do DE sobreescreve esse formato
isLenHexa       [bool]      true = indica que o tamanho da tag esta em hexa
isLenRaw        [bool]      true = quando formato for BCD, utilizar o tamanho puro enviado (soma +1 se valor impar) (para corrigir o envio da tag 4D pelo WQ3 para venda do QR Code)
*/

function break_bit48_pos_info(tag)
{
    var info

    tag = tag.toUpperCase()

    switch (tag)
    {
        case "01":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Identificação da transação",
                len: 4,
                breakFuncDesc: break_bit48_pos_tag01,
            }
            break

        case "02":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Código do terminal",
                len: 8,
            }
            break

        case "03":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Modo de criptografia",
                len: 2,
                breakFuncDesc: break_bit48_pos_tag03,
            }
            break

        case "04":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Quantidade de parcelas",
                len: 2,
            }
            break

        case "05":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "CVC2 não criptografado",
                len: 4,
            }
            break

        case "06":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Data Débito Pré-Datado",
                len: 6,
            }
            break

        case "07":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Data Validade Pré-Autorização",
                len: 8,
            }
            break

        case "08":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Dados Private Label",
                len: 6,
            }
            break

        case "09":
            info = {
                tipo: kLLvar,
                formato: kFMT_BCD,
                nome: "CPF/CNPJ",
            }
            break

        case "0A":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Número do Cheque",
                len: 10,
            }
            break

        case "0D":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "CMC-7 (Serasa)",
                len: 30,
            }
            break

        case "0F":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "ACHEI-RECHEQUE (Serasa)",
                len: 1,
            }
            break

        case "10":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Número do item",
                len: 12,
            }
            break

        case "11":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Dados PCJ",
                len: 30,
            }
            break

        case "16":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "Dados Simulação Crediário",
                breakFunc: break_bit48_pos_tag16,
            }
            break

        case "20":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Dados de Contratação RAV",
                len: 14,
            }
            break

        case "2A":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "Dados Resgate de Senha RAV",
            }
            break

        case "30":
            info = {
                tipo: kFixo,
                formato: kFMT_BIN,
                nome: "CVC2 Criptografado",
                len: 16,
            }
            break

        case "33":
            info = {
                nome: "Indicação desfazimento estorno",
                isNoValue: true,
            }
            break

        case "34":
            info = {
                nome: "Indicação tecla cancela",
                isNoValue: true,
            }
            break

        case "35":
            info = {
                tipo: kLLvar,
                formato: kFMT_BCD,
                nome: "Data da transação a ser confirmada",
            }
            break

        case "36":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "NSU da transação a ser confirmada",
            }
            break

        case "3E":
            info = {
                tipo: kFixo,
                len: 1,
                formato: kFMT_HEXA,
                nome: "Flag Terminal iti",
            }
            break

        case "40":
            info = {
                tipo: kFixo,
                len: 2,
                nome: "Pooling ITI",
            }
            break

        case "41":
            info = {
                tipo: kFixo,
                len: 6,
                nome: "Stan da Solicitação QRCode",
            }
            break

        case "42":
            info = {
                tipo: kLLLvar,
                nome: "Data Geração QR Code",
            }
            break

        case "43":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "CNPJ",
            }
            break

        case "45":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Nome Fantasia",
            }
            break

        case "46":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Cidade",
            }
            break

        case "47":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Modalidade",
                breakFuncDesc: break_bit48_pos_tag47,
            }
            break

        case "48":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                len: 4,
                nome: "Fluxo Transação",
            }
            break

        case "49":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BIN,
                nome: "Código de Autorização Offline",
            }
            break

        case "4A":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Identificação QRCode Financeira",
            }
            break

        case "4B":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                len: 6,
                nome: "Stan Financeira",
            }
            break

        case "4C":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                len: 2,
                nome: "Identificação Transação QRCode",
            }
            break

        case "4D":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "Identificação Carteira Digital",
                lenRaw: true,
            }
            break

        case "4E":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Código Autenticação Pagamento QR Code",
            }
            break

        case "4F":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                len: 1,
                nome: "Modelo QR Code",
                breakFuncDesc: break_bit48_pos_tag4F,
            }
            break

        case "50":
            info = {
                tipo: kLLvar,
                formato: kFMT_BCD,
                nome: "Dados Confirmação Positiva e Referral",
            }
            break

        case "51":
            info = {
                tipo: kLLvar,
                formato: kFMT_BCD,
                nome: "Dados a Coletar Transação Referral",
            }
            break

        case "52":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Capacidade Terminal Confirmação Positiva",
                len: 2,
            }
            break

        case "53":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Capacidade Terminal Refereal",
                len: 2,
            }
            break

        case "55":
            info = {
                tipo: kFixo,
                nome: "Dados Voucher Frota",
                len: 38,
                breakFunc: break_bit48_pos_tag55,
            }
            break

        case "60":
            info = {
                tipo: kFixo,
                nome: "Status Consulta DCC",
                len: 2,
                breakFuncDesc: break_bit48_pos_tag60,
            }
            break

        case "61":
            info = {
                tipo: kLLvar,
                nome: "Data da Consulta CDC",
            }
            break

        case "62":
            info = {
                tipo: kFixo,
                nome: "NSU da Consulta CDC",
                len: 24,
            }
            break

        case "63":
            info = {
                tipo: kFixo,
                nome: "ID Transacao Original",
                len: 4,
                breakFuncDesc: break_bit48_pos_tag01,
            }
            break

        case "70":
            info = {
                tipo: kLLvar,
                formato: kFMT_BCD,
                nome: "IMEI"
            }
            break

        case "71":
            info = {
                tipo: kLLvar,
                formato: kFMT_BCD,
                nome: "SIMCard ID (ICCID)",
            }
            break

        case "72":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "Nome operadora",
            }
            break

        case "73":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "MAC address",
            }
            break

        case "74":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "Endereço IP",
            }
            break

        case "75":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "Informações antena (CGI)",
            }
            break

        case "76":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "Versão plataforma (CA + plataforma)",
            }
            break

        case "77":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "Latitude",
            }
            break

        case "78":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "Longitude",
            }
            break

        case "84":
            info = {
                tipo: kLLvar,
                formato: kFMT_HEXA,
                nome: "Estatística - versão do kernel EMV",
            }
            break

        case "85":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "Estatística - dados presentes em terminais POS",
                breakFunc: break_bit48_pos_tag85,
            }
            break

        case "88":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Versão da Aplicacão",
                isLenHexa: true,
            }
            break

        case "89":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Indicacão de Auto-Inicialização",
                len: 1,
            }
            break

        case "8A":
            info = {
                tipo: kFixo,
                formato: kFMT_HEXA,
                nome: "Baixa Técnica",
                len: 61,
            }
            break

        // case "8B":
        //     info = {
        //         nome: "Finalização",
        //         hasLen: false,
        //         len: 40,
        //         vezes2: true,
        //         hex2a: true,
        //     }
        //     break

        case "8C":
            info = {
                tipo: kFixo,
                formato: kFMT_BCD,
                nome: "Indicação de Autocarga",
                len: 12,
            }
            break

        case "9D":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "Estatística para terminais 3G",
            }
            break

        case "90":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "Estatística - terminais wireless",
                breakFunc: break_bit48_pos_tag90,
            }
            break

        case "91":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Estatística - controle de SIMCARD para terminais wireless",
                breakFunc: break_bit48_pos_tag91,
            }
            break

        case "92":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Número de série do terminal",
            }
            break

        case "93":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Número de série do PINPAD externo",
            }
            break

        case "94":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "Número Ordem de Serviço",
            }
            break

        case "95":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "Estatística SCRM - Estatísticas de carga e Inicialização em terminais POS",
                breakFunc: break_bit48_pos_tag95,
            }
            break

        case "A0":
            info = {
                tipo: kLLLvar,
                formato: kFMT_BCD,
                nome: "CAVV QR Code",
            }
            break

        case "A1":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "ECI QR Code",
            }
            break

        case "A2":
            info = {
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                nome: "Wallet ID",
            }
            break

        // case "9B":
        //     info = {
        //         nome: "Estatística - Ethernet Wi-Fi e Bluetooth",
        //         hasLen: true,
        //         isLenLLLVAR: true,
        //         vezes2: true,
        //     }
        //     break
    }

    return info
}
