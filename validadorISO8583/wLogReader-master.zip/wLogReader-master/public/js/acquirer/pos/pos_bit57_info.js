// pos_bit57_info.js

function break_bit57_pos_info(tag)
{
    var info = {}

    tag = tag.toLowerCase()
    console.log(tag)
    switch (tag)
    {
        case "01":
            info = {
                nome: "Tipo Comprovante",
                tipo: kLLLvar,
                breakFuncDesc: break_bit57_pos_tag01,
                nao_conv: true,
                formato: kFMT_HEXA,
            }
            break

        case "02":
            info = {
                nome: "Canal Estabelecimento",
                tipo: kLLLvar,
                breakFuncDesc: break_bit57_pos_tag02,
                nao_conv: true,
                formato: kFMT_HEXA,
            }
            break

        case "03":
            info = {
                nome: "Canal Portador",
                tipo: kLLLvar,
                breakFuncDesc: break_bit57_pos_tag02,
                formato: kFMT_HEXA,
                nao_conv: true,
            }
            break

        case "04":
            info = {
                nome: "Celular Portador",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "06":
            info = {
                nome: "Reenvio",
                tipo: kLLLvar,
                breakFuncDesc: break_bit57_pos_tag06,
                formato: kFMT_HEXA,
                nao_conv: true,
            }
            break

        case "07":
            info = {
                nome: "Queda Energia",
                tipo: kLLLvar,
                breakFuncDesc: break_bit57_pos_tag06,
                formato: kFMT_HEXA,
            }
            break

        case "08":
            info = {
                nome: "Imprime Logo",
                tipo: kLLLvar,
                breakFuncDesc: break_bit57_pos_tag06,
                nao_conv: true,
                formato: kFMT_HEXA,
            }
            break

        case "09":
            info = {
                nome: "ARQC",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "10":
            info = {
                nome: "Application Label",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "11":
            info = {
                nome: "AID",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "12":
            info = {
                nome: "Modo de Entrada",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "13":
            info = {
                nome: "PAN",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "14":
            info = {
                nome: "Código Autorização",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "15":
            info = {
                nome: "Razão Social",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "16":
            info = {
                nome: "Endereço Estabelecimento",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "17":
            info = {
                nome: "Endereço Estabelecimento",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "18":
            info = {
                nome: "Cidade Estabelecimento",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "19":
            info = {
                nome: "Telefone Estabelecimento",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "20":
            info = {
                nome: "Mensagem Terminal",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "21":
            info = {
                nome: "Nome Portador",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "22":
            info = {
                nome: "Status Terminal ",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "23":
            info = {
                nome: "Nome Fantasia Estab",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "40":
            info = {
                nome: "NA – Número Aleatório",
                tipo: kLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "41":
            info = {
                nome: "TK – Chave Terminal",
                tipo: kLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "42":
            info = {
                nome: "Criptograma (ID, Email, Telefone, NA)",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
                breakFunc: break_bit57_tag42
            }
            break

        case "43":
            info = {
                nome: "Email Portador",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break

        case "44":
            info = {
                nome: "Criptograma",
                tipo: kLLLvar,
                formato: kFMT_HEXA,
            }
            break
    }
    return info
}

function break_bit57_pos_tag01(tag_info)
{
    var desc
    var valor = get_field_break_aux()

    switch (valor)
    {
        case "0001":
            desc = "Crédito À Vista"
            break

        case "0003":
            desc = "Crédito Parcelado Sem Juros"
            break

        case "0025":
            desc = "Débito À Vista"
            break

        case "0043":
            desc = "Voucher"
            break

        case "0057":
            desc = "Private Label"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit57_pos_tag02(tag_info)
{
    var desc
    var valor = get_field_break_aux()

    switch (valor)
    {
        case "00":
            desc = "Não Enviar"
            break

        case "01":
            desc = "Email"
            break

        case "02":
            desc = "SMS"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}

function break_bit57_pos_tag06(tag_info)
{
    console.log("break_bit57_pos_tag06")
    var desc
    var valor = get_field_break_aux()

    switch (valor)
    {
        case "00":
            desc = "Não"
            break

        case "01":
            desc = "Sim"
            break
    }

    if (desc)
    {
        tag_info.desc = desc
    }

    return tag_info
}