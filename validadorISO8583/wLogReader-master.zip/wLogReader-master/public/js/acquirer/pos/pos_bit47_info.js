// pos_bit47_tag.js

// ================================================================================================
// PROPRIEDADES DO RETORNO
// ================================================================================================
// ret          - true = tag existe
//              - false = tag existe
// nome         - nome da tag
// hasLen       - indica se a tag tem o tamanho antes do valor
// isLenHexa    - indica se o tamanho esta no formata hexa
// len          - tamanho do tamanho da tag
// hex2a        - indica se o valor devera ser convertido de hexa pra ascII
// vezes2       - true = precisa pegar o tamanho da tag e dobrar para coneguir pegar o conteudo
//

function break_bit47_pos_info(tag)
{
    var info = {}

    tag = tag.toUpperCase()

    switch (tag)
    {
        case "01":
            info = {
                nome: "Saldo Voucher / Comprovante Voucher Frota",
            }
            break

        case "02":
            info = {
                nome: "Mensagem do Emissor",
            }
            break

        case "04":
            info = {
                nome: "CVM Result",
                nao_conv: true,
                breakFunc: break_bit47_pos_tag04,
            }
            break

        case "0A":
            info = {
                nome: "Dados do 2nc GAC",
                nao_conv: true,
            }
            break

        case "0B":
            info = {
                nome: "Issuer Script Result",
                nao_conv: true,
            }
            break

        case "0C":
            info = {
                nome: "TOAKI - Data e hora da última transação realizada",
                nao_conv: true,
            }
            break

        case "0D":
            info = {
                nome: "CNPJ",
            }
            break

        case "0E":
            info = {
                nome: "TOAKI - Tempo de Inatividade",
            }
            break

        case "0F":
            info = {
                nome: "MAC do Valor",
                nao_conv: true,
            }
            break

        case "10":
            info = {
                nome: "Chave DUKPT KSN",
                nao_conv: true,
                breakFunc: break_bit47_pos_tag10,
            }
            break

        case "12":
            info = {
                nome: "Certificado RSA",
                nao_conv: true,
            }
            break

        case "21":
            info = {
                nome: "Número do Estabelecimento (Baixa Técnica)",
            }
            break

        case "25":
            info = {
                nome: "RAV Total / Parcial / Automático",
            }
            break

        case "26":
            info = {
                nome: "Aprovação/Negação da offline - 1st GAC ou 2nd GAC",
            }
            break

        case "27":
            info = {
                nome: "Nova Senha",
                nao_conv: true,
            }
            break

        case "28":
            info = {
                nome: "Confirmação Nova Senha",
                nao_conv: true,
            }
            break

        case "29":
            info = {
                nome: "Cartão emitido fora do Brasil",
                nao_conv: true,
            }
            break

        case "2B":
            info = {
                nome: "Resgate Senha RAV",
                nao_conv: true,
            }
            break

        case "31":
            info = {
                nome: "Nome do Emissor",
            }
            break

        case "33":
            info = {
                nome: "Nome do Portador",
            }
            break

        case "35":
            info = {
                nome: "Form Factor Indicator",
            }
            break

        case "36":
            info = {
                nome: "Criptograma de validação de Host",
                nao_conv: true,
            }
            break

        case "37":
            info = {
                nome: "TAG 8A Amex Full",
            }
            break

        case "3A":
            info = {
                nome: "Data Host para atualização do terminal",
                nao_conv: true,
            }
            break

        case "3B":
            info = {
                nome: "Nome do Portador",
            }
            break

        case "3C":
            info = {
                nome: "PAN",
            }
            break

        case "3D":
            info = {
                nome: "Lista de Pré",
                nao_conv: true,
                breakFunc: break_bit47_pos_tag3D,
            }
            break

        case "3E":
            info = {
                nome: "Código de Resposta Emissor",
            }
            break

        case "50":
            info = {
                nome: "Telefone do Comprador",
                formato: kFMT_BCD,
            }
            break

        case "51":
            info = {
                nome: "Nome do Comprador",
                formato: kFMT_HEXA,
            }
            break

        case "52":
            info = {
                nome: "Data Pagamento ITI",
                nao_conv: true,
            }
            break

        case "53":
            info = {
                nome: "Hora Pagamento ITI",
                nao_conv: true,
            }
            break

        case "54":
            info = {
                nome: "CPF do Portador",
                nao_conv: true,
            }
            break

        case "55":
            info = {
                nome: "Número do Pedido ITI",
                formato: kFMT_BCD,
            }
            break

        case "56":
            info = {
                nome: "Habilitação QR Code Offline",
            }
            break

        case "57":
            info = {
                nome: "Cartão Mascarado",
            }
            break

        case "58":
            info = {
                nome: "NSU Transação Financeira",
            }
            break

        case "90":
            info = {
                nome: "KSN do Número do cartão (DE02)",
                nao_conv: true,
                breakFunc: break_bit47_pos_tag10,
            }
            break

        case "91":
            info = {
                nome: "KSN da Trilha 2 (DE35)",
                nao_conv: true,
                breakFunc: break_bit47_pos_tag10,
            }
            break

        case "92":
            info = {
                nome: "KSN da Trilha 1 (DE45)",
                nao_conv: true,
                breakFunc: break_bit47_pos_tag10,
            }
            break

        case "93":
            info = {
                nome: "KSN do MAC do Valor (DE47 tag 0x0F)",
                nao_conv: true,
                breakFunc: break_bit47_pos_tag10,
            }
            break

        case "94":
            info = {
                nome: "KSN do CVC2 (DE48 tag 0x30)",
                nao_conv: true,
                breakFunc: break_bit47_pos_tag10,
            }
            break

        case "95":
            info = {
                nome: "KSN dos dados de Confirmação Positiva (DE48 tag 0x50) ou Referida (DE48 tag 0x51)",
                nao_conv: true,
            }
            break

        case "96":
            info = {
                nome: "Indicador de formato de dados sensíveis para criptografia",
            }
            break
    }

    return info
}
