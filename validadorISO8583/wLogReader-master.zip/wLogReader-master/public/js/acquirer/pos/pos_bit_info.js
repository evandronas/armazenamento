// pos_bit_info.js

function get_bit_pos(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 2:
            info.formato = kFMT_BIN
            break

        case 3:
            info.formato = kFMT_BCD
            break

        case 4:
            info.formato = kFMT_BCD
            break

        case 6:
            info.formato = kFMT_BCD
            break

        case 7:
            info.formato = kFMT_BCD
            break

        case 10:
            info.formato = kFMT_BCD
            break

        case 11:
            info.formato = kFMT_BCD
            break

        case 12:
            info.formato = kFMT_BCD
            break

        case 13:
            info.formato = kFMT_BCD
            break

        case 14:
            info.formato = kFMT_BCD
            break

        case 15:
            info.formato = kFMT_BCD
            break

        case 22:
            info.len = 4
            info.formato = kFMT_BCD
            break

        case 23:
            info.len = 4
            info.formato = kFMT_BCD
            break

        case 24:
            info.len = 4
            info.formato = kFMT_BCD
            break

        case 35:
            info.formato = kFMT_BCD
            break

        case 45:
            info.nao_conv = true
            break

        case 47:
            info.nao_conv = true
            info.break_bit_func = break_bit47_pos
            break

        case 48:
            info.nao_conv = true
            info.break_bit_func = break_bit48_pos
            break

        case 52:
            info.formato = kFMT_BIN
            break

        case 55:
            info.nao_conv = true
            info.break_bit_func = genBreakBit55Puro
            break

        case 56:
            info.nao_conv = true
            info.break_bit_func = break_bit56_pos
            break

        case 57:
            info.nao_conv = true
            info.break_bit_func = break_bit57_pos
            break

        case 61:
            info.break_bit_func = break_bit61_pos
            break
    }

    return info
}
