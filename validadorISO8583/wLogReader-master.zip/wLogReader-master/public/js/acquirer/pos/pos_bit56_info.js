// pos_bit56_tag.js

function break_bit56_pos_info(tag)
{
    var info = {}

    tag = tag.toLowerCase()

    switch (tag)
    {
        case "01": // nao esta na espec
            info = {
                nome: "DDD",
                nao_conv: true,
            }
            break

        case "02": // nao esta na espec
            info = {
                nome: "Número do Celular",
                nao_conv: true,
            }
            break

        case "03": // nao esta na espec
            info = {
                nome: "Operadora",
                nao_conv: true,
            }
            break

        case "04":
            info = {
                nome: "NSU Serviço",
                nao_conv: true,
            }
            break

        case "05":
            info = {
                nome: "NSU Serviço da última confirmada",
                nao_conv: true,
            }
            break

        case "06": // nao esta na espec
            info = {
                nome: "Código de Autorização da Operadora",
                nao_conv: true,
            }
            break

        case "07": // nao esta na espec
            info = {
                nome: "Terminal Físico",
            }
            break

        case "08": // nao esta na espec
            info = {
                nome: "Estabelecimento Físico",
            }
            break

        case "09": // nao esta na espec
            info = {
                nome: "Indicador de Consulta de Valores",
                nao_conv: true,
            }
            break

        case "0a":
            info = {
                nome: "Mensagem da transação de serviço",
            }
            break

        case "0c":
            info = {
                nome: "Nome fantasia",
            }
            break

        case "0d":
            info = {
                nome: "Código do serviço",
                nao_conv: true,
            }
            break

        case "0e":
            info = {
                nome: "Stan da transação original",
                nao_conv: true,
            }
            break

        case "0f":
            info = {
                nome: "Agência de Relacionamento",
                nao_conv: true,
            }
            break

        case "18":
            info = {
                nome: "Corban: Codigo de Barras",
                nao_conv: true,
            }
            break

        case "40":
            info = {
                nome: "Corban: Limite para pagamento em Dinheiro",
                nao_conv: true,
            }
            break

        case "42":
            info = {
                nome: "Corban: CPF do Pagador",
                nao_conv: true,
            }
            break

        case "43":
            info = {
                nome: "Corban: Data de Nascimento do Pagador",
                nao_conv: true,
            }
            break
    }

    return info
}
