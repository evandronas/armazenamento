// pdv_gen.js

function format_bit42_PDV(value)
{
    // pegando o terminal
    var term = value.substr(0, 6)

    // pegando o pv
    var pv = value.substr(6, 9)

    // formatando
    return "Terminal PV" + term + " " + "Estabelecimento " + pv
}
