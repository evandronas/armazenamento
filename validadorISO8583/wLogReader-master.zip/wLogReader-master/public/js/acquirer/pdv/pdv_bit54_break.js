// pdv_bit48_break.js

function break_bit54_pdv()
{
    var space = 15

    var len
    var valor
    var valor_conv
    var desc
    var infodisp

    while(msg_break_bit.length != 0)
    {
        // tipo da conta
        len = 2
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Tipo da Conta",
            nomeCampoSpace: space,
            valorOrig: valor,
            convEbc: true,
        }
        genDisplayInfo(infodisp)

        // tipo do valor
        len = 2
        valor = get_field_break_bit(len * 2)
        valor_conv = conv_ebc2a(valor)
        switch(valor_conv)
        {
            case "30":
                desc = "Aprovação por saldo disponível"
                break

            case "40":
                desc = "Saque (Cashback)"
                break

            case "57":
                desc = "Valor original"
                break

            default:
                desc = undefined
                break
        }
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Tipo da Valor",
            nomeCampoSpace: space,
            valorOrig: valor,
            valorConv: valor_conv,
            desc: desc,
        }
        genDisplayInfo(infodisp)

        // código moeada
        len = 3
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Código Moeda",
            nomeCampoSpace: space,
            valorOrig: valor,
            convEbc: true,
        }
        genDisplayInfo(infodisp)

        // indicador
        len = 1
        valor = get_field_break_bit(len * 2)
        valor_conv = conv_ebc2a(valor)
        switch(valor_conv)
        {
            case "C":
                desc = "Crédito"
                break

            case "D":
                desc = "Débito"
                break

            case "V":
                desc = "Voucher/Voucher Frota"
                break

            default:
                desc = undefined
                break
        }
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Indicador",
            nomeCampoSpace: space,
            valorOrig: valor,
            valorConv: valor_conv,
            desc: desc,
        }
        genDisplayInfo(infodisp)

        // valor
        len = 12
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Valor",
            nomeCampoSpace: space,
            valorOrig: valor,
            convEbc: true,
            formatMoney: true,
        }
        genDisplayInfo(infodisp)
    }

    return 0
}
