// pdv_bit61_break.js

function break_bit61_pdv()
{
    var space = 63

    var len
    var valor_orig
    var valor_conv
    var desc
    var infodisp

    // posicao 1 - POS Terminal Attendance Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Attended terminal"
            break

        case "1":
            desc = "Unattended terminal (cardholder-activated terminal [CAT], home PC)"
            break

        case "2":
            desc = "No terminal used (voice/audio response unit [ARU] authorization)"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 01: POS Terminal Attendance Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 2 - POS Terminal Operator Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "no longer used"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 02: POS Terminal Operator Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 3 - POS Terminal Location Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "On premises of card acceptor facility"
            break

        case "1":
            desc = "Off premises of card acceptor facility (merchant terminal - remote location)"
            break

        case "2":
            desc = "On premises of cardholder (home PC)"
            break

        case "3":
            desc = "No terminal used (voice/ARU authorization)"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 03: POS Terminal Location Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 4 - POS Cardholder Presence Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Cardholder Present"
            break

        case "1":
            desc = "Cardholder not Present, unspecified"
            break

        case "2":
            desc = "Cardholder not Present, mail/facsimile order"
            break

        case "3":
            desc = "Cardholder not Present, phone/ARU order"
            break

        case "4":
            desc = "Cardholder not Present, standing order/recurring transactions"
            break

        case "5":
            desc = "Electronic order (home PC, Internet)"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 04: POS Cardholder Presence Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 5 - POS Card Presence Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Card Present"
            break

        case "1":
            desc = "Card not Present"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 05: POS Card Presence Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 6 - POS Card Capture Capabilities Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Terminal/operator has no card capture capability"
            break

        case "1":
            desc = "Terminal/operator has card capture capability"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 06: POS Card Capture Capabilities Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 7 - POS Transaction Status Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Normal request (original presentment)"
            break

        case "4":
            desc = "Preauthorized request (transações de pré-autorização e estorno de pré-autorização)"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 07: POS Transaction Status Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 8 - POS Transaction Security Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "No security concern"
            break

        case "1":
            desc = "Suspected fraud (merchant suspicious - code 10)"
            break

        case "2":
            desc = "identification verified"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 08: POS Transaction Security Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 9 - POS Transaction Routing Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "no longer used"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 09: POS Transaction Routing Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 10 - Cardholder-Activated Terminal Level Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Not a CAT transaction"
            break

        case "1":
            desc = "Authorized Level 1 CAT: Automated dispensing machine with PIN"
            break

        case "2":
            desc = "Authorized Level 2 CAT: Self service terminal"
            break

        case "3":
            desc = "Authorized Level 3 CAT: Limited amount terminal"
            break

        case "4":
            desc = "Authorized Level 4 CAT: In-flight commerce"
            break

        case "5":
            desc = "Reserved"
            break

        case "6":
            desc = "Authorized Level 6 CAT: Electronic commerce"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 10: Cardholder-Activated Terminal Level Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)

    // posicao 11 - POS Card Data Terminal Input Capability Indicator
    len = 1
    valor_orig = get_field_break_bit(len * 2)
    valor_conv = conv_ebc2a(valor_orig)
    switch(valor_conv)
    {
        case "0":
            desc = "Unknown Or Unspecified"
            break

        case "1":
            desc = "No Terminal Used"
            break

        case "2":
            desc = "Magnetic Stripe Reader"
            break

        case "3":
            desc = "Contactless M/Chip / qVSDC / MagStripe / MSD"
            break

        case "4":
            desc = "Optical Character Recognition"
            break

        case "5":
            desc = "Magnetic stripe reader and Europay-MasterCard-Visa (EMV) specification- compatible integrated circuit card (ICC) reader"
            break

        case "6":
            desc = "Key entry only"
            break

        case "7":
            desc = "Magnetic stripe reader and key entry"
            break

        case "8":
            desc = "Magnetic stripe reader, key entry and EMV - compatible ICC reader"
            break

        case "9":
            desc = "EMV compatible ICC reader"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Posição 11: POS Card Data Terminal Input Capability Indicator",
        nomeCampoSpace: space,
        valorOrig: valor_orig,
        valorConv: valor_conv,
        desc: desc,
    }
    genDisplayInfo(infodisp)
}
