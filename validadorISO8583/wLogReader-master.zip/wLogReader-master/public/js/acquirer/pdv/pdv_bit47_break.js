// break BIT47 PDV

function break_bit47_pdv()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTL: 3,
        infoFunc: break_bit47_pdv_info,
        nomeCampo: "TAG",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)
}

function break_bit47_pdv_tag04() // cvm
{
    genBreakCvm(kDEF_PDV)
}

function break_bit47_pdv_tag16() // ksn
{
    genBreakKsn(kDEF_PDV)
}
