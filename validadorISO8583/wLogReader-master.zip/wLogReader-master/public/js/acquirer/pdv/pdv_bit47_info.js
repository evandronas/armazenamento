// pdv_bit47_info.js

function break_bit47_pdv_info(tag)
{
    var info = {}

    tag = tag.toUpperCase()

    switch (tag)
    {
        case "003":
            info = {
                nome: "Versões Aplicativo Cliente",
            }
            break

        case "004":
            info = {
                nome: "CVM Result",
                breakFunc: break_bit47_pdv_tag04,
            }
            break

        case "005":
            info = {
                nome: "CTAH Voucher",
            }
            break

        case "006":
            info = {
                nome: "By Phone/Internet",
            }
            break

        case "007":
            info = {
                nome: "Marketplace - Endereço",
            }
            break

        case "008":
            info = {
                nome: "Marketplace - CEP",
            }
            break

        case "009":
            info = {
                nome: "Marketplace - CNPJ",
            }
            break

        case "010":
            info = {
                nome: "Dados DE55 gerados no 2nd GAC",
            }
            break

        case "011":
            info = {
                nome: "Issuer Script Result (ISR)",
            }
            break

        case "012":
            info = {
                nome: "Marketplace - ID Facilitador",
            }
            break

        case "013":
            info = {
                nome: "Marketplace - ID Submerchant",
            }
            break

        case "014":
            info = {
                nome: "Marketplace - Estado",
            }
            break

        case "015":
            info = {
                nome: "MAC do Valor",
            }
            break

        case "016":
            info = {
                nome: "Chave DUKPT KSN",
                breakFunc: break_bit47_pdv_tag16,
            }
            break

        case "017":
            info = {
                nome: "Chave DUKPT KSN (Confirmação Positiva ou Referida)",
            }
            break

        case "020":
            info = {
                nome: "Biblioteca Compartilhada",
            }
            break

        case "027":
            info = {
                nome: "Informações PinPad",
            }
            break

        case "029":
            info = {
                nome: "Dados Simulação Crediário",
            }
            break

        case "030":
            info = {
                nome: "CVC2",
            }
            break

        case "033":
            info = {
                nome: "Saldo Disponível",
            }
            break

        case "034":
            info = {
                nome: "Fornecedor Aplicação",
            }
            break

        case "035":
            info = {
                nome: "Número SIM Card",
            }
            break

        case "036":
            info = {
                nome: "Número IMEI",
            }
            break

        case "037":
            info = {
                nome: "Conexão GPRS ou WiFi",
            }
            break

        case "053":
            info = {
                nome: "Form Factor Indicator",
            }
            break

        case "056":
            info = {
                nome: "CNPJ",
            }
            break
    }

    return info
}
