// pdv_bit48_break.js

var bit48_identificacao

function break_bit48_pdv()
{
    // identificacao
    bit48_identificacao = get_field_break_bit(4)

    switch (conv_ebc2a(bit48_identificacao))
    {
        case "R1": // credito, crediario e pre-autorizacao
            break_bit48_pdv_R1()
            break

        case "CP": // debito
            break_bit48_pdv_CP()
            break

        case "VO": // voucher
            break_bit48_pdv_VO()
            break

        case "VF": // voucher frota
            break_bit48_pdv_VF()
            break

        case "AD": // private label e demais casos
            break_bit48_pdv_AD()
            break
    }
}

function break_bit48_pdv_R1()
{
    var qtde_space = 55
    var len
    var valor

    var infodisp
    var tipoR1 = {}

    switch((msg_break_bit.length / 2) + 2)
    {
        case 49:
            tipoR1.iata = true
            break
    }

    //
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificação",
        nomeCampoSpace: qtde_space,
        valorOrig: bit48_identificacao,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 3
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CVC2",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    // tratamento para iata
    if (tipoR1.iata)
    {
        //
        len = 12
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Taxa de Embarque",
            nomeCampoSpace: qtde_space,
            valorOrig: valor,
            convEbc: true,
            formatMoney: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 12
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Valor de Entrada",
            nomeCampoSpace: qtde_space,
            valorOrig: valor,
            convEbc: true,
            formatMoney: true,
        }
        genDisplayInfo(infodisp)
    }

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Tipo de Criptografia",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
        descFunc: get_desc_ind_crypto,
    }
    genDisplayInfo(infodisp)

    //
    len = 14
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificação do Pedido",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Solicita Assinatura Portador",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Capacidade Terminal Transação Referida",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Quantidade Máxima de Prompts para Transação Referida",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}

function break_bit48_pdv_CP()
{
    var qtde_space = 55

    var len
    var valor
    var infodisp

    //
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificação",
        nomeCampoSpace: qtde_space,
        valorOrig: bit48_identificacao,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Tipo de Criptografia",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
        descFunc: get_desc_ind_crypto,
    }
    genDisplayInfo(infodisp)

    //
    len = 5
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CVC2",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 14
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificação do Pedido",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Capacidade Terminal Confirmação Positiva",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Quantidade Máxima de Prompts para Confirmação Positiva",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Indicativo Coleta de Dados para Confirmação Positiva",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 15
    valor = get_field_break_bit(len * 2)
    if (valor.length > 0)
    {
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Dados para Confirmação Positiva",
            nomeCampoSpace: qtde_space,
            valorOrig: valor,
            convEbc: true,
        }
        genDisplayInfo(infodisp)
    }
}

function break_bit48_pdv_VO()
{
    var qtde_space = 25

    var len
    var valor
    var infodisp

    //
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificação",
        nomeCampoSpace: qtde_space,
        valorOrig: bit48_identificacao,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Tipo de Criptografia",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
        descFunc: get_desc_ind_crypto,
    }
    genDisplayInfo(infodisp)

    //
    len = 5
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CVC2",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 14
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificação do Pedido",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Saldo Parcial",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}

function break_bit48_pdv_VF()
{
    var qtde_space = 25

    var len
    var valor
    var infodisp

    //
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificação",
        nomeCampoSpace: qtde_space,
        valorOrig: bit48_identificacao,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Tipo de Criptografia",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
        descFunc: get_desc_ind_crypto,
    }
    genDisplayInfo(infodisp)

    //
    len = 5
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "CVC2",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 14
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Identificação do Pedido",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 1
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Saldo Parcial",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 8
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código do Veículo",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 8
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código do Condutor",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Tipo do Serviço",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 2
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Código do Combustível",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 7
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "QTD",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)

    //
    len = 10
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Quilometragem",
        nomeCampoSpace: qtde_space,
        valorOrig: valor,
        convEbc: true,
    }
    genDisplayInfo(infodisp)
}

function break_bit48_pdv_AD()
{
    var qtde_space = 25
    var len
    var valor

    if (msg_break_bit.length == 42) // ate L0602
    {
        //
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Identificação",
            nomeCampoSpace: qtde_space,
            valorOrig: bit48_identificacao,
            convEbc: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 2
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Tipo de Criptografia",
            nomeCampoSpace: qtde_space,
            valorOrig: valor,
            convEbc: true,
            descFunc: get_desc_ind_crypto,
        }
        genDisplayInfo(infodisp)

        //
        len = 5
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "CVC2",
            nomeCampoSpace: qtde_space,
            valorOrig: valor,
            convEbc: true,
            descFunc: get_desc_ind_crypto,
        }
        genDisplayInfo(infodisp)

        //
        len = 14
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Identificação do Pedido",
            nomeCampoSpace: qtde_space,
            valorOrig: valor,
            convEbc: true,
        }
        genDisplayInfo(infodisp)
    }
    else if (msg_break_bit.length == 32) // a partir L0603
    {
        //
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Identificação",
            nomeCampoSpace: qtde_space,
            valorOrig: bit48_identificacao,
            convEbc: true,
        }
        genDisplayInfo(infodisp)

        //
        len = 2
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Tipo de Criptografia",
            nomeCampoSpace: qtde_space,
            valorOrig: valor,
            convEbc: true,
            descFunc: get_desc_ind_crypto,
        }
        genDisplayInfo(infodisp)

        //
        len = 14
        valor = get_field_break_bit(len * 2)
        infodisp = {
            display: true,
            qtdeTabL1: true,
            nomeCampo: "Identificação do Pedido",
            nomeCampoSpace: qtde_space,
            valorOrig: valor,
            convEbc: true,
        }
        genDisplayInfo(infodisp)
    }
}
