// pdv_bit56_break.js

function break_bit56_pdv()
{
    var tlvinfo = {
        formato: kFMT_EBC,
        lenTagDiff: 6,
        ignoreTagConv: false,
        lenLengthDiff: 6,
        ignoreLenConv: false,
        padLen: true,
        infoFunc: break_bit56_pdv_info,
        nomeCampo: "TAG",
        qtdeTab: 16,
    }
    genTLVBreak(tlvinfo)

    return 0
}
