// pdv_bit_info.js

function get_bit_pdv(bit)
{
    var info

    info = get_bit_gen_iso_v0(bit)

    switch (bit)
    {
        case 42:
            info.formatBIT42 = true
            break

        case 43:
            info.break_bit_func = gen_bit43_break_ebc
            break

        case 47:
            info.break_bit_func = break_bit47_pdv
            break

        case 48:
            info.break_bit_func = break_bit48_pdv
            break

        case 52:
            delete info.nao_conv
            break

        case 54:
            info.tipo = kLLvar
            info.break_bit_func = break_bit54_pdv
            break

        case 55:
            info.break_bit_func = genBreakBit55Ebc
            break

        case 56:
            info.break_bit_func = break_bit56_pdv
            break

        case 61:
            info.break_bit_func = break_bit61_pdv
            break

        case 90:
            info.break_bit_func = break_bit90_pdv
            break
    }

    return info
}
