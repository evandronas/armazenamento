// pdv_get_header.js

function get_header_pdv(pdv, tipo)
{
    /*
    Dominios do NII

    000050 - Logon. Inicializacao
    111050 - Financeiras
    222003 - Injecao de chaves
    */

    var info = {}

    if (pdv == kFE_PDV75)
    {
        info.len_msg_pdv75 = get_field_msg(4)
    }

    switch (tipo)
    {
        case kDRV_PDV_IP:
            var header = get_field_msg(6)

            // NII
            var header_nii = header

            break

        case kDRV_PDV_PROTOM:
            var len_header_protom_req = 40 // len header request
            var len_header_protom_res = 46 // len header response
            var isReq = true
            var isRes = false
            var msgtype

            msgtype = msg.substr(len_header_protom_req, 8)
            msgtype = conv_ebc2a(msgtype)
            // console.log("msgtype [%s]", msgtype)

            if (validMsgType(msgtype) < 0)
            {
                msgtype = msg.substr(len_header_protom_res, 8)
                msgtype = conv_ebc2a(msgtype)

                if (validMsgType(msgtype) < 0)
                {
                    info = { ret: false }

                    return info
                }

                isReq = false
                isRes = true
            }

            info = {}

            if (isReq)
            {
                var header = get_field_msg(len_header_protom_req)
                info.header = header
            }
            else if (isRes)
            {
                var header = get_field_msg(len_header_protom_res)
                info.header = header
            }

            break
        case kDRV_PDV_INTELLINAC:
            var header = get_field_msg(46)

            // Msg ID
            var header_msg_id = header.substr(0, 2)

            // TPDU
            var header_tpdu = header.substr(2, 8)

            // EC Code
            var header_ec_code = header.substr(10, 28)

            // NII
            var header_nii = header.substr(40, 6)

            //alert('get_header_PDV - msg ID: ' + header_msg_id)
            //alert('get_header_PDV - TPDU: ' + header_tpdu)
            //alert('get_header_PDV - EC Code: ' + header_ec_code)
            //alert('get_header_PDV - NII: ' + header_nii)

            break

        case kDRV_PDV_QH:
            break
    }

    // formatando o header para retornar
    var header_formatted = ""
    if (info.len_msg_pdv75)
    {
        info.header = info.len_msg_pdv75 + info.header
        header_formatted += "Tamanho Mensagem ISO - " + info.len_msg_pdv75 + " [" + parseInt(info.len_msg_pdv75, 16) + "]" + get_break_line()
    }

    if (header)
    {
        header_formatted += "Header - " + header + "<br>"
    }

    if (header_msg_id)
    {
        header_formatted += "Msg ID - " + header_msg_id + "<br>"
    }

    if (header_tpdu)
    {
        header_formatted += "TPDU - " + header_tpdu + "<br>"
    }

    if (header_ec_code)
    {
        header_formatted += "EC Code - " + header_ec_code + mostrarColchete(conv_ebc2a(header_ec_code)) + "<br>"
    }

    if (header_nii)
    {
        header_formatted += "NII - " + header_nii + "<br>"
    }

    // criando o objeto de retorno
    info = {
        ret: true,
        header: header_formatted,
        header_clean: header,
    }

    return info
}
