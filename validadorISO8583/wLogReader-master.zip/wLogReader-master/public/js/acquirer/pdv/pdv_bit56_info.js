// pdv_bit56_info.js

function break_bit56_pdv_info(tag)
{
    var info = {}

    tag = tag.toLowerCase()

    switch (tag)
    {
        //case "0x18":
        case "024":
            info = {
                nome: "Corban: Codigo de Barras",
            }
            break

        //case "0x40":
        case "064":
            info = {
                nome: "Corban: Limite para pagamento em Dinheiro",
            }
            break

        //case "0x41":
        case "065":
            info = {
                nome: "Corban: PDV habilitado para tratar limite",
            }
            break

        //case "0x42":
        case "066":
            info = {
                nome: "Corban: CPF do Pagador",
            }
            break

        //case "0x43":
        case "067":
            info = {
                nome: "Corban: Data de Nascimento do Pagador",
            }
            break
    }
    return info
}
