// get_bit_gen_iso_v0.js

// Definicao generica dos bits da ISO 8583 : 1987

/*
Propriedades do objeto com as informacoes de DE

tipo            [string]    nome do tipo do DE (Fixo, Lvar, LLvar ou LLLvar)
len             [num]       tamanho do DE quando eh fixo
formato         [string]    formato do mensagem (HEXA, EBC ou BCD) - o formato do DE sobreescreve esse formato
formatMoney     [bool]      true = realizar a formatacao como dinheiro
nao_conv        [bool]      true = nao realiza a conversao do valor
break_bit_func  [string]    nome da funcao para quebrar o bit
paramArray      [string]    array com string para passar como paremetro para a break_bit_func
*/

function get_bit_gen_iso_v0(bit)
{
    var info

    switch (bit)
    {
        case 2:  // Primary account number (PAN)
            info = {
                tipo: kLLvar,
            }
            break

        case 3:  // Processing code
            info = {
                tipo: kFixo,
                len: 6,
            }
            break

        case 4: // Amount, transaction
            info = {
                tipo: kFixo,
                len: 12,
                formatMoney: true,
            }
            break

        case 5: // Amount, settlement
            info = {
                tipo: kFixo,
                len: 12,
                formatMoney: true,
            }
            break

        case 6: // Amount, cardholder billing
            info = {
                tipo: kFixo,
                len: 12,
            }
            break

        case 7: // Transmission date & time
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 8: // Amount, cardholder billing fee
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 9: // Conversion rate, settlement
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 10: // Conversion rate, cardholder billing
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 11: // System trace audit number (STAN)
            info = {
                tipo: kFixo,
                len: 6,
            }
            break

        case 12: // Local transaction time (hhmmss)
            info = {
                tipo: kFixo,
                len: 6,
            }
            break

        case 13: // Local transaction date (MMDD)
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 14: // Expiration date
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 15: // Settlement date
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 16: // Currency conversion date
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 17: // Capture date
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 18: // Merchant type, or merchant category code
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 19: // Acquiring institution (country code)
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 20: // Acquiring institution (country code)
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 21: // Forwarding institution (country code)
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 22: // Point of service entry mode
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 23: // Application PAN sequence number
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 24: // Function code (ISO 8583:1993), or network international identifier (NII)
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 25: // Point of service condition code
            info = {
                tipo: kFixo,
                len: 2,
            }
            break

        case 26: // Point of service capture code
            info = {
                tipo: kFixo,
                len: 2,
            }
            break

        case 27: // Authorizing identification response length
            info = {
                tipo: kFixo,
                len: 1,
            }
            break

        case 28: // Amount, transaction fee
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 29: // Amount, settlement fee
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 30: // Amount, transaction processing fee
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 31: // Amount, settlement processing fee
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 32: // Acquiring institution identification code
            info = {
                tipo: kLLvar,
            }
            break

        case 33: // Forwarding institution identification code
            info = {
                tipo: kLLvar,
            }
            break

        case 34: // Primary account number, extended
            info = {
                tipo: kLLvar,
            }
            break

        case 35: // Track 2 data
            info = {
                tipo: kLLvar,
            }
            break

        case 36: // Track 3 data
            info = {
                tipo: kLLvar,
            }
            break

        case 37: // Retrieval reference number
            info = {
                tipo: kFixo,
                len: 12,
            }
            break

        case 38: // Authorization identification response
            info = {
                tipo: kFixo,
                len: 6,
            }
            break

        case 39: // Response code
            info = {
                tipo: kFixo,
                len: 2,
            }
            break

        case 40: // Service restriction code
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 41: // Card acceptor terminal identification
            info = {
                tipo: kFixo,
                len: 8,
            }
            break

        case 42: // Card acceptor identification code
            info = {
                tipo: kFixo,
                len: 15,
            }
            break

        case 43: // Card acceptor name/location
            info = {
                tipo: kFixo,
                len: 40,
            }
            break

        case 44: // Additional response data
            info = {
                tipo: kLLvar,
            }
            break

        case 45: // Track 1 data
            info = {
                tipo: kLLvar,
            }
            break

        case 46: // Additional data (ISO)
            info = {
                tipo: kLLLvar,
            }
            break

        case 47: // Additional data (national)
            info = {
                tipo: kLLLvar,
            }
            break

        case 48: // Additional data (private)
            info = {
                tipo: kLLLvar,
            }
            break

        case 49: // Currency code, transaction
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 50: // Currency code, settlement
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 51: // Currency code, cardholder billing
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 52: // Personal identification number data (PIN)
            info = {
                tipo: kFixo,
                len: 16,
                nao_conv: true, // propriedade que indica para nao realizar a conversao
            }
            break

        case 53: // Security related control information
            info = {
                tipo: kFixo,
                len: 16,
            }
            break

        case 54: // Additional amounts
            info = {
                tipo: kLLLvar,
            }
            break

        case 55: // ICC data – EMV having multiple tags
            info = {
                tipo: kLLLvar,
            }
            break

        case 56: // Reserved (ISO)
            info = {
                tipo: kLLLvar,
            }
            break

        case 57: // Reserved (national)
            info = {
                tipo: kLLLvar,
            }
            break

        case 58: // Reserved (national)
            info = {
                tipo: kLLLvar,
            }
            break

        case 59: // Reserved (national)
            info = {
                tipo: kLLLvar,
            }
            break

        case 60: // Reserved (national)
            info = {
                tipo: kLLLvar,
            }
            break

        case 61: // Reserved (private)
            info = {
                tipo: kLLLvar,
            }
            break

        case 62: // Reserved (private)
            info = {
                tipo: kLLLvar,
            }
            break

        case 63: // Reserved (private)
            info = {
                tipo: kLLLvar,
            }
            break

        case 64: // Message authentication code (MAC)
            info = {
                tipo: kFixo,
                len: 16,
            }
            break

        case 65: // Extended bitmap indicator
            info = {
                tipo: kFixo,
                len: 2,
            }
            break

        case 66: // Settlement code
            info = {
                tipo: kFixo,
                len: 1,
            }
            break

        case 67: // Extended payment code
            info = {
                tipo: kFixo,
                len: 2,
            }
            break

        case 68: // Receiving institution country code
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 69: // Settlement institution country code
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 70: // Network management information code
            info = {
                tipo: kFixo,
                len: 3,
            }
            break

        case 71: // Message number
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 72: // Last message's number
            info = {
                tipo: kFixo,
                len: 4,
            }
            break

        case 73: // Action date (YYMMDD)
            info = {
                tipo: kFixo,
                len: 6,
            }
            break

        case 74: // Number of credits
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 75: // Credits, reversal number
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 76: // Number of debits
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 77: // Debits, reversal number
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 78: // Transfer number
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 79: // Transfer, reversal number
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 80: // Number of inquiries
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 81: // Number of authorizations
            info = {
                tipo: kFixo,
                len: 10,
            }
            break

        case 82: // Credits, processing fee amount
            info = {
                tipo: kFixo,
                len: 12,
            }
            break

        case 83: // Credits, transaction fee amount
            info = {
                tipo: kFixo,
                len: 12,
            }
            break

        case 84: // Debits, processing fee amount
            info = {
                tipo: kFixo,
                len: 12,
            }
            break

        case 85: // Debits, transaction fee amount
            info = {
                tipo: kFixo,
                len: 12,
            }
            break

        case 86: // Total amount of credits
            info = {
                tipo: kFixo,
                len: 16,
            }
            break

        case 87: // Credits, reversal amount
            info = {
                tipo: kFixo,
                len: 16,
            }
            break

        case 88: // Total amount of debits
            info = {
                tipo: kFixo,
                len: 16,
            }
            break

        case 89: // Debits, reversal amount
            info = {
                tipo: kFixo,
                len: 16,
            }
            break

        case 90: // Original data elements
            info = {
                tipo: kFixo,
                len: 42,
            }
            break

        case 91: // File update code
            info = {
                tipo: kFixo,
                len: 1,
            }
            break

        case 92: // File security code
            info = {
                tipo: kFixo,
                len: 2,
            }
            break

        case 93: // Response indicator
            info = {
                tipo: kFixo,
                len: 5,
            }
            break

        case 94: // Service indicator
            info = {
                tipo: kFixo,
                len: 7,
            }
            break

        case 95: // Replacement amounts
            info = {
                tipo: kFixo,
                len: 42,
            }
            break

        case 96: // Message security code
            info = {
                tipo: kFixo,
                len: 128,
            }
            break

        case 97: // Net settlement amount
            info = {
                tipo: kFixo,
                len: 16,
            }
            break

        case 98: // Payee
            info = {
                tipo: kFixo,
                len: 25,
            }
            break

        case 99: // Settlement institution identification code
            info = {
                tipo: kLLvar,
            }
            break

        case 100: // Receiving institution identification code
            info = {
                tipo: kLLvar,
            }
            break

        case 101: // File name
            info = {
                tipo: kLLvar,
            }
            break

        case 102: // Account identification 1
            info = {
                tipo: kLLvar,
            }
            break

        case 103: // Account identification 2
            info = {
                tipo: kLLvar,
            }
            break

        case 104: // Transaction description
            info = {
                tipo: kLLLvar,
            }
            break

        case 105: // Reserved for ISO use
            info = {
                tipo: kLLLvar,
            }
            break

        case 106: // Reserved for ISO use
            info = {
                tipo: kLLLvar,
            }
            break

        case 107: // Reserved for ISO use
            info = {
                tipo: kLLLvar,
            }
            break

        case 108: // Reserved for ISO use
            info = {
                tipo: kLLLvar,
            }
            break

        case 109: // Reserved for ISO use
            info = {
                tipo: kLLLvar,
            }
            break

        case 110: // Reserved for ISO use
            info = {
                tipo: kLLLvar,
            }
            break

        case 111: // Reserved for ISO use
            info = {
                tipo: kLLLvar,
            }
            break

        case 112: // Reserved for national use
            info = {
                tipo: kLLLvar,
            }
            break

        case 113: // Reserved for national use
            info = {
                tipo: kLLLvar,
            }
            break

        case 114: // Reserved for national use
            info = {
                tipo: kLLLvar,
            }
            break

        case 115: // Reserved for national use
            info = {
                tipo: kLLLvar,
            }
            break

        case 116: // Reserved for national use
            info = {
                tipo: kLLLvar,
            }
            break

        case 117: // Reserved for national use
            info = {
                tipo: kLLLvar,
            }
            break

        case 118: // Reserved for national use
            info = {
                tipo: kLLLvar,
            }
            break

        case 119: // Reserved for national use
            info = {
                tipo: kLLLvar,
            }
            break

        case 120: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break

        case 121: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break

        case 122: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break

        case 123: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break

        case 124: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break

        case 125: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break

        case 126: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break

        case 127: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break

        case 128: // Reserved for private use
            info = {
                tipo: kLLLvar,
            }
            break
    }

    return info
}
