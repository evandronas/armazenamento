// convert.js

function hex2a(hex)
{
    var str = ""

    for (var i = 0; i < hex.length; i += 2)
    {
        var v = parseInt(hex.substr(i, 2), 16)
        if (v) str += String.fromCharCode(v)
    }

    return str
}

function hex16b2a(hex)
{
    return parseInt(hex, 16).toString()
}

function formatMoney(v)
{
    var aux
    var formatted
    // recebe a string com o valor e devolve o formatado

    // DE04     = 000000108050
    // Retorno  = R$ 1.080,50

    var len = v.length
    // console.log("v [%s] len [%s]", v, len)

    var inteiro = v.substr(0, len - 2)
    inteiro = parseInt(inteiro, 10).toString()
    // console.log("inteiro [%s]", inteiro)

    if (inteiro.length >= 1 && inteiro.length <= 3)
    {
        // console.log("1 - 3")
        formatted = inteiro
    }
    else if (inteiro.length >= 4 && inteiro.length <= 6)
    {
        // console.log("4 - 6")
        aux = inteiro.substr(0, inteiro.length - 3)

        formatted = aux + "." + inteiro.substr(inteiro.length - 3)
    }
    else if (inteiro.length >= 7 && inteiro.length <= 9)
    {
        // console.log("7 - 9")
        aux = inteiro.substr(0, inteiro.length - 6)

        formatted = aux + "." + inteiro.substr(aux.length, 3) + "." + inteiro.substr(aux.length + 3)
    }
    else if (inteiro.length >= 10 && inteiro.length <= 12)
    {
        // console.log("10 - 12")
        aux = inteiro.substr(0, inteiro.length - 9)

        formatted = aux + "." + inteiro.substr(aux.length, 3) + "." + inteiro.substr(aux.length + 3, 3) + "." + inteiro.substr(aux.length + 6)
    }

    var centavo = v.substr(len - 2, 2)
    // console.log("centavo [%s]", centavo)

    // var formatMoney = "R$ " + inteiro + "," + padCENTAVO(centavo)
    var formatMoney = "R$ " + formatted + "," + centavo

    return formatMoney
}

function format_pct(valor, len_decimal)
{
    if (!len_decimal)
        len_decimal = 2

    var decimal = valor.substr(valor.length - len_decimal, len_decimal)

    var len_inteiro = valor.length - len_decimal
    var inteiro = valor.substr(0, len_inteiro)
    inteiro = parseInt(inteiro, 10)

    //

    // var format_pct = inteiro + "," + padCENTAVO(decimal) + "%"
    var format_pct = inteiro + ","
    if (len_decimal != 1)
        format_pct += padCENTAVO(decimal)
    else
        format_pct += decimal
    format_pct += "%"

    return format_pct
}

function formatDate(data, formatIn, formatOut)
{
    // console.log("formatDate - data [%s] formatIn [%s] formatOut [%s] - INICIO", data, formatIn, formatOut)
    data = data.toString()

    var dt = ""
    var dia
    var mes
    var ano

    switch(formatIn)
    {
        case kDATA_YYYYMMDD:
            // console.log("case YYYYMMDD formatIn")
            if (data.length != 8)
                return

            ano = data.substr(0, 4)
            mes = data.substr(4, 2)
            dia = data.substr(6, 2)
            break

        case kDATA_YYMMDD:
            // console.log("case YYMMDD formatIn")
            if (data.length != 6)
                return

            ano = data.substr(0, 2)
            mes = data.substr(2, 2)
            dia = data.substr(4, 2)
            break

        // case kDATA_DDMMYYYY:
        // 	break

        case kDATA_DDMMYYYY:
            // console.log("case DDMMYYYY formatIn")
            if (data.length != 8)
                return

            dia = data.substr(0, 2)
            mes = data.substr(4, 2)
            ano = data.substr(4)
            break

        default:
            // console.log("formatDate - formatIn default")
            break
    }

    // console.log("formatDate - dia [%s] mes [%s] ano [%s] - MEIO", dia, mes, ano)

    switch(formatOut)
    {
        case kDATA_YYYYMMDD:
            // console.log("case YYYYMMDD/YYMMDD formatOut")
            if (ano && mes && dia)
            {
                if (ano.length == 4)
                {
                    dt = ano
                }
                else
                {
                    dt = "20" + ano
                }

                dt += "/" + mes + "/" + dia
            }
            break

        case kDATA_YYMMDD:
            // console.log("case YYMMDD formatOut")
            if (ano && mes && dia)
            {
                if (ano.length == 4)
                {
                    dt = ano.substr(2, 2)
                }
                else
                {
                    dt = ano
                }

                dt += "/" + mes + "/" + dia
            }
            break

        case kDATA_DDMMYY:
            // console.log("case DDMMYY formatOut")
            if (ano && mes && dia)
            {
                dt += dia + "/" + mes + "/"

                if (ano.length == 4)
                {
                    dt += ano.substr(2, 2)
                }
                else
                {
                    dt += ano
                }
            }
            break

        case kDATA_DDMMYYYY:
            // console.log("case DDMMYYYY formatOut")
            if (ano && mes && dia)
            {
                dt = dia + "/" + mes + "/"

                if (ano.length == 4)
                {
                    dt += ano
                }
                else
                {
                    dt += "20" + ano
                }
            }
            break

        default:
            // console.log("formatDate - formatOut default")
            break
    }

    // console.log("formatData - return [%s] - FIM", dt)

    return dt
}

function hex2bin(hex)
{
    var bin = -1

    // forcar a string pra upper
    hex = hex.toUpperCase()

    switch (hex) {

        case "0":
            bin = "0000"
            break

        case "1":
            bin = "0001"
            break

        case "2":
            bin = "0010"
            break

        case "3":
            bin = "0011"
            break

        case "4":
            bin = "0100"
            break

        case "5":
            bin = "0101"
            break

        case "6":
            bin = "0110"
            break

        case "7":
            bin = "0111"
            break

        case "8":
            bin = "1000"
            break

        case "9":
            bin = "1001"
            break

        case "A":
            bin = "1010"
            break

        case "B":
            bin = "1011"
            break

        case "C":
            bin = "1100"
            break

        case "D":
            bin = "1101"
            break

        case "E":
            bin = "1110"
            break

        case "F":
            bin = "1111"
            break

    }

    return bin;
}

function hex2dec(hex)
{
    var dec = -1

    // forcar a string pra upper
    hex = hex.toUpperCase()

    switch (hex)
    {
        case "0":
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
            dec = parseInt(hex, 10) // transformando pra numero - usando radix 10
            break

        case "A":
            dec = 10
            break

        case "B":
            dec = 11
            break

        case "C":
            dec = 12
            break

        case "D":
            dec = 13
            break

        case "E":
            dec = 14
            break

        case "F":
            dec = 15
            break

        default:
            // valor em hexa com 2 casas - 10 ate FF

            var dec1 = ""

            var pos1 = hex.substring(0, 1)
            //alert("posicao 1: " + pos1);

            switch (pos1)
            {
                case "0": // nunca deve cair
                case "1":
                    dec1 = "16"
                    break

                case "2":
                    dec1 = "32"
                    break

                case "3":
                    dec1 = "48"
                    break

                case "4":
                    dec1 = "64"
                    break

                case "5":
                    dec1 = "80"
                    break

                case "6":
                    dec1 = "96"
                    break

                case "7":
                    dec1 = "112"
                    break

                case "8":
                    dec1 = "128"
                    break

                case "9":
                    dec1 = "144"
                    break

                case "A":
                    dec1 = "160"
                    break

                case "B":
                    dec1 = "176"
                    break

                case "C":
                    dec1 = "192"
                    break

                case "D":
                    dec1 = "208"
                    break

                case "E":
                    dec1 = "224"
                    break

                case "F":
                    dec1 = "240"
                    break
            }

            var pos2 = hex.substring(1, 2)

            var dec2 = hex2dec(pos2)

            // convertendo pra numero
            dec1 = parseInt(dec1, 10) // transformando pra numero - usando radix 10
            dec2 = parseInt(dec2, 10) // transformando pra numero - usando radix 10

            return dec1 + dec2

            break
    }

    //alert("vai retornar: " + dec);
    return dec
}

function conv_ebc2a(value)
{
    var conv = ""
    for (var i = 0, len = value.length; i < len; i += 2)
    {
        var v = value.substr(i, 2)
        if (v == "@@")
        {
            conv += v
        }
        else
        {
            conv += ebcdic2a(v)
        }
    }

    return conv
}

function ebcdic2a(value)
{
    var asc
    var arr_8 = ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
    var arr_9 = ["j", "k", "l", "m", "n", "o", "p", "q", "r"]
    var arr_A = [" ", "s", "t", "u", "v", "w", "x", "y", "z"]
    var arr_C = ["A", "B", "C", "D", "E", "F", "G", "H", "I"]
    var arr_D = ["J", "K", "L", "M", "N", "O", "P", "Q", "R"]
    var arr_E = [" ", "S", "T", "U", "V", "W", "X", "Y", "Z"]

    value = value.toLowerCase()

    switch (value)
    {
        case "25":
            asc = "LF" // line fit
            break

        case "40":
            asc = " " // branco
            break

        case "42":
            asc = "â"
            break

        case "43":
            asc = "ä"
            break

        case "44":
            asc = "à"
            break

        case "45":
            asc = "á"
            break

        case "46":
            asc = "ã"
            break

        case "47":
            asc = "å"
            break

        case "48":
            asc = "ç"
            break

        case "49":
            asc = "ñ"
            break

        case "4a":
            asc = "¢"
            break

        case "4b":
            asc = "." // ponto
            break

        case "4c":
            asc = "<"
            break

        case "4d":
            asc = "("
            break

        case "4e":
            asc = "+"
            break

        case "4f":
            asc = "|"
            break

        case "50":
            asc = "&"
            break

        case "51":
            asc = "é"
            break

        case "52":
            asc = "ê"
            break

        case "53":
            asc = "ë"
            break

        case "54":
            asc = "è"
            break

        case "55":
            asc = "í"
            break

        case "56":
            asc = "î"
            break

        case "57":
            asc = "ï"
            break

        case "58":
            asc = "ì"
            break

        case "59":
            asc = "ß"
            break

        case "5a":
            asc = "!"
            break

        case "5b":
            asc = "$" // cifrao
            break

        case "5c":
            asc = "*" // asterisco
            break

        case "5d":
            asc = ")"
            break

        case "5e":
            asc = ";"
            break

        case "5f":
            asc = "¬"
            break

        case "60":
            asc = "-"
            break

        case "61":
            asc = "/"
            break

        case "62":
            asc = "Â"
            break

        case "63":
            asc = "Ä"
            break

        case "64":
            asc = "À"
            break

        case "65":
            asc = "Á"
            break

        case "66":
            asc = "Ã"
            break

        case "67":
            asc = "Å"
            break

        case "68":
            asc = "Ç"
            break

        case "69":
            asc = "Ñ"
            break

        case "6a":
            asc = "¦"
            break

        case "6b":
            asc = "," // virgula
            break

        case "6c":
            asc = "%"
            break

        case "6d":
            asc = "_"
            break

        case "6e":
            asc = ">"
            break

        case "6f":
            asc = "?"
            break

        case "70":
            asc = "ø"
            break

        case "71":
            asc = "É"
            break

        case "72":
            asc = "Ê"
            break

        case "73":
            asc = "Ë"
            break

        case "74":
            asc = "È"
            break

        case "75":
            asc = "Í"
            break

        case "76":
            asc = "Î"
            break

        case "77":
            asc = "Ï"
            break

        case "78":
            asc = "Ì"
            break

        case "79":
            asc = "`"
            break

        case "7a":
            asc = ":" // dois pontos
            break

        case "7b":
            asc = "#"
            break

        case "7c":
            asc = "@" // arroba
            break

        case "7d":
            asc = "'"
            break

        case "7e":
            asc = "=" // igual
            break

        case "7f":
            asc = "\""
            break

        case "80":
            asc = "Ø"
            break

        case "81":
        case "82":
        case "83":
        case "84":
        case "85":
        case "86":
        case "87":
        case "88":
        case "89":
            asc = value.substring(1) // retirando o "8"
            asc = parseInt(asc, 10)
            asc = arr_8[asc - 1]
            break

        case "8d":
            asc = "ý"
            break

        case "91":
        case "92":
        case "93":
        case "94":
        case "95":
        case "96":
        case "97":
        case "98":
        case "99":
            asc = value.substring(1) // retirando o "8"
            asc = parseInt(asc, 10)
            asc = arr_9[asc - 1]
            break

        case "9c":
            asc = "æ"
            break

        case "9e":
            asc = "Æ"
            break

        case "a1":
        case "a2":
        case "a3":
        case "a4":
        case "a5":
        case "a6":
        case "a7":
        case "a8":
        case "a9":
            asc = value.substring(1) // retirando o "8"
            asc = parseInt(asc, 10)
            asc = arr_A[asc - 1]
            break

        case "0d":
            asc = "CR" // carrigde return
            break

        case "ba":
            asc = "["
            break

        case "bb":
            asc = "]"
            break

        case "c0":
            asc = "{"
            break

        case "c1":
        case "c2":
        case "c3":
        case "c4":
        case "c5":
        case "c6":
        case "c7":
        case "c8":
        case "c9":
            asc = value.substring(1) // retirando o "c"
            asc = parseInt(asc, 10)
            asc = arr_C[asc - 1]
            break

        case "cb":
            asc = "ô"
            break

        case "cc":
            asc = "ö"
            break

        case "cd":
            asc = "ò"
            break

        case "ce":
            asc = "ó"
            break

        case "cf":
            asc = "õ"
            break

        case "d0":
            asc = "}"
            break

        case "d1":
        case "d2":
        case "d3":
        case "d4":
        case "d5":
        case "d6":
        case "d7":
        case "d8":
        case "d9":
            asc = value.substring(1) // retirando o "d"
            asc = parseInt(asc, 10)
            asc = arr_D[asc - 1]
            break

        case "db":
            asc = "û"
            break

        case "dc":
            asc = "ü"
            break

        case "dd":
            asc = "ù"
            break

        case "de":
            asc = "ú"
            break

        case "df":
            asc = "ÿ"
            break

        case "e0":
            asc = "\\"
            break

        case "e1":
        case "e2":
        case "e3":
        case "e4":
        case "e5":
        case "e6":
        case "e7":
        case "e8":
        case "e9":
            asc = value.substring(1) // retirando o "e"
            asc = parseInt(asc, 10)
            asc = arr_E[asc - 1]
            break

        case "eb":
            asc = "Ô"
            break

        case "ec":
            asc = "Ö"
            break

        case "ed":
            asc = "Ò"
            break

        case "ee":
            asc = "Ó"
            break

        case "ef":
            asc = "Õ"
            break

        case "f0":
        case "f1":
        case "f2":
        case "f3":
        case "f4":
        case "f5":
        case "f6":
        case "f7":
        case "f8":
        case "f9":
            asc = value.substring(1) // retirando o "f"
            break

        case "fb":
            asc = "Û"
            break

        case "fc":
            asc = "Ü"
            break

        case "fd":
            asc = "Ù"
            break

        case "fe":
            asc = "Ú"
            break

        case "fe":
            asc = "Ÿ"
            break

        default: // nao encontrou o valor pra coverter, retorna ele mesmo
            asc = value
            break
    }

    return asc
}

function bitmap_hex2bin(bitmap_hexa)
{
    var bitmap_bin = ""
    for (var i = 0, len = bitmap_hexa.length; i < len; i++)
    {
        bitmap_bin += hex2bin(bitmap_hexa.substr(i, 1))
    }

    return bitmap_bin
}
