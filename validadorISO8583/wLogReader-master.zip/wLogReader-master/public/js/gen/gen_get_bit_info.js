// gen_get_bit_info.js

// function get_bit_gen_iso_v0(bit)
// {
    // var info

    // switch (bit)
    // {
    //     default: // DE desconhecido
    //         info = {
    //             ret: false,
    //         }
    //         break
    // }

    // return info
// }
