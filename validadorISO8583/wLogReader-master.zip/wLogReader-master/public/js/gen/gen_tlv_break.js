// gen_tlv_break.js

/*
Propriedades de entrada do info_tlv

formato             [string]    formato da mensagem que sera quebrada
lenTL               [num]       tamanho da tag e length
lenTagDiff          [num]       tamanho da tag
lenLengthDiff       [num]       tamanho do length
lenLengthFormato    [string]    formato do tamanho (Ex.: Visa eh em hexa)
ignoreTagConv       [bool]      true = nao realiza a conversao da tag
ignoreLenConv       [bool]      true = nao realiza a conversao do len da tag
padLen              [bool]      true = utiliza a funcao padLEN para o tamanho
infoFunc            [string]    funcao para pegar mais informacao sobre a tag
nomeCampo           [string]    nome do campo para aparecer no display (ex.: Subelement, Subfield)
subBreak            [bool]      true = esta quebrando um subfield dentro de um subelemento (ex.: subfields 1 e 2 do DE48.42 da Master)
subBreakTag         [string]    nome da tag pai (ex.: 42 - subelemento do DE48 da Master)
*/

/*
Propriedades do tag_info

nome                [string]    nome da tag
breakTLV            [bool]      true = quebrar a tag como TLV
breakFunc           [string]    nome da funcao para quebrar a tag que nao eh TLV (ex.: DE48.42.01 da Master)
descFunc            [string]    nome da funcao para colocar a descricao do valor na mesma linha
desc                [string]    adicionada pela funcao "descFunc"
nao_conv            [bool]      true = nao converte o valor da tag
*/

function genTLVBreak(info_tlv)
{
    while(msg_break_bit.length != 0)
    {
        // tag id
        var tag_id_orig
        if (info_tlv.lenTagDiff)
            tag_id_orig = get_field_break_bit(info_tlv.lenTagDiff)
        else
            tag_id_orig = get_field_break_bit(info_tlv.lenTL * 2)
        var tag_id_conv
        if (!info_tlv.ignoreTagConv)
            tag_id_conv = tag_id_orig.convert(info_tlv.formato)
        else
            tag_id_conv = tag_id_orig
        // console.log("tag_id_orig [%s] tag_id_conv [%s]", tag_id_orig, tag_id_conv)

        // tag len
        var tag_len_orig
        if (info_tlv.lenLengthDiff)
            tag_len_orig = get_field_break_bit(info_tlv.lenLengthDiff)
        else
            tag_len_orig = get_field_break_bit(info_tlv.lenTL * 2)
        var tag_len_conv
        if (!info_tlv.ignoreLenConv)
        {
            if (info_tlv.lenLengthFormato)
            {
                tag_len_conv = tag_len_orig.convert(info_tlv.lenLengthFormato)
            }
            else
                tag_len_conv = tag_len_orig.convert(info_tlv.formato)
        }
        else
            tag_len_conv = tag_len_orig
        var tag_len_int = parseInt(tag_len_conv)
        // console.log("tag_len_orig [%s] tag_len_conv [%s] tag_len_int [%s]", tag_len_orig, tag_len_conv, tag_len_int)

        // tag value
        var tag_value_orig = get_field_break_bit(tag_len_int * 2)
        var tag_value_conv = tag_value_orig.convert(info_tlv.formato)
        // console.log("tag_value_orig [%s] tag_value_conv [%s]", tag_value_orig, tag_value_conv)

        // tag info
        var tag_info
        if (info_tlv.infoFunc)
        {
            if (info_tlv.subBreak && info_tlv.subBreakTag)
            {
                // console.log("if subBreak && subBreakTag")
                tag_info = info_tlv.infoFunc(info_tlv.subBreakTag, tag_id_conv)
            }
            else
            {
                // console.log("else subBreak && subBreakTag - tag_id_conv [%s]", tag_id_conv)
                tag_info = info_tlv.infoFunc(tag_id_conv)
            }
        }
        if (tag_info)
        {
            if (tag_info.nao_conv)
            {
                tag_value_conv = undefined
            }
            if (tag_info.descFunc)
            {
                msg_break_aux = tag_value_orig
                tag_info = tag_info.descFunc(tag_info)
            }
        }
        else
            tag_info = {}

        // dump_obj_console(tag_info)
        //

        var infodisp = {
            display: true,
            qtdeTab: info_tlv.qtdeTab,
            nomeCampo: info_tlv.nomeCampo + " " + tag_id_conv,
            lenV: tag_len_conv,
            padLen: info_tlv.padLen,
            valorOrig: tag_value_orig,
            valorConv: tag_value_conv,
            nome: tag_info.nome,
            desc: tag_info.desc,
            formatMoney: tag_info.formatMoney,
        }
        genDisplayInfo(infodisp)

        //

        if (tag_info.breakTLV || tag_info.breakFunc)
        {
            if (tag_info.breakFunc)
            {
                // console.log("breakFunc [%s]", tag_info.breakFunc)
                msg_break_aux = tag_value_orig
                tag_info.breakFunc()
            }
            else if (tag_info.breakTLV)
            {
                // console.log("quebrar o subelemento [%s]", tag_id_conv)
                var save_msg_break_bit = msg_break_bit
                msg_break_bit = tag_value_orig

                var tlvinfo = {
                    formato: info_tlv.formato,
                    lenTL: info_tlv.lenTL,
                    infoFunc: info_tlv.infoFunc,
                    nomeCampo: "Subfield",
                    qtdeTab: 20,
                    subBreak: true,
                    subBreakTag: tag_id_conv,
                }
                genTLVBreak(tlvinfo)

                msg_break_bit = save_msg_break_bit
            }
        }
        // console.log("")
    }
}

// ================================================================================================

/*
Objeto de retorno

campos          - array com os subelementos identificados
X               - propriedade com o conteudo do subelemento. Por exemplo, para  subelemento 1, X = 1
    len         - propriedade de X com o tamanho do subelemento
    ebc         - propriedade de X com o conteudo do subelemnto em ebcedic
    conv        - propriedade de X com o conteudo convertido
    more        - propriedade de X com mais informacoes
        nome    - propriedade de more com o nome do subelemento
*/

function gen_tlv_break(tipo, bit, len_default, subelemento_param)
{
    // console.log("gen_tlv_break - tipo [%s] bit [%s] len_default [%s] subelemento_param [%s]", tipo, bit, len_default, subelemento_param)
    var tlv_info = {}
    tlv_info.campos = []

    while(msg_break_bit.length != 0)
    {
        // identificacao
        var sub_id_ebc = get_field_break_bit(len_default * 2)
        var sub_id_conv = conv_ebc2a(sub_id_ebc)
        tlv_info.campos.push(sub_id_conv)
        // console.log("sub id ebc [%s] sub id conv [%s]", sub_id_ebc, sub_id_conv)

        var obj = {}

        // tamanho
        var len_ebc = get_field_break_bit(len_default * 2)
        var len_conv = conv_ebc2a(len_ebc)
        var len = parseInt(len_conv)
        obj["len"] = len_conv
        // console.log("len ebc [%s] len conv [%s] len [%s]", len_ebc, len_conv, len)

        // conteudo
        var valor_ebc = get_field_break_bit(len * 2)
        var valor_conv = conv_ebc2a(valor_ebc)
        obj["ebc"] = valor_ebc
        obj["conv"] = valor_conv
        // console.log("valor ebc [%s] valor conv [%s]", valor_ebc, valor_conv)

        // info do subelemento
        var subelemento_info
        switch(tipo)
        {
            case kBNDR_MASTER:
                if (subelemento_param)
                    subelemento_info = info_tlv_mastercard(bit, subelemento_param, sub_id_conv)
                else
                    subelemento_info = info_tlv_mastercard(bit, sub_id_conv)
                break

            case kDRV_WEB_EC:
                if (subelemento_param)
                    subelemento_info = break_bit48_web_info(subelemento_param, sub_id_conv)
                else
                    subelemento_info = break_bit48_web_info(sub_id_conv)
                break
        }
        // dump_obj_console(subelemento_info)

        if (subelemento_info)
        {
            if (subelemento_info.nao_conv)
            {
                delete obj.conv
            }
            obj["more"] = subelemento_info
        }

        tlv_info[sub_id_conv] = obj
    }

    return tlv_info
}

function gen_tlv_display_subelement(sub_id, sub_info)
{
    // console.log("gen_tlv_display_subelement - sub_id [%s] sub_info [%s]", sub_id, JSON.stringify(sub_info, null, 4))
    return gen_tlv_display(undefined, "Subelement", sub_id, sub_info)
}

function gen_tlv_display_subfield(sub_id, sub_info)
{
    // console.log("gen_tlv_display_subfield - sub_id [%s] sub_info [%s]", sub_id, JSON.stringify(sub_info, null, 4))
    return gen_tlv_display(22, "Subfield", sub_id, sub_info)
}

function gen_tlv_display(qtde_tab, tipo, sub_id, sub_info)
{
    var display = ""

    display = get_html_spaces(qtde_tab)
    display += tipo + " " + sub_id + " - " + "V" + sub_info.len + " - " + sub_info.ebc

    if (sub_info)
    {
        // se existir a propriedade, nao realizar a conversao
        if (!sub_info.more || (sub_info.more && !sub_info.more.nao_conv))
        {
            display += " [" + converterEspacoParaHtml(sub_info.conv) + "]"
        }

        if (sub_info.inline)
        {
            display += " = " + sub_info.inline
        }

        if (sub_info.more && sub_info.more.nome)
        {
            display += " (" + sub_info.more.nome + ")"
        }

        if (sub_info.newline)
        {
            display += get_break_line()
            display += sub_info.newline
        }
        else
        {
            display += get_break_line()
        }
    }

    return display
}
