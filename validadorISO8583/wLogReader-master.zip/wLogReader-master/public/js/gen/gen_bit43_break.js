// gen_bit43_break.js

function gen_bit43_break_hexa()
{
    gen_bit43_break(kFMT_HEXA)
}

function gen_bit43_break_ebc()
{
    gen_bit43_break(kFMT_EBC)
}

function gen_bit43_break(tipo)
{
    var space = 37

    var len
    var valor

    // nome do estabelecimento
    len = 22
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Nome do Estabelecimento (1-22)" + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        tipoConv: tipo,
    }
    genDisplayInfo(infodisp)

    // separador - espaco
    len = 1
    get_field_break_bit(len * 2)

    // cidade
    len = 13
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "Cidade (23-35)" + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        tipoConv: tipo,
    }
    genDisplayInfo(infodisp)

    // separador - espaco
    len = 1
    get_field_break_bit(len * 2)

    // pais
    len = 3
    valor = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "País (37-40)" + mostrarParentese(len),
        nomeCampoSpace: space,
        valorOrig: valor,
        tipoConv: tipo,
    }
    genDisplayInfo(infodisp)
}
