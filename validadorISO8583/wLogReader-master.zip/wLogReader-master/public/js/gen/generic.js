// generic.js

function validMsgType(msgtype)
{
    var ret = -1 // valor default - msgtype invalido

    switch (msgtype)
    {
        case "0100": // pre-autorizacao
        case "0200": // venda
        case "0202": // confirmacao
        case "0220": // advice
        case "0400": // estorno
        case "0420": // desfazimento
        case "0500": // adm
        case "0600": // pooling
        case "0800": // adm
        case "1624": // rav
            // msgtype request
            ret = 0
            break

        case "0110": // pre-autorizacao
        case "0210": // venda
        case "0212": // confirmacao
        case "0230": // advice
        case "0410": // estorno
        case "0430": // desfazimento
        case "0510": // adm
        case "0610": // pooling
        case "0810": // adm
        case "1634": // rav
            // msgtype response
            ret = 1
            break
    }

    return ret
}

function getField(msg, len)
{
    // retira da mensagem uma string do tamanho que foi passado como paramentro, atualizada a mensagem e retorna um objeto com esses dois parametros

    // pegando o valor com o tamanho esperado
    var valor = msg.substr(0, len)

    // atualizando a mensagem sem o valor
    msg = msg.substring(len)

    // criando um objeto pra retornar o valor recuperado e a mensagem atualizada
    var ret = {
        valor: valor,
        msg: msg,
    }

    return ret
}

function get_field_msg(len)
{
    // retira da mensagem uma string do tamanho que foi passado como paramentro, atualiza a mensagem e retorna o campo desejado

    // pegando o valor com o tamanho esperado
    var valor = msg.substr(0, len)

    // atualizando a mensagem sem o valor
    msg = msg.substring(len)

    return valor
}

function get_field_break_bit(len)
{
    // se o tamanho nao foi passado, retornar a string inteira
    if (len == undefined)
    {
        len = msg_break_bit.length
    }

    // retira da mensagem uma string do tamanho que foi passado como paramentro, atualiza a mensagem e retorna o campo desejado

    // pegando o valor com o tamanho esperado
    var valor = msg_break_bit.substr(0, len)

    // atualizando a mensagem sem o valor
    msg_break_bit = msg_break_bit.substring(len)

    return valor
}

function get_field_break_aux(len)
{
    // se o tamanho nao foi passado, retornar a string inteira
    if (!len)
    {
        len = msg_break_aux.length
    }

    // pegando o valor com o tamanho esperado
    var valor = msg_break_aux.substr(0, len)

    // atualizando a mensagem sem o valor
    msg_break_aux = msg_break_aux.substring(len)

    return valor
}

String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g,"");
}

String.prototype.ltrim = function() {
    return this.replace(/^\s+/,"");
}

String.prototype.rtrim = function() {
    return this.replace(/\s+$/,"");
}

String.prototype.convert = function(formato) {
    // console.log("convert - formato [%s] value [%s]", formato, this)
    if (formato == kFMT_EBC)
    {
        return conv_ebc2a(this)
    }
    else if (formato == kFMT_HEXA)
    {
        return hex2a(this)
    }
    else if (formato == kFMT_HEXA_BASE16)
    {
        return parseInt(this, 16).toString()
    }
    else
    {
        return this
    }
}

function removerEspaco(valor)
{
    return valor.toString().replace(/\s/g, "")
}

function converterEspacoParaHtml(valor)
{
    return valor.toString().replace(/\s/g, "&nbsp;")
}

function mostrarColchete(valor)
{
    return " [" + converterEspacoParaHtml(valor) + "]"
}

function mostrarParentese(valor)
{
    return " (" + converterEspacoParaHtml(valor) + ")"
}

function bitmap2formatted(bitmap_bin, is_issuer)
{
    var len = 64

    if (bitmap_bin.substr(0, 1) == "1") // verificando se o segundo bitmap esta ligado
    {
        len = 128
    }

    var bitmap_formatted = ""
    for (var i = 0; i < len; i++)
    {
        var bit_bin = bitmap_bin.substr(i, 1) // flag pra ver se o DE esta ligado

        if (bit_bin == 1) // bit presente
        {
            if (i > 0 && is_issuer == undefined) // ignorar o bit 1 do bitmap
            {
                // bitmap_formatted += " " + (i + 1) + " "
                bitmap_formatted += (i + 1) + " "
            }
            else if (is_issuer)
            {
                bitmap_formatted += (i + 1) + " "
            }
        }
    }

    bitmap_formatted = bitmap_formatted.trim()

    return bitmap_formatted
}

function fill_break_line()
{
    msg_formatted += "<br>"
}

function get_break_line()
{
    return "<br>"
}

function fill_html_spaces(qtde)
{
    // filler pra formatar em baixo do valor - 16 espacos
    if (!qtde)
    {
        qtde = 16
    }

    msg_formatted += get_html_spaces(qtde)
}

function fill_html_spaces_sub()
{
    msg_formatted += get_html_spaces(36)
}

function fill_html_spaces2(qtde)
{
    var html_space = "&nbsp;"

    for (var i = 1; i <= qtde; i++)
    {
        msg_formatted += html_space
    }
}

function get_html_spaces(qtde)
{
    var html_space = "&nbsp;"
    var label = ""

    if (!qtde)
    {
        qtde = 16
    }

    for (var i = 1; i <= qtde; i++)
    {
        label += html_space
    }

    return label
}

function dump_obj(obj)
{
    alert(JSON.stringify(obj, null, 4))
}

function dump_obj_console(obj)
{
    console.log(JSON.stringify(obj, null, 4))
}

function padDE(bit)
{
    return pad(bit, 3)
}

function padSubfield(subfield)
{
    return pad(subfield, 2)
}

function padLEN(value)
{
    // return pad(value, 3)
    return pad(parseInt(value), 3)
}

function padTAG(bit)
{
    return pad(bit, 2)
}

function pad(value, zeros)
{
    var padzeros = "1"

    for (var i = 1; i <= zeros; i++)
    {
        padzeros = padzeros + "0"
    }

    padzeros = parseInt(padzeros, 10) // convertendo pra numero pra conseguir somar

    return (padzeros + value).toString().substring(1,4)
}

// ==============================================================

function padTAGBIT55(value)
{
    if (value.length == 2)
    {
        return pad2("&nbsp;", 2, "left", value)
    }

    return value
}

function padCENTAVO(value)
{
    if (value.length != 2)
    {
        return pad2(0, 1, "left", value)
    }

    return value
}

function pad2(filler, len, LR, value)
{
    // filler   - com o que sera formatado (ex.: espacos, zeros)
    // len      - tamanho do filler
    // LR       - em qual posicao ficara o filler (Left/Right)
    // value    - valor que sera formatado com o filler

    var ret = ""

    for (var i = 1; i <= len; i++)
    {
        ret += filler
    }

    if (LR == "left")
    {
        ret = ret + value
    }
    else if (LR == "right")
    {
        ret = value + ret
    }

    return ret
}

function padEXT(value, len)
{
    // return pad3(" ", 20, "right", value, false).replace(/\s/g, "&nbsp;")
    return pad3("&nbsp;", len, "right", value, false)
}

function pad3(filler, len, LR, value, ignore_val_len)
{
    // filler           - com o que sera formatado (ex.: espacos, zeros)
    // len              - tamanho do filler
    // LR               - em qual posicao ficara o filler (Left/Right)
    // value            - valor que sera formatado com o filler
    // ignore_val_len   - indica se o filler precisa levar em consideracao o tamanho do value

    var value_len = value.length
    if (!ignore_val_len)
    {
        if (value_len >= len)
        {
            return value
        }
        else
        {
            len = len - value_len
        }
    }

    var ret = ""

    for (var i = 1; i <= len; i++)
    {
        ret += filler
    }

    if (LR == "left")
    {
        ret = ret + value
    }
    else if (LR == "right")
    {
        ret = value + ret
    }

    return ret
}

function dump_log(valor)
{
    console.log(valor)
}

function conv_hex2bin(value)
{
    var bin = ""
    for (var i = 0, len = value.length; i < len; i++)
    {
        bin += hex2bin(value.substr(i, 1))
    }

    return bin
}

function mergeObject(obj1, obj2)
{
    var obj3 = {}

    for (var attrname in obj1)
        obj3[attrname] = obj1[attrname]

    for (var attrname in obj2)
        obj3[attrname] = obj2[attrname]

    return obj3
}

function genDisplayInfo(info) // renomear para genDisplayInfoDetalhe
{
    /*
    Propriedades

    display                 [bool]      true = concatena resultado na msg_formatted | false/undefined = retorna o valor
    displayClean            [bool]      true = concatena resultado orig na msg_clean
    qtdeTab                 [num]       quantidade de tabs para a linha
    qtdeTabL1               [bool]      true = level 1: coloca 16 tabs
    nomeCampo               [string]    nome para o campo (Ex.: Subelemento, TAG)
    nomeCampoSpace          [string]    quantidade de espaco para mostrar o nome
    nomeCampoIgnoreDash     [bool]      true = nao colocar o traco apos o nome do campo
    valorFirst              [string]    valor antes do Orig e Conv
    valorOrig               [string]    valor original do campo
    valorOrigColchete       [bool]      mostra colchete no valorOrig
    valorConv               [string]    valor do campo convertido
    formatMoney             [bool]      formatar o valor com a moeda
    formatPct               [bool]      formatar o valor com a porcentagem
    // format_YYMMDD_DDMMYY [bool]      formata a data no formato DDMMYY
    formatDateIn            [string]    formato da data de entrada
    formatDateOut           [string]    formato da data de saida
    lenDecimal              [num]       tamanho de digitos da casa decimal
    desc                    [string]    descricao do campo
    descFunc                [string]    nome da funcao para pegar a descricao, usado o valor do campo valorConv. A funcao deve retornar uma string
    nome                    [string]    nome do campo
    lenV                    [int]       mostra o tamanho junto com a literal de variavel "V"
    lenF                    [int]       mostra o tamanho junto com a literal de fixo "F"
    lenFixo                 [bool]      mostra o tamanho com o texto "Fixo"
    padLen                  [bool]      true = utiliza a funcao padLEN para o tamanho
    convEbc                 [bool]      converte o valor original de ebcdic
    convHexa                [bool]      converte o valor original de hexa
    tipoConv                [string]    tipo da conversao (kFMT_HEXA ou kFMT_EBC)
    tipoConvSecond          [string]    tipo da segunda conversao (kFMT_HEXA ou kFMT_EBC)			
    ignoreBreakLine         [bool]      true = nao coloca o "br" no final | false/undefined = coloca o "br" no final
    newline                 [string]    valor para colocar apos a quebra de linha (como se fosse quebrando o conteudo da linha de cima)
    */

    /*
    Exemplo do objeto recebido

    infodisp = {
        display: true,
        qtdeTabL1: true,
        nomeCampo: "nome",
        nomeCampoSpace: space,
        valorOrig: tag_value_orig,
        valorConv: tag_value_conv,
        nome: tag_info.nome,
    }
    */

    // se nao receber o objeto ou o valor, nao faz nada
    if (!info)
        return

    //

    var display = ""

    //

    if (info.qtdeTabL1)
    {
        display += get_html_spaces(16)
    }
    else if (info.qtdeTab)
    {
        display += get_html_spaces(info.qtdeTab)
    }

    //

    if (info.nomeCampo)
    {
        if (info.nomeCampoSpace)
        {
            display += padEXT(info.nomeCampo, info.nomeCampoSpace)
        }
        else
        {
            display += info.nomeCampo
        }

        if (!info.nomeCampoIgnoreDash)
        {
            display += " - "
        }
    }

    if (info.lenV)
    {
        if (info.padLen)
        {
            display += "V" + padLEN(info.lenV) + " - "
        }
        else
        {
            display += "V" + info.lenV + " - "
        }
    }
    else if (info.lenF)
    {
        if (info.padLen)
        {
            display += "F" + padLEN(info.lenF) + " - "
        }
        else
        {
            display += "F" + info.lenF + " - "
        }
    }
    else if (info.lenFixo)
    {
        display += "Fixo" + " - "
    }

    //

    if (info.valorFirst)
    {
        display += info.valorFirst
    }

    if (info.valorOrig && info.valorConv)
    {
        display += info.valorOrig + mostrarColchete(info.valorConv)
    }
    else if (info.valorOrig)
    {
        if (info.valorOrigColchete)
        {
            display += mostrarColchete(info.valorOrig)
        }
        else
        {
            display += info.valorOrig
        }
    }
    else if (info.valorConv)
    {
        display += info.valorConv
    }

    if (info.valorOrig && !info.valorConv)
    {
        info.valorConv = info.valorOrig
    }

    //

    if (info.convEbc || info.tipoConv == kFMT_EBC)
    {
        // display += mostrarColchete(conv_ebc2a(info.valorOrig))
        info.valorConv = conv_ebc2a(info.valorOrig)
        display += mostrarColchete(info.valorConv)
    }
    else if (info.convHexa || info.tipoConv == kFMT_HEXA)
    {
        // display += mostrarColchete(hex2a(info.valorOrig))
        info.valorConv = hex2a(info.valorOrig)
        display += mostrarColchete(info.valorConv)
    }
    else if (info.tipoConv == kFMT_HEXA_BASE16)
    {
        info.valorConv = hex16b2a(info.valorOrig)
        display += mostrarColchete(info.valorConv)
    }

    if (info.tipoConvSecond)
    {
        if (info.tipoConvSecond == kFMT_EBC)
        {
            display += mostrarColchete(conv_ebc2a(info.valorConv))
        }
        else if (info.tipoConvSecond == kFMT_HEXA)
        {
            display += mostrarColchete(hex2a(info.valorConv))
        }
        else if (info.tipoConvSecond == kFMT_HEXA_BASE16)
        {
            display += mostrarColchete(hex16b2a(info.valorConv))
        }
    }

    //

    if (info.formatMoney) // formatar money
    {
        if (info.valorConv.trim().length > 0)
        {
            display += mostrarColchete(formatMoney(info.valorConv))
        }
    }
    else if (info.formatPct) // formatar porcentagem
    {
        if (info.valorConv.trim().length > 0)
        {
            display += mostrarColchete(format_pct(info.valorConv, info.lenDecimal))
        }
    }
    else if (info.formatDateIn && info.formatDateOut)
    {
        if (info.valorConv.trim().length > 0 && parseInt(info.valorConv) > 0)
        {
            display += mostrarColchete(formatDate(info.valorConv, info.formatDateIn, info.formatDateOut))
        }
    }
    // else if (info.format_YYMMDD_DDMMYY)
    // {
    //     if (info.valorConv.trim().length > 0)
    //     {
    //         console.log("genDisplayInfo - info.valorConv [%s]", info.valorConv)
    //         display += mostrarColchete(formatDate(info.valorConv.toString(), kDATA_YYMMDD, kDATA_DDMMYY))
    //     }
    // }

    //

    if (info.desc)
    {
        display += " = " + info.desc
    }
    else if (info.descFunc)
    {
        if (info.valorConv)
        {
            var aux = info.descFunc(info.valorConv)
            if (aux)
            {
                display += " = " + aux
            }
        }
    }

    //

    if (info.nome)
    {
        display += mostrarParentese(info.nome)
    }

    //

    if (!info.ignoreBreakLine)
    {
        display += get_break_line()
    }

    //

    if (info.newline)
    {
        display += info.newline
    }

    //

    if (info.displayClean)
    {
        if (info.valorOrig)
        {
            msg_clean += info.valorOrig + get_break_line()
        }
    }

    //

    if (info.display)
    {
        msg_formatted += display
    }
    else
    {
        return display
    }
}
