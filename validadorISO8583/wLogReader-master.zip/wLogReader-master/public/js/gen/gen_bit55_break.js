// gen_bit55_break.js

function genBreakBit55Puro(qtdeTab)
{
    genBreakBit55(undefined, qtdeTab)
}

function genBreakBit55Ascii(qtdeTab)
{
    // genBreakBit55("ascii")
    genBreakBit55(kFMT_HEXA, qtdeTab)
}

function genBreakBit55Ebc(qtdeTab)
{
    // genBreakBit55("ebc")
    genBreakBit55(kFMT_EBC, qtdeTab)
}

function genBreakBit55(formato55, qtdeTabParam)
{
    var len
    var aux
    var qtdeTab = 16

    if (qtdeTabParam)
    {
        qtdeTab = qtdeTabParam
    }

    while(msg_break_bit.length != 0)
    {
        // tag
        len = 2
        if (formato55 == kFMT_HEXA || formato55 == kFMT_EBC)
            len += 2
        var tag_id = get_field_break_bit(len).toUpperCase()

        if (formato55 == kFMT_HEXA)
            tag_id = hex2a(tag_id)
        else if (formato55 == kFMT_EBC)
            tag_id = conv_ebc2a(tag_id)
        var tag_id_bin = conv_hex2bin(tag_id)

        // verificar se a tag tem mais dois bytes
        // tem mais 2 bytes se o resultado em binario for XXX11111 (o ultimo bit for 1 e se outros 4 bits forem 1)
        if (tag_id_bin.substring(3, tag_id_bin.length) == "11111")
        {
            // pegar os outros dois bytes da tag
            aux = get_field_break_bit(len).toUpperCase()

            if (formato55 == kFMT_HEXA)
                aux = hex2a(aux)
            else if (formato55 == kFMT_EBC)
                aux = conv_ebc2a(aux)

            tag_id += aux
        }

        var tag_info = get_info_bit55(tag_id)

        // len
        var tag_len_hexa = get_field_break_bit(len)
        if (formato55 == kFMT_HEXA)
            tag_len_hexa = hex2a(tag_len_hexa)
        else if (formato55 == kFMT_EBC)
            tag_len_hexa = conv_ebc2a(tag_len_hexa)
        var tag_len = parseInt(tag_len_hexa, 16)

        // value
        // var tag_value = get_field_break_bit(tag_len * 2)
        var tag_value
        if (formato55 == kFMT_HEXA)
        {
            tag_value = get_field_break_bit(tag_len * 4)
            aux = hex2a(tag_value)
        }
        else if (formato55 == kFMT_EBC)
        {
            tag_value = get_field_break_bit(tag_len * 4)
            aux = conv_ebc2a(tag_value)
        }
        else
            tag_value = get_field_break_bit(tag_len * 2)

        //

        var infodisp = {
            display:true,
            qtdeTab: qtdeTab,
            nomeCampo: "TAG " + padTAGBIT55(tag_id),
            lenV: padLEN(tag_len),
            valorOrig: tag_value,
            tipoConv: formato55,
            nome: tag_info.nome
        }

        if (tag_info.hex2a)
        {
            infodisp.tipoConvSecond = kFMT_HEXA_BASE16
        }

        genDisplayInfo(infodisp)
    }

    return 0
}
