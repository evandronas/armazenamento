// gen_bit55_tag.js

function get_info_bit55(tag)
{
    /*
    Propriedades do objeto de retorno

    nome                [string]    nome da tag
    hex2a               [bool]      indica se devera converter de hexa
    */

    var info = {}

    tag = tag.toUpperCase() // forcar a string pra upper

    switch (tag) {

        case "5F34":
            info = {
                nome: "Application PAN Sequence Number",
            }
            break

        case "5F2A":
            info = {
                nome: "Transaction Currency Code",
            }
            break

        case "9F02":
            info = {
                nome: "Amount, Authorized",
            }
            break

        case "9F03":
            info = {
                nome: "Amount, Other",
            }
            break

        case "9F06":
            info = {
                nome: "Application Identifier (AID)",
            }
            break

        case "9F09":
            info = {
                nome: "Terminal Application Version Number",
            }
            break

        case "9F10":
            info = {
                nome: "Issuer Application Data",
            }
            break

        case "9F1A":
            info = {
                nome: "Terminal Country Code",
            }
            break

        case "9F26":
            info = {
                nome: "Application Cryptogram",
            }
            break

        case "9F27":
            info = {
                nome: "Cryptogram Information Data",
            }
            break

        case "9F33":
            info = {
                nome: "Terminal Capabilities",
            }
            break

        case "9F34":
            info = {
                nome: "Cardholder Verification Method (CVM) Results",
            }
            break

        case "9F35":
            info = {
                nome: "Terminal Type",
            }
            break

        case "9F36":
            info = {
                nome: "Application Transaction Counter",
                hex2a: true,
            }
            break

        case "9F37":
            info = {
                nome: "Unpredictable Number",
            }
            break

        case "9F6E":
            info = {
                nome: "Form Factor",
            }
            break

        case "50":
            info = {
                nome: "Application Label",
            }
            break

        case "71":
            info = {
                nome: "Issuer Script Before 2nd GAC",
            }
            break

        case "72":
            info = {
                nome: "Issuer Script After 2nd GAC",
            }
            break

        case "82":
            info = {
                nome: "Application Interchange Profile",
            }
            break

        case "84":
            info = {
                nome: "Application Identifier (AID)",
            }
            break

        case "91":
            info = {
                nome: "Issuer Authentication Data",
            }
            break

        case "95":
            info = {
                nome: "Terminal Verification Results",
            }
            break

        case "9A":
            info = {
                nome: "Transaction Date",
            }
            break

        case "9C":
            info = {
                nome: "Transaction Type",
            }
            break
    }

    return info
}
