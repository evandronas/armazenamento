// gen_get_desc.js

function get_desc_transcode(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 1:
            desc = "Débito À Vista - Magnético/Chip"
            break

        case 2:
            desc = "Débito À Vista - Digitado"
            break

        case 3:
            desc = "Crédito À Vista - Magnético/Chip"
            break

        case 4:
            desc = "Crédito À Vista - Digitado"
            break

        case 5:
            desc = "Crédito Parcelado Com Juros (IATA ou não) - Magnético/Chip"
            break

        case 6:
            desc = "Crédito Parcelado Com Juros (IATA ou não) - Digitado"
            break

        case 7:
            desc = "Crédito Parcelado Sem Juros - Magnético/Chip"
            break

        case 8:
            desc = "Crédito Parcelado Sem Juros - Digitado"
            break

        case 20:
            desc = "Simulação Crediário"
            break

        case 21:
            desc = "Contratação Crediário"
            break

        case 39:
            desc = "IATA À Vista"
            break

        case 40:
            desc = "IATA Parcelado Sem Juros"
            break

        case 41:
            desc = "Estorno"
            break

        case 43:
            desc = "Desfazimento"
            break

        case 57:
            desc = "Débito Pré-Datado"
            break

        case 67:
            desc = "Voucher"
            break

        case 68:
            desc = "Confirmação de Pré-Autorização - Magnético/Chip"
            break

        case 69:
            desc = "Confirmação de Pré-Autorização - Digitado"
            break

        case 70:
            desc = "Estorno de Pré-Autorização"
            break

        case 71:
            desc = "Desfazimento de Pré-Autorização"
            break

        case 72:
            desc = "Solicitação de Pré-Autorização - Magnético/Chip"
            break

        case 73:
            desc = "Solicitação de Pré-Autorização - Digitado"
            break

        case 74:
            desc = "Venda Private Label"
            break

        case 75:
            desc = "Consulta Private Label"
            break

        case 77:
            desc = "Estorno de Confirmação de Pré-Autorização"
            break

        case 78:
            desc = "Desfazimento de Confirmação de de Pré-Autorização"
            break

        case 79:
            desc = "Venda Off-Line Crédito/Débito"
            break

        case 80:
            desc = "Confirmação de Pré-Autorização Parcelado Sem Juros - Magnético/Chip"
            break

        case 81:
            desc = "Confirmação de Pré-Autorização Parcelado Sem Juros - Digitado"
            break

        case 98:
            desc = "Zero Dollar"
            break

        case 105:
            desc = "Solicitação de Pré-Autorização Parcelado Sem Juros - Magnético/Chip"
            break

        case 106:
            desc = "Solicitação de Pré-Autorização Parcelado Sem Juros - Digitado"
            break

        case 108:
            desc = "Transação ITI"
            break

        case 109:
            desc = "Estorno ITI Negado"
            break

        case 110:
            desc = "Solicitação QR Code/Pooling QR Code"
            break

        case 111:
            desc = "Solicitação Estorno QR Code/Pooling Estorno QR Code"
            break

        case 112:
            desc = "Solicitação PIX/Pooling PIX"
            break

        case 113:
            desc = "Solicitação Cancelamento PIX/Pooling Cancelamento PIX"
            break

        // default:
        // 	desc = kMSG_ERRO_VALOR_NAO_MAPEADO
        // 	break
    }

    return desc
}

function get_desc_status(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 1:
            desc = "Confirmada"
            break

        case 2:
            desc = "Negada"
            break

        case 3:
            desc = "Desfeita"
            break

        case 4:
            desc = "Estornada"
            break

        default:
            // desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}

function get_desc_entry_mode(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 11:
            desc = "Digitado"
            break

        case 21:
            desc = "Magnético"
            break

        case 51:
        case 52:
        case 59:
            desc = "Chip"
            break

        case 71:
            desc = "Contacless Chip"
            break

        case 791:
            desc = "Fallback Digitado"
            break

        case 801:
            desc = "Fallback Magnético"
            break

        case 810:
            desc = "E-Commerce"
            break

        case 911:
            desc = "Contacless Magnético"
            break

        default:
            // desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}

function get_desc_codigo_emissor(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 0:
            desc = "Sem emissor"
            break

        case 2:
            desc = "Mastercard Crédito"
            break

        case 6:
            desc = "Diners"
            break

        case 6:
        case 8:
            desc = "Diners Internacional"
            break

        case 18:
            desc = "Mastercard Débito"
            break

        case 19:
            desc = "PL Fininvest"
            break

        case 24:
            desc = "Voucher"
            break

        case 45:
            desc = "PL Bradesco"
            break

        case 47:
            desc = "Hipercard/Hiper Crédito"
            break

        case 48:
            desc = "Visa Crédito"
            break

        case 49:
            desc = "Visa Débito"
            break

        case 50:
            desc = "Cabal Débito"
            break

        case 51:
            desc = "Cabal Crédito"
            break

        case 53:
            desc = "Sorocred Van"
            break

        case 55:
            desc = "PL Porto Seguro"
            break

        case 61:
            desc = "Sorocred Crédito"
            break

        case 62:
            desc = "Coopercard Crédito"
            break

        case 63:
            desc = "UPI Crédito"
            break

        case 64:
            desc = "Sicredi Crédito"
            break

        case 65:
            desc = "Sicredi Débito"
            break

        case 66:
            desc = "Calcard Crédito"
            break

        case 67:
            desc = "Avista Crédito"
            break

        case 68:
            desc = "Credsystem Crédito"
            break

        case 84:
            desc = "Hiper Débito"
            break

        case 86:
            desc = "Amex Crédito Van"
            break

        case 87:
            desc = "Elo Crédito Van"
            break

        case 88:
            desc = "Elo Débito Van"
            break

        case 89:
            desc = "Nova Bandeira Crédito"
            break

        case 90:
            desc = "Nova Bandeira Débito"
            break

        case 91:
            desc = "Banescard Crédito"
            break

        case 92:
            desc = "Banescard Débito"
            break

        case 93:
            desc = "JCB Crédito"
            break

        case 94:
            desc = "CredZ Crédito"
            break

        case 95:
            desc = "Amex Crédito"
            break

        case 96:
            desc = "Elo Crédito"
            break

        case 97:
            desc = "Elo Débito"
            break

        case 98:
            desc = "Avancard Crédito"
            break

        case 99:
            desc = "Avancard Débito"
            break

        case 102:
            desc = "Bigcard Crédito"
            break

        case 103:
            desc = "Bigcard Débito"
            break

        case 104:
            desc = "Bonuscred Crédito"
            break

        case 105:
            desc = "CDC Card Crédito"
            break

        case 106:
            desc = "CDC Card Débito"
            break

        case 107:
            desc = "Comprocard Crédito"
            break

        case 110:
            desc = "Convenios Card Crédito"
            break

        case 111:
            desc = "Diamante Card Crédito"
            break

        case 112:
            desc = "Eucard Crédito"
            break

        case 113:
            desc = "Eucard Débito"
            break

        case 114:
            desc = "Fortbrasil Crédito"
            break

        case 115:
            desc = "Fortcard Crédito"
            break

        case 116:
            desc = "Goias Card Crédito"
            break

        case 117:
            desc = "Goodcard Crédito"
            break

        case 118:
            desc = "Card Ideal Crédito"
            break

        case 119:
            desc = "Card Ideal Débito"
            break

        case 120:
            desc = "Credpar"
            break

        case 121:
            desc = "Libercard Crédito"
            break

        case 122:
            desc = "Libercard Débito"
            break

        case 123:
            desc = "Maxxcard Crédito"
            break

        case 124:
            desc = "Maxxcard Débito"
            break

        case 125:
            desc = "Megavale Card Crédito"
            break

        case 126:
            desc = "Megavale Card Débito"
            break

        case 127:
            desc = "Meu Vale Crédito"
            break

        case 128:
            desc = "Meu Vale Débito"
            break

        case 131:
            desc = "Onecard Crédito"
            break

        case 132:
            desc = "Personal Card Crédito"
            break

        case 133:
            desc = "Personal Card Débito"
            break

        case 134:
            desc = "Romcard Crédito"
            break

        case 135:
            desc = "Romcard Débito"
            break

        case 138:
            desc = "Senff Crédito"
            break

        case 139:
            desc = "Sincard Crédito"
            break

        case 140:
            desc = "Sincard Débito"
            break

        case 141:
            desc = "Sind Crédito"
            break

        case 142:
            desc = "Smccard Crédito"
            break

        case 145:
            desc = "System Farma Crédito"
            break

        case 146:
            desc = "Ter Cred Crédito"
            break

        case 147:
            desc = "Vegas Card Crédito"
            break

        case 148:
            desc = "Veran Crédito"
            break

        case 149:
            desc = "Veran Débito"
            break

        case 150:
            desc = "Verdecard Crédito"
            break

        case 151:
            desc = "Verdecard Débito"
            break

        case 152:
            desc = "Volus Crédito"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}

function get_desc_codigo_bandeira(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 0:
            desc = "Outros"
            break

        case 1:
            desc = "Mastercard Crédito"
            break

        case 2:
            desc = "Diners"
            break

        case 3:
            desc = "Débito"
            break

        case 4:
            desc = "Redeshop Crédito"
            break

        case 5:
            desc = "Visa Crédito"
            break

        case 17:
            desc = "Mastercard Débito"
            break

        case 18:
            desc = "Avancard Crédito"
            break

        case 19:
            desc = "Voucher"
            break

        case 20:
            desc = "Construcard"
            break

        case 21:
            desc = "Private Label"
            break

        case 22:
            desc = "Volus Crédito"
            break

        case 25:
            desc = "Bigcard Crédito"
            break

        case 26:
            desc = "Card Ideal Crédito"
            break

        case 27:
            desc = "CDC Card Crédito"
            break

        case 29:
            desc = "Eucard Crédito"
            break

        case 30:
            desc = "Libercard Crédito"
            break

        case 31:
            desc = "Maxxcard Crédito"
            break

        case 32:
            desc = "Megavale Card Crédito"
            break

        case 33:
            desc = "Meu Vale Crédito"
            break

        case 35:
            desc = "Personal Card Crédito"
            break

        case 36:
            desc = "Romcard Crédito"
            break

        case 38:
            desc = "Sincard Crédito"
            break

        case 40:
            desc = "Veran Crédito"
            break

        case 41:
            desc = "Verdecard Crédito"
            break

        case 42:
            desc = "Avancard Débito"
            break

        case 44:
            desc = "Bigcard Débito"
            break

        case 45:
            desc = "Card Ideal Débito"
            break

        case 46:
            desc = "CDC Card Débito"
            break

        case 48:
            desc = "Eucard Débito"
            break

        case 49:
            desc = "Libercard Débito"
            break

        case 50:
            desc = "Cabal Débito"
            break

        case 51:
            desc = "Cabal Crédito"
            break

        case 52:
            desc = "Maxxcard Débito"
            break

        case 53:
            desc = "Megavale Débito"
            break

        case 55:
            desc = "Visa Débito"
            break

        case 56:
            desc = "Meu Vale Débito"
            break

        case 58:
            desc = "Hiper Débito"
            break

        case 59:
            desc = "Personal Card Débito"
            break

        case 60:
            desc = "Hipercard/Hiper Crédito"
            break

        case 61:
            desc = "Sorocred Crédito"
            break

        case 62:
            desc = "Coopercard Crédito"
            break

        case 63:
            desc = "UPI Crédito"
            break

        case 64:
            desc = "Sicredi Crédito"
            break

        case 65:
            desc = "Sicredi Débito"
            break

        case 66:
            desc = "Romcard Débito"
            break

        case 67:
            desc = "Avista Crédito"
            break

        case 68:
            desc = "Credsystem Crédito"
            break

        case 69:
            desc = "Amex Crédito"
            break

        case 70:
            desc = "Elo Crédito"
            break

        case 71:
            desc = "Elo Débito"
            break

        case 72:
            desc = "Nova Bandeira Crédito"
            break

        case 73:
            desc = "Nova Bandeira Débito"
            break

        case 74:
            desc = "Banescard Crédito"
            break

        case 75:
            desc = "Banescard Débito"
            break

        case 76:
            desc = "JCB Crédito"
            break

        case 77:
            desc = "CredZ Crédito"
            break

        case 80:
            desc = "Sincard Débito"
            break

        case 82:
            desc = "Veran Débito"
            break

        case 83:
            desc = "Verdecard Débito"
            break

        case 84:
            desc = "Bonuscred Crédito"
            break

        case 85:
            desc = "Comprocard Crédito"
            break

        case 86:
            desc = "Convenios Card Crédito"
            break

        case 87:
            desc = "Credpar Crédito"
            break

        case 88:
            desc = "Diamante Card Crédito"
            break

        case 89:
            desc = "Fortbrasil Crédito"
            break

        case 90:
            desc = "Fortcard Crédito"
            break

        case 91:
            desc = "Goias Card Crédito"
            break

        case 92:
            desc = "Goodcard Crédito"
            break

        case 93:
            desc = "Onecard Crédito"
            break

        case 94:
            desc = "Senff Crédito"
            break

        case 95:
            desc = "Sind Crédito"
            break

        case 96:
            desc = "Smccard Crédito"
            break

        case 97:
            desc = "System Farma Crédito"
            break

        case 98:
            desc = "Ter Cred Crédito"
            break

        case 99:
            desc = "Vegas Card Crédito"
            break

        // default:
        //     desc = kMSG_ERRO_VALOR_NAO_MAPEADO
        //     break
    }

    return desc
}

function get_desc_ind_crypto(valor)
{
    var pin
    var dados
    var refereal
    var desc

    switch (valor)
    {
        case "S3":
            pin = "3DES"
            dados = "3DES"
            refereal = "3DES"
            break

        case "S4":
            pin = "DUKPT 3DES"
            dados = "3DES"
            refereal = "3DES"
            break

        case "S5":
            pin = "DUKPT 3DES"
            dados = "DES"
            refereal = "DUKPT"
            break

        case "S6":
            pin = "DUKPT 3DES"
            dados = "3DES"
            refereal = "DUKPT"
            break

        case "S7":
            pin = "DES"
            dados = "DES"
            refereal = "DES"
            break

        case "S8":
            pin = "3DES"
            dados = "DES"
            refereal = "3DES"
            break

        case "S9":
            pin = "DUKPT 3DES"
            dados = "DUKPT 3DES"
            refereal = "DUKPT 3DES"
            break

        case "SB":
            pin = "DUKPT 3DES"
            dados = "Sem criptografia"
            refereal = "Sem criptografia"
            break

        case "SC":
            pin = "N/A"
            dados = "DUKPT AES"
            refereal = "N/A"
            break

        case "N0":
        case "0N":
            desc = "Sem Criptografia"
            break
    }

    if (pin && dados && refereal)
    {
        desc = "Senha: " + pin + " / " + "Dados: " + dados + " / " + "Refereal: " + refereal
        return desc
    }
    else if (desc)
    {
        return desc
    }
}

function get_desc_codigo_empresa_adquirente(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 0:
            desc = "Rede"
            break

        case 20:
            desc = "Cielo"
            break

        case 21:
            desc = "GetNet"
            break
    }

    return desc
}

function get_desc_codigo_servico(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 230:
            desc = "Corban"
            break

        case 240:
            desc = "Zolkin"
            break

        case 500:
            desc = "Recarga"
            break
    }

    return desc
}

function get_desc_hostname(valor)
{
    var desc
    valor = valor.trim()

    switch(valor)
    {
        case "sxxxp2100cto":
            desc = "436 7.1"
            break

        case "sxxxp2104cto":
            desc = "436 7.5"
            break

        case "sxxxp1100ctm":
            desc = "437 7.1"
            break

        case "sxxxp1104ctm":
            desc = "437 7.5"
            break

        case "sxxxp2101cto":
            desc = "438 7.1"
            break

        case "sxxxp2105cto":
            desc = "438 7.5"
            break

        case "sxxxp1101ctm":
            desc = "439 7.1"
            break

        case "sxxxp1105ctm":
            desc = "439 7.5"
            break

        case "sxxxp2102cto":
            desc = "440 7.1"
            break

        case "sxxxp2106cto":
            desc = "440 7.5"
            break

        case "sxxxp1102ctm":
            desc = "441 7.1"
            break

        case "sxxxp1106ctm":
            desc = "441 7.5"
            break

        case "sxxxp2103cto":
            desc = "442 7.1"
            break

        case "sxxxp2107cto":
            desc = "442 7.5"
            break

        case "sxxxp1103ctm":
            desc = "443 7.1"
            break

        case "sxxxp1107ctm":
            desc = "443 7.5"
            break
    }

    return desc
}

function get_desc_capture_source_web(valor)
{
    var desc
    valor = valor.trim()

    switch (valor)
    {
        case "01":
            desc = "E-Rede Adquirência"
            break

        case "02":
            desc = "RedePay"
            break

        case "03":
            desc = "Datacash"
            break

        case "04":
        case "05":
            desc = "MasterPass"
            break

        case "06":
            desc = "VisaCheckout"
            break

        case "07":
            desc = "Link Pagamento"
            break

        case "08":
            desc = "Parceiro"
            break

        case "99":
            desc = "Outros"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}
