// gen_break_tag.js

function genBreakCvm(tipo)
{
    // recebe o conteudo pela msg_break_aux

    var qtde_tab

    var info
    var len
    var valor_orig
    var valor_conv
    var desc

    if (tipo == kDEF_POS)
    {
        qtde_tab = 32
    }
    else if (tipo == kDEF_PDV)
    {
        qtde_tab = 33
    }

    //

    // Codigo referente ao CVM result enviado pelo terminal
    // n1
    len = 2
    valor_orig = get_field_break_aux(len)
    valor_conv = valor_orig
    if (tipo == kDEF_PDV)
        valor_conv = conv_ebc2a(valor_conv)
    valor_conv = parseInt(valor_conv)
    desc = genBreakCvm_CodigoTerminal(valor_conv)
    info = {
        display: true,
        qtdeTab: qtde_tab,
        valorOrig: valor_orig,
        desc: desc,
    }
    if (tipo == kDEF_PDV)
        info.valorConv = valor_conv
    genDisplayInfo(info)

    // Posicao 1 - n2
    len = 2
    if (tipo == kDEF_PDV) len = 4
    valor_orig = get_field_break_aux(len)
    valor_conv = valor_orig
    if (tipo == kDEF_PDV)
        valor_conv = conv_ebc2a(valor_conv)
    desc = genBreakCvm_Posicao1(valor_conv)
    info = {
        display: true,
        qtdeTab: qtde_tab,
        valorOrig: valor_orig,
        desc: desc,
    }
    if (tipo == kDEF_PDV)
        info.valorConv = valor_conv
    genDisplayInfo(info)

    // Posicao 2 - n2
    len = 2
    if (tipo == kDEF_PDV) len = 4
    valor_orig = get_field_break_aux(len)
    valor_conv = valor_orig
    if (tipo == kDEF_PDV)
        valor_conv = conv_ebc2a(valor_conv)
    desc = genBreakCvm_Posicao2(valor_conv)
    info = {
        display: true,
        qtdeTab: qtde_tab,
        valorOrig: valor_orig,
        desc: desc,
    }
    if (tipo == kDEF_PDV)
        info.valorConv = valor_conv
    genDisplayInfo(info)
}

function genBreakCvm_CodigoTerminal(valor)
{
    var desc

    switch(valor)
    {
        case 1:
            desc = "Senha (Online ou Offline)"
            break

        case 2:
            desc = "Assinatura"
            break

        case 3:
            desc = "Senha (Online ou Offline) + Assinatura"
            break

        case 4:
            desc = "No CVM"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}

function genBreakCvm_Posicao1(valor)
{
    var desc

    switch(valor)
    {
        // case "":
        // 	desc = ""
        //     break

        // case "":
        // 	desc = ""
        //     break

        // case "":
        //     desc = ""
        //     break

        // case "":
        //     desc = ""
        //     break

        // case "":
        //     desc = ""
        //     break

        // case "":
        //     desc = ""
        //     break

        // case "":
        //     desc = ""
        //     break

        // case "":
        //     desc = ""
        //     break

        case "00":
        case "40":
            desc = "Fail CVM processing"
            break

        case "01":
        case "41":
            desc = "Plaintext PIN verification performed by ICC"
            break

        case "02":
        case "42":
            desc = "Enciphered PIN verification online"
            break

        case "03":
        case "43":
            desc = "Plaintext PIN verification performed by ICC and signature (paper)"
            break

        case "04":
        case "44":
            desc = "Enciphered PIN verification performed by ICC"
            break

        case "05":
        case "45":
            desc = "Enciphered PIN verification performed by ICC and signature (paper)"
            break

        case "1E":
        case "5E":
            desc = "Signature (paper)"
            break

        case "1F":
        case "5F":
            desc = "No CVM required"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}

function genBreakCvm_Posicao2(valor)
{
    var desc

    switch(valor)
    {
        case "00":
            desc = "Always"
            break

        case "01":
            desc = "If unattended cash"
            break

        case "02":
            desc = "If not unattended cash and not manual cash and not purchase with cashback"
            break

        case "03":
            desc = "If terminal supports the CVM"
            break

        case "04":
            desc = "If manual cash"
            break

        case "05":
            desc = "If purchase with cashback"
            break

        case "06":
            desc = "If transaction is in the application currency for a discussion of “X” and is under X value"
            break

        case "07":
            desc = "If transaction is in the application currency and is over X value"
            break

        case "08":
            desc = "If transaction is in the application currency and is under Y value"
            break

        case "09":
            desc = "If transaction is in the application currency and is over Y value"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}

function genBreakKsn(tipo)
{
    var qtde_tab

    var info
    var valor_orig

    if (tipo == kDEF_POS)
    {
        qtde_tab = 32
    }
    else if (tipo == kDEF_PDV)
    {
        msg_break_aux = conv_ebc2a(msg_break_aux)
        qtde_tab = 33
    }

    // ignorar os "F" do comeco
    get_field_break_aux(5)

    var valor_orig = get_field_break_aux(5)

    info = {
        display: true,
        qtdeTab: qtde_tab,
        nomeCampo: "ID Chave",
        valorOrig: valor_orig,
        tipoConv: kFMT_HEXA_BASE16,
    }
    genDisplayInfo(info)
}
