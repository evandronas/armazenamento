// gen_bit90_break.js

function gen_bit90_break_hexa(param)
{
    gen_bit90_break(kFMT_HEXA, param)
}

function gen_bit90_break_ebc(param)
{
    gen_bit90_break(kFMT_EBC, param)
}

function gen_bit90_break(tipo, param)
{
    var pos = 0

    var info = {
        tipo: tipo,
        qtdeTab: 16,
        space: 35,
    }

    for (var i = 0; i < param.length; i++)
    {
        switch(param[i])
        {
            case "mti":
                pos = gen_bit90_break_mti(info, pos)
                break

            case "stan":
                pos = gen_bit90_break_stan(info, pos)
                break

            case "data":
                pos = gen_bit90_break_data(info, pos)
                break

            case "hora":
                pos = gen_bit90_break_hora(info, pos)
                break

            case "codaut":
                pos = gen_bit90_break_codaut(info, pos)
                break

            case "res22":
                gen_bit90_break_res22(info)
                break

            case "filler":
                pos = gen_bit90_break_filler(info, pos)
                break
        }
    }
}

function gen_bit90_break_mti(info, pos)
{
    // message type
    len = 4
    name = "Message Type"
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: info.qtdeTab,
        // nomeCampo: name + mostrarParentese("1-4") + mostrarParentese(len),
        nomeCampo: name + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: info.space,
        valorOrig: value,
        tipoConv: info.tipo,
    }
    genDisplayInfo(infodisp)
    pos += len

    return pos
}

function gen_bit90_break_stan(info, pos)
{
    // stan (BIT 11)
    len = 6
    name = "Stan Terminal"
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: info.qtdeTab,
        // nomeCampo: name + mostrarParentese("5-10") + mostrarParentese(len),
        nomeCampo: name + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: info.space,
        valorOrig: value,
        tipoConv: info.tipo,
    }
    genDisplayInfo(infodisp)
    pos += len

    return pos
}

function gen_bit90_break_data(info, pos)
{
    // data (BIT 13)
    len = 4
    name = "Data"
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: info.qtdeTab,
        // nomeCampo: name + mostrarParentese("17-20") + mostrarParentese(len),
        nomeCampo: name + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: info.space,
        valorOrig: value,
        tipoConv: info.tipo,
    }
    genDisplayInfo(infodisp)
    pos += len

    return pos
}

function gen_bit90_break_hora(info, pos)
{
    // hora (BIT 12)
    len = 6
    name = "Hora"
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: info.qtdeTab,
        // nomeCampo: name + mostrarParentese("11-16") + mostrarParentese(len),
        nomeCampo: name + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: info.space,
        valorOrig: value,
        tipoConv: info.tipo,
    }
    genDisplayInfo(infodisp)
    pos += len

    return pos
}

function gen_bit90_break_codaut(info, pos)
{
    // codigo de autorizacao (BIT 38)
    len = 6
    name = "Código de Autorização"
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: info.qtdeTab,
        nomeCampo: name + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: info.space,
        valorOrig: value,
        tipoConv: info.tipo,
    }
    genDisplayInfo(infodisp)
    pos += len

    return pos
}

function gen_bit90_break_res22(info)
{
    // reservado
    len = 22
    name = "Reservado"
    value = get_field_break_bit(len * 2)
    infodisp = {
        display: true,
        qtdeTab: info.qtdeTab,
        nomeCampo: name,
        nomeCampoSpace: info.space,
        valorOrig: value,
        tipoConv: info.tipo,
    }
    genDisplayInfo(infodisp)
}

function gen_bit90_break_filler(info, pos)
{
    // filler
    name = "Reservado"
    value = get_field_break_bit()
    len = value.length / 2
    infodisp = {
        display: true,
        qtdeTab: info.qtdeTab,
        nomeCampo: name + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
        nomeCampoSpace: info.space,
        valorOrig: value,
        tipoConv: info.tipo,
    }
    genDisplayInfo(infodisp)
    pos += len

    return pos
}

function gen_bit90_break2(obj)
{
    /*
    Detalhes do objeto -> obj

    exemplo:
    obj = {
        formato: kFMT_EBC,
        campos: [
            {
                nome: kDE90_MSGTYPE,
                len: 4,
            },
            {
                ...
            },
        ],
        qtdeTab: 16,
        space: 35,
    }

    formato         string          formato da mensagem (HEXA, EBCDIC)
    campos          [object]        informacoes de cada campo dentro do DE
        nome        string          nome do campo
        len         num             tamanho do campo
    space           num             quantidade de espaco apos o nome do campo
    */

    var nome
    var len
    var value
    var pos = 0
    var infodisp

    if (obj.campos)
    {
        for (var i = 0; i < obj.campos.length; i++)
        {
            info_campo = obj.campos[i]
            // dump_obj_console(info_campo)

            nome = info_campo.nome
            len = info_campo.len
            value = get_field_break_bit(len * 2)
            infodisp = {
                display: true,
                qtdeTabL1: true,
                nomeCampoSpace: obj.space,
                nomeCampo: nome + mostrarParentese((pos + 1) + "-" + (pos + len)) + mostrarParentese(len),
                valorOrig: value,
                tipoConv: obj.formato,
            }
            genDisplayInfo(infodisp)
            pos += len
        }

        if (msg_break_bit.length > 0)
        {
            alert('Ainda há campos no DE90 da mensagem.')
        }
    }
}
