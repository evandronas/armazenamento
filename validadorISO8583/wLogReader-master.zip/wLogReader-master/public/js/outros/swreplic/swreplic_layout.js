// swreplic_layout.js

/*
Propriedades

nome                    [string]    nome do campo
len                     [num]       tamanho do campo
descFunc                [string]    nome da funcao para pegar a descricao. A funcao deve retornar uma string
disabled                [bool]      true = campo esta desativado
formatMoney             [bool]      formatar o valor com a moeda
*/

function swreplic_layout()
{
    var info = {
        array_fields: [
            { nome: "Data", len: 8 },
            { nome: "Hora", len: 6 },
            { nome: "NSU", len: 10 },
            { nome: "Valor", len: 13, formatMoney: true },
            { nome: "Entry Mode", len: 2, descFunc: swreplic_desc_entry_mode },
            { nome: "Status", len: 1, descFunc: swreplic_desc_status },
            { nome: "Código Bandeira", len: 2, descFunc: get_desc_codigo_bandeira },
            { nome: "Código Produto", len: 2, descFunc: swreplic_desc_codigo_produto },
            { nome: "Tipo Transação", len: 2, descFunc: swreplic_desc_tipo_transacao },
            { nome: "Tipo Venda", len: 1, descFunc: swreplic_desc_tipo_venda },
            { nome: "Tipo Código Emissor", len: 1, descFunc: swreplic_desc_tipo_codigo_emissor },
            { nome: "Código Emissor (ICA/Member ID)", len: 11, descFunc: swreplic_desc_codigo_emissor },
            { nome: "Tipo Rede", len: 2, descFunc: swreplic_desc_tipo_rede },
            { nome: "Código Terminal", len: 8 },
            { nome: "Estabelecimento", len: 9 },
            { nome: "cod_grup_ram_atvd", len: 1, disabled: true },
            { nome: "Ramo Atividade", len: 5 },
            { nome: "CEP", len: 8 },
            { nome: "Estado", len: 2 },
            { nome: "Número Cartão", len: 19 },
            { nome: "Código Sub Produto", len: 2, descFunc: swreplic_desc_codigo_subproduto },
            { nome: "Código Transação GE", len: 3, descFunc: swreplic_desc_cod_tran_ge },
            { nome: "Código Sub Produto Private Label", len: 3 },
            { nome: "Tipo Origem Transação WEB", len: 2, descFunc: get_desc_capture_source_web },
            { nome: "Código Empresa Adquirente", len: 3, descFunc: get_desc_codigo_empresa_adquirente },
            { nome: "Código Serviço", len: 3, descFunc: get_desc_codigo_servico },
            { nome: "Front-End Acquirer", len: 5 },
            { nome: "Hostname", len: 16, descFunc: get_desc_hostname },
            { nome: "Transcode", len: 3, descFunc: get_desc_transcode },
            { nome: "Código Motivo Rede Externa", len: 3 },
            { nome: "Identificação Token", len: 1 },
            { nome: "Quantidade Parcelas", len: 2 },
            { nome: "MCC SubMerchant", len: 4 },
            { nome: "Versão Aplicação Terminal", len: 16 },
            { nome: "Código Motivo SW", len: 3 },
            { nome: "Net Code", len: 5 },
            { nome: "Código SubModalidade", len: 2 },
            { nome: "Código Tecnologia", len: 4 },
            { nome: "Indicação QR Code", len: 1 },
            { nome: "Código Parceiro", len: 5 },
            { nome: "IMEI", len: 16 },
            { nome: "SIMCard ID (ICCID)", len: 22 },
            { nome: "Nome da operadora", len: 10 },
            { nome: "MAC address", len: 12 },
            { nome: "Endereço IP", len: 32 },
            { nome: "Informações antena (CGI)", len: 30 },
            { nome: "Versão plataforma (CA + plataforma)", len: 20 },
            { nome: "PAN Hash", len: 32 },
            { nome: "CVV Hash", len: 32 },
            { nome: "Acceptor Name", len: 40 },
            { nome: "Nome Portador Hash", len: 40 },
            { nome: "Numero do Pedido Hash", len: 32 },
            { nome: "Tipo de Criptografia", len: 2 },
            { nome: "Porta Origem", len: 5 },
            { nome: "Tempo de Resposta", len: 5 },
            { nome: "Codigo Transação Cadastro", len: 5 },
            { nome: "Codigo Moeda Portador", len: 3 },
            { nome: "Valor Transação Moeda Portador", len: 13 },
        ],
        opcionais: 16, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
