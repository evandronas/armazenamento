// swreplic_break.js

function swreplic_break()
{
    var info = swreplic_layout()
    var qtde = info.array_fields.length
    var op = info.opcionais

    var infodisp
    var valor
    var pos = 1

    // mostrar tamanho total da mensagem antes
    infodisp = {
        display: true,
        nomeCampo: "Tamanho da mensagem: " + msg.length,
        nomeCampoIgnoreDash: true,
        newline: get_break_line(),
    }
    genDisplayInfo(infodisp)

    for (var i = 0; i < info.array_fields.length; i++)
    {
        var field = info.array_fields[i]
        var num = i + 1

        if (op && qtde <= op && msg.length == 0)
        {
            // campo opcional e nao esta presente
        }
        else
        {
            if (field.disabled)
            {
                qtde -= 1
                continue
            }

            valor = get_field_msg(field.len)

            var desc = undefined
            if (field.descFunc)
            {
                desc = field.descFunc(valor)
            }

            //

            infodisp = {
                display: true,
                displayClean: true,
                nomeCampoSpace: 45,
                nomeCampo: swreplic_nome_campo(field.nome, num),
                valorFirst: padLEN(field.len) + " - " + padLEN(pos) + " - ",
                valorOrig: valor,
                valorOrigColchete: true,
                desc: desc,
                formatMoney: field.formatMoney,
            }
            genDisplayInfo(infodisp)
        }

        pos += field.len
        qtde -= 1
    }
}

function swreplic_nome_campo(nome, num)
{
    return mostrarParentese(pad(num, 2)) + " " + nome
}
