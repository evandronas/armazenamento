// swreplic_desc.js

function swreplic_desc_entry_mode(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 1:
            desc = "Digitada"
            break

        case 2:
            desc = "Magnética"
            break

        case 5:
            desc = "Chip"
            break

        case 7:
            desc = "NFC Chip"
            break

        case 8:
            desc = "Carteira Digital (transações ITI/QR Code)"
            break

        case 17:
            desc = "ITI"
            break

        case 78:
            desc = "Chip Off-Line"
            break

        // case 80:
        //     desc = "Fallback Chip"
        //     break

        case 81:
            desc = "E-Commerce"
            break

        case 86:
            desc = "Fallback Chip"
            break

        case 91:
            desc = "NFC Magnético"
            break
    }

    return desc
}

function swreplic_desc_status(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 1:
            desc = "Aprovada"
            break

        case 2:
            desc = "Negada Redecard (Acquirer)"
            break

        case 3:
            desc = "Negada Emissor (Issuer)"
            break

        case 4:
            desc = "Desfeita Emissor (Time-out Issuer)"
            break

        case 5:
            desc = "Desfeita Redecard (Time-out Acquirer)"
            break

        case 6:
            desc = "Desfeita Cliente (Tecla cancela)"
            break

        case 7:
            desc = "Pooling (Consulta de Status ITI)"
            break
    }

    return desc
}

function swreplic_desc_codigo_bandeira(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {   
        case 1:
            desc = "Outros"
            break

        case 98:
            desc = "ITI"
            break

        case 99:
            desc = "Operacional"
            break
    }

    return desc
}

function swreplic_desc_codigo_produto(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {   
        case 1:
            desc = "Crédito"
            break

        case 2:
            desc = "Débito"
            break

        case 3:
            desc = "Voucher"
            break

        case 4:
            desc = "Private Label"
            break

        case 5:
            desc = "Serasa"
            break

        case 6:
            desc = "CDC"
            break

        case 7:
            desc = "Construcard"
            break

        case 8:
            desc = "Pagamento de Contas"
            break

        case 9:
            desc = "Outros"
            break

        case 10:
            desc = "Foneshop"
            break

        case 12:
            desc = "Trishop"
            break

        case 14:
            desc = "Parcele Mais"
            break

        case 15:
            desc = "Crediário"
            break

        case 16:
            desc = "Saque"
            break

        case 17:
            desc = "ITI"
            break

        case 18:
            desc = "QR Code"
            break

        case 19:
            desc = "PIX"
            break
    }

    return desc
}

function swreplic_desc_tipo_transacao(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {   
        case 1:
            desc = "Venda"
            break

        case 2:
            desc = "Desfazimento"
            break

        case 3:
            desc = "Estorno"
            break

        case 4:
            desc = "Consulta"
            break

        case 5:
            desc = "Administrativa"
            break

        case 6:
            desc = "Confirmação de Pré-Autorização"
            break

        case 7:
            desc = "Consulta de Pré-Autorização"
            break

        case 9:
            desc = "Outros"
            break

        case 10:
            desc = "Finalização de Auto-Inicialização"
            break

        case 11:
            desc = "Finalização de Auto-Carga"
            break

        case 12:
            desc = "Desfazimento Dual"
            break

        case 13:
            desc = "Estorno Dual"
            break

        case 14:
            desc = "PIX"
            break
    }

    return desc
}

function swreplic_desc_tipo_venda(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 0:
            desc = "Parcele Mais"
            break

        case 1:
            desc = "À Vista"
            break

        case 2:
            desc = "Parcelado Emissor"
            break

        case 3:
            desc = "Parcelado Estabelecimento"
            break

        case 4:
            desc = "Pré-Datada"
            break

        case 5:
            desc = "Cash"
            break

        case 6:
            desc = "À Vista em Dóllar"
            break

        case 7:
            desc = "IATA"
            break

        case 8:
            desc = "Referida"
            break

        case 9:
            desc = "Solicitação Foneshop"
            break
    }

    return desc
}

function swreplic_desc_tipo_codigo_emissor(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 1:
            desc = "ICA"
            break

        case 2:
            desc = "Bacen"
            break

        case 3:
            desc = "Issuer Code"
            break

        case 9:
            desc = "Outros"
            break
    }

    return desc
}

function swreplic_desc_tipo_rede(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 1:
            desc = "POS"
            break

        case 2:
            desc = "PDV"
            break

        case 3:
            desc = "POO"
            break

        case 4:
            desc = "Komerci"
            break

        case 5:
            desc = "TOF"
            break

        case 7:
            desc = "By-Phone"
            break

        case 8:
            desc = "POS Wireless"
            break

        case 11:
            desc = "MPOS"
            break

        case 12:
            desc = "POE"
            break

        case 13:
            desc = "PWI"
            break

        case 14:
            desc = "POY"
            break

        case 15:
            desc = "ATM (Tecban)"
            break

        case 99:
            desc = "Outros"
            break
    }

    return desc
}

function swreplic_desc_codigo_subproduto(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 12:
            desc = "Ben Alimentação"
            break

        case 13:
            desc = "Ben Refeição"
            break
    }

    return desc
}

function swreplic_desc_cod_tran_ge(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 18:
            desc = "Ticket Alimentação"
            break

        case 27:
            desc = "Ticket Refeição"
            break

        case 51:
            desc = "Cabal Alimentação"
            break

        case 52:
            desc = "Cabal Refeição"
            break

        case 53:
            desc = "Cabal Combustível"
            break

        case 54:
            desc = "Cabal Farmácia"
            break

        case 55:
            desc = "Cabal Premiação"
            break

        case 128:
            desc = "Alelo Refeição"
            break

        case 129:
            desc = "Alelo Alimentação"
            break

        case 137:
            desc = "Mastercard Refeição"
            break

        case 138:
            desc = "Mastercard Alimentação"
            break

        case 139:
            desc = "Abrapetite"
            break

        case 140:
            desc = "Bamex Benefícios"
            break

        case 141:
            desc = "Biq Benefícios"
            break

        case 142:
            desc = "Bonuscred"
            break

        case 143:
            desc = "Convenios Card"
            break

        case 144:
            desc = "Credalimentação"
            break

        case 145:
            desc = "Eucard"
            break

        case 146:
            desc = "Facecard"
            break

        case 147:
            desc = "Flex"
            break

        case 148:
            desc = "Goodcard"
            break

        case 149:
            desc = "Lecard"
            break

        case 150:
            desc = "Libercard"
            break

        case 151:
            desc = "Maxxcard"
            break

        case 152:
            desc = "Nutricard"
            break

        case 153:
            desc = "Ok Cartões"
            break

        case 154:
            desc = "Onecard"
            break

        case 155:
            desc = "Sindplus"
            break

        case 156:
            desc = "Uauh Benefícios"
            break

        case 158:
            desc = "Vale Shop"
            break

        case 159:
            desc = "Vegas Card"
            break

        case 160:
            desc = "Viasoft Pay"
            break

        case 161:
            desc = "Volus"
            break

        case 162:
            desc = "Vscard"
            break

        case 163:
            desc = "Ben Alimentação"
            break

        case 164:
            desc = "Ben Refeição"
            break
    }

    return desc
}

function swreplic_desc_codigo_emissor(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch(valor)
    {
        case 48:
            desc = "TICKET"
            break

        case 58:
            desc = "SODEXHO"
            break

        case 70:
            desc = "CABAL"
            break

        case 78:
            desc = "ALELO"
            break

        case 80:
            desc = "SFORZA"
            break
    }

    return desc
}
