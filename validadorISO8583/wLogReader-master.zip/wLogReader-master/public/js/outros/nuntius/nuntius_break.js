// nuntius_break.js

function nuntius_break(tipo)
{
    var info = nuntius_layout()

    var infodisp
    var valor
    var pos = 1

    for (var i = 0; i < info.array_fields.length; i++)
    {
        var field = info.array_fields[i]

        valor = get_field_msg(field.len)

        var desc = undefined
        if (field.descFunc)
        {
            desc = field.descFunc(valor)
        }

        infodisp = {
            display: true,
            displayClean: true,
            nomeCampoSpace: 30,
            nomeCampo: field.nome,
            valorFirst: padLEN(field.len) + " - " + padLEN(pos) + " - ",
            valorOrig: valor,
            valorOrigColchete: true,
            desc: desc,
            formatMoney: field.formatMoney,
        }
        genDisplayInfo(infodisp)

        pos += field.len
    }
}
