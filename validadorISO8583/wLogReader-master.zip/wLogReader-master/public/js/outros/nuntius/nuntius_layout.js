// nuntius_layout.js

/*
Propriedades

nome                    [string]    nome do campo
len                     [num]       tamanho do campo
descFunc                [string]    nome da funcao para pegar a descricao. A funcao deve retornar uma string
formatMoney             [bool]      formatar o valor com a moeda
*/

function nuntius_layout()
{
    var info = {
        array_fields: [
        { nome: "Estabelecimento", len: 9 },
        { nome: "Data", len: 8 },
        { nome: "Hora", len: 6 },
        { nome: "Tipo Venda", len: 1, descFunc: nuntius_desc_tipo },
        { nome: "Codigo Transacao", len: 5},
        { nome: "Quantidade Parcelas", len: 3 },
        { nome: "Código Bandeira", len: 3, descFunc: get_desc_codigo_bandeira },
        { nome: "NSU", len: 12 },
        { nome: "NSU Original", len: 12 },
        { nome: "Código Autorização", len: 9 },
        { nome: "Dados Adicionais Emissor", len: 21},
        { nome: "Valor", len: 15, formatMoney: true },
        { nome: "Código Tecnologia", len: 4 },
        { nome: "Código Terminal", len: 8 },
        { nome: "Status", len: 1, descFunc: get_desc_status },
        { nome: "Entry Mode", len: 3, descFunc: get_desc_entry_mode },
        { nome: "Nome Portador", len: 40 },
        { nome: "Bin", len: 6 },
        { nome: "Sufixo", len: 4 },
        { nome: "Tipo Transação", len: 5, descFunc: get_desc_transcode },
        ],
        opcionais: 0, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
