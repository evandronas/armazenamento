// nuntius_desc.js

function nuntius_desc_tipo(valor)
{
    var desc

    switch(valor)
    {
        case "A":
            desc = "Administrativa"
            break

        case "C":
            desc = "Crédito"
            break

        case "D":
            desc = "Débito"
            break

        case "P":
            desc = "Private Label"
            break

        case "V":
            desc = "Voucher"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}
