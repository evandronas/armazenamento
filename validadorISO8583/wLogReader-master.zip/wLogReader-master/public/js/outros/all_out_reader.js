// all_out_reader.js

function all_out_reader()
{
    var valor = kHTML_CBOX_DRIVER.value

    switch(valor)
    {
        case kOUT_FEINTERF_CR:
        case kOUT_FEINTERF_DB:
        case kOUT_FEINTERF_B:
            feinterf_break(valor)
            break

        case kOUT_SWREPLIC:
            swreplic_break()
            break

        case kOUT_NUNTIUS:
            nuntius_break()
            break

        default:
            alert("A opção [" + valor + "] não foi mapeada.")
            return
    }

    all_out_display_result()
}
