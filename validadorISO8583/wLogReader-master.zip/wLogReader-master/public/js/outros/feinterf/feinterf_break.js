// feinterf_break.js

function feinterf_break(tipo)
{
    var info
    if (tipo == kOUT_FEINTERF_B)
        info = feinterf_b_layout()
    else
        info = feinterf_layout()

    var qtde = info.array_fields.length
    var op = info.opcionais

    var infodisp
    var valor
    var pos = 1

    // mostrar tamanho total da mensagem antes
    infodisp = {
        display: true,
        nomeCampo: "Tamanho da mensagem: " + msg.length,
        nomeCampoIgnoreDash: true,
        newline: get_break_line(),
    }
    genDisplayInfo(infodisp)

    for (var i = 0; i < info.array_fields.length; i++)
    {
        var field = info.array_fields[i]

        if (op && qtde <= op && msg.length == 0)
        {
            // campo opcional e nao esta presente
        }
        else
        {
            if (field.disabled)
            {
                qtde -= 1
                continue
            }
            else if ((field.isOnlyCredit && tipo != kOUT_FEINTERF_CR) || (field.isOnlyDebit && tipo != kOUT_FEINTERF_DB))
            {
                qtde -= 1
                continue
            }

            valor = get_field_msg(field.len)

            var desc = undefined
            if (field.descFunc)
            {
                desc = field.descFunc(valor)
            }

            //

            infodisp = {
                display: true,
                displayClean: true,
                nomeCampoSpace: 50,
                nomeCampo: field.nome,
                valorFirst: padLEN(field.len) + " - " + padLEN(pos) + " - ",
                valorOrig: valor,
                valorOrigColchete: true,
                desc: desc,
                formatMoney: field.formatMoney,
            }
            genDisplayInfo(infodisp)
        }

        pos += field.len
        qtde -= 1
    }

    if (msg.length > 0)
    {
        var msg_erro = ""
        msg_erro += "Ainda há campos no registro." + "\n\n"
        msg_erro += "registro [" + msg + "]" + "\n"
        msg_erro += "len [" + msg.length + "]" + "\n"

        alert(msg_erro)
        return
    }
}
