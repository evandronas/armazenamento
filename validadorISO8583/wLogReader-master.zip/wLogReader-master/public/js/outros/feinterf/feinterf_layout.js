// feinterf_layout.js

/*
Propriedades

nome                    [string]    nome do campo
len                     [num]       tamanho do campo
descFunc                [string]    nome da funcao para pegar a descricao. A funcao deve retornar uma string
disabled                [bool]      true = campo esta desativado
formatMoney             [bool]      formatar o valor com a moeda
isOnlyCredit            [bool]      true = campo existe apenas no layout de credito
isOnlyDebit             [bool]      true = campo existe apenas no layout de debito
*/

function feinterf_layout()
{
    var info = {
        array_fields: [
            { nome: "Tipo", len: 1, descFunc: feinterf_desc_tipo },
            { nome: "NSU", len: 12 },
            { nome: "Estabelecimento", len: 9 },
            { nome: "Data", len: 8 },
            { nome: "Hora", len: 6 },
            { nome: "Código Emissor", len: 2, descFunc: get_desc_codigo_emissor },
            { nome: "Status", len: 1, descFunc: feinterf_desc_status },
            { nome: "Número Cartão", len: 19 },
            { nome: "Data Validade", len: 6 },
            { nome: "Entry Mode", len: 3, descFunc: get_desc_entry_mode },
            { nome: "Descrição Entry Mode", len: 20 },
            { nome: "Valor", len: 13, formatMoney: true },
            { nome: "Quantidade Parcelas", len: 3 },
            { nome: "Valor Parcela", len: 10, formatMoney: true },
            { nome: "Código Tecnologia", len: 4 },
            { nome: "Código País Cartão", len: 3 },
            { nome: "Transcode", len: 2, descFunc: get_desc_transcode },
            { nome: "Descrição Transcode", len: 50 },
            { nome: "Motivo ISO (PB Reason Code)", len: 3 },
            { nome: "Descrição Motivo ISO", len: 50 },
            { nome: "Respcode Bandeira", len: 3 },
            { nome: "Identificação Emissor (ICA/Member ID)", len: 11 },
            { nome: "Bacen", len: 4 },
            { nome: "Franquia", len: 6 },
            { nome: "Código Terminal", len: 8 },
            { nome: "Stan", len: 6 },
            { nome: "Subtranscode", len: 2, isOnlyDebit: true },
            { nome: "Cashback", len: 13, isOnlyDebit: true },
            { nome: "Número Checkout", len: 8 },
            { nome: "Número de Serie", len: 32 },
            { nome: "Número Telefone Chamador", len: 16 },
            { nome: "Identificador Coleta CVC2", len: 1 },
            { nome: "Versão Software", len: 5 },
            { nome: "Score", len: 4, isOnlyCredit: true },
            { nome: "Código Serviço", len: 3 },
            { nome: "PV Físico", len: 9 },
            { nome: "DDD Celular", len: 4 },
            { nome: "Número Celular", len: 9 },
            { nome: "Número Pedido", len: 17 },
            { nome: "Tipo Pagamento", len: 3 },
            { nome: "Identificação Token", len: 1 },
            { nome: "Payment Account Reference (PAR)", len: 29 },
            { nome: "CNPJ Rede", len: 14 },
            { nome: "CNPJ PDV", len: 14 },
            { nome: "Versão PDV Cliente", len: 10 },
            { nome: "Versão PinPad", len: 30 },
            { nome: "Versão PDV Server", len: 2 },
            { nome: "Nome Portador Cartão", len: 40 },
            { nome: "Código SubModalidade", len: 2, isOnlyDebit: true },
            { nome: "Indicação QR Code", len: 1 },
            { nome: "Código Parceiro", len: 5 },
            { nome: "IMEI", len: 16 },
            { nome: "SIMCard ID (ICCID)", len: 22 },
            { nome: "Nome operadora", len: 10 },
            { nome: "MAC address", len: 12 },
            { nome: "Endereço IP", len: 32 },
            { nome: "Informações antena (CGI)", len: 30 },
            { nome: "Versão plataforma (CA + plataforma)", len: 20 },
            { nome: "Capture Source", len: 2, descFunc: feinterf_desc_capturesource},
            { nome: "Código Emissor", len: 4, descFunc: get_desc_codigo_emissor },
            { nome: "Clear Sale Score", len: 20 },
            { nome: "Latitude", len: 20 },
            { nome: "Longitude", len: 20 },
        ],
        opcionais: 5, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}

function feinterf_b_layout()
{
    var info = {
        array_fields: [
            { nome: "Tipo", len: 1, descFunc: feinterf_desc_tipo },
            { nome: "Estabelecimento", len: 9 },
            { nome: "Data", len: 8 },
            { nome: "Hora", len: 6 },
            { nome: "Código Terminal", len: 8 },
            { nome: "Stan", len: 6 },
            { nome: "Número Checkout", len: 8 },
            { nome: "Número de Serie", len: 32 },
            { nome: "Número Telefone Chamador", len: 16 },
            { nome: "Identificador Coleta CVC2", len: 1 },
            { nome: "Versão Software", len: 5 },
            { nome: "IMEI", len: 16 },
            { nome: "SIMCard ID (ICCID)", len: 22 },
            { nome: "Nome operadora", len: 10 },
            { nome: "MAC address", len: 12 },
            { nome: "Endereço IP", len: 32 },
            { nome: "Informações antena (CGI)", len: 30 },
            { nome: "Versão plataforma (CA + plataforma)", len: 20 },
        ],
        opcionais: 7, // Sempre que um campo for adicionado, incrementar esse valor
    }

    return info
}
