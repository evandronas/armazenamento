// feinterf_desc.js

function feinterf_desc_tipo(valor)
{
    var desc

    switch(valor)
    {
        case "B":
            desc = "Baixa Técnica"
            break

        case "C":
            desc = "Crédito"
            break

        case "D":
            desc = "Débito/Voucher"
            break

        case "L":
            desc = "Sign-On"
            break

        default:
            // desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}

function feinterf_desc_status(valor)
{
    var desc
    valor = parseInt(valor, 10)

    switch (valor)
    {
        case 1:
            desc = "Aprovada"
            break

        case 2:
            desc = "Negada"
            break

        default:
            desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}

function feinterf_desc_capturesource(valor)
{
    var desc

    switch(valor)
    {
        case "01":
            desc = "Produto Adquirência"
            break

        case "02":
            desc = "Carteira Digital REDE"
            break

        case "03":
            desc = "Datacash"
            break

        case "04":
            desc = "Carteira Digital Master Remote"
            break

        case "05":
            desc = "Carteira Digital Master NFC"
            break

        case "06":
            desc = "Carteira Digital Visa Checkout"
            break

        case "07":
            desc = "Link de Pagamento"
            break

        case "99":
            desc = "Outros"
            break

        default:
            // desc = kMSG_ERRO_VALOR_NAO_MAPEADO
            break
    }

    return desc
}
