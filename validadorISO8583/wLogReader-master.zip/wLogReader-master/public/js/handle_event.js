// handle_event.js

// ================================================================================================
// Objetos HTML - apenas apos a pagina ser carregada
var kHTML_TEXTAREA_MSG = document.getElementById(kID_TXTAREA_MSG)
var kHTML_RB_ACQ = document.getElementById(kID_RB_ACQ)
var kHTML_RB_ISS = document.getElementById(kID_RB_ISS)
var kHTML_RB_EXT = document.getElementById(kID_RB_EXT)
var kHTML_RB_OUT = document.getElementById(kID_RB_OUT)
var kHTML_RB_BIT = document.getElementById(kID_RB_BIT)
var kHTML_CBOX_FE = document.getElementById(kID_CBOX_FE)
var kHTML_CBOX_DRIVER = document.getElementById(kID_CBOX_DRIVER)
var kHTML_CB_SEM_HEADER = document.getElementById(kID_CB_SEM_HEADER)
var kHTML_CB_SEM_FORMATACAO = document.getElementById(kID_CB_SEM_FORMATACAO)
var kHTML_BT_GO = document.getElementById(kID_BT_GO)
var kHTML_BT_LIMPAR_MSG = document.getElementById(kID_BT_LIMPAR_MSG)
var kHTML_BT_LIMPAR_MSG_RESULT = document.getElementById(kID_BT_LIMPAR_MSG_RESULT)
var kHTML_BT_LIMPAR_RESULT = document.getElementById(kID_BT_LIMPAR_RESULT)
var kHTML_BT_LIMPAR_TUDO = document.getElementById(kID_BT_LIMPAR_TUDO)
var kHTML_LABEL_MSG_FORMATTED = document.getElementById(kID_LABEL_MSG_FORMATTED)
var kHTML_LABEL_MSG_CLEAN = document.getElementById(kID_LABEL_MSG_CLEAN)

// ================================================================================================

/*
=================================================
RADIO ACQUIRER
=================================================
*/
kHTML_RB_ACQ.addEventListener("click", rb_acq_event_click)

function rb_acq_event_click()
{
    handle_rb_acq()
    updateUrl(kURL_PARAM_TIPO)
}

/*
=================================================
RADIO ISSUER
=================================================
*/
kHTML_RB_ISS.addEventListener("click", rb_iss_event_click)

function rb_iss_event_click()
{
    handle_rb_iss()
    updateUrl(kURL_PARAM_TIPO)
}

/*
=================================================
RADIO EXTRACAO
=================================================
*/
kHTML_RB_EXT.addEventListener("click", rb_ext_event_click)

function rb_ext_event_click()
{
    handle_rb_ext()
    updateUrl(kURL_PARAM_TIPO)
}

/*
=================================================
RADIO OUTROS
=================================================
*/
kHTML_RB_OUT.addEventListener("click", rb_out_event_click)

function rb_out_event_click()
{
    handle_rb_out()
    updateUrl(kURL_PARAM_TIPO)
}

/*
=================================================
RADIO BIT
=================================================
*/
kHTML_RB_BIT.addEventListener("click", rb_bit_event_click)

function rb_bit_event_click()
{
    handle_rb_bit()
}

/*
=================================================
COMBOBOX FRONT-END
=================================================
*/
kHTML_CBOX_FE.addEventListener("change", combobox_fe_event_click)

function combobox_fe_event_click()
{
    handle_cbox_fe_changed()
    updateUrl(kURL_PARAM_FE)
}

/*
=================================================
COMBOBOX DRIVER
=================================================
*/
kHTML_CBOX_DRIVER.addEventListener("change", combobox_driver_event_click)

function combobox_driver_event_click()
{
    if (kHTML_RB_ACQ.checked)
    {
        updateUrl(kURL_PARAM_DRV)
    }
    else if (kHTML_RB_ISS.checked)
    {
        updateUrl(kURL_PARAM_BNDR)
    }
    else if (kHTML_RB_EXT.checked)
    {
        updateUrl(kURL_PARAM_CAP)
    }
    else if (kHTML_RB_OUT.checked)
    {
        updateUrl(kURL_PARAM_OUTROS)
    }
}

/*
=================================================
CHECKBOX SEM HEADER
=================================================
*/
kHTML_CB_SEM_HEADER.addEventListener("change", checkbox_sem_header_event_click)

function checkbox_sem_header_event_click()
{
    handle_cb_sem_header()
    // updateUrl(kURL_PARAM_SEMHEADER)
}

/*
=================================================
CHECKBOX SEM FORMATACAO
=================================================
*/
kHTML_CB_SEM_FORMATACAO.addEventListener("change", checkbox_sem_formatacao_event_click)

function checkbox_sem_formatacao_event_click()
{
    // updateUrl(kURL_PARAM_SEMFMT)
}

/*
=================================================
BOTAO GO
=================================================
*/
kHTML_BT_GO.addEventListener("click", bt_go_event_click)

function bt_go_event_click()
{
    read_main()
}

/*
=================================================
BOTAO LIMPAR MSG
=================================================
*/
kHTML_BT_LIMPAR_MSG.addEventListener("click", bt_limpar_msg_event_click)

function bt_limpar_msg_event_click()
{
    limpar_msg()
}

/*
=================================================
BOTAO LIMPAR MSG e RESULTADO
=================================================
*/
kHTML_BT_LIMPAR_MSG_RESULT.addEventListener("click", bt_limpar_msg_result_event_click)

function bt_limpar_msg_result_event_click()
{
    limpar_msg()
    limpar_resultado()
}

/*
=================================================
BOTAO LIMPAR RESULTADO
=================================================
*/
kHTML_BT_LIMPAR_RESULT.addEventListener("click", bt_limpar_result_event_click)

function bt_limpar_result_event_click()
{
    limpar_resultado()
}

/*
=================================================
BOTAO LIMPAR TUDO
=================================================
*/
kHTML_BT_LIMPAR_TUDO.addEventListener("click", bt_limpar_tudo_event_click)

function bt_limpar_tudo_event_click()
{
    limpar_tudo()
}
