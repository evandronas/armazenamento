// handle_html_input.js

function handle_page_load()
{
    kHTML_RB_ACQ.checked = false

    kHTML_RB_ISS.checked = false

    kHTML_RB_EXT.checked = false

    kHTML_RB_OUT.checked = false

    kHTML_RB_BIT.checked = false

    // var cbox_fes

    // var cbox_driver

    kHTML_CB_SEM_HEADER.checked = false

    kHTML_CB_SEM_FORMATACAO.checked = false

    // aceitar parametros na URL
    handleUrl()

    //

    // dev_on_going()
}

// sempre que atualiza a pagina, ja preenche as opcoes e foca no botao GO
function dev_on_going()
{
    // Acquirer/Front-End/Driver
    // kHTML_RB_ACQ.checked = true
    // handle_rb_acq()
    // kHTML_CBOX_FE.value = kFE_PDV
    // handle_cbox_fe_changed()
    // kHTML_CBOX_DRIVER.value = kDRV_PDV_INTELLINAC
    // kHTML_CB_SEM_FORMATACAO.checked = true

    // Issuer
    // kHTML_RB_ISS.checked = true
    // handle_rb_iss()
    // kHTML_CBOX_DRIVER.value = kBNDR_MASTER
    // kHTML_CB_SEM_FORMATACAO.checked = true

    // Extracao
    // kHTML_RB_EXT.checked = true
    // handle_rb_ext()
    // kHTML_CBOX_DRIVER.value = kEXT_CAPCHFULAMEX_71
    // kHTML_CB_SEM_FORMATACAO.checked = true

    // Outros
    // kHTML_RB_OUT.checked = true
    // handle_rb_out()
    // kHTML_CBOX_DRIVER.value = kOUT_FEINTERF_B

    // BIT
    // kHTML_RB_BIT.checked = true
    // handle_rb_bit()
    // kHTML_CBOX_DRIVER.value = kBIT_GEN_DE55_EBCDIC

    //

    kHTML_BT_GO.focus()
}

function handle_rb_acq()
{
    hideAll()

    toggleComboBoxFrontEnd()
    changeLabelText(kID_LABEL_CBOX_FE, "Front-End")
    toggleCheckBoxSemHeader()
    toggleCheckBoxSemFormatacao()

    var arr = [
        kFE_POS71,
        kFE_POS75,
        kFE_PDV71,
        kFE_PDV75,
        kFE_WEB,
    ]

    fillComboBox(kID_CBOX_FE, arr)
}

function handle_cbox_fe_changed()
{
    if (kHTML_CB_SEM_HEADER.checked)
    {
        if (kHTML_CBOX_FE.value != kFE_WEB)
        {
            if (!hasHideCssClass(kID_CBOX_DRIVER))
                toggleComboBoxDriver()

            return
        }
        else
        {
            if (hasHideCssClass(kID_CBOX_DRIVER))
                toggleComboBoxDriver()
        }
    }

    var arr

    switch (kHTML_CBOX_FE.value)
    {
        case kFE_POS71:
            arr = [
                kDRV_POS_MEGANAC,
                kDRV_POS_NAC,
                kDRV_POS_POSIP,
            ]
            break

        case kFE_POS75:
            arr = [
                kDRV_POS_MEGANAC,
                kDRV_POS_NAC,
                kDRV_POS_POSIP,
                kDRV_POS_POSIP_MEGANAC,
                kDRV_POS_TAPONPHONE,
            ]
            break

        case kFE_PDV71:
            arr = [
                kDRV_PDV_PROTOM,
                kDRV_PDV_INTELLINAC,
                kDRV_PDV_IP,
                kDRV_PDV_QH,
            ]
            break

        case kFE_PDV75:
            arr = [
                kDRV_PDV_INTELLINAC,
                kDRV_PDV_IP,
                kDRV_PDV_QH,
            ]
            break

        case kFE_WEB:
            arr = [
                kDRV_WEB_EC,
                kDRV_WEB_EC_TPDU,
                kDRV_WEB_OL,
            ]
            break
    }

    if (hasHideCssClass(kID_CBOX_DRIVER))
        toggleComboBoxDriver()

    changeLabelText(kID_LABEL_CBOX_DRIVER, "Tipo")

    arr.sort()
    fillComboBox(kID_CBOX_DRIVER, arr)
}

function handle_rb_iss()
{
    hideAll()

    toggleComboBoxDriver()
    changeLabelText(kID_LABEL_CBOX_DRIVER, "Bandeira")
    toggleCheckBoxSemHeader()
    toggleCheckBoxSemFormatacao()

    var arr = [
        kBNDR_ALELO,
        kBNDR_AMEXFULL,
        kBNDR_DINERS,
        kBNDR_ELOFULL,
        kBNDR_HV,
        kBNDR_ITI,
        kBNDR_MASTER,
        kBNDR_MULTIBNDRFULL,
        kBNDR_MULTIBNDRVAN,
        kBNDR_PRIVATELABEL,
        kBNDR_TICKET,
        kBNDR_VISA,
        kBNDR_VOUCHER,
        kBNDR_WQ3,
    ]

    arr.sort()
    fillComboBox(kID_CBOX_DRIVER, arr)
}

function handle_rb_ext()
{
    hideAll()

    toggleComboBoxDriver()
    changeLabelText(kID_LABEL_CBOX_DRIVER, "CAP")
    toggleCheckBoxSemFormatacao()

    arr = [
        // Financeira
        kEXT_CAPCRED,
        kEXT_CAPCREDD,
        kEXT_CAPCREDAMEX,
        kEXT_CAPCREDAMEXD,
        kEXT_CAPCREDELO,
        kEXT_CAPCREDELOD,
        kEXT_CAPCREDELOVAN,
        kEXT_CAPCREDVAN,
        kEXT_CAPCREDVISA,
        kEXT_CAPCREDVISAD,
        kEXT_CAPCRCUP,
        kEXT_CAPDEB,
        kEXT_CAPDEBD,
        kEXT_CAPDEBELO,
        kEXT_CAPDEBELOD,
        kEXT_CAPDEBELOVAN,
        kEXT_CAPDEBVAN,
        kEXT_CAPDEBMC,
        kEXT_CAPDEBMCD,
        // kEXT_CAPDEBVAN_71,
        // kEXT_CAPDEBVAN_75,
        kEXT_CAPDEBVISA,
        kEXT_CAPDEBVISAD,
        kEXT_CAPPRIV,

        // Dados de Chip
        kEXT_CAPCHFUL,
        kEXT_CAPCHFULAMEX,
        // kEXT_CAPCHFULAMEX_71,
        // kEXT_CAPCHFULAMEX_75,
        kEXT_CAPCHFULDEB,
        kEXT_CAPCHFULDEBELO,
        kEXT_CAPCHFULDEBVAN,
        kEXT_CAPCHFULDEBVISA,
        kEXT_CAPCHFULELO,
        kEXT_CAPCHFULVAN,
        kEXT_CAPCHFULVISA,
        kEXT_CAPCHPRV,
        kEXT_CAPCHUPI,
        kEXT_CAPCHDEBMC,

        // Dados Adicionais
        kEXT_EXTIATA,
        kEXT_SIMULCREDIARIO,
        kEXT_TRNNEGADAS,
        kEXT_TRNAPROVADAS,
        kEXT_CAPCREDQRC,
        kEXT_CAPDEBQRC,
        kEXT_CAPNFIN,

        // Servico
        kEXT_CAPITI,
        kEXT_CAPPSERV,
        kEXT_CAPRCRG,
        kEXT_CAPSERVRCRG,
        kEXT_CAPPIX,

        // Relatorio
        kEXT_CAPCREDCONS,
        kEXT_CAPCREDCONS1,
        kEXT_CAPCREDCONSVISA,
        kEXT_CAPDEBCONS,
        kEXT_CAPDEBCONS1,
        kEXT_CAPDEBCONSVISA,
        kEXT_CAPEND,
        kEXT_DEBFRD,
        kEXT_REVAMEX,

        // OL
        kEXT_OLTO,
    ]

    arr.sort();
    fillComboBox(kID_CBOX_DRIVER, arr)
}

function handle_rb_out()
{
    hideAll()

    toggleComboBoxDriver()
    changeLabelText(kID_LABEL_CBOX_DRIVER, "Outros")
    toggleCheckBoxSemFormatacao()

    arr = [
        kOUT_FEINTERF_CR,
        kOUT_FEINTERF_DB,
        kOUT_FEINTERF_B,
        kOUT_SWREPLIC,
        kOUT_NUNTIUS,
    ]

    arr.sort();
    fillComboBox(kID_CBOX_DRIVER, arr)
}

function handle_rb_bit()
{
    hideAll()

    toggleComboBoxDriver()
    changeLabelText(kID_LABEL_CBOX_DRIVER, "BIT")

    var arr = [
        kBIT_POS_DE47,
        kBIT_POS_DE48,
        kBIT_POS_DE55,
        kBIT_GEN_DE55_ASCII,
        kBIT_GEN_DE55_EBCDIC,
        kBIT_DE55_VISA,
    ]

    fillComboBox(kID_CBOX_DRIVER, arr)
}

function handle_cb_sem_header()
{
    if (kHTML_CB_SEM_HEADER.checked) // selecionado - sem header
    {
        if (kHTML_RB_ACQ.checked && kHTML_CBOX_FE.value != kFE_WEB) // se for mensagem do acquirer
        {
            toggleComboBoxDriver()
        }
    }
    else // nao selecionado - com header
    {
        if (kHTML_RB_ACQ.checked && kHTML_CBOX_FE.value != kFE_WEB) // se for mensagem do acquirer
        {
            handle_cbox_fe_changed()
        }
    }
}

function limpar_msg()
{
    // Text Area
    kHTML_TEXTAREA_MSG.value = ""
    kHTML_TEXTAREA_MSG.focus()
}

function limpar_resultado()
{
    // label formatado
    kHTML_LABEL_MSG_FORMATTED.innerHTML = ""

    // label clean
    kHTML_LABEL_MSG_CLEAN.innerHTML = ""
}

function limpar_tudo()
{
    // Text Area
    kHTML_TEXTAREA_MSG.value = ""
    kHTML_TEXTAREA_MSG.focus()

    // Radio Button Acquirer
    kHTML_RB_ACQ.checked = false

    // Radio Button Issuer
    kHTML_RB_ISS.checked = false

    // Radio Button Extracao
    kHTML_RB_EXT.checked = false

    // Radio Button Outros
    kHTML_RB_OUT.checked = false

    // Radio Button BIT
    kHTML_RB_BIT.checked = false

    hideAll()

    // sem header
    kHTML_CB_SEM_HEADER.checked = false

    // sem formatacao
    kHTML_CB_SEM_FORMATACAO.checked = false

    // Label com o resultado formatado
    kHTML_LABEL_MSG_FORMATTED.innerHTML = ""

    // Label com o resultado clean
    kHTML_LABEL_MSG_CLEAN.innerHTML = ""

    // voltar titulo
    mudarNomePagina(true)

    // limpar parametros da url
    cleanUrl()
}

function mudarNomePagina(voltarDefault)
{
    var nome = kNOME_PAGINA

    if (!voltarDefault)
    {
        nome += " - "

        // if (!cbox_fes.disabled)
        if (!hasHideCssClass(kID_CBOX_FE))
        {
            nome += kHTML_CBOX_FE.value + " "
        }

        nome += kHTML_CBOX_DRIVER.value

    }

    document.title = nome
}

function toggleCssClass(id)
{
    var element = document.getElementById(id)
    element.classList.toggle(kCSS_CLASS_HIDE)
}

function toggleComboBoxFrontEnd()
{
    // label
    toggleCssClass(kID_LABEL_CBOX_FE)

    // combo box
    toggleCssClass(kID_CBOX_FE)
}

function toggleComboBoxDriver()
{
    // label
    toggleCssClass(kID_LABEL_CBOX_DRIVER)

    // combo box
    toggleCssClass(kID_CBOX_DRIVER)
}

function hideComboBoxDriver()
{
    if (!hasHideCssClass(kID_LABEL_CBOX_DRIVER) && !hasHideCssClass(kID_CBOX_DRIVER))
    {
        // console.log("!hasHideCssClass - hideComboBoxDriver")
        // label
        toggleCssClass(kID_LABEL_CBOX_DRIVER)
        // document.getElementById(kID_LABEL_CBOX_DRIVER).classList.add(kCSS_CLASS_HIDE)

        // combo box
        // toggleCssClass(kID_CBOX_DRIVER)
        // console.log(document.getElementById(kID_CBOX_DRIVER).classList)
        document.getElementById(kID_CBOX_DRIVER).classList.add(kCSS_CLASS_HIDE)
        // var a = document.getElementById(kID_CBOX_DRIVER)
        // a.classList.add(kCSS_CLASS_HIDE)
        // console.log(document.getElementById(kID_CBOX_DRIVER).classList)
    }
}

function toggleCheckBoxSemHeader()
{
    // label
    toggleCssClass(kID_LABEL_SEM_HEADER)

    // combo box
    toggleCssClass(kID_CB_SEM_HEADER)
}

function toggleCheckBoxSemFormatacao()
{
    // label
    toggleCssClass(kID_LABEL_SEM_FORMATACAO)

    // combo box
    toggleCssClass(kID_CB_SEM_FORMATACAO)
}

function hasHideCssClass(id)
{
    var element = document.getElementById(id)
    return element.classList.contains(kCSS_CLASS_HIDE)
}

function fillComboBox(id, array)
{
    var cbox = document.getElementById(id);

    cbox.innerText = null

    for (var i = 0; i < array.length; i++)
    {
        var opt = document.createElement("option");
        opt.innerHTML = array[i];
        opt.value = array[i];
        cbox.appendChild(opt);
    }

    // limpando a selecao
    cbox.selectedIndex = -1

    // dando foco
    cbox.focus()
}

function hideAll()
{
    // cbox front-end
    if (!hasHideCssClass(kID_CBOX_FE))
        toggleComboBoxFrontEnd()

    // cbox driver
    if (!hasHideCssClass(kID_CBOX_DRIVER))
        toggleComboBoxDriver()

    // cb sem header
    if (!hasHideCssClass(kID_CB_SEM_HEADER))
        toggleCheckBoxSemHeader()

    // cb sem formatacao
    if (!hasHideCssClass(kID_CB_SEM_FORMATACAO))
        toggleCheckBoxSemFormatacao()
}

function changeLabelText(id, value)
{
    var element = document.getElementById(id)
    element.innerText = value
}
