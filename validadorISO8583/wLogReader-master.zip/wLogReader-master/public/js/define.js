// define.js

// ================================================================================================
// Variaveis que guardam a mensagem
var msg
var msg_formatted
var msg_clean
var msg_break_bit
var msg_break_aux

// ================================================================================================
var kNOME_PAGINA = "wLogReader"

// ================================================================================================
var kDEF_POS = "POS"
var kDEF_PDV = "PDV"

// ================================================================================================
// Tipos do DE
var kFixo = "fixo"
var kLvar = "LVAR"
var kLLvar = "LLVAR"
var kLLLvar = "LLLVAR"

// ================================================================================================
// Formatos
var kFMT_HEXA = "hexa"
var kFMT_HEXA_BASE16 = "hexa_base16"
var kFMT_EBC = "ebc"
var kFMT_BCD = "bcd"
var kFMT_BIN = "bin"

// ================================================================================================
// Front-Ends
var kFE_POS71 = "POS 7.1"
var kFE_POS75 = "POS 7.5"
var kFE_PDV71 = "PDV 7.1"
var kFE_PDV75 = "PDV 7.5"
var kFE_WEB = "WEB"

// ================================================================================================
// Drivers
var kDRV_POS_MEGANAC = "MegaNAC"
var kDRV_POS_NAC = "NAC"
var kDRV_POS_POSIP = "IP"
var kDRV_POS_POSIP_MEGANAC = "MegaNAC Criptografado"
var kDRV_POS_TAPONPHONE = "Tap on Phone"
var kDRV_PDV_INTELLINAC = "Intellinac"
var kDRV_PDV_IP = "IP"
var kDRV_PDV_PROTOM = "Protom"
var kDRV_PDV_QH = "QH"
var kDRV_WEB_EC = "EC"
var kDRV_WEB_EC_TPDU = "EC TPDU"
var kDRV_WEB_OL = "OL"

// ================================================================================================
// Bandeiras
var kBNDR_ALELO = "Alelo"
var kBNDR_AMEXFULL = "Amex Full"
var kBNDR_DINERS = "Diners/JCB"
var kBNDR_ELOFULL = "Elo Full"
var kBNDR_HV = "HV"
var kBNDR_ITI = "ITI"
var kBNDR_MASTER = "Mastercard"
var kBNDR_MULTIBNDRFULL = "Multibandeira Full"
var kBNDR_MULTIBNDRVAN = "Multibandeira Van"
var kBNDR_PRIVATELABEL = "Private Label"
var kBNDR_TICKET = "Ticket"
var kBNDR_VISA = "Visa"
var kBNDR_VOUCHER = "Voucher"
var kBNDR_WQ3 = "WQ3"

// ================================================================================================
// Extracoes
// POS / PDV
var kEXT_CAPCRED = "CAPCRED"
var kEXT_CAPCREDAMEX = "CAPCREDAMEX"
var kEXT_CAPCREDELO = "CAPCREDELO"
var kEXT_CAPCREDELOVAN = "CAPCREDELOVAN"
var kEXT_CAPCREDVAN = "CAPCREDVAN"
var kEXT_CAPCREDVISA = "CAPCREDVISA"
var kEXT_CAPDEB = "CAPDEB"
var kEXT_CAPDEBELO = "CAPDEBELO"
var kEXT_CAPDEBELOVAN = "CAPDEBELOVAN"
var kEXT_CAPDEBVAN = "CAPDEBVAN"
var kEXT_CAPDEBVAN_71 = "CAPDEBVAN 7.1"
var kEXT_CAPDEBVAN_75 = "CAPDEBVAN 7.5"
var kEXT_CAPDEBVISA = "CAPDEBVISA"
var kEXT_CAPPRIV = "CAPPRIV"
var kEXT_CAPCRCUP = "CAPCRCUP"
var kEXT_CAPDEBMC = "CAPDEBMC"
var kEXT_CAPDEBMCD = "CAPDEBMCD"
// DADOS CHIP
var kEXT_CAPCHFUL = "CAPCHFUL"
var kEXT_CAPCHFULAMEX = "CAPCHFULAMEX"
var kEXT_CAPCHFULAMEX_71 = "CAPCHFULAMEX 7.1"
var kEXT_CAPCHFULAMEX_75 = "CAPCHFULAMEX 7.5"
var kEXT_CAPCHFULDEB = "CAPCHFULDEB"
var kEXT_CAPCHFULDEBELO = "CAPCHFULDEBELO"
var kEXT_CAPCHFULDEBVAN = "CAPCHFULDEBVAN"
var kEXT_CAPCHFULDEBVISA = "CAPCHFULDEBVISA"
var kEXT_CAPCHFULELO = "CAPCHFULELO"
var kEXT_CAPCHFULVAN = "CAPCHFULVAN"
var kEXT_CAPCHFULVISA = "CAPCHFULVISA"
var kEXT_CAPCHPRV = "CAPCHPRV"
var kEXT_CAPCHUPI = "CAPCHUPI"
var kEXT_CAPCHDEBMC = "CAPCHDEBMC"
// WEB
var kEXT_CAPCREDD = "CAPCREDD"
var kEXT_CAPCREDAMEXD = "CAPCREDAMEXD"
var kEXT_CAPCREDELOD = "CAPCREDELOD"
var kEXT_CAPCREDVISAD = "CAPCREDVISAD"
var kEXT_CAPDEBD = "CAPDEBD"
var kEXT_CAPDEBELOD = "CAPDEBELOD"
var kEXT_CAPDEBVISAD = "CAPDEBVISAD"
// DADOS ADICIONAIS
var kEXT_EXTIATA = "EXT IATA"
var kEXT_SIMULCREDIARIO = "SIMUL CREDIARIO"
var kEXT_TRNNEGADAS = "TRANSAÇÕES NEGADAS"
var kEXT_TRNAPROVADAS = "TRANSAÇÕES APROVADAS"
var kEXT_CAPCREDQRC = "CAPCREDQRC"
var kEXT_CAPDEBQRC = "CAPDEBQRC"
var kEXT_CAPNFIN = "CAPNFIN"
// SERVICO
var kEXT_CAPITI = "CAPITI"
var kEXT_CAPPSERV = "CAPPSERV"
var kEXT_CAPRCRG = "CAPRCRG"
var kEXT_CAPSERVRCRG = "CAPSERVRCRG"
var kEXT_CAPPIX = "CAPPIX"
// RELATORIO
var kEXT_CAPCREDCONS = "CAPCREDCONS"
var kEXT_CAPCREDCONS1 = "CAPCREDCONS1"
var kEXT_CAPCREDCONSVISA = "CAPCREDCONSVISA"
var kEXT_CAPDEBCONS = "CAPDEBCONS"
var kEXT_CAPDEBCONS1 = "CAPDEBCONS1"
var kEXT_CAPDEBCONSVISA = "CAPDEBCONSVISA"
var kEXT_CAPEND = "CAPEND"
var kEXT_DEBFRD = "DEBFRD"
var kEXT_REVAMEX = "REVAMEX"
// OL
var kEXT_OLTO = "fltouppa"

// ================================================================================================
// Outros
var kOUT_FEINTERF_CR = "FEInterf Crédito"
var kOUT_FEINTERF_DB = "FEInterf Débito"
var kOUT_FEINTERF_B = "FEInterf B"
var kOUT_SWREPLIC = "SWReplic"
var kOUT_NUNTIUS = "Nuntius"

// ================================================================================================
// BIT
var kBIT_POS_DE47 = "POS DE47"
var kBIT_POS_DE48 = "POS DE48"
var kBIT_POS_DE55 = "POS DE55"
var kBIT_GEN_DE55_ASCII = "DE55 ASCII"
var kBIT_GEN_DE55_EBCDIC = "DE55 EBCDIC"
var kBIT_DE55_VISA = "DE55 VISA"

// ================================================================================================
// URL
var kURL_PARAM_TIPO = "tipo"
    var kURL_VALOR_TIPO_ACQ = "acq"
    var kURL_VALOR_TIPO_ISS = "iss"
    var kURL_VALOR_TIPO_EXT = "ext"
    var kURL_VALOR_TIPO_OUT = "out"
    var kURL_VALOR_TIPO_BIT = "bit"
var kURL_PARAM_FE = "fe"
    var kURL_VALOR_FE_POS71 = "pos71"
    var kURL_VALOR_FE_POS75 = "pos75"
    var kURL_VALOR_FE_PDV71 = "pdv71"
    var kURL_VALOR_FE_PDV75 = "pdv75"
    var kURL_VALOR_FE_WEB = "web"
var kURL_PARAM_DRV = "drv"
    var kURL_VALOR_DRV_MTG = "mtg"
    var kURL_VALOR_DRV_TG = "tg"
    var kURL_VALOR_DRV_IP = "ip"
    var kURL_VALOR_DRV_TAPONPHONE = "taponphone"
    var kURL_VALOR_DRV_PROTOM = "protom"
    var kURL_VALOR_DRV_INAC = "inac"
    var kURL_VALOR_DRV_QH = "qh"
    var kURL_VALOR_DRV_EC = "ec"
    var kURL_VALOR_DRV_EC_TPDU = "ectpdu"
    var kURL_VALOR_DRV_OL = "ol"
var kURL_PARAM_BNDR = "bndr"
    var kURL_VALOR_BNDR_ALELO = "alelo"
    var kURL_VALOR_BNDR_AMEXFULL = "amexfull"
    var kURL_VALOR_BNDR_DINERS = "diners"
    var kURL_VALOR_BNDR_JCB = "jcb"
    var kURL_VALOR_BNDR_ELOFULL = "elofull"
    var kURL_VALOR_BNDR_HV = "hv"
    var kURL_VALOR_BNDR_ITI = "iti"
    var kURL_VALOR_BNDR_MASTERCARD = "mastercard"
    var kURL_VALOR_BNDR_MULTIBANDEIRAFULL = "multibandeirafull"
    var kURL_VALOR_BNDR_MULTIBANDEIRAVAN = "multibandeiravan"
    var kURL_VALOR_BNDR_PRIVATELABEL = "privatelabel"
    var kURL_VALOR_BNDR_TICKET = "ticket"
    var kURL_VALOR_BNDR_VISA = "visa"
    var kURL_VALOR_BNDR_VOUCHER = "voucher"
    var kURL_VALOR_BNDR_WQ3 = "wq3"
var kURL_PARAM_CAP = "cap"
    var kURL_VALOR_CAP_EXTIATA = "extiata"
    var kURL_VALOR_CAP_SIMULCREDIARIO = "simulcrediario"
    var kURL_VALOR_CAP_OLTO = "fltouppa"
var kURL_PARAM_OUTROS = "out"
    var kURL_VALOR_OUT_FEINTERFCR = "feinterfcr"
    var kURL_VALOR_OUT_FEINTERFDB = "feinterfdb"
    var kURL_VALOR_OUT_FEINTERFB = "feinterfb"
    var kURL_VALOR_OUT_SWREPLIC = "swreplic"
    var kURL_VALOR_OUT_NUNTIUS = "nuntius"
// var kURL_PARAM_BIT = "bit"
var kURL_PARAM_SEMHEADER = "semheader"
var kURL_PARAM_SEMFMT = "semfmt"
var kURL_PARAM_SEMFORMATACAO = "semformatacao"

// ================================================================================================
// IDs HTML
var kID_TXTAREA_MSG = "txtarea_msg"
var kID_RB_ACQ = "radio_bt_acq"
var kID_RB_ISS = "radio_bt_iss"
var kID_RB_EXT = "radio_bt_ext"
var kID_RB_OUT = "radio_bt_out"
var kID_RB_BIT = "radio_bt_bit"
var kID_LABEL_CBOX_FE = "lbl_combobox_fes"
var kID_CBOX_FE = "combobox_fes"
var kID_LABEL_CBOX_DRIVER = "lbl_combobox_driver"
var kID_CBOX_DRIVER = "combobox_driver"
var kID_LABEL_SEM_HEADER = "lbl_checkbox_sem_header"
var kID_CB_SEM_HEADER = "checkbox_sem_header"
var kID_LABEL_SEM_FORMATACAO = "lbl_checkbox_sem_formatacao"
var kID_CB_SEM_FORMATACAO = "checkbox_sem_formatacao"
var kID_TXTAREA_QTDE_REG_EXT = "txtarea_qtde_reg_ext"
var kID_BT_GO = "bt_go"
var kID_BT_LIMPAR_MSG = "bt_limpar_msg"
var kID_BT_LIMPAR_MSG_RESULT = "bt_limpar_msg_result"
var kID_BT_LIMPAR_RESULT = "bt_limpar_result"
var kID_BT_LIMPAR_TUDO = "bt_limpar_tudo"
var kID_LABEL_MSG_FORMATTED = "label_result_formatted"
var kID_LABEL_MSG_CLEAN = "label_result_clean"

// ================================================================================================
// Objetos HTML
// no arquivo handle_event.js

// ================================================================================================
// var kMSG_ERRO_VALOR_NAO_MAPEADO = "ERRO: Valor não mapeado!!!"
var kMSG_ERRO_VALOR_NAO_MAPEADO = "Valor não mapeado"

// ================================================================================================
var kCSS_CLASS_HIDE = "hide"

// ================================================================================================
// Datas
var kDATA_YYYYMMDD = "YYYYMMDD"
var kDATA_YYMMDD = "YYMMDD"
var kDATA_DDMMYY = "DDMMYY"
var kDATA_DDMMYYYY = "DDMMYYYY"
// var kDATA_MMDD = "MMDD"
// var kDATA_DDMMM = "DDMMM"
// var kDATA_DDMMMYY = "DDMMMYY"

// ================================================================================================
// Outros valores
var kDE90_MSGTYPE = "Message Type"
var kDE90_STAN = "Stan (DE11)"
var kDE90_DATA = "Data MMDD (DE13)"
var kDE90_HORA = "Hora HHMMSS (DE12)"
var kDE90_IDENT_ACQ = "Identificação Acquirer (DE32)"
var kDE90_RES = "Reservado"

// ================================================================================================
