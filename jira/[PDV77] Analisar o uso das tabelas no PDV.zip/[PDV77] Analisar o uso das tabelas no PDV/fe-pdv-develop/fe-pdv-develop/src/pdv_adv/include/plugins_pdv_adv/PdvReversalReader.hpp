/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -----------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2013, 13 de setembro
/ Hist�rico Mudan�as: 2012 ,13 de setembro, t689066, Alexandre Teodoro 
                                                      Guimaraes, Versao Inicial
/ -----------------------------------------------------------------------------
*/
#pragma once
#include "dispatcher/Reader.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dbaccess_pdv_adv/Reversal.hpp"
#include "logger/Logger.hpp"

namespace plugins_pdv_adv
{
    extern "C" base::Identificable* createPdvReversalReader();

    class PdvReversalReader : public dispatcher::Reader
    {
    public:
        PdvReversalReader();
        virtual ~PdvReversalReader();
        bool startConfiguration( const configBase::Tag* a_tag );
		bool open( ) ;
		void close( );
		bool fetch( ); 
        int getTps( );       
        PdvReversalReader& setStartInterval( const std::string& a_value );
        PdvReversalReader& setEndInterval( const std::string& a_value );
        PdvReversalReader& setEndIntervalOnFirstRun( const std::string& a_value );
        PdvReversalReader& setMaxTrxForSleep( const std::string& a_value );                           
        PdvReversalReader& setSleep( const std::string& a_value ); 
    private: 
        std::string m_startInterval;
        std::string m_endInterval;
        std::string m_endIntervalOnFirstRun;
        bool m_firstRun;
        dbaccess_pdv_adv::Reversal m_PdvReversalTb30;	
        long double m_trxCounter;
        unsigned int m_maxTrxForSleep;
        unsigned int m_sleep;        
        unsigned int m_sleepTimes; 
        std::string m_tps;
        logger::Logger* m_logger;
    };
}


