/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -----------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2013, 13 de setembro
/ Hist�rico Mudan�as: 2013, 13 de setembro, t689066, Alexandre Teodoro 
                                                      Guimaraes, Versao Inicial
/ -----------------------------------------------------------------------------
*/
#pragma once
#include "configBase/TagList.hpp"
#include "fieldSet/fscopy.hpp"
#include "dbaccess_pdv_adv/Reversal.hpp"
#include "plugins_pdv_adv/PdvReversalReader.hpp"
#include "logger/LoggerGen.hpp"
#include <sstream>
#include <cmath>
#include <cstring>
#include <unistd.h>

namespace plugins_pdv_adv
{
    base::Identificable* createPdvReversalReader( )
    {
        PdvReversalReader* l_new = new PdvReversalReader;
        return l_new;
    }
	PdvReversalReader::PdvReversalReader( )
	{
        m_startInterval = "1";
        m_endInterval = "1";
        m_trxCounter = 0;
        m_maxTrxForSleep = 0;
        m_sleep = 0;
        m_sleepTimes = 0;
        m_firstRun = true;
        m_logger = 0;
        m_tps = "0";
	}
	PdvReversalReader::~PdvReversalReader( )
	{
	}
    bool PdvReversalReader::startConfiguration( const configBase::Tag* a_tag )
    {   
        configBase::TagList l_tagList;
        m_logger = logger::LoggerGen::getInstance( );
		m_logger->init( );
        a_tag->findTag( "startInterval", l_tagList );
        this->setStartInterval( l_tagList.front().findProperty( "value" ).value() );

        a_tag->findTag( "endInterval", l_tagList );
        this->setEndInterval( l_tagList.front().findProperty( "value" ).value() );

        a_tag->findTag( "endIntervalOnFirstRun", l_tagList );
        this->setEndIntervalOnFirstRun( l_tagList.front().findProperty( "value" ).value() );

        a_tag->findTag( "maxTrxForSleep", l_tagList );
        this->setMaxTrxForSleep( l_tagList.front().findProperty( "value" ).value() );

        a_tag->findTag( "sleep", l_tagList );
        this->setSleep( l_tagList.front().findProperty( "value" ).value() ); 

        return true; 
    }    
    PdvReversalReader& PdvReversalReader::setStartInterval( const std::string& a_value )
    {
        m_startInterval = a_value;
        return *this;
    }
    PdvReversalReader& PdvReversalReader::setEndInterval( const std::string& a_value )
    {    
        m_endInterval = a_value;
        return *this;
    }      
    PdvReversalReader& PdvReversalReader::setEndIntervalOnFirstRun( const std::string& a_value )
    {    
        m_endIntervalOnFirstRun = a_value;
        return *this;
    }        
    PdvReversalReader& PdvReversalReader::setMaxTrxForSleep( const std::string& a_value )
    {    
        m_maxTrxForSleep = static_cast<unsigned int>( strtoul( a_value.c_str( ), NULL, 10 ) );
        return *this;
    }    
    PdvReversalReader& PdvReversalReader::setSleep( const std::string& a_value )
    {    
        m_sleep = static_cast<unsigned int>( strtoul( a_value.c_str( ), NULL, 10 ) );;
        return *this;
    }            
	bool PdvReversalReader::open( )
	{
        char l_lostTime[12];
        std::ostringstream l_whereClauseTb30;
		std::string nmFe;
		std::string hostAcq;
		std::string nmSite;

		nmFe = getenv ("NOM_FE_ACQR");
		hostAcq = getenv ("NOM_HOST_ACQR");
		nmSite = getenv ("NOM_SITE_ACQR");

		if(nmFe.size() == 0 || hostAcq.size() == 0 ||  nmSite.size() == 0) {
            m_logger->print( logger::LEVEL_FATAL, std::string("Configura��es inv�lidas!").c_str() );
			return false;
		}

        l_whereClauseTb30 << "TB30.dat_mov_tran = TB121.dat_mov_tran and TB30.num_seq_unc = TB121.num_seq_unc "
                          << " and TB30.NOM_FE_ACQR_ORGL = '"<< nmFe << "'"
		                  << " and TB30.NOM_HOST_ACQR_ORGL = '"<< hostAcq << "'"
						  << " and TB30.NOM_SITE_ACQR_ORGL = '"<< nmSite << "'"
                      	  << " and TB30.IND_STTU_TRAN = 'A'"
                          << " and (sysdate - TB30.DTH_STTU_TRAN) between ("
						  << m_startInterval << "/86400)"
						  << " and (";
        if( m_firstRun == true )
        {
            l_whereClauseTb30 <<  m_endIntervalOnFirstRun;
        }
        else
        {
            memset( l_lostTime, 0, sizeof l_lostTime );
            snprintf( l_lostTime, sizeof l_lostTime, "%d", m_sleepTimes * m_sleep );
            l_whereClauseTb30 <<  m_endInterval << "+" << l_lostTime;     
        }
        l_whereClauseTb30 << "/86400)";     
        //l_whereClauseTb30 << " and tip_tran = 4 and cod_cmpm_tran in ('34','35')";     
        m_PdvReversalTb30.setWhereClause( l_whereClauseTb30.str() );
        //m_PdvReversalTb30.setTableName( "TBSW0030" );          
		m_logger->print( logger::LEVEL_DEBUG, " ============ TBSW0030 ============\n" );
        m_logger->print( logger::LEVEL_DEBUG, l_whereClauseTb30.str( ).c_str( ) );
        //m_logger->print( logger::LEVEL_DEBUG, l_whereClauseTb30.str().c_str() );        
        m_PdvReversalTb30.prepare();
        m_PdvReversalTb30.execute();        
        m_firstRun = false;
        m_trxCounter = 0;
        m_sleepTimes = 0;
		return true;
	}
	void PdvReversalReader::close( )
	{
	}
	bool PdvReversalReader::fetch( )
	{      
        char l_bufferTemp[64];
        if( m_PdvReversalTb30.fetch() )
        {
            if( ( m_trxCounter >= m_maxTrxForSleep-1 ) && 
                ( fmod( m_trxCounter, m_maxTrxForSleep ) == 0 ) )
            {
                m_logger->print( logger::LEVEL_DEBUG, ": Too many trx in TBSW0030 to process, waiting a bit to skip overload." );
                m_sleepTimes++;
                sleep( m_sleep );
            }
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.COD_MSG_ISO" ), m_PdvReversalTb30.get_COD_MSG_ISO() ); //acq_msgtype, cd_msg_iso
            oasis_dec_t l_dec_temp;
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.COD_PCM_ISO" ), m_PdvReversalTb30.get_COD_PCM_ISO() ); //pcode de003
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.COD_POS_ENTR_MODO" ), m_PdvReversalTb30.get_COD_POS_ENTR_MODO() ); //pdv_entry_mode de022
            l_dec_temp = m_PdvReversalTb30.get_VAL_TRAN_DLR(); //vlr_trx_dlr
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar( &l_dec_temp, l_bufferTemp );
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.VAL_TRAN_DLR" ), std::string( l_bufferTemp ) );
            l_dec_temp = m_PdvReversalTb30.get_VAL_TRAN();
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar( &l_dec_temp, l_bufferTemp );   
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.VAL_TRAN" ), std::string( l_bufferTemp ) ); //vl_ctc_dlr
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.TRANDATE" ), m_PdvReversalTb30.get_TRANDATE() );
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.TRANTIME" ), m_PdvReversalTb30.get_TRANTIME() );
            l_dec_temp = m_PdvReversalTb30.get_NUM_STAN();
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar( &l_dec_temp, l_bufferTemp );           
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.NUM_STAN" ), std::string( l_bufferTemp ) ); //nu_grc_trm  -de011
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.LOCALDATE" ), m_PdvReversalTb30.get_LOCALDATE() );
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.LOCALTIME" ), m_PdvReversalTb30.get_LOCALTIME() );
            
            //l_dec_temp = m_PdvReversalTb30.get_NUM_SEQ_UNC();
            //memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            //dbm_dectochar( &l_dec_temp, l_bufferTemp );   
            //fieldSet::fscopy( this->navigate( "PDVREVERSAL.NUM_SEQ_UNC" ), std::string( l_bufferTemp ) );
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.NUM_SEQ_UNC" ), m_PdvReversalTb30.get_NUM_SEQ_UNC() ); //de037
            
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.NUM_ESTB" ), m_PdvReversalTb30.get_NUM_ESTB() ); //nu_etb num_pdv de042             
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.ORIGDATE" ), m_PdvReversalTb30.get_ORIGDATE() );
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.ORIGTIME" ), m_PdvReversalTb30.get_ORIGTIME() );                
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.NUM_CAR" ), m_PdvReversalTb30.get_NUM_CAR() );      //nu_car - de002,de035,de045    
			fieldSet::fscopy( this->navigate( "PDVREVERSAL.TIP_TRAN" ), m_PdvReversalTb30.get_TIP_TRAN() );  //in_tpo_trx_ori 
			fieldSet::fscopy( this->navigate( "PDVREVERSAL.COD_MOED" ), m_PdvReversalTb30.get_COD_MOED() ); //cd_mda			
            if( m_PdvReversalTb30.get_COD_EMSR() == 18 ) //MAESTRO
            {
                m_logger->print( logger::LEVEL_DEBUG, ": PDVREVERSAL.ISSUER_FE = MAESTRO" );
                fieldSet::fscopy( this->navigate( "PDVREVERSAL.ISSUER_FE" ), 'M' );  //FE_MC
            }
			else
            {
                m_logger->print( logger::LEVEL_DEBUG, ": PDVREVERSAL.ISSUER_FE = HOST" );
				fieldSet::fscopy( this->navigate( "PDVREVERSAL.ISSUER_FE" ), 'H' );  //FE_HOST
            }
            
            if( m_PdvReversalTb30.GetStatusTransacao().compare("A") == 0 )
            {
                fieldSet::fscopy( this->navigate( "PDVREVERSAL.IND_DEB_CRED" ), 'C' );
            }
            else if( m_PdvReversalTb30.GetStatusTransacao().compare("D") == 0 )
            {
                fieldSet::fscopy( this->navigate( "PDVREVERSAL.IND_DEB_CRED" ), 'D' );
            }
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.NETWORKID" ), m_PdvReversalTb30.GetNetworkId() );
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.VERSAO_APLICATIVO" ), m_PdvReversalTb30.GetVersaoAplicativo().substr(2, 3) );
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.COD_TERM" ), m_PdvReversalTb30.get_COD_TERM() );
            fieldSet::fscopy( this->navigate( "PDVREVERSAL.DAT_MOV_TRAN" ), m_PdvReversalTb30.GetDataMovimento() );
        }
        else
        {
            m_logger->print( logger::LEVEL_DEBUG, ": No row was returned from TBSW0030." );
            return false;
        }
        m_trxCounter++;
        return true;        
    }

    int PdvReversalReader::getTps() {    
       return atoi(m_tps.c_str());  
    }    

}//namespace plugins_pdv_adv


