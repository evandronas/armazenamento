#pragma once

#include <sstream>
#include <iostream>
#include <iomanip>
#include <string>

#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "dataManip/Command.hpp"

#include "TBSW0044.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0044Loader();

    class TBSW0044Loader : public dataManip::Command
    {
        public:

            TBSW0044Loader();
            TBSW0044Loader( const std::string& str );
            virtual ~TBSW0044Loader();

            bool init();
            void finish();
            int execute( bool& a_stop );
            dataManip::Command* clone() const;

            TBSW0044Loader& setTargetFieldPath( const std::string& a_path );
            TBSW0044Loader& setSourceFieldPath( const std::string& a_path );
            TBSW0044Loader& setLocalFieldPath( const std::string& a_path );

        private:

            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::FieldAccess m_num_pdv;
            fieldSet::FieldAccess m_num_bin_ini;
            fieldSet::FieldAccess m_num_bin_fim;
            fieldSet::FieldAccess m_cod_emsr;
            fieldSet::FieldAccess m_cod_sttu_tran;
            fieldSet::FieldAccess m_dat_atlz_reg;
            fieldSet::FieldAccess m_cod_usr_atlz_reg;
            fieldSet::FieldAccess m_ind_sttu_reg;
            fieldSet::FieldAccess m_termloc;
            fieldSet::FieldAccess m_pan;
    };
}
