#pragma once

#include <TBSW0153RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0153RegrasFormatacao : public TBSW0153RegrasFormatacaoBase
    {
        public:
            TBSW0153RegrasFormatacao( );
            ~TBSW0153RegrasFormatacao( );
			void update_VAL_EFTV_APRV( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
            void update_IND_VAL_APR_SLDO_DSPL( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
    };
}