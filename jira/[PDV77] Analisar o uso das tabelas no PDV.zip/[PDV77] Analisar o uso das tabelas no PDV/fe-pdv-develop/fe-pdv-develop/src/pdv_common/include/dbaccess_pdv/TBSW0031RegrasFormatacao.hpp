#pragma once

#include <TBSW0031RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0031RegrasFormatacao : public TBSW0031RegrasFormatacaoBase
    {
        public:
            TBSW0031RegrasFormatacao( );
            ~TBSW0031RegrasFormatacao( );
    };
}
