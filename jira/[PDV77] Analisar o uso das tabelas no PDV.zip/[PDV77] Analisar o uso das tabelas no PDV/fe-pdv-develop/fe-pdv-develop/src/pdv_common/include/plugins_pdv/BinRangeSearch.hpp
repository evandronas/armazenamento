/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Teller
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t689064, Raphael Teller, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <deque>
#include "plugins_pdv/Range.hpp"


namespace plugins_pdv
{
	class BinRangeSearch
	{
	public:
		BinRangeSearch();
		virtual ~BinRangeSearch();
	
		bool init();
		Range findRange( unsigned long a_bin );

		typedef std::deque<Range> RANGE_DEQUE;
		RANGE_DEQUE m_rangeDeque;

	private:
		class RangeComparator
		{
		public:
			bool operator()( const Range& a_first, const Range& a_second )
			{
				bool l_ret = a_first.getNUM_BIN_CAR_INI() < a_second.getNUM_BIN_CAR_INI();
				return l_ret;
			}
		};

		class PriorityComparator
		{
		public:
			bool operator()( const Range& a_first, const Range& a_second )
			{
				bool l_ret = a_first.getIND_PRRD() < a_second.getIND_PRRD();
				return l_ret;
			}
		};

		bool pickQualifiedRanges( unsigned long a_bin );
		void sortQualifiedRanges();

		RANGE_DEQUE m_qualifiedRanges;

		RangeComparator m_rangeComparator;
		PriorityComparator m_priorityComparator;
	};
}

