/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0058Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0058Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, CKen>
/ Data de Cria��o: <Thu Oct 18 19:28:59 2012>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ <22.09.2013, FEPOS, t694449, Fernando Ramires, Merge do PDV para o POS>
/ <11.11.2013, FEPOS, t694449, Fernando Ramires, GAP3 Inclusao de novo campo>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0058Loader( );
    
    class TBSW0058Loader : public dataManip::Command
    {
        public:
            
            enum tableFields
            { 
                RESULT,
                DAT_MOV_TRAN,
                NUM_SEQ_UNC,
                TIP_TRAN,
                NUM_MOT_RSPS,
                NUM_ESTB,
                COD_TERM,
                NUM_RD_ORG,
                COD_POS_ENTR_MODO,
                COD_EMSR,
                VAL_TRAN,
                COD_RAM_ATVD,
                NUM_CAR,
                NUM_AUT,
                VAL_COT_DLR,
                DAT_VLD_CAR,
                COD_TRK_CAR,
                COD_MOED,
                COD_PAIS_CAR,
                COD_SERV_SNHA,
                IND_RD_ORG,
                COD_MOT_AUT,
                DAT_PAUZ,
                COD_GRU_ESTB,
                COD_MTZ_ESTB,
                DTH_INI_TRAN,
                DTH_STTU_TRAN,
                DTH_GMT,
                NUM_STAN,
                VAL_EFTV_CPTR,
                QTD_PRCL_CNFR,
                IND_RD_CPTR,
                COD_CNDC_CPTR,
                DAT_CNFR_PAUZ,
                VAL_TRAN_DLR,
                DAT_CAN_PAUZ,
                DAT_VLD_PAUZ,
                NOM_PORT_CAR,
                COD_MSG_ISO,
                COD_PCM_ISO,
                NOM_SITE_ACQR_ORGL,
                NOM_HOST_ACQR_ORGL,
                NOM_FE_ACQR_ORGL,
                NOM_SITE_ISSR,
                NOM_HOST_ISSR,
                NOM_FE_ISSR,
                NOM_SITE_ACQR_ATLZ,
                NOM_HOST_ACQR_ATLZ,
                NOM_FE_ACQR_ATLZ,
                COD_MOT_ISO_EMSR,
                COD_TERM_CNFR,
                DAT_MOV_TRAN_CNFR,
                DTH_CNFR,
                IND_RD_ORG_ESTR,
                IND_STTU_TRAN,
                NUM_EMSR,
                NUM_ESTB_CNFR,
                NUM_ESTB_ESTR,
                NUM_ID_CAR,
                NUM_SEQ_UNC_CNFR,
                NUM_STAN_ORGL,
                COD_BNDR,
                IND_EMSR_MTC,
                NUM_AVSO_AUT,
                TXT_DA_ADIC_EMSR,
                NOM_FNTS_PDV,
                COD_PGM_AUT,
                IND_NVL_SGRA_KMRC,
                COD_UCAF,
                COD_AUT_EMSR_CNVT,
                COD_AUT_EMSR,
                NTWK_ID_ACQR_ATLZ,
                NTWK_ID_ACQR_ORGL,
                NTWK_ID_ROUTE_ATLZ,
                NTWK_ID_ROUTE_ORGL,
                NTWK_ID_ISSR_ATLZ,
                NTWK_ID_ISSR_ORGL,
                //IND_CPTRDO,   // 12.11.2013 - Removido no GAP3
                //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
                COD_CTAH_VOCH,
                //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//
                COD_TIP_PROD_CAR,
                NUM_REF_TRAN,
                COD_CPCD_TERM,
                IND_TRAN_TKN,
                COD_ORG_APRV,
                COD_PROD_MTC, 
                COD_RGAO_MTC,
                // Release Bandeiras PDV - Abril 2019 - INICIO
                COD_PORT_PRES_VLDC_BNDR,
                COD_CPCD_TERM_VLDC_BNDR,
                // Release Bandeiras PDV - Abril 2019 - FIM
                LAST_TB_FIELD
            };
            
            enum sourceFields
            {
                LOCAL_DATE,
                LOCAL_TIME,
                REFNUM,
                MSGTYPE,
                PAN,
                ACQ_CURRENCY_CODE,
                AUTHNUM,
                AMOUNT,
                TERMLOC,
                ORIGDATE,
                ORIGTIME,
                ORIGTRACE,
                TRANDATE,
                TRANTIME,
                ORIGREFNUM,
                ORIG_AUTHNUM,
                ORIG_PAN,
                IS_3A_PERNA,
                COD_MTZ,
				IS_DESF_CONF,
				// cr689721@FIS - Data: 21/10/2014 - Ref. Atualiza��o para Estorno e Desfazimento de Confirma��o.
				TRANSCODE,
				NUM_SEQ_UNC_PAUZ,
                DATE_MOV_TRAN_PAUZ,
                MSG_NAME,
                INSTALL_NUM,
                VERSAO_APLICATIVO,
                COD_TERMN,
                LAST_SOURCE_FIELD
            };
             
            TBSW0058Loader( );
            TBSW0058Loader( const std::string& str );
            virtual ~TBSW0058Loader( );
            
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            
            std::string getResult( );
            
            TBSW0058Loader& setResult( const std::string& a_status );
            TBSW0058Loader& setTargetFieldPath( const std::string& a_path );
            TBSW0058Loader& setSourceFieldPath( const std::string& a_path );
            
        private:
            
            bool startConfiguration( const configBase::Tag* a_tag );
            
            fieldSet::FieldAccess m_targetField[ LAST_TB_FIELD ];
            fieldSet::FieldAccess m_sourceField[ LAST_SOURCE_FIELD ];
            
            std::string m_targetFieldPath;
            std::string m_sourceFieldPath;
            std::string m_result;
    };
}


