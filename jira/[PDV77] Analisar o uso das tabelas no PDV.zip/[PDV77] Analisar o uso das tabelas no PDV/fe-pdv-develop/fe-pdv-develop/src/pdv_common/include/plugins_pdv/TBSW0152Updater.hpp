#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0152Updater( );
    class TBSW0152Updater : public dataManip::Command
    {
        public:
            TBSW0152Updater( );
            TBSW0152Updater( const std::string& str );
            virtual ~TBSW0152Updater( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            TBSW0152Updater& setTargetFieldPath( const std::string& a_path );
            TBSW0152Updater& setSourceFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_origrefnum;
            fieldSet::ConstFieldAccess m_orig_local_date;
            fieldSet::ConstFieldAccess m_install_amt;
            fieldSet::ConstFieldAccess m_applied_fee;
            fieldSet::ConstFieldAccess m_fee;
            fieldSet::ConstFieldAccess m_status;
            fieldSet::ConstFieldAccess m_msg_name;
            fieldSet::ConstFieldAccess m_iss_name;
			fieldSet::ConstFieldAccess m_amount;
			fieldSet::ConstFieldAccess m_install_num;

            std::string m_targetFieldPath;
            std::string m_sourceFieldPath;
    };
}
