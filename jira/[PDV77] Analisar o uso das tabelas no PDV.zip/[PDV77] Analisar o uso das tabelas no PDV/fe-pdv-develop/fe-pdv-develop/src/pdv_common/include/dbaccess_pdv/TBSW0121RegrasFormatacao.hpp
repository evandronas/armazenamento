#pragma once

#include <TBSW0121RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0121RegrasFormatacao : public TBSW0121RegrasFormatacaoBase
    {
        public:
            TBSW0121RegrasFormatacao( );
            ~TBSW0121RegrasFormatacao( );
            void insert_COD_MODL_PNPD( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
            void insert_COD_VERS_CHCK_PDV( dbaccess_common::TBSW0121 &tbsw0121, const struct acq_common::tbsw0121_params &params );
    };
}