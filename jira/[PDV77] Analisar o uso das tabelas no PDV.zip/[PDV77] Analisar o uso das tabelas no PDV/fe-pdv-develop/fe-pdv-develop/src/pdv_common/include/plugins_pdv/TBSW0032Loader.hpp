#pragma once
#include "TBSW0032.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0032Loader();

    class TBSW0032Loader : public dataManip::Command
    {
        public:
            TBSW0032Loader();
            virtual ~TBSW0032Loader();

            bool init();
            void finish();
            int execute( bool& a_stop );
            dataManip::Command* clone() const;

            TBSW0032Loader& setSourceFieldPath( const std::string& a_path );
            TBSW0032Loader& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess m_result;
            fieldSet::FieldAccess m_num_bco_deb;
            fieldSet::FieldAccess m_num_emsr;
            fieldSet::FieldAccess m_num_bco_estb;
            fieldSet::FieldAccess m_num_age_estb;
            fieldSet::FieldAccess m_cod_cta_estb;
            fieldSet::FieldAccess m_cod_vd_bco;
            fieldSet::FieldAccess m_ind_cnfr_pstv;
            fieldSet::FieldAccess m_val_sque;
            fieldSet::FieldAccess m_ind_impr_cpom;
            fieldSet::FieldAccess m_dat_mov_tran;
            fieldSet::FieldAccess m_num_seq_unc;
            fieldSet::FieldAccess m_qtd_dia_crnc;
            fieldSet::FieldAccess m_ind_car_mltp;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_origrefnum;
            fieldSet::ConstFieldAccess m_origdate;
    };
}
