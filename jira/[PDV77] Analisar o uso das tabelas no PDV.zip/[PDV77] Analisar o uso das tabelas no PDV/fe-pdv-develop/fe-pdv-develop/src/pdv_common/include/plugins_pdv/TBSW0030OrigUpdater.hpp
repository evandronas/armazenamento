#pragma once

#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0030OrigUpdater( );
    
    class TBSW0030OrigUpdater : public dataManip::Command
    {
        public:
            
            TBSW0030OrigUpdater( );
            virtual ~TBSW0030OrigUpdater( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            
            TBSW0030OrigUpdater& setSourceFieldPath( const std::string& a_path );
            TBSW0030OrigUpdater& setTargetFieldPath( const std::string& a_path );
            TBSW0030OrigUpdater& setLocalFieldPath( const std::string& a_path );
            
        private:
            
            bool startConfiguration( const configBase::Tag* a_tag );
        
            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;
            
            fieldSet::FieldAccess m_result;   
            
            fieldSet::ConstFieldAccess m_cod_ntwk_id_rout_atlz;
            
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_orig_local_date;
            fieldSet::ConstFieldAccess m_origrefnum;
            fieldSet::ConstFieldAccess m_is_reversal;
            fieldSet::ConstFieldAccess m_is_void;
            fieldSet::ConstFieldAccess m_issuer;
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_local_time;
            fieldSet::ConstFieldAccess m_msg_category;
            fieldSet::ConstFieldAccess m_status_trn_orig;
            fieldSet::ConstFieldAccess m_msg_name;
    };
}
