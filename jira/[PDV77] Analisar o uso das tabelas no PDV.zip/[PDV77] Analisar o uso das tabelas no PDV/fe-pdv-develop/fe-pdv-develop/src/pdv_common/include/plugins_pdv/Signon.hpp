/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::Signon>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::Signon>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689068, Jos� Augusto T. Gavazza>
/ Data de Cria��o: <2013, 04 de Fevereiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <dbm.h>
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createSignon( );

    class Signon : public dataManip::Command
    {
    public:
        Signon();
        virtual ~Signon();        
        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;    
        Signon& setShcMsgFieldPath( const std::string& a_path );
        Signon& setTargetFieldPath( const std::string& a_path );
        Signon& setSignonFieldPath( const std::string& a_path );
    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        std::string m_shcmsgFieldPath;
        std::string m_targetFieldPath;
        std::string m_signonFieldPath;
        fieldSet::FieldAccess m_de48;
        fieldSet::FieldAccess m_de48Len;
        fieldSet::FieldAccess m_ecrInitDir;
        fieldSet::FieldAccess m_ecrInitDirTmp;
        fieldSet::FieldAccess m_result;
        fieldSet::ConstFieldAccess m_verid;
        fieldSet::ConstFieldAccess m_termloc;
        fieldSet::ConstFieldAccess m_termid;
    };
}
   
