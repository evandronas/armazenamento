/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0033Inserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0033Inserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>
/ Data de Cria��o: <2013, 18 de Janeiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0033Inserter();

    class TBSW0033Inserter : public dataManip::Command
    {
        public:
                TBSW0033Inserter();
            virtual ~TBSW0033Inserter();
        
            bool init();
            void finish();
            int execute( bool& a_stop );
            dataManip::Command* clone() const;
        
            TBSW0033Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0033Inserter& setTargetFieldPath( const std::string& a_path );
            TBSW0033Inserter& setLocalFieldPath ( const std::string& a_path );
        
        private:
            bool startConfiguration( const configBase::Tag* a_tag );
        
            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;
        
            fieldSet::FieldAccess m_result;
        
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_local_time;
            
            fieldSet::ConstFieldAccess m_refnum; 
            fieldSet::ConstFieldAccess mensagemCategoria;  
            fieldSet::ConstFieldAccess nomeMensagem; 
            
            //Campos TXT1
            fieldSet::ConstFieldAccess trace;
            fieldSet::ConstFieldAccess mensagemOriginal;
            fieldSet::ConstFieldAccess traceOriginal;
            fieldSet::ConstFieldAccess dataOriginal;
            fieldSet::ConstFieldAccess horaOriginal;
            fieldSet::ConstFieldAccess dataLocalOriginal;
            fieldSet::ConstFieldAccess horaLocalOriginal;
            fieldSet::ConstFieldAccess nomeEmissor;
            fieldSet::ConstFieldAccess cartao;
            
            //Campos TXT2
            fieldSet::ConstFieldAccess m_cd_tpo_trm;
            fieldSet::ConstFieldAccess m_load_program;
            fieldSet::ConstFieldAccess m_load_init;
            fieldSet::ConstFieldAccess m_nu_age_etb;
            fieldSet::ConstFieldAccess m_cd_cta_etb;
            fieldSet::ConstFieldAccess m_in_tpo_tcn;
            fieldSet::ConstFieldAccess m_indUtlzPnpd;
        
            fieldSet::ConstFieldAccess m_nu_rv;
            fieldSet::ConstFieldAccess m_dt_rv;
            
            fieldSet::ConstFieldAccess enderecoFantasia;
            fieldSet::ConstFieldAccess cpf;
    };
}

