#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0087Loader( );
	class TBSW0087Loader : public dataManip::Command
	{
	public:
		enum tableFields
		{
			RESULT, NUM_PRFX_CAR, COD_SGL_PAI, COD_STTU_REG, DAT_ATLZ_REG, LAST_TB_FIELD
		};
		enum sourceFields
		{
			BIN, LAST_SOURCE_FIELD
		};
		TBSW0087Loader( );
		TBSW0087Loader( const std::string &str );
		virtual ~TBSW0087Loader( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		TBSW0087Loader& setSourceFieldPath( const std::string& a_path );
		TBSW0087Loader& setTargetFieldPath( const std::string& a_path );
		TBSW0087Loader& setResult( const std::string& a_result );
		std::string getResult( );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_targetField[LAST_TB_FIELD];
		fieldSet::FieldAccess m_sourceField[LAST_SOURCE_FIELD];
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_result;
	};
}

