#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "plugins_pdv/BinRangeSearch.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTrxVoucherRouting( );
    class TrxVoucherRouting : public dataManip::Command
    {
    public:
        TrxVoucherRouting( );
        TrxVoucherRouting( const std::string &str );
        virtual ~TrxVoucherRouting( );

        bool init( );
        void finish( );
        int execute( bool& a_stop );
        dataManip::Command* clone( ) const;

    private:
        bool startConfiguration( const configBase::Tag* a_tag );

        fieldSet::ConstFieldAccess m_bin;
        fieldSet::ConstFieldAccess m_cod_issuer_sw;
        fieldSet::ConstFieldAccess m_track2;
        fieldSet::ConstFieldAccess pan;
        fieldSet::ConstFieldAccess categoriaMensagem;
        fieldSet::ConstFieldAccess numeroRoteador;

        fieldSet::FieldAccess m_cod_sttu_reg;
        fieldSet::FieldAccess m_num_rtdr;
        fieldSet::FieldAccess m_cod_sbpd;
        fieldSet::FieldAccess m_cod_emsr;
        fieldSet::FieldAccess m_nom_emsr;
        fieldSet::FieldAccess m_cod_tran_ge;
        fieldSet::FieldAccess m_nom_prod_cpom;
        fieldSet::FieldAccess m_txt_rdpe_cpom;
        fieldSet::FieldAccess m_cod_usr_atlz_reg;
        fieldSet::FieldAccess m_dat_atlz_reg;
        fieldSet::FieldAccess m_dat_atvc_voch;
        fieldSet::FieldAccess m_ntwkid;
        fieldSet::FieldAccess m_num_bin;

        fieldSet::FieldAccess m_cod_issr_sw;
        fieldSet::FieldAccess m_nom_emsr_sw;
        fieldSet::FieldAccess m_cod_emsr_sw;
        fieldSet::FieldAccess m_cod_bndr;
        fieldSet::FieldAccess m_cod_fe_emsr;

        fieldSet::FieldAccess m_result;

        std::string m_sourceFieldPath;
        std::string m_targetFieldPath;
        std::string localFieldPath;
        std::string m_binPath;

        BinRangeSearch m_binRangeSearch;
    };
}
