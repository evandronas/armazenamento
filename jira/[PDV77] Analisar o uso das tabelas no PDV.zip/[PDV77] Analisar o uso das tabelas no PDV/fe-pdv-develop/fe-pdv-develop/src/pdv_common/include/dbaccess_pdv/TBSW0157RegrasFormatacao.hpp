#pragma once

#include<TBSW0157RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0157RegrasFormatacao : public TBSW0157RegrasFormatacaoBase
    {
        public:
            TBSW0157RegrasFormatacao( );
            ~TBSW0157RegrasFormatacao( );
            
    };
}