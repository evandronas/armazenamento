/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include "TBSW0102.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTbsw0102Inserter( );

    class Tbsw0102Inserter : public dataManip::Command
    {
        public:
            Tbsw0102Inserter( );
            virtual ~Tbsw0102Inserter( );

            bool init( );
            void finish( );
            int execute( bool& stopParametro );
            dataManip::Command* clone( ) const;

            Tbsw0102Inserter& SetSourceFieldPath( const std::string& pathParametro );
            Tbsw0102Inserter& SetTargetFieldPath( const std::string& pathParametro );

        private:
            bool startConfiguration( const configBase::Tag* tagParametro );

            std::string sourceFieldPath;
            std::string targetFieldPath;

            fieldSet::FieldAccess result;

            fieldSet::ConstFieldAccess localDate;                /// shc_msg.local_date
            fieldSet::ConstFieldAccess refnum;                   /// shc_msg.refnum
            fieldSet::ConstFieldAccess tokenAssuranceLevel;      /// segments.common.tokenAssuranceLevel
            fieldSet::ConstFieldAccess paymentAccountReference;  /// segments.common.paymentAccountReference
    }; // class Tbsw0102Inserter
} // namespace plugins_pdv
