#pragma once
#include "TBSW0035.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0035Inserter();

    class TBSW0035Inserter : public dataManip::Command
    {
        public:
            TBSW0035Inserter( );
            virtual ~TBSW0035Inserter( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0035Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0035Inserter& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_num_bxa_tec;
            fieldSet::ConstFieldAccess m_in_tpo_tcn;
            fieldSet::ConstFieldAccess m_termloc;
            fieldSet::ConstFieldAccess m_termid;
            fieldSet::ConstFieldAccess m_num_sre_term;
            fieldSet::ConstFieldAccess m_num_sre_pnpd_ext;
            fieldSet::ConstFieldAccess m_cod_id_pnpd;
            fieldSet::ConstFieldAccess m_cod_aplv_pnpd;
            fieldSet::ConstFieldAccess m_cod_vers_sftw;
            fieldSet::ConstFieldAccess m_nom_modl_chip;
            fieldSet::ConstFieldAccess m_num_sre_smcrd;
            fieldSet::ConstFieldAccess m_nom_oper;
            fieldSet::ConstFieldAccess m_cod_ip_prmi;
            fieldSet::ConstFieldAccess m_num_prta_prmi;
            fieldSet::ConstFieldAccess m_cod_ip_secd;
            fieldSet::ConstFieldAccess m_num_prta_secd;
            fieldSet::ConstFieldAccess m_nom_url_cnfr;
            fieldSet::ConstFieldAccess m_qtd_tran_gprs_prmi;
            fieldSet::ConstFieldAccess m_qtd_tran_gsm_prmi;
            fieldSet::ConstFieldAccess m_qtd_tran_gprs_secd;
            fieldSet::ConstFieldAccess m_qtd_tran_gsm_secd;
            fieldSet::ConstFieldAccess m_qtd_tnta_prmi;
            fieldSet::ConstFieldAccess m_qtd_tnta_secd;
			
			// t689049
			fieldSet::ConstFieldAccess m_bit63;

    }; // class TBSW0035Inserter

} // namespace plugins_pdv

