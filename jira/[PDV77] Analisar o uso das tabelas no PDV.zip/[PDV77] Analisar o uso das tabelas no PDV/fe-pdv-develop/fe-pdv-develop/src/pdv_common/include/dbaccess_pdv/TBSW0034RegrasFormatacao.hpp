#pragma once

#include<TBSW0034RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
	class TBSW0034RegrasFormatacao : public TBSW0034RegrasFormatacaoBase
	{
	public:
		TBSW0034RegrasFormatacao( );
		~TBSW0034RegrasFormatacao( );
	};
}