#pragma once
#include "TBSW0153.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0153Updater( );

    class TBSW0153Updater : public dataManip::Command
    {
        public:
            TBSW0153Updater( );
            virtual ~TBSW0153Updater( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0153Updater& setSourceFieldPath( const std::string& a_path );
            TBSW0153Updater& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_pb_reason_code;
            fieldSet::ConstFieldAccess m_aval_balance;
            fieldSet::ConstFieldAccess modoEntrada;
            fieldSet::ConstFieldAccess respcode;
    }; // class TBSW0153Updater
} // namespace plugins_pdv
