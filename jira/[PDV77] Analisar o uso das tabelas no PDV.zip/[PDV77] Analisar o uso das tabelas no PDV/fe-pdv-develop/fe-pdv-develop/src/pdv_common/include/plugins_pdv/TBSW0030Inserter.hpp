#pragma once

#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0030Inserter( );
    
    class TBSW0030Inserter : public dataManip::Command
    {
        public:
            
            TBSW0030Inserter( );
            virtual ~TBSW0030Inserter( );
            
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            
            TBSW0030Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0030Inserter& setTargetFieldPath( const std::string& a_path );
            TBSW0030Inserter& setLocalFieldPath( const std::string& a_path );
            
        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;
            
            fieldSet::FieldAccess m_result;
            
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_pcode;
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_transcode;
            fieldSet::ConstFieldAccess m_termloc;
            fieldSet::ConstFieldAccess m_termid;
            fieldSet::ConstFieldAccess m_status;
            fieldSet::ConstFieldAccess m_pos_entry_code;
            fieldSet::ConstFieldAccess m_cd_ems;
            fieldSet::ConstFieldAccess m_amount;
            fieldSet::ConstFieldAccess m_mer_cat_code;
            fieldSet::ConstFieldAccess m_orig_pan;
            fieldSet::ConstFieldAccess m_expiry_date;
            fieldSet::ConstFieldAccess m_bin;
            fieldSet::ConstFieldAccess m_cod_bndr;
            fieldSet::ConstFieldAccess m_is_reversal;
            fieldSet::ConstFieldAccess m_is_void;
            fieldSet::ConstFieldAccess m_local_time;
            fieldSet::ConstFieldAccess m_trace;
            fieldSet::ConstFieldAccess m_in_tpo_tcn;
            fieldSet::ConstFieldAccess m_cd_tpo_trm;
            fieldSet::ConstFieldAccess m_track2;
            fieldSet::ConstFieldAccess m_cvv2;
            fieldSet::ConstFieldAccess m_cod_mtv_sw;
            fieldSet::ConstFieldAccess m_orig_transcode;
            fieldSet::ConstFieldAccess m_subtranscode;
            fieldSet::ConstFieldAccess m_service_code;
            fieldSet::ConstFieldAccess m_track3;
            fieldSet::ConstFieldAccess m_is_van;
            fieldSet::ConstFieldAccess m_acceptorname;
            fieldSet::ConstFieldAccess m_tip_dtlh_tran;
            fieldSet::ConstFieldAccess m_is_cod_serv_trk_car;
            fieldSet::ConstFieldAccess m_num_rsmo_vd;
            fieldSet::ConstFieldAccess m_dat_rsmo_vd;
            fieldSet::ConstFieldAccess m_cod_item;
            fieldSet::ConstFieldAccess m_origrefnum;
            fieldSet::ConstFieldAccess m_issuer;
            fieldSet::ConstFieldAccess m_ind_tran_refd;
            fieldSet::ConstFieldAccess m_pb_reason_code;
            fieldSet::ConstFieldAccess m_receive_inst_id;
            fieldSet::ConstFieldAccess m_codTranCad;
            fieldSet::ConstFieldAccess m_cod_cndc_cptr_pauz;
            fieldSet::ConstFieldAccess m_tip_ent_pauz;
            fieldSet::ConstFieldAccess m_cod_mot_aut_pauz;
            fieldSet::ConstFieldAccess m_dat_pauz;
            fieldSet::ConstFieldAccess m_local_cod_sgl_pai;
            fieldSet::ConstFieldAccess m_merchant_type;
            fieldSet::ConstFieldAccess m_cd_ctg_trx;
            fieldSet::ConstFieldAccess m_l_cod_serv_senha;
            fieldSet::ConstFieldAccess m_l_cod_serv;
            fieldSet::ConstFieldAccess m_value_cod_serv_trk_car;
            fieldSet::ConstFieldAccess m_chip_full_data_len;
            fieldSet::ConstFieldAccess m_l_cod_trk_car;
            fieldSet::ConstFieldAccess m_l_ind_trk;
            fieldSet::ConstFieldAccess m_ind_term_ltro_chip;
            fieldSet::ConstFieldAccess m_local_num_car;
            fieldSet::ConstFieldAccess m_dat_pauz_time;
            fieldSet::ConstFieldAccess m_iss_name;
            fieldSet::ConstFieldAccess m_msg_category;
            fieldSet::ConstFieldAccess m_acq_name;
            fieldSet::ConstFieldAccess m_msg_name;
            fieldSet::ConstFieldAccess m_is_pre_auth;
            fieldSet::ConstFieldAccess m_origtrace;
            fieldSet::ConstFieldAccess m_plano_pagamento;
            fieldSet::ConstFieldAccess m_has_pin;
            fieldSet::ConstFieldAccess m_trandate;
            fieldSet::ConstFieldAccess m_trantime;
            fieldSet::ConstFieldAccess m_cod_cndc_cptr;
            fieldSet::ConstFieldAccess m_trn_tem_original;
            fieldSet::ConstFieldAccess m_ind_pagt_fatura;
            fieldSet::ConstFieldAccess m_ecr_sftw_verid;
            fieldSet::ConstFieldAccess m_mer_name;
            fieldSet::ConstFieldAccess m_mer_city;
            fieldSet::ConstFieldAccess m_form_factor;
            fieldSet::ConstFieldAccess m_cod_service;
            fieldSet::ConstFieldAccess m_is_nfc;
            fieldSet::ConstFieldAccess m_common_vl_txa;
            fieldSet::ConstFieldAccess m_cod_mot_rsps_ext;
            fieldSet::ConstFieldAccess m_is_desfaz_estorno;
            fieldSet::ConstFieldAccess m_cod_gru_clas_ram;
            fieldSet::ConstFieldAccess m_orig_ind_da_rlcd_chip;
            fieldSet::ConstFieldAccess m_ind_da_rlcd_iata;
            fieldSet::ConstFieldAccess m_cod_prod_cdst;
            fieldSet::ConstFieldAccess tokenIdentifier;  // Apartir deste ponto segue padrao novo
            fieldSet::ConstFieldAccess codigoOrigemRespostaAutorizacao;
            // Release Bandeiras PDV - Abril 2019 - INICIO
            fieldSet::ConstFieldAccess indicadorModoEntrada;
            fieldSet::ConstFieldAccess indicadorPresencaPortador;
            fieldSet::ConstFieldAccess indicadorTecnologiaTerminal;
            // Release Bandeiras PDV - Abril 2019 - FIM
            // BRUM - EAK-1657 - 27/08/2019 - MCC Dinamico - Inicio
            fieldSet::ConstFieldAccess merchantCategoryCodeSubLojista;
            // BRUM - EAK-1657 - Fim
            fieldSet::ConstFieldAccess indicadorTrilha3Len;
            fieldSet::ConstFieldAccess codigoRoteamentoTransacao;
    };
}

