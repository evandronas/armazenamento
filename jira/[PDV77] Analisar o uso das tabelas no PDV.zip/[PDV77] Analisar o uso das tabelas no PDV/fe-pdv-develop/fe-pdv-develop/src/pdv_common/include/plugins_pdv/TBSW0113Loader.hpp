/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0113Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0113Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <698224, Raphael Ferreira Gomes>
/ Data de Cria��o: <2013, 21 de Fevereiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "TBSW0113.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0113Loader();

    class TBSW0113Loader : public dataManip::Command
    {
    public:
    TBSW0113Loader();
        virtual ~TBSW0113Loader();

        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;

        TBSW0113Loader& setSourceFieldPath( const std::string& a_path );
        TBSW0113Loader& setTargetFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );

        std::string m_sourceFieldPath;
        std::string m_targetFieldPath;

        fieldSet::FieldAccess m_result;

        fieldSet::FieldAccess m_cod_sttu_reg;
        fieldSet::FieldAccess m_num_rtdr;
        fieldSet::FieldAccess m_cod_sbpd;
        fieldSet::FieldAccess m_cod_emsr;
        fieldSet::FieldAccess m_nom_emsr;
        fieldSet::FieldAccess m_cod_tran_ge;
        fieldSet::FieldAccess m_nom_prod_cpom;
        fieldSet::FieldAccess m_txt_rdpe_cpom;
        fieldSet::FieldAccess m_cod_usr_atlz_reg;
        fieldSet::FieldAccess m_dat_atlz_reg;
        fieldSet::FieldAccess m_dat_atvc_voch;
        fieldSet::FieldAccess m_ntwkid;
        fieldSet::FieldAccess m_num_bin;

        fieldSet::ConstFieldAccess m_bin;
        fieldSet::ConstFieldAccess m_msgtype;
        fieldSet::ConstFieldAccess m_track2;
        fieldSet::ConstFieldAccess m_is_3a_perna;

    };
}
