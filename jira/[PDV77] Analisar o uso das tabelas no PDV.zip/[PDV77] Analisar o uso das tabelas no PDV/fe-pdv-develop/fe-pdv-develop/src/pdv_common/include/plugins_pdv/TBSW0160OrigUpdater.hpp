#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0160OrigUpdater();

	class TBSW0160OrigUpdater : public dataManip::Command
	{
	public:
        TBSW0160OrigUpdater();
		virtual ~TBSW0160OrigUpdater();
		bool init();
		void finish();
		int execute( bool& a_stop );
		dataManip::Command* clone() const;
		TBSW0160OrigUpdater& setSourceFieldPath( const std::string& a_path );
		TBSW0160OrigUpdater& setTargetFieldPath( const std::string& a_path );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;		
		fieldSet::FieldAccess m_result;
		fieldSet::FieldAccess m_refnum;
        fieldSet::FieldAccess m_msg_name; 
        fieldSet::FieldAccess m_orig_local_date;        
        fieldSet::FieldAccess m_origrefnum;
    };
}

