/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTbsw0034Loader();

    class Tbsw0034Loader : public dataManip::Command
    {
    public:
        Tbsw0034Loader();
        Tbsw0034Loader( const std::string& str );
        virtual ~Tbsw0034Loader();

        bool init();
        void finish();
        int execute( bool& stopParametro );
        dataManip::Command* clone() const;

        Tbsw0034Loader& SetTargetFieldPath( const std::string& pathParametro );
        Tbsw0034Loader& SetSourceFieldPath( const std::string& pathParametro );

    private:
        bool startConfiguration( const configBase::Tag* tagParametro );

        std::string sourceFieldPath;
        std::string targetFieldPath;

        fieldSet::FieldAccess result;
        fieldSet::FieldAccess textoRelacionadoChip;                 /// TXT_RLCD_CHIP : TEXTO_RELACIONADO_CHIP
        fieldSet::FieldAccess textoInformacaoComplementarChip;      /// TXT_INFO_CMPM_CHIP : TEXTO_INFORMACAO_COMPLEMENTAR_CHIP
        fieldSet::FieldAccess textoResultadoAtualizacaoChip;        /// TXT_RSTD_ATLZ_CHIP : TEXTO_RESULTADO_ATUALIZACAO_CHIP
        fieldSet::FieldAccess indicadorNivelSegurancaKomerci;       /// IND_NVL_SGRA_KMRC : INDICADOR_NIVEL_SEGURANÇA_KOMERCI
        fieldSet::FieldAccess dataMovimentoTransacao;               /// DAT_MOV_TRAN : DATA_MOVIMENTO_TRANSACAO
        fieldSet::FieldAccess numeroSequencialUnico;                /// NUM_SEQ_UNC : NUMERO_SEQUENCIAL_UNICO
        fieldSet::FieldAccess dataVendaChip;                        /// DAT_VD_CHIP : DATA_VENDA_CHIP
        fieldSet::FieldAccess codigoProgramaAutorizacao;            /// COD_PGM_AUT : CODIGO_PROGRAMA_AUTORIZACAO
        fieldSet::FieldAccess indicadorMetodoVerificacaoPortador;   /// IND_MTDO_VRFC_PORT : INDICADOR_METODO_VERIFICACAO_PORTADOR
        fieldSet::FieldAccess indicadorPresencaSenha;               /// IND_PRSC_SNHA : INDICADOR_PRESENCA_SENHA
        fieldSet::FieldAccess numeroSequencialCartaoValidacaoChip;  /// NUM_SEQ_CAR_VLDC_CHIP : NUMERO_SEQUENCIAL_CARTAO_VALIDACAO_CHIP
        fieldSet::FieldAccess nomePortadorCartao;                   /// NOM_PORT_CAR : NOME_PORTADOR_CARTAO

        fieldSet::ConstFieldAccess origRefnum;   /// segments.common.origrefnum
        fieldSet::ConstFieldAccess origDate;     /// shc_msg.origdate
		
    };
}
