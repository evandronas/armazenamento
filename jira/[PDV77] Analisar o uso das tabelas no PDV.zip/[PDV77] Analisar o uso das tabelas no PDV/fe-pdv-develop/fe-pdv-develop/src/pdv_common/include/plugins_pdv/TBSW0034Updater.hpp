/*
/ -------------------------------------------------------------------------
/ Sigla: fepdv
/ Descri��o: 
/ Conte�do: 
/ Autor: 689066, Alexandre T. Guimaraes
/ Data de Cria��o: 2013, 04 de Setembro
/ Hist�rico Mudan�as: 2013, 04 de Setembro, Alexandre, Primeira versao
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "acq_common/TBSW0034.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0034Updater();

	class TBSW0034Updater : public dataManip::Command
	{
	public:
        TBSW0034Updater();
		virtual ~TBSW0034Updater();
		bool init();
		void finish();
		int execute( bool& a_stop );
		dataManip::Command* clone() const;
		TBSW0034Updater& setSourceFieldPath( const std::string& a_path );
		TBSW0034Updater& setTargetFieldPath( const std::string& a_path );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );
        bool validateDateNSU(std::string nsu, unsigned long date);

		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;		
		fieldSet::FieldAccess m_result;
		fieldSet::FieldAccess m_txt_info_cmpm_chip;
        fieldSet::FieldAccess m_txt_rstd_atlz_chip;        
		fieldSet::ConstFieldAccess m_isr_date;
		fieldSet::ConstFieldAccess m_isr_nsu;
		fieldSet::ConstFieldAccess m_2ndGAC_date;
		fieldSet::ConstFieldAccess m_2ndGAC_nsu;        
    };
}

