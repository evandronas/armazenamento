#pragma once
#include "TBSW0084.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dataManip/Command.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0084Loader();

    class TBSW0084Loader : public dataManip::Command
    {
        public:
            TBSW0084Loader();
            TBSW0084Loader( const std::string& str );
            virtual ~TBSW0084Loader();

            bool init();
            void finish();
            int execute( bool& a_stop );
            dataManip::Command* clone() const;

            TBSW0084Loader& setTargetFieldPath( const std::string& a_path );
            TBSW0084Loader& setSourceFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );
            std::string m_targetFieldPath;
            std::string m_sourceFieldPath;

            fieldSet::FieldAccess m_result;
            fieldSet::FieldAccess m_dat_mov_tran;
            fieldSet::FieldAccess m_cod_term;
            fieldSet::FieldAccess m_num_stan;
            fieldSet::FieldAccess m_dth_ini_tran;
            fieldSet::FieldAccess m_num_estb;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_terminal_pdv;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_origrefnum;

            fieldSet::FieldAccess m_cod_pnpd_pdv;
            fieldSet::FieldAccess m_nom_fbrc_pnpd;
            fieldSet::FieldAccess m_num_sre_pnpd;
            fieldSet::FieldAccess m_cod_vers_hdw_pnpd;
            fieldSet::FieldAccess m_cod_vers_frwr_pnpd;
            fieldSet::FieldAccess m_nom_fbrc_tef;
            fieldSet::FieldAccess m_cod_vers_sftw_tef;
            fieldSet::FieldAccess m_nom_fbrc_atmc;
            fieldSet::FieldAccess m_cod_vers_sftw_atmc;
            fieldSet::FieldAccess m_qtd_leit_magn;
            fieldSet::FieldAccess m_qtd_err_leit_magn;
            fieldSet::FieldAccess m_qtd_snha_magn;
            fieldSet::FieldAccess m_qtd_err_snha_magn;
            fieldSet::FieldAccess m_qtd_snha_chip_onln;
            fieldSet::FieldAccess m_qtd_err_snha_chip_onln;
            fieldSet::FieldAccess m_qtd_snha_chip_ofln;
            fieldSet::FieldAccess m_qtd_err_snha_chip_ofln;
            fieldSet::FieldAccess m_qtd_blqd_chip;
            fieldSet::FieldAccess m_qtd_leit_chip;
            fieldSet::FieldAccess m_qtd_fallback_cre;
            fieldSet::FieldAccess m_qtd_fallback_deb;
            fieldSet::FieldAccess m_cod_vers_sftw_pnpd;
    };
}
