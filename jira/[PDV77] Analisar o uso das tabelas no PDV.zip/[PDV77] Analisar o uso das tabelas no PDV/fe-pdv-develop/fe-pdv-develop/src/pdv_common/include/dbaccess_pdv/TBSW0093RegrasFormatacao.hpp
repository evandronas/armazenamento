#pragma once

#include<TBSW0093RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
	class TBSW0093RegrasFormatacao : public TBSW0093RegrasFormatacaoBase
	{
	public:
		TBSW0093RegrasFormatacao( );
		~TBSW0093RegrasFormatacao( );
	};
}