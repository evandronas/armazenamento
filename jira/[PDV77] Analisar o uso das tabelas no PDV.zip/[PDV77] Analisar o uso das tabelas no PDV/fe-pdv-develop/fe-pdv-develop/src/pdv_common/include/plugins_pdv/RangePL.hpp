/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: 
/ Data de Cria��o: 
/ Hist�rico Mudan�as: Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <iostream>
#include <dbm.h>

namespace plugins_pdv
{
	class RangePL
	{
	public:
		RangePL();
		virtual ~RangePL();

        // TBSW0044
        unsigned long       get_NUM_PDV() const;
        oasis_dec_t         get_NUM_BIN_INI() const;
        oasis_dec_t         get_NUM_BIN_FIM() const;
        unsigned long       get_COD_EMSR() const;
        const std::string&  get_COD_STTU_TRAN() const;
        dbm_datetime_t      get_DAT_ATLZ_REG() const;
        const std::string&  get_COD_USR_ATLZ_REG() const;
        const std::string&  get_IND_STTU_REG() const;
        // TBSW2011
        unsigned long       get_COD_ISSR_SW() const;
        const std::string&  get_NOM_EMSR_SW() const;
        unsigned long       get_COD_EMSR_SW() const;
        unsigned long       get_COD_BNDR() const;
        unsigned long       get_COD_FE_EMSR() const;
        // TBSW2013
        unsigned long       get_COD_ROTA_PRVT_LBEL() const;
        const std::string&  get_NETWORK_ID() const;
        const std::string&  get_NOM_FE_ACQR() const;
        const std::string&  get_NOM_HOST_ACQR() const;

        // TBSW0044
        void set_NUM_PDV( unsigned long a_NUM_PDV );
        void set_NUM_BIN_INI( oasis_dec_t a_NUM_BIN_INI );
        void set_NUM_BIN_FIM( oasis_dec_t a_NUM_BIN_FIM );
        void set_COD_EMSR( unsigned long a_COD_EMSR );
        void set_COD_STTU_TRAN( const std::string& a_COD_STTU_TRAN );
        void set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG );
        void set_COD_USR_ATLZ_REG( const std::string& a_COD_USR_ATLZ_REG );
        void set_IND_STTU_REG( const std::string& a_IND_STTU_REG );
        // TBSW2011
        void set_COD_ISSR_SW( unsigned long a_COD_ISSR_SW );
        void set_NOM_EMSR_SW( const std::string& a_NOM_EMSR_SW );
        void set_COD_EMSR_SW( unsigned long a_COD_EMSR_SW );
        void set_COD_BNDR( unsigned long a_COD_BNDR );
        void set_COD_FE_EMSR( unsigned long a_COD_FE_EMSR );
        // TBSW2013
        void set_COD_ROTA_PRVT_LBEL( unsigned long a_COD_ROTA_PRVT_LBEL );
        void set_NETWORK_ID( const std::string& a_NETWORK_ID );
        void set_NOM_FE_ACQR( const std::string& a_NOM_FE_ACQR );
        void set_NOM_HOST_ACQR( const std::string& a_NOM_HOST_ACQR );

        
		bool getIS_VALID() const;

		void setIS_VALID( bool a_boolean );

	private:
        // TBSW0044
        unsigned long       m_NUM_PDV;
        oasis_dec_t         m_NUM_BIN_INI;
        oasis_dec_t         m_NUM_BIN_FIM;
        unsigned long       m_COD_EMSR;
        std::string         m_COD_STTU_TRAN;
        dbm_datetime_t      m_DAT_ATLZ_REG;
        std::string         m_COD_USR_ATLZ_REG;
        std::string         m_IND_STTU_REG;
        // TBSW2011
        unsigned long       m_COD_ISSR_SW;
        std::string         m_NOM_EMSR_SW;
        unsigned long       m_COD_EMSR_SW;
        unsigned long       m_COD_BNDR;
        unsigned long       m_COD_FE_EMSR;
        // TBSW2013
        unsigned long       m_COD_ROTA_PRVT_LBEL;
        std::string         m_NETWORK_ID;
        std::string         m_NOM_FE_ACQR;
        std::string         m_NOM_HOST_ACQR;

		bool m_IS_VALID;
	};
}

