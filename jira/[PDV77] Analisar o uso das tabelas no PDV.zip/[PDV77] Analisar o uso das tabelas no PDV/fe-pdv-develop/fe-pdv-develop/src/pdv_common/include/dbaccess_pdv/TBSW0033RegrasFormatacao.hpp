#pragma once

#include<TBSW0033RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
	class TBSW0033RegrasFormatacao : public TBSW0033RegrasFormatacaoBase
	{
	public:
		TBSW0033RegrasFormatacao( );
		~TBSW0033RegrasFormatacao( );

		void insert_TXT_MSG_1( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
		void insert_TXT_MSG_2( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
        void update_TXT_MSG_1( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
        void update_TXT_MSG_2( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
	};
}
