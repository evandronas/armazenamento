/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o:
/ Conte�do:
/ Autor: cr689068, Jos� Augusto T. Gavazza
/ Data de Cria��o: 2013, 05 de Fevereiro
/ Hist�rico Mudan�as: 2013, 05 de Fevereiro, cr689068, Jos� Augusto T. Gavazza, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <iostream>


namespace plugins_pdv
{
	class SeekInitFile
	{
		public:
			SeekInitFile();
			virtual ~SeekInitFile();

			const std::string& getCurrentInitInfoFileName() const;
			int seekFile(const std::string& a_ecrInitDir,
									   const std::string& a_ecrInitDirTmp,
									   const std::string& a_verid,
									   const std::string& a_termid,
									   const std::string& a_termloc);
									   
		private:
			std::string m_currentInitInfoFileName;
		
			int access(const std::string& a_filename);
	};
}

