#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "plugins_pdv/BinRangeSearch.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTrxRouting( );
	class TrxRouting : public dataManip::Command
	{
	public:
		TrxRouting( );
		TrxRouting( const std::string &str );
		virtual ~TrxRouting( );

		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		
		fieldSet::ConstFieldAccess m_inputBin;
		fieldSet::ConstFieldAccess m_inputCodTipTran;
		fieldSet::ConstFieldAccess m_inputNomHostAcqr;
		fieldSet::ConstFieldAccess m_inputNomFeAcqr;
		
		fieldSet::FieldAccess m_outputCodRota;
		fieldSet::FieldAccess m_outputCodIssrSw;
		fieldSet::FieldAccess m_outputNetworkId;
		fieldSet::FieldAccess m_outputNetworkIdVan;
		fieldSet::FieldAccess m_outputNomEmsrSw;
		fieldSet::FieldAccess m_outputCodEmsrSw;
		fieldSet::FieldAccess m_outputCodBndr;
		fieldSet::FieldAccess m_outputCodFeEmsr;
		fieldSet::FieldAccess m_resultField;
		
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_binPath;
		
		BinRangeSearch m_binRangeSearch;
	};
}
