#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "TBSW0139.hpp"
#include "dbaccess_pdv/TBSW0139RegrasFormatacao.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createConfirmacaoTBSW0139( );

    class ConfirmacaoTBSW0139 : public dataManip::Command
    {
        public:
            ConfirmacaoTBSW0139( );
            virtual ~ConfirmacaoTBSW0139( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            ConfirmacaoTBSW0139& setTargetFieldPath( const std::string& a_path );
            ConfirmacaoTBSW0139& setSourceFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_termid;

    }; // class ConfirmacaoTBSW0139

} // namespace plugins_pdv
