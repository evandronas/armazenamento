#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0030Loader();

    class TBSW0030Loader : public dataManip::Command
    {
        public:

            TBSW0030Loader();
            TBSW0030Loader( const std::string& str );
            virtual ~TBSW0030Loader();

            bool init();
            void finish();
            int execute( bool& a_stop );
            dataManip::Command* clone() const;

            TBSW0030Loader& setTargetFieldPath( const std::string& a_path );
            TBSW0030Loader& setSourceFieldPath( const std::string& a_path );
            TBSW0030Loader& setLocalFieldPath( const std::string& a_path );

        private:

            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;

            fieldSet::FieldAccess m_result;
            fieldSet::FieldAccess m_target_dat_mov_tran;
            fieldSet::FieldAccess m_target_num_seq_unc;
            fieldSet::FieldAccess m_target_tip_tran;
            fieldSet::FieldAccess m_target_num_mot_rsps;
            fieldSet::FieldAccess m_target_tip_tcnl;
            fieldSet::FieldAccess m_target_num_estb;
            fieldSet::FieldAccess m_target_cod_term;
            fieldSet::FieldAccess m_target_tip_term;
            fieldSet::FieldAccess m_target_num_rd_org;
            fieldSet::FieldAccess m_target_cod_pos_entr_modo;
            fieldSet::FieldAccess m_target_cod_emsr;
            fieldSet::FieldAccess m_target_tip_vd;
            fieldSet::FieldAccess m_target_val_tran;
            fieldSet::FieldAccess m_target_cod_ram_atvd;
            fieldSet::FieldAccess m_target_num_car;
            fieldSet::FieldAccess m_target_cod_mot_rsps_ext;
            fieldSet::FieldAccess m_target_num_aut;
            fieldSet::FieldAccess m_target_val_tx;
            fieldSet::FieldAccess m_target_val_cot_dlr;
            fieldSet::FieldAccess m_target_dat_vld_car;
            fieldSet::FieldAccess m_target_cod_trk_car;
            fieldSet::FieldAccess m_target_cod_moed;
            fieldSet::FieldAccess m_target_num_cv;
            fieldSet::FieldAccess m_target_val_tran_dlr;
            fieldSet::FieldAccess m_target_cod_ctgr_tran;
            fieldSet::FieldAccess m_target_num_bin_car;
            fieldSet::FieldAccess m_target_cod_pais_car;
            fieldSet::FieldAccess m_target_ind_id_prev;
            fieldSet::FieldAccess m_target_cod_prod;
            fieldSet::FieldAccess m_target_cod_ctr;
            fieldSet::FieldAccess m_target_cod_cndc_cptr;
            fieldSet::FieldAccess m_target_num_emsr;
            fieldSet::FieldAccess m_target_dat_ctb_tran;
            fieldSet::FieldAccess m_target_cod_bndr;
            fieldSet::FieldAccess m_target_dat_rsmo_vd;
            fieldSet::FieldAccess m_target_ind_tran_refd;
            fieldSet::FieldAccess m_target_cod_ref_restante;
            fieldSet::FieldAccess m_target_ind_trk;
            fieldSet::FieldAccess m_target_cod_mot_sw;
            fieldSet::FieldAccess m_target_ind_cptr_cvc_2;
            fieldSet::FieldAccess m_target_ind_term_rlcd_chip;
            fieldSet::FieldAccess m_target_cod_serv;
            fieldSet::FieldAccess m_target_cod_serv_snha;
            fieldSet::FieldAccess m_target_val_tx_risc;
            fieldSet::FieldAccess m_target_nom_loc_estb;
            fieldSet::FieldAccess m_target_cod_msg_iso;
            fieldSet::FieldAccess m_target_cod_pcm_iso;
            fieldSet::FieldAccess m_target_ind_dfzm;
            fieldSet::FieldAccess m_target_ind_estr;
            fieldSet::FieldAccess m_target_ind_cptrdo;
            fieldSet::FieldAccess m_target_tip_tran_orgl;
            fieldSet::FieldAccess m_target_tip_pln_pgmn;
            fieldSet::FieldAccess m_target_dat_expc_tran;
            fieldSet::FieldAccess m_target_ind_agnd_tran;
            fieldSet::FieldAccess m_target_cod_cmpm_tran;
            fieldSet::FieldAccess m_target_ind_impr_cpom;
            fieldSet::FieldAccess m_target_dth_ini_tran;
            fieldSet::FieldAccess m_target_dth_sttu_tran;
            fieldSet::FieldAccess m_target_prcn_tx_risc;
            fieldSet::FieldAccess m_target_num_stan;
            fieldSet::FieldAccess m_target_cod_cndc_cptr_pauz;
            fieldSet::FieldAccess m_target_tip_ent_pauz;
            fieldSet::FieldAccess m_target_cod_oper_cnfr;
            fieldSet::FieldAccess m_target_ind_emsr_mtc;
            fieldSet::FieldAccess m_target_ind_da_rlcd_chip;
            fieldSet::FieldAccess m_target_tip_dtlh_tran;
            fieldSet::FieldAccess m_target_ind_da_rlcd_iata;
            fieldSet::FieldAccess m_target_dth_gmt;
            fieldSet::FieldAccess m_target_cod_mot_aut;
            fieldSet::FieldAccess m_target_num_cvc_2;
            fieldSet::FieldAccess m_target_val_totl_tran;
            fieldSet::FieldAccess m_target_ind_sttu_tran;
            fieldSet::FieldAccess m_target_num_rsmo_vd;
            fieldSet::FieldAccess m_target_nom_site_acqr_orgl;
            fieldSet::FieldAccess m_target_nom_host_acqr_orgl;
            fieldSet::FieldAccess m_target_nom_fe_acqr_orgl;
            fieldSet::FieldAccess m_target_nom_site_issr;
            fieldSet::FieldAccess m_target_nom_host_issr;
            fieldSet::FieldAccess m_target_nom_fe_issr;
            fieldSet::FieldAccess m_target_nom_site_acqr_atlz;
            fieldSet::FieldAccess m_target_nom_host_acqr_atlz;
            fieldSet::FieldAccess m_target_nom_fe_acqr_atlz;
            fieldSet::FieldAccess m_target_txt_da_adic_emsr;
            fieldSet::FieldAccess m_target_tip_modl_cptr;
            fieldSet::FieldAccess m_target_dth_tran_emsr;
            fieldSet::FieldAccess m_target_dat_lqdc_emsr;
            fieldSet::FieldAccess m_target_cod_istt_acqr;
            fieldSet::FieldAccess m_target_cod_istt_frwd;
            fieldSet::FieldAccess m_target_cod_rsps_dtlh_emsr;
            fieldSet::FieldAccess m_target_cod_rstd_num_cvc_2;
            fieldSet::FieldAccess m_target_cod_serv_trk_car;
            fieldSet::FieldAccess m_target_cod_vldc_emsr;
            fieldSet::FieldAccess m_target_ind_aut;
            fieldSet::FieldAccess m_target_ind_da_rlcd_kmrc;
			fieldSet::FieldAccess m_target_COD_TRAN_CAD;
			fieldSet::FieldAccess m_target_DAT_PAUZ;			// 23/10/2014
			fieldSet::FieldAccess m_target_NUM_SEQ_UNC_PAUZ;	// 23/10/2014
            fieldSet::FieldAccess m_target_COD_NTWK_ID_ISSR_ORGL;
            fieldSet::FieldAccess m_target_COD_NTWK_ID_ACQR_ORGL;
            fieldSet::FieldAccess m_target_cod_prod_cdst;
            fieldSet::FieldAccess m_target_cod_prod_prcr;

            //fieldSet::FieldAccess m_target_val_eftv_aprv;
            fieldSet::FieldAccess m_cod_ram_mcc;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_origrefnum;
            fieldSet::ConstFieldAccess m_origpan;
            fieldSet::ConstFieldAccess m_origtrace;
            fieldSet::ConstFieldAccess m_origmsg;
            fieldSet::ConstFieldAccess m_termid;
            fieldSet::ConstFieldAccess m_origdate;
            fieldSet::ConstFieldAccess m_is_3a_perna;
            fieldSet::ConstFieldAccess m_acquirer_data;
            fieldSet::ConstFieldAccess m_pan;
            fieldSet::ConstFieldAccess m_amount;
            fieldSet::ConstFieldAccess m_referralCondition;
            //fieldSet::ConstFieldAccess m_authnum;
            //fieldSet::ConstFieldAccess m_pb_reason_code;
            //fieldSet::ConstFieldAccess m_ext_network_code;
            //fieldSet::ConstFieldAccess m_cod_mtv_sw;
            //fieldSet::ConstFieldAccess m_nom_host_issr;
            //fieldSet::ConstFieldAccess m_nom_fe_issr;
            //fieldSet::ConstFieldAccess m_az_reason_code;
            //fieldSet::ConstFieldAccess m_local_time;
            //fieldSet::ConstFieldAccess m_status;

            // t694446@FIS_BEGIN - Data: 06/01/2014 - 13:35 - Ref. ao BT53.136
               fieldSet::FieldAccess m_target_cod_aut_emsr;
            // t694446@FIS_END - Data: 06/01/2014 - 13:35 - Ref. ao BT53.136

            // t689721@FIS_BEGIN - Data: 20/02/2014 - Ref. BT55.769
               fieldSet::FieldAccess m_target_cod_tran_cad;
            // t689721@FIS_END - Data: 20/02/2014 - Ref. BT55.769

            fieldSet::FieldAccess indicadorTransacaoTokenizada;
            
            // Release Bandeiras PDV - Abril 2019 - INICIO
            fieldSet::FieldAccess indicadorModoEntrada;
            fieldSet::FieldAccess indicadorPresencaPortador;
            fieldSet::FieldAccess indicadorTecnologiaTerminal;
            // Release Bandeiras PDV - Abril 2019 - FIM
            
            fieldSet::ConstFieldAccess settlementDate;
    };
}


