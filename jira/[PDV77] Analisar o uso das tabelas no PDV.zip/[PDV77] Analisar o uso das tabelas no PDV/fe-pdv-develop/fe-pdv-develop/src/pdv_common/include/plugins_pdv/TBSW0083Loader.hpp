/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0083Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0083Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, cken>
/ Data de Cria��o: <Fri Oct 26 15:21:52 2012
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0083Loader();

    class TBSW0083Loader : public dataManip::Command
    {
    public:
        TBSW0083Loader();
        TBSW0083Loader( const std::string& str );
        virtual ~TBSW0083Loader();

        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;

        TBSW0083Loader& setTargetFieldPath( const std::string& a_path );
        TBSW0083Loader& setSourceFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );
		
		fieldSet::FieldAccess m_result;
		fieldSet::FieldAccess m_COD_CEP_PORT;
		fieldSet::FieldAccess m_COD_CEP_CMPM_PORT;
		fieldSet::FieldAccess m_TXT_ENDR_PORT;
		fieldSet::FieldAccess m_NUM_CPF_PORT;
		fieldSet::FieldAccess m_DAT_MOV_TRAN;
		fieldSet::FieldAccess m_NUM_SEQ_UNC;
		fieldSet::FieldAccess m_COD_RSPS_AVS;
		fieldSet::FieldAccess m_TXT_CMPM_ENDR_PORT;
		
        fieldSet::ConstFieldAccess m_origdate;
		fieldSet::ConstFieldAccess m_origrefnum;		
        fieldSet::ConstFieldAccess m_msgtype;
		fieldSet::ConstFieldAccess m_refnum;	
		fieldSet::ConstFieldAccess m_local_date;	
        
        std::string m_targetFieldPath;
        std::string m_sourceFieldPath;
    };
}




