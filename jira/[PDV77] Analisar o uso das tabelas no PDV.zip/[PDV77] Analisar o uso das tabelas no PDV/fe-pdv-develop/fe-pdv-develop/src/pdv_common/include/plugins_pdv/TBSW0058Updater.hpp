/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0058Updater>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0058Updater>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <694037, Fernando Amaral>
/ Data de Cria��o: <2012, 10 de Julho>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once

#include <fieldSet/FieldAccess.hpp>
#include <dataManip/Command.hpp>
#include <TBSW0058.hpp>

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0058Updater();

	class TBSW0058Updater : public dataManip::Command
	{
	public:
		TBSW0058Updater();
		TBSW0058Updater( const std::string &str );
		virtual ~TBSW0058Updater();
		
		bool init();
		void finish();
		int execute( bool& a_stop );
		dataManip::Command* clone() const;
		
		TBSW0058Updater& setSourceFieldPath( const std::string& a_path );
		TBSW0058Updater& setTargetFieldPath( const std::string& a_path );
		TBSW0058Updater& setResult( const std::string& a_result );
      
      // t694446@FIS_BEGIN - Data: 21/11/2013 - GAP3: 1.1.4.11 - Tratamento do C�digo de Autoriza��o nos Front-Ends 
         TBSW0058Updater& setLocalFieldPath( const std::string& a_path );
      // t694446@FIS_END - Data: 21/11/2013 - GAP3: 1.1.4.11 - Tratamento do C�digo de Autoriza��o nos Front-Ends 
      
		std::string getResult( );
      

	private:
		bool startConfiguration( const configBase::Tag* a_tag );

		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;

      fieldSet::FieldAccess m_local_date;
      fieldSet::FieldAccess m_local_time;
      fieldSet::FieldAccess m_refnum;
      fieldSet::FieldAccess m_origrefnum;
      fieldSet::FieldAccess m_msgtype;
      fieldSet::FieldAccess m_origtrace;
      fieldSet::FieldAccess m_origpan;
      fieldSet::FieldAccess m_amount;
      fieldSet::FieldAccess m_origdate;
      fieldSet::FieldAccess m_origtime;
      fieldSet::FieldAccess m_authnum;
      fieldSet::FieldAccess m_origauthnum;
      fieldSet::FieldAccess dataLocalOriginal;
      fieldSet::FieldAccess m_is_3a_perna;
      fieldSet::FieldAccess m_transcode;
      fieldSet::FieldAccess m_isVan;
      fieldSet::FieldAccess m_az_reason_code;
      fieldSet::ConstFieldAccess m_txt_adic_pos;
      fieldSet::FieldAccess m_cd_ems;
      fieldSet::FieldAccess m_mc_info_country;
      fieldSet::FieldAccess m_nom_site_issr;
      fieldSet::FieldAccess m_nom_host_issr;
      fieldSet::FieldAccess m_nom_fe_issr;                
      fieldSet::FieldAccess m_status;
      fieldSet::FieldAccess m_trace;
      fieldSet::FieldAccess m_termid;
      fieldSet::FieldAccess m_install_num;
      fieldSet::FieldAccess m_termloc;
      fieldSet::FieldAccess m_mc_info_ica;
      fieldSet::FieldAccess m_pb_reason_code;
      fieldSet::FieldAccess m_ext_network_code;            
      fieldSet::FieldAccess m_pin;
      fieldSet::FieldAccess m_acq_conv_rate;
      fieldSet::FieldAccess m_issuer;
      fieldSet::FieldAccess m_de_adc_ete;
      fieldSet::FieldAccess m_mc_info_prod_code;
      fieldSet::FieldAccess numeroReferenciaTransacao;
      fieldSet::FieldAccess codigoCapacidadeTerminal;
      //mc_info_region
      fieldSet::FieldAccess infoRegiaoMastercard;
      
      fieldSet::FieldAccess m_result;

        std::string m_Strresult;

        //cr689721@FIS - Data: 16/09/2014 - Criando m�todo de convers�o do numero de autoriza��o.
        std::string converteAuthnum( const std::string& a_numAuth );
            
		// t694446@FIS - Data: 21/11/2013 - GAP3: 1.1.4.11 - Tratamento do C�digo de Autoriza��o nos Front-Ends 
		std::string m_localFieldPath;
		
		//cr689721@FIS - Data: 04/03/2015 
		fieldSet::ConstFieldAccess m_num_seq_unc_pauz;
		fieldSet::ConstFieldAccess m_dat_mov_tran_pauz;
        fieldSet::ConstFieldAccess m_iss_name ;     
        fieldSet::ConstFieldAccess m_msg_category ;  
        fieldSet::ConstFieldAccess m_msg_name ;  
        fieldSet::ConstFieldAccess m_addresponse      ;
        fieldSet::ConstFieldAccess m_has_pin      ;
                 
        fieldSet::ConstFieldAccess numeroAutorizacoLocal;
        fieldSet::ConstFieldAccess codigoAutorizacaoEmissor;
        fieldSet::ConstFieldAccess codigoAutorizacaoEmissorConvertido;
        fieldSet::ConstFieldAccess dataPreAutorizacao;
        fieldSet::ConstFieldAccess senderMailboxName;
        fieldSet::ConstFieldAccess tokenIdentifier;
        fieldSet::ConstFieldAccess codigoOrigemRespostaAutorizacao;
        fieldSet::ConstFieldAccess codigoProdutoMastercard; /// COD_PROD_MTC
        fieldSet::ConstFieldAccess codigoRegiaoMastercard; /// COD_RGAO_MTC
        
        // Release Bandeiras PDV - Abril 2019 - INICIO
        fieldSet::ConstFieldAccess indicadorPresencaPortador;
        fieldSet::ConstFieldAccess indicadorTecnologiaTerminal;
        // Release Bandeiras PDV - Abril 2019 - FIM

	};
}



