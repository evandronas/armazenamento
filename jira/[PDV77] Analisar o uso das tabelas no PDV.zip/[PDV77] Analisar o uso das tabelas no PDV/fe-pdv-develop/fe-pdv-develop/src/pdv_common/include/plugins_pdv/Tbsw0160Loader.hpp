/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTbsw0160Loader();

    class Tbsw0160Loader : public dataManip::Command
    {
    public:
        Tbsw0160Loader();
        Tbsw0160Loader( const std::string& str );
        virtual ~Tbsw0160Loader();

        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;

        Tbsw0160Loader& SetTargetFieldPath( const std::string& pathParametro );
        Tbsw0160Loader& SetSourceFieldPath( const std::string& pathParametro );

    private:
        bool startConfiguration( const configBase::Tag* tagParametro );

        std::string sourceFieldPath;
        std::string targetFieldPath;

        fieldSet::FieldAccess result;

        fieldSet::FieldAccess dataMovimentoTransacao;               /// DAT_MOV_TRAN : DATA_MOVIMENTO_TRANSACAO
        fieldSet::FieldAccess numeroSequencialUnico;                /// NUM_SEQ_UNC : NUMERO_SEQUENCIAL_UNICO
        fieldSet::FieldAccess indicadorRedeOrigem;                  /// IND_RD_ORG : INDICADOR_REDE_ORIGEM
        fieldSet::FieldAccess codigoProgramaAutorizacao;            /// COD_PGM_AUT : CODIGO_PROGRAMA_AUTORIZACAO
        fieldSet::FieldAccess textoRelacionadoChip;                 /// TXT_RLCD_CHIP : TEXTO_RELACIONADO_CHIP
        fieldSet::FieldAccess textoInformacaoComplementarChip;      /// TXT_INFO_CMPM_CHIP : TEXTO_INFORMACAO_COMPLEMENTAR_CHIP
        fieldSet::FieldAccess textoResultadoAtualizacaoChip;        /// TXT_RSTD_ATLZ_CHIP : TEXTO_RESULTADO_ATUALIZACAO_CHIP
        fieldSet::FieldAccess indicadorNivelSegurancaKomerci;       /// IND_NVL_SGRA_KMRC : INDICADOR_NIVEL_SEGURANÇA_KOMERCI
        fieldSet::FieldAccess indicadorMetodoVerificacaoPortador;   /// IND_MTDO_VRFC_PORT : INDICADOR_METODO_VERIFICACAO_PORTADOR
        fieldSet::FieldAccess indicadorPresencaSenha;               /// IND_PRSC_SNHA : INDICADOR_PRESENCA_SENHA
        fieldSet::FieldAccess dataConfirmacaoPreautorizacao;        /// DAT_CNFR_PAUZ : DATA_CONFIRMACAO_PREAUTORIZACAO
        fieldSet::FieldAccess numeroSequencialUnicoConfirmacao;     /// NUM_SEQ_UNC_CNFR : NUMERO_SEQUENCIAL_UNICO_CONFIRMACAO
        fieldSet::FieldAccess numeroSequencialCartaoValidacaoChip;  /// NUM_SEQ_CAR_VLDC_CHIP : NUMERO_SEQUENCIAL_CARTAO_VALIDACAO_CHIP

        fieldSet::ConstFieldAccess origRefnum;   /// segments.common.origrefnum
        fieldSet::ConstFieldAccess origDate;     /// shc_msg.origdate

    };
}
