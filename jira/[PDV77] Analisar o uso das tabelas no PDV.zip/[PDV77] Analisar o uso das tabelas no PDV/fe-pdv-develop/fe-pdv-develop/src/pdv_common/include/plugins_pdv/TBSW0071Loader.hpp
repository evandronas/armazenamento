/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0071Loader( );
	class TBSW0071Loader : public dataManip::Command
	{
		enum tableFields
		{
			RESULT, NUM_PDV, COD_STTU_REG, DAT_ATLZ_REG, COD_SERV, NUM_PDV_BCO_ARCD, TIP_MDLD_PGMN, COD_BLTO_BCO_ARCD, VAL_MN_VD, VAL_MX_SQUE, LAST_TB_FIELD
		};
		enum sourceFields
		{
			TERMLOC, TRANSCODE, SUBTRANSCODE, LAST_SOURCE_FIELD
		};
	public:
		TBSW0071Loader( );
		TBSW0071Loader( const std::string& str );
		virtual ~TBSW0071Loader( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		std::string getResult( );
		TBSW0071Loader& setResult( const std::string& a_result );
		TBSW0071Loader& setTargetFieldPath( const std::string& a_path );
		TBSW0071Loader& setSourceFieldPath( const std::string& a_path );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_targetField[LAST_TB_FIELD];
		fieldSet::FieldAccess m_sourceField[LAST_SOURCE_FIELD];
		std::string m_targetFieldPath;
		std::string m_sourceFieldPath;
		std::string m_result;
	};
}

