#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "plugins_pdv/BinRangeSearch.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTrxPLRouting( );
	class TrxPLRouting : public dataManip::Command
	{
	public:
		TrxPLRouting( );
		TrxPLRouting( const std::string &str );
		virtual ~TrxPLRouting( );

		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;

	private:
		bool startConfiguration( const configBase::Tag* a_tag );

		fieldSet::ConstFieldAccess m_pan;
		fieldSet::ConstFieldAccess m_termloc;

        fieldSet::FieldAccess m_num_pdv;
        fieldSet::FieldAccess m_num_bin_ini;
        fieldSet::FieldAccess m_num_bin_fim;
        fieldSet::FieldAccess m_cod_emsr;
        fieldSet::FieldAccess m_cod_sttu_tran;
        fieldSet::FieldAccess m_dat_atlz_reg;
        fieldSet::FieldAccess m_cod_usr_atlz_reg;
        fieldSet::FieldAccess m_ind_sttu_reg;

        fieldSet::FieldAccess m_cod_issr_sw;
        fieldSet::FieldAccess m_nom_emsr_sw;
        fieldSet::FieldAccess m_cod_emsr_sw;
        fieldSet::FieldAccess m_cod_bndr;
        fieldSet::FieldAccess m_cod_fe_emsr;
        fieldSet::FieldAccess m_cod_rota_prvt_lbel;
        fieldSet::FieldAccess m_network_id;
        fieldSet::FieldAccess m_nom_fe_acqr;
        fieldSet::FieldAccess m_nom_host_acqr;

		fieldSet::FieldAccess m_result;

		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_binPath;

		BinRangeSearch m_binRangeSearch;
	};
}
