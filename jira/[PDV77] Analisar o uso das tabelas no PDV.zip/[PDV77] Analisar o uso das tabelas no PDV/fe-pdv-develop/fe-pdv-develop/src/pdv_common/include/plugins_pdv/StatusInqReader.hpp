/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -----------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Teodoro Guimaraes
/ Data de Cria��o: 2013, 1 de marco
/ Hist�rico Mudan�as: 2013, 1 de marco, t689066, Alexandre Teodoro 
                                                      Guimaraes, Versao Inicial
/ -----------------------------------------------------------------------------
*/

/*
*********************** MODIFICACOES ************************
Autor    : Joao Paulo F. Costa
Data     : 16/03/2021
Empresa  : Rede
Descricao: Falha no processo de Sonda
ID       : EAK-6005
*************************************************************
*/

#pragma once
#include "plugins_pdv/ProtomServer.hpp"
#include "dispatcher/Reader.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "TBSW0030.hpp"
#include "TBSW0121.hpp"
//TODOSW75 #include "TBSW0059.hpp"
#include "base/GenException.hpp"
#include "logger/Logger.hpp"
//TODOSW75 #include "contigencyHandler.hpp"

using namespace std;

namespace plugins_pdv
{
    extern "C" base::Identificable* createStatusInqReader();
    extern "C" long shc_local_currenttime();

    class StatusInqReader : public dispatcher::Reader
    {
        #define HISTORY_DAYS_RANGE      "statusinq.history_days_range"
        #define SEARCH_INTERVAL         "statusinq.search_interval"
        #define PENDING_WAITING_TIME    "statusinq.pending_waiting_time"
        #define ITERACTIONS_INTERVAL    "statusinq.iteractions_interval"
        #define TPS                     "statusinq.tps"
        #define ENABLE_REMOTE_QUERY     "statusinq.enable_remote_query"
        #define REMOTE_ACQR_HOST_NAME   "statusinq.remote_acqr_host_name"

    public:
        StatusInqReader();
        virtual ~StatusInqReader();
        bool startConfiguration( const configBase::Tag* a_tag );
		bool open( ) ;
		void close( );
		bool fetch( ); 
        int getTps( );       
        int getNetMbid( short a_netcode );
        void getSecsFromMidnight( unsigned int& a_value);
        bool checkContingency();
        void calculateQueryIntervals();
        void calculateFinalInterval();

        StatusInqReader& setHistoryDaysRange( string& a_value );
        StatusInqReader& setSearchInterval( string& a_value );
        StatusInqReader& setPendingWaitingTime( string& a_value );
        StatusInqReader& setInteractions_Interval( string& a_value );                           
        StatusInqReader& setTps( string& a_value ); 

        StatusInqReader& setMsgHeaderSize( const char* a_value );

    private: 
        dbaccess_common::TBSW0030 m_TBSW0030;
        //TODOSW75 dbaccess_common::ContigencyHandler *m_cntHandler;
        logger::Logger* m_logger;
        configBase::ConfigBase* m_cfg;

        string m_historyDaysRange;
        string m_searchInterval;
        string m_pendingWaitingTime;
        string m_iteractions_interval;
        string m_tps;
        string m_enable_remote_query;
        string m_remote_acqr_host_name;
        string serverAliasId;

        unsigned int m_initInterval;
        unsigned int m_finalInterval;
        unsigned int m_auxDaysRange;
        /* JPFC - EAK-6005: Falha no processo de Sonda - Inicio */
        unsigned int m_globalDaysRange;
        /* JPFC - EAK-6005: Falha no processo de Sonda - Fim */
        unsigned int m_currentSec;
     
        bool m_firstRun;
        bool m_finalRange;
        bool m_stopExec;
        bool m_flagRemoteExec;
        bool m_flagSleep;

        int m_acqsrvMbid;  

        long int m_msgHeaderSize;

    };
}

