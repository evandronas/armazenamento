/* Copyright 2020 Rede S.A.
Autor  : Breder
Empresa: Rede
*/

#ifndef __TBSW0268Loader_H__
#define __TBSW0268Loader_H__

#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "msgConv/fistmv.hpp"
#include "configBase/TagList.hpp"
#include "base/GenException.hpp"
#include "dataManip/Command.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <sstream>
#include <stdio.h>

namespace plugins_pdv
{
    extern "C" base::Identificable* CreateTBSW0268Loader();

    class TBSW0268Loader : public dataManip::Command
    {
        public:
            // Declaracao dos Contrutores
            TBSW0268Loader();
            TBSW0268Loader( const std::string& where );
            
            // Declaracao dos Destrutores
            ~TBSW0268Loader();

            // Metodos herdados
            bool init();
            void finish();
            int execute( bool& a_stop );
            dataManip::Command* clone() const;

            std::string GetStatus();
            TBSW0268Loader& SetStatus( const std::string& status );

            TBSW0268Loader& SetTargetFieldPath( const std::string& path );
            TBSW0268Loader& SetSourceFieldPath( const std::string& path );

        private:
            // Metodos herdados
            bool startConfiguration( const configBase::Tag* tag );
            
            // Atributos da classe
            fieldSet::FieldAccess targetField[32];
            fieldSet::FieldAccess sourceField[32];
            std::string targetFieldPath;
            std::string sourceFieldPath;
            std::string status;
    };
}
#endif  // __TBSW0268Loader_H__
