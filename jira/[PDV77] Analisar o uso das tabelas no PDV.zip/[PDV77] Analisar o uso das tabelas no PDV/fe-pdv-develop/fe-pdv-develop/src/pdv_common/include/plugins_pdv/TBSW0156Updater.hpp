/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0156Updater>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TBSW0156Updater>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694451, Ricardo Deus>
/ Data de Criação: <Thur Apr 11 17:37:29 2012
>
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ . . .
/ <Data, Módulo, Autor, Descrição da Mudança>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "logger/LoggerGen.hpp"
#include "TBSW0156.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
  extern "C" base::Identificable* createTBSW0156Updater( );

  class TBSW0156Updater : public dataManip::Command
  {
  public:
    TBSW0156Updater( );
    virtual ~TBSW0156Updater( );
    
    bool init( );
    void finish( );
    int execute( bool& a_stop );
    dataManip::Command* clone( ) const;
    
    TBSW0156Updater& setSourceFieldPath( const std::string& a_path );
    TBSW0156Updater& setTargetFieldPath( const std::string& a_path );
    TBSW0156Updater& setLocalFieldPath( const std::string& a_path );
    
  private:
	logger::Logger* m_logger;
    bool startConfiguration( const configBase::Tag* a_tag );
    dbm_datetime_t f_datetime( long a_data, long a_time );
    
    dbaccess_common::TBSW0156 m_table0156;

    std::string m_sourceFieldPath;
    std::string m_targetFieldPath;
    std::string m_localFieldPath;
    
    fieldSet::FieldAccess m_result;   
 				
	fieldSet::ConstFieldAccess COD_TERM;
	fieldSet::ConstFieldAccess NUM_STAN;                                
	fieldSet::ConstFieldAccess DTH_ESTT;                              
	fieldSet::ConstFieldAccess COD_STTU_TERM;                          
	fieldSet::ConstFieldAccess QTD_MSG_RCBD;                           
	fieldSet::ConstFieldAccess QTD_MSG_ENVD;                           
	fieldSet::ConstFieldAccess QTD_TRAN;                               
	fieldSet::ConstFieldAccess QTD_NOVA_DSGM;                          
	fieldSet::ConstFieldAccess QTD_ERR_COM;                            
	fieldSet::ConstFieldAccess QTD_TMOT_TRAN;                          
	fieldSet::ConstFieldAccess QTD_TMOT_RVRS;                          
	fieldSet::ConstFieldAccess QTD_RTRM;                               
	fieldSet::ConstFieldAccess QTD_ERR_RCBM_MSG;                       
	fieldSet::ConstFieldAccess QTD_SNRM_RCBD;                          
	fieldSet::ConstFieldAccess QTD_SNRM_ENVD;                          
	fieldSet::ConstFieldAccess QTD_RNR_RCBD;                           
	fieldSet::ConstFieldAccess QTD_RNR_ENVD;                           
	fieldSet::ConstFieldAccess QTD_TST_RCBD;                           
	fieldSet::ConstFieldAccess QTD_TST_ENVD;                           
	fieldSet::ConstFieldAccess QTD_DM_RCBD;                            
	fieldSet::ConstFieldAccess QTD_DM_ENVD;                            
	fieldSet::ConstFieldAccess QTD_UAS_RCBD;                           
	fieldSet::ConstFieldAccess QTD_UAS_ENVD;                           
	fieldSet::ConstFieldAccess QTD_FRME_RCBD;                          
	fieldSet::ConstFieldAccess QTD_FRME_ENVD;                          
	fieldSet::ConstFieldAccess CONT_TMPO_RSPS;                         
	fieldSet::ConstFieldAccess LIM_TMPO_RSPS_1;                        
	fieldSet::ConstFieldAccess LIM_TMPO_RSPS_2;                        
	fieldSet::ConstFieldAccess LIM_TMPO_RSPS_3;                        
	fieldSet::ConstFieldAccess LIM_TMPO_RSPS_4;                        
	fieldSet::ConstFieldAccess CONT_TMPO_RSPS_1;                       
	fieldSet::ConstFieldAccess CONT_TMPO_RSPS_2;                       
	fieldSet::ConstFieldAccess CONT_TMPO_RSPS_3;                       
	fieldSet::ConstFieldAccess CONT_TMPO_RSPS_4;                       
	fieldSet::ConstFieldAccess QTD_MIN_ATVD;                           
	fieldSet::ConstFieldAccess QTD_MIN_INTD;                           
	fieldSet::ConstFieldAccess QTD_REINCZ;                             
	fieldSet::ConstFieldAccess QTD_ERR_ENT;                            
	fieldSet::ConstFieldAccess MODL_OPE_TERM;                          
	fieldSet::ConstFieldAccess IND_TIP_ALRM;                           
	fieldSet::ConstFieldAccess QTD_TRAN_SCSO_NUM_PRMI;                 
	fieldSet::ConstFieldAccess QTD_TRAN_SCSO_NUM_SECD;                 
	fieldSet::ConstFieldAccess QTD_NOVA_DSGM_SCSO_NUM_PRMI;            
	fieldSet::ConstFieldAccess QTD_NOVA_DSGM_SCSO_NUM_SECD;            
	fieldSet::ConstFieldAccess QTD_ERR_LEIT_CAR;                       
	fieldSet::ConstFieldAccess QTD_ERR_CNXO_HOST;                      
	fieldSet::ConstFieldAccess QTD_TMPO_OFLN;                          
	fieldSet::ConstFieldAccess QTD_LEIT_MSR;                           
	fieldSet::ConstFieldAccess CPO_RSVA_1;                             
	fieldSet::ConstFieldAccess VLCD_OPE_TERM;                          
	fieldSet::ConstFieldAccess QTD_TNTA_SECD_OCPD;                     
	fieldSet::ConstFieldAccess PSSW;                                   
	fieldSet::ConstFieldAccess QTD_TNTA_PRMI_NAO_ATDD;                 
	fieldSet::ConstFieldAccess OPC_TERM;                               
	fieldSet::ConstFieldAccess OPC_TERM_LOCL;                          
	fieldSet::ConstFieldAccess CPO_RSVA_2;                             
	fieldSet::ConstFieldAccess IND_OPE_PNPD;                           
	fieldSet::ConstFieldAccess VERS_SFTW_TERM;                         
	fieldSet::ConstFieldAccess QTD_LIN_IMPR;                           
	fieldSet::ConstFieldAccess CPCD_MMRA_TERM;                         
	fieldSet::ConstFieldAccess MODL_OPE_CMPH;                          
	fieldSet::ConstFieldAccess QTD_FALLBACK;                           
	fieldSet::ConstFieldAccess TIP_DSGM;                               
	fieldSet::ConstFieldAccess TIP_CNXO;                               
	fieldSet::ConstFieldAccess IND_UTLZ_PABX;                          
	fieldSet::ConstFieldAccess NUM_TEL_INCZ;                           
	fieldSet::ConstFieldAccess NUM_TEL_PRMI_TERM;                      
	fieldSet::ConstFieldAccess NUM_TEL_SECD_TERM;                      
	fieldSet::ConstFieldAccess TMPO_MDOI_CNXO;                         
	fieldSet::ConstFieldAccess TMPO_MDOI_OPE;                          
	fieldSet::ConstFieldAccess TMPO_MDOI_TRAN;                         
	fieldSet::ConstFieldAccess QTD_ENTR_ERR_PIN;                       
	fieldSet::ConstFieldAccess QTD_TRAN_CNCL_PSSW;                     
	fieldSet::ConstFieldAccess QTD_CAR_BLQD_PSSW;                      
	fieldSet::ConstFieldAccess QTD_TRAN_OFLN;                          
	fieldSet::ConstFieldAccess IND_STTU_RPLC;                          
	fieldSet::ConstFieldAccess QTD_CV_IMPR_PRMR_SGND_VIA;              
	fieldSet::ConstFieldAccess QTD_CV_IMPR_PRMR_VIA;                   
	fieldSet::ConstFieldAccess QTD_CV_IMPR_SGND_VIA;                   
	fieldSet::ConstFieldAccess QTD_CV_NAO_IMPR;                        
	fieldSet::ConstFieldAccess QTD_TRAN_DEB_MAGN_CHIP;                 
	fieldSet::ConstFieldAccess QTD_CNXO_TLCG_SCSO;                     
	fieldSet::ConstFieldAccess QTD_CNXO_INCZ_SCSO;                     
	fieldSet::ConstFieldAccess TMPO_CNXO_TLCG_SCSO;                    
	fieldSet::ConstFieldAccess TMPO_CNXO_INCZ_SCSO;                    
	fieldSet::ConstFieldAccess QTD_CNXO_PRBL_COM_INCZ;                 
	fieldSet::ConstFieldAccess QTD_CNXO_PRBL_COM_TLCG;                 
	fieldSet::ConstFieldAccess QTD_ERR_TMOT_INCZ;                      
	fieldSet::ConstFieldAccess QTD_ERR_TMOT_TLCG;                      
	fieldSet::ConstFieldAccess QTD_ERR_MAP_BIT_INCZ;                   
	fieldSet::ConstFieldAccess QTD_ERR_MAP_BIT_TLCG;                   
	fieldSet::ConstFieldAccess QTD_ERR_DA_INCZ;                        
	fieldSet::ConstFieldAccess QTD_ERR_DA_TLCG;                        
	fieldSet::ConstFieldAccess QTD_ERR_CNXO_PRDD_INCZ;                 
	fieldSet::ConstFieldAccess QTD_ERR_CNXO_PRDD_TLCG;                 
	fieldSet::ConstFieldAccess QTD_ERR_COM_INCZ;                       
	fieldSet::ConstFieldAccess QTD_ERR_COM_TLCG;                       
	fieldSet::ConstFieldAccess QTD_ERR_LIN_USO_INCZ;                   
	fieldSet::ConstFieldAccess QTD_ERR_LIN_USO_TLCG;                   
	fieldSet::ConstFieldAccess QTD_ERR_SEM_TOM_DSGM_INCZ;              
	fieldSet::ConstFieldAccess QTD_ERR_SEM_TOM_DSGM_TLCG;              
	fieldSet::ConstFieldAccess QTD_ERR_LIN_OCPD_INCZ;                  
	fieldSet::ConstFieldAccess QTD_ERR_LIN_OCPD_TLCG;                  
	fieldSet::ConstFieldAccess QTD_ERR_NAO_ATND_INCZ;                  
	fieldSet::ConstFieldAccess QTD_ERR_NAO_ATND_TLCG;                  
	fieldSet::ConstFieldAccess QTD_ERR_FLHA_ANXO_INCZ;                
	fieldSet::ConstFieldAccess QTD_ERR_FLHA_ANXO_TLCG;                 
	fieldSet::ConstFieldAccess QTD_ERR_FLHA_TCP_INCZ;                  
	fieldSet::ConstFieldAccess QTD_ERR_FLHA_TCP_TLCG;                  
	fieldSet::ConstFieldAccess TMPO_CNCT_TLCG;                         
	fieldSet::ConstFieldAccess TMPO_CNCT_INCZ;                         
	fieldSet::ConstFieldAccess NUM_TEL_CRGA_RMT;                       
	fieldSet::ConstFieldAccess NUM_IP_CNFG;
	fieldSet::ConstFieldAccess m_local_date;
	fieldSet::ConstFieldAccess m_local_time;
	fieldSet::ConstFieldAccess m_nom_site_issr;
	fieldSet::ConstFieldAccess m_nom_host_issr;
	fieldSet::ConstFieldAccess m_nom_fe_issr;
	fieldSet::ConstFieldAccess m_msg_name;
	fieldSet::ConstFieldAccess m_orig_transcode;

  };
} 

  
