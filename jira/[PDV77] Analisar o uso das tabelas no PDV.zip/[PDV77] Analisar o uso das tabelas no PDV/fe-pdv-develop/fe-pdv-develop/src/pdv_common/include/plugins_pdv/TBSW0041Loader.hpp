/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0041Loader( );
	class TBSW0041Loader : public dataManip::Command
	{
		enum tableFields
		{
			RESULT, NUM_PDV, COD_BNDR, QTD_MXO_PRCL, COD_STTU_REG, DAT_ATLZ_REG, COD_BCO_CMPS, COD_AGE, NUM_CTA_BNCR, DAT_INI_COB_ANT, DAT_INI_COB_ATU, TIP_COB_TRAN_ANT, TIP_COB_TRAN_ATU, VAL_COB_TRAN_ANT, VAL_COB_TRAN_ATU, COD_TRAN, IND_PERM_TRAN_DGTD_EMSR, IND_MODL_CPTR, TB_FIELDS_SIZE
		};
		enum sourceFields
		{
			TERMLOC, COD_TRANS, BNDR, LAST_SOURCE_FIELD
		};
	public:
		TBSW0041Loader( );
		TBSW0041Loader( const std::string &str );
		virtual ~TBSW0041Loader( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		TBSW0041Loader& setSourceFieldPath( const std::string& a_path );
		TBSW0041Loader& setTargetFieldPath( const std::string& a_path );
		TBSW0041Loader& setResult( const std::string& a_result );
		std::string getResult( );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_targetField[TB_FIELDS_SIZE];
		fieldSet::FieldAccess m_sourceField[LAST_SOURCE_FIELD];
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_result;
	};
}

