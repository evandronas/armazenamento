/* Copyright 2019 Rede S.A.
Autor : Fernando Brum
Empresa : Rede
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "dbaccess_pdv/Tbsw0165.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTbsw0165Inserter( );

    /// Tbsw0165Inserter
    /// Insere registro da tabela Tbsw0165
    /// EF/ET: ET1
    /// Historico: [Data] – [Autor] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    class Tbsw0165Inserter : public dataManip::Command
    {
        public:
            Tbsw0165Inserter( );
            Tbsw0165Inserter( const std::string &stringValue );
            virtual ~Tbsw0165Inserter( );

            bool init( ); // metodo herdado da classe base
            void finish( );  // metodo herdado da classe base
            int execute( bool& stopExecute );  // metodo herdado da classe base
            dataManip::Command* clone( ) const;  // metodo herdado da classe base

            Tbsw0165Inserter& SetSourceFieldPath( const std::string& valuePath );
            Tbsw0165Inserter& SetTargetFieldPath( const std::string& valuePath );

        private:
            // metodo executado pela engine fwsw e herdado da classe base
            bool startConfiguration( const configBase::Tag* configTag );

            dbaccess_pdv::Tbsw0165 memberTable;
            
            std::string sourceFieldPath;
            std::string targetFieldPath;

            fieldSet::FieldAccess result;
            
            fieldSet::ConstFieldAccess dataMovimentoTransacao;
            fieldSet::ConstFieldAccess numeroSequencialUnico;
            fieldSet::ConstFieldAccess paymentFacilitator;
            fieldSet::ConstFieldAccess codigoSubLojista;
            fieldSet::ConstFieldAccess cnpjSubLojista;
            fieldSet::ConstFieldAccess enderecoSubLojista;
            fieldSet::ConstFieldAccess nomeSubLojista;
            fieldSet::ConstFieldAccess cidadeSubLojista;
            fieldSet::ConstFieldAccess paisSubLojista;
            fieldSet::ConstFieldAccess cepSubLojista;
            fieldSet::ConstFieldAccess estadoSubLojista;            
    }; // class Tbsw0165Inserter

} // namespace plugins_pdv
