/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o: Plugin para parsear o track2
/ Conte�do:
/ Autor: t694450, Lauro Sanches
/ Data de Cria��o: 2013, 28 de maio
/ Hist�rico Mudan�as: 2013, 28 de maio, t694450, Lauro Sanches
/ -------------------------------------------------------------------------------------------------
*/
#pragma once

#include "dataManip/Command.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createGetExpiryDate();
    
    class GetExpiryDate : public dataManip::Command
    {
    public:
        GetExpiryDate();
        virtual ~GetExpiryDate();
    
        bool init();
        void finish();
        int execute( bool& a_stop );
        dataManip::Command* clone() const;
        
        GetExpiryDate& setSourceFieldPath( const std::string& a_path );
        GetExpiryDate& setTargetFieldPath( const std::string& a_path );

    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        std::string m_targetFieldPath;
        std::string m_sourceFieldPath;
        
        fieldSet::FieldAccess m_track2;
        fieldSet::FieldAccess m_track3;
        fieldSet::FieldAccess m_expiry_date;
    };
}
