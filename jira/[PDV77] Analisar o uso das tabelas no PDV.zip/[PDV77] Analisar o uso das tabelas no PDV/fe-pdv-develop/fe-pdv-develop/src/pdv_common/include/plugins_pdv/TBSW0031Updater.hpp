#pragma once
#include "TBSW0031.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0031Updater( );

    class TBSW0031Updater : public dataManip::Command
    {
        public:
            TBSW0031Updater( );
            virtual ~TBSW0031Updater( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0031Updater& setSourceFieldPath( const std::string& a_path );
            TBSW0031Updater& setTargetFieldPath( const std::string& a_path );
            TBSW0031Updater& setLocalFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;

            fieldSet::FieldAccess      m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_msgtype;
            fieldSet::ConstFieldAccess m_origrefnum;
            fieldSet::ConstFieldAccess m_origdate;
            fieldSet::ConstFieldAccess m_iss_name;
            fieldSet::ConstFieldAccess m_ext_refnum;
            fieldSet::ConstFieldAccess m_status;
            fieldSet::ConstFieldAccess m_is_van;
            fieldSet::ConstFieldAccess m_mc_info_prod_code;
            fieldSet::ConstFieldAccess m_mc_info_region;
            fieldSet::ConstFieldAccess m_num_ref_tran;
            fieldSet::ConstFieldAccess m_cod_cpcd_term;
    }; // class TBSW0031Updater
} // namespace plugins_pdv
