#pragma once

#include <TBSW0084RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0084RegrasFormatacao : public TBSW0084RegrasFormatacaoBase
    {
        public:
            TBSW0084RegrasFormatacao( );
            ~TBSW0084RegrasFormatacao( );
    };
}