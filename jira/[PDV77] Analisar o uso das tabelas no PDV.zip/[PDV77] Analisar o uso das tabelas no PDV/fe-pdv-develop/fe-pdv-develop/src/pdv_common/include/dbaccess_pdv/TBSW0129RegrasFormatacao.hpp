#pragma once

#include <TBSW0129RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0129RegrasFormatacao : public TBSW0129RegrasFormatacaoBase
    {
        public:
            TBSW0129RegrasFormatacao( );
            ~TBSW0129RegrasFormatacao( );
    };
}