/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0157Inserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0157Inserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor:
/ Data de Cria��o:
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "TBSW0157.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
  extern "C" base::Identificable* createTBSW0157Inserter();

  class TBSW0157Inserter : public dataManip::Command
  {
  public:
             TBSW0157Inserter();
    virtual ~TBSW0157Inserter();

    bool init();
    void finish();
    int execute( bool& a_stop );
    dataManip::Command* clone() const;

    TBSW0157Inserter& setSourceFieldPath( const std::string& a_path );
    TBSW0157Inserter& setTargetFieldPath( const std::string& a_path );
    TBSW0157Inserter& setLocalFieldPath( const std::string& a_path );

  private:
    bool startConfiguration( const configBase::Tag* a_tag );

    std::string m_sourceFieldPath;
    std::string m_targetFieldPath;
    std::string m_localFieldPath;

    fieldSet::FieldAccess m_result;

    fieldSet::ConstFieldAccess m_local_date;     // DAT_MOV_TRAN
    fieldSet::ConstFieldAccess m_refnum;         // NUM_SEQ_UNC
    fieldSet::ConstFieldAccess m_cod_service;    // COD_SERV_TRAN
    fieldSet::ConstFieldAccess m_pv_fisico;      // NUM_PDV_ORG_TRAN
    fieldSet::ConstFieldAccess m_term_fisico;    // COD_TERM_ORG_TRAN
    fieldSet::ConstFieldAccess m_ddd_celular;    // NUM_DDD_RCRG
    fieldSet::ConstFieldAccess m_num_celular;    // NUM_TEL_RCRG
    fieldSet::ConstFieldAccess m_nsu_operadora;  // NUM_SEQ_UNC_OPER

  };
}

