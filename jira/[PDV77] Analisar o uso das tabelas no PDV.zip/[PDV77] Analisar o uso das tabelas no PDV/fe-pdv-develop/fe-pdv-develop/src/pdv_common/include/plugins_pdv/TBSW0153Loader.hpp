#pragma once
#include "TBSW0153.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0153Loader( );

    class TBSW0153Loader : public dataManip::Command
    {
        public:
            TBSW0153Loader( );
            virtual ~TBSW0153Loader( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0153Loader& setSourceFieldPath( const std::string& a_path );
            TBSW0153Loader& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess m_result;

            fieldSet::FieldAccess m_dat_mov_tran;
            fieldSet::FieldAccess m_num_seq_unc;
            fieldSet::FieldAccess m_num_emsr;
            fieldSet::FieldAccess m_ind_val_apr_sldo_dspl;
            fieldSet::FieldAccess m_val_eftv_aprv;
            fieldSet::FieldAccess m_num_rtdr_trk;
            fieldSet::FieldAccess m_dth_vd_term;
            fieldSet::FieldAccess m_cod_mot_aprv_ofln;

            fieldSet::ConstFieldAccess m_nsu;
            fieldSet::ConstFieldAccess m_dat_tran;

    }; // class TBSW0153Loader

} // namespace plugins_pdv


