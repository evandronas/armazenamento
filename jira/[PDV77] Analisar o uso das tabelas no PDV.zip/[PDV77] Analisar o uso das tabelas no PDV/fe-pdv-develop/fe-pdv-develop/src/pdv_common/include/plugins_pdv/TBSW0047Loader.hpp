/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0047Loader( );
	class TBSW0047Loader : public dataManip::Command
	{
		enum tableFields
		{
			RESULT, COD_BCO_CMPS, COD_INT_BCO, COD_MODO_OPE_BCO, COD_MODO_PLTO, IND_OPE_CDC, DAT_VIG_CDC, IND_OPE_PRCI, DAT_VIG_PRCI, DAT_VIG_PDA, IND_OPE_GRNT_CHQ, IND_SIT_BCO, IND_SIT_BCO_ESTB, NOM_BCO_CMPL, TMS_INCL, COD_STTU_REG, IND_OPE_PDA, DAT_VIG_GRNT_CHQ, LAST_FIELD
		};
		enum sourceFields
		{
			NU_BCO_ETB, LAST_SOURCE_FIELD
		};
	public:
		TBSW0047Loader( );
		TBSW0047Loader( const std::string &str );
		virtual ~TBSW0047Loader( );
		bool init( );
		void finish( );
		int execute( bool& a_stop );
		dataManip::Command* clone( ) const;
		TBSW0047Loader& setSourceFieldPath( const std::string& a_path );
		TBSW0047Loader& setTargetFieldPath( const std::string& a_path );
		TBSW0047Loader& setResult( const std::string& a_result );
		std::string getResult( );
	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		fieldSet::FieldAccess m_targetField[LAST_FIELD];
		fieldSet::FieldAccess m_sourceField[LAST_SOURCE_FIELD];
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		std::string m_result;
	};
}

