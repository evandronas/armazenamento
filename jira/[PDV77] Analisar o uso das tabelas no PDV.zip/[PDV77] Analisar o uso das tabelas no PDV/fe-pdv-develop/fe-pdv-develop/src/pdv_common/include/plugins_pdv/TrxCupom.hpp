/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TrxCupom>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TrxCupom>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694451, Ricardo Deus>
/ Data de Criação: 
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ <Data, Módulo, Autor, Descrição da Mudança>
/ <26.06.2013, 694449 (Fernando Ramires), inclusao do tratamento do cupom>
/ ---------------------------------------------------------------------------
*/

#pragma once

//=========================================================================//
// Includes
//=========================================================================//

#include <time.h>
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbm.h"
#include "syslg.h"
#include "debug.h"
#include "ist_cfg.h"

//=========================================================================//
// Defines
//=========================================================================//

#define SHC_REFNUM_LEN                  12
#define SHC_TERMLOC_LEN                 25
#define SHC_TERMID_LEN                  8
#define SHC_TRACK3_LEN                  104
#define SHC_TRACK2_LEN                  79
#define SHC_AUTHNUM_LEN                 6
#define SHC_FORMATTER_USE               255 
#define SHC_FILLER_LEN                  50
#define SMS_DATA_LEN                    128
#define MAX_BIT63_LEN                   640  
#define MAX_CFD_LEN                     171 
#define MAX_CODVER_LEN                  32
#define SHC_PAN_LEN                     19
#define BALANCE_VOUCHER                 amount9
#define DT_PRDT                         dt_pre_auz
#define MC_AUTHCODE                     44
#define MC_AUTHCODE_LEN                 6
#define FLAG_PREMIACAO                  (0x02)
#define FLAG_PREMIAVEL                  (0x04)
#define FLAG_TRANSACAO_PREMIADA         (0x08)
#define PROMO_MAX_ISSUER_ID             50
#define PROMO_MAX_COD_BND               20
#define PROMO_MAX_TRANSCODES            30
#define PROMO_MAX_ENTRY_MODE            20
#define PROMO_MAX_TECH_TYPE             25
#define CD_EMS                          auth_devcap
#define MAESTRO                         44
#define TABLE_ONE                       '1'
#define SYSLG_PREFIX                    "acqutil_receipt"
#define MAX_MEM_TABLES_PER_SET          25

//=========================================================================//
// Macros
//=========================================================================//

#define MM(x)                           ( ( ( x ) / 100 ) % 100 )
#define YY(x)                           ( ( ( x ) / 10000 ) % 100 )
#define FLAGS_ISSET( flags, f )         ( flags & ( f ) )
#define IsMerchIntl( m )                ( ( ( ( m ) / 1000 ) % 10 ) == 8 )
#define IS_CREDIARIO_LOJA( ecr_pcode, ir, iv )  ( ecr_pcode == 170000 && !IsReversal( ir ) && !IsVoid( iv ) )

//=========================================================================//
// Namespace
//=========================================================================//

namespace plugins_pdv
{
	using namespace std;

    // ============== Struct to Token ================
    struct _token
    {
        int id;
        char name[ 21 ];
        char len;
        char position;
        char left_zero;
        char decimal;
        char separator;
    };
    
    // =========== Create class ==============
    extern "C" base::Identificable* createTrxCupom( );
    class TrxCupom : public dataManip::Command
    {
        public:
            
            // ============== Basics =================
            TrxCupom( );
            TrxCupom( const std::string& str );
            virtual ~TrxCupom( );
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            
            // ========== Sets by targets ============
            TrxCupom& setTargetFieldPath( const std::string& a_path );
            TrxCupom& setSourceFieldPath( const std::string& a_path );
            TrxCupom& setLocalFieldPath( const std::string& a_path );
            
        private:
            
            // ============== Basics =================
            bool startConfiguration( const configBase::Tag* a_tag );
            
            //=======================================//
            // Tratamento do cupom
            //=======================================//
            
            // ========== General ============
            int getTranstype( short a_transcode );
            int IsReversal( char is_reversal );
            int IsVoid( char is_void );
            
            // ============== Voucher ================
            int voucherGetTrackGroup( );
            
            // ============ Lib capture ==============
            int get_exp_date( char* track2 );
            int get_exp_date_track3( char* track3 );
            
            // ================= VDA =================
            void binary_to_char( char* dest, char* orig, int len );
            void get_bit63data( char *dest );
            void get_additional_txn_data( short* in_qtd_ccl, short* in_pln_pgt, dec_t* vl_tot_trx );
            int convert_in_tpo_vda( int in_tpo_trx ); 
            int plabel_in_tpo_vda( int in_tpo_trx );
            
            // ================ Main =================
            struct _token* token_and_layout_init( );
            struct _token* get_token( char** wlayout, int* len );
            char* get_layout( char* type_key );
            char* format_receipt( char* type );
            int replace_token_on_receipt( struct _token *wtoken, char *wreceipt, int outstrlen );
            void createDemoCupom( );
            int createCupom( );
            
            // Padronizacao Crediario PDV - INICIO
            int MascararDocumento( const string &documento, const string &mascara, char *documentoFormatado );
            // Padronizacao Crediario PDV - FIM

			/** 
			 * Seleciona a chave do cupom de acordo com a versao do PDV
			 * @param formatType Chave destino
			 * @param formatType1 Chave do cupom se PDV com versao >= 6.00
			 * @param formatType2 Chave do cupom se PDV com versao < 6.00
			 */			
			void voucherFormatType( string &formatType, 
	                                const string &formatType1,
									const string &formatType2 );
            
            // ========= DynamicFieldAccess ==========
            fieldSet::FieldAccess m_respTxt;
            fieldSet::FieldAccess m_termloc;
            // ========== ConstFieldAccess ===========
            fieldSet::ConstFieldAccess m_cod_prdc_term;
            fieldSet::ConstFieldAccess m_msgType;
            fieldSet::ConstFieldAccess m_posEntryCode;
            fieldSet::ConstFieldAccess m_ecrCVM;
            fieldSet::ConstFieldAccess m_acquirerData;
            fieldSet::ConstFieldAccess m_addresponse;
            fieldSet::ConstFieldAccess m_ecrPcode;
            fieldSet::ConstFieldAccess m_avsRespcode;
            fieldSet::ConstFieldAccess m_isVoid;
            fieldSet::ConstFieldAccess m_merCatCode;
            fieldSet::ConstFieldAccess m_installNum;
            fieldSet::ConstFieldAccess m_origTranscode;
            fieldSet::ConstFieldAccess m_ecrOrigElems;
            fieldSet::ConstFieldAccess m_ecrMsgtype;
            fieldSet::ConstFieldAccess m_authDevcap;
            fieldSet::ConstFieldAccess m_isReversal;
            fieldSet::ConstFieldAccess m_codTrans;
            fieldSet::ConstFieldAccess m_origPan;
            fieldSet::ConstFieldAccess m_termid;
            fieldSet::ConstFieldAccess m_filler3;
            fieldSet::ConstFieldAccess m_pay_code;
            fieldSet::ConstFieldAccess m_origrefnum;
            fieldSet::ConstFieldAccess m_fee; 
            fieldSet::ConstFieldAccess m_vl_pca_ent; 
            fieldSet::ConstFieldAccess m_install_num;
            fieldSet::ConstFieldAccess m_install_amt;
            fieldSet::ConstFieldAccess m_actual_amount;
            fieldSet::ConstFieldAccess m_mer_name;
            fieldSet::ConstFieldAccess m_orig_pan;
            fieldSet::ConstFieldAccess m_cardholder_name;
            fieldSet::ConstFieldAccess m_bit63len; 
            fieldSet::ConstFieldAccess m_bit63;
            fieldSet::ConstFieldAccess m_bit63_issuer;
            fieldSet::ConstFieldAccess m_dt_vdd_pre_auz; 
            fieldSet::ConstFieldAccess m_vl_txa;
            fieldSet::ConstFieldAccess m_chip_full_data;
            fieldSet::ConstFieldAccess m_chip_full_data_len;
            fieldSet::ConstFieldAccess m_codver;
            fieldSet::ConstFieldAccess m_vl_iof;
            fieldSet::ConstFieldAccess m_pct_tx_x_mes;
            fieldSet::ConstFieldAccess m_pct_tx_x_ano;
            fieldSet::ConstFieldAccess m_pct_juro_mora;
            fieldSet::ConstFieldAccess m_dt_pri_prcl;
            fieldSet::ConstFieldAccess m_valor_tarifa;
            fieldSet::ConstFieldAccess m_valor_tributos;
            fieldSet::ConstFieldAccess m_valor_seguro;
            fieldSet::ConstFieldAccess m_valor_pag_terceiros;
            fieldSet::ConstFieldAccess m_is_reversal;
            fieldSet::ConstFieldAccess m_is_void;
            fieldSet::ConstFieldAccess m_flags;
            fieldSet::ConstFieldAccess m_avs_cep;
            fieldSet::ConstFieldAccess m_voucher_group_name;
            fieldSet::ConstFieldAccess m_voucher_footer;
            fieldSet::ConstFieldAccess m_auth_devcap;
            fieldSet::ConstFieldAccess m_cd_ems;
            fieldSet::ConstFieldAccess m_settlement_date;
            fieldSet::ConstFieldAccess m_cash_back;
            fieldSet::ConstFieldAccess m_authnum;
            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_local_time;
            fieldSet::ConstFieldAccess m_track3;
            fieldSet::ConstFieldAccess m_track2;
            fieldSet::ConstFieldAccess m_acquirer_data;
            fieldSet::ConstFieldAccess m_filler1;
            fieldSet::ConstFieldAccess m_filler2;
            fieldSet::ConstFieldAccess m_pcode;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_amount;
            //fieldSet::ConstFieldAccess m_termloc;
            fieldSet::ConstFieldAccess m_trace;
            fieldSet::ConstFieldAccess m_formatter_use;
            fieldSet::ConstFieldAccess m_bin;
            fieldSet::ConstFieldAccess m_ecr_pcode;
            fieldSet::ConstFieldAccess m_transcode;
            fieldSet::ConstFieldAccess m_cet_mensal;
            fieldSet::ConstFieldAccess m_cet_anual;
            fieldSet::ConstFieldAccess m_ecr_msgtype;
            fieldSet::ConstFieldAccess m_isIntlTrx;
            fieldSet::ConstFieldAccess m_has_pin;
            fieldSet::ConstFieldAccess m_versao_aplicativo;
            fieldSet::ConstFieldAccess m_cod_ocorr;
            fieldSet::ConstFieldAccess m_data_baixa;
            fieldSet::ConstFieldAccess m_hora_baixa;
            fieldSet::ConstFieldAccess isFallback;
            fieldSet::ConstFieldAccess isContactless;
            fieldSet::ConstFieldAccess nomeModoEntrada;
            fieldSet::ConstFieldAccess applicationIdentifier;
            fieldSet::ConstFieldAccess applicationLabel;
			
			fieldSet::ConstFieldAccess m_numero_parcelas;
			fieldSet::ConstFieldAccess m_plano_pagamento;
			fieldSet::ConstFieldAccess m_numero_ciclos;
            
            // Release Bandeiras PDV - Abril 2019 - INICIO
            fieldSet::ConstFieldAccess indicadorModoEntrada;
            // Release Bandeiras PDV - Abril 2019 - FIM
            
            // Padronizacao Crediario PDV - INICIO
            fieldSet::ConstFieldAccess messageName;
            fieldSet::ConstFieldAccess merchantDocument;
            fieldSet::ConstFieldAccess informationCrediario;
            fieldSet::ConstFieldAccess complementoCrediario;
            // Padronizacao Crediario PDV - FIM

			// Nava - EAK-2319
			fieldSet::ConstFieldAccess messageIssuerName;
            
            // ========= Fields for Cupom ============
            bool m_cvForPrivateLabel;
            std::string m_formatType;
			std::string m_receipt;
            std::string m_trailerType;
            std::string m_cupomOrigPan;
            std::string m_cupomTermid;
            
            std::string m_targetFieldPath;
            std::string m_sourceFieldPath;
            std::string m_localFieldPath;
            
            int g_promo_LinesCount;
            char trailer[ 1024 ];
            char prm_msg[ 24 ];
            _token* token;
            char* layout_start;
            int g_promo_init;
            long prm_local_date;
            long* ap_data_ini_piloto;
            long* ap_data_fim_piloto;
            long* ap_data_ini_promocao;
            long* ap_data_fim_promocao;
            char* ap_msg_premiada_piloto;
            char* ap_msg_premiada_promocao;
            char* ap_msg_nao_premiada_piloto;
            char* ap_msg_nao_premiada_promocao;
            char* ap_msg_nao_premiavel_piloto;
            char* ap_msg_nao_premiavel_promocao;
            int debugFlag;
            int cv_for_private_label;
            int pos_entry_code;
            char *reason_code;
            long mer_cat_code;

			// Nava - EAK-2319
			std::string issuerName;
            
            // ========== Struct used in 71 ==========
            char bin[ 11 ];
            long dt_pre_auz;
            long auth_devcap;
            long pcode;
            long transcode;
            int ecr_pcode;
            short ecr_msgtype;
            short cd_ems;
            char refnum[ SHC_REFNUM_LEN + 1 ];
            dec_t amount;
            dec_t amount8;
            dec_t amount2;
            dec_t amount9;
            long settlement_date;
            long local_date;
            dec_t cash_back;
            char termloc[ SHC_TERMLOC_LEN + 1 ];
            long local_time;
            char termid[ SHC_TERMID_LEN + 1 ];
            long trace;
            char track3[ SHC_TRACK3_LEN + 1 ];
            char track2[ SHC_TRACK2_LEN + 1 ];
            int track2Leng;
            char authnum[ SHC_AUTHNUM_LEN + 1 ];
            char formatter_use[ SHC_FORMATTER_USE + 1];
            char filler1[ SHC_FILLER_LEN + 1 ];
            char filler2[ SHC_FILLER_LEN + 1 ];
            char acquirer_data[ SMS_DATA_LEN + 1 ];
            float cet_mensal;
            float cet_anual;
            short pay_code;
            char origrefnum[ 12 + 1 ];
            dec_t fee; 
            dec_t vl_pca_ent; 
            short install_num;
            dec_t install_amt;
            dec_t actual_amount;
            char mer_name[ 23 + 1 ];
            char orig_pan[ SHC_PAN_LEN + 1 ];
            char cardholder_name[ 30 + 1 ];
            short bit63len; 
            char bit63[ MAX_BIT63_LEN ];
            long dt_vdd_pre_auz; 
            dec_t vl_txa;
            char chip_full_data[ MAX_CFD_LEN ];
            short chip_full_data_len;
            char codver[ MAX_CODVER_LEN + 1 ];
            float vl_iof;
            float pct_tx_x_mes;
            float pct_tx_x_ano;
            float pct_juro_mora;
            long dt_pri_prcl;
            char valor_tarifa[ 7 + 1 ];
            char valor_tributos[ 7 + 1 ];
            char valor_seguro[ 7 + 1 ];
            char valor_pag_terceiros[ 7 + 1 ];
            char is_reversal;
            char is_void;
            unsigned char flags;
            char avs_cep[ 9 + 1 ];
            char voucher_group_name[ 24 ];
            char voucher_footer[ 24 ];
            
            char cod_ocorr[ 8 + 1 ];
            char data_baixa[ 6 + 1 ];
            char hora_baixa[ 4 + 1 ];
            
            char textoIsFallback[ 5 + 1 ];
            char textoIsContactless[ 5 + 1 ];
            char textoNomeModoEntrada[ 5 + 1 ];

            char textoApplicationIdentifier[ 32 + 1 ];
            char textoApplicationLabel[ 16 + 1 ];

            fieldSet::ConstFieldAccess m_saldo_disp;
            dec_t saldo_disp;
            
            int lECRSftwVerid;
            int isIntlTrx;

			float valorTaxa;
			float valorVenda;
    };
}

