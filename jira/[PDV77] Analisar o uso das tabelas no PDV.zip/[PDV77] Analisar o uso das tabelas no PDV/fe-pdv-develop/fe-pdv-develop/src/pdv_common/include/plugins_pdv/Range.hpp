/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Teller
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t689064, Raphael Teller, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <iostream>


namespace plugins_pdv
{
	class Range
	{
	public:
		Range();
		virtual ~Range();

		long getCOD_ROTA() const;
		const std::string& getNUM_BIN_CAR_INI() const;
		const std::string& getNUM_BIN_CAR_FIM() const;
		long getCOD_ISSR_SW() const;
		const std::string& getCOD_TIP_TRAN() const;
		long getIND_PRRD() const;
		const std::string& getNETWORK_ID() const;
		const std::string& getNETWORK_ID_VAN() const;
		const std::string& getNOM_HOST_ACQR() const;
		const std::string& getNOM_FE_ACQR() const;
		const std::string& getNOM_EMSR_SW() const;
		long getCOD_EMSR_SW() const;
		long getCOD_BNDR() const;
		long getCOD_FE_EMSR() const;
		bool getIS_VALID() const;

		void setCOD_ROTA( long a_COD_ROTA );
		void setNUM_BIN_CAR_INI( const std::string& a_NUM_BIN_CAR_INI );
		void setNUM_BIN_CAR_FIM( const std::string& a_NUM_BIN_CAR_FIM );
		void setCOD_ISSR_SW( long a_COD_ISSR_SW );
		void setCOD_TIP_TRAN( const std::string& a_COD_TIP_TRAN );
		void setIND_PRRD( long a_IND_PRRD );
		void setNETWORK_ID( const std::string& a_NETWORK_ID );
		void setNETWORK_ID_VAN( const std::string& a_NETWORK_ID_VAN );
		void setNOM_HOST_ACQR( const std::string& a_NOM_HOST_ACQR );
		void setNOM_FE_ACQR( const std::string& a_NOM_FE_ACQR );
		void setNOM_EMSR_SW( const std::string& a_NOM_EMSR_SW );
		void setCOD_EMSR_SW( long a_COD_EMSR_SW );
		void setCOD_BNDR( long a_COD_BNDR );
		void setCOD_FE_EMSR( long a_COD_FE_EMSR );
		void setIS_VALID( bool a_boolean );

	private:
		long m_COD_ROTA;
		std::string m_NUM_BIN_CAR_INI;
		std::string m_NUM_BIN_CAR_FIM;
		long m_COD_ISSR_SW;
		std::string m_COD_TIP_TRAN;
		long m_IND_PRRD;
		std::string m_NETWORK_ID;
		std::string m_NETWORK_ID_VAN;
		std::string m_NOM_HOST_ACQR;
		std::string m_NOM_FE_ACQR;
		std::string m_NOM_EMSR_SW;
		long m_COD_EMSR_SW;
		long m_COD_BNDR;
		long m_COD_FE_EMSR;
		bool m_IS_VALID;
	};
}

