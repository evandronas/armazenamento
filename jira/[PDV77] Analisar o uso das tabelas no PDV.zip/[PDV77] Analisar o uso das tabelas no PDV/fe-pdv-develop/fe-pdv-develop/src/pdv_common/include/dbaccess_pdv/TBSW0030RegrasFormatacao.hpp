#pragma once

#include<TBSW0030RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
class TBSW0030RegrasFormatacao : public TBSW0030RegrasFormatacaoBase
{
public:
    TBSW0030RegrasFormatacao( );
    ~TBSW0030RegrasFormatacao( );
    
    void insert_NUM_RD_ORG( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );
    void insert_TIP_TRAN_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );
    void insert_VAL_TX( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );
    void insert_COD_SERV_CORP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );
    void insert_COD_DSPO_NFC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );
    void update_VAL_TX( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );
    void update_NUM_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );
    void insert_IND_DA_RLCD_IATA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );
    void update_DTH_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params );

private:
    void GetNow( unsigned long *day, unsigned long *hour );
};
} //dbaccess_pdv
