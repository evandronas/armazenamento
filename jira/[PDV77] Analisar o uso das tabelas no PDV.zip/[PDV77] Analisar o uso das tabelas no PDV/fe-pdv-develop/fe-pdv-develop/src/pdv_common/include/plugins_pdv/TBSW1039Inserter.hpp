#pragma once
#include "TBSW1039.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW1039Inserter( );

    class TBSW1039Inserter : public dataManip::Command
    {
        public:
            TBSW1039Inserter( );
            virtual ~TBSW1039Inserter( );
            
            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;
            
            TBSW1039Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW1039Inserter& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            
            fieldSet::FieldAccess m_result;

            fieldSet::ConstFieldAccess  m_local_date;
            fieldSet::ConstFieldAccess  m_refnum;
            fieldSet::ConstFieldAccess  m_origpcode;
            fieldSet::ConstFieldAccess  m_origmsg;
            fieldSet::ConstFieldAccess  m_origtrace;
            fieldSet::ConstFieldAccess  m_ecr_acqinst_id;
            fieldSet::ConstFieldAccess  m_origdate;
            fieldSet::ConstFieldAccess  m_origtime;

    }; // class TBSW1039Inserter

} // namespace plugins_pdv
