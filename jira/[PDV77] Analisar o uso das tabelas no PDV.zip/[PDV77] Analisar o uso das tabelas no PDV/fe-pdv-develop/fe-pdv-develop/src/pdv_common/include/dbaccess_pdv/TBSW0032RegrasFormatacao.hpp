#pragma once

#include <TBSW0032RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
    class TBSW0032RegrasFormatacao : public TBSW0032RegrasFormatacaoBase
    {
        public:
            TBSW0032RegrasFormatacao( );
            ~TBSW0032RegrasFormatacao( );
            void insert_VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
    };
}
