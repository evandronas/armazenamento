#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
	extern "C" base::Identificable* createTBSW0033Updater();

	class TBSW0033Updater : public dataManip::Command
	{
	public:
        TBSW0033Updater();
		virtual ~TBSW0033Updater();
		
		bool init();
		void finish();
		int execute( bool& a_stop );
		dataManip::Command* clone() const;
		
		TBSW0033Updater& setSourceFieldPath( const std::string& a_path );
		TBSW0033Updater& setTargetFieldPath( const std::string& a_path );

	private:
		bool startConfiguration( const configBase::Tag* a_tag );
		
		std::string m_sourceFieldPath;
		std::string m_targetFieldPath;
		
		fieldSet::FieldAccess m_result;
        
		fieldSet::ConstFieldAccess m_local_date;
		fieldSet::ConstFieldAccess m_refnum;
		fieldSet::ConstFieldAccess m_msg_name;
        
        fieldSet::ConstFieldAccess m_nu_rv;
        fieldSet::ConstFieldAccess m_dt_rv;
        
        fieldSet::ConstFieldAccess enderecoFantasia;
        fieldSet::ConstFieldAccess cpf;
        fieldSet::ConstFieldAccess respcode;

        fieldSet::ConstFieldAccess codigoMembroBandeira;
        fieldSet::ConstFieldAccess nomeEmissor;
	};
}

