/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0093Updater>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0093Updater>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <698224, Raphael Gomes>
/ Data de Cria��o: <Fri Oct 26 15:21:52 2012
>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0093Updater();
    class TBSW0093Updater : public dataManip::Command
    {
     public:
        TBSW0093Updater();
        TBSW0093Updater( const std::string& str );
        virtual ~TBSW0093Updater( );
        bool init( );
        void finish( );
        int execute( bool& a_stop );
        dataManip::Command* clone( ) const;
        TBSW0093Updater& setTargetFieldPath( const std::string& a_path );
        TBSW0093Updater& setSourceFieldPath( const std::string& a_path );
    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        
        fieldSet::FieldAccess m_result;
        fieldSet::ConstFieldAccess m_local_date;
        fieldSet::ConstFieldAccess m_refnum;
        fieldSet::ConstFieldAccess m_msgtype;
        fieldSet::ConstFieldAccess m_origrefnum; 
        fieldSet::ConstFieldAccess m_origdate;
        fieldSet::ConstFieldAccess m_pb_reason_code;
		fieldSet::ConstFieldAccess m_ext_network_code;
		fieldSet::ConstFieldAccess m_settlement_date;
        
        std::string m_targetFieldPath;
        std::string m_sourceFieldPath;
    };
}




