#pragma once
#include "TBSW0031.hpp"
#include "dataManip/Command.hpp"
#include "fieldSet/FieldAccess.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0031Inserter( );

    class TBSW0031Inserter : public dataManip::Command
    {
        public:
            TBSW0031Inserter( );
            virtual ~TBSW0031Inserter( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0031Inserter& setSourceFieldPath( const std::string& a_path );
            TBSW0031Inserter& setTargetFieldPath( const std::string& a_path );

        private:
            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;

            fieldSet::FieldAccess      m_result;

            fieldSet::ConstFieldAccess m_local_date;
            fieldSet::ConstFieldAccess m_refnum;
            fieldSet::ConstFieldAccess m_ind_term_flex;
            fieldSet::ConstFieldAccess m_ctah;
            fieldSet::ConstFieldAccess m_num_ref_tran;
            fieldSet::ConstFieldAccess m_cod_cpcd_term;
            fieldSet::ConstFieldAccess infoCodigoProdutoMastercard; /// mc_info_prod_code
            fieldSet::ConstFieldAccess infoRegiaoMastercard; /// mc_info_region
            fieldSet::ConstFieldAccess categoriaMensagem;
            fieldSet::ConstFieldAccess nomeIssuer;

    }; // class TBSW0031Inserter
} // namespace plugins_pdv
