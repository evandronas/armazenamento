#pragma once

#include<TBSW0035RegrasFormatacaoBase.hpp>

namespace dbaccess_pdv
{
	class TBSW0035RegrasFormatacao : public TBSW0035RegrasFormatacaoBase
	{
	public:
		TBSW0035RegrasFormatacao( );
		~TBSW0035RegrasFormatacao( );
		
		void insert_DTH_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_COD_ORDM_SERV( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_COD_OCOR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_NUM_TEL_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_TXT_ENDR_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_COD_ID_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_COD_EPS( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_COD_VERS_KRN ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_NOM_FNTS_PT_DE_VD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
		void insert_NUM_TEL_ADIC_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
	};
}