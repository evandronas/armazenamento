#pragma once
#include "dataManip/Command.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "logger/Logger.hpp"

namespace plugins_pdv
{
    extern "C" base::Identificable* createTraceTrap( );
    class TraceTrap : public dataManip::Command
    {
    public:
        TraceTrap( );
        virtual ~TraceTrap( );

        bool init( );
        void finish( );
        int execute( bool& a_stop );
        dataManip::Command* clone( ) const;
    private:
        bool startConfiguration( const configBase::Tag* a_tag );
        logger::Logger* m_logger;

        pid_t m_pid;

        fieldSet::ConstFieldAccess m_acq_name;
        fieldSet::ConstFieldAccess m_msgType;
        fieldSet::ConstFieldAccess m_pcode;
        fieldSet::ConstFieldAccess m_posEntryCode;
        fieldSet::ConstFieldAccess m_amount;
        fieldSet::ConstFieldAccess m_termloc;
        fieldSet::ConstFieldAccess m_terminal_pdv;
        fieldSet::ConstFieldAccess m_num_vers_clit;
        fieldSet::ConstFieldAccess m_DE47_56_num_cnpj;
        fieldSet::ConstFieldAccess m_TBSW0040_num_cnpj;

        std::string m_sourceFieldPath;
        std::string m_TBSW0040FieldPath;
    };
}//namespace plugins_pdv
