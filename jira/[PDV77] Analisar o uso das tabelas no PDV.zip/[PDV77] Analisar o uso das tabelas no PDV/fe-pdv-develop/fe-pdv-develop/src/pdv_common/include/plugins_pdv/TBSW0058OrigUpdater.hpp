/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0058OrigUpdater>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0058OrigUpdater>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <694611, Carlos Cesar>
/ Data de Cria��o: <2014, 07 de Maio>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <fieldSet/FieldAccess.hpp>
#include <dataManip/Command.hpp>

namespace plugins_pdv
{
    extern "C" base::Identificable* createTBSW0058OrigUpdater( );

    class TBSW0058OrigUpdater : public dataManip::Command
    {
        public:

            TBSW0058OrigUpdater( );
            virtual ~TBSW0058OrigUpdater( );

            bool init( );
            void finish( );
            int execute( bool& a_stop );
            dataManip::Command* clone( ) const;

            TBSW0058OrigUpdater& setSourceFieldPath( const std::string& a_path );
            TBSW0058OrigUpdater& setLocalFieldPath( const std::string& a_path );
            TBSW0058OrigUpdater& setTargetFieldPath( const std::string& a_path );

        private:

            bool startConfiguration( const configBase::Tag* a_tag );

            std::string m_sourceFieldPath;
            std::string m_targetFieldPath;
            std::string m_localFieldPath;

            fieldSet::FieldAccess m_result; 
            fieldSet::FieldAccess m_msgtype;	//cr689721@FIS - Data: 27/02/2015
            fieldSet::FieldAccess m_status;
            fieldSet::FieldAccess m_termloc;	//cr689721@FIS - Data: 28/08/2014 - Ref. BT72.982
            fieldSet::FieldAccess m_issuer;		//cr689721@FIS - Data: 27/02/2015
            fieldSet::FieldAccess m_acquirer;	//cr689721@FIS - Data: 27/02/2015
            fieldSet::FieldAccess m_refnum;
            fieldSet::FieldAccess m_msg_name; 
            fieldSet::FieldAccess dataLocalOriginal;
            fieldSet::FieldAccess m_origrefnum;
            fieldSet::FieldAccess m_install_num;
            fieldSet::FieldAccess m_termid_type;
            fieldSet::FieldAccess m_termid;
            fieldSet::FieldAccess m_local_date;
            fieldSet::FieldAccess m_local_time;
            fieldSet::FieldAccess m_status_trn_orig;
            fieldSet::ConstFieldAccess m_iss_name ;         
            fieldSet::ConstFieldAccess m_msg_category ;
            fieldSet::ConstFieldAccess amount;
    };
}


