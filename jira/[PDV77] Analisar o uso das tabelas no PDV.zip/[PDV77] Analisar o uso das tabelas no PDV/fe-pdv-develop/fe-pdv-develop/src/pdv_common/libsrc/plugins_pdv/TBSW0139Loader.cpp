#pragma once
#include <cstring>
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbaccess_pdv/TBSW0139RegrasFormatacao.hpp"
#include "plugins_pdv/TBSW0139Loader.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0139Loader()
    {
        TBSW0139Loader* l_new = new TBSW0139Loader;
        return l_new;
    }

    bool TBSW0139Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0139Loader::TBSW0139Loader()
    {
    }

    TBSW0139Loader::~TBSW0139Loader()
    {
    }

    bool TBSW0139Loader::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        m_target_cod_pnpd_pdv = this->navigate( m_targetFieldPath + ".COD_PNPD_PDV" );
        m_target_tip_cip = this->navigate( m_targetFieldPath + ".TIP_CIP" );                     
        m_target_num_vers_srvd_pdv = this->navigate( m_targetFieldPath + ".NUM_VERS_SRVD_PDV" ); 
        m_target_cod_vers_sftw = this->navigate( m_targetFieldPath + ".NUM_VERS_CLIT" );    
        m_target_num_vers_aplv_rcd = this->navigate( m_targetFieldPath + ".NUM_VERS_APLV_RCD" );    
        m_target_num_vers_sftw_bblt_pnpd = this->navigate( m_targetFieldPath + ".NUM_VERS_SFTW_BBLT_PNPD" ); 
        m_target_num_vers_espf_bblt_pnpd = this->navigate( m_targetFieldPath + ".NUM_VERS_ESPF_BBLT_PNPD" ); 
        m_target_cod_fbrc_pdv = this->navigate( m_targetFieldPath + ".COD_FBRC_PDV" );              
        m_target_cod_term = this->navigate( m_targetFieldPath + ".COD_TERM" ); 
        m_target_num_pdv = this->navigate( m_targetFieldPath + ".NUM_PDV" ); 
        m_target_dat_mov_tran = this->navigate( m_targetFieldPath + ".DAT_MOV_TRAN" ); 

        m_source_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" ); 
        m_source_terminal_pdv = this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" ); 

        return true;
    }

    void TBSW0139Loader::finish()
    {
    }

    int TBSW0139Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_local_date = 0;
            std::string l_cod_terminal_pdv;

            fieldSet::fsextr( l_local_date, m_source_local_date );
            fieldSet::fsextr( l_cod_terminal_pdv,   m_source_terminal_pdv );

            l_whereClause << "DAT_MOV_TRAN = " << l_local_date;
            if( strlen( l_cod_terminal_pdv.c_str() ) ) l_whereClause << " AND COD_TERM = '" << l_cod_terminal_pdv << "'";

            dbaccess_common::TBSW0139 l_TBSW0139( l_whereClause.str() );

            l_TBSW0139.prepare();
            l_TBSW0139.execute();
            int ret = l_TBSW0139.fetch();

            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "OK", 2 );

                fieldSet::fscopy( m_target_cod_term, l_TBSW0139.get_COD_TERM() );
                fieldSet::fscopy( m_target_dat_mov_tran, l_TBSW0139.get_DAT_MOV_TRAN() );
                fieldSet::fscopy( m_target_cod_pnpd_pdv, l_TBSW0139.get_COD_PNPD_PDV() );
                fieldSet::fscopy( m_target_tip_cip, l_TBSW0139.get_TIP_CIP() );
                fieldSet::fscopy( m_target_num_pdv, l_TBSW0139.get_NUM_PDV() );
                fieldSet::fscopy( m_target_num_vers_srvd_pdv, l_TBSW0139.get_NUM_VERS_SRVD_PDV() );
                fieldSet::fscopy( m_target_cod_vers_sftw, l_TBSW0139.get_NUM_VERS_CLIT() );
                fieldSet::fscopy( m_target_num_vers_aplv_rcd, l_TBSW0139.get_NUM_VERS_APLV_RCD() );
                fieldSet::fscopy( m_target_num_vers_sftw_bblt_pnpd, l_TBSW0139.get_NUM_VERS_SFTW_BBLT_PNPD() );
                fieldSet::fscopy( m_target_num_vers_espf_bblt_pnpd, l_TBSW0139.get_NUM_VERS_ESPF_BBLT_PNPD() );
                fieldSet::fscopy( m_target_cod_fbrc_pdv, l_TBSW0139.get_COD_FBRC_PDV() );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0139 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0139 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW0139Loader& TBSW0139Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0139Loader& TBSW0139Loader::setSourceFieldPath( const std::string& a_path )
    {
          m_sourceFieldPath = a_path;
          return *this;
    }

    dataManip::Command* TBSW0139Loader::clone() const
    {
        return new TBSW0139Loader(*this);
    }

}//namespace plugins_pdv
