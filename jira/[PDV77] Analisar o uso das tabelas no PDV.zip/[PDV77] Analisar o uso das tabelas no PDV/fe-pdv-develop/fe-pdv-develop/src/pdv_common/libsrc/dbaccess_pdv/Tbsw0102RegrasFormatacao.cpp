/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#include<dbaccess_pdv/Tbsw0102RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    Tbsw0102RegrasFormatacao::Tbsw0102RegrasFormatacao( )
    {
    }
    
    Tbsw0102RegrasFormatacao::~Tbsw0102RegrasFormatacao( )
    {
    }
}
