/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0073.hpp"
#include "plugins_pdv/TBSW0073Loader.hpp"

namespace plugins_pdv
{
	base::Identificable* createTBSW0073Loader( )
	{
		TBSW0073Loader* l_new = new TBSW0073Loader;
		return l_new;
	}
	bool TBSW0073Loader::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "sourceFieldPath", l_tagList );
		std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "targetFieldPath", l_tagList );
		std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setSourceFieldPath( l_sourcePath );
		this->setTargetFieldPath( l_targetPath );
		return true;
	}
	TBSW0073Loader::TBSW0073Loader( )
	{
	}
	TBSW0073Loader::~TBSW0073Loader( )
	{
	}
	bool TBSW0073Loader::init( )
	{
		std::string tb_components[]
		=
		{
			"RESULT", "COD_RAM_ATVD", "COD_STTU_REG", "QTD_DIA_PRZO_PRE_AUT"
		};
		for ( unsigned int i = 0; i < LAST_TB_FIELD; i++ )
		{
			m_targetField[i]
			= this->navigate( m_targetFieldPath + "." + tb_components[i] );
			if ( !m_targetField[i] )
			{
				std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ">" );
				this->enableError( true );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		std::string source_components[]
		=
		{
			"segments.merchant.mer_cat_code"
		};
		for ( unsigned int i = 0; i < LAST_SOURCE_FIELD; i++ )
		{
			m_sourceField[i]
			= this->navigate( m_sourceFieldPath + "." + source_components[i] );
			if ( !m_sourceField[i] )
			{
				std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + "." + source_components[i]
				+ ">" );
				this->enableError( true );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		return true;
	}
	void TBSW0073Loader::finish( )
	{
	}
	int TBSW0073Loader::execute( bool& a_stop )
	{
		try
		{
			std::ostringstream l_whereClause;
			long l_cod_ram_atvd = 0;
			fieldSet::fsextr( l_cod_ram_atvd, m_sourceField[MER_CAT_CODE] );
			l_whereClause << "COD_RAM_ATVD = " << l_cod_ram_atvd;
			dbaccess_common::TBSW0073 l_table0073( l_whereClause.str( ) );
			l_table0073.prepare( );
			l_table0073.execute( );
			int ret = l_table0073.fetch( );
			if ( !ret )
			{
				this->setResult( "NO ROWS" );
			}
			else
			{
				this->setResult( "OK" );
				fieldSet::fscopy( m_targetField[COD_RAM_ATVD], l_table0073.getCOD_RAM_ATVD( ) );
				fieldSet::fscopy( m_targetField[COD_STTU_REG], l_table0073.getCOD_STTU_REG( ) );
				fieldSet::fscopy( m_targetField[QTD_DIA_PRZO_PRE_AUT], l_table0073.getQTD_DIA_PRZO_PRE_AUT( ) );
			}
		}
		catch( base::GenException e )
		{
			this->setResult( "ERROR" );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0073 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0073[" + l_what + "]";
		}
		fieldSet::fscopy( m_targetField[0], getResult( ) );
		a_stop = false;
		return 0;
	}
	std::string TBSW0073Loader::getResult( )
	{
		return m_result;
	}
	TBSW0073Loader& TBSW0073Loader::setResult( const std::string& a_result )
	{
		m_result = a_result;
		return *this;
	}
	TBSW0073Loader& TBSW0073Loader::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	TBSW0073Loader& TBSW0073Loader::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	dataManip::Command* TBSW0073Loader::clone( ) const
	{
		return new TBSW0073Loader( *this );
	}
}//namespace plugins_pdv

