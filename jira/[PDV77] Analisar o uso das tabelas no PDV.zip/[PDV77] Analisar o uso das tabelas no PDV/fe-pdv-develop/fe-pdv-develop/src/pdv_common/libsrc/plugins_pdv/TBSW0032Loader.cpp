#pragma once
#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbaccess_pdv/TBSW0032RegrasFormatacao.hpp"
#include "plugins_pdv/TBSW0032Loader.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0032Loader()
    {
        TBSW0032Loader* l_new = new TBSW0032Loader;     
        return l_new;
    }

    TBSW0032Loader::TBSW0032Loader()
    {
    }

    TBSW0032Loader::~TBSW0032Loader()
    {
    }
  
    bool TBSW0032Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

        return true;    
    }
  
    bool TBSW0032Loader::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        m_num_bco_deb = this->navigate( m_targetFieldPath + ".NUM_BCO_DEB" );
        m_num_emsr = this->navigate( m_targetFieldPath + ".NUM_EMSR" );
        m_num_bco_estb = this->navigate( m_targetFieldPath + ".NUM_BCO_ESTB" );
        m_num_age_estb = this->navigate( m_targetFieldPath + ".NUM_AGE_ESTB" );
        m_cod_cta_estb = this->navigate( m_targetFieldPath + ".COD_CTA_ESTB" );
        m_cod_vd_bco = this->navigate( m_targetFieldPath + ".COD_VD_BCO" );
        m_ind_cnfr_pstv = this->navigate( m_targetFieldPath + ".IND_CNFR_PSTV" );
        m_val_sque = this->navigate( m_targetFieldPath + ".VAL_SQUE" );
        m_ind_impr_cpom = this->navigate( m_targetFieldPath + ".IND_IMPR_CPOM" );
        m_dat_mov_tran = this->navigate( m_targetFieldPath + ".DAT_MOV_TRAN" );
        m_num_seq_unc = this->navigate( m_targetFieldPath + ".NUM_SEQ_UNC" );
        m_qtd_dia_crnc = this->navigate( m_targetFieldPath + ".QTD_DIA_CRNC" );
        m_ind_car_mltp = this->navigate( m_targetFieldPath + ".IND_CAR_MLTP" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );                  
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );    
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );                

        return true;
    }

    void TBSW0032Loader::finish()
    {
    }

    int TBSW0032Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_msgtype, l_local_date, l_origdate, l_refnum, l_origrefnum;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );
            fieldSet::fsextr( l_msgtype, m_msgtype );                    
            fieldSet::fsextr( l_origrefnum, m_origrefnum );
            fieldSet::fsextr( l_origdate, m_origdate );

            switch ( l_msgtype )
            {
                case 100 :
                case 200 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
                    break;

                case 220 :
                case 400 :
                case 420 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
                    break;
                default:
                    fieldSet::fscopy( m_result, "EMPTY QUERY", 11 );
                    a_stop = false;
                    return 0;     
                    break;
            }

            dbaccess_common::TBSW0032 l_TBSW0032( l_whereClause.str() );

            l_TBSW0032.prepare();
            l_TBSW0032.execute();
            int ret = l_TBSW0032.fetch();
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "OK", 2 );

                fieldSet::fscopy( m_dat_mov_tran, l_TBSW0032.get_DAT_MOV_TRAN( ) );
                fieldSet::fscopy( m_num_bco_deb, l_TBSW0032.get_NUM_BCO_DEB( ) );
                fieldSet::fscopy( m_num_emsr, l_TBSW0032.get_NUM_EMSR( ) );
                fieldSet::fscopy( m_num_bco_estb, l_TBSW0032.get_NUM_BCO_ESTB( ) );
                fieldSet::fscopy( m_cod_cta_estb, l_TBSW0032.get_COD_CTA_ESTB( ) );
                fieldSet::fscopy( m_cod_vd_bco, l_TBSW0032.get_COD_VD_BCO( ) );
                fieldSet::fscopy( m_ind_cnfr_pstv, l_TBSW0032.get_IND_CNFR_PSTV( ) );
                fieldSet::fscopy( m_ind_impr_cpom, l_TBSW0032.get_IND_IMPR_CPOM( ) );
                fieldSet::fscopy( m_qtd_dia_crnc, l_TBSW0032.get_QTD_DIA_CRNC( ) );
                fieldSet::fscopy( m_ind_car_mltp, l_TBSW0032.get_IND_CAR_MLTP( ) );

                char l_bufferTemp[64];
                oasis_dec_t l_dec_temp;

                l_dec_temp = l_TBSW0032.get_NUM_SEQ_UNC( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_seq_unc, std::string( l_bufferTemp ) );

                l_dec_temp = l_TBSW0032.get_NUM_AGE_ESTB( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_age_estb, std::string( l_bufferTemp ) );

                l_dec_temp = l_TBSW0032.get_VAL_SQUE( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
                fieldSet::fscopy( m_val_sque, std::string( l_bufferTemp ) );
            }//else
        }//try
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0032 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0032 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW0032Loader& TBSW0032Loader::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW0032Loader& TBSW0032Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
  
    dataManip::Command* TBSW0032Loader::clone() const
    {
        return new TBSW0032Loader(*this);
    }
}//namespace plugins_pdv
