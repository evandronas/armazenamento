#pragma once
#include <cstdio>
#include <ctime>
#include <cctype>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbaccess_pdv/TBSW0084RegrasFormatacao.hpp"
#include "plugins_pdv/TBSW0084Inserter.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0084Inserter()
    {
        TBSW0084Inserter* l_new = new TBSW0084Inserter;
        return l_new;
    }

    bool TBSW0084Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_source = l_tagList.front().findProperty( "value" ).value();
        this->setSourceFieldPath( l_source );

        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0084Inserter::TBSW0084Inserter()
    {
    }

    TBSW0084Inserter::~TBSW0084Inserter()
    {
    }

    bool TBSW0084Inserter::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_trace = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
        m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_statistics = this->navigate( m_sourceFieldPath + ".segments.adm.statistics" );
        m_terminal_pdv = this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        m_id_pinpad = this->navigate( m_sourceFieldPath + ".segments.adm.id_pinpad");

        return true;
    }

    void TBSW0084Inserter::finish()
    {
    
    }

    int TBSW0084Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0084 l_table0084;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0084" );
            dbaccess_pdv::TBSW0084RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0084_params params = { 0 };

            fieldSet::fsextr( params.local_date,    m_local_date );
            fieldSet::fsextr( params.trace,         m_trace );
            fieldSet::fsextr( params.termloc,       m_termloc );
            fieldSet::fsextr( params.local_time,    m_local_time );
            fieldSet::fsextr( params.refnum,        m_refnum );
            fieldSet::fsextr( params.statistics,    m_statistics );
            fieldSet::fsextr( params.terminal_pdv,  m_terminal_pdv );
            fieldSet::fsextr( params.id_pinpad,     m_id_pinpad );

            regrasFmt.DAT_MOV_TRAN              ( l_table0084, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC               ( l_table0084, params, acq_common::INSERT );
            regrasFmt.DTH_INI_TRAN              ( l_table0084, params, acq_common::INSERT );
            regrasFmt.COD_TERM                  ( l_table0084, params, acq_common::INSERT );
            regrasFmt.NUM_STAN                  ( l_table0084, params, acq_common::INSERT );
            regrasFmt.NUM_ESTB                  ( l_table0084, params, acq_common::INSERT );
            regrasFmt.COD_PNPD_PDV              ( l_table0084, params, acq_common::INSERT );
            regrasFmt.NOM_FBRC_PNPD             ( l_table0084, params, acq_common::INSERT );
            regrasFmt.NUM_SRE_PNPD              ( l_table0084, params, acq_common::INSERT );
            regrasFmt.COD_VERS_HDW_PNPD         ( l_table0084, params, acq_common::INSERT );
            regrasFmt.COD_VERS_FRWR_PNPD        ( l_table0084, params, acq_common::INSERT );
            regrasFmt.COD_VERS_SFTW_PNPD        ( l_table0084, params, acq_common::INSERT );
            regrasFmt.NOM_FBRC_TEF              ( l_table0084, params, acq_common::INSERT );
            regrasFmt.COD_VERS_SFTW_TEF         ( l_table0084, params, acq_common::INSERT );
            regrasFmt.NOM_FBRC_ATMC             ( l_table0084, params, acq_common::INSERT );
            regrasFmt.COD_VERS_SFTW_ATMC        ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_LEIT_MAGN             ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_ERR_LEIT_MAGN         ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_SNHA_MAGN             ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_ERR_SNHA_MAGN         ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_SNHA_CHIP_ONLN        ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_ERR_SNHA_CHIP_ONLN    ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_SNHA_CHIP_OFLN        ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_ERR_SNHA_CHIP_OFLN    ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_BLQD_CHIP             ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_LEIT_CHIP             ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_FALLBACK_CRE          ( l_table0084, params, acq_common::INSERT );
            regrasFmt.QTD_FALLBACK_DEB          ( l_table0084, params, acq_common::INSERT );

            l_table0084.insert( );
            l_table0084.commit( );

            fieldSet::fscopy( m_result, "OK", 2 );

        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0084 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0084 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( ... )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0084 <UNKNOWN>";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;

    }

    TBSW0084Inserter& TBSW0084Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
    TBSW0084Inserter& TBSW0084Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW0084Inserter& TBSW0084Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0084Inserter::clone() const
    {
        return new TBSW0084Inserter(*this);
    }
}//namespace plugins_pdv

