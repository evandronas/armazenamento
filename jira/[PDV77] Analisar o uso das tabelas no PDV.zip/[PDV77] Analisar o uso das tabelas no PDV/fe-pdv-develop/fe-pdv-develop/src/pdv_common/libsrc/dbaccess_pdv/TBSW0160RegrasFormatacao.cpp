#include<dbaccess_pdv/TBSW0160RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
	TBSW0160RegrasFormatacao::TBSW0160RegrasFormatacao( )
	{
	}

	TBSW0160RegrasFormatacao::~TBSW0160RegrasFormatacao( )
	{
	}
}
