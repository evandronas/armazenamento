#include <dbaccess_pdv/TBSW0152RegrasFormatacao.hpp>
#include <cstring>

namespace dbaccess_pdv
{
    TBSW0152RegrasFormatacao::TBSW0152RegrasFormatacao( )
    {
    }

    TBSW0152RegrasFormatacao::~TBSW0152RegrasFormatacao( )
    {
    }

    void TBSW0152RegrasFormatacao::insert_VAL_PRCL_ENTR( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
    {
        oasis_dec_t l_dect;

        dbm_chartodec( &l_dect, "0.00", 2 );

        if ( params.msg_name == "VEND_IATA_PARC_SJURO" || params.msg_name == "VEND_IATA_PARC_CJURO" )
            if ( params.vl_pca_ent.empty( ) == false )
                dbm_chartodec( &l_dect, params.vl_pca_ent.c_str( ), 0 );

        tbsw0152.set_VAL_PRCL_ENTR( l_dect );
        
    }

    void TBSW0152RegrasFormatacao::insert_VAL_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
    {
        oasis_dec_t l_dect;

        // Inicia com valor zerado
        dbm_chartodec( &l_dect, "0.00", 2 );

        tbsw0152.set_VAL_PRCL( l_dect );

    }

    void TBSW0152RegrasFormatacao::update_VAL_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
    {
        oasis_dec_t l_dect;
        char l_bufferTemp[ 64 ];

        // Transacao nao aprovada ou transacao PL, move ZERO
        if ( params.status == 2 ||
            ( params.msg_name == "CONS_PL_VEND" || params.msg_name == "VEND_PL" ) )
            dbm_chartodec( &l_dect, "0.00", 2 );
        else
        if ( params.msg_name == "VEND_CRT_PARC_CJURO"      ||
             params.msg_name == "VEND_IATA_PARC_CJURO"     ||
             params.msg_name == "CONF_VEND_CRT_PARC_CJURO" ||
             params.msg_name == "CONF_VEND_IATA_PARC_CJURO" ||
             params.msg_name == "CREDIARIO_SIMUL" ||  // Padronizacao Crediario PDV
             params.msg_name == "CREDIARIO_VENDA" )  // Padronizacao Crediario PDV
        {
            if ( params.install_amt.empty( ) == false &&
                 params.iss_name.compare( "UPI" ) != 0 )  //Especificacao CUP, move ZERO
            {
                strcpy( l_bufferTemp, params.install_amt.c_str( ) );
                dbm_chartodec( &l_dect, l_bufferTemp, 0 );
            }
            else
                dbm_chartodec( &l_dect, "0.00", 2 );
        }
		else if ( params.msg_name == "VEND_CRT_PARC_SJURO" || 
			      params.msg_name == "VEND_IATA_PARC_SJURO" ||
                  params.msg_name == "CONF_PREAUT_PARC_SJURO" )
	    {
            if ( params.amount.empty( ) == false )
            {
                oasis_dec_t l_amount;
                oasis_dec_t l_install_num;

                strcpy( l_bufferTemp, params.amount.c_str( ) );
    			dbm_chartodec( &l_amount, l_bufferTemp, 0 );

                sprintf( l_bufferTemp, "%.2f", ( dbm_dectodbl( &l_amount ) / ( params.install_num * 1.0000 ) ) );

                dbm_chartodec( &l_dect, l_bufferTemp, 0 );
            }
            else
                dbm_chartodec( &l_dect, "0.00", 2 );
		}

        tbsw0152.set_VAL_PRCL( l_dect );
    }
}
