/*
Copyright 2018 REDE
*********************** MODIFICA��ES ************************
Autor     : Gustavo Silva Franco
Data      : 25/07/2019
Empresa   : Rede
Descri��o : Corre��o para que confirma��o de pr� atualize o registro corretamente na TBSW0058
ID        : EAK 1649
*************************************************************
*/


#include <fieldSet/ConstFieldAccess.hpp>
#include <fieldSet/FieldSet.hpp>
#include <fieldSet/fscopy.hpp>
#include <fieldSet/fsextr.hpp>
#include <configBase/TagList.hpp>
#include <base/GenException.hpp>
#include <sstream>
#include <ctime>
#include <cstdio>
#include <cstring>
#include "plugins_pdv/TBSW0058OrigUpdater.hpp"
#include "TBSW0058.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
//TODOSW75 #include "dualHandler.hpp"

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "dbaccess_pdv/TBSW0058RegrasFormatacao.hpp"
#include <defines.hpp>

//TODOSW75 
/***
dbm_datetime_t f_datetime ( long a_data, long a_time )
{
    struct tm l_dattim;
    char l_szdate[ 20 ];
    char l_sztime[ 20 ];
    std::string l_date;
    std::string l_time;
    
    memset( &l_dattim, 0, sizeof( l_dattim ) );
    sprintf( l_szdate, "%08d", a_data );
    sprintf( l_sztime, "%06d", a_time );
    l_date = l_szdate;
    l_time = l_sztime;
    l_dattim.tm_sec   = atoi( l_time.substr( 4, 2 ).c_str( ) );
    l_dattim.tm_min   = atoi( l_time.substr( 2, 2 ).c_str( ) );
    l_dattim.tm_hour  = atoi( l_time.substr( 0, 2 ).c_str( ) );
    l_dattim.tm_mday  = atoi( l_date.substr( 6, 2 ).c_str( ) );
    l_dattim.tm_mon   = atoi( l_date.substr( 4, 2 ).c_str( ) ) - 1;
    l_dattim.tm_year  = atoi( l_date.substr( 0, 4 ).c_str( ) ) - 1900;
    l_dattim.tm_isdst = -1;
    
    return( mktime ( &l_dattim ) );
}
***/

namespace plugins_pdv
{
    base::Identificable* createTBSW0058OrigUpdater( )
    {
        TBSW0058OrigUpdater* l_new = new TBSW0058OrigUpdater;
        return( l_new );
    }
    
    bool TBSW0058OrigUpdater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );
        
        return( true );
    }
    
    TBSW0058OrigUpdater::TBSW0058OrigUpdater( )
    {
    }
    
    TBSW0058OrigUpdater::~TBSW0058OrigUpdater( )
    {
    }
    
    bool TBSW0058OrigUpdater::init( )
    {
		// TARGET
		m_result = this->navigate( m_targetFieldPath + ".RESULT" );
		
		m_msgtype =    this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
		m_termid =     this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
		m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
		m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
		
		// SOURCE
		m_status       = this->navigate( m_sourceFieldPath + ".segments.common.status" );
		m_install_num  = this->navigate( m_sourceFieldPath + ".segments.common.install_num" );
		m_termid_type  = this->navigate( m_sourceFieldPath + ".segments.common.termid_type" );
        m_iss_name =         this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_msg_category =     this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        //m_acq_name = this->navigate( m_sourceFieldPath + ".segments.common.acq_name" );
        m_msg_name =         this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        //m_is_pre_auth =      this->navigate( m_sourceFieldPath + ".segments.common.is_pre_auth" );
        
        //cr689721@FIS - Data: 28/08/2014 - Ref. BT72.982
		m_termloc  = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
		m_issuer   = this->navigate( m_sourceFieldPath + ".shc_msg.issuer" );
		m_acquirer = this->navigate( m_sourceFieldPath + ".shc_msg.acquirer" );

		m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        dataLocalOriginal = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_date" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_status_trn_orig = this->navigate( m_sourceFieldPath + ".segments.common.status_trn_orig" );
        amount = this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
        
        return( true );
    }
    
    void TBSW0058OrigUpdater::finish( )
    {
    }
    
    int TBSW0058OrigUpdater::execute( bool& a_stop )
    {
        std::ostringstream l_whereClause;
        
        try
        {   
			std::string dataLocalOriginalLocal;
            std::string l_origrefnum;
			
			fieldSet::fsextr( dataLocalOriginalLocal, dataLocalOriginal );
			fieldSet::fsextr( l_origrefnum, m_origrefnum ); 
			
			l_whereClause << "DAT_MOV_TRAN = " << dataLocalOriginalLocal << " AND NUM_SEQ_UNC = " << l_origrefnum;
			
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0058 ORIG ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );            
            
            dbaccess_common::TBSW0058 l_table0058( l_whereClause.str( ) );
            l_table0058.prepare_for_update( );
            l_table0058.execute( );
            
            //TODOSW75 
            /***
            dbaccess_common::DualHandler l_dualHand( &l_table0058 );
            int ret = l_dualHand.fetch( dbaccess::table::UPDATE );
            ***/
            int ret = l_table0058.fetch( );
            if ( !ret )
            {
                logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ORIGINAL TRANSACTION NOT UPDATED" );
                fieldSet::fscopy( m_result, "ERROR", 5 );
                std::string l_msg = "WhereClause <" + l_whereClause.str( ) + ">";
                this->enableError( true );
                this->setErrorMessage( l_msg );
            }
            else
            {  
				l_table0058.let_as_is( );

                dbaccess_pdv::TBSW0058RegrasFormatacao regrasFormatacao;         
                acq_common::tbsw0058_params tbsw0058_params = { 0 };

				fieldSet::fsextr( tbsw0058_params.msgtype     ,m_msgtype      );
				// fieldSet::fsextr( tbsw0058_params.status      ,m_status_trn_orig );
                fieldSet::fsextr( tbsw0058_params.status      ,m_status       );
                fieldSet::fsextr( tbsw0058_params.termloc     ,m_termloc      );
                fieldSet::fsextr( tbsw0058_params.issuer      ,m_issuer       );
                fieldSet::fsextr( tbsw0058_params.acquirer    ,m_acquirer     );
                fieldSet::fsextr( tbsw0058_params.install_num ,m_install_num  );
                fieldSet::fsextr( tbsw0058_params.termid_type ,m_termid_type  );
                fieldSet::fsextr( tbsw0058_params.local_date  ,m_local_date   );
                fieldSet::fsextr( tbsw0058_params.local_time  ,m_local_time   );
                fieldSet::fsextr( tbsw0058_params.msg_category,m_msg_category );
                fieldSet::fsextr( tbsw0058_params.termid      ,m_termid       );
                fieldSet::fsextr( tbsw0058_params.refnum      ,m_refnum       ); 
                fieldSet::fsextr( tbsw0058_params.msg_name    ,m_msg_name     );
                fieldSet::fsextr( tbsw0058_params.install_num ,m_install_num  );
                fieldSet::fsextr( tbsw0058_params.orig_status ,m_status_trn_orig );
                fieldSet::fsextr( tbsw0058_params.amount      ,amount       );

                regrasFormatacao.VAL_EFTV_CPTR     ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.QTD_PRCL_CNFR     ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.COD_TERM_CNFR     ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.DAT_MOV_TRAN_CNFR ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.DTH_CNFR          ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.IND_RD_ORG_ESTR   ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.IND_STTU_TRAN     ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NUM_ESTB_CNFR     ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NUM_ESTB_ESTR     ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NUM_SEQ_UNC_CNFR  ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NUM_STAN_ORGL     ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NOM_SITE_ACQR_ATLZ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NOM_HOST_ACQR_ATLZ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NOM_FE_ACQR_ATLZ  ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NUM_AVSO_AUT      ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NTWK_ID_ACQR_ATLZ ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NTWK_ID_ROUTE_ATLZ( l_table0058, tbsw0058_params, acq_common::UPDATE ); 
                regrasFormatacao.NTWK_ID_ISSR_ATLZ ( l_table0058, tbsw0058_params, acq_common::UPDATE );
            
            //??
            //regrasFormatacao.COD_CTAH_VOCH     ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
            //regrasFormatacao.COD_TIP_PROD_CAR  ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
            //regrasFormatacao.NUM_PDV_EXT       ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
            //regrasFormatacao.NUM_PDV_VAN       ( tbsw0058, tbsw0058_params, acq_common::UPDATE );  

                l_table0058.set_IND_STTU_TRAN( tbsw0058_params.orig_status );

                l_table0058.show( 0 );

				l_table0058.update( );
				l_table0058.commit( );
				fieldSet::fscopy( m_result, "OK", 2 );
			}
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0058 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0058 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }        
        
        a_stop = false;
        return( 0 );
    }

    TBSW0058OrigUpdater& TBSW0058OrigUpdater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    
    TBSW0058OrigUpdater& TBSW0058OrigUpdater::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }
    
    TBSW0058OrigUpdater& TBSW0058OrigUpdater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    
    dataManip::Command* TBSW0058OrigUpdater::clone( ) const
    {
        return( new TBSW0058OrigUpdater( *this ) );
    }
}//namespace plugins_pdv
