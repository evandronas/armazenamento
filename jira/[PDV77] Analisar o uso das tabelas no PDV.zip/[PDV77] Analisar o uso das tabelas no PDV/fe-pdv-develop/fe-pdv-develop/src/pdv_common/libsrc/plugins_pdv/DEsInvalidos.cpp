#pragma once
#include <cstdio>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/DEsInvalidos.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <iostream>

namespace plugins_pos
{
    base::Identificable* createDEsInvalidos( )
    {
        DEsInvalidos* l_new = new DEsInvalidos;
        return( l_new );
    }

    DEsInvalidos::DEsInvalidos( )
    {
    }

    DEsInvalidos::~DEsInvalidos( )
    {
    }
    
   
    int DEsInvalidos::execute( bool& a_stop )
    {
        std::string l_listaDEsValidar="";
        std::string l_numeroCT="";
        std::string l_logIndevidos="";
        std::string l_logFaltantes="";
        
        std::string arrayDEsMensagem[128];
        std::string arrayCondicoes[352];  
        std::string arrayDEsLista[128];        
          
        //std::string teste;       
        try
        {   
            //fieldSet::fsextr( teste, m_DE002 );
            fieldSet::fsextr( l_listaDEsValidar, m_listaDEsValidar );

            fieldSet::fsextr( arrayDEsMensagem[2], m_DE002 );
            fieldSet::fsextr( arrayDEsMensagem[3], m_DE003 );
            fieldSet::fsextr( arrayDEsMensagem[4], m_DE004 );
            fieldSet::fsextr( arrayDEsMensagem[5], m_DE005 );
            fieldSet::fsextr( arrayDEsMensagem[6], m_DE006 );
            fieldSet::fsextr( arrayDEsMensagem[7], m_DE007 );
            fieldSet::fsextr( arrayDEsMensagem[8], m_DE008 );
            fieldSet::fsextr( arrayDEsMensagem[9], m_DE009 );
            fieldSet::fsextr( arrayDEsMensagem[10], m_DE010 );
            fieldSet::fsextr( arrayDEsMensagem[11], m_DE011 );
            fieldSet::fsextr( arrayDEsMensagem[12], m_DE012 );
            fieldSet::fsextr( arrayDEsMensagem[13], m_DE013 );
            fieldSet::fsextr( arrayDEsMensagem[14], m_DE014 );
            fieldSet::fsextr( arrayDEsMensagem[15], m_DE015 );
            fieldSet::fsextr( arrayDEsMensagem[16], m_DE016 );
            fieldSet::fsextr( arrayDEsMensagem[17], m_DE017 );
            fieldSet::fsextr( arrayDEsMensagem[18], m_DE018 );
            fieldSet::fsextr( arrayDEsMensagem[19], m_DE019 );
            fieldSet::fsextr( arrayDEsMensagem[20], m_DE020 );
            fieldSet::fsextr( arrayDEsMensagem[21], m_DE021 );
            fieldSet::fsextr( arrayDEsMensagem[22], m_DE022 );
            fieldSet::fsextr( arrayDEsMensagem[23], m_DE023 );
            fieldSet::fsextr( arrayDEsMensagem[24], m_DE024 );
            fieldSet::fsextr( arrayDEsMensagem[25], m_DE025 );
            fieldSet::fsextr( arrayDEsMensagem[26], m_DE026 );
            fieldSet::fsextr( arrayDEsMensagem[27], m_DE027 );
            fieldSet::fsextr( arrayDEsMensagem[28], m_DE028 );
            fieldSet::fsextr( arrayDEsMensagem[29], m_DE029 );
            fieldSet::fsextr( arrayDEsMensagem[30], m_DE030 );
            fieldSet::fsextr( arrayDEsMensagem[31], m_DE031 );
            fieldSet::fsextr( arrayDEsMensagem[32], m_DE032 );
            fieldSet::fsextr( arrayDEsMensagem[33], m_DE033 );
            fieldSet::fsextr( arrayDEsMensagem[34], m_DE034 );
            fieldSet::fsextr( arrayDEsMensagem[35], m_DE035 );
            fieldSet::fsextr( arrayDEsMensagem[36], m_DE036 );
            fieldSet::fsextr( arrayDEsMensagem[37], m_DE037 );
            fieldSet::fsextr( arrayDEsMensagem[38], m_DE038 );
            fieldSet::fsextr( arrayDEsMensagem[39], m_DE039 );
            fieldSet::fsextr( arrayDEsMensagem[40], m_DE040 );
            fieldSet::fsextr( arrayDEsMensagem[41], m_DE041 );
            fieldSet::fsextr( arrayDEsMensagem[42], m_DE042 );
            fieldSet::fsextr( arrayDEsMensagem[43], m_DE043 );
            fieldSet::fsextr( arrayDEsMensagem[44], m_DE044 );
            fieldSet::fsextr( arrayDEsMensagem[45], m_DE045 );
            fieldSet::fsextr( arrayDEsMensagem[46], m_DE046 );
            fieldSet::fsextr( arrayDEsMensagem[47], m_DE047 );
            fieldSet::fsextr( arrayDEsMensagem[48], m_DE048 );
            fieldSet::fsextr( arrayDEsMensagem[49], m_DE049 );
            fieldSet::fsextr( arrayDEsMensagem[50], m_DE050 );
            fieldSet::fsextr( arrayDEsMensagem[51], m_DE051 );
            fieldSet::fsextr( arrayDEsMensagem[52], m_DE052 );
            fieldSet::fsextr( arrayDEsMensagem[53], m_DE053 );
            fieldSet::fsextr( arrayDEsMensagem[54], m_DE054 );
            fieldSet::fsextr( arrayDEsMensagem[55], m_DE055 );
            fieldSet::fsextr( arrayDEsMensagem[56], m_DE056 );
            fieldSet::fsextr( arrayDEsMensagem[57], m_DE057 );
            fieldSet::fsextr( arrayDEsMensagem[58], m_DE058 );
            fieldSet::fsextr( arrayDEsMensagem[59], m_DE059 );
            fieldSet::fsextr( arrayDEsMensagem[60], m_DE060 );
            fieldSet::fsextr( arrayDEsMensagem[61], m_DE061 );
            fieldSet::fsextr( arrayDEsMensagem[62], m_DE062 );
            fieldSet::fsextr( arrayDEsMensagem[63], m_DE063 );
            fieldSet::fsextr( arrayDEsMensagem[64], m_DE064 );
            fieldSet::fsextr( arrayDEsMensagem[65], m_DE065 );
            fieldSet::fsextr( arrayDEsMensagem[66], m_DE066 );
            fieldSet::fsextr( arrayDEsMensagem[67], m_DE067 );
            fieldSet::fsextr( arrayDEsMensagem[68], m_DE068 );
            fieldSet::fsextr( arrayDEsMensagem[69], m_DE069 );
            fieldSet::fsextr( arrayDEsMensagem[70], m_DE070 );
            fieldSet::fsextr( arrayDEsMensagem[71], m_DE071 );
            fieldSet::fsextr( arrayDEsMensagem[72], m_DE072 );
            fieldSet::fsextr( arrayDEsMensagem[73], m_DE073 );
            fieldSet::fsextr( arrayDEsMensagem[74], m_DE074 );
            fieldSet::fsextr( arrayDEsMensagem[75], m_DE075 );
            fieldSet::fsextr( arrayDEsMensagem[76], m_DE076 );
            fieldSet::fsextr( arrayDEsMensagem[77], m_DE077 );
            fieldSet::fsextr( arrayDEsMensagem[78], m_DE078 );
            fieldSet::fsextr( arrayDEsMensagem[79], m_DE079 );
            fieldSet::fsextr( arrayDEsMensagem[80], m_DE080 );
            fieldSet::fsextr( arrayDEsMensagem[81], m_DE081 );
            fieldSet::fsextr( arrayDEsMensagem[82], m_DE082 );
            fieldSet::fsextr( arrayDEsMensagem[83], m_DE083 );
            fieldSet::fsextr( arrayDEsMensagem[84], m_DE084 );
            fieldSet::fsextr( arrayDEsMensagem[85], m_DE085 );
            fieldSet::fsextr( arrayDEsMensagem[86], m_DE086 );
            fieldSet::fsextr( arrayDEsMensagem[87], m_DE087 );
            fieldSet::fsextr( arrayDEsMensagem[88], m_DE088 );
            fieldSet::fsextr( arrayDEsMensagem[89], m_DE089 );
            fieldSet::fsextr( arrayDEsMensagem[90], m_DE090 );
            fieldSet::fsextr( arrayDEsMensagem[91], m_DE091 );
            fieldSet::fsextr( arrayDEsMensagem[92], m_DE092 );
            fieldSet::fsextr( arrayDEsMensagem[93], m_DE093 );
            fieldSet::fsextr( arrayDEsMensagem[94], m_DE094 );
            fieldSet::fsextr( arrayDEsMensagem[95], m_DE095 );
            fieldSet::fsextr( arrayDEsMensagem[96], m_DE096 );
            fieldSet::fsextr( arrayDEsMensagem[97], m_DE097 );
            fieldSet::fsextr( arrayDEsMensagem[98], m_DE098 );
            fieldSet::fsextr( arrayDEsMensagem[99], m_DE099 );
            fieldSet::fsextr( arrayDEsMensagem[100], m_DE100 );
            fieldSet::fsextr( arrayDEsMensagem[101], m_DE101 );
            fieldSet::fsextr( arrayDEsMensagem[102], m_DE102 );
            fieldSet::fsextr( arrayDEsMensagem[103], m_DE103 );
            fieldSet::fsextr( arrayDEsMensagem[104], m_DE104 );
            fieldSet::fsextr( arrayDEsMensagem[105], m_DE105 );
            fieldSet::fsextr( arrayDEsMensagem[106], m_DE106 );
            fieldSet::fsextr( arrayDEsMensagem[107], m_DE107 );
            fieldSet::fsextr( arrayDEsMensagem[108], m_DE108 );
            fieldSet::fsextr( arrayDEsMensagem[109], m_DE109 );
            fieldSet::fsextr( arrayDEsMensagem[110], m_DE110 );
            fieldSet::fsextr( arrayDEsMensagem[111], m_DE111 );
            fieldSet::fsextr( arrayDEsMensagem[112], m_DE112 );
            fieldSet::fsextr( arrayDEsMensagem[113], m_DE113 );
            fieldSet::fsextr( arrayDEsMensagem[114], m_DE114 );
            fieldSet::fsextr( arrayDEsMensagem[115], m_DE115 );
            fieldSet::fsextr( arrayDEsMensagem[116], m_DE116 );
            fieldSet::fsextr( arrayDEsMensagem[117], m_DE117 );
            fieldSet::fsextr( arrayDEsMensagem[118], m_DE118 );
            fieldSet::fsextr( arrayDEsMensagem[119], m_DE119 );
            fieldSet::fsextr( arrayDEsMensagem[120], m_DE120 );
            fieldSet::fsextr( arrayDEsMensagem[121], m_DE121 );
            fieldSet::fsextr( arrayDEsMensagem[122], m_DE122 );
            fieldSet::fsextr( arrayDEsMensagem[123], m_DE123 );
            fieldSet::fsextr( arrayDEsMensagem[124], m_DE124 );
            fieldSet::fsextr( arrayDEsMensagem[125], m_DE125 );
            fieldSet::fsextr( arrayDEsMensagem[126], m_DE126 );
            fieldSet::fsextr( arrayDEsMensagem[127], m_DE127 );
                      
            fieldSet::fsextr( arrayCondicoes[1], m_COND001 );
            fieldSet::fsextr( arrayCondicoes[2], m_COND002 );
            fieldSet::fsextr( arrayCondicoes[3], m_COND003 );
            fieldSet::fsextr( arrayCondicoes[4], m_COND004 );
            fieldSet::fsextr( arrayCondicoes[5], m_COND005 );
            fieldSet::fsextr( arrayCondicoes[6], m_COND006 );
            fieldSet::fsextr( arrayCondicoes[7], m_COND007 );
            fieldSet::fsextr( arrayCondicoes[8], m_COND008 );
            fieldSet::fsextr( arrayCondicoes[9], m_COND009 );
            fieldSet::fsextr( arrayCondicoes[10], m_COND010 );
            fieldSet::fsextr( arrayCondicoes[11], m_COND011 );
            fieldSet::fsextr( arrayCondicoes[12], m_COND012 );
            fieldSet::fsextr( arrayCondicoes[13], m_COND013 );
            fieldSet::fsextr( arrayCondicoes[14], m_COND014 );
            fieldSet::fsextr( arrayCondicoes[15], m_COND015 );
            fieldSet::fsextr( arrayCondicoes[16], m_COND016 );
            fieldSet::fsextr( arrayCondicoes[17], m_COND017 );
            fieldSet::fsextr( arrayCondicoes[18], m_COND018 );
            fieldSet::fsextr( arrayCondicoes[19], m_COND019 );
            fieldSet::fsextr( arrayCondicoes[20], m_COND020 );
            fieldSet::fsextr( arrayCondicoes[21], m_COND021 );
            fieldSet::fsextr( arrayCondicoes[22], m_COND022 );
            fieldSet::fsextr( arrayCondicoes[23], m_COND023 );
            fieldSet::fsextr( arrayCondicoes[24], m_COND024 );
            fieldSet::fsextr( arrayCondicoes[25], m_COND025 );
            fieldSet::fsextr( arrayCondicoes[26], m_COND026 );
            fieldSet::fsextr( arrayCondicoes[27], m_COND027 );
            fieldSet::fsextr( arrayCondicoes[28], m_COND028 );
            fieldSet::fsextr( arrayCondicoes[29], m_COND029 );
            fieldSet::fsextr( arrayCondicoes[30], m_COND030 );
            fieldSet::fsextr( arrayCondicoes[31], m_COND031 );
            fieldSet::fsextr( arrayCondicoes[32], m_COND032 );
            fieldSet::fsextr( arrayCondicoes[33], m_COND033 );
            fieldSet::fsextr( arrayCondicoes[34], m_COND034 );
            fieldSet::fsextr( arrayCondicoes[35], m_COND035 );
            fieldSet::fsextr( arrayCondicoes[36], m_COND036 );
            fieldSet::fsextr( arrayCondicoes[37], m_COND037 );
            fieldSet::fsextr( arrayCondicoes[38], m_COND038 );
            fieldSet::fsextr( arrayCondicoes[39], m_COND039 );
            fieldSet::fsextr( arrayCondicoes[40], m_COND040 );
            fieldSet::fsextr( arrayCondicoes[41], m_COND041 );
            fieldSet::fsextr( arrayCondicoes[42], m_COND042 );
            fieldSet::fsextr( arrayCondicoes[43], m_COND043 );
            fieldSet::fsextr( arrayCondicoes[44], m_COND044 );
            fieldSet::fsextr( arrayCondicoes[45], m_COND045 );
            fieldSet::fsextr( arrayCondicoes[46], m_COND046 );
            fieldSet::fsextr( arrayCondicoes[47], m_COND047 );
            fieldSet::fsextr( arrayCondicoes[48], m_COND048 );
            fieldSet::fsextr( arrayCondicoes[49], m_COND049 );
            fieldSet::fsextr( arrayCondicoes[50], m_COND050 );
            fieldSet::fsextr( arrayCondicoes[51], m_COND051 );
            fieldSet::fsextr( arrayCondicoes[52], m_COND052 );
            fieldSet::fsextr( arrayCondicoes[53], m_COND053 );
            fieldSet::fsextr( arrayCondicoes[54], m_COND054 );
            fieldSet::fsextr( arrayCondicoes[55], m_COND055 );
            fieldSet::fsextr( arrayCondicoes[56], m_COND056 );
            fieldSet::fsextr( arrayCondicoes[57], m_COND057 );
            fieldSet::fsextr( arrayCondicoes[58], m_COND058 );
            fieldSet::fsextr( arrayCondicoes[59], m_COND059 );
            fieldSet::fsextr( arrayCondicoes[60], m_COND060 );
            fieldSet::fsextr( arrayCondicoes[61], m_COND061 );
            fieldSet::fsextr( arrayCondicoes[62], m_COND062 );
            fieldSet::fsextr( arrayCondicoes[63], m_COND063 );
            fieldSet::fsextr( arrayCondicoes[64], m_COND064 );
            fieldSet::fsextr( arrayCondicoes[65], m_COND065 );
            fieldSet::fsextr( arrayCondicoes[66], m_COND066 );
            fieldSet::fsextr( arrayCondicoes[67], m_COND067 );
            fieldSet::fsextr( arrayCondicoes[68], m_COND068 );
            fieldSet::fsextr( arrayCondicoes[69], m_COND069 );
            fieldSet::fsextr( arrayCondicoes[70], m_COND070 );
            fieldSet::fsextr( arrayCondicoes[71], m_COND071 );
            fieldSet::fsextr( arrayCondicoes[72], m_COND072 );
            fieldSet::fsextr( arrayCondicoes[73], m_COND073 );
            fieldSet::fsextr( arrayCondicoes[74], m_COND074 );
            fieldSet::fsextr( arrayCondicoes[75], m_COND075 );
            fieldSet::fsextr( arrayCondicoes[76], m_COND076 );
            fieldSet::fsextr( arrayCondicoes[77], m_COND077 );
            fieldSet::fsextr( arrayCondicoes[78], m_COND078 );
            fieldSet::fsextr( arrayCondicoes[79], m_COND079 );
            fieldSet::fsextr( arrayCondicoes[80], m_COND080 );
            fieldSet::fsextr( arrayCondicoes[81], m_COND081 );
            fieldSet::fsextr( arrayCondicoes[82], m_COND082 );
            fieldSet::fsextr( arrayCondicoes[83], m_COND083 );
            fieldSet::fsextr( arrayCondicoes[84], m_COND084 );
            fieldSet::fsextr( arrayCondicoes[85], m_COND085 );
            fieldSet::fsextr( arrayCondicoes[86], m_COND086 );
            fieldSet::fsextr( arrayCondicoes[87], m_COND087 );
            fieldSet::fsextr( arrayCondicoes[88], m_COND088 );
            fieldSet::fsextr( arrayCondicoes[89], m_COND089 );
            fieldSet::fsextr( arrayCondicoes[90], m_COND090 );
            fieldSet::fsextr( arrayCondicoes[91], m_COND091 );
            fieldSet::fsextr( arrayCondicoes[92], m_COND092 );
            fieldSet::fsextr( arrayCondicoes[93], m_COND093 );
            fieldSet::fsextr( arrayCondicoes[94], m_COND094 );
            fieldSet::fsextr( arrayCondicoes[95], m_COND095 );
            fieldSet::fsextr( arrayCondicoes[96], m_COND096 );
            fieldSet::fsextr( arrayCondicoes[97], m_COND097 );
            fieldSet::fsextr( arrayCondicoes[98], m_COND098 );
            fieldSet::fsextr( arrayCondicoes[99], m_COND099 );
            fieldSet::fsextr( arrayCondicoes[100], m_COND100 );
            fieldSet::fsextr( arrayCondicoes[101], m_COND101 );
            fieldSet::fsextr( arrayCondicoes[102], m_COND102 );
            fieldSet::fsextr( arrayCondicoes[103], m_COND103 );
            fieldSet::fsextr( arrayCondicoes[104], m_COND104 );
            fieldSet::fsextr( arrayCondicoes[105], m_COND105 );
            fieldSet::fsextr( arrayCondicoes[106], m_COND106 );
            fieldSet::fsextr( arrayCondicoes[107], m_COND107 );
            fieldSet::fsextr( arrayCondicoes[108], m_COND108 );
            fieldSet::fsextr( arrayCondicoes[109], m_COND109 );
            fieldSet::fsextr( arrayCondicoes[110], m_COND110 );
            fieldSet::fsextr( arrayCondicoes[111], m_COND111 );
            fieldSet::fsextr( arrayCondicoes[112], m_COND112 );
            fieldSet::fsextr( arrayCondicoes[113], m_COND113 );
            fieldSet::fsextr( arrayCondicoes[114], m_COND114 );
            fieldSet::fsextr( arrayCondicoes[115], m_COND115 );
            fieldSet::fsextr( arrayCondicoes[116], m_COND116 );
            fieldSet::fsextr( arrayCondicoes[117], m_COND117 );
            fieldSet::fsextr( arrayCondicoes[118], m_COND118 );
            fieldSet::fsextr( arrayCondicoes[119], m_COND119 );  
            fieldSet::fsextr( arrayCondicoes[120], m_COND120 ); 
            fieldSet::fsextr( arrayCondicoes[121], m_COND121 ); 
            fieldSet::fsextr( arrayCondicoes[122], m_COND122 ); 
            fieldSet::fsextr( arrayCondicoes[123], m_COND123 ); 
            fieldSet::fsextr( arrayCondicoes[124], m_COND124 ); 
            fieldSet::fsextr( arrayCondicoes[125], m_COND125 ); 
            fieldSet::fsextr( arrayCondicoes[126], m_COND126 ); 
            fieldSet::fsextr( arrayCondicoes[127], m_COND127 ); 
            fieldSet::fsextr( arrayCondicoes[128], m_COND128 ); 
            fieldSet::fsextr( arrayCondicoes[129], m_COND129 ); 
            fieldSet::fsextr( arrayCondicoes[130], m_COND130 ); 
            fieldSet::fsextr( arrayCondicoes[131], m_COND131 ); 
            fieldSet::fsextr( arrayCondicoes[132], m_COND132 ); 
            fieldSet::fsextr( arrayCondicoes[133], m_COND133 ); 
            fieldSet::fsextr( arrayCondicoes[134], m_COND134 ); 
            fieldSet::fsextr( arrayCondicoes[135], m_COND135 ); 
            fieldSet::fsextr( arrayCondicoes[136], m_COND136 ); 
            fieldSet::fsextr( arrayCondicoes[137], m_COND137 ); 
            fieldSet::fsextr( arrayCondicoes[138], m_COND138 ); 
            fieldSet::fsextr( arrayCondicoes[139], m_COND139 ); 
            fieldSet::fsextr( arrayCondicoes[140], m_COND140 ); 
            fieldSet::fsextr( arrayCondicoes[141], m_COND141 ); 
            fieldSet::fsextr( arrayCondicoes[142], m_COND142 ); 
            fieldSet::fsextr( arrayCondicoes[143], m_COND143 ); 
            fieldSet::fsextr( arrayCondicoes[144], m_COND144 ); 
            fieldSet::fsextr( arrayCondicoes[145], m_COND145 ); 
            fieldSet::fsextr( arrayCondicoes[146], m_COND146 ); 
            fieldSet::fsextr( arrayCondicoes[147], m_COND147 ); 
            fieldSet::fsextr( arrayCondicoes[148], m_COND148 ); 
            fieldSet::fsextr( arrayCondicoes[149], m_COND149 ); 
            fieldSet::fsextr( arrayCondicoes[150], m_COND150 ); 
            fieldSet::fsextr( arrayCondicoes[151], m_COND151 ); 
            fieldSet::fsextr( arrayCondicoes[152], m_COND152 ); 
            fieldSet::fsextr( arrayCondicoes[153], m_COND153 ); 
            fieldSet::fsextr( arrayCondicoes[154], m_COND154 ); 
            fieldSet::fsextr( arrayCondicoes[155], m_COND155 ); 
            fieldSet::fsextr( arrayCondicoes[156], m_COND156 ); 
            fieldSet::fsextr( arrayCondicoes[157], m_COND157 ); 
            fieldSet::fsextr( arrayCondicoes[158], m_COND158 ); 
            fieldSet::fsextr( arrayCondicoes[159], m_COND159 ); 
            fieldSet::fsextr( arrayCondicoes[160], m_COND160 ); 
            fieldSet::fsextr( arrayCondicoes[161], m_COND161 ); 
            fieldSet::fsextr( arrayCondicoes[162], m_COND162 ); 
            fieldSet::fsextr( arrayCondicoes[163], m_COND163 ); 
            fieldSet::fsextr( arrayCondicoes[164], m_COND164 ); 
            fieldSet::fsextr( arrayCondicoes[165], m_COND165 ); 
            fieldSet::fsextr( arrayCondicoes[166], m_COND166 ); 
            fieldSet::fsextr( arrayCondicoes[167], m_COND167 ); 
            fieldSet::fsextr( arrayCondicoes[168], m_COND168 ); 
            fieldSet::fsextr( arrayCondicoes[169], m_COND169 ); 
            fieldSet::fsextr( arrayCondicoes[170], m_COND170 ); 
            fieldSet::fsextr( arrayCondicoes[171], m_COND171 ); 
            fieldSet::fsextr( arrayCondicoes[172], m_COND172 ); 
            fieldSet::fsextr( arrayCondicoes[173], m_COND173 ); 
            fieldSet::fsextr( arrayCondicoes[174], m_COND174 ); 
            fieldSet::fsextr( arrayCondicoes[175], m_COND175 ); 
            fieldSet::fsextr( arrayCondicoes[176], m_COND176 ); 
            fieldSet::fsextr( arrayCondicoes[177], m_COND177 ); 
            fieldSet::fsextr( arrayCondicoes[178], m_COND178 ); 
            fieldSet::fsextr( arrayCondicoes[179], m_COND179 ); 
            fieldSet::fsextr( arrayCondicoes[180], m_COND180 ); 
            fieldSet::fsextr( arrayCondicoes[181], m_COND181 ); 
            fieldSet::fsextr( arrayCondicoes[182], m_COND182 ); 
            fieldSet::fsextr( arrayCondicoes[183], m_COND183 ); 
            fieldSet::fsextr( arrayCondicoes[184], m_COND184 ); 
            fieldSet::fsextr( arrayCondicoes[185], m_COND185 ); 
            fieldSet::fsextr( arrayCondicoes[186], m_COND186 ); 
            fieldSet::fsextr( arrayCondicoes[187], m_COND187 ); 
            fieldSet::fsextr( arrayCondicoes[188], m_COND188 ); 
            fieldSet::fsextr( arrayCondicoes[189], m_COND189 ); 
            fieldSet::fsextr( arrayCondicoes[190], m_COND190 ); 
            fieldSet::fsextr( arrayCondicoes[191], m_COND191 ); 
            fieldSet::fsextr( arrayCondicoes[192], m_COND192 ); 
            fieldSet::fsextr( arrayCondicoes[193], m_COND193 ); 
            fieldSet::fsextr( arrayCondicoes[194], m_COND194 ); 
            fieldSet::fsextr( arrayCondicoes[195], m_COND195 ); 
            fieldSet::fsextr( arrayCondicoes[196], m_COND196 ); 
            fieldSet::fsextr( arrayCondicoes[197], m_COND197 ); 
            fieldSet::fsextr( arrayCondicoes[198], m_COND198 ); 
            fieldSet::fsextr( arrayCondicoes[199], m_COND199 ); 
            fieldSet::fsextr( arrayCondicoes[200], m_COND200 ); 
            fieldSet::fsextr( arrayCondicoes[201], m_COND201 ); 
            fieldSet::fsextr( arrayCondicoes[202], m_COND202 ); 
            fieldSet::fsextr( arrayCondicoes[203], m_COND203 ); 
            fieldSet::fsextr( arrayCondicoes[204], m_COND204 ); 
            fieldSet::fsextr( arrayCondicoes[205], m_COND205 ); 
            fieldSet::fsextr( arrayCondicoes[206], m_COND206 ); 
            fieldSet::fsextr( arrayCondicoes[207], m_COND207 ); 
            fieldSet::fsextr( arrayCondicoes[208], m_COND208 ); 
            fieldSet::fsextr( arrayCondicoes[209], m_COND209 ); 
            fieldSet::fsextr( arrayCondicoes[210], m_COND210 ); 
            fieldSet::fsextr( arrayCondicoes[211], m_COND211 ); 
            fieldSet::fsextr( arrayCondicoes[212], m_COND212 ); 
            fieldSet::fsextr( arrayCondicoes[213], m_COND213 ); 
            fieldSet::fsextr( arrayCondicoes[214], m_COND214 ); 
            fieldSet::fsextr( arrayCondicoes[215], m_COND215 ); 
            fieldSet::fsextr( arrayCondicoes[216], m_COND216 ); 
            fieldSet::fsextr( arrayCondicoes[217], m_COND217 ); 
            fieldSet::fsextr( arrayCondicoes[218], m_COND218 ); 
            fieldSet::fsextr( arrayCondicoes[219], m_COND219 ); 
            fieldSet::fsextr( arrayCondicoes[220], m_COND220 );   
            fieldSet::fsextr( arrayCondicoes[221], m_COND221 );   
            fieldSet::fsextr( arrayCondicoes[222], m_COND222 );   
            fieldSet::fsextr( arrayCondicoes[223], m_COND223 );   
            fieldSet::fsextr( arrayCondicoes[224], m_COND224 );   
            fieldSet::fsextr( arrayCondicoes[225], m_COND225 );   
            fieldSet::fsextr( arrayCondicoes[226], m_COND226 );   
            fieldSet::fsextr( arrayCondicoes[227], m_COND227 );   
            fieldSet::fsextr( arrayCondicoes[228], m_COND228 );   
            fieldSet::fsextr( arrayCondicoes[229], m_COND229 );   
            fieldSet::fsextr( arrayCondicoes[230], m_COND230 );   
            fieldSet::fsextr( arrayCondicoes[231], m_COND231 );   
            fieldSet::fsextr( arrayCondicoes[232], m_COND232 );   
            fieldSet::fsextr( arrayCondicoes[233], m_COND233 );   
            fieldSet::fsextr( arrayCondicoes[234], m_COND234 );   
            fieldSet::fsextr( arrayCondicoes[235], m_COND235 );   
            fieldSet::fsextr( arrayCondicoes[236], m_COND236 );   
            fieldSet::fsextr( arrayCondicoes[237], m_COND237 );   
            fieldSet::fsextr( arrayCondicoes[238], m_COND238 );   
            fieldSet::fsextr( arrayCondicoes[239], m_COND239 );   
            fieldSet::fsextr( arrayCondicoes[240], m_COND240 );   
            fieldSet::fsextr( arrayCondicoes[241], m_COND241 );   
            fieldSet::fsextr( arrayCondicoes[242], m_COND242 );   
            fieldSet::fsextr( arrayCondicoes[243], m_COND243 );   
            fieldSet::fsextr( arrayCondicoes[244], m_COND244 );   
            fieldSet::fsextr( arrayCondicoes[245], m_COND245 );   
            fieldSet::fsextr( arrayCondicoes[246], m_COND246 );   
            fieldSet::fsextr( arrayCondicoes[247], m_COND247 );   
            fieldSet::fsextr( arrayCondicoes[248], m_COND248 );   
            fieldSet::fsextr( arrayCondicoes[249], m_COND249 );   
            fieldSet::fsextr( arrayCondicoes[250], m_COND250 );   
            fieldSet::fsextr( arrayCondicoes[251], m_COND251 );   
            fieldSet::fsextr( arrayCondicoes[252], m_COND252 );   
            fieldSet::fsextr( arrayCondicoes[253], m_COND253 );   
            fieldSet::fsextr( arrayCondicoes[254], m_COND254 );   
            fieldSet::fsextr( arrayCondicoes[255], m_COND255 );   
            fieldSet::fsextr( arrayCondicoes[256], m_COND256 );   
            fieldSet::fsextr( arrayCondicoes[257], m_COND257 );   
            fieldSet::fsextr( arrayCondicoes[258], m_COND258 );   
            fieldSet::fsextr( arrayCondicoes[259], m_COND259 );   
            fieldSet::fsextr( arrayCondicoes[260], m_COND260 );   
            fieldSet::fsextr( arrayCondicoes[261], m_COND261 );   
            fieldSet::fsextr( arrayCondicoes[262], m_COND262 );   
            fieldSet::fsextr( arrayCondicoes[263], m_COND263 );   
            fieldSet::fsextr( arrayCondicoes[264], m_COND264 );   
            fieldSet::fsextr( arrayCondicoes[265], m_COND265 );   
            fieldSet::fsextr( arrayCondicoes[266], m_COND266 );   
            fieldSet::fsextr( arrayCondicoes[267], m_COND267 );   
            fieldSet::fsextr( arrayCondicoes[268], m_COND268 );   
            fieldSet::fsextr( arrayCondicoes[269], m_COND269 );   
            fieldSet::fsextr( arrayCondicoes[270], m_COND270 );   
            fieldSet::fsextr( arrayCondicoes[271], m_COND271 );
            fieldSet::fsextr( arrayCondicoes[272], m_COND272 );
            fieldSet::fsextr( arrayCondicoes[273], m_COND273 );
            fieldSet::fsextr( arrayCondicoes[274], m_COND274 );
            fieldSet::fsextr( arrayCondicoes[275], m_COND275 );
            fieldSet::fsextr( arrayCondicoes[276], m_COND276 );
            fieldSet::fsextr( arrayCondicoes[277], m_COND277 );
            fieldSet::fsextr( arrayCondicoes[278], m_COND278 );
            fieldSet::fsextr( arrayCondicoes[279], m_COND279 );
            fieldSet::fsextr( arrayCondicoes[280], m_COND280 );
            fieldSet::fsextr( arrayCondicoes[281], m_COND281 );
            fieldSet::fsextr( arrayCondicoes[282], m_COND282 );
            fieldSet::fsextr( arrayCondicoes[283], m_COND283 );
            fieldSet::fsextr( arrayCondicoes[284], m_COND284 );
            fieldSet::fsextr( arrayCondicoes[285], m_COND285 );
            fieldSet::fsextr( arrayCondicoes[286], m_COND286 );
            fieldSet::fsextr( arrayCondicoes[287], m_COND287 );
            fieldSet::fsextr( arrayCondicoes[288], m_COND288 );
            fieldSet::fsextr( arrayCondicoes[289], m_COND289 );
            fieldSet::fsextr( arrayCondicoes[290], m_COND290 );
            fieldSet::fsextr( arrayCondicoes[291], m_COND291 );
            fieldSet::fsextr( arrayCondicoes[292], m_COND292 );
            fieldSet::fsextr( arrayCondicoes[293], m_COND293 );
            fieldSet::fsextr( arrayCondicoes[294], m_COND294 );
            fieldSet::fsextr( arrayCondicoes[295], m_COND295 );
            fieldSet::fsextr( arrayCondicoes[296], m_COND296 );
            fieldSet::fsextr( arrayCondicoes[297], m_COND297 );
            fieldSet::fsextr( arrayCondicoes[298], m_COND298 );
            fieldSet::fsextr( arrayCondicoes[299], m_COND299 );
            fieldSet::fsextr( arrayCondicoes[300], m_COND300 );
            fieldSet::fsextr( arrayCondicoes[301], m_COND301 ); 
            fieldSet::fsextr( arrayCondicoes[302], m_COND302 ); 
            fieldSet::fsextr( arrayCondicoes[303], m_COND303 ); 
            fieldSet::fsextr( arrayCondicoes[304], m_COND304 ); 
            fieldSet::fsextr( arrayCondicoes[305], m_COND305 ); 
            fieldSet::fsextr( arrayCondicoes[306], m_COND306 ); 
            fieldSet::fsextr( arrayCondicoes[307], m_COND307 ); 
            fieldSet::fsextr( arrayCondicoes[308], m_COND308 ); 
            fieldSet::fsextr( arrayCondicoes[309], m_COND309 ); 
            fieldSet::fsextr( arrayCondicoes[310], m_COND310 ); 
            fieldSet::fsextr( arrayCondicoes[311], m_COND311 ); 
            fieldSet::fsextr( arrayCondicoes[312], m_COND312 ); 
            fieldSet::fsextr( arrayCondicoes[313], m_COND313 ); 
            fieldSet::fsextr( arrayCondicoes[314], m_COND314 ); 
            fieldSet::fsextr( arrayCondicoes[315], m_COND315 ); 
            fieldSet::fsextr( arrayCondicoes[316], m_COND316 ); 
            fieldSet::fsextr( arrayCondicoes[317], m_COND317 ); 
            fieldSet::fsextr( arrayCondicoes[318], m_COND318 ); 
            fieldSet::fsextr( arrayCondicoes[319], m_COND319 ); 
            fieldSet::fsextr( arrayCondicoes[320], m_COND320 );   
            fieldSet::fsextr( arrayCondicoes[321], m_COND321 );   
            fieldSet::fsextr( arrayCondicoes[322], m_COND322 );   
            fieldSet::fsextr( arrayCondicoes[323], m_COND323 );   
            fieldSet::fsextr( arrayCondicoes[324], m_COND324 );   
            fieldSet::fsextr( arrayCondicoes[325], m_COND325 );   
            fieldSet::fsextr( arrayCondicoes[326], m_COND326 );   
            fieldSet::fsextr( arrayCondicoes[327], m_COND327 );   
            fieldSet::fsextr( arrayCondicoes[328], m_COND328 );   
            fieldSet::fsextr( arrayCondicoes[329], m_COND329 );   
            fieldSet::fsextr( arrayCondicoes[330], m_COND330 );   
            fieldSet::fsextr( arrayCondicoes[331], m_COND331 );   
            fieldSet::fsextr( arrayCondicoes[332], m_COND332 );   
            fieldSet::fsextr( arrayCondicoes[333], m_COND333 );   
            fieldSet::fsextr( arrayCondicoes[334], m_COND334 );   
            fieldSet::fsextr( arrayCondicoes[335], m_COND335 );   
            fieldSet::fsextr( arrayCondicoes[336], m_COND336 );   
            fieldSet::fsextr( arrayCondicoes[337], m_COND337 );   
            fieldSet::fsextr( arrayCondicoes[338], m_COND338 );   
            fieldSet::fsextr( arrayCondicoes[339], m_COND339 );   
            fieldSet::fsextr( arrayCondicoes[340], m_COND340 );   
            fieldSet::fsextr( arrayCondicoes[341], m_COND341 );   
            fieldSet::fsextr( arrayCondicoes[342], m_COND342 );   
            fieldSet::fsextr( arrayCondicoes[343], m_COND343 );   
            fieldSet::fsextr( arrayCondicoes[344], m_COND344 );   
            fieldSet::fsextr( arrayCondicoes[345], m_COND345 );   
            fieldSet::fsextr( arrayCondicoes[346], m_COND346 );   
            fieldSet::fsextr( arrayCondicoes[347], m_COND347 );   
            fieldSet::fsextr( arrayCondicoes[348], m_COND348 );   
            fieldSet::fsextr( arrayCondicoes[349], m_COND349 );   
            fieldSet::fsextr( arrayCondicoes[350], m_COND350 );            
            
            for(int i=0;i<128;i++)
            {
                arrayDEsLista[i]="FALSE";
            }
            
            setArrayDEsMensagem(l_listaDEsValidar, arrayDEsLista, arrayCondicoes);            
                 
            //validacao dos DEs
            //Todos os campos recebidos tem que constar no mapeamento, sejam eles obrigatorios ou nao
                        
            for(int i=2;i<128;i++)
            {
                char buff[100];
                
                /*
                if(!arrayDEsLista[i].empty() || !arrayDEsMensagem[i].empty())
                {
                    sprintf(buff,", DE%03d",i);  
                    std::cout <<"DE"<< buff << " arrayDEsLista[" << arrayDEsLista[i].c_str() << "] arrayDEsMensagem[" << arrayDEsMensagem[i].c_str() << "]"<<std::endl;
                }
                */
                
                if(arrayDEsLista[i].compare("indiferente")==0 || arrayDEsMensagem[i].compare("indiferente")==0)
                {
                    continue;
                }
                 
                //se o mapeamento nao recebeu dados do fieldset, fica false
                if(arrayDEsMensagem[i].empty())
                {    
                    arrayDEsMensagem[i]="FALSE";                    
                }
                else if(arrayDEsMensagem[i]=="false")
                {    
                    arrayDEsMensagem[i]="FALSE";                    
                }                                
                else if(arrayDEsMensagem[i]=="true")
                {    
                    arrayDEsMensagem[i]="TRUE";                    
                }                

                if(arrayDEsLista[i].empty())
                {
                    arrayDEsLista[i]="FALSE";
                }
                
                //if(arrayDEsMensagem[i] != arrayDEsLista[i])
                //{
                //char buff[100];
                 
                if(arrayDEsLista[i].compare("FALSE")==0 && arrayDEsMensagem[i].compare("TRUE")==0)
                {
                    if(l_logIndevidos.empty())
                    {
                        sprintf(buff,"DE%03d",i);
                    }
                    else
                    {
                        sprintf(buff,", DE%03d",i);
                    }
                    l_logIndevidos.append(buff);                        
                    fieldSet::fscopy( m_result, "TRUE", 4 );                        
                }
                else if(arrayDEsLista[i].compare("TRUE")==0 && arrayDEsMensagem[i].compare("FALSE")==0)
                {
                    if(l_logFaltantes.empty())
                    {
                        sprintf(buff,"DE%03d",i);                        
                    }
                    else
                    {
                        sprintf(buff,", DE%03d",i);                        
                    }
                    l_logFaltantes.append(buff);
                    fieldSet::fscopy( m_result, "TRUE", 4 );
                }
                       
                    //logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, buff, sizeof( buff ) );
                    //return true;
                //}
                /*
                if(arrayDEsLista[i].compare(arrayDEsMensagem[i])!=0)
                {
                    std::cout << "buff [" << buff << "]" << std::endl;
                    std::cout << "arrayDEsMensagem [" << arrayDEsMensagem[i].c_str() << "]" << std::endl;
                    std::cout << "arrayDEsLista [" << arrayDEsLista[i].c_str() << "]" << std::endl;          
                }
                arrayDEsMensagem[i] = "";
                arrayDEsLista[i] = "";
                */
                
            }
            
             /*
            for(int i=2;i<128;i++)
            {
                char buff[100];
                sprintf(buff,"%3d Mensagem[%5s]\t\Lista[%5s]",i,arrayDEsMensagem[i].c_str(),arrayDEsLista[i].c_str());
                std::cout << buff << std::endl;
            }*/           
                    
            if(arrayDEsMensagem[11].compare("TRUE")==0)
            {
                fieldSet::fsextr( l_numeroCT, m_numeroCT );   
            }                                 
                    
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "FALSE", 5 );
            std::string l_msg = "Gen Exception in DEsInvalidos <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "FALSE", 5 );
            std::string l_msg = "std::exception in DEsInvalidos <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }      
        
        std::string l_logSaida="";
        
        if(!l_logIndevidos.empty())
        {
            l_logSaida.append("DEs indevidos: ");
            l_logSaida.append(l_logIndevidos);
        }
        
        if(!l_logFaltantes.empty())
        {
            if(!l_logIndevidos.empty())
                l_logSaida.append(" - ");
            l_logSaida.append("DEs faltando: ");
            l_logSaida.append(l_logFaltantes);
        }               
        
        if(l_logSaida.empty())
        {
            fieldSet::fscopy( m_result, "FALSE", 5 );
        }
        else
        {            
            if(l_numeroCT.empty())
                l_numeroCT = "vazio";
            
            std::cout << "LISTA [" << l_listaDEsValidar.c_str() << "]" << std::endl;
            std::cout << "CT/msgtype/msg_name/versao/origem [" << l_numeroCT.c_str() << "] ["<< l_logSaida.c_str() << "]" << std::endl;        
        
            fieldSet::fscopy( m_result, "TRUE", 5 );
            l_listaDEsValidar="RESULTADO DEINVALIDO: "; 
            l_listaDEsValidar.append(l_logSaida);
            fieldSet::fscopy( m_listaDEsValidar, l_listaDEsValidar.c_str(), l_listaDEsValidar.length());
        }
        

        a_stop = false;
        return( 0 );        
    }


    void DEsInvalidos::setArrayDEsMensagem( std::string lista, std::string arrayDEsLista[], std::string arrayCondicoes[] )
    {
        
        int comeco = 0;
        int de = 0;
        int cond = 0;
        std::string bit;

        int tam = lista.length();
        
        /*
        for(int i=2;i<128;i++)
        {
                char buff[100];
                sprintf(buff,"dentro %3d Lista[%5s]",i,arrayDEsLista[i].c_str());
                std::cout << std::endl << buff;        
        
            //std::cout << std::endl << "dentro arrayDEsLista " << i << " [" << arrayDEsLista[i] << "]";
        }
        
        std::cout << std::endl << "dentro LISTA [" << lista.c_str() << "]" << std::endl;
        */
        
        for(int i=0;i<tam;i++)
        {            
            if(lista[i]==',' || i == tam-1)
            {			
                if(i == tam-1)
                {
                    bit = lista.substr(comeco,tam-comeco);
                }
                else
                {
                    bit = lista.substr(comeco,i-comeco);
                }
                cond = -1;
                
                int inicioTag = bit.find('[');
                if(inicioTag==-1)
                {
                    //obtem parte numerica do DE sem condicao
                    de = atoi(bit.c_str());
                    arrayDEsLista[de]="TRUE";
                    //std::cout << "DE simples: [" << bit.c_str() << "]" << std::endl;                    
                }
                else
                {
                    int fimTag = bit.find_last_of(']');
                    
                    //obtem parte numerica do DE com condicao
                    de = atoi(bit.substr(0,inicioTag).c_str());
                    
                    //ultimo elemento nao tem virgula
                    if(fimTag==-1 &&  i == tam-1)
                    {
                        fimTag=bit.length()+1;
                    }
                    
                    if(fimTag-inicioTag>3)
                    {
                        //aceita C ou c como indicador de condicao
                        inicioTag = bit.find_last_of('C');					
                        if(inicioTag==-1)
                            inicioTag = bit.find_last_of('c');
                        inicioTag++;
                        //std::cout << "[" << bit.substr(inicioTag,fimTag-inicioTag).c_str() << "]" << std::endl;
                        //obtem a parte numerica da condicao
                        cond = atoi(bit.substr(inicioTag,fimTag-inicioTag).c_str());
                    }
                    else
                    {                        
                        cond = 0;
                    }				
                }
                //O ou C000 sao indiferentes para a validacao
                if(cond==0)
                {
                    arrayDEsLista[de]="indiferente";
                }
                else
                {
                    //Se for condicional e essa transacao se enquadra dentro dos parametros
                    //dessa condicao, a presenca desse DE torna-se obrigatoria
                    if(cond!=-1 && arrayCondicoes[cond].compare("TRUE")==0)
                    {
                        arrayDEsLista[de] = "TRUE";
                    }
                    else if(cond!=-1 && arrayCondicoes[cond].compare("indiferente")==0)
                    {
                        arrayDEsLista[de] = "indiferente";
                    }
                }
                //marca o comeco do proximo DE                
                comeco=i+1;
                //se tiver espacos entre a virgula e o proximo DE, pula estes espacos
                while(comeco<tam -1 && lista[comeco]==' ')
                    comeco++;                
            }
        }
    }
    
    bool DEsInvalidos::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value( );
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else if( l_source == "CONDICOES" )
            {
                this->setCondFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return true;
    }

    bool DEsInvalidos::init( )
    {               
        m_numeroCT        = this->navigate( m_targetFieldPath + ".NUMEROCT" );
        m_listaDEsValidar = this->navigate( m_targetFieldPath + ".LISTADES" );          
        m_result          = this->navigate( m_targetFieldPath + ".RESULT" );            
          
        m_DE002 = this->navigate( m_localFieldPath + ".DE002isOn" );
        m_DE003 = this->navigate( m_localFieldPath + ".DE003isOn" );
        m_DE004 = this->navigate( m_localFieldPath + ".DE004isOn" );
        m_DE005 = this->navigate( m_localFieldPath + ".DE005isOn" );
        m_DE006 = this->navigate( m_localFieldPath + ".DE006isOn" );
        m_DE007 = this->navigate( m_localFieldPath + ".DE007isOn" );
        m_DE008 = this->navigate( m_localFieldPath + ".DE008isOn" );
        m_DE009 = this->navigate( m_localFieldPath + ".DE009isOn" );
        m_DE010 = this->navigate( m_localFieldPath + ".DE010isOn" );
        m_DE011 = this->navigate( m_localFieldPath + ".DE011isOn" );
        m_DE012 = this->navigate( m_localFieldPath + ".DE012isOn" );
        m_DE013 = this->navigate( m_localFieldPath + ".DE013isOn" );
        m_DE014 = this->navigate( m_localFieldPath + ".DE014isOn" );
        m_DE015 = this->navigate( m_localFieldPath + ".DE015isOn" );
        m_DE016 = this->navigate( m_localFieldPath + ".DE016isOn" );
        m_DE017 = this->navigate( m_localFieldPath + ".DE017isOn" );
        m_DE018 = this->navigate( m_localFieldPath + ".DE018isOn" );
        m_DE019 = this->navigate( m_localFieldPath + ".DE019isOn" );
        m_DE020 = this->navigate( m_localFieldPath + ".DE020isOn" );
        m_DE021 = this->navigate( m_localFieldPath + ".DE021isOn" );
        m_DE022 = this->navigate( m_localFieldPath + ".DE022isOn" );
        m_DE023 = this->navigate( m_localFieldPath + ".DE023isOn" );
        m_DE024 = this->navigate( m_localFieldPath + ".DE024isOn" );
        m_DE025 = this->navigate( m_localFieldPath + ".DE025isOn" );
        m_DE026 = this->navigate( m_localFieldPath + ".DE026isOn" );
        m_DE027 = this->navigate( m_localFieldPath + ".DE027isOn" );
        m_DE028 = this->navigate( m_localFieldPath + ".DE028isOn" );
        m_DE029 = this->navigate( m_localFieldPath + ".DE029isOn" );
        m_DE030 = this->navigate( m_localFieldPath + ".DE030isOn" );
        m_DE031 = this->navigate( m_localFieldPath + ".DE031isOn" );
        m_DE032 = this->navigate( m_localFieldPath + ".DE032isOn" );
        m_DE033 = this->navigate( m_localFieldPath + ".DE033isOn" );
        m_DE034 = this->navigate( m_localFieldPath + ".DE034isOn" );
        m_DE035 = this->navigate( m_localFieldPath + ".DE035isOn" );
        m_DE036 = this->navigate( m_localFieldPath + ".DE036isOn" );
        m_DE037 = this->navigate( m_localFieldPath + ".DE037isOn" );
        m_DE038 = this->navigate( m_localFieldPath + ".DE038isOn" );
        m_DE039 = this->navigate( m_localFieldPath + ".DE039isOn" );
        m_DE040 = this->navigate( m_localFieldPath + ".DE040isOn" );
        m_DE041 = this->navigate( m_localFieldPath + ".DE041isOn" );
        m_DE042 = this->navigate( m_localFieldPath + ".DE042isOn" );
        m_DE043 = this->navigate( m_localFieldPath + ".DE043isOn" );
        m_DE044 = this->navigate( m_localFieldPath + ".DE044isOn" );
        m_DE045 = this->navigate( m_localFieldPath + ".DE045isOn" );
        m_DE046 = this->navigate( m_localFieldPath + ".DE046isOn" );
        m_DE047 = this->navigate( m_localFieldPath + ".DE047isOn" );
        m_DE048 = this->navigate( m_localFieldPath + ".DE048isOn" );
        m_DE049 = this->navigate( m_localFieldPath + ".DE049isOn" );
        m_DE050 = this->navigate( m_localFieldPath + ".DE050isOn" );
        m_DE051 = this->navigate( m_localFieldPath + ".DE051isOn" );
        m_DE052 = this->navigate( m_localFieldPath + ".DE052isOn" );
        m_DE053 = this->navigate( m_localFieldPath + ".DE053isOn" );
        m_DE054 = this->navigate( m_localFieldPath + ".DE054isOn" );
        m_DE055 = this->navigate( m_localFieldPath + ".DE055isOn" );
        m_DE056 = this->navigate( m_localFieldPath + ".DE056isOn" );
        m_DE057 = this->navigate( m_localFieldPath + ".DE057isOn" );
        m_DE058 = this->navigate( m_localFieldPath + ".DE058isOn" );
        m_DE059 = this->navigate( m_localFieldPath + ".DE059isOn" );
        m_DE060 = this->navigate( m_localFieldPath + ".DE060isOn" );
        m_DE061 = this->navigate( m_localFieldPath + ".DE061isOn" );
        m_DE062 = this->navigate( m_localFieldPath + ".DE062isOn" );
        m_DE063 = this->navigate( m_localFieldPath + ".DE063isOn" );
        m_DE064 = this->navigate( m_localFieldPath + ".DE064isOn" );
        m_DE065 = this->navigate( m_localFieldPath + ".DE065isOn" );
        m_DE066 = this->navigate( m_localFieldPath + ".DE066isOn" );
        m_DE067 = this->navigate( m_localFieldPath + ".DE067isOn" );
        m_DE068 = this->navigate( m_localFieldPath + ".DE068isOn" );
        m_DE069 = this->navigate( m_localFieldPath + ".DE069isOn" );
        m_DE070 = this->navigate( m_localFieldPath + ".DE070isOn" );
        m_DE071 = this->navigate( m_localFieldPath + ".DE071isOn" );
        m_DE072 = this->navigate( m_localFieldPath + ".DE072isOn" );
        m_DE073 = this->navigate( m_localFieldPath + ".DE073isOn" );
        m_DE074 = this->navigate( m_localFieldPath + ".DE074isOn" );
        m_DE075 = this->navigate( m_localFieldPath + ".DE075isOn" );
        m_DE076 = this->navigate( m_localFieldPath + ".DE076isOn" );
        m_DE077 = this->navigate( m_localFieldPath + ".DE077isOn" );
        m_DE078 = this->navigate( m_localFieldPath + ".DE078isOn" );
        m_DE079 = this->navigate( m_localFieldPath + ".DE079isOn" );
        m_DE080 = this->navigate( m_localFieldPath + ".DE080isOn" );
        m_DE081 = this->navigate( m_localFieldPath + ".DE081isOn" );
        m_DE082 = this->navigate( m_localFieldPath + ".DE082isOn" );
        m_DE083 = this->navigate( m_localFieldPath + ".DE083isOn" );
        m_DE084 = this->navigate( m_localFieldPath + ".DE084isOn" );
        m_DE085 = this->navigate( m_localFieldPath + ".DE085isOn" );
        m_DE086 = this->navigate( m_localFieldPath + ".DE086isOn" );
        m_DE087 = this->navigate( m_localFieldPath + ".DE087isOn" );
        m_DE088 = this->navigate( m_localFieldPath + ".DE088isOn" );
        m_DE089 = this->navigate( m_localFieldPath + ".DE089isOn" );
        m_DE090 = this->navigate( m_localFieldPath + ".DE090isOn" );
        m_DE091 = this->navigate( m_localFieldPath + ".DE091isOn" );
        m_DE092 = this->navigate( m_localFieldPath + ".DE092isOn" );
        m_DE093 = this->navigate( m_localFieldPath + ".DE093isOn" );
        m_DE094 = this->navigate( m_localFieldPath + ".DE094isOn" );
        m_DE095 = this->navigate( m_localFieldPath + ".DE095isOn" );
        m_DE096 = this->navigate( m_localFieldPath + ".DE096isOn" );
        m_DE097 = this->navigate( m_localFieldPath + ".DE097isOn" );
        m_DE098 = this->navigate( m_localFieldPath + ".DE098isOn" );
        m_DE099 = this->navigate( m_localFieldPath + ".DE099isOn" );
        m_DE100 = this->navigate( m_localFieldPath + ".DE100isOn" );
        m_DE101 = this->navigate( m_localFieldPath + ".DE101isOn" );
        m_DE102 = this->navigate( m_localFieldPath + ".DE102isOn" );
        m_DE103 = this->navigate( m_localFieldPath + ".DE103isOn" );
        m_DE104 = this->navigate( m_localFieldPath + ".DE104isOn" );
        m_DE105 = this->navigate( m_localFieldPath + ".DE105isOn" );
        m_DE106 = this->navigate( m_localFieldPath + ".DE106isOn" );
        m_DE107 = this->navigate( m_localFieldPath + ".DE107isOn" );
        m_DE108 = this->navigate( m_localFieldPath + ".DE108isOn" );
        m_DE109 = this->navigate( m_localFieldPath + ".DE109isOn" );
        m_DE110 = this->navigate( m_localFieldPath + ".DE110isOn" );
        m_DE111 = this->navigate( m_localFieldPath + ".DE111isOn" );
        m_DE112 = this->navigate( m_localFieldPath + ".DE112isOn" );
        m_DE113 = this->navigate( m_localFieldPath + ".DE113isOn" );
        m_DE114 = this->navigate( m_localFieldPath + ".DE114isOn" );
        m_DE115 = this->navigate( m_localFieldPath + ".DE115isOn" );
        m_DE116 = this->navigate( m_localFieldPath + ".DE116isOn" );
        m_DE117 = this->navigate( m_localFieldPath + ".DE117isOn" );
        m_DE118 = this->navigate( m_localFieldPath + ".DE118isOn" );
        m_DE119 = this->navigate( m_localFieldPath + ".DE119isOn" );
        m_DE120 = this->navigate( m_localFieldPath + ".DE120isOn" );
        m_DE121 = this->navigate( m_localFieldPath + ".DE121isOn" );
        m_DE122 = this->navigate( m_localFieldPath + ".DE122isOn" );
        m_DE123 = this->navigate( m_localFieldPath + ".DE123isOn" );
        m_DE124 = this->navigate( m_localFieldPath + ".DE124isOn" );
        m_DE125 = this->navigate( m_localFieldPath + ".DE125isOn" );
        m_DE126 = this->navigate( m_localFieldPath + ".DE126isOn" );
        m_DE127 = this->navigate( m_localFieldPath + ".DE127isOn" );

        m_COND001 = this->navigate( m_condFieldPath + ".C001" );
        m_COND002 = this->navigate( m_condFieldPath + ".C002" );
        m_COND003 = this->navigate( m_condFieldPath + ".C003" );
        m_COND004 = this->navigate( m_condFieldPath + ".C004" );
        m_COND005 = this->navigate( m_condFieldPath + ".C005" );
        m_COND006 = this->navigate( m_condFieldPath + ".C006" );
        m_COND007 = this->navigate( m_condFieldPath + ".C007" );
        m_COND008 = this->navigate( m_condFieldPath + ".C008" );
        m_COND009 = this->navigate( m_condFieldPath + ".C009" );
        m_COND010 = this->navigate( m_condFieldPath + ".C010" );
        m_COND011 = this->navigate( m_condFieldPath + ".C011" );
        m_COND012 = this->navigate( m_condFieldPath + ".C012" );
        m_COND013 = this->navigate( m_condFieldPath + ".C013" );
        m_COND014 = this->navigate( m_condFieldPath + ".C014" );
        m_COND015 = this->navigate( m_condFieldPath + ".C015" );
        m_COND016 = this->navigate( m_condFieldPath + ".C016" );
        m_COND017 = this->navigate( m_condFieldPath + ".C017" );
        m_COND018 = this->navigate( m_condFieldPath + ".C018" );
        m_COND019 = this->navigate( m_condFieldPath + ".C019" );
        m_COND020 = this->navigate( m_condFieldPath + ".C020" );
        m_COND021 = this->navigate( m_condFieldPath + ".C021" );
        m_COND022 = this->navigate( m_condFieldPath + ".C022" );
        m_COND023 = this->navigate( m_condFieldPath + ".C023" );
        m_COND024 = this->navigate( m_condFieldPath + ".C024" );
        m_COND025 = this->navigate( m_condFieldPath + ".C025" );
        m_COND026 = this->navigate( m_condFieldPath + ".C026" );
        m_COND027 = this->navigate( m_condFieldPath + ".C027" );
        m_COND028 = this->navigate( m_condFieldPath + ".C028" );
        m_COND029 = this->navigate( m_condFieldPath + ".C029" );
        m_COND030 = this->navigate( m_condFieldPath + ".C030" );
        m_COND031 = this->navigate( m_condFieldPath + ".C031" );
        m_COND032 = this->navigate( m_condFieldPath + ".C032" );
        m_COND033 = this->navigate( m_condFieldPath + ".C033" );
        m_COND034 = this->navigate( m_condFieldPath + ".C034" );
        m_COND035 = this->navigate( m_condFieldPath + ".C035" );
        m_COND036 = this->navigate( m_condFieldPath + ".C036" );
        m_COND037 = this->navigate( m_condFieldPath + ".C037" );
        m_COND038 = this->navigate( m_condFieldPath + ".C038" );
        m_COND039 = this->navigate( m_condFieldPath + ".C039" );
        m_COND040 = this->navigate( m_condFieldPath + ".C040" );
        m_COND041 = this->navigate( m_condFieldPath + ".C041" );
        m_COND042 = this->navigate( m_condFieldPath + ".C042" );
        m_COND043 = this->navigate( m_condFieldPath + ".C043" );
        m_COND044 = this->navigate( m_condFieldPath + ".C044" );
        m_COND045 = this->navigate( m_condFieldPath + ".C045" );
        m_COND046 = this->navigate( m_condFieldPath + ".C046" );
        m_COND047 = this->navigate( m_condFieldPath + ".C047" );
        m_COND048 = this->navigate( m_condFieldPath + ".C048" );
        m_COND049 = this->navigate( m_condFieldPath + ".C049" );
        m_COND050 = this->navigate( m_condFieldPath + ".C050" );
        m_COND051 = this->navigate( m_condFieldPath + ".C051" );
        m_COND052 = this->navigate( m_condFieldPath + ".C052" );
        m_COND053 = this->navigate( m_condFieldPath + ".C053" );
        m_COND054 = this->navigate( m_condFieldPath + ".C054" );
        m_COND055 = this->navigate( m_condFieldPath + ".C055" );
        m_COND056 = this->navigate( m_condFieldPath + ".C056" );
        m_COND057 = this->navigate( m_condFieldPath + ".C057" );
        m_COND058 = this->navigate( m_condFieldPath + ".C058" );
        m_COND059 = this->navigate( m_condFieldPath + ".C059" );
        m_COND060 = this->navigate( m_condFieldPath + ".C060" );
        m_COND061 = this->navigate( m_condFieldPath + ".C061" );
        m_COND062 = this->navigate( m_condFieldPath + ".C062" );
        m_COND063 = this->navigate( m_condFieldPath + ".C063" );
        m_COND064 = this->navigate( m_condFieldPath + ".C064" );
        m_COND065 = this->navigate( m_condFieldPath + ".C065" );
        m_COND066 = this->navigate( m_condFieldPath + ".C066" );
        m_COND067 = this->navigate( m_condFieldPath + ".C067" );
        m_COND068 = this->navigate( m_condFieldPath + ".C068" );
        m_COND069 = this->navigate( m_condFieldPath + ".C069" );
        m_COND070 = this->navigate( m_condFieldPath + ".C070" );
        m_COND071 = this->navigate( m_condFieldPath + ".C071" );
        m_COND072 = this->navigate( m_condFieldPath + ".C072" );
        m_COND073 = this->navigate( m_condFieldPath + ".C073" );
        m_COND074 = this->navigate( m_condFieldPath + ".C074" );
        m_COND075 = this->navigate( m_condFieldPath + ".C075" );
        m_COND076 = this->navigate( m_condFieldPath + ".C076" );
        m_COND077 = this->navigate( m_condFieldPath + ".C077" );
        m_COND078 = this->navigate( m_condFieldPath + ".C078" );
        m_COND079 = this->navigate( m_condFieldPath + ".C079" );
        m_COND080 = this->navigate( m_condFieldPath + ".C080" );
        m_COND081 = this->navigate( m_condFieldPath + ".C081" );
        m_COND082 = this->navigate( m_condFieldPath + ".C082" );
        m_COND083 = this->navigate( m_condFieldPath + ".C083" );
        m_COND084 = this->navigate( m_condFieldPath + ".C084" );
        m_COND085 = this->navigate( m_condFieldPath + ".C085" );
        m_COND086 = this->navigate( m_condFieldPath + ".C086" );
        m_COND087 = this->navigate( m_condFieldPath + ".C087" );
        m_COND088 = this->navigate( m_condFieldPath + ".C088" );
        m_COND089 = this->navigate( m_condFieldPath + ".C089" );
        m_COND090 = this->navigate( m_condFieldPath + ".C090" );
        m_COND091 = this->navigate( m_condFieldPath + ".C091" );
        m_COND092 = this->navigate( m_condFieldPath + ".C092" );
        m_COND093 = this->navigate( m_condFieldPath + ".C093" );
        m_COND094 = this->navigate( m_condFieldPath + ".C094" );
        m_COND095 = this->navigate( m_condFieldPath + ".C095" );
        m_COND096 = this->navigate( m_condFieldPath + ".C096" );
        m_COND097 = this->navigate( m_condFieldPath + ".C097" );
        m_COND098 = this->navigate( m_condFieldPath + ".C098" );
        m_COND099 = this->navigate( m_condFieldPath + ".C099" );
        m_COND100 = this->navigate( m_condFieldPath + ".C100" );
        m_COND101 = this->navigate( m_condFieldPath + ".C101" );
        m_COND102 = this->navigate( m_condFieldPath + ".C102" );
        m_COND103 = this->navigate( m_condFieldPath + ".C103" );
        m_COND104 = this->navigate( m_condFieldPath + ".C104" );
        m_COND105 = this->navigate( m_condFieldPath + ".C105" );
        m_COND106 = this->navigate( m_condFieldPath + ".C106" );
        m_COND107 = this->navigate( m_condFieldPath + ".C107" );
        m_COND108 = this->navigate( m_condFieldPath + ".C108" );
        m_COND109 = this->navigate( m_condFieldPath + ".C109" );
        m_COND110 = this->navigate( m_condFieldPath + ".C110" );
        m_COND111 = this->navigate( m_condFieldPath + ".C111" );
        m_COND112 = this->navigate( m_condFieldPath + ".C112" );
        m_COND113 = this->navigate( m_condFieldPath + ".C113" );
        m_COND114 = this->navigate( m_condFieldPath + ".C114" );
        m_COND115 = this->navigate( m_condFieldPath + ".C115" );
        m_COND116 = this->navigate( m_condFieldPath + ".C116" );
        m_COND117 = this->navigate( m_condFieldPath + ".C117" );
        m_COND118 = this->navigate( m_condFieldPath + ".C118" );
        m_COND119 = this->navigate( m_condFieldPath + ".C119" );
        m_COND120 = this->navigate( m_condFieldPath + ".C120" );
        m_COND120 = this->navigate( m_condFieldPath + ".C120" );
        m_COND121 = this->navigate( m_condFieldPath + ".C121" );
        m_COND122 = this->navigate( m_condFieldPath + ".C122" );
        m_COND123 = this->navigate( m_condFieldPath + ".C123" );
        m_COND124 = this->navigate( m_condFieldPath + ".C124" );
        m_COND125 = this->navigate( m_condFieldPath + ".C125" );
        m_COND126 = this->navigate( m_condFieldPath + ".C126" );
        m_COND127 = this->navigate( m_condFieldPath + ".C127" );
        m_COND128 = this->navigate( m_condFieldPath + ".C128" );
        m_COND129 = this->navigate( m_condFieldPath + ".C129" );
        m_COND130 = this->navigate( m_condFieldPath + ".C130" );
        m_COND131 = this->navigate( m_condFieldPath + ".C131" );
        m_COND132 = this->navigate( m_condFieldPath + ".C132" );
        m_COND133 = this->navigate( m_condFieldPath + ".C133" );
        m_COND134 = this->navigate( m_condFieldPath + ".C134" );
        m_COND135 = this->navigate( m_condFieldPath + ".C135" );
        m_COND136 = this->navigate( m_condFieldPath + ".C136" );
        m_COND137 = this->navigate( m_condFieldPath + ".C137" );
        m_COND138 = this->navigate( m_condFieldPath + ".C138" );
        m_COND139 = this->navigate( m_condFieldPath + ".C139" );
        m_COND140 = this->navigate( m_condFieldPath + ".C140" );
        m_COND141 = this->navigate( m_condFieldPath + ".C141" );
        m_COND142 = this->navigate( m_condFieldPath + ".C142" );
        m_COND143 = this->navigate( m_condFieldPath + ".C143" );
        m_COND144 = this->navigate( m_condFieldPath + ".C144" );
        m_COND145 = this->navigate( m_condFieldPath + ".C145" );
        m_COND146 = this->navigate( m_condFieldPath + ".C146" );
        m_COND147 = this->navigate( m_condFieldPath + ".C147" );
        m_COND148 = this->navigate( m_condFieldPath + ".C148" );
        m_COND149 = this->navigate( m_condFieldPath + ".C149" );
        m_COND150 = this->navigate( m_condFieldPath + ".C150" );
        m_COND151 = this->navigate( m_condFieldPath + ".C151" );
        m_COND152 = this->navigate( m_condFieldPath + ".C152" );
        m_COND153 = this->navigate( m_condFieldPath + ".C153" );
        m_COND154 = this->navigate( m_condFieldPath + ".C154" );
        m_COND155 = this->navigate( m_condFieldPath + ".C155" );
        m_COND156 = this->navigate( m_condFieldPath + ".C156" );
        m_COND157 = this->navigate( m_condFieldPath + ".C157" );
        m_COND158 = this->navigate( m_condFieldPath + ".C158" );
        m_COND159 = this->navigate( m_condFieldPath + ".C159" );
        m_COND160 = this->navigate( m_condFieldPath + ".C160" );
        m_COND161 = this->navigate( m_condFieldPath + ".C161" );
        m_COND162 = this->navigate( m_condFieldPath + ".C162" );
        m_COND163 = this->navigate( m_condFieldPath + ".C163" );
        m_COND164 = this->navigate( m_condFieldPath + ".C164" );
        m_COND165 = this->navigate( m_condFieldPath + ".C165" );
        m_COND166 = this->navigate( m_condFieldPath + ".C166" );
        m_COND167 = this->navigate( m_condFieldPath + ".C167" );
        m_COND168 = this->navigate( m_condFieldPath + ".C168" );
        m_COND169 = this->navigate( m_condFieldPath + ".C169" );
        m_COND170 = this->navigate( m_condFieldPath + ".C170" );
        m_COND171 = this->navigate( m_condFieldPath + ".C171" );
        m_COND172 = this->navigate( m_condFieldPath + ".C172" );
        m_COND173 = this->navigate( m_condFieldPath + ".C173" );
        m_COND174 = this->navigate( m_condFieldPath + ".C174" );
        m_COND175 = this->navigate( m_condFieldPath + ".C175" );
        m_COND176 = this->navigate( m_condFieldPath + ".C176" );
        m_COND177 = this->navigate( m_condFieldPath + ".C177" );
        m_COND178 = this->navigate( m_condFieldPath + ".C178" );
        m_COND179 = this->navigate( m_condFieldPath + ".C179" );
        m_COND180 = this->navigate( m_condFieldPath + ".C180" );
        m_COND181 = this->navigate( m_condFieldPath + ".C181" );
        m_COND182 = this->navigate( m_condFieldPath + ".C182" );
        m_COND183 = this->navigate( m_condFieldPath + ".C183" );
        m_COND184 = this->navigate( m_condFieldPath + ".C184" );
        m_COND185 = this->navigate( m_condFieldPath + ".C185" );
        m_COND186 = this->navigate( m_condFieldPath + ".C186" );
        m_COND187 = this->navigate( m_condFieldPath + ".C187" );
        m_COND188 = this->navigate( m_condFieldPath + ".C188" );
        m_COND189 = this->navigate( m_condFieldPath + ".C189" );
        m_COND190 = this->navigate( m_condFieldPath + ".C190" );
        m_COND191 = this->navigate( m_condFieldPath + ".C191" );
        m_COND192 = this->navigate( m_condFieldPath + ".C192" );
        m_COND193 = this->navigate( m_condFieldPath + ".C193" );
        m_COND194 = this->navigate( m_condFieldPath + ".C194" );
        m_COND195 = this->navigate( m_condFieldPath + ".C195" );
        m_COND196 = this->navigate( m_condFieldPath + ".C196" );
        m_COND197 = this->navigate( m_condFieldPath + ".C197" );
        m_COND198 = this->navigate( m_condFieldPath + ".C198" );
        m_COND199 = this->navigate( m_condFieldPath + ".C199" );
        m_COND200 = this->navigate( m_condFieldPath + ".C200" );
        m_COND201 = this->navigate( m_condFieldPath + ".C201" );
        m_COND202 = this->navigate( m_condFieldPath + ".C202" );
        m_COND203 = this->navigate( m_condFieldPath + ".C203" );
        m_COND204 = this->navigate( m_condFieldPath + ".C204" );
        m_COND205 = this->navigate( m_condFieldPath + ".C205" );
        m_COND206 = this->navigate( m_condFieldPath + ".C206" );
        m_COND207 = this->navigate( m_condFieldPath + ".C207" );
        m_COND208 = this->navigate( m_condFieldPath + ".C208" );
        m_COND209 = this->navigate( m_condFieldPath + ".C209" );
        m_COND210 = this->navigate( m_condFieldPath + ".C210" );
        m_COND211 = this->navigate( m_condFieldPath + ".C211" );
        m_COND212 = this->navigate( m_condFieldPath + ".C212" );
        m_COND213 = this->navigate( m_condFieldPath + ".C213" );
        m_COND214 = this->navigate( m_condFieldPath + ".C214" );
        m_COND215 = this->navigate( m_condFieldPath + ".C215" );
        m_COND216 = this->navigate( m_condFieldPath + ".C216" );
        m_COND217 = this->navigate( m_condFieldPath + ".C217" );
        m_COND218 = this->navigate( m_condFieldPath + ".C218" );
        m_COND219 = this->navigate( m_condFieldPath + ".C219" );
        m_COND220 = this->navigate( m_condFieldPath + ".C220" );
        m_COND221 = this->navigate( m_condFieldPath + ".C221" );
        m_COND222 = this->navigate( m_condFieldPath + ".C222" );
        m_COND223 = this->navigate( m_condFieldPath + ".C223" );
        m_COND224 = this->navigate( m_condFieldPath + ".C224" );
        m_COND225 = this->navigate( m_condFieldPath + ".C225" );
        m_COND226 = this->navigate( m_condFieldPath + ".C226" );
        m_COND227 = this->navigate( m_condFieldPath + ".C227" );
        m_COND228 = this->navigate( m_condFieldPath + ".C228" );
        m_COND229 = this->navigate( m_condFieldPath + ".C229" );
        m_COND230 = this->navigate( m_condFieldPath + ".C230" );
        m_COND231 = this->navigate( m_condFieldPath + ".C231" );
        m_COND232 = this->navigate( m_condFieldPath + ".C232" );
        m_COND233 = this->navigate( m_condFieldPath + ".C233" );
        m_COND234 = this->navigate( m_condFieldPath + ".C234" );
        m_COND235 = this->navigate( m_condFieldPath + ".C235" );
        m_COND236 = this->navigate( m_condFieldPath + ".C236" );
        m_COND237 = this->navigate( m_condFieldPath + ".C237" );
        m_COND238 = this->navigate( m_condFieldPath + ".C238" );
        m_COND239 = this->navigate( m_condFieldPath + ".C239" );
        m_COND240 = this->navigate( m_condFieldPath + ".C240" );
        m_COND241 = this->navigate( m_condFieldPath + ".C241" );
        m_COND242 = this->navigate( m_condFieldPath + ".C242" );
        m_COND243 = this->navigate( m_condFieldPath + ".C243" );
        m_COND244 = this->navigate( m_condFieldPath + ".C244" );
        m_COND245 = this->navigate( m_condFieldPath + ".C245" );
        m_COND246 = this->navigate( m_condFieldPath + ".C246" );
        m_COND247 = this->navigate( m_condFieldPath + ".C247" );
        m_COND248 = this->navigate( m_condFieldPath + ".C248" );
        m_COND249 = this->navigate( m_condFieldPath + ".C249" );
        m_COND250 = this->navigate( m_condFieldPath + ".C250" );
        m_COND251 = this->navigate( m_condFieldPath + ".C251" );
        m_COND252 = this->navigate( m_condFieldPath + ".C252" );
        m_COND253 = this->navigate( m_condFieldPath + ".C253" );
        m_COND254 = this->navigate( m_condFieldPath + ".C254" );
        m_COND255 = this->navigate( m_condFieldPath + ".C255" );
        m_COND256 = this->navigate( m_condFieldPath + ".C256" );
        m_COND257 = this->navigate( m_condFieldPath + ".C257" );
        m_COND258 = this->navigate( m_condFieldPath + ".C258" );
        m_COND259 = this->navigate( m_condFieldPath + ".C259" );
        m_COND260 = this->navigate( m_condFieldPath + ".C260" );
        m_COND261 = this->navigate( m_condFieldPath + ".C261" );
        m_COND262 = this->navigate( m_condFieldPath + ".C262" );
        m_COND263 = this->navigate( m_condFieldPath + ".C263" );
        m_COND264 = this->navigate( m_condFieldPath + ".C264" );
        m_COND265 = this->navigate( m_condFieldPath + ".C265" );
        m_COND266 = this->navigate( m_condFieldPath + ".C266" );
        m_COND267 = this->navigate( m_condFieldPath + ".C267" );
        m_COND268 = this->navigate( m_condFieldPath + ".C268" );
        m_COND269 = this->navigate( m_condFieldPath + ".C269" );
        m_COND270 = this->navigate( m_condFieldPath + ".C270" );
        m_COND271 = this->navigate( m_condFieldPath + ".C271" );
        m_COND272 = this->navigate( m_condFieldPath + ".C272" );
        m_COND273 = this->navigate( m_condFieldPath + ".C273" );
        m_COND274 = this->navigate( m_condFieldPath + ".C274" );
        m_COND275 = this->navigate( m_condFieldPath + ".C275" );
        m_COND276 = this->navigate( m_condFieldPath + ".C276" );
        m_COND277 = this->navigate( m_condFieldPath + ".C277" );
        m_COND278 = this->navigate( m_condFieldPath + ".C278" );
        m_COND279 = this->navigate( m_condFieldPath + ".C279" );
        m_COND280 = this->navigate( m_condFieldPath + ".C280" );
        m_COND281 = this->navigate( m_condFieldPath + ".C281" );
        m_COND282 = this->navigate( m_condFieldPath + ".C282" );
        m_COND283 = this->navigate( m_condFieldPath + ".C283" );
        m_COND284 = this->navigate( m_condFieldPath + ".C284" );
        m_COND285 = this->navigate( m_condFieldPath + ".C285" );
        m_COND286 = this->navigate( m_condFieldPath + ".C286" );
        m_COND287 = this->navigate( m_condFieldPath + ".C287" );
        m_COND288 = this->navigate( m_condFieldPath + ".C288" );
        m_COND289 = this->navigate( m_condFieldPath + ".C289" );
        m_COND290 = this->navigate( m_condFieldPath + ".C290" );
        m_COND291 = this->navigate( m_condFieldPath + ".C291" );
        m_COND292 = this->navigate( m_condFieldPath + ".C292" );
        m_COND293 = this->navigate( m_condFieldPath + ".C293" );
        m_COND294 = this->navigate( m_condFieldPath + ".C294" );
        m_COND295 = this->navigate( m_condFieldPath + ".C295" );
        m_COND296 = this->navigate( m_condFieldPath + ".C296" );
        m_COND297 = this->navigate( m_condFieldPath + ".C297" );
        m_COND298 = this->navigate( m_condFieldPath + ".C298" );
        m_COND299 = this->navigate( m_condFieldPath + ".C299" );
        m_COND300 = this->navigate( m_condFieldPath + ".C300" );
        m_COND301 = this->navigate( m_condFieldPath + ".C301" );
        m_COND302 = this->navigate( m_condFieldPath + ".C302" );
        m_COND303 = this->navigate( m_condFieldPath + ".C303" );
        m_COND304 = this->navigate( m_condFieldPath + ".C304" );
        m_COND305 = this->navigate( m_condFieldPath + ".C305" );
        m_COND306 = this->navigate( m_condFieldPath + ".C306" );
        m_COND307 = this->navigate( m_condFieldPath + ".C307" );
        m_COND308 = this->navigate( m_condFieldPath + ".C308" );
        m_COND309 = this->navigate( m_condFieldPath + ".C309" );
        m_COND310 = this->navigate( m_condFieldPath + ".C310" );
        m_COND311 = this->navigate( m_condFieldPath + ".C311" );
        m_COND312 = this->navigate( m_condFieldPath + ".C312" );
        m_COND313 = this->navigate( m_condFieldPath + ".C313" );
        m_COND314 = this->navigate( m_condFieldPath + ".C314" );
        m_COND315 = this->navigate( m_condFieldPath + ".C315" );
        m_COND316 = this->navigate( m_condFieldPath + ".C316" );
        m_COND317 = this->navigate( m_condFieldPath + ".C317" );
        m_COND318 = this->navigate( m_condFieldPath + ".C318" );
        m_COND319 = this->navigate( m_condFieldPath + ".C319" );
        m_COND320 = this->navigate( m_condFieldPath + ".C320" );
        m_COND321 = this->navigate( m_condFieldPath + ".C321" );
        m_COND322 = this->navigate( m_condFieldPath + ".C322" );
        m_COND323 = this->navigate( m_condFieldPath + ".C323" );
        m_COND324 = this->navigate( m_condFieldPath + ".C324" );
        m_COND325 = this->navigate( m_condFieldPath + ".C325" );
        m_COND326 = this->navigate( m_condFieldPath + ".C326" );
        m_COND327 = this->navigate( m_condFieldPath + ".C327" );
        m_COND328 = this->navigate( m_condFieldPath + ".C328" );
        m_COND329 = this->navigate( m_condFieldPath + ".C329" );
        m_COND330 = this->navigate( m_condFieldPath + ".C330" );
        m_COND331 = this->navigate( m_condFieldPath + ".C331" );
        m_COND332 = this->navigate( m_condFieldPath + ".C332" );
        m_COND333 = this->navigate( m_condFieldPath + ".C333" );
        m_COND334 = this->navigate( m_condFieldPath + ".C334" );
        m_COND335 = this->navigate( m_condFieldPath + ".C335" );
        m_COND336 = this->navigate( m_condFieldPath + ".C336" );
        m_COND337 = this->navigate( m_condFieldPath + ".C337" );
        m_COND338 = this->navigate( m_condFieldPath + ".C338" );
        m_COND339 = this->navigate( m_condFieldPath + ".C339" );
        m_COND340 = this->navigate( m_condFieldPath + ".C340" );
        m_COND341 = this->navigate( m_condFieldPath + ".C341" );
        m_COND342 = this->navigate( m_condFieldPath + ".C342" );
        m_COND343 = this->navigate( m_condFieldPath + ".C343" );
        m_COND344 = this->navigate( m_condFieldPath + ".C344" );
        m_COND345 = this->navigate( m_condFieldPath + ".C345" );
        m_COND346 = this->navigate( m_condFieldPath + ".C346" );
        m_COND347 = this->navigate( m_condFieldPath + ".C347" );
        m_COND348 = this->navigate( m_condFieldPath + ".C348" );
        m_COND349 = this->navigate( m_condFieldPath + ".C349" );
        m_COND350 = this->navigate( m_condFieldPath + ".C350" );        
        
        return( true );
    }

    void DEsInvalidos::finish( )
    {
    }

    DEsInvalidos& DEsInvalidos::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    DEsInvalidos& DEsInvalidos::setCondFieldPath( const std::string& a_path )
    {
        m_condFieldPath = a_path;
        return( *this );
    }
   
    DEsInvalidos& DEsInvalidos::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    
    DEsInvalidos& DEsInvalidos::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }
 
    dataManip::Command* DEsInvalidos::clone( ) const
    {
        return( new DEsInvalidos( *this ) );
    }
    
    
}