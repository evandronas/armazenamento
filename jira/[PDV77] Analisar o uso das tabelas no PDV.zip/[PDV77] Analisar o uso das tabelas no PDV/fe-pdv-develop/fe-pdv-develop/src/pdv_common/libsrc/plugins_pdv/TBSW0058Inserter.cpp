#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0058.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0058Inserter.hpp"

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "dbaccess_pdv/TBSW0058RegrasFormatacao.hpp"
#include<iostream>

// Release Bandeiras PDV - Abril 2019
using namespace std;

namespace plugins_pdv
{
    base::Identificable* createTBSW0058Inserter( )
    {
        TBSW0058Inserter* l_new = new TBSW0058Inserter;
        return( l_new );
    }

    bool TBSW0058Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value( );
            if ( l_source == "target" )
            {
                this->setSourceFieldPath( l_source );
            }
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_target = l_tagList.front( ).findProperty( "value" ).value( );
        this->setTargetFieldPath( l_target );

        return( true );
    }

    TBSW0058Inserter::TBSW0058Inserter( )
    {
    }

    TBSW0058Inserter::~TBSW0058Inserter( )
    {
    }

    bool TBSW0058Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        
        m_local_time       = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_local_date       = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_msgtype          = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_cd_ems           = this->navigate( m_sourceFieldPath + ".segments.common.cd_ems" );
        m_amount           = this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
        m_acq_currency_code= this->navigate( m_sourceFieldPath + ".shc_msg.acq_currency_code" );
        m_mer_cat_code     = this->navigate( m_sourceFieldPath + ".segments.merchant.mer_cat_code" );
        m_orig_pan         = this->navigate( m_sourceFieldPath + ".segments.common.orig_pan" );
        m_bin              = this->navigate( m_sourceFieldPath + ".segments.common.bin" );
        m_pcode            = this->navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        m_refnum           = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_transcode        = this->navigate( m_sourceFieldPath + ".segments.common.transcode" );
        m_pb_reason_code   = this->navigate( m_sourceFieldPath + ".segments.common.pb_reason_code" );
        m_termloc          = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_pos_entry_code   = this->navigate( m_sourceFieldPath + ".shc_msg.pos_entry_code" );
        m_expiry_date      = this->navigate( m_sourceFieldPath + ".shc_data.expiry_date" );
        m_trandate         = this->navigate( m_sourceFieldPath + ".shc_msg.trandate" );
        m_trantime         = this->navigate( m_sourceFieldPath + ".shc_msg.trantime" );
        m_trace            = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
        m_dt_vdd_pre_auz   = this->navigate( m_sourceFieldPath + ".segments.credit.dt_vdd_pre_auz" );
        m_cod_bndr         = this->navigate( m_sourceFieldPath + ".segments.common.cod_bndr" );
        m_issuer           = this->navigate( m_sourceFieldPath + ".shc_msg.issuer" );
        m_status           = this->navigate( m_sourceFieldPath + ".segments.common.status" );
        m_mc_info_ica      = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_ica" );
        m_track2           = this->navigate( m_sourceFieldPath + ".shc_msg.track2" );
        m_authnum          = this->navigate( m_sourceFieldPath + ".shc_msg.authnum" );
        m_termid           = this->navigate( m_sourceFieldPath + ".shc_msg.termid" ); 
        //m_origdate         = this->navigate( m_sourceFieldPath + ".shc_msg.origdate"            );
        //m_origtime         = this->navigate( m_sourceFieldPath + ".shc_msg.origtime"            );
        //m_origtrace        = this->navigate( m_sourceFieldPath + ".shc_msg.origtrace"           );
        //m_origrefnum       = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum"  );
        //m_origpan          = this->navigate( m_sourceFieldPath + ".segments.common.orig_pan"    );
        //m_origauthnum      = this->navigate( m_sourceFieldPath + ".segments.common.orig_authnum");  
        m_mc_info_country  = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_country"); 
        m_termid_type      = this->navigate( m_sourceFieldPath + ".segments.common.termid_type");
        m_cod_cndc_cptr    = this->navigate( m_sourceFieldPath + ".segments.common.cod_cndc_cptr");
        m_addresponse      = this->navigate( m_sourceFieldPath + ".shc_msg.addresponse" );
        m_has_pin          = this->navigate( m_sourceFieldPath + ".segments.common.has_pin" );
        
        m_cod_gru_estb      = this->navigate( m_localFieldPath + ".cod_gru_estb"); 
        m_cod_mtz_estb      = this->navigate( m_localFieldPath + ".cod_mtz_estb"); 
        m_receive_inst_id      = this->navigate( m_sourceFieldPath + ".shc_msg.receive_inst_id"); 
        
        m_iss_name =         this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_msg_category =     this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        m_acq_name = this->navigate( m_sourceFieldPath + ".segments.common.acq_name" );
        m_msg_name =         this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        m_is_pre_auth =      this->navigate( m_sourceFieldPath + ".segments.common.is_pre_auth" );
        m_install_num =      this->navigate( m_sourceFieldPath + ".segments.common.install_num" );

        m_isVan            = this->navigate( m_localFieldPath  + ".isVan" );

        m_cod_gru_clas_ram = this->navigate( m_localFieldPath  + ".cod_gru_clas_ram" );
        m_track3           = this->navigate( m_sourceFieldPath + ".shc_msg.track3" );

        m_tokenIdentifier  = this->navigate( m_sourceFieldPath + ".segments.common.tokenIdentifier" );
        m_codigoOrigemRespostaAutorizacao = this->navigate( m_sourceFieldPath + ".segments.common.codigoOrigemRespostaAutorizacao" );
        // Release Bandeiras PDV - Abril 2019 - INICIO
        indicadorModoEntrada = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorModoEntrada") );
        indicadorPresencaPortador = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorPresencaPortador") );
        indicadorTecnologiaTerminal = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorTecnologiaTerminal") );
        // Release Bandeiras PDV - Abril 2019 - FIM
        
        return( true );
        
        //std::string source_components[ ] =
        //{
        //    "shc_msg.acq_currency_code",                 //0
        //    "shc_msg.track2",                            //1
        //    "shc_msg.termid",                            //2
        //    "shc_msg.trandate",                          //3
        //    "shc_msg.local_date",                        //4
        //    "shc_msg.origdate",                          //5
        //    "shc_msg.origdate",                          //6
        //    "shc_msg.trantime",                          //7
        //    "shc_msg.local_time",                        //8
        //    "shc_msg.authnum",                           //9
        //    "shc_msg.pan",                               //10
        //    "shc_msg.termloc",                           //11
        //    "shc_msg.trace",                             //12
        //    "shc_msg.refnum",                            //13
        //    "shc_msg.pos_entry_code",                    //14
        //    "shc_msg.amount",                            //15
        //    "shc_msg.msgtype",                           //16
        //    "shc_msg.pcode",                             //17
        //    "shc_data.expiry_date",                      //18
        //    "segments.common.cod_bndr",                  //19
        //    "segments.common.cd_ems",                    //20
        //    "segments.common.az_reason_code",            //21
        //    "segments.common.ext_network_code",          //22
        //    "segments.common.transcode",                 //23
        //    "segments.common.orig_pan",                  //24
        //    "segments.common.pb_reason_code",            //25
        //    "segments.common.status",                    //26
        //    "segments.merchant.mer_cat_code",            //27
        //    "shc_msg.tra_currency_code",                 //28
        //    "shc_msg.pos_condition_code",                //29
        //    "shc_msg.pos_cap_code",                      //30
        //    "shc_msg.pos_pin_cap_code",                  //31
        //    "segments.common.nom_site_issr",             //32
        //    "segments.common.nom_host_issr",             //33
        //    "segments.common.nom_fe_issr",               //34
        //    "segments.credit.dt_vdd_pre_auz",            //35
        //    "segments.common.issuer_id",                 //36
        //    "segments.common.bin",                       //37
        //    "segments.common.install_num",               //38
        //    "segments.common.termid_type",               //39
        //    "segments.common.is_3a_perna",               //40
        //    "segments.credit.mc_info_local",             //41
        //    "shc_msg.origtrace",                         //42
		//	"shc_msg.acquirer_data",                     //43
		//	"shc_msg.issuer",                            //44
		//	"segments.merchant.mer_name",                //45
		//	"segments.common.cod_cndc_cptr",             //46
        //    "segments.credit.mc_info_ica",               //47
        //
        //    //t694449@FIS-BEGIN: 11.11.2013 - Adicionado campos novos GAP3 ---------------//
        //    "segments.voucher.ctah",                     //48
        //    //t694449@FIS-END: 11.11.2013 - Adicionado campos novos GAP3 -----------------//
        //    "segments.common.terminal_attendance_indicator", //49
		//	"segments.common.terminal_operator_indicator",   //50
		//	"segments.common.terminal_location_indicator",   //51
		//	"segments.common.cardholder_presence_indicator", //52
		//	"segments.common.card_presence_indicator",       //53
		//	"segments.common.card_capture_capabilities_indicator", //54
		//	"segments.common.transaction_status_indicator",        //55
		//	"segments.common.transaction_security_indicator",      //56
		//	"segments.common.transaction_routing_indicator",       //58
		//	"segments.common.cardholder_activated_terminal_level_indicator", //58
		//	"segments.common.card_data_terminal_input_capability_indicator"  //59
        //};
        
    }

    void TBSW0058Inserter::finish( )
    {
    }

    int TBSW0058Inserter::execute( bool& a_stop )
    {
        try
        {            
            dbaccess_pdv::TBSW0058RegrasFormatacao regrasFormatacao;
            dbaccess_common::TBSW0058 tbsw0058;
            acq_common::tbsw0058_params tbsw0058_params = { 0 };
            
            fieldSet::fsextr( tbsw0058_params.local_time,        m_local_time       );
            fieldSet::fsextr( tbsw0058_params.local_date,        m_local_date       );
            fieldSet::fsextr( tbsw0058_params.msgtype,           m_msgtype          );
            fieldSet::fsextr( tbsw0058_params.cd_ems,            m_cd_ems           );
            fieldSet::fsextr( tbsw0058_params.amount,            m_amount           );
            fieldSet::fsextr( tbsw0058_params.acq_currency_code, m_acq_currency_code);
            fieldSet::fsextr( tbsw0058_params.mer_cat_code,      m_mer_cat_code     );
            fieldSet::fsextr( tbsw0058_params.orig_pan,          m_orig_pan         );
            fieldSet::fsextr( tbsw0058_params.bin,               m_bin              );
            fieldSet::fsextr( tbsw0058_params.pcode,             m_pcode            );
            fieldSet::fsextr( tbsw0058_params.refnum,            m_refnum           );
            fieldSet::fsextr( tbsw0058_params.transcode,         m_transcode        );
            fieldSet::fsextr( tbsw0058_params.pb_reason_code,    m_pb_reason_code   );
            fieldSet::fsextr( tbsw0058_params.termloc,           m_termloc          );
            fieldSet::fsextr( tbsw0058_params.pos_entry_code,    m_pos_entry_code   );
            fieldSet::fsextr( tbsw0058_params.expiry_date,       m_expiry_date      );
            fieldSet::fsextr( tbsw0058_params.trandate,          m_trandate         );
            fieldSet::fsextr( tbsw0058_params.trantime,          m_trantime         );
            fieldSet::fsextr( tbsw0058_params.trace,             m_trace            );
            fieldSet::fsextr( tbsw0058_params.dt_vdd_pre_auz,    m_dt_vdd_pre_auz   );
            fieldSet::fsextr( tbsw0058_params.cod_bndr,          m_cod_bndr         );
            fieldSet::fsextr( tbsw0058_params.issuer,            m_issuer           );
            //fieldSet::fsextr( tbsw0058_params.cod_ctah_voch,     m_cod_ctah_voch    );
            fieldSet::fsextr( tbsw0058_params.status,            m_status           );
            fieldSet::fsextr( tbsw0058_params.mc_info_ica,       m_mc_info_ica      );
            fieldSet::fsextr( tbsw0058_params.track2,            m_track2           );
            fieldSet::fsextr( tbsw0058_params.authnum,           m_authnum          );
            fieldSet::fsextr( tbsw0058_params.termid,            m_termid           );
            fieldSet::fsextr( tbsw0058_params.cod_gru_estb,      m_cod_gru_estb     );
            fieldSet::fsextr( tbsw0058_params.cod_mtz_estb,      m_cod_mtz_estb     );
            fieldSet::fsextr( tbsw0058_params.receive_inst_id,   m_receive_inst_id     );   
            fieldSet::fsextr( tbsw0058_params.termid_type,       m_termid_type      ); 
            fieldSet::fsextr( tbsw0058_params.cod_cndc_cptr,     m_cod_cndc_cptr    ); 
            fieldSet::fsextr( tbsw0058_params.addresponse,       m_addresponse      ); 
            fieldSet::fsextr( tbsw0058_params.has_pin,           m_has_pin          );
            
            fieldSet::fsextr( tbsw0058_params.iss_name         ,       m_iss_name         );
            fieldSet::fsextr( tbsw0058_params.msg_category     ,       m_msg_category     );
            fieldSet::fsextr( tbsw0058_params.acq_name ,       m_acq_name );
            fieldSet::fsextr( tbsw0058_params.msg_name         ,       m_msg_name         );
            fieldSet::fsextr( tbsw0058_params.is_pre_auth      ,       m_is_pre_auth      );
            fieldSet::fsextr( tbsw0058_params.install_num      ,       m_install_num      );
            fieldSet::fsextr( tbsw0058_params.isVan            ,       m_isVan            );
            fieldSet::fsextr( tbsw0058_params.cod_gru_clas_ram ,       m_cod_gru_clas_ram );
            
            fieldSet::fsextr( tbsw0058_params.track3,            m_track3           );

            fieldSet::fsextr( tbsw0058_params.tokenIdentifier  ,       m_tokenIdentifier  );
            fieldSet::fsextr( tbsw0058_params.codigoOrigemRespostaAutorizacao , m_codigoOrigemRespostaAutorizacao );
            
            // Release Bandeiras PDV - Abril 2019 - INICIO
            string localIndicadorModoEntrada = "";
            fieldSet::fsextr( localIndicadorModoEntrada, indicadorModoEntrada );
            fieldSet::fsextr( tbsw0058_params.indicadorPresencaPortador, indicadorPresencaPortador );
            fieldSet::fsextr( tbsw0058_params.indicadorTecnologiaTerminal, indicadorTecnologiaTerminal );

            if ( ( ( tbsw0058_params.iss_name.compare("ELO_CRT_FULL") == 0 ) 
                    || ( tbsw0058_params.iss_name.compare("ELO_DBT_FULL") == 0 ) )
                && (localIndicadorModoEntrada.compare("1") == 0) )
            {
                tbsw0058_params.pos_entry_code = "861";
            }
            // Release Bandeiras PDV - Abril 2019 - FIM

            regrasFormatacao.DAT_MOV_TRAN      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_SEQ_UNC       ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.DTH_GMT           ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.DTH_INI_TRAN      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_BNDR          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.DAT_PAUZ          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_MSG_ISO       ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_PCM_ISO       ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.TIP_TRAN          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.IND_RD_ORG        ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_RD_ORG        ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_GRU_ESTB      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_MTZ_ESTB      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_ESTB          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_TERM          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_STAN          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_RAM_ATVD      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_POS_ENTR_MODO ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_EMSR          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_CAR           ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_PAIS_CAR      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_TRK_CAR       ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.DAT_VLD_CAR       ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_SERV_SNHA     ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.VAL_TRAN          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_MOED          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.VAL_TRAN_DLR      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.VAL_COT_DLR       ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_MOT_RSPS      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.DTH_STTU_TRAN     ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.DAT_VLD_PAUZ      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.IND_RD_CPTR       ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_CNDC_CPTR     ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.IND_STTU_TRAN     ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_EMSR          ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_ID_CAR        ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NOM_SITE_ACQR_ORGL( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NOM_HOST_ACQR_ORGL( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NOM_FE_ACQR_ORGL  ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NOM_SITE_ISSR     ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NOM_HOST_ISSR     ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.IND_EMSR_MTC      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_AVSO_AUT      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NTWK_ID_ACQR_ORGL ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NTWK_ID_ROUTE_ORGL( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NTWK_ID_ISSR_ORGL ( tbsw0058, tbsw0058_params, acq_common::INSERT ); 
            regrasFormatacao.COD_TIP_PROD_CAR  ( tbsw0058, tbsw0058_params, acq_common::INSERT ); 
            regrasFormatacao.COD_GRU_CLAS_RAM  ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.NUM_REF_TRAN      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_CPCD_TERM     ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.IND_TRAN_TKN      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.QTD_PRCL_CNFR     ( tbsw0058, tbsw0058_params, acq_common::INSERT );

            regrasFormatacao.IND_TRAN_TKN      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.COD_ORG_APRV      ( tbsw0058, tbsw0058_params, acq_common::INSERT );
            
            // Release Bandeiras PDV - Abril 2019 - INICIO
            regrasFormatacao.IndicadorPresencaPortador( tbsw0058, tbsw0058_params, acq_common::INSERT );
            regrasFormatacao.IndicadorTecnologiaTerminal( tbsw0058, tbsw0058_params, acq_common::INSERT );
            // Release Bandeiras PDV - Abril 2019 - FIM

			tbsw0058.show( 0 );            

            tbsw0058.insert( );
            tbsw0058.commit( );
            this->setResult( "OK" );
        }
        catch ( base::GenException e )
        {
            this->setResult( "NOT INSERTED" );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0058 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            this->setResult( "NOT INSERTED" );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0058 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        fieldSet::fscopy( m_result, this->getResult( ) );
        a_stop = false;
        return( 0 );
    }

    TBSW0058Inserter& TBSW0058Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0058Inserter& TBSW0058Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }
    TBSW0058Inserter& TBSW0058Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    TBSW0058Inserter& TBSW0058Inserter::setResult( const std::string& a_result )
    {
        m_str_result = a_result;
        return( *this );
    }

    std::string TBSW0058Inserter::getResult( )
    {
        return( m_str_result );
    }

    dataManip::Command* TBSW0058Inserter::clone( ) const
    {
        return( new TBSW0058Inserter( *this ) );
    }
}//namespace standardAcqPlugins


