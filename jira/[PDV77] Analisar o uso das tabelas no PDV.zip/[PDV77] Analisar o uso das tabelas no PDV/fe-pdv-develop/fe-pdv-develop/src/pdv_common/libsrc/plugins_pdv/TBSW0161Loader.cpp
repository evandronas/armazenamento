/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0161.hpp"
#include "plugins_pdv/TBSW0161Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
	base::Identificable* createTBSW0161Loader( )
	{
		TBSW0161Loader* l_new = new TBSW0161Loader;
		return l_new;
	}
	bool TBSW0161Loader::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		
		a_tag->findTag( "sourceFieldPath", l_tagList );
		this->setSourceFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
		a_tag->findTag( "targetFieldPath", l_tagList );		
		this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
		
		return true;
	}
	TBSW0161Loader::TBSW0161Loader( )
	{
	}
	TBSW0161Loader::~TBSW0161Loader( )
	{
	}
	bool TBSW0161Loader::init( )
	{
		m_RESULT = this->navigate( m_targetFieldPath + ".RESULT" );
        m_NUM_PDV_BNDR = this->navigate( m_targetFieldPath + ".NUM_PDV_BNDR" );
		
		m_termloc  = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_cod_bndr = this->navigate( m_sourceFieldPath + ".segments.common.cod_bndr" );
        m_iss_name = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
		
		return true;
	}
	void TBSW0161Loader::finish( )
	{
	}
	int TBSW0161Loader::execute( bool& a_stop )
	{
		try
		{
			std::string l_num_pdv;
            std::string l_cod_bndr;
            std::string l_iss_name;
            
            fieldSet::fsextr( l_num_pdv, m_termloc );
            fieldSet::fsextr( l_iss_name, m_iss_name );
            if( "AMEX_FULL" == l_iss_name )
                l_cod_bndr = std::string ( "13" );
            else
                fieldSet::fsextr( l_cod_bndr, m_cod_bndr );
			
			std::ostringstream l_whereClause;
			l_whereClause << "NUM_PDV = " << l_num_pdv << " AND COD_BNDR_CORP = " << l_cod_bndr;
						
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0161 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
            dbaccess_common::TBSW0161 l_table0161( l_whereClause.str( ) );

			l_table0161.prepare( );
			l_table0161.execute( );
			
			if ( !l_table0161.fetch( ) )
			{
				fieldSet::fscopy( m_RESULT, std::string( "NO ROWS" ) );
			}
			else
			{
				fieldSet::fscopy( m_RESULT, std::string( "OK" ) );
				fieldSet::fscopy( m_NUM_PDV_BNDR, l_table0161.get_NUM_PDV_BNDR( ) );
			}
		}
		catch( base::GenException e )
		{
			fieldSet::fscopy( m_RESULT, std::string( "ERROR" ) );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0161 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			fieldSet::fscopy( m_RESULT, std::string( "ERROR" ) );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0161[" + l_what + "]";
			this->enableError( true );
			this->setErrorMessage( l_msg );			
		}
		
		a_stop = false;
		return 0;
	}
	TBSW0161Loader& TBSW0161Loader::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	TBSW0161Loader& TBSW0161Loader::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	dataManip::Command* TBSW0161Loader::clone( ) const
	{
		return new TBSW0161Loader( *this );
	}
}//namespace plugins_pdv

