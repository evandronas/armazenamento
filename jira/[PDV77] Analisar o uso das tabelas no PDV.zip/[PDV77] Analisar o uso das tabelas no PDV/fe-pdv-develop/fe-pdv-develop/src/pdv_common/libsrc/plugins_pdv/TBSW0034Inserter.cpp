#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "acq_common/TBSW0034.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0034Inserter.hpp"
#include "msgConv/TextConv.hpp"
#include "dbaccess_pdv/TBSW0034RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0034Inserter()
    {
        TBSW0034Inserter* l_new = new TBSW0034Inserter;
        return l_new;
    }

    TBSW0034Inserter::TBSW0034Inserter()
    {
    }

    TBSW0034Inserter::~TBSW0034Inserter()
    {
    }

    bool TBSW0034Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );    
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
                this->setLocalFieldPath( l_source );
            else
                this->setSourceFieldPath( l_source );
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );
            
        return true;  
    }

    bool TBSW0034Inserter::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_txt_rlcd_chip = this->navigate( m_sourceFieldPath + ".segments.chip.chip_full_data" );
        m_chip_full_data_len = this->navigate( m_sourceFieldPath + ".segments.chip.chip_full_data_len" );
        m_txt_info_cmpm_chip = this->navigate( m_sourceFieldPath + ".segments.chip.second_gen_ac" );
        m_txt_rstd_atlz_chip = this->navigate( m_sourceFieldPath + ".segments.chip.isr" );
        /*m_ind_nvl_sgra_kmrc = this->navigate( m_sourceFieldPath + "?" ); */
        m_ecr_cvm = this->navigate( m_sourceFieldPath + ".segments.common.cvm_code" ); 
        m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
		m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_pos_entry_code = this->navigate( m_sourceFieldPath + ".segments.common.pos_entry_code" );
        m_transcode = this->navigate( m_sourceFieldPath + ".segments.common.transcode" );
        m_acq_msgtype = this->navigate( m_sourceFieldPath + ".segments.common.acq_msgtype" );
        m_pin = this->navigate( m_sourceFieldPath + ".shc_msg.pin" );
//t689066@FIS_BEGIN - Data: 22/10/2013 - Trocado card_seqno para segmento de common, pois o short do shc_msg nao tem como saber se eh nulo        
        m_card_seqno = this->navigate( m_sourceFieldPath + ".segments.common.card_seqno" );
//t689066@FIS_END - Data: 22/10/2013 - Trocado card_seqno para segmento de common, pois o short do shc_msg nao tem como saber se eh nulo        
        m_cd_ems = this->navigate( m_sourceFieldPath + ".segments.common.cd_ems" );
        m_cardholder_name_extended = this->navigate( m_sourceFieldPath + ".segments.common.cardholder_name_extended" );

        m_pcode = this->navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        
        m_iss_name = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );

        return true;
    }

    void TBSW0034Inserter::finish()
    {
    }

    int TBSW0034Inserter::execute( bool& a_stop )
    {
        try
        {       
            dbaccess_pdv::TBSW0034RegrasFormatacao regrasFormatacao;
            dbaccess_common::TBSW0034 tbsw0034;
            acq_common::tbsw0034_params tbsw0034_params = { 0 };
                                    
            fieldSet::fsextr( tbsw0034_params.local_date,               m_local_date );
            fieldSet::fsextr( tbsw0034_params.local_time,               m_local_time ); 
            fieldSet::fsextr( tbsw0034_params.refnum,                   m_refnum ); 
            fieldSet::fsextr( tbsw0034_params.second_gen_ac,            m_txt_info_cmpm_chip );
			fieldSet::fsextr( tbsw0034_params.chip_full_data,           m_txt_rlcd_chip );            
            fieldSet::fsextr( tbsw0034_params.chip_full_data_len,       m_chip_full_data_len );
            fieldSet::fsextr( tbsw0034_params.isr,                      m_txt_rstd_atlz_chip ); 
            fieldSet::fsextr( tbsw0034_params.cvm_code,                 m_ecr_cvm );            
            fieldSet::fsextr( tbsw0034_params.pin,                      m_pin );            
            fieldSet::fsextr( tbsw0034_params.transcode,                m_transcode );
            fieldSet::fsextr( tbsw0034_params.cd_ems,                   m_cd_ems );
            fieldSet::fsextr( tbsw0034_params.card_seqno,               m_card_seqno );
            fieldSet::fsextr( tbsw0034_params.cardholder_name_extended, m_cardholder_name_extended );
            
            fieldSet::fsextr( tbsw0034_params.iss_name,                 m_iss_name );  
            
            //DAT_MOV_TRAN           
            regrasFormatacao.DAT_MOV_TRAN( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
            
            //DAT_VD_CHIP
            regrasFormatacao.DAT_VD_CHIP( tbsw0034, tbsw0034_params, acq_common::INSERT ); 

            //IND_NVL_SGRA_KMRC, de acordo com a planilha BD_Captura_POS_PDV_v1_11.xls, 
            //esse campo n�o esta sendo sendo inserido no banco de dados.
            //regrasFormatacao.IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0034 *tbsw0034, const std::string& ind_nvl_sgra_kmrc );
            
            //NUM_SEQ_UNC
            regrasFormatacao.NUM_SEQ_UNC( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
            
            //TXT_INFO_CMPM_CHIP
            regrasFormatacao.TXT_INFO_CMPM_CHIP( tbsw0034, tbsw0034_params, acq_common::INSERT );       
            
            //TXT_RLCD_CHIP
			//t694449@FIS@BT57923@11.03.2014@bgn         
            regrasFormatacao.TXT_RLCD_CHIP( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
            //t694449@FIS@BT57923@11.03.2014@end
            
            //TXT_RSTD_ATLZ_CHIP
            regrasFormatacao.TXT_RSTD_ATLZ_CHIP( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
            
            //COD_PGM_AUT
            regrasFormatacao.COD_PGM_AUT( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
                        
            //IND_MTDO_VRFC_PORT  - DE47.TAG04 - valor em 2 digitos (ex: 01). 
            regrasFormatacao.IND_MTDO_VRFC_PORT( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
            
            //IND_PRSC_SNHA
            regrasFormatacao.IND_PRSC_SNHA( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
            
            //NUM_SEQ_CAR_VLDC_CHIP            
            regrasFormatacao.NUM_SEQ_CAR_VLDC_CHIP( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
            
            //NOM_PORT_CAR
            regrasFormatacao.NOM_PORT_CAR( tbsw0034, tbsw0034_params, acq_common::INSERT ); 
            
            tbsw0034.show(0);			
            tbsw0034.insert( );
            tbsw0034.commit( );
            fieldSet::fscopy( m_result, "OK", 2 );

        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Gen Exception when inserting into table TBSW0034 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception when inserting into table TBSW0034 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    TBSW0034Inserter& TBSW0034Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
  
    TBSW0034Inserter& TBSW0034Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
  
    TBSW0034Inserter& TBSW0034Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0034Inserter::clone() const
    {
        return new TBSW0034Inserter(*this);
    }
  
}//namespace plugins_pdv

