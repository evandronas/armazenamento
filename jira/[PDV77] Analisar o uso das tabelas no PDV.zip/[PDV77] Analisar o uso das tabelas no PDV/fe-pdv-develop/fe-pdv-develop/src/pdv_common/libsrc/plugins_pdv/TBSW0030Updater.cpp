#pragma once

#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>

#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "defines.hpp"
//TODOSW75 #include "dualHandler.hpp"
#include "TBSW0030.hpp"
#include "plugins_pdv/TBSW0030Updater.hpp"
#include "dbaccess_pdv/TBSW0030RegrasFormatacao.hpp"

// Release Bandeiras PDV - Abril 2019
using namespace std;

namespace plugins_pdv
{
    base::Identificable* createTBSW0030Updater( )
    {
        TBSW0030Updater* l_new = new TBSW0030Updater;
        return( l_new );
    }

    TBSW0030Updater::TBSW0030Updater( )
    {
    }

    TBSW0030Updater::~TBSW0030Updater( )
    {
    }

    bool TBSW0030Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return( true );
    }

    bool TBSW0030Updater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_authnum = this->navigate( m_sourceFieldPath + ".shc_msg.authnum" );
        m_ext_network_code = this->navigate( m_sourceFieldPath + ".segments.common.ext_network_code" );
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_status = this->navigate( m_sourceFieldPath + ".segments.common.status" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_origauthnum = this->navigate( m_sourceFieldPath + ".segments.common.orig_authnum" );
        m_cod_istt_acqr =  this->navigate( m_sourceFieldPath + ".segments.credit.cod_istt_acqr");
        m_cod_istt_frwd =  this->navigate( m_sourceFieldPath + ".segments.credit.cod_istt_frwd");
        m_cod_rsps_dtlh_emsr =  this->navigate( m_sourceFieldPath + ".segments.cod_rsps_dtlh_emsr");
        m_ext_refnum = this->navigate( m_sourceFieldPath + ".segments.common.ext_refnum");
        m_de_adc_ete = this->navigate( m_sourceFieldPath + ".segments.common.de_adc_ete");
        m_mc_info_country = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_country" );
        m_mc_info_ica = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_ica" );
        m_settlement_date = this->navigate( m_sourceFieldPath + ".shc_msg.settlement_date" );
        m_addresponse = this->navigate( m_sourceFieldPath + ".shc_msg.addresponse" );
        m_respcode = this->navigate( m_sourceFieldPath + ".shc_msg.respcode" );
        m_ind_tran_refd = this->navigate( m_localFieldPath + ".IND_TRAN_REFD" );
        m_extrac_out_de60 = this->navigate( m_sourceFieldPath + ".segments.debt.extrac_out_de60" );
        m_issuer = this->navigate( m_sourceFieldPath + ".shc_msg.issuer" );
        m_iss_name = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_msg_category = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        m_acq_name = this->navigate( m_sourceFieldPath + ".segments.common.acq_name" );
        m_msg_name = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        m_hor_tran_emsr = this->navigate( m_sourceFieldPath + ".segments.credit.hor_tran_emsr" );
        m_dat_mov_tran_emsr = this->navigate( m_sourceFieldPath + ".segments.credit.dat_mov_tran_emsr" );
        m_receive_inst_id = this->navigate( m_sourceFieldPath + ".shc_msg.receive_inst_id" );
        m_pb_reason_code = this->navigate( m_sourceFieldPath + ".segments.common.pb_reason_code" );
        m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_has_pin = this->navigate( m_sourceFieldPath + ".segments.common.has_pin" );
        m_az_reason_code = this->navigate( m_sourceFieldPath + ".segments.common.az_reason_code" );
        m_nom_site_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_site_issr" );
        m_nom_fe_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_fe_issr" );
        m_nom_host_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_host_issr" );
        m_ind_modl_cptr = this->navigate( m_localFieldPath + ".ind_modl_cptr" );
        m_quem_negou = this->navigate( m_sourceFieldPath + ".segments.common.quem_negou" );
        m_txt_adic_pos = this->navigate( m_sourceFieldPath + ".segments.credit.txt_adic_pos");
        m_segments_credit_fee = this->navigate( m_sourceFieldPath + ".segments.credit.fee" );
        // t689049@FIS - 16/01/2017 - IND_IMPR_CPOM
        m_trn_tem_cupom = this->navigate( m_sourceFieldPath + ".segments.common.trn_tem_cupom" );
        m_cod_mtv_sw = this->navigate( m_sourceFieldPath + ".segments.common.cod_mtv_sw" );
        m_is_desfaz_estorno = this->navigate( m_sourceFieldPath + ".segments.common.is_desfaz_estorno" );
        m_sender_mbname = this->navigate( m_localFieldPath + ".mailboxName" );
        m_de38IssOff = this->navigate( m_sourceFieldPath + ".segments.common.de38IssOff" );
        tokenIdentifier = this->navigate( m_sourceFieldPath + ".segments.common.tokenIdentifier" );
        temOriginal = this->navigate( m_localFieldPath + ".trn_tem_original" );
        codigoOrigemRespostaAutorizacao = this->navigate( m_sourceFieldPath + ".segments.common.codigoOrigemRespostaAutorizacao" );
	alphaResponseCode = this->navigate( m_sourceFieldPath + ".shc_msg.alpha_response_code" );
        m_origtranscode= this->navigate( m_sourceFieldPath + ".segments.common.orig_transcode" );
        
        // Release Bandeiras PDV - Abril 2019 - INICIO
        indicadorPresencaPortador = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorPresencaPortador") );
        indicadorTecnologiaTerminal = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorTecnologiaTerminal") );
        // Release Bandeiras PDV - Abril 2019 - FIM
        
        // J01_2020 - Novo Debito da Mastercard - INICIO
        codigoSubtranscode = this->navigate( string(m_sourceFieldPath).append(".segments.common.subtranscode") );
        // J01_2020 - Novo Debito da Mastercard - FIM
        termloc = this->navigate( string(m_sourceFieldPath).append(".shc_msg.termloc") );
        
        return( true );
    }

    void TBSW0030Updater::finish( )
    {
    }

    int TBSW0030Updater::execute( bool& a_stop )
    {
        try
        {
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Updating in TBSW0030 =========" );
            std::ostringstream l_whereClause;
            unsigned long l_msgtype;
            unsigned long l_local_date;
            unsigned long l_refnum;
            unsigned long localTermloc;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );
            fieldSet::fsextr( l_msgtype, m_msgtype );
            fieldSet::fsextr( localTermloc, termloc );
          
            {
                switch ( l_msgtype )
                {
                    case 110 :
                    case 210 :
                    case 230 :
                    case 400 :
                    case 410 :
                    case 420 :
                    case 430 :
                    case 500 :
                    case 510 :
                    case 800 :
                    case 810 :
                    case 1624 :
                    case 1634 :
                    case 9090 :
                    case 9170 :
                    // t689049@FIS - 25/01/2017 - Update para as ADM
                    case 9070 : // RES_VEND ..
                    case 9610 : // BAIXA_OS ..
                    case 9310 : //Revers�o de Transa��o Aprovada por Saldo Dispon�vel . Voucher
                        l_whereClause << " DAT_MOV_TRAN = " << l_local_date
                                      << " AND NUM_SEQ_UNC = " << l_refnum;
                        break;
                    case 610 :
                        l_whereClause << " DAT_MOV_TRAN = " << l_local_date
                                      << " AND NUM_SEQ_UNC = " << l_refnum
                                      << " AND IND_STTU_TRAN IN ('0', '9')"
                                      << " AND NOM_FE_ACQR_ORGL = 'FEPDV'"
                                      << " AND NUM_ESTB = " << localTermloc;
                        break;
                    default:
                        char l_szAux[50];
                        sprintf( l_szAux, " MSGTYPE : [%ld] - INVALIDO ", l_msgtype );
                        logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_szAux );
                        fieldSet::fscopy( m_result, "ERROR", 5 );
                        a_stop = false;
                        return 0;
                        break;
                }

            }

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0030 - UPDATE ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );
            
            dbaccess_common::TBSW0030 tbsw0030( l_whereClause.str( ) );
            dbaccess_pdv::TBSW0030RegrasFormatacao regrasFmt;
            acq_common::tbsw0030_params st_tbsw0030 = { 0 };

            tbsw0030.prepare_for_update( );
            tbsw0030.execute( );

            //TODOSW75 
            /***
            dbaccess_common::DualHandler l_dualHand( &tbsw0030 );
            if ( l_msgtype == 610 )
            {
                logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " l_dualHand.setIsStatusInq( ) " );
                l_dualHand.setIsStatusInq( );
            }
            if ( l_dualHand.fetch( dbaccess::table::UPDATE ) )
            ***/
            if ( tbsw0030.fetch( ) )
            {
                tbsw0030.let_as_is( );
                
                fieldSet::fsextr( st_tbsw0030.settlement_date, m_settlement_date );
                fieldSet::fsextr( st_tbsw0030.mc_info_ica, m_mc_info_ica );
                fieldSet::fsextr( st_tbsw0030.mc_info_country, m_mc_info_country );
                fieldSet::fsextr( st_tbsw0030.status, m_status );
                fieldSet::fsextr( st_tbsw0030.orig_authnum, m_origauthnum );
                fieldSet::fsextr( st_tbsw0030.authnum, m_authnum );
                fieldSet::fsextr( st_tbsw0030.local_ind_tran_refd, m_ind_tran_refd );
                fieldSet::fsextr( st_tbsw0030.de_adc_ete, m_de_adc_ete );
                fieldSet::fsextr( st_tbsw0030.hor_tran_emsr, m_hor_tran_emsr );
                fieldSet::fsextr( st_tbsw0030.dat_mov_tran_emsr, m_dat_mov_tran_emsr );
                fieldSet::fsextr( st_tbsw0030.cod_istt_acqr, m_cod_istt_acqr );
                fieldSet::fsextr( st_tbsw0030.cod_rsps_dtlh_emsr, m_cod_rsps_dtlh_emsr );
                fieldSet::fsextr( st_tbsw0030.addresponse, m_addresponse );
                fieldSet::fsextr( st_tbsw0030.ext_refnum, m_ext_refnum );
                fieldSet::fsextr( st_tbsw0030.receive_inst_id, m_receive_inst_id );
                fieldSet::fsextr( st_tbsw0030.issuer, m_issuer );
                fieldSet::fsextr( st_tbsw0030.extrac_out_de60, m_extrac_out_de60 );
                fieldSet::fsextr( st_tbsw0030.respcode, m_respcode );
                fieldSet::fsextr( st_tbsw0030.ext_network_code, m_ext_network_code );
                fieldSet::fsextr( st_tbsw0030.cod_istt_frwd, m_cod_istt_frwd );
                fieldSet::fsextr( st_tbsw0030.iss_name, m_iss_name );
                fieldSet::fsextr( st_tbsw0030.msg_category, m_msg_category );
                fieldSet::fsextr( st_tbsw0030.acq_name, m_acq_name );
                fieldSet::fsextr( st_tbsw0030.msg_name, m_msg_name );
                fieldSet::fsextr( st_tbsw0030.pb_reason_code, m_pb_reason_code );
                fieldSet::fsextr( st_tbsw0030.local_date, m_local_date );
                fieldSet::fsextr( st_tbsw0030.local_time, m_local_time );
                fieldSet::fsextr( st_tbsw0030.has_pin, m_has_pin );
                fieldSet::fsextr( st_tbsw0030.az_reason_code, m_az_reason_code );
                fieldSet::fsextr( st_tbsw0030.nom_site_issr, m_nom_site_issr );
                fieldSet::fsextr( st_tbsw0030.nom_fe_issr, m_nom_fe_issr );
                fieldSet::fsextr( st_tbsw0030.nom_host_issr, m_nom_host_issr );
                fieldSet::fsextr( st_tbsw0030.quem_negou, m_quem_negou );
                fieldSet::fsextr( st_tbsw0030.ind_modl_cptr, m_ind_modl_cptr );
                fieldSet::fsextr( st_tbsw0030.txt_adic_pos, m_txt_adic_pos );
                fieldSet::fsextr( st_tbsw0030.segments_credit_fee, m_segments_credit_fee );
                // t689049@FIS - 16/01/2017 - IND_IMPR_CPOM
                fieldSet::fsextr( st_tbsw0030.trn_tem_cupom, m_trn_tem_cupom );
                fieldSet::fsextr( st_tbsw0030.cod_mtv_sw, m_cod_mtv_sw );
                fieldSet::fsextr( st_tbsw0030.is_desfaz_estorno, m_is_desfaz_estorno );
                fieldSet::fsextr( st_tbsw0030.sender_mbname, m_sender_mbname );
                fieldSet::fsextr( st_tbsw0030.de38IssOff, m_de38IssOff );
                fieldSet::fsextr( st_tbsw0030.tokenIdentifier, tokenIdentifier );
                fieldSet::fsextr( st_tbsw0030.trn_tem_original, temOriginal );
                fieldSet::fsextr( st_tbsw0030.codigoOrigemRespostaAutorizacao, codigoOrigemRespostaAutorizacao );
		fieldSet::fsextr( st_tbsw0030.alphaResponseCode, alphaResponseCode );
                fieldSet::fsextr( st_tbsw0030.orig_transcode, m_origtranscode );
                // Release Bandeiras PDV - Abril 2019 - INICIO
                fieldSet::fsextr( st_tbsw0030.indicadorPresencaPortador, indicadorPresencaPortador );
                fieldSet::fsextr( st_tbsw0030.indicadorTecnologiaTerminal, indicadorTecnologiaTerminal );
                // Release Bandeiras PDV - Abril 2019 - FIM
                // J01_2020 - Novo Debito da Mastercard - INICIO
                fieldSet::fsextr( st_tbsw0030.subtranscode, codigoSubtranscode );
                // J01_2020 - Novo Debito da Mastercard - FIM
                
                regrasFmt.DAT_CTB_TRAN( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NUM_ID_CAR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_PAIS_CAR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_SERV_SNHA( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NUM_AUT( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NUM_MOT_RSPS( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_MOT_RSPS_EXT( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.IND_STTU_TRAN( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.DTH_STTU_TRAN( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.IND_IMPR_CPOM( tbsw0030, st_tbsw0030, acq_common::UPDATE ); 
                regrasFmt.IND_TRAN_REFD( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.NOM_SITE_ISSR( tbsw0030, st_tbsw0030, acq_common::UPDATE ); 
                regrasFmt.NOM_HOST_ISSR( tbsw0030, st_tbsw0030, acq_common::UPDATE ); 
                regrasFmt.NOM_FE_ISSR( tbsw0030, st_tbsw0030, acq_common::UPDATE ); 
                regrasFmt.TXT_DA_ADIC_EMSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.DTH_TRAN_EMSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.DAT_LQDC_EMSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_ISTT_ACQR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_ISTT_FRWD( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_RSPS_DTLH_EMSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_RSTD_NUM_CVC_2( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_VLDC_EMSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.IND_AUT( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_AUT_EMSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_CNDC_CPTR_EMSR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.TIP_MODL_CPTR( tbsw0030, st_tbsw0030, acq_common::UPDATE );
				regrasFmt.IND_CPTRDO( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_MOT_SW( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.IND_TRAN_TKN( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.COD_ORG_APRV( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                // Release Bandeiras PDV - Abril 2019 - INICIO
                regrasFmt.IndicadorPresencaPortador( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                regrasFmt.IndicadorTecnologiaTerminal( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                // Release Bandeiras PDV - Abril 2019 - FIM
                // J01_2020 - Novo Debito da Mastercard - INICIO
                regrasFmt.COD_CMPM_TRAN( tbsw0030, st_tbsw0030, acq_common::UPDATE );
                // J01_2020 - Novo Debito da Mastercard - FIM
                regrasFmt.COD_OPER_CNFR( tbsw0030, st_tbsw0030, acq_common::UPDATE );

                tbsw0030.update( );
                tbsw0030.commit( );
                fieldSet::fscopy( m_result, "OK", 2 );
            }
            else
            {
                fieldSet::fscopy( m_result, "ORIGINAL TRANSACTION NOT FOUND", 30 );
            }
        }
        catch( base::GenException e )
        {
            std::string l_what( e.what( ) );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0030 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            std::string l_what( e.what( ) );
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0030 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }

    TBSW0030Updater& TBSW0030Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0030Updater& TBSW0030Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    TBSW0030Updater& TBSW0030Updater::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0030Updater::clone( ) const
    {
        return( new TBSW0030Updater( *this ) );
    }
}//namespace standardAcqPlugins

