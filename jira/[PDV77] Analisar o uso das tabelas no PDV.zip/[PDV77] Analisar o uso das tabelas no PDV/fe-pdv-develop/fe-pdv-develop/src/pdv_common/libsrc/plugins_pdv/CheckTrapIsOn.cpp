/* Copyright 2018 Rede S.A.
Autor : Danilo Jose de Oliveia
Empresa : FIS
*/
#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <cstring>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/CheckTrapIsOn.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    /// CreateCheckTrapIsOn
    /// Inicia instancia da classe
    /// EF/ET: 0000
    /// Historico: 03/05/2018 Criacao inicial.
    base::Identificable* CreateCheckTrapIsOn( )
    {
        CheckTrapIsOn* l_new = new CheckTrapIsOn;
        return( l_new );
    }
    
    CheckTrapIsOn::CheckTrapIsOn( )
    {
    }
    
    CheckTrapIsOn::~CheckTrapIsOn( )
    {
    }
    /// startConfiguration
    /// Inicia configuracoes
    /// EF/ET: 0000
    /// Historico: 03/05/2018 Criacao inicial.
    bool CheckTrapIsOn::startConfiguration( const configBase::Tag* tagParametro )
    {
        configBase::TagList tagListLocal;
        
        tagParametro->findTag( "sourceFieldPath", tagListLocal );
        this->SetSourceFieldPath( tagListLocal.front( ).findProperty( "value" ).value( ) );
        
        tagParametro->findTag( "targetFieldPath", tagListLocal );
        this->SetTargetFieldPath( tagListLocal.front( ).findProperty( "value" ).value( ) );
        
        return( true );
    }
    
    bool CheckTrapIsOn::init( )
    {
        result = this->navigate( targetFieldPath + ".RESULT" );
        trapNumber = this->navigate( sourceFieldPath + ".trap_number" );
        trapsOnFile = this->navigate( sourceFieldPath + ".traps_on_file" );

        return( true );
    }
    
     void CheckTrapIsOn::finish( )
    {
    }
    /// execute
    /// Execucao principal
    /// EF/ET: 0000
    /// Historico: 03/05/2018 Criacao inicial.
    int CheckTrapIsOn::execute( bool& stopParametro )
    {
        try
        {
            FILE * fileLocal;
            char aux[32];
            std::string trapNumberLocal;
            std::string trapsOnFileLocal;
            bool find = false;

            fieldSet::fsextr( trapNumberLocal, trapNumber );
            fieldSet::fsextr( trapsOnFileLocal, trapsOnFile );

            if( ( fileLocal = fopen( trapsOnFileLocal.c_str(), "r" ) ) != NULL )
            {
                while( fgets( aux, sizeof(aux), fileLocal) != NULL )
                {
                    if( strncmp( aux, trapNumberLocal.c_str(), trapNumberLocal.size() ) == 0 )
                    {
                        // a trava estah desligada se o trapNumber esta presente no arquivo
                        find = true;
                        break;
                    }
                }
            }
            else
            {
                logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "ERRO AO LER ARQUIVO DE CONFIGURACAO DE TRAVAS ON/OFF" );
            }

            if ( find )
            {
                fieldSet::fscopy( result, "ON", 2 );
            }
            else
            {
                fieldSet::fscopy( result, "OFF", 3 );
            }
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string whatLocal( e.what( ) );
            std::string msgLocal = "Exception in TRAP_IS_ON <" + whatLocal + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        catch ( std::exception  e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string whatLocal( e.what( ) );
            std::string msgLocal = "std::exception in TRAP_IS_ON <" + whatLocal + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        
        stopParametro = false;
        return( 0 );
    }
    /// SetSourceFieldPath
    /// Grava caminho original das configuracoes originais
    /// EF/ET: 0000
    /// Historico: 03/05/2018 Criacao inicial.
    CheckTrapIsOn& CheckTrapIsOn::SetSourceFieldPath( const std::string& pathParametro )
    {
        sourceFieldPath = pathParametro;
        return( *this );
    }
    /// SetTargetFieldPath
    /// Grava caminho original das configuracoes para copia
    /// EF/ET: 0000
    /// Historico: 03/05/2018 Criacao inicial.
    CheckTrapIsOn& CheckTrapIsOn::SetTargetFieldPath( const std::string& pathParametro )
    {
        targetFieldPath = pathParametro;
        return( *this );
    }
    
    dataManip::Command* CheckTrapIsOn::clone( ) const
    {
        return( new CheckTrapIsOn( *this ) );
    }
} //namespace plugins_pdv
