/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0157Inserter>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0157Inserter>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor:
/ Data de Cria��o:
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ <20.05.2013, FEPOS, 694449, Correcao de tratamento para Resumo de Vendas>
/ <20.05.2013, FEPOS, 694449, Inclusao de tratamento para Serasa>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <iostream>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0157.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0157Inserter.hpp"
#include "dbaccess_pdv/TBSW0157RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0157Inserter()
    {
        TBSW0157Inserter* l_new = new TBSW0157Inserter;
        return l_new;
    }

    TBSW0157Inserter::TBSW0157Inserter()
    {
    }

    TBSW0157Inserter::~TBSW0157Inserter()
    {
    }

    bool TBSW0157Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
                this->setLocalFieldPath( l_source );
            else
                this->setSourceFieldPath( l_source );
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

        return true;
    }

    bool TBSW0157Inserter::init()
    {

        // DAT_MOV_TRAN
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        // NUM_SEQ_UNC
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        // COD_SERV_TRAN
        m_cod_service = this->navigate( m_sourceFieldPath + ".segments.service.cod_service" );
        // NUM_PDV_ORG_TRAN
        m_pv_fisico = this->navigate( m_sourceFieldPath + ".segments.service.pv_fisico" );
        // COD_TERM_ORG_TRAN
        m_term_fisico = this->navigate( m_sourceFieldPath + ".segments.service.term_fisico" );
        // NUM_DDD_RCRG
        m_ddd_celular = this->navigate( m_sourceFieldPath + ".segments.service.ddd_celular" );
        // NUM_TEL_RCRG
        m_num_celular = this->navigate( m_sourceFieldPath + ".segments.service.num_celular" );
        // NUM_SEQ_UNC_OPER
        m_nsu_operadora = this->navigate( m_sourceFieldPath + ".segments.service.num_aut_operadora" );

        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        return( true );
    }

    void TBSW0157Inserter::finish()
    {
	
    }

    int TBSW0157Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0157 l_table0157;
            dbaccess_pdv::TBSW0157RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0157_params params = { 0 };
			oasis_dec_t l_dect;
			std::string l_string;
			
            fieldSet::fsextr( params.local_date, 	m_local_date );
			fieldSet::fsextr( l_string, 	m_refnum );			
			dbm_chartodec(&l_dect,l_string.c_str(),0);
			params.refnum=l_dect;			
			
			fieldSet::fsextr( params.cod_service, 	m_cod_service );
            fieldSet::fsextr( params.pv_fisico,     m_pv_fisico);
            fieldSet::fsextr( params.term_fisico,     m_term_fisico );


            fieldSet::fsextr( params.ddd_celular, 	m_ddd_celular );
			fieldSet::fsextr( params.nsu_operadora, m_nsu_operadora );
			
			fieldSet::fsextr( l_string, 	m_num_celular );			
			dbm_chartodec(&l_dect,l_string.c_str(),0);
			params.num_celular=l_dect;
			
			regrasFmt.DAT_MOV_TRAN 		( l_table0157, params, acq_common::INSERT );
			regrasFmt.NUM_SEQ_UNC 		( l_table0157, params, acq_common::INSERT );
			regrasFmt.COD_SERV_TRAN 	( l_table0157, params, acq_common::INSERT );
			regrasFmt.NUM_PDV_ORG_TRAN 	( l_table0157, params, acq_common::INSERT );
			regrasFmt.COD_TERM_ORG_TRAN ( l_table0157, params, acq_common::INSERT );
			regrasFmt.NUM_DDD_RCRG 		( l_table0157, params, acq_common::INSERT );
			regrasFmt.NUM_TEL_RCRG 		( l_table0157, params, acq_common::INSERT );
			regrasFmt.NUM_SEQ_UNC_OPER 	( l_table0157, params, acq_common::INSERT );
			
            l_table0157.insert( );
            l_table0157.commit( );

            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0157 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0157 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }

    TBSW0157Inserter& TBSW0157Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    TBSW0157Inserter& TBSW0157Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    TBSW0157Inserter& TBSW0157Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0157Inserter::clone() const
    {
        return( new TBSW0157Inserter( *this ) );
    }

} //namespace standardAcqPlugins

