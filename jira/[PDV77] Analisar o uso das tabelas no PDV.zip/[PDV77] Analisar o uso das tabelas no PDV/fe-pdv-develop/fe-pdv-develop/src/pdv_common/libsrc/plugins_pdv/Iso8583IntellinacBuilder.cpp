/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/* Copyright 2018 Rede S.A.
Autor : FIDELITY
Empresa : REDE

*********************** MODIFICACOES ************************
Autor    : Arthur Henrique 
Data     : 18/07/2018 
Empresa  : Rede 
Descrição: Correções de problemas de inspeção de código fonte 'Switch sem default'.
ID       : 227.478
************************************************************* 
*/

#pragma once
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/DOMTreatment.hpp"
#include "configBase/TagList.hpp"
#include "configLoader/Iso8583Config.hpp"
#include "msgConv/DataElementProperties.hpp"
#include "plugins_pdv/Iso8583IntellinacBuilder.hpp"
#include "msgConv/TextConv.hpp"
#include <sstream>
#include <iostream>

namespace msgConv
{
    msgConv::FieldSetExtractor* createIso8583IntellinacBuilder()
	{
		Iso8583IntellinacBuilder* l_new = new Iso8583IntellinacBuilder;			
		return l_new;
	}
    bool Iso8583IntellinacBuilder::loadXml( const std::string& a_xmlPath, const std::string& l_xmlName, configBase::Tag& a_tag )
	{
		configBase::DOMTreatment l_domTreat;
		bool l_xmlret = l_domTreat.load( a_xmlPath, l_xmlName, a_tag );
		if ( !l_xmlret )
		{
			const configBase::XMLParseErrorHandler::ERRMSGS& l_errors = l_domTreat.errors( );
            unsigned int l_count = l_errors.size( );
            std::stringstream l_logmsg;
            for ( unsigned int i = 0; i < l_count; ++i )
            {                
                l_logmsg << __FUNCTION__ << "[" << l_errors[i].systemFile( ) << "][" << l_errors[i].lineNumber( ) << "][" << l_errors[i].columnNumber( ) << "][" << l_errors[i].message( ) << "]" << std::endl;
            }
            this->setHasError( true );
			this->setErrorMessage( l_logmsg.str() );
		}
		return l_xmlret;
	}    
    bool Iso8583IntellinacBuilder::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_iso8583PropertiesXmltagList;
        configBase::Tag l_full;        
        if ( a_tag->findTagNotRequired( "iso8583PropertiesXml", l_iso8583PropertiesXmltagList ) )
        {
            configBase::TagList l_list;
            configLoader::Iso8583Config l_iso8583Config;
            msgConv::Iso8583Properties l_isoProperties;
            
            if(!loadXml( l_iso8583PropertiesXmltagList.front().findProperty( "filePath" ).value( ), 
                         l_iso8583PropertiesXmltagList.front().findProperty( "fileName" ).value( ), 
                         l_full ) )
            {
                return false;
            }            
            l_full.findTag( "Iso8583Properties", "label", "Iso8583Msg", l_list );            
            if (!l_iso8583Config.load( l_isoProperties, l_list.front( ) ) )
            {
                return false;
            }
            this->setIso8583Properties( l_isoProperties );           
        }    
         return true;
    }
	Iso8583IntellinacBuilder::Iso8583IntellinacBuilder( )
	{
		const unsigned int l_buffLength = 65536;
		m_auxBuffer			= new unsigned char[l_buffLength];
		m_auxBufferLength	= l_buffLength;
	}
	Iso8583IntellinacBuilder::~Iso8583IntellinacBuilder( )
	{
		delete[]
		m_auxBuffer;
	}
	bool Iso8583IntellinacBuilder::open( )
	{
		return initialiseIndexers( );
	}
	void Iso8583IntellinacBuilder::close( )
	{
	}
	
	void Iso8583IntellinacBuilder::printHEX( std::string a_varname, const char* a_buf, unsigned int size )
	{
		char buffer[1024];
		sprintf( buffer, "%s: <", a_varname.c_str() );
		//logger::DebugWriter::getInstance()->write( logger::LEVEL_ALWAYS, buffer);
		printf("%s:", a_varname.c_str() );
		for( unsigned int i = 0 ; i < size ; i++ )
		{
			sprintf( buffer, " %02x ", (const unsigned char*)a_buf[i] );
			//logger::DebugWriter::getInstance()->write( logger::LEVEL_ALWAYS, buffer);			
			printf( " %02x ", (const unsigned char*)a_buf[i] );
		}
		//logger::DebugWriter::getInstance()->write( logger::LEVEL_ALWAYS, ">\n");
		printf("%\n");
	}		
	
	bool Iso8583IntellinacBuilder::turnBitOn( unsigned char* a_bitmaps, unsigned int a_bitmapSize, unsigned int a_bitNum )
	{
		unsigned char l_base = 0x80;
		unsigned int l_mov =( a_bitNum-1 )
		% 8;
		l_base >>= l_mov;
		if ( l_mov >= a_bitmapSize )
		{
			return false;
		}
		a_bitmaps[( a_bitNum-1 )>>3]
		|= l_base;
		return true;
	}
	unsigned int Iso8583IntellinacBuilder::build( unsigned char* a_target, unsigned int a_targetBufferLen )
	{
		const unsigned int l_firstBitmapSize	= 8;
		const unsigned int l_secondBitmapSize	= 8;
		const unsigned int l_bitmapTotalSize	= l_firstBitmapSize + l_secondBitmapSize;
		unsigned char l_bitmaps[l_bitmapTotalSize];
		memset( l_bitmaps, 0, l_bitmapTotalSize );
		std::string l_dataElements;
		for ( unsigned int l_deNumber = 1; l_deNumber <= m_deCount; ++l_deNumber )
		{
			const fieldSet::Field& l_field = getDataElement( l_deNumber );
			if ( l_field.isDummy( ) || !l_field.isOn( ) )
			{
				continue;
			}
			if ( !this->turnBitOn( l_bitmaps, l_bitmapTotalSize, l_deNumber ) )
			{
				this->setHasError( true );
				this->setErrorMessage( "Internal error turning bit on" );
				return 0;
			}
			if ( l_deNumber == 1 )
			continue;
			const DataElementProperties& l_deProp = m_iso8583Properties.dataElementsProperties( l_deNumber );
			if ( l_deProp.isLVar( ) )
			{
				std::string l_value;
				this->convertFromAscii( l_value, l_field.value( ), l_deProp.dataCoding( ) );
				unsigned int l_lvarSize = this->calculateSize( l_deProp.dataElementSize( ), l_deProp.lvarDataCoding( ) );
				char l_lvar[32];
				snprintf( l_lvar, sizeof l_lvar, "%0*u", l_lvarSize, l_value.length( ) );
				std::string l_convLVar;
				this->convertFromAscii( l_convLVar, l_lvar, l_deProp.lvarDataCoding( ) );
				l_dataElements += l_convLVar;
				l_dataElements += l_value;
			}
			else
			{
				std::string l_value;
				this->convertFromAscii( l_value, l_field.value( ), l_deProp.dataCoding( ) );
				l_dataElements += l_value;
			}
		}
		const fieldSet::Field& l_header = m_headerAccess.field( );
		unsigned int l_current = 0;
		if ( l_header.isOn( ) )
		{
			if ( l_current + l_header.length( )> a_targetBufferLen )
			{
				this->setHasError( true );
				this->setErrorMessage( "Target buffer not enough while putting the header" );
				return 0;
			}
			std::string l_convHeader;
			this->convertFromAscii( l_convHeader, l_header.value( ), m_iso8583Properties.headerDataType( ) );
			
			memcpy( &a_target[l_current], l_convHeader.data( ), l_convHeader.length( ) );
			l_current += l_convHeader.length( );
		}
		
		//std::cout << "TERMINOU HEADER" << std::endl;
		
		const fieldSet::Field& l_tpdu = m_tpduAccess.field( );
		if ( l_tpdu.isOn( ) )
		{
			//std::cout << "ENTROU TPDU" << std::endl;
			if ( l_current + l_tpdu.length( )> a_targetBufferLen )
			{
				this->setHasError( true );
				this->setErrorMessage( "Target buffer not enough while putting the tpdu" );
				return 0;
			}
			std::string temp_tpdu = l_tpdu.value( );
			
			if( temp_tpdu.length( ) > 0 )
			{
				std::string destino, origem, fix;
				
				//printHEX( "TPDU INICIAL", temp_tpdu.c_str( ), temp_tpdu.length( ) );
				
				//std::cout << "CP TPDU" << std::endl;
					
				fix.assign( temp_tpdu, 0, 1 );
				//printHEX( "fix", fix.c_str( ), fix.length( ) );

				destino.assign( temp_tpdu, 3, 2 );
				//printHEX( "destino", destino.c_str( ), destino.length( ) );

				origem.assign( temp_tpdu, 1, 2 );
				//printHEX( "origem", origem.c_str( ), origem.length( ) );
				
				temp_tpdu.clear( );		
				temp_tpdu.append( fix );
				temp_tpdu.append( destino );
				temp_tpdu.append( origem );
				
				//std::cout << "APPEND TPDU" << std::endl;
				
				memcpy( &a_target[l_current], temp_tpdu.data( ), temp_tpdu.length( ) );
				
				//std::cout << "MEMCPY TPDU" << std::endl;
				
				l_current += temp_tpdu.length( );
			}
			
			//printHEX( "TPDU", temp_tpdu.c_str( ), temp_tpdu.length( ) );
		}
		
		//std::cout << "TERMINOU TPDU" << std::endl;
		
		const fieldSet::Field& l_mct = m_mctAccess.field( );
		if ( l_mct.isOn( ) )
		{
			if ( l_current + l_mct.length( )> a_targetBufferLen )
			{
				this->setHasError( true );
				this->setErrorMessage( "Target buffer not enough while putting the merchant type" );
				return 0;
			}
			std::string l_convMct;

			this->convertFromAscii( l_convMct, l_mct.value( ), msgConv::EBCDIC );
			memcpy( &a_target[l_current], l_convMct.data( ), l_convMct.length( ) );
			l_current += l_convMct.length( );
			
			//printHEX( "MCT", l_convMct.c_str( ), l_convMct.length( ) );
		}				
		
		//std::cout << "TERMINOU MCT" << std::endl;
		
        const fieldSet::Field& l_niip = m_niipAccess.field( );		
		if ( l_niip.isOn( ) )
		{
			if ( l_current + l_niip.length( )> a_targetBufferLen )
			{
				this->setHasError( true );
				this->setErrorMessage( "Target buffer not enough while putting the niip" );
				return 0;
			}
			std::string l_convNiip;

			this->convertFromAscii( l_convNiip, l_niip.value( ), m_iso8583Properties.headerDataType( ) );
			memcpy( &a_target[ l_current ], l_convNiip.data( ), l_convNiip.length( ) );
			l_current += l_convNiip.length( );
			
			//printHEX( "NIIP", l_convNiip.c_str( ), l_convNiip.length( ) );
		}        
		
		//std::cout << "TERMINOU NIIP" << std::endl;
		
		const fieldSet::Field& l_msgType = m_msgTypeAccess.field( );
		if ( l_current + l_msgType.length( )> a_targetBufferLen )
		{
			this->setHasError( true );
			this->setErrorMessage( "Target buffer not enough while putting the message type" );
			return 0;
		}
		std::string l_convMsgType;
		this->convertFromAscii( l_convMsgType, l_msgType.value( ), m_iso8583Properties.messageTypeDataType( ) );
		memcpy( &a_target[l_current], l_convMsgType.data( ), l_convMsgType.length( ) );
		l_current += l_convMsgType.length( );
		if ( getDataElement( 1 ).isOn( ) )
		{
			if ( l_current + l_bitmapTotalSize > a_targetBufferLen )
			{
				this->setHasError( true );
				this->setErrorMessage( "Target buffer not enough while putting the 8 bytes bitmap" );
				return 0;
			}
			std::string l_convBitmap;
			this->convertFromHEX( l_convBitmap, std::string( reinterpret_cast<const char*>( l_bitmaps ), l_bitmapTotalSize ), m_iso8583Properties.bitmapsDataType( ) );			
			memcpy( &a_target[l_current], l_convBitmap.data( ), l_convBitmap.length( ) );
			l_current += l_convBitmap.length( );
		}
		else
		{
			if ( l_current + l_firstBitmapSize > a_targetBufferLen )
			{
				this->setHasError( true );
				this->setErrorMessage( "Target buffer not enough while putting the 16 bytes bitmap" );
				return 0;
			}
			
			std::string l_convBitmap;
			this->convertFromHEX( l_convBitmap, std::string( reinterpret_cast<const char*>( l_bitmaps ), l_firstBitmapSize ), m_iso8583Properties.bitmapsDataType( ) );
			memcpy( &a_target[l_current], l_convBitmap.data(), l_convBitmap.length( ) );
			l_current += l_convBitmap.length( );
		}
		if ( l_current + l_dataElements.length( )> a_targetBufferLen )
		{
			this->setHasError( true );
			this->setErrorMessage( "Target buffer not enough while putting the data elements" );
			return 0;
		}
		memcpy( &a_target[l_current], l_dataElements.data( ), l_dataElements.length( ) );
		unsigned int l_totalLength = l_current + l_dataElements.length( );
		this->setHasError( false );
		this->setErrorMessage( "No error" );
		return l_totalLength;
	}
	unsigned int Iso8583IntellinacBuilder::calculateSize( unsigned int a_numDigits, DataCoding a_dataCoding )
	{
		unsigned int l_calc = 0;
		if ( a_dataCoding == HEX || a_dataCoding == BCD)
		{
			l_calc = 2 * ( a_numDigits / 2  + a_numDigits % 2);
                   
			//l_calc = a_numDigits >>= 1;
			//l_calc += a_numDigits & 0x01 ? 1 : 0;
			//Se for impar vai sobrar 1/2
		}
		else
		{
			l_calc = a_numDigits;
		}
		return l_calc;
	}
	bool Iso8583IntellinacBuilder::convertFromAscii( std::string& a_output, const std::string& a_input, DataCoding a_dataCoding )
	{
		switch ( a_dataCoding )
		{
			case EBCDIC:
			{
				unsigned int l_toEbcdicLength =
				TextConv::asciiToEbcdic( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_output.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_toEbcdicLength );
			}
			break;
	
			case BCD:
			{
				unsigned int l_toBcdLength =
				TextConv::asciiToBcd( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_output.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_toBcdLength );
			}
			break;
			
			case ASCII:
			{
				a_output = a_input;
			}
			break;
			
			case RAW:
			{
				a_output = a_input;
			}
			break;
			
			case HEX:
			{
				unsigned int l_hexLength =
				TextConv::asciiToHex( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_output.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_hexLength );
			}
			break;
            default:
            	//default
            	break;
		}
		return true;
	}
	bool Iso8583IntellinacBuilder::convertFromHEX( std::string& a_output, const std::string& a_input, DataCoding a_dataCoding )
	{
		switch ( a_dataCoding )
		{
			case EBCDIC:
			{
				unsigned int l_toEbcdicLength =
				TextConv::hexToEbcdic( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_output.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_toEbcdicLength );
			}
			break;
            case BCD:
			{
				unsigned int l_toBcdLength =
				TextConv::hexToBcd( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_output.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_toBcdLength );
			}
			break;
			case ASCII:
			{
				unsigned int l_toAsciiLength =
				TextConv::hexToAscii( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_output.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_toAsciiLength );
			}
			break;
			case HEX:
			{
				a_output = a_input;
			}
			break;
			
			case RAW:
			{
				a_output = a_input;
			}
			break;
			default:
				//default
			    break;
		}
		return true;
	}
	Iso8583IntellinacBuilder& Iso8583IntellinacBuilder::setIso8583Properties( const Iso8583Properties& a_iso8583Properties )
	{
		m_iso8583Properties = a_iso8583Properties;
		return *this;
	}
	bool Iso8583IntellinacBuilder::initialiseIndexers( )
	{
		const unsigned int l_maxLabelSize = 128;
		char l_label[l_maxLabelSize];
		for ( unsigned int l_deNumber = 0; l_deNumber < m_deCount; ++l_deNumber )
		{
			snprintf( l_label, l_maxLabelSize, "DE%03u", l_deNumber + 1 );
			m_dataElements[l_deNumber]
			= fieldSet::ConstFieldAccess( source( ), l_label );
		}
		m_headerAccess	= fieldSet::ConstFieldAccess( source( ), "HEADER" );
		m_niipAccess	= fieldSet::ConstFieldAccess( source( ), "NIIP" );
        m_msgTypeAccess	= fieldSet::ConstFieldAccess( source( ), "MSG_TYPE" );
        m_tpduAccess	= fieldSet::ConstFieldAccess( source( ), "TPDU" );
		m_mctAccess	    = fieldSet::ConstFieldAccess( source( ), "MERCHANT_TYPE" );		
		
		return true;
	}
	const fieldSet::Field& Iso8583IntellinacBuilder::getDataElement( unsigned int a_deNumber ) const
	{
		base::genAssert( a_deNumber > 0 && a_deNumber <= m_deCount, __FUNCTION__, "Invalid Data Element Number" );
		return m_dataElements[a_deNumber-1].field( );
	}
}//namespace msgConv

