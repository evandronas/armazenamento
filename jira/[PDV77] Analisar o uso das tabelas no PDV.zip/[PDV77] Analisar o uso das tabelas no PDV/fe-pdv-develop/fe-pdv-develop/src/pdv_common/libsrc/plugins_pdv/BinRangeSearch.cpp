/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689064, Raphael Teller
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t689064, Raphael Teller, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <algorithm>
#include <deque>
#include "base/GenException.hpp"
#include "plugins_pdv/BinRangeSearch.hpp"
#include "plugins_pdv/Range.hpp"
#include <sstream>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
	BinRangeSearch::BinRangeSearch()
	{
	}

	BinRangeSearch::~BinRangeSearch()
	{
	}

	bool BinRangeSearch::init()
	{
		std::sort( m_rangeDeque.begin(), m_rangeDeque.end(), m_rangeComparator );
		return true;
	}

	bool BinRangeSearch::pickQualifiedRanges( unsigned long a_bin )
	{
//		int l_first = 0;
//		int l_last = m_rangeDeque.size();
//		int l_mid = 0;
		
		/*logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "**** rangeDeque antes da busca binaria ****" );		
		for( int i = l_first; i < l_last; i++ )
		{
			char buffer[1024];
			memset(buffer, 0, sizeof(buffer));
			sprintf(buffer, "        binIni[%s] binFin[%s] prio[%d] netid[%s]",
				m_rangeDeque[i].getNUM_BIN_CAR_INI().c_str(),
				m_rangeDeque[i].getNUM_BIN_CAR_FIM().c_str(),
				m_rangeDeque[i].getIND_PRRD(),
				m_rangeDeque[i].getNETWORK_ID().c_str()
			);
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, buffer );
		}*/

//		while ( l_first <= l_last )
//		{
//			l_mid = ( l_first + l_last ) / 2;
//
//			if ( a_bin < atoi( m_rangeDeque[l_mid].getNUM_BIN_CAR_INI().c_str() ) )
//			{
//				l_last =  l_mid - 1;
//			}
//			else if ( a_bin > atoi( m_rangeDeque[l_mid].getNUM_BIN_CAR_INI().c_str() ) )
//			{
//				l_first = l_mid + 1;
//			}
//			else
//			{
//				break;
//			}
//		}
//
//		int l_up;
//		int l_down;
//
//		l_up = l_mid;
//		l_down = l_mid + 1;
		
		/*logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "**** rangeDeque depois da busca binaria ****" );		
		for( int i = l_up; i < l_down; i++ )
		{
			char buffer[1024];
			memset(buffer, 0, sizeof(buffer));
			sprintf(buffer, "        binIni[%s] binFin[%s] prio[%d] netid[%s]",
				m_rangeDeque[i].getNUM_BIN_CAR_INI().c_str(),
				m_rangeDeque[i].getNUM_BIN_CAR_FIM().c_str(),
				m_rangeDeque[i].getIND_PRRD(),
				m_rangeDeque[i].getNETWORK_ID().c_str()
			);
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, buffer );
		}*/

//		while ( l_up >= 0 )
//		{
//			if ( a_bin <= atoi( m_rangeDeque[l_up].getNUM_BIN_CAR_FIM().c_str() ) && a_bin >= atoi( m_rangeDeque[l_up].getNUM_BIN_CAR_INI().c_str() ) )
//			{
//				m_qualifiedRanges.push_front( m_rangeDeque[l_up] );
//			}
//			l_up--;
//		}
//		while ( a_bin <= atoi( m_rangeDeque[l_down].getNUM_BIN_CAR_FIM().c_str() ) &&
//		a_bin >= atoi( m_rangeDeque[l_down].getNUM_BIN_CAR_INI().c_str() ) )
//		{
//			m_qualifiedRanges.push_back( m_rangeDeque[l_down] );
//			l_down++;
//		}

		int l_size;
		int l_numBinCarIni;
		int l_numBinCarFim;

		l_size = m_rangeDeque.size( );

		for( int l_pos=0; l_pos < l_size; l_pos++ )
		{
			l_numBinCarIni = atoi( m_rangeDeque[ l_pos ].getNUM_BIN_CAR_INI().c_str() );
			l_numBinCarFim = atoi( m_rangeDeque[ l_pos ].getNUM_BIN_CAR_FIM().c_str() );

			// Se o bin inicial for maior que bin desejado, encerra a busca
			if ( a_bin < l_numBinCarIni)
				break;

			if ( a_bin >= l_numBinCarIni && a_bin <= l_numBinCarFim )
			{
				m_qualifiedRanges.push_back( m_rangeDeque[ l_pos ] );
			}
		}

		//char txtBinNumber[20];
		//sprintf( txtBinNumber, "a_bin => %d", a_bin );
		//logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, txtBinNumber );

		//logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "**** rangeDeque depois do filtro ****" );
		//for( int i = 0; i < m_qualifiedRanges.size( ); i++ )
		//{
		//	char buffer[1024];
		//	memset(buffer, 0, sizeof(buffer));
		//	sprintf(buffer, "        binIni[%s] binFin[%s] prio[%d] netid[%s]",
		//		m_qualifiedRanges[i].getNUM_BIN_CAR_INI().c_str(),
		//		m_qualifiedRanges[i].getNUM_BIN_CAR_FIM().c_str(),
		//		m_qualifiedRanges[i].getIND_PRRD(),
		//		m_qualifiedRanges[i].getNETWORK_ID().c_str()
		//	);
		//	logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, buffer );
		//}

		bool l_ret = m_qualifiedRanges.size( ) > 0;
		return l_ret;
	}

	void BinRangeSearch::sortQualifiedRanges()
	{
		std::sort( m_qualifiedRanges.begin(), m_qualifiedRanges.end(), m_priorityComparator );
	}

	Range BinRangeSearch::findRange( unsigned long a_bin )
	{
		if ( pickQualifiedRanges( a_bin ) == false )
		{
			Range notValid;
			notValid.setIS_VALID( false );
			return notValid;
		}
		
		sortQualifiedRanges();
		
		Range l_range = m_qualifiedRanges[0];
		m_qualifiedRanges.clear();
		return l_range;
	}
}

