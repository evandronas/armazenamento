/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0042Loader>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::TBSW0042Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689049, CKen>
/ Data de Cria��o: <Thu Oct 25 13:26:42 2012
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0042.hpp"
#include "plugins_pdv/TBSW0042Loader.hpp"

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0042Loader()
    {
        TBSW0042Loader* l_new = new TBSW0042Loader;
        return l_new;
    }

    bool TBSW0042Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0042Loader::TBSW0042Loader()
    {
    }

    TBSW0042Loader::~TBSW0042Loader()
    {
    }

    bool TBSW0042Loader::init()
    {
    m_RESULT = this->navigate( m_targetFieldPath + ".RESULT" );
    m_NUM_PDV = this->navigate( m_targetFieldPath + ".NUM_PDV" );
    m_COD_TERM = this->navigate( m_targetFieldPath + ".COD_TERM" );
    m_COD_STTU_REG = this->navigate( m_targetFieldPath + ".COD_STTU_REG" );
    m_DAT_ATLZ_REG = this->navigate( m_targetFieldPath + ".DAT_ATLZ_REG" );
    m_COD_PSSE_TERM = this->navigate( m_targetFieldPath + ".COD_PSSE_TERM" );
    m_COD_SIT_TERM = this->navigate( m_targetFieldPath + ".COD_SIT_TERM" );
    m_COD_PRDC_TERM = this->navigate( m_targetFieldPath + ".COD_PRDC_TERM" );
    m_IND_ATIN = this->navigate( m_targetFieldPath + ".IND_ATIN" );
    m_IND_ATCG = this->navigate( m_targetFieldPath + ".IND_ATCG" );
    m_IND_UTLZ_PNPD = this->navigate( m_targetFieldPath + ".IND_UTLZ_PNPD" );
    m_IND_TRAN_DGTD = this->navigate( m_targetFieldPath + ".IND_TRAN_DGTD" );
    m_COD_VERS_SFTW = this->navigate( m_targetFieldPath + ".COD_VERS_SFTW" );
    m_COD_VERS_DLL = this->navigate( m_targetFieldPath + ".COD_VERS_DLL" );
    m_COD_TCNL = this->navigate( m_targetFieldPath + ".COD_TCNL" );
    m_SGL_TCNL = this->navigate( m_targetFieldPath + ".SGL_TCNL" );
    m_TIP_LGCO = this->navigate( m_targetFieldPath + ".TIP_LGCO" );
    m_IND_TERM_BLQD = this->navigate( m_targetFieldPath + ".IND_TERM_BLQD" );
    m_TIP_TERM = this->navigate( m_targetFieldPath + ".TIP_TERM" );
    m_TIP_EQPM = this->navigate( m_targetFieldPath + ".TIP_EQPM" );
    m_IND_TRAN_CHIP = this->navigate( m_targetFieldPath + ".IND_TRAN_CHIP" );
    m_IND_TERM_LTRO_CHIP = this->navigate( m_targetFieldPath + ".IND_TERM_LTRO_CHIP" );
    m_DAT_ATCG = this->navigate( m_targetFieldPath + ".DAT_ATCG" );
    m_IND_TERM_FATR_EXPS = this->navigate( m_targetFieldPath + ".IND_TERM_FATR_EXPS" );

    m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
    m_termid = this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
    m_in_tpo_tcn = this->navigate( m_sourceFieldPath + ".segments.merchant.in_tpo_tcn" );

        return true;
    }

    void TBSW0042Loader::finish()
    {
    }

    int TBSW0042Loader::execute( bool& a_stop )
    {
        try
        {

      std::string l_termid;
      fieldSet::fsextr( l_termid, m_termid );
      
      std::ostringstream l_whereClause;
     
      l_whereClause << "COD_TERM = '" << l_termid << "'"; 
      
      logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0042 ==========" );
      logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
      
      dbaccess_common::TBSW0042 l_TBSW0042( l_whereClause.str() );
      l_TBSW0042.prepare();
      l_TBSW0042.execute();

      if( !l_TBSW0042.fetch() )
      {
          fieldSet::fscopy( m_RESULT, "NO ROWS" ); 
          std::string l_msg = "WhereClause <<" + l_whereClause.str() + ">>";
          this->enableError( true );
          this->setErrorMessage( l_msg );
      }
      else
      {
          fieldSet::fscopy( m_RESULT, "OK" );
      
          fieldSet::fscopy( m_NUM_PDV, l_TBSW0042.get_NUM_PDV() );
          fieldSet::fscopy( m_COD_TERM, l_TBSW0042.get_COD_TERM() );
          fieldSet::fscopy( m_COD_STTU_REG, l_TBSW0042.get_COD_STTU_REG() );
          fieldSet::fscopy( m_DAT_ATLZ_REG, l_TBSW0042.get_DAT_ATLZ_REG() );
          fieldSet::fscopy( m_COD_PSSE_TERM, l_TBSW0042.get_COD_PSSE_TERM() );
          fieldSet::fscopy( m_COD_SIT_TERM, l_TBSW0042.get_COD_SIT_TERM() );
          fieldSet::fscopy( m_COD_PRDC_TERM, l_TBSW0042.get_COD_PRDC_TERM() );
          fieldSet::fscopy( m_IND_ATIN, l_TBSW0042.get_IND_ATIN() );
          fieldSet::fscopy( m_IND_ATCG, l_TBSW0042.get_IND_ATCG() );
          fieldSet::fscopy( m_IND_UTLZ_PNPD, l_TBSW0042.get_IND_UTLZ_PNPD() );
          fieldSet::fscopy( m_IND_TRAN_DGTD, l_TBSW0042.get_IND_TRAN_DGTD() );
          fieldSet::fscopy( m_COD_VERS_SFTW, l_TBSW0042.get_COD_VERS_SFTW() );
          fieldSet::fscopy( m_COD_VERS_DLL, l_TBSW0042.get_COD_VERS_DLL() );
          fieldSet::fscopy( m_COD_TCNL, l_TBSW0042.get_COD_TCNL() );
          fieldSet::fscopy( m_SGL_TCNL, l_TBSW0042.get_SGL_TCNL() );
          fieldSet::fscopy( m_TIP_LGCO, l_TBSW0042.get_TIP_LGCO() );
          fieldSet::fscopy( m_IND_TERM_BLQD, l_TBSW0042.get_IND_TERM_BLQD() );
          fieldSet::fscopy( m_TIP_TERM, l_TBSW0042.get_TIP_TERM() );
          fieldSet::fscopy( m_TIP_EQPM, l_TBSW0042.get_TIP_EQPM() );
          fieldSet::fscopy( m_IND_TRAN_CHIP, l_TBSW0042.get_IND_TRAN_CHIP() );
          fieldSet::fscopy( m_IND_TERM_LTRO_CHIP, l_TBSW0042.get_IND_TERM_LTRO_CHIP() );
          fieldSet::fscopy( m_DAT_ATCG, l_TBSW0042.get_DAT_ATCG() );
          fieldSet::fscopy( m_IND_TERM_FATR_EXPS, l_TBSW0042.get_IND_TERM_FATR_EXPS() );
      }
    }
    catch( base::GenException e )
    {
      fieldSet::fscopy( m_RESULT, "ERROR" );
      std::string l_what( e.what( ) );
      std::string l_msg = "Exception in TBSW0042Loader <" + l_what + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }
    catch( std::exception  e )
    {
      fieldSet::fscopy( m_RESULT, "ERROR" );
      std::string l_what( e.what( ) );
      std::string l_msg = "std::exception in TBSW0042Loader <" + l_what + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }

    a_stop = false;
    return 0;
    }

    TBSW0042Loader& TBSW0042Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0042Loader& TBSW0042Loader::setSourceFieldPath( const std::string& a_path )
    {
          m_sourceFieldPath = a_path;
          return *this;
    }

    dataManip::Command* TBSW0042Loader::clone() const
    {
        return new TBSW0042Loader(*this);
    }
}//namespace plugins_pdv

