#include <fieldSet/ConstFieldAccess.hpp>
#include <fieldSet/FieldSet.hpp>
#include <fieldSet/fscopy.hpp>
#include <fieldSet/fsextr.hpp>
#include <configBase/TagList.hpp>
#include <base/GenException.hpp>
#include <sstream>
#include <ctime>
#include <cstdio>
#include <iostream>

#include "plugins_pdv/TBSW0058Updater.hpp"
#include "TBSW0058.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
//TODOSW75 #include "dualHandler.hpp"

#include "dbaccess_pdv/TBSW0058RegrasFormatacao.hpp"

// Release Bandeiras PDV - Abril 2019
using namespace std;

namespace plugins_pdv
{
    base::Identificable* createTBSW0058Updater()
    {
        TBSW0058Updater* l_new = new TBSW0058Updater;
        return l_new;
    }

    bool TBSW0058Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        // t694446@FIS_BEGIN - Data: 21/11/2013 - GAP3: 1.1.4.11 - Tratamento do C�digo de Autoriza��o nos Front-Ends 
        //a_tag->findTag( "sourceFieldPath", l_tagList );
        //std::string l_source = l_tagList.front().findProperty( "value" ).value();
        //this->setSourceFieldPath( l_source );

        std::string l_source;
        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }
        // t694446@FIS_BEGIN - Data: 21/11/2013 - GAP3: 1.1.4.11 - Tratamento do C�digo de Autoriza��o nos Front-Ends 
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_target = l_tagList.front().findProperty( "value" ).value();
        this->setTargetFieldPath( l_target );

        return true;
    }

    TBSW0058Updater::TBSW0058Updater()
    {
    }

    TBSW0058Updater::~TBSW0058Updater()
    {
    }
    
    bool TBSW0058Updater::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_iss_name         = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_msg_category     = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        m_msg_name         = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        m_has_pin          = this->navigate( m_sourceFieldPath + ".segments.common.has_pin" );
        m_addresponse      = this->navigate( m_sourceFieldPath + ".shc_msg.addresponse" );
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_origtrace = this->navigate( m_sourceFieldPath + ".shc_msg.origtrace" );
        m_origpan = this->navigate( m_sourceFieldPath + ".segments.common.orig_pan" );
        m_amount = this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_origtime = this->navigate( m_sourceFieldPath + ".shc_msg.origtime" );
        m_authnum = this->navigate( m_sourceFieldPath + ".shc_msg.authnum" );
        m_origauthnum = this->navigate( m_sourceFieldPath + ".segments.common.orig_authnum" );
        dataLocalOriginal  = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_date" );
        m_is_3a_perna = this->navigate( m_sourceFieldPath + ".segments.common.is_3a_perna" );
        m_transcode = this->navigate( m_sourceFieldPath + ".segments.common.transcode" );
        m_isVan = this->navigate( m_sourceFieldPath + ".segments.common.is_van" );
        m_az_reason_code = this->navigate( m_localFieldPath + ".az_reason_code_orig" );
        m_cd_ems = this->navigate( m_sourceFieldPath + ".segments.common.cd_ems" );
        m_mc_info_country = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_country" ); 
        m_nom_site_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_site_issr" );
        m_nom_host_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_host_issr" );
        m_nom_fe_issr = this->navigate( m_sourceFieldPath + ".segments.common.nom_fe_issr" );
        m_status = this->navigate( m_sourceFieldPath + ".segments.common.status" );
        m_transcode = this->navigate( m_sourceFieldPath + ".segments.common.transcode" );
        m_trace = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
        m_termid = this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
        m_install_num = this->navigate( m_sourceFieldPath + ".segments.common.install_num" );
        m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_mc_info_ica = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_ica" );
        m_pb_reason_code = this->navigate( m_sourceFieldPath + ".segments.common.pb_reason_code" );
        m_ext_network_code = this->navigate( m_sourceFieldPath + ".segments.common.ext_network_code" );
        m_pin = this->navigate( m_sourceFieldPath + ".shc_msg.pin" );
        m_acq_conv_rate = this->navigate( m_sourceFieldPath + ".shc_msg.acq_conv_rate" );
        m_issuer = this->navigate( m_sourceFieldPath + ".shc_msg.issuer" );
        m_de_adc_ete = this->navigate( m_sourceFieldPath + ".segments.common.de_adc_ete" );
        m_txt_adic_pos     = this->navigate( m_sourceFieldPath + ".segments.credit.txt_adic_pos");
        m_mc_info_prod_code = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_prod_code" );
        numeroReferenciaTransacao = this->navigate( m_sourceFieldPath + ".segments.credit.numeroTransacaoEmissor" );
        codigoCapacidadeTerminal = this->navigate( m_sourceFieldPath + ".segments.credit.codigoCapacidadeTerminalEmissor" );
        senderMailboxName    = this->navigate( m_localFieldPath + ".mailboxName" );
        tokenIdentifier  = this->navigate( m_sourceFieldPath + ".segments.common.tokenIdentifier" );
        codigoOrigemRespostaAutorizacao = this->navigate( m_sourceFieldPath + ".segments.common.codigoOrigemRespostaAutorizacao" );
        /// COD_PROD_MTC
        /// m_mc_info_prod_code
        /// COD_RGAO_MTC
        infoRegiaoMastercard = this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_region" );
        
        // Release Bandeiras PDV - Abril 2019 - INICIO
        indicadorPresencaPortador = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorPresencaPortador") );
        indicadorTecnologiaTerminal = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorTecnologiaTerminal") );
        // Release Bandeiras PDV - Abril 2019 - FIM
        
        return true;
    }

    void TBSW0058Updater::finish()
    {
    }

    int TBSW0058Updater::execute( bool& a_stop )
    {
        std::ostringstream l_whereClause;

        try
        {
            std::string     l_string;
            oasis_dec_t     l_dect;
            
            //local_date
            unsigned long     l_local_date;
            unsigned long     l_local_time;
            unsigned long     l_origdate;
            unsigned long     l_origtime;
            unsigned long     l_msgtype;
            char             l_szDtHrAux[128];
            unsigned long     l_refnum;
            unsigned long     l_origrefnum;
            unsigned long     l_origtrace;
            std::string     l_origpan;
            std::string     l_amount;
            std::string     l_authnum;
            std::string     l_origauthnum;
            unsigned long l_orig_local_date;
            std::string     l_is_3a_perna;
            // unsigned long     l_transcode;    
            std::string     l_msg_name;

            fieldSet::fsextr( l_local_date,     m_local_date );
            fieldSet::fsextr( l_local_time,     m_local_time );
            fieldSet::fsextr( l_refnum,         m_refnum );
            fieldSet::fsextr( l_origrefnum,     m_origrefnum );
            fieldSet::fsextr( l_msgtype,         m_msgtype );
            fieldSet::fsextr( l_origtrace,         m_origtrace );
            fieldSet::fsextr( l_origpan,         m_origpan );
            fieldSet::fsextr( l_amount,         m_amount );
            fieldSet::fsextr( l_origdate,         m_origdate );
            fieldSet::fsextr( l_origtime,         m_origtime );
            fieldSet::fsextr( l_authnum,         m_authnum );
            fieldSet::fsextr( l_origauthnum,     m_origauthnum );
            fieldSet::fsextr( l_orig_local_date, dataLocalOriginal );
            fieldSet::fsextr( l_is_3a_perna,     m_is_3a_perna );
            // fieldSet::fsextr( l_transcode,         m_transcode );
            fieldSet::fsextr( l_msg_name,         m_msg_name );

            // cr689721@FIS - Data: 23/10/2014 - Ref. Coletar dados para estorno ou
            // desfazimento de confirma��o de pr�-autoriza��o.
            // if( l_transcode == 77 || l_transcode == 78 )
            if ( l_msg_name.compare( "EST_CONF_PREAUT" ) == 0            ||
                 l_msg_name.compare( "EST_CONF_PREAUT_PARC_SJURO" ) == 0 ||
                 l_msg_name.compare( "DESF_CONF_PREAUT" ) == 0           ||
                 l_msg_name.compare( "DESF_CONF_PREAUT_SJURO" ) == 0
               )
            {
                m_dat_mov_tran_pauz = this->navigate( m_localFieldPath + ".dat_mov_tran_pauz" );
                m_num_seq_unc_pauz  = this->navigate( m_localFieldPath + ".num_seq_unc_pauz" );
            
                fieldSet::fsextr( l_orig_local_date, m_dat_mov_tran_pauz );
                fieldSet::fsextr( l_origrefnum, m_num_seq_unc_pauz );
                
            }
            
            //NUM_AUT            shc_msg.authnum
            //cr689721@FIS - Data: 27/10/2014 - Ref. Copiada a convers�o pra c� devido a
            // utiliza��o do origauthnum na query dos estornos e desfazimentos.
            if((l_origauthnum.size() > 0) && (l_msgtype == 130 || l_msgtype == 410 || l_msgtype == 430))
            {
                std::string l_num = l_origauthnum.c_str();
                //Verificar se o numero de autoriza��o recebido � tudo branco
                while (l_num.size() > 0 && l_num.at(0) == ' ')
                {
                    l_num.erase(0);
                }
                //Se for tudo branco, grava como veio
                if(l_num.size() > 0)
                {
                    if( (l_origauthnum = converteAuthnum( l_origauthnum ).c_str() ).size() > 0 )
                    {
                        //Salva o numero de autoriza��o original convertido
                        std::string l_original_convertido = l_origauthnum.c_str();

                        //Completa com zeros a esquerda at� o tamanho de 6.
                        while( l_origauthnum.size() < 6 )
                        {
                            l_origauthnum.insert(0,"0"); 
                        }
                        //Salva sem o primeiro de seis digitos.
                        l_origauthnum = l_origauthnum.substr(1).c_str();
                    }
                }
            }

            std::string l_isVan;
            fieldSet::fsextr( l_isVan, m_isVan );
            
            if ( !l_is_3a_perna.compare("Y") )
            {
                l_whereClause << "DAT_MOV_TRAN = " << l_orig_local_date << " AND NUM_SEQ_UNC = " << l_origrefnum;
            }
            else
            {    
                // t689066@FIS_BEGIN - Data: 30/12/2013 - BT53125: cartoes menores que 16 estavam gravando NUM_CAR com separador.
                size_t l_pos = l_origpan.find_first_of("=DF^");                
                if( l_pos != std::string::npos )
                {
                    l_origpan.erase( l_pos, std::string::npos );
                }
                // t689066@FIS_END - Data: 30/12/2013 - BT53125: cartoes menores que 16 estavam gravando NUM_CAR com separador.   
            
                switch ( l_msgtype )
                {
                case 230 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_orig_local_date << " AND NUM_SEQ_UNC = " << l_origrefnum;
                    break;
                
                case 110 :
                    sprintf(l_szDtHrAux, "%08ld%06ld", l_local_date, l_local_time);
                    
                    l_whereClause << "DAT_MOV_TRAN = " << l_local_date << 
                        " AND NUM_SEQ_UNC=" << l_refnum << 
                        //" AND DTH_INI_TRAN = to_date('" << l_szDtHrAux << "', 'YYYYMMDDHH24MISS')";
                        " AND DTH_INI_TRAN = to_timestamp('" << l_szDtHrAux << "', 'YYYYMMDDhh24miss')";
                    break;
                    
                case 130 :
                    l_whereClause << "NUM_CAR = '" << l_origpan << "'" <<
                        " AND NUM_AUT = '" << l_origauthnum << "'" <<
                        " AND VAL_TRAN <= " << l_amount <<
                        " AND TO_CHAR(DAT_PAUZ,'YYYYMMDD') = '" << l_origdate << "'";
                    break;

                case 410 :
                
                    // if ( l_transcode == 77 ) //estorno de confirmacao de pre
                    if ( l_msg_name.compare( "EST_CONF_PREAUT" ) == 0     ||
                         l_msg_name.compare( "EST_CONF_PREAUT_PARC_SJURO" ) == 0
                       )
                    {
                        // cr689721@FIS - Data: 23/10/2014 - Ref. Acerto para estorno de confirma��o de pr�-autoriza��o.
                        // l_whereClause << "DAT_MOV_TRAN_CNFR = " << l_origdate << " AND NUM_SEQ_UNC_CNFR = " << l_origrefnum
                        // << " AND NUM_AUT='" << l_origauthnum << "' AND NUM_CAR='" << l_origpan << "'";
                        l_whereClause << "DAT_MOV_TRAN = " << l_orig_local_date << " AND NUM_SEQ_UNC = " << l_origrefnum
                        << " AND NUM_AUT='" << l_origauthnum << "' AND NUM_CAR='" << l_origpan << "'";
                    }
                    else
                    {
                        sprintf(l_szDtHrAux, "%08ld%06ld", l_origdate, l_origtime);
                        
                        l_whereClause << " DAT_MOV_TRAN=" << l_orig_local_date
                        << " AND (" << "(NUM_AUT='" << l_origauthnum << "' AND NUM_CAR='" << l_origpan << "' AND NUM_STAN = "
                        //<< l_origtrace << " AND DTH_GMT = to_date('" << l_szDtHrAux << "', 'YYYYMMDDHH24MISS'))"
                        << l_origtrace << " AND DTH_GMT = to_timestamp('" << l_szDtHrAux <<  "', 'YYYYMMDDhh24miss'))"
                        << " OR NUM_SEQ_UNC=" << l_origrefnum << ")";
                    }
                    break;
                
                case 430 :
                    // if ( l_transcode == 78 ) //desfazimento de confirmacao de pre
                    if ( l_msg_name.compare( "DESF_CONF_PREAUT" ) == 0     ||
                         l_msg_name.compare( "DESF_CONF_PREAUT_SJURO" ) == 0
                       )
                    {
                        // cr689721@FIS - Data: 23/10/2014 - Ref. Acerto para desfazimento de confirma��o de pr�-autoriza��o.
                        // l_whereClause << "DAT_MOV_TRAN_CNFR = " << l_origdate << " AND NUM_SEQ_UNC_CNFR = " << l_origrefnum
                        // << " AND NUM_AUT='" << l_origauthnum << "' AND NUM_CAR='" << l_origpan << "'";
                        l_whereClause << "DAT_MOV_TRAN = " << l_orig_local_date << " AND NUM_SEQ_UNC = " << l_origrefnum
                        << " AND NUM_AUT='" << l_origauthnum << "' AND NUM_CAR='" << l_origpan << "'";
                    }    
                    else
                    {
                        sprintf(l_szDtHrAux, "%08ld%06ld", l_origdate, l_origtime);
                        
                        l_whereClause << " DAT_MOV_TRAN=" << l_orig_local_date
                        << " AND (" << "(NUM_CAR='" << l_origpan << "' AND NUM_STAN = " << l_origtrace
                        //<< " AND DTH_GMT = to_date('" << l_szDtHrAux << "', 'YYYYMMDDHH24MISS'))"
                        << " AND DTH_GMT = to_timestamp('" << l_szDtHrAux << "', 'YYYYMMDDhh24miss'))"
                        << " OR NUM_SEQ_UNC=" << l_origrefnum << ")";
                    }
                    break;

                default:
                    this->setResult( "EMPTY QUERY" );
                    fieldSet::fscopy( m_result, this->getResult( ) );
                    a_stop = false;
                    return 0;
                    break;
                }
            }
            
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " =========  - Clausula Where TBSW0058 -  ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );            
            
            
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " =========  setting l_whereClause -  ==========" );
            dbaccess_common::TBSW0058 tbsw0058( l_whereClause.str() );
    
    
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " =========  Preparing for Update -  ==========" );
            tbsw0058.prepare_for_update();
            
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " =========  Executing            -  ==========" );
            tbsw0058.execute();
            
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " =========  Dual Handling        -  ==========" );
            //TODOSW75 dbaccess_common::DualHandler l_dualHand( &tbsw0058 );
            
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " =========  Dual Handling - Fetch-  ==========" );
            //TODOSW75 int ret = l_dualHand.fetch( dbaccess::table::UPDATE ); 
            int ret = tbsw0058.fetch( ); 
            if ( !ret )
            {
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " =========  Fetch not OK     -  ==========" );
                this->setResult( "NOT UPDATED" );
                std::string l_msg = "WhereClause <" + l_whereClause.str() + ">";
                this->enableError( true );
                this->setErrorMessage( l_msg );
            }
            else
            {
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Updating TBSW0058 fields ==========" );

                         
                                
                dbaccess_pdv::TBSW0058RegrasFormatacao regrasFormatacao;
                acq_common::tbsw0058_params tbsw0058_params = { 0 }; 
                tbsw0058.let_as_is( );
                
                fieldSet::fsextr( tbsw0058_params.az_reason_code,   m_az_reason_code );
                fieldSet::fsextr( tbsw0058_params.cd_ems,           m_cd_ems );
                fieldSet::fsextr( tbsw0058_params.mc_info_country,  m_mc_info_country );
                fieldSet::fsextr( tbsw0058_params.nom_site_issr,    m_nom_site_issr );
                fieldSet::fsextr( tbsw0058_params.nom_host_issr,    m_nom_host_issr );
                fieldSet::fsextr( tbsw0058_params.nom_fe_issr,      m_nom_fe_issr );                
                fieldSet::fsextr( tbsw0058_params.status,           m_status );
                fieldSet::fsextr( tbsw0058_params.transcode,        m_transcode );
                fieldSet::fsextr( tbsw0058_params.msgtype,          m_msgtype );
                fieldSet::fsextr( tbsw0058_params.trace,            m_trace );
                fieldSet::fsextr( tbsw0058_params.termid,           m_termid );
                fieldSet::fsextr( tbsw0058_params.install_num,      m_install_num );
                fieldSet::fsextr( tbsw0058_params.termloc,          m_termloc );
                fieldSet::fsextr( tbsw0058_params.mc_info_ica,      m_mc_info_ica );
                fieldSet::fsextr( tbsw0058_params.pb_reason_code,   m_pb_reason_code );
                fieldSet::fsextr( tbsw0058_params.ext_network_code, m_ext_network_code );                
                fieldSet::fsextr( tbsw0058_params.pin, 16,          m_pin );
                fieldSet::fsextr( tbsw0058_params.acq_conv_rate,    m_acq_conv_rate );
                fieldSet::fsextr( tbsw0058_params.issuer,           m_issuer );
                fieldSet::fsextr( tbsw0058_params.authnum,          m_authnum );
                fieldSet::fsextr( tbsw0058_params.local_date,       m_local_date );
                fieldSet::fsextr( tbsw0058_params.local_time,       m_local_time );
                fieldSet::fsextr( tbsw0058_params.de_adc_ete,       m_de_adc_ete );
                tbsw0058_params.ind_rd_cptr = "2";
                fieldSet::fsextr( tbsw0058_params.mc_info_prod_code,m_mc_info_prod_code );
                fieldSet::fsextr( tbsw0058_params.num_ref_tran,      numeroReferenciaTransacao );
                fieldSet::fsextr( tbsw0058_params.cod_cpcd_term,     codigoCapacidadeTerminal );
                
                fieldSet::fsextr( tbsw0058_params.iss_name    , m_iss_name     );
                fieldSet::fsextr( tbsw0058_params.msg_category, m_msg_category );
                fieldSet::fsextr( tbsw0058_params.msg_name    , m_msg_name     );
                fieldSet::fsextr( tbsw0058_params.txt_adic_pos,      m_txt_adic_pos);
                fieldSet::fsextr( tbsw0058_params.addresponse , m_addresponse  ); 
                fieldSet::fsextr( tbsw0058_params.has_pin     , m_has_pin      );
                fieldSet::fsextr( tbsw0058_params.sender_mbname,     senderMailboxName);
                fieldSet::fsextr( tbsw0058_params.tokenIdentifier,   tokenIdentifier );
                fieldSet::fsextr( tbsw0058_params.codigoOrigemRespostaAutorizacao, codigoOrigemRespostaAutorizacao );
                /// COD_PROD_MTC
                fieldSet::fsextr( tbsw0058_params.codigoProdutoMastercard, m_mc_info_prod_code );
                /// COD_RGAO_MTC
                fieldSet::fsextr( tbsw0058_params.codigoRegiaoMastercard, infoRegiaoMastercard );
                
                // Release Bandeiras PDV - Abril 2019 - INICIO
                fieldSet::fsextr( tbsw0058_params.indicadorPresencaPortador, indicadorPresencaPortador );
                fieldSet::fsextr( tbsw0058_params.indicadorTecnologiaTerminal, indicadorTecnologiaTerminal );
                // Release Bandeiras PDV - Abril 2019 - FIM
                
                regrasFormatacao.COD_SERV_SNHA    ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.NUM_AUT          ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.COD_MOT_AUT      ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.NUM_MOT_RSPS     ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.DTH_STTU_TRAN    ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.COD_MOT_ISO_EMSR ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.IND_STTU_TRAN    ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.NOM_FE_ISSR      ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.NUM_AVSO_AUT     ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.TXT_DA_ADIC_EMSR ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.COD_AUT_EMSR     ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.COD_AUT_EMSR_CNVT( tbsw0058, tbsw0058_params, acq_common::UPDATE );  
                regrasFormatacao.NUM_ID_CAR       ( tbsw0058, tbsw0058_params, acq_common::UPDATE );				
                regrasFormatacao.COD_PAIS_CAR     ( tbsw0058, tbsw0058_params, acq_common::UPDATE );				

                regrasFormatacao.COD_TIP_PROD_CAR  ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.NOM_SITE_ISSR    ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.NOM_HOST_ISSR    ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.NUM_REF_TRAN     ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.COD_CPCD_TERM    ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.IND_TRAN_TKN     ( tbsw0058, tbsw0058_params, acq_common::UPDATE );               
                regrasFormatacao.COD_ORG_APRV     ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.QTD_PRCL_CNFR    ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                /// COD_PROD_MTC
                regrasFormatacao.CodigoProdutoMastercard ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                /// COD_RGAO_MTC
                regrasFormatacao.CodigoRegiaoMastercard  ( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                // Release Bandeiras PDV - Abril 2019 - INICIO
                regrasFormatacao.IndicadorPresencaPortador( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                regrasFormatacao.IndicadorTecnologiaTerminal( tbsw0058, tbsw0058_params, acq_common::UPDATE );
                // Release Bandeiras PDV - Abril 2019 - FIM


                tbsw0058.show( 0 );
                tbsw0058.update();
                tbsw0058.commit();
                this->setResult( "OK" );
            }
        }
        catch( base::GenException e )
        {
            this->setResult( "ERROR" );
            std::string l_what( e.what() );
            std::string l_msg = "Exception in TBSW0058 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            this->setResult( "ERROR" );
            std::string l_what( e.what() );
            std::string l_msg = "std::exception in TBSW0058 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }        
        fieldSet::fscopy( m_result, this->getResult( ) );
        a_stop = false;
        return 0;
    }

    //cr689721@FIS - Data: 16/09/2014 - ref. Analise conjunta de BD.
    //Criado o m�todo de convers�o do numero de autoriza��o.
    std::string TBSW0058Updater::converteAuthnum( const std::string& a_numAuth )
    {

        std::string l_result = "";
        std::string l_authnum = a_numAuth.c_str();
        
        try
        {
            char l_byte;

            if( l_authnum.size() > 0 )
            {
                std::string l_message;
                // std::string l_message = "\nconvertAuthnum(IN): [" + l_authnum + "]\n";
                // logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_message.c_str() );
                
                for ( std::string::iterator it=l_authnum.begin( ); it!=l_authnum.end( ); ++it )
                {
                    l_byte =( char )*it;
                    if ( isalpha( *it ) )
                    {
                        l_byte =( *it ) % 16;
                        l_byte =( l_byte % 10 ) + 48;
                    }
                    l_result.push_back( l_byte );
                }                

                l_message = "convertAuthnum(IN): ["+ l_authnum + "] -> (OUT): [" + l_result + "]\n";
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_message.c_str() );                
            }
        }
        catch( base::GenException e )
        {
            std::string l_msg = "Exception in ConverteAuthnum <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            std::string l_msg = "Exception in ConverteAuthnum <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }        

        //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "\nConverteNumAut: execute()-end " );

        return( l_result );
    }
    
    TBSW0058Updater& TBSW0058Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW0058Updater& TBSW0058Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
    TBSW0058Updater& TBSW0058Updater::setResult( const std::string& a_result )
    {
        m_Strresult = a_result;
        return *this;
    }
    std::string TBSW0058Updater::getResult( )
    {
        return m_Strresult;
    }
    
    dataManip::Command* TBSW0058Updater::clone() const
    {
        return new TBSW0058Updater(*this);
    }
    
    // t694446@FIS - Data: 21/11/2013 - GAP3: 1.1.4.11 - Tratamento do C�digo de Autoriza��o nos Front-Ends 
    TBSW0058Updater& TBSW0058Updater::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }
    
}//namespace plugins_pdv

