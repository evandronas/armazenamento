#include<dbaccess_pdv/TBSW0083RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
	TBSW0083RegrasFormatacao::TBSW0083RegrasFormatacao( )
	{
	}

	TBSW0083RegrasFormatacao::~TBSW0083RegrasFormatacao( )
	{
	}
}
