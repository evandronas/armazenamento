/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0047.hpp"
#include "plugins_pdv/TBSW0047Loader.hpp"

namespace plugins_pdv
{
	base::Identificable* createTBSW0047Loader( )
	{
		TBSW0047Loader* l_new = new TBSW0047Loader;
		return l_new;
	}
	bool TBSW0047Loader::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "sourceFieldPath", l_tagList );
		std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "targetFieldPath", l_tagList );
		std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setSourceFieldPath( l_sourcePath );
		this->setTargetFieldPath( l_targetPath );
		return true;
	}
	TBSW0047Loader::TBSW0047Loader( )
	{
	}
	TBSW0047Loader::~TBSW0047Loader( )
	{
	}
	bool TBSW0047Loader::init( )
	{
		std::string tb_components[]
		=
		{
			"RESULT", "COD_BCO_CMPS", "COD_INT_BCO", "COD_MODO_OPE_BCO", "COD_MODO_PLTO", "IND_OPE_CDC", "DAT_VIG_CDC", "IND_OPE_PRCI", "DAT_VIG_PRCI", "DAT_VIG_PDA", "IND_OPE_GRNT_CHQ", "IND_SIT_BCO", "IND_SIT_BCO_ESTB", "NOM_BCO_CMPL", "TMS_INCL", "COD_STTU_REG", "IND_OPE_PDA", "DAT_VIG_GRNT_CHQ"
		};
		for ( unsigned int i = 0; i < LAST_FIELD; i++ )
		{
			m_targetField[i]
			= this->navigate( m_targetFieldPath + "." + tb_components[i] );
			if ( !m_targetField[i] )
			{
				std::string l_errorMsg( "Field not found <" + m_targetFieldPath + "." + tb_components[i]
				+ ">" );
				this->enableError( true );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		std::string source_components[]
		=
		{
			"segments.merchant.nu_bco_etb"
		};
		for ( unsigned int i = 0; i < LAST_SOURCE_FIELD; i++ )
		{
			m_sourceField[i]
			= this->navigate( m_sourceFieldPath + "." + source_components[i] );
			if ( !m_sourceField[i] )
			{
				std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + "." + source_components[i]
				+ ">" );
				this->enableError( true );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		return true;
	}
	void TBSW0047Loader::finish( )
	{
	}
	int TBSW0047Loader::execute( bool& a_stop )
	{
		try
		{
			std::ostringstream l_whereClause;
			long l_cod_bco_cmps = 0;
			fieldSet::fsextr( l_cod_bco_cmps, m_sourceField[NU_BCO_ETB] );
			l_whereClause << "COD_BCO_CMPS = " << l_cod_bco_cmps;
			dbaccess_common::TBSW0047 l_table0047( l_whereClause.str( ) );
			l_table0047.prepare( );
			l_table0047.execute( );
			int ret = l_table0047.fetch( );
			if ( !ret )
			{
				setResult( "NO ROWS" );
			}
			else
			{
				setResult( "OK" );
				// enum tableFields
				fieldSet::fscopy( m_targetField[COD_BCO_CMPS], l_table0047.getCOD_BCO_CMPS( ) );
				fieldSet::fscopy( m_targetField[COD_INT_BCO], l_table0047.getCOD_INT_BCO( ) );
				fieldSet::fscopy( m_targetField[COD_MODO_OPE_BCO], l_table0047.getCOD_MODO_OPE_BCO( ) );
				fieldSet::fscopy( m_targetField[COD_MODO_PLTO], l_table0047.getCOD_MODO_PLTO( ) );
				fieldSet::fscopy( m_targetField[IND_OPE_CDC], l_table0047.getIND_OPE_CDC( ) );
				fieldSet::fscopy( m_targetField[DAT_VIG_CDC], l_table0047.getDAT_VIG_CDC( ) );
				fieldSet::fscopy( m_targetField[IND_OPE_PRCI], l_table0047.getIND_OPE_PRCI( ) );
				fieldSet::fscopy( m_targetField[DAT_VIG_PRCI], l_table0047.getDAT_VIG_PRCI( ) );
				fieldSet::fscopy( m_targetField[DAT_VIG_PDA], l_table0047.getDAT_VIG_PDA( ) );
				fieldSet::fscopy( m_targetField[IND_OPE_GRNT_CHQ], l_table0047.getIND_OPE_GRNT_CHQ( ) );
				fieldSet::fscopy( m_targetField[IND_SIT_BCO], l_table0047.getIND_SIT_BCO( ) );
				fieldSet::fscopy( m_targetField[IND_SIT_BCO_ESTB], l_table0047.getIND_SIT_BCO_ESTB( ) );
				fieldSet::fscopy( m_targetField[NOM_BCO_CMPL], l_table0047.getNOM_BCO_CMPL( ) );
				fieldSet::fscopy( m_targetField[TMS_INCL], l_table0047.getTMS_INCL( ) );
				fieldSet::fscopy( m_targetField[COD_STTU_REG], l_table0047.getCOD_STTU_REG( ) );
				fieldSet::fscopy( m_targetField[IND_OPE_PDA], l_table0047.getIND_OPE_PDA( ) );
				fieldSet::fscopy( m_targetField[DAT_VIG_GRNT_CHQ], l_table0047.getDAT_VIG_GRNT_CHQ( ) );
			}
		}
		catch( base::GenException e )
		{
			setResult( "ERROR" );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0047 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0047[" + l_what + "]";
		}
		fieldSet::fscopy( m_targetField[RESULT], getResult( ) );
		a_stop = false;
		return 0;
	}
	TBSW0047Loader& TBSW0047Loader::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	TBSW0047Loader& TBSW0047Loader::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	TBSW0047Loader& TBSW0047Loader::setResult( const std::string& a_result )
	{
		m_result = a_result;
		return *this;
	}
	std::string TBSW0047Loader::getResult( )
	{
		return m_result;
	}
	dataManip::Command* TBSW0047Loader::clone( ) const
	{
		return new TBSW0047Loader( *this );
	}
}//namespace plugins_pdv

