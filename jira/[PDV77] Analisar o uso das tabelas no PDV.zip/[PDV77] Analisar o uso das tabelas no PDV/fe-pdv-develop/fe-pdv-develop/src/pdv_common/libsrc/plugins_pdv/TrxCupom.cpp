/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TrxCupom>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TrxCupom>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694451, Ricardo Deus>
/ Data de Criação: <Fri Oct 26 15:21:52 2012>
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ <Data, Módulo, Autor, Descrição da Mudança>
/ <26.06.2013, 694449 (Fernando Ramires), inclusao do tratamento do cupom>
/ ---------------------------------------------------------------------------
************************ MODIFICACOES ************************
Autor    : Gustavo Silva Franco
Data     : 06/06/2019
Empresa  : Rede
Descricao: Correcao para adicionar zeros a esquerda no TKN_MERCHANT para completar 9 digitos
ID       : AM 230.883 (Adicional do EAK-1557)
*************************************************************
Autor    : Eduardo De Souza
Data     : 25/07/2019
Empresa  : Rede
Descricao:  EAK-1618 -  Corre��es no Cupom
ID       : AM 230.883
**************************************************************
Autor    : Fernando Brum
Data     : 26/12/2019
Empresa  : Rede
Descricao: EAK-1931 - Erro Cupom Transa��es Venda IATA PSJ
ID       : AM 230.883
**************************************************************
Autor    : Daniel Nava
Data     : 29/01/2020
Empresa  : Leega
Descricao: EAK-2026 - Correção Cupom IATA a Vista ELO
ID       : AM 262.075
**************************************************************
Autor    : Daniel Nava
Data     : 11/02/2020
Empresa  : Leega
Descricao: EAK-2319 - Retirada da validade para crédito Mastercard
ID       : AM 262.075
**************************************************************
Autor    : Darlan Delmondes
Data     : 02/06/2020
Empresa  : Rede
Descricao: AUT1-1274 - Transações com o cupom MAESTRO - TAG50 ApplicationLabel
ID       : AM 267.544
**************************************************************
*/

#pragma once

//=========================================================================//
// Includes
//=========================================================================//

#include <time.h>
#include <math.h>
#include <cstring>
#include "plugins_pdv/TrxCupom.hpp"
#include <exception>
using namespace std;

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

using namespace fieldSet;
//=========================================================================//
// Namespace
//=========================================================================//

namespace plugins_pdv
{
    //===================================================================================================//
    // Create class
    //===================================================================================================//

    base::Identificable* createTrxCupom()
    {
        TrxCupom* l_new = new TrxCupom;
        return l_new;
    }

    //===================================================================================================//
    // Basic
    //===================================================================================================//

    bool TrxCupom::startConfiguration( const configBase::Tag* a_tag )
    {
      configBase::TagList l_tagList;
      std::string l_source;

      a_tag->findTag( "sourceFieldPath", l_tagList );
      for ( unsigned int i = 0; i < l_tagList.size(); i++ )
      {
              l_source = l_tagList.at( i ).findProperty( "value" ).value();
              if ( l_source == "LOCAL" )
                  this->setLocalFieldPath( l_source );
              else
                  this->setSourceFieldPath( l_source );
      }

      a_tag->findTag( "targetFieldPath", l_tagList );
      this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

      return true;
    }

    TrxCupom::TrxCupom()
    {
    }

    TrxCupom::~TrxCupom()
    {
    }

    bool TrxCupom::init()
    {
        m_msgType = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        if( !m_msgType )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.msgtype>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_pcode = this->navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        if( !m_pcode )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.pcode>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_posEntryCode = this->navigate( m_sourceFieldPath + ".shc_msg.pos_entry_code" );
        if( !m_posEntryCode )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.pos_entry_code>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_versao_aplicativo = this->navigate( m_sourceFieldPath + ".segments.common.versao_aplicativo" );
        if( !m_versao_aplicativo )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.versao_aplicativo>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg ); 
            return false;
        }       

        m_ecrCVM = this->navigate( m_sourceFieldPath + ".segments.common.cvm_code" );
        if( !m_ecrCVM )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.ecr_CVM>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_acquirerData = this->navigate( m_sourceFieldPath + ".shc_msg.acquirer_data" );
        if( !m_acquirerData )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.acquirer_data>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_addresponse = this->navigate( m_sourceFieldPath + ".shc_msg.addresponse" );
        if( !m_addresponse )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.addresponse>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_ecrPcode = this->navigate( m_sourceFieldPath + ".segments.common.ecr_pcode" );
        if( !m_ecrPcode )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.ecr_pcode>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_avsRespcode = this->navigate( m_sourceFieldPath + ".segments.credit.avs_respcode" );
        if( !m_avsRespcode )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.avs_respcode>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_isVoid = this->navigate( m_sourceFieldPath + ".segments.common.is_void" );
        if( !m_isVoid )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.is_void>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_transcode = this->navigate( m_sourceFieldPath + ".segments.common.transcode" );
        if( !m_transcode )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.transcode>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_merCatCode = this->navigate( m_sourceFieldPath + ".segments.merchant.mer_cat_code" );
        if( !m_merCatCode )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.merchant.mer_cat_code>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_installNum = this->navigate( m_sourceFieldPath + ".segments.common.install_num" );
        if( !m_installNum )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.install_num>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_origTranscode = this->navigate( m_sourceFieldPath + ".segments.common.orig_transcode" );
        if( !m_origTranscode )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.orig_transcode>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_ecrOrigElems = this->navigate( m_sourceFieldPath + ".segments.common.ecr_orig_elems" );
        if( !m_ecrOrigElems )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.ecr_orig_elems>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_ecrMsgtype = this->navigate( m_sourceFieldPath + ".segments.common.ecr_msgtype" );
        if( !m_ecrMsgtype )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.ecr_msgtype>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_authDevcap = this->navigate( m_sourceFieldPath + ".shc_msg.auth_devcap" );
        if( !m_authDevcap )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.auth_devcap>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_isReversal = this->navigate( m_sourceFieldPath + ".segments.common.is_reversal" );
        if( !m_isReversal )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.is_reversal>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_codTrans = this->navigate( m_sourceFieldPath + ".segments.common.cod_trans" );
        if( !m_codTrans )
        {
            std::string l_errorMsg( "Invalid field path <" +
                                    m_sourceFieldPath +
                                    ".segments.common.cod_trans>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_track2 = this->navigate( m_sourceFieldPath + ".shc_msg.track2" );
        if( !m_track2 )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.track2>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_origPan = this->navigate( m_sourceFieldPath + ".segments.common.orig_pan" );
        if( !m_origPan )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.orig_pan>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

		//t694449@BT53965@24032014@BGN
        //m_termid = this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
        m_termid = this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
		//t694449@BT53965@24032014@END
		if( !m_termid )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.termid>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_filler3 = this->navigate( m_sourceFieldPath + ".shc_msg.filler3" );
        if( !m_filler3 )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.filler3>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_auth_devcap = this->navigate( m_sourceFieldPath + ".shc_msg.auth_devcap" );
        if ( !m_auth_devcap )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.auth_devcap>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_cd_ems = this->navigate( m_sourceFieldPath + ".segments.common.cd_ems" );
        if ( !m_cd_ems )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.auth_devcap>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_settlement_date = this->navigate( m_sourceFieldPath + ".shc_msg.settlement_date" );
        if ( !m_settlement_date )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.settlement_date>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_cash_back = this->navigate( m_sourceFieldPath + ".shc_msg.cash_back" );
        if ( !m_cash_back )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.cash_back>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_authnum = this->navigate( m_sourceFieldPath + ".shc_msg.authnum" );
        if ( !m_authnum )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.authnum>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        if ( !m_local_date )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.local_date>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        if ( !m_local_time )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.local_time>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_track3 = this->navigate( m_sourceFieldPath + ".shc_msg.track3" );
        if ( !m_track3 )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.track3>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_acquirer_data = this->navigate( m_sourceFieldPath + ".shc_msg.acquirer_data" );
        if ( !m_acquirer_data )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.acquirer_data>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_filler1 = this->navigate( m_sourceFieldPath + ".shc_msg.filler1" );
        if ( !m_filler1 )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.filler1>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_filler2 = this->navigate( m_sourceFieldPath + ".shc_msg.filler2" );
        if ( !m_filler2 )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.filler2>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
		
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        if ( !m_refnum )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.refnum>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_amount = this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
        if ( !m_amount )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.amount>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        //alterei de m_sourceFieldPath para m_targetFieldPath
        m_termloc = this->navigate( m_targetFieldPath + ".shc_msg.termloc" );
        if ( !m_termloc )
        {
            std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ".shc_msg.termloc>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_trace = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
        if ( !m_trace )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.trace>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_formatter_use = this->navigate( m_sourceFieldPath + ".shc_msg.formatter_use" );
        if ( !m_formatter_use )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.formatter_use>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_bin = this->navigate( m_sourceFieldPath + ".segments.common.bin" );
        if ( !m_bin )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.bin>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_ecr_pcode = this->navigate( m_sourceFieldPath + ".segments.common.ecr_pcode" );
        if ( !m_ecr_pcode )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.ecr_pcode>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_cet_mensal = this->navigate( m_sourceFieldPath + ".segments.credit.cet_mensal" );
        if ( !m_cet_mensal )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.cet_mensal>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_cet_anual = this->navigate( m_sourceFieldPath + ".segments.credit.cet_anual" );
        if ( !m_cet_anual )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.cet_anual>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_ecr_msgtype = this->navigate( m_sourceFieldPath + ".segments.common.ecr_msgtype" );
        if ( !m_ecr_msgtype )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.ecr_msgtype>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_pay_code = this->navigate( m_sourceFieldPath + ".segments.common.pay_code" );
        if ( !m_pay_code )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.pay_code>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        if ( !m_origrefnum )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.origrefnum>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_fee = this->navigate( m_sourceFieldPath + ".segments.credit.fee" );
        if ( !m_fee )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.fee>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_vl_pca_ent = this->navigate( m_sourceFieldPath + ".segments.common.vl_pca_ent" );
        if ( !m_vl_pca_ent )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.vl_pca_ent>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_install_num = this->navigate( m_sourceFieldPath + ".segments.common.install_num" );
        if ( !m_install_num )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.install_num>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_install_amt = this->navigate( m_sourceFieldPath + ".segments.credit.install_amt" );
        if ( !m_install_amt )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.install_amt>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_actual_amount = this->navigate( m_sourceFieldPath + ".segments.common.actual_amount" );
        if ( !m_actual_amount )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.actual_amount>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        //BT 59.390 - Inicio
        m_saldo_disp = this->navigate( m_sourceFieldPath + ".segments.voucher.saldo_parcial" );
        if ( !m_saldo_disp )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.voucher.saldo_parcial>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        //BT 59.390 - Fim
        
        m_mer_name = this->navigate( m_sourceFieldPath + ".segments.merchant.mer_name" );
        if ( !m_mer_name )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.merchant.mer_name>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_orig_pan = this->navigate( m_sourceFieldPath + ".segments.common.orig_pan" );
        if ( !m_orig_pan )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.orig_pan>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_bit63 = this->navigate( m_sourceFieldPath + ".segments.common.bit63" );
        if ( !m_bit63 )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.bit63>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_dt_vdd_pre_auz = this->navigate( m_sourceFieldPath + ".segments.credit.dt_vdd_pre_auz" );
        if ( !m_dt_vdd_pre_auz )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.dt_vdd_pre_auz>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_vl_txa = this->navigate( m_sourceFieldPath + ".segments.common.vl_txa" );
        if ( !m_vl_txa )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.vl_txa>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_chip_full_data = this->navigate( m_sourceFieldPath + ".segments.chip.chip_full_data" );
        if ( !m_chip_full_data )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.chip.chip_full_data>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_chip_full_data_len = this->navigate( m_sourceFieldPath + ".segments.chip.chip_full_data_len" );
        if ( !m_chip_full_data_len )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.chip.chip_full_data_len>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_codver = this->navigate( m_sourceFieldPath + ".segments.common.codver" );
        if ( !m_codver )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".shc_msg.msgtype>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_valor_tarifa = this->navigate( m_sourceFieldPath + ".segments.credit.valor_tarifa" );
        if ( !m_valor_tarifa )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.valor_tarifa>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_valor_tributos = this->navigate( m_sourceFieldPath + ".segments.credit.valor_tributos" );
        if ( !m_valor_tributos )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.valor_tributos>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_valor_seguro = this->navigate( m_sourceFieldPath + ".segments.credit.valor_seguro" );
        if ( !m_valor_seguro )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.valor_seguro>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_valor_pag_terceiros = this->navigate( m_sourceFieldPath + ".segments.credit.valor_pag_terceiros" );
        if ( !m_valor_pag_terceiros )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.valor_pag_terceiros>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_is_reversal = this->navigate( m_sourceFieldPath + ".segments.common.is_reversal" );
        if ( !m_is_reversal )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.is_reversal>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_is_void = this->navigate( m_sourceFieldPath + ".segments.common.is_void" );					
        if ( !m_is_void )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.is_void>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_avs_cep = this->navigate( m_sourceFieldPath + ".segments.credit.avs_cep" );
        if ( !m_avs_cep )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.credit.avs_cep>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_respTxt = this->navigate( m_targetFieldPath + ".segments.common.resp_txt" );
        if( !m_respTxt )
        {
            std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ".segments.common.resp_txt>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_cardholder_name = this->navigate( m_targetFieldPath + ".shc_msg.acceptorname" );
        if( !m_cardholder_name )
        {
            std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ".shc_msg.acceptorname>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        m_voucher_group_name = this->navigate( m_targetFieldPath + ".segments.voucher.nom_prod_cpom" );
        if( !m_voucher_group_name )
        {
            std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ".segments.voucher.nom_prod_cpom>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        m_voucher_footer = this->navigate( m_targetFieldPath + ".segments.voucher.txt_rdpe_cpom" );
        if( !m_voucher_footer )
        {
            std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ".segments.voucher.txt_rdpe_cpom>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        m_cod_prdc_term = this->navigate( m_targetFieldPath + ".segments.common.term_demo" );
        if( !m_cod_prdc_term )
        {
            std::string l_errorMsg( "Invalid field path <" + m_targetFieldPath + ".segments.common.term_demo>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        if (!strcmp( getenv( "ACQUIRER_ID" ), "PL" ) )
        {	
			 m_bit63_issuer = this->navigate(m_sourceFieldPath + ".segments.common.bit63");
            if( !m_bit63_issuer )
            {
                std::string l_errorMsg( "Invalid field path <" + m_localFieldPath + ".bit63>" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
			
			 m_numero_parcelas = this->navigate(m_sourceFieldPath + ".segments.private_label.numero_parcelas");
            if( !m_numero_parcelas )
            {
                std::string l_errorMsg( "Invalid field path <" + m_localFieldPath + ".segments.private_label.numero_parcelas>" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
			
			 m_plano_pagamento = this->navigate(m_sourceFieldPath + ".segments.private_label.plano_pagamento");
            if( !m_plano_pagamento )
            {
                std::string l_errorMsg( "Invalid field path <" + m_localFieldPath + ".private_label.plano_pagamento>" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
			
			 m_numero_ciclos = this->navigate(m_sourceFieldPath + ".segments.private_label.numero_ciclos");
            if( !m_numero_ciclos )
            {
                std::string l_errorMsg( "Invalid field path <" + m_localFieldPath + ".segments.private_label.numero_ciclos>" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
        }
		
        m_has_pin = this->navigate( m_sourceFieldPath + ".segments.common.has_pin" );
        if( !m_has_pin )
        {
            std::string l_errorMsg( "Invalid field path <" + m_sourceFieldPath + ".segments.common.has_pin>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        // CUPOM BAIXA TECNICA ..
        m_cod_ocorr = this->navigate( m_localFieldPath + ".cod_ocorr" );
        if( !m_cod_ocorr )
        {
            std::string l_errorMsg( "Invalid field path <" + m_localFieldPath + ".cod_ocorr>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        // DATA BAIXA TECNICA ..
        m_data_baixa = this->navigate( m_localFieldPath + ".data_baixa" );
        if( !m_data_baixa )
        {
            std::string l_errorMsg( "Invalid field path <" + m_localFieldPath + ".data_baixa>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        // HORA BAIXA TECNICA ..
        m_hora_baixa = this->navigate( m_localFieldPath + ".hora_baixa" );
        if( !m_hora_baixa )
        {
            std::string l_errorMsg( "Invalid field path <" + m_localFieldPath + ".hora_baixa>" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }

        isFallback = this->navigate( string( m_sourceFieldPath ).append( ".segments.common.is_fallback" ) );
        if( !isFallback )
        {
            string mensagemErro( "Invalid field path <" );
            
            mensagemErro.append( m_sourceFieldPath ).append( ".segments.common.is_fallback>" );
            this->enableError( true );
            this->setErrorMessage( mensagemErro );
            return false;
        }
        isContactless = this->navigate( string( m_sourceFieldPath ).append( ".segments.common.is_nfc" ) );
        if( !isContactless )
        {
            string mensagemErro( "Invalid field path <" );

            mensagemErro.append( m_sourceFieldPath ).append( ".segments.common.is_nfc>" );
            this->enableError( true );
            this->setErrorMessage( mensagemErro );
            return false;
        }
        nomeModoEntrada = this->navigate( string( m_sourceFieldPath ).append( ".segments.common.msg_entrymode" ) );
        if( !nomeModoEntrada )
        {
            string mensagemErro( "Invalid field path <" );
            
            mensagemErro.append( m_sourceFieldPath ).append( ".segments.common.msg_entrymode>" );;
            this->enableError( true );
            this->setErrorMessage( mensagemErro );
            return false;
        }
        
        // Release Bandeiras PDV - Abril 2019 - INICIO
        indicadorModoEntrada = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorModoEntrada") );
        if( !indicadorModoEntrada )
        {
            string mensagemErro( "Invalid field path <" );
            
            mensagemErro.append( m_sourceFieldPath ).append( ".segments.common.indicadorModoEntrada>" );;
            this->enableError( true );
            this->setErrorMessage( mensagemErro );
            return false;
        }
        // Release Bandeiras PDV - Abril 2019 - FIM
        
        // Padronizacao Crediario PDV - INICIO
        messageName = this->navigate( string(m_sourceFieldPath).append(".segments.common.msg_name") );
        if( !messageName )
        {
            string mensagemErro( "Invalid field path <" );
            
            mensagemErro.append( m_sourceFieldPath ).append( ".segments.common.msg_name>" );;
            this->enableError( true );
            this->setErrorMessage( mensagemErro );
            return false;
        }
        // Padronizacao Crediario PDV - FIM
        
        // Padronizacao Crediario PDV - INICIO
        merchantDocument = this->navigate( string(m_sourceFieldPath).append(".segments.merchant.nu_cgc_cpf") );
        if( !merchantDocument )
        {
            string mensagemErro( "Invalid field path <" );
            
            mensagemErro.append( m_sourceFieldPath ).append( ".segments.merchant.nu_cgc_cpf>" );;
            this->enableError( true );
            this->setErrorMessage( mensagemErro );
            return false;
        }
        // Padronizacao Crediario PDV - FIM
        
        // Padronizacao Crediario PDV - INICIO
        informationCrediario = this->navigate( string(m_sourceFieldPath).append(".segments.credit.info_crediario") );
        if( !informationCrediario )
        {
            string mensagemErro( "Invalid field path <" );
            
            mensagemErro.append( m_sourceFieldPath ).append( ".segments.credit.info_crediario>" );;
            this->enableError( true );
            this->setErrorMessage( mensagemErro );
            return false;
        }
        // Padronizacao Crediario PDV - FIM
        
        // Padronizacao Crediario PDV - INICIO
        complementoCrediario = this->navigate( string(m_sourceFieldPath).append(".segments.credit.complementoCrediario") );
        if( !complementoCrediario )
        {
            string mensagemErro( "Invalid field path <" );
            
            mensagemErro.append( m_sourceFieldPath ).append( ".segments.credit.complementoCrediario>" );;
            this->enableError( true );
            this->setErrorMessage( mensagemErro );
            return false;
        }
        // Padronizacao Crediario PDV - FIM

        // APPLICATION IDENTIFIER AND APPLICATION LABEL ( CHIP DATA - APENAS CRT E DBT )
        applicationIdentifier = this->navigate( m_localFieldPath + ".appl_id" );
        applicationLabel = this->navigate( m_localFieldPath + ".appl_label" );

		// Nava - EAK-2319
		messageIssuerName = this->navigate( m_sourceFieldPath.append( ".segments.common.iss_name" ) );

        return true;
    }

    void TrxCupom::finish()
    {
    }

    dataManip::Command* TrxCupom::clone() const
    {
        return new TrxCupom(*this);
    }

    void TrxCupom::createDemoCupom( )
    {
        int l_lastLine = __LINE__;
        try
        {
            int MAX_LINES_TICKET = 8;
            char *j;
            std::string l_receipt;
            int i;
            dec_t temp;
            int inst_pay_nr;
            int txn_with_interest = 0;/* Installment with interest ? (Com juros ?) */
            std::string s_aux;

            fieldSet::fsextr( s_aux, m_amount );
            dbm_chartodec( &amount, s_aux.c_str( ), 0 );
            l_lastLine = __LINE__;
            fieldSet::fsextr( pcode, m_pcode );

            dbm_dbltodec(&temp, (double) 2.02);
            if ((dbm_deccmp(&(amount), &temp)) == 0)
            {
                strcpy(reason_code, "DEM");
            }
            l_lastLine = __LINE__;
            dbm_dbltodec(&temp, (double) 1.01);
            if (dbm_deccmp(&(amount), &temp) == 0)
            {
                l_receipt = "TOTAL              1.01";
            }
            else
            {
                dbm_dbltodec(&(amount), (double) 0);
                l_receipt = "TOTAL              0.00";
            }
            l_lastLine = __LINE__;
            l_receipt += " DEMONSTRACAO - INVALIDO";
            l_receipt += " COMO FORMA DE PAGAMENTO";
            l_receipt += ' ';
            i = 5;

            /*bsSep98: Additional ECF001 msg on the bill, if it is the case*/
            if ((i) && (!txn_with_interest) && (pcode!=29000))
            {
                l_receipt += "EXIJA O DOCUMENTO FIS- ";i++;
                l_receipt += "CAL DE NUMERO INDICADO ";i++;
                l_receipt += "NESTE COMPROVANTE.     ";i++;
                l_receipt += "T:____ N:_____________ ";i++;
            }
            l_lastLine = __LINE__;
            if (i > MAX_LINES_TICKET)
            {
                i = MAX_LINES_TICKET;
                syslg("W-5417: Ticket too big!!\n");
            }
            l_lastLine = __LINE__;
            fieldSet::fscopy( m_respTxt, l_receipt );
        }
        catch( base::GenException e )
        {
            char l_line[10];
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            std::string l_msg = "GenException in Cupom <" + std::string( e.what() ) +
                                "> at <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            char l_line[10];
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            std::string l_msg = "Exception in Cupom <" + std::string( e.what() ) +
                                "> at <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( ... )
        {
            char l_line[10];
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            std::string l_msg = "Exception in Cupom <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
    }

	void TrxCupom::voucherFormatType( string &formatType, 
	                                  const string &formatType1,
									  const string &formatType2 )
	{
        std::string s_aux;
        
        fieldSet::fsextr( s_aux, m_versao_aplicativo );
		formatType = ( atoi( s_aux.c_str() ) > 600) ? formatType2 : formatType1;
	}
	
    int TrxCupom::createCupom( )
    {
        int l_lastLine = __LINE__;
        try
        {
            layout_start = NULL;
            std::string s_aux;
            long laux;
            char debugMessage[1024] = {0};

            fieldSet::fsextr( auth_devcap, m_auth_devcap );

            fieldSet::fsextr( cd_ems, m_cd_ems );

            fieldSet::fsextr( settlement_date, m_settlement_date );
			
			fieldSet::fsextr( pos_entry_code, m_posEntryCode );

			// Nava - EAK-2319
			fieldSet::fsextr( issuerName, messageIssuerName );

			// AUT2-2816 - REDECOMPRAS HUB DE BANDEIRAS - INICIO
			std::string localMessageName = "";
			fieldSet::fsextr( localMessageName, messageName );
			// AUT2-2816 - REDECOMPRAS HUB DE BANDEIRAS - FIM

			fieldSet::fsextr( s_aux, m_cod_ocorr );
            std::strcpy( cod_ocorr, s_aux.c_str( ) );
			
            fieldSet::fsextr( s_aux, m_data_baixa );
            std::strcpy( data_baixa, s_aux.c_str( ) );
			
            fieldSet::fsextr( s_aux, m_hora_baixa );
            std::strcpy( hora_baixa, s_aux.c_str( ) );

            m_cvForPrivateLabel = false;

            fieldSet::fsextr( s_aux, m_cash_back );
            dbm_chartodec( &cash_back, s_aux.c_str( ), 0 );
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_authnum );
            if ( s_aux.length( ) <= ( SHC_AUTHNUM_LEN + 1 ) )
            {
                std::strcpy( authnum, s_aux.c_str( ) );
            }
            else
            {
                std::strcpy( authnum, "000000" );
            }

            l_lastLine = __LINE__;

            fieldSet::fsextr( local_date, m_local_date );

            fieldSet::fsextr( local_time, m_local_time );
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_track3 );
            if ( s_aux.length( ) <= ( SHC_TRACK3_LEN + 1 ) )
            {
                std::strcpy( track3, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( track3, '\0' );
                track3[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_track2 );
            if ( s_aux.length( ) <= ( SHC_TRACK2_LEN + 1 ) )
            {
                std::strcpy( track2, s_aux.c_str( ) );

                track2Leng = s_aux.size( );
            }
            else
            {
                //std::strcpy( track2, '\0' );
                track2[0] = '\n';

                track2Leng = 0;
            }

            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_acquirer_data );
            if ( s_aux.length( ) <= ( SMS_DATA_LEN + 1 ) )
            {
                std::strcpy( acquirer_data, &( s_aux.c_str( )[24] ) );
            }
            else
            {
                //std::strcpy( acquirer_data, '\0' );
                acquirer_data[0] = '\0';
            }

            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_filler1 );
            if ( s_aux.length( ) <= ( SHC_FILLER_LEN + 1 ) )
            {
                std::strcpy( filler1, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( filler1, '\0' );
                filler1[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_filler2 );
            if ( s_aux.length( ) <= ( SHC_FILLER_LEN + 1 ) )
            {
                std::strcpy( filler2, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( filler2, '\0' );
                filler2[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( pcode, m_pcode );

            fieldSet::fsextr( s_aux, m_termid );
            if ( s_aux.length( ) <= ( SHC_TERMID_LEN + 1 ) )
            {
                std::strcpy( termid, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( termid, '\0' );
                termid[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_refnum );
            if ( s_aux.length( ) <= ( SHC_REFNUM_LEN + 1 ) )
            {
                std::strcpy( refnum, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( refnum, '\0' );
                refnum[0] = '\0';
            }
            l_lastLine = __LINE__;
			
			char strAux[256];

            fieldSet::fsextr( s_aux, m_amount );
			fieldSet::fsextr( valorVenda, m_amount );
			fieldSet::fsextr( valorTaxa, m_vl_txa );
            dbm_chartodec( &amount, s_aux.c_str( ), 0 );
			sprintf( strAux, "%f", valorVenda + valorTaxa);
            dbm_chartodec( &amount2, "0.0", 0 );
            dbm_chartodec( &amount8, strAux, 0 );
            dbm_chartodec( &amount9, "0.0", 0 );

            fieldSet::fsextr( s_aux, m_termloc );
            if ( s_aux.length( ) <= ( SHC_TERMLOC_LEN + 1 ) )
            {
                std::strcpy( termloc, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( termloc, '\0' );
                termloc[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( trace, m_trace );

            fieldSet::fsextr( s_aux, m_formatter_use );
            if ( s_aux.length( ) <= ( SHC_FORMATTER_USE ) )
            {
                std::strcpy( formatter_use, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( formatter_use, '\0' );
                formatter_use[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_bin );
            if ( s_aux.length( ) <= ( 10 + 1 ) )
            {
                std::strcpy( bin, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( bin, '\0' );
                bin[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( ecr_pcode, m_ecr_pcode );
            fieldSet::fsextr( transcode, m_transcode );
            fieldSet::fsextr( cet_mensal, m_cet_mensal );
            fieldSet::fsextr( cet_anual, m_cet_anual );
            fieldSet::fsextr( ecr_msgtype, m_ecr_msgtype );
            fieldSet::fsextr( ecr_msgtype, m_msgType );
            fieldSet::fsextr( pay_code, m_pay_code );
            fieldSet::fsextr( s_aux, m_origrefnum );
            l_lastLine = __LINE__;

            if( s_aux.length( ) <= ( 12 + 1 ) )
            {
                std::strcpy( origrefnum, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( origrefnum, '\0' );
                origrefnum[0] = '\0';
            }

            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_fee );
            dbm_chartodec( &fee, s_aux.c_str( ), 0 );

            fieldSet::fsextr( s_aux, m_vl_pca_ent );
            dbm_chartodec( &vl_pca_ent, s_aux.c_str( ), 0 );

            fieldSet::fsextr( install_num, m_install_num );

            fieldSet::fsextr( s_aux, m_install_amt );
            dbm_chartodec( &install_amt, s_aux.c_str( ), 0 );

            fieldSet::fsextr( s_aux, m_actual_amount );
            dbm_chartodec( &actual_amount, s_aux.c_str( ), 0 );
            
            fieldSet::fsextr( s_aux, m_saldo_disp );
            dbm_chartodec( &saldo_disp, s_aux.c_str( ), 0 );
            
            l_lastLine = __LINE__;

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_mer_name );
            if( s_aux.length( ) <= ( 23 + 1 ) )
            {
                std::strcpy( mer_name, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( mer_name, '\0' );
                mer_name[0] = '\0';
            }

            l_lastLine = __LINE__;

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_orig_pan );

            if( s_aux.length( ) <= ( SHC_PAN_LEN + 1 ) )
            {
                std::strcpy( orig_pan, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( orig_pan, '\0' );
                orig_pan[0] = '\0';
            }

            l_lastLine = __LINE__;

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_cardholder_name );

            if( s_aux.length( ) <= ( 30 + 1 ) )
            {
                std::strcpy( cardholder_name, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( cardholder_name, '\0' );
                cardholder_name[0] = '\0';
            }

            l_lastLine = __LINE__;

            s_aux.clear( );

            if (!strcmp( getenv( "ACQUIRER_ID" ), "PL" ) )
             fieldSet::fsextr( s_aux, m_bit63_issuer );
            else
             fieldSet::fsextr( s_aux, m_bit63 );

            if( s_aux.length( ) <= MAX_BIT63_LEN )
            {
                std::strcpy( bit63, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( bit63, '\0' );
                bit63[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( dt_vdd_pre_auz, m_dt_vdd_pre_auz );

            fieldSet::fsextr( s_aux, m_vl_txa );
            dbm_chartodec( &vl_txa, s_aux.c_str( ), 0 );

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_chip_full_data );

            if( s_aux.length( ) <= MAX_CFD_LEN )
            {
                std::strcpy( chip_full_data, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( chip_full_data, '\0' );
                chip_full_data[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( chip_full_data_len, m_chip_full_data_len );

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_codver );

            if( s_aux.length( ) <= ( MAX_CODVER_LEN + 1 ) )
            {
                std::strcpy( codver, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( codver, '\0' );
                codver[0] = '\0';
            }

            l_lastLine = __LINE__;

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_valor_tarifa );

            if( s_aux.length( ) <= ( 7 + 1 ) )
            {
                std::strcpy( valor_tarifa, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( valor_tarifa, '\0' );
                valor_tarifa[0] = '\0';
            }

            l_lastLine = __LINE__;

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_valor_tributos );

            if( s_aux.length( ) <= ( 7 + 1 ) )
            {
                std::strcpy( valor_tributos, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( valor_tributos, '\0' );
                valor_tributos[0] = '\0';
            }


            l_lastLine = __LINE__;

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_valor_seguro );

            if( s_aux.length( ) <= ( 7 + 1 ) )
            {
                std::strcpy( valor_seguro, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( valor_seguro, '\0' );
                valor_seguro[0] = '\0';
            }

            l_lastLine = __LINE__;

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_valor_pag_terceiros );

            if( s_aux.length( ) <= ( 7 + 1 ) )
            {
                std::strcpy( valor_pag_terceiros, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( valor_pag_terceiros, '\0' );
                valor_pag_terceiros[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( is_reversal, m_is_reversal );
            l_lastLine = __LINE__;

            s_aux.clear( );

            fieldSet::fsextr( s_aux, m_avs_cep );

            if( s_aux.length( ) <= ( 9 + 1 ) )
            {
                std::strcpy( avs_cep, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( avs_cep, '\0' );
                avs_cep[0] = '\0';
            }


            s_aux.clear( );
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_voucher_group_name );

            if( s_aux.length( ) <= 24 )
            {
                std::strcpy( voucher_group_name, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( voucher_group_name, '\0' );
                voucher_group_name[0] = '\0';
            }

             s_aux.clear( );
             l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_voucher_footer );

            if( s_aux.length( ) <= 24 )
            {
                std::strcpy( voucher_footer, s_aux.c_str( ) );
            }
            else
            {
                //std::strcpy( voucher_footer, '\0' );
                voucher_footer[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( ecr_pcode, m_pcode );

            bool l_isChip = false;
            int l_posEntryCode = 0;
            fieldSet::fsextr( l_posEntryCode, m_posEntryCode );
            bool l_isEcrChipfullTerm=false;

            s_aux.clear();
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, m_versao_aplicativo );

            if( !s_aux.empty() )
            {
                l_isEcrChipfullTerm =  ( atoi( s_aux.c_str() ) >= 401 )? true:false;
            }
            l_lastLine = __LINE__;

            long l_pcode = 0;
            fieldSet::fsextr( l_pcode, m_pcode );
            long l_ecrPcode = 0;
            s_aux.clear();
            fieldSet::fsextr( s_aux, m_ecrPcode );
            l_ecrPcode = atol( s_aux.c_str() );

            char l_aux[80];
            char * l_receipt = NULL;

            bool l_isVoid = false;

            s_aux.clear();

            fieldSet::fsextr( s_aux, m_isVoid );
            l_lastLine = __LINE__;
          
            if( !s_aux.empty() )
            {               
                l_isVoid =  (s_aux == "TRUE" )? true:false;
            }

            bool l_hasPin = true;

            s_aux.clear();

            fieldSet::fsextr( s_aux, m_has_pin);
            l_lastLine = __LINE__;

            if( !s_aux.empty() )
            {
                l_hasPin =  (s_aux == "TRUE" )? true:false;
            }

            int l_transcode = 0;
            fieldSet::fsextr( l_transcode, m_transcode );
            long l_merCatCode = 0;
            fieldSet::fsextr( l_merCatCode, m_merCatCode );

            bool l_isMerchCrediDollar=false;

            if(( l_merCatCode == 60806) ||
              (l_merCatCode == 61300)||
              (l_merCatCode == 61399))
              {
                l_isMerchCrediDollar = true;
              }
              l_lastLine = __LINE__;

            bool l_isMerchIntl=false;

            if(( ( l_merCatCode / 1000 ) % 10 ) == 8 )
            {
                l_isMerchIntl = true;
            }

            long l_origTranscode = 0;

            fieldSet::fsextr( l_origTranscode, m_origTranscode );

            bool l_isVoucher=false;

            if(( l_transcode == 67 )||
               (!strcmp( getenv( "ACQUIRER_ID" ), "VOUCHER" ) ))
             {
                l_isVoucher = true;
             }
             l_lastLine = __LINE__;

            long l_ecrMsgtype = 0;

            fieldSet::fsextr( l_ecrMsgtype, m_ecrMsgtype );

            l_lastLine = __LINE__;

            long l_authDevcap = 0;

            fieldSet::fsextr( l_authDevcap, m_authDevcap );

            bool l_isVisaElectron=false;

            if( l_authDevcap == 49 )
            {
                l_isVisaElectron = true;
            }

            int l_installNum = 0;

            fieldSet::fsextr( l_installNum, m_installNum );

            bool l_isReversal=false;

            s_aux.clear();

            fieldSet::fsextr( s_aux, m_isReversal );

            if( !s_aux.empty() )
            {
                //l_isReversal =  (s_aux == "Y" )? true:false;
                l_isReversal =  (s_aux == "TRUE" )? true:false;
            }
            l_lastLine = __LINE__;


            bool l_isCrediarioLoja=false;

            if(( l_ecrPcode == 170000 ) &&
               (!l_isReversal && !l_isVoid))
            {
                l_isCrediarioLoja = true;
            }

            int l_codTrans = 0;

            fieldSet::fsextr( l_codTrans, m_codTrans );

            int l_group = voucherGetTrackGroup();

            bool l_isPreAuthTxn=false;
            l_lastLine = __LINE__;

            s_aux.clear( );
            fsextr( s_aux, isFallback );
            if( s_aux.length( ) <= 5 )
            {
                strcpy( textoIsFallback, s_aux.c_str( ) );
            }
            else
            {
                //strcpy( textoIsFallback, '\0' );
                textoIsFallback[0] = '\0';
            }
            l_lastLine = __LINE__;

            s_aux.clear( );
            fsextr( s_aux, isContactless );
            if( s_aux.length( ) <= 5 )
            {
                strcpy( textoIsContactless, s_aux.c_str( ) );
            }
            else
            {
                //strcpy( textoIsContactless, '\0' );
                textoIsContactless[0] = '\0';
            }
            l_lastLine = __LINE__;

            s_aux.clear( );
            fsextr( s_aux, nomeModoEntrada );
            if( s_aux.length( ) <= 5 )
            {
                strcpy( textoNomeModoEntrada, s_aux.c_str( ) );
            }
            else
            {
                //strcpy( textoNomeModoEntrada, '\0' );
                textoNomeModoEntrada[0] = '\0';
            }
            l_lastLine = __LINE__;

            fieldSet::fsextr( s_aux, applicationIdentifier );
            std::strcpy( textoApplicationIdentifier, s_aux.c_str( ) );
			
            s_aux.clear( );
            
            if( !applicationLabel )
            { 
                //strcpy( textoApplicationLabel, '\0' );
                textoApplicationLabel[0] = '\0';
            }
            else
            {                                            
                fieldSet::fsextr( s_aux, applicationLabel );
                std::strcpy( textoApplicationLabel, s_aux.c_str( ) );
            }
                              
            if( ( l_transcode == 72 ) || ( l_transcode == 73) ||
                ( l_transcode == 68 ) || ( l_transcode == 69) ||
                ( l_transcode == 80 ) || ( l_transcode == 81) ||
                ( l_transcode == 70 ) || ( l_transcode == 77) ||
                ( l_transcode == 71 ) || ( l_transcode == 78 ) ||
                ( l_transcode == 105 ) || ( l_transcode == 106 ) // 105, 106 => Pre-auth Parcelada 
                )
             {
                l_isPreAuthTxn = true;
             }

            m_formatType.clear();

            m_trailerType.clear();

            if ( ( l_posEntryCode / 10 ) == 5 ||
                 ( l_posEntryCode / 10 ) == 7 )
            {
                l_lastLine = __LINE__;
                l_isChip = true;

                s_aux.clear();

                fieldSet::fsextr( s_aux, m_ecrCVM );

                if( !s_aux.empty() && l_isEcrChipfullTerm &&
                  ( s_aux.c_str()[1] >= '1' ) &&
                  ( s_aux.c_str()[1] <= '4' ) )
                {
                    l_lastLine = __LINE__;
                    switch ( s_aux.c_str()[1] )
                    {
                        case '1':
                            m_trailerType.assign( "trailer_pin    " );
                            break;
                        case '2':
                            m_trailerType.assign( "trailer_sig    " );
                            break;
                        case '3':
                            m_trailerType.assign( "trailer_pin_sig" );
                            break;
                        case '4':
                            m_trailerType.assign( "trailer_emissor" );
                            break;
                    }
                }
                else
                {
                    l_lastLine = __LINE__;
                    s_aux.clear();

                    fieldSet::fsextr( s_aux, m_acquirerData );

                    if ( ( s_aux.length() >=  21 ) && ( s_aux.compare( 21, 1, "N" ) == 0 ) )
                    //if ( s_aux.compare( 21, 1, "N" ) == 0  )
                    {
                        m_trailerType.assign( "trailer_pin    " );
                    }
                    else
                    {
                        m_trailerType.assign( "trailer_sig    " );
                    }
                }
                l_lastLine = __LINE__;
            }
            else if( ( l_pcode == 3000 || l_pcode == 3009 || l_pcode == 3900))
            {
                    l_lastLine = __LINE__;
                    s_aux.clear();

                    fieldSet::fsextr( s_aux, m_addresponse );

                    if( ( s_aux.length() >= 2 && ( ( s_aux.compare( 0, 2, "PV" ) == 0 ) || // Gap 9 - RF-SWo-001
                    //if( ( s_aux.compare( 0, 2, "PV" ) == 0 ) ||                          // Esta condicao, pre-existente, cobre 
                          ( s_aux.compare( 0, 2, "TV" ) == 0 ) ||                          // MASTERCARD.
                          ( s_aux.compare( 0, 2, "PX" ) == 0 ) ) ) ||                      // E para os outros emissores de credito:
                        ( l_posEntryCode == 21 && l_hasPin && !( cd_ems == 1 || cd_ems == 2 || cd_ems == 7 ) ) )
                        {
                            m_trailerType.assign( "trailer_pin    " );
                        }
                        else
                        {
                            m_trailerType.assign( "trailer_sig    " );
                        }

            }
            else
            {
                l_isChip = false;
                m_trailerType.clear();
            }

            l_lastLine = __LINE__;
            if( l_isVoid )
            {
                
                l_lastLine = __LINE__;
                if( l_transcode == 18)
                {
                    if( l_isMerchCrediDollar || l_isMerchIntl )
                    {
                        if( l_installNum > 0)
                        {
                            if( l_origTranscode == 5 || l_origTranscode == 6 )
                            {
                                l_lastLine = __LINE__;
                                m_formatType.assign( "m0400p200030s21" );
                            }
                            else if( l_origTranscode == 7 || l_origTranscode == 8 )
                            {
                                l_lastLine = __LINE__;
                                m_formatType.assign( "m0400p200030s22" );
                            }
                        }
                        else
                        {
                            l_lastLine = __LINE__;
                             m_formatType.assign( "m0400p200030s01" );
                        }
                    }
                    else if( l_ecrPcode == 9000 || l_ecrPcode == 19000 )
                    {
                        l_lastLine = __LINE__;
                        m_formatType.assign( "m0400p0n9000s00" );
                        m_cvForPrivateLabel = true;
                    }
                    else
                    {
                        s_aux.clear();

                        fieldSet::fsextr( s_aux, m_ecrOrigElems );

                        if ( s_aux.length() >= 4 && !s_aux.compare( 0, 4, "0220" ) )
                        //if ( !s_aux.compare( 0, 4, "0220" ) )
                        {
                            m_formatType.assign( "m0400p200030s30" );
                        }
                        else if ( !l_isChip )
                        {
                            m_formatType.assign( "m0400p200030s00" );
                        }
                        else
                        {
                            m_formatType.assign( "m0400p200030f00" );
                        }
                        l_lastLine = __LINE__;
                    }
                }
                else
                if( l_transcode == 70 )
                {
                    m_formatType.assign( "m0400p003000s00" );
                }
                else
                if( l_transcode == 77 )
                {
                    m_formatType.assign( "m0400p003000s77" );
                }
                else
                if( l_transcode == 12)
                {
                    if( l_isVoucher )
                    {
                        /*if( strlen(voucher_footer) )
						{
						voucherFormatType( m_formatType, 
                    						   "m0200p183000s14",  // Cupom c/ saldo
                    						   "m0200p183000s63"); // Cupom do estabelecimento sem saldo
                    												// Serial = Serial do cupom c/ saldo + 50
						}
                    	else
                    	{
                    		voucherFormatType( m_formatType,
										   "m0200p183000s12",  // Cupom c/ saldo
										   "m0200p183000s62"); // Cupom do estabelecimento sem saldo
										                       // Serial = Serial do cupom c/ saldo + 50
                        }*/
                        if( l_isChip )
                        {
                            m_formatType.assign( "m0200p183000s13" );
                        }
                        else
                        {
                            m_formatType.assign( "m0200p183000s12" );
                        }
                    }
                    else if ( l_ecrPcode == 280020 )
                    {
                        m_formatType.assign( "m0200p280020s30" );
                    }
                    else if ( l_ecrPcode == 90000 )
                    {
                        m_formatType.assign( "m0200p090000s12" );
                    }
                    else if ( l_ecrPcode == 170000 )
                    {
                        m_formatType.assign( "m0200p170000s12" );
                    }
                    else if( l_isChip )
                    {
                        m_formatType.assign( "m0200p002000f12" );
                    }
                    else
                    {
                        m_formatType.assign( "m0200p002000s12" );
                    }
                }
                l_lastLine = __LINE__;
            }
            else if( l_ecrMsgtype == 9500 )
            {
                m_formatType.assign( "m9500p900800s01");
            }
            else if( l_transcode == 39)
            {
                s_aux.clear();
                fieldSet::fsextr( s_aux, m_versao_aplicativo );
                if( atoi (s_aux.c_str() ) >= 604 && cd_ems == 96 )
                {
                    m_formatType.assign( "m0200p003009S39");
                }
                else
                {
                    m_formatType.assign( "m0200p003009s39");
                }
            }
            else if( l_transcode == 40)
            {
                m_formatType.assign( "m0200p003009s00" );
            }
            else if( l_transcode == 68 || l_transcode == 69 ) // CONFIRMACAO DE PRE A VISTA
            {
                if ( cd_ems == 95 ) // AMEX
                {
                    if ( l_isMerchCrediDollar || l_isMerchIntl )
                    {
                        m_formatType.assign( "m0220p003000s11" ); // DOLAR
                    }
                    else
                    {
                        m_formatType.assign( "m0220p003000s10" );
                    }
                }
                else
                {
                    m_formatType.assign( "m0220p003000s69" );
                }
            }
            else if( l_transcode == 72 || l_transcode == 73 ) // PRE-AUTORIZACAO A VISTA
            {
                if ( cd_ems == 95 ) // AMEX
                {
                    if ( l_isMerchCrediDollar || l_isMerchIntl )
                    {
                        m_formatType.assign( "m0100p003000s11" ); // DOLAR
                    }
                    else
                    {
                        m_formatType.assign( "m0100p003000s10" );
                    }
                }
                else
                {
                    m_formatType.assign( "m0100p003000s73" );
                }
            }
            else if( l_transcode == 80 || l_transcode == 81 ) //  CONFIRMACAO DE PRE PSJ
            {
                if ( cd_ems == 95 ) // AMEX
                {
                    if ( l_isMerchCrediDollar || l_isMerchIntl ) 
                    {
                        m_formatType.assign( "m0220p003000s13" ); // DOLAR
                    }
                    else
                    {
                        m_formatType.assign( "m0220p003000s12" );
                    }
                }
                else
                {
                    m_formatType.assign( "m0220p003000s81" );
                }
            }
            // Padronizacao Crediario PDV - INICIO
            else if (l_transcode == 21) // Contratcao Creditario
            {
                if ( l_isChip )
                {
                    m_formatType.assign( "m0200p003700f00" );
                }
                else
                {
                    m_formatType.assign( "m0200p003700s00" );
                }
            }
            // Padronizacao Crediario PDV - FIM
            else if ( l_transcode == 105 || l_transcode == 106 ) // PRE-AUTORIZACAO PARCELADA
            {
                l_lastLine = __LINE__;

                if ( cd_ems == 95 ) // AMEX PRE PSJ
                {
                    if ( l_isMerchCrediDollar || l_isMerchIntl )
                    {
                        m_formatType.assign( "m0100p003000s13" ); // DOLAR
                    }
                    else
                    {
                        m_formatType.assign( "m0100p003000s12" );
                    }
                }
                else
                {
                    m_formatType.assign( "m0100p003000s74" );   
                }

            }
            else if( l_ecrMsgtype == 9600 )
            {
                m_formatType.assign( "m9600p000000s31" );
            }
            else if( l_transcode == 75 )
            {
                m_formatType.assign( "m0100p399000s00");
                m_cvForPrivateLabel = true;
            }
            else if( l_transcode == 74)
            {
                l_lastLine = __LINE__;
                if ( l_ecrPcode == 19000 )
                {
                    m_formatType.assign( "m0200p019000s00" );
                }
                else
                {
                    m_formatType.assign( "m0200p0n9000s00" );
                }
                m_cvForPrivateLabel = true;
            }
            else
            {
                l_lastLine = __LINE__;
                if( l_installNum > 0 && !l_isCrediarioLoja )
                {
                    l_lastLine = __LINE__;
                    if( l_codTrans == 2)
                    {
                        l_lastLine = __LINE__;
                        if ( !l_isChip )
                        {
                            l_lastLine = __LINE__;
                            if( l_isMerchCrediDollar || l_isMerchIntl )
                            {
                                m_formatType.assign( "m0200p003800s05" );
                            }
                            else
                            {
                                m_formatType.assign( "m0200p003800s00");
                            }
                        }
                        else
                        {
                            m_formatType.assign( "m0200p003800f00" );
                        }
                    }
                    else
                    {
                        if( l_isVoucher )
                        {
							voucherFormatType( m_formatType, 
							                   "m0200p183000s00",   // Cupom c/ saldo
							                   "m0200p183000s50");  // Cupom do estabelecimento sem saldo
                        }
                        if( getTranstype( l_transcode ) == 2 )
                        {
                            l_lastLine = __LINE__;
                            if ( !l_isChip )
                            {
                                if( l_isMerchCrediDollar || l_isMerchIntl )
                                {
                                    // AMEX CREDI-DOLAR PARC
                                    if ( cd_ems == 95) 
                                    {
                                        m_formatType.assign( "m0200p003000s35" );
                                    }
                                    else 
                                    {
                                        m_formatType.assign( "m0200p003000s27" );
                                    }
                                }
                                else
                                {
                                    // AMEX PSJ
                                    if ( cd_ems == 95) 
                                    {
                                        m_formatType.assign( "m0200p003000s34" );
                                    }
                                    else 
                                    {   
                                        m_formatType.assign( "m0200p003000s21" );
                                    }
                                }
                            }
                            else
                            {
                                // AMEX CHIP PSJ
                                if ( cd_ems == 95) 
                                {
                                    m_formatType.assign( "m0200p003000s36" );
                                }
                                else 
                                {
                                    m_formatType.assign( "m0200p003000f21" );
                                }
                            }
                        }
                        else
                        {
                            l_lastLine = __LINE__;
                            m_formatType.assign( "m0200p002000s21" );
                        }
                    }
                }
                else
                {
                    l_lastLine = __LINE__;
                    if( l_isVoucher )
                    {
                        if ( l_group == 78 || l_group == 18 
							// AUT2-2816 - REDECOMPRAS HUB DE BANDEIRAS - INICIO
							|| localMessageName.compare("VEND_VCH_FROT") == 0
							|| localMessageName.compare("EST_VEND_VCH_FROT") == 0
							// AUT2-2816 - REDECOMPRAS HUB DE BANDEIRAS - FIM
							)
                        {
                            l_lastLine = __LINE__;
                            if( l_isChip )
                            {
                                if( strlen(voucher_footer) )
                                {
                                    m_formatType.assign( "m0200p182000s05" );
                                }
                                else
                                {
                                    m_formatType.assign( "m0200p182000s03" );
                                }
                            }
                            else
                            {
                                if( strlen(voucher_footer) )
                                {
                                    m_formatType.assign( "m0200p182000s04" );
                                }
                                else
                                {
                                    m_formatType.assign( "m0200p182000s02" );
                                }
                            }
                            /*tofix: aguardando novo voucher_get_cv_footer
                            if( strlen(footer) )
                                m_formatType.assign( "m0200p182000s01" );
                            else*/
                            //    m_formatType.assign( "m0200p182000s00" );
                        }
                        else
                        {   //   [SALDOVOUCHER]@
                        	if( strlen(voucher_footer) )
							{
							voucherFormatType( m_formatType, 
							                   "m0200p183000s01",       // Cupom c/ saldo
							                   "m0200p183000s51");  // Cupom do estabelecimento sem saldo
							}
                        	else
                        	{
                           		voucherFormatType( m_formatType,
							                   "m0200p183000s00",       // Cupom c/ saldo
							                   "m0200p183000s50");  // Cupom do estabelecimento sem saldo
                            }
                        }    
                    }
                    else if( getTranstype( l_transcode ) == 2 )
                    {
                        l_lastLine = __LINE__;
                        s_aux.clear();
                        fieldSet::fsextr( s_aux, m_versao_aplicativo );
                        if ( !l_isChip )
                        {
                            if( l_isMerchCrediDollar || l_isMerchIntl )
                            {
                                // AMEX A VISTA CREDI DOLAR
                                if ( cd_ems == 95) 
                                {
                                    m_formatType.assign( "m0200p003000s31" );
                                }
                                else
                                {
                                    m_formatType.assign( "m0200p003000s05" );
                                }
                            }
                            else
                            {
                                if( atoi (s_aux.c_str() ) >= 604 && ( l_transcode == 3 || l_transcode == 4 ) && cd_ems == 96 )
                                {
                                    m_formatType.assign( "m0200p003000S00" );
                                }
                                else if ( cd_ems == 95) // AMEX A VISTA NORMAL
                                {
                                    m_formatType.assign( "m0200p003000s30" );
                                }
                                else
                                {
                                    m_formatType.assign( "m0200p003000s00" );
                                }
                            }
                        }
                        else
                        {
                            if( atoi (s_aux.c_str() ) >= 604 && ( l_transcode == 3 || l_transcode == 4 ) && cd_ems == 96 )
                            {
                                m_formatType.assign( "m0200p003000F00" );
                            }
                            else if ( cd_ems == 95) // AMEX CHIP A VISTA
                            {
                                m_formatType.assign( "m0200p003000s32" );
                            }
                            else
                            {
                                m_formatType.assign( "m0200p003000f00" );
                            }
                        }
                    }
                    else
                    {

                        int versaoPDV = 0;
                        std::string versaoPDVConv;

                        fieldSet::fsextr( versaoPDVConv, m_versao_aplicativo );

                        if( !versaoPDVConv.empty() )
                        {
	                        versaoPDV = atoi( versaoPDVConv.c_str() );
                        }
			
                        if( l_ecrPcode == 2800 )
                        {
                            m_formatType.assign( "m0200p002800s30" );
                        }
                        else if( l_ecrPcode == 900800 )
                        {
                            m_formatType.assign( "m9200p900800s01" );
                        }
                        else if( l_ecrPcode == 2900 )
                        {
                            l_lastLine = __LINE__;
                            if (l_isChip)
                            {
                                if( l_isEcrChipfullTerm )
                                {
                                    m_formatType.assign( "m0200p002900f01" );
                                }
                                else
                                {
                                    m_formatType.assign( "m0200p002900f00" );
                                }
                            }
                            else
                            {
                                m_formatType.assign( "m0200p002900s00" );
                            }
                        }
                        else if ( l_ecrPcode == 90000 )
                        {
                            m_formatType.assign( "m0200p090000s00" );
                        }
                        else if ( l_ecrPcode == 170000 )
                        {
                            m_formatType.assign( "m0200p170000s00" );
                            /*tofix: aguardando novo complemento_get
                            memset(&compl,0,sizeof(compl));
                            complemento_get(Txn,&compl);
                            if (strlen(compl.txt_cmpm_cpom_vd) > 0)
                            {
                                strcpy (Txn->swmsg.bit63, compl.txt_cmpm_cpom_vd);

                            }
                            */
                        }
                        else if ( l_isChip )
                        {
                            l_lastLine = __LINE__;
                            s_aux.clear();
                            fieldSet::fsextr( s_aux, m_versao_aplicativo );
                            if( l_isEcrChipfullTerm )
                            {
                                if( atoi (s_aux.c_str() ) >= 604 && cd_ems == 97 )
                                {
                                    m_formatType.assign( "m0200p002000F01" );
                                }
                                else
                                {
                                    m_formatType.assign( "m0200p002000f01" );
                                }
                            }
                            else
                            {
                                if( atoi (s_aux.c_str() ) >= 604 && cd_ems == 97 )
                                {
                                    m_formatType.assign( "m0200p002000F00" );
                                }
                                else
                                {
                                    m_formatType.assign( "m0200p002000f00" );
                                }
                            }
                        }
                        else if((cd_ems == 49)                                           && // Visa debito
                                (pos_entry_code == 21 || pos_entry_code == 801)          && // Tarja e fallback
                                (l_pcode == 2000 || l_pcode == 2900 || l_pcode == 90000) &&
                                (versaoPDV >= 503)                                       &&
                                !l_hasPin)
                        {
                                		m_formatType.assign( "m0200p002000s01");
                        }
                        else
                        {
                            m_formatType.assign( "m0200p002000s00");
                        }
                    }
                }
            }

            if( !l_receipt )
            {
                l_lastLine = __LINE__;

                if ( !l_isPreAuthTxn  && ( l_isVoucher ||
                                           l_transcode == 74 ||
                                           l_transcode == 75 ||
                                           l_transcode == 76 ||
                                           l_origTranscode == 74 ||
                                           l_origTranscode == 75 ||
                                           l_origTranscode == 76 ||
                                           ( getTranstype( l_transcode ) == 2 ) ||
                                           l_transcode == 1 ||
                                           l_transcode == 2 ||
                                           l_transcode == 12 ) )
                {
                    l_lastLine = __LINE__;
                    s_aux.clear();

                    fieldSet::fsextr( s_aux, m_origPan );

                    m_cupomOrigPan.assign( s_aux );
                    m_cupomOrigPan.replace( 0, 1, s_aux.length() - 4 ,'x');
                }
                else
                {
                    l_lastLine = __LINE__;
                    s_aux.clear();

                    fieldSet::fsextr( s_aux, m_versao_aplicativo );

                    if( atoi (s_aux.c_str() ) >= 202 )
                    {
                        m_cupomOrigPan.assign( "[CARTAO]" );
                    }
                }

                s_aux.clear();

                fieldSet::fsextr( s_aux, m_termid );

                m_cupomTermid.assign( s_aux );
                l_lastLine = __LINE__;

                if( l_ecrPcode == 2800 || l_ecrPcode == 280020 ||
                    l_ecrMsgtype == 9100 || l_ecrMsgtype == 9200 ||
                    l_ecrMsgtype == 9500 )
                {
                    s_aux.clear();

                    fieldSet::fsextr( s_aux, m_filler3 );

                    m_cupomTermid.assign( s_aux.substr( 41, s_aux.length() ) );
                }


                char buffer[m_formatType.size()+1];
                sprintf( buffer, "%s", m_formatType.c_str( ) );

                sprintf( debugMessage, "Calling format_receipt [%s] ", m_formatType.c_str( ) );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, debugMessage );

                //printf("\n\n\nbuffer: %s\n\n\n", buffer);
                l_lastLine = __LINE__;
                if ( (l_receipt = format_receipt( buffer )) == NULL )
                {
                    return -1;
                }

				// Nava - EAK-2319
				if( !issuerName.compare( "MASTERCARD" ) && m_receipt.length() > 0 )
				{
					int valPos = m_receipt.find( "VAL:" );
					
					if( valPos >= 0 && m_receipt.at( valPos + 6 ) == '/' )
					{
						m_receipt.replace( valPos, 9, "         " );
					}
				}

                fieldSet::fscopy( m_respTxt, m_receipt );
            }
        }
        catch( base::GenException e )
        {
            char l_line[10];
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            std::string l_msg = "GenException in Cupom <" + std::string( e.what() ) +
                                "> at <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            char l_line[10];
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            std::string l_msg = "Exception in Cupom <" + std::string( e.what() ) +
                                "> at <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( ... )
        {
            char l_line[10];
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            std::string l_msg = "Exception in Cupom <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        return 1;
    }

    int TrxCupom::execute( bool& a_stop )
    {
        layout_start = NULL;

        std::string cod_prdc_term = "0";

        fieldSet::fsextr( cod_prdc_term, m_cod_prdc_term );

        if (cod_prdc_term == "1")
        {
            createDemoCupom( );
        }
        else
        {
            createCupom( );
        }

        a_stop = false;

        return 0;
    }

    //===================================================================================================//
    // Sets by targets
    //===================================================================================================//

    TrxCupom& TrxCupom::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TrxCupom& TrxCupom::setSourceFieldPath( const std::string& a_path )
    {
          m_sourceFieldPath = a_path;
          return *this;
    }

    TrxCupom& TrxCupom::setLocalFieldPath( const std::string& a_path )
    {
          m_localFieldPath = a_path;
          return *this;
    }

    //===================================================================================================//
    // General
    //===================================================================================================//

    int TrxCupom::getTranstype( short a_transcode )
    {
        int l_txnType = -1;
        char dumpMsg[64] = {0};

        switch ( a_transcode )
        {
            case  3: /* VENDA VISTA - MAGNETICO                          */
            case  4: /* VENDA VISTA CART CRED DIGIT                      */
            case  5: /* VENDA PRAZO CART CRED MAGN                       */
            case  6: /* VENDA PRAZO CART CRED DIGIT                      */
            case  7: /* VENDA PARC. SEM JUROS MAGN                       */
            case  8: /* VENDA PARC. SEM JUROS DIGIT                      */
            case 18: /* ESTORNO VENDA CARTAO CREDITO                     */
            case 21: /* AUTORIZACAO ROTAT/PLUS/CASH (VARIG)              */
            case 39: /* VENDA PASSAGEM AEREA A VIST                      */
            case 40: /* VENDA PASSAGEM AEREA - IATA                      */
            case 41: /* ESTORNO DE AUTORIZACAO (VARIG)                   */
            case 48: /* VENDA SIDECARD - MAGNETICA                       */
            case 49: /* VENDA SIDECARD - DIGITADA                        */
            case 55: /* PRE-DATADO MAGNETICO                             */
            case 56: /* PRE-DATADO DIGITADO                              */
            case 68: /* CONFIRMACAO DE PRE-AUTORIZACAO MAGNETICA         */
            case 69: /* CONFIRMACAO DE PRE-AUTORIZACAO DIGITADA          */
            case 70: /* CONFIRMACAO DE PRE-AUTORIZACAO DIGITADA          */
            case 71: /* DESFAZIMENTO DE PRE-AUTORIZACAO                  */
            case 72: /* SOLICITACAO DE PRE-AUTORIZACAO MAGNETICA         */
            case 73: /* SOLICITACAO DE PRE-AUTORIZACAO DIGITADA          */
            /* TAII FINI & etc Take them as credit begin- */
            case 74: /* VENDA CARTAO PROPRIO (FININVEST/UNNISA)          */
            case 75: /* CONSULTA CARTAO PROPRIO (FININVEST/UNNISA)       */
            case 76: /* VENDA OFF-LINE CARTAO PROPRIO (FININVEST/UNNISA) */
            /* TAII FINI & etc Take them as credit -end */
            case 77: /* ESTORNO DE CAPTURA DE PRE-AUTORIZACAO            */
            case 78: /* DESFAZIMENTO DE CAPTURA DE PRE-AUTORIZACAO       */
            case 79: /* SMART-CARD VENDA OFF-LINE                        */
            case 80: /* CONFIR. DE PREAUTOR. MAG. PARC SEM JUROS         */
            case 81: /* CONFIR. DE PREAUTOR. DIG. PARC SEM JUROS         */
            case 82: /* FUNCAO CAPTURA VISTA MA                          */
            case 83: /* FUNCAO CAPTURA VISTA DIGIT                       */
            case 84: /* FUNCAO CAPTURA PRAZO MAGN                        */
            case 85: /* FUNCAO CAPTURA PRAZO DIGIT                       */
            case 86: /* FUNCAO CAPTURA PARC. SEM JUROS MAGN              */
            case 87: /* FUNCAO CAPTURA PARC. SEM JUROS DIGIT             */
            case 91: /* FONESHOP PAGAMENTO ROTATIVO - mai2008            */
            case 92: /* FONESHOP PAGAMENTO PSJ - mai2008                 */
            case 93: /* FONESHOP PAGAMENTO PCJ - mai2008                 */
            case 105: /* SOLICITACAO DE PRE-AUTORIZACAO PARCELADA CHIP/MAG */
            case 106: /* SOLICITACAO DE PRE-AUTORIZACAO PARCELADA DIGIT */

                l_txnType = 2;       /* Credit */
                break;

            case  1: /* VENDA BANCO - MAGNETICO                          */
            case  2: /* VENDA BANCO - DIGITADO                           */
            case  9: /* VENDA BANCO - DIGITADO                           */
            case 12: /* ESTORNO DE VENDA BANCO                           */
            case 20: /* CONSULTA GARANTIA DE CHEQUE                      */
            case 57: /* DEBITO PRE-DATADO                                */
            case 65: /* DEB. PRE-DATADO S/GARANTIA                       */
            case 66: /* DEB. PARCELADO  S/GARANTIA                       */
            case 67: /* VOUCHER (TICKET)                                 */
            case 89: /* CREDIARIO LOJA                                   */
                l_txnType = 1;       /* Debit */
                break;

            case 0:  /* Nao previsto                                     */
            case 10: /* CONSULTA TELECHEQUE                              */
            case 11: /* RESUMO DE VENDAS                                 */
            case 13: /* POSICAO ACUMULADA                                */
            case 14: /* ABERTURA TERMINAL / SIGN-ON                      */
            case 15: /* FECHAMENTO TERMINAL/SIGN OFF                     */
            case 16: /* CONSULTA RAV                                     */
            case 17: /* AVS                                              */
            case 19: /* CONFIRMACAO RAV                                  */
            case 31: /* BAIXA DE OCORRENCIA TECNICA                      */
            case 43: /* DESFAZIMENTO DE TRANSACAO                        */
            case 90: /* CONSULTA FONESHOP                                */
            case 94: /* CONFIRMACAO FONESHOP PAGAMENTO - mai2008         */
                l_txnType = 3;       /* Generic */
                break;
        }

        sprintf( dumpMsg, "getTranstype( %d ) -> [%d] ", a_transcode, l_txnType );
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, dumpMsg );

        return l_txnType;
    }

    int TrxCupom::IsReversal( char is_reversal )
    {
        return( is_reversal == 'Y' );
    }

    //===================================================================================================//
    // Voucher
    //===================================================================================================//

    int TrxCupom::voucherGetTrackGroup()
    {
        if ( track2Leng > 33 )
        {
            std::string aux(track2);

            return atoi( aux.substr( 31, 2 ).c_str() );
        }
        return -1;
    }

    //===================================================================================================//
    // Lib capture
    //===================================================================================================//

    int TrxCupom::get_exp_date( char* track2 )
    {
        char c;
        char exp_date[ 5 ];

        while ( ( *track2 != '\0' ) && ( *track2 != '=' ) && ( *track2 != 'D' ) )
        {
            ++track2;
        }

        if ( ( *track2 == '=' ) || ( *track2 == 'D' ) )
        {
            memcpy( exp_date, track2 + 1, 4 );
            exp_date[ 4 ] = '\0';
        }

        return( atoi( exp_date ) );
    }

    int TrxCupom::get_exp_date_track3( char* track3 )
    {
        char c;
        char exp_date[ 5 ];

        while ( ( *track3 != '\0' ) && ( *track3 != '^' ) )
        {
            ++track3;
        }

        ++track3;
        while ( ( *track3 != '\0' ) && ( *track3 != '^' ) )
        {
            ++track3;
        }

        if ( *track3 == '^' )
        {
            memcpy( exp_date, track3 + 1, 4 );
            exp_date[ 4 ] = '\0';
        }

        return( atoi( exp_date ) );
    }

    //===================================================================================================//
    // VDA
    //===================================================================================================//

    void TrxCupom::binary_to_char( char* dest, char* orig, int len )
    {
        //Convert from the binary format contents to the hex-printable char.
        int i;
        char* destp;
        char* origp;
        for ( i = 0, destp = dest, origp = orig; ( i * 2 ) < len; i++, destp += 2, origp++ )
        {
            sprintf( destp, "%02x", *origp );
        }
        if ( len % 2 )
        {
            *( dest + len ) = '\0';
        }
    }

    void TrxCupom::get_bit63data( char *dest )
    {
        char *origp = avs_cep;
        int len = (int) *origp++;
        binary_to_char( dest, origp, len );
    }
   
    int TrxCupom::convert_in_tpo_vda( int in_tpo_trx )
    {
        int in_tpo_vda = 0;
        switch ( in_tpo_trx )
        {
            case 3:
            case 4:
            case 39:
            case 68:
            case 69:
                in_tpo_vda = 1;
                break;
            case 5:
            case 6:
                in_tpo_vda = 2;
                break;
            case 7:
            case 8:
            case 80:
            case 81:
                in_tpo_vda = 3;
                break;
            case 48:
            case 49:
                in_tpo_vda = 4;
                break;
            case 57:
                in_tpo_vda = 6;
                break;
        }
        return( in_tpo_vda );
    }

    int TrxCupom::plabel_in_tpo_vda( int in_tpo_trx )
    {
        int in_tpo_vda = 0;
        if ( in_tpo_trx == 74 || in_tpo_trx == 75 || in_tpo_trx == 76 )
        {
            short in_qtd_ccl;
            short in_pln_pgt;
            dec_t vl_tot_trx;
						
			fieldSet::fsextr( in_pln_pgt, m_plano_pagamento );
			fieldSet::fsextr( in_qtd_ccl, m_numero_ciclos );           

            //if( pcode == 383000 || pcode == 173000 )
            if ( cd_ems == 32 )
            {
                //Parcelas - only this? That's told.
                in_tpo_vda = 2;
            }
            else
            {
                //Purchase or inquiry for purchase.
                if ( pcode == 9000 || ( pcode == 399000 && pay_code == 31 ) )
                {
                    if ( in_pln_pgt == 0 && in_qtd_ccl == 0 )
                    {
                        in_tpo_vda = 1;
                    }
                    else if ( in_pln_pgt != 0 && in_qtd_ccl == 0 )
                    {
                        in_tpo_vda = 2;
                    }
                    else if ( in_pln_pgt == 0 && in_qtd_ccl != 0 )
                    {
                        in_tpo_vda = 3;
                    }
                    else if ( in_pln_pgt != 0 && in_qtd_ccl != 0 )
                    {
                        in_tpo_vda = 4;
                    }
                }
                else
                {
                    //Cash or inquiry for cash.
                    if ( pcode == 19000 || ( pcode == 399000 && pay_code == 41 ) )
                    {
                        if ( in_pln_pgt < 2 )
                        {
                            in_tpo_vda = 1;
                        }
                        else if ( in_pln_pgt > 1 )
                        {
                            in_tpo_vda = 2;
                        }
                    }
                }
            }
        }
        return( in_tpo_vda );
    }

    //===================================================================================================//
    // Main
    //===================================================================================================//

    struct _token *TrxCupom::token_and_layout_init()
    {
        char aux[160];
        char *auxp;
        char buf[81];
        unsigned int i, j, k, l, x, y;

        FILE *layfp;

        struct _token *wtoken;
        char *wlay;

        int ltoken_id;
        char ltoken_name[41];
        char llen[4];
        char lposition;
        char lleft_zero;
        char ldecimal[3];
        char lseparator;

        try
        {
    
            sprintf( aux, "%s", getenv("CUPOMLAYOUTFILEPATH"));
    
            if( (layfp = fopen( aux, "r")) == NULL)
            {
                //printf("\n\nLINE: %d\n\n",__LINE__);
                return( NULL);
            }
    
            for( i = 0; fgets( aux, sizeof(aux), layfp) != NULL; )
            {
                if( !strncmp( aux, "token-id:", 9))
                {
                    i = 1;
                    break;
                }
            }
            //printf("\n\nLINE: %d\n\n",__LINE__);
            if(i)
            {
                for( i = 0; fgets( aux, sizeof(aux), layfp) != NULL &&
                (k = strncmp( aux, "end_token-id", 12)); )
                {
                        if( aux[0] != ';')
                        {
                            i++;
                        }
                    }
            }
    
            if( !i || k)
            {
                //printf("\n\nLINE: %d\n\n",__LINE__);
                return( NULL);
            }
    
            i++;
    
            rewind( layfp);
    
            for( j = 0, l = 1; fgets( aux, sizeof(aux), layfp) != NULL; l++)
            {
                if( strncmp( aux, "type:", 5))
                {
                    continue;
                }
                /*
                printf("\n\n aux: %d\n\n",aux);
                printf("\n\n buf: %d\n\n",buf);
                printf("\n\n strlen( buf): %d\n\n",strlen( buf));
                printf("\n\n sscanf( aux, s s, buf, buf): %d\n\n",sscanf( aux, "%s %s", buf, buf));
                printf("\n\n aux: %s\n\n",aux);
                */
                if( sscanf( aux, "%s %s", buf, buf) != 2
                || strlen( buf) > 15)
                {   /*
                    printf("Line:%d Invalid type name len. Must be %s",
                        "m<msgtype>p<pcode>s<serial> completing 15 bytes");
                    */
                    //printf("\n\nLINE: %d\n\n",__LINE__);
                    //return( NULL);
                }
    
                j += 15;
    
                for( ++l ; fgets( aux, sizeof(aux), layfp) != NULL &&
                (k = strncmp( aux, "end_type", 8)); l++ )
                {
                    if( aux[0] == ';')/*Discard the comment line*/
                    {
                        continue;
                    }
    
                    aux[ strlen(aux) - 1] = '\0';/*Slash out 0x0a */
    
                    aux[ strcspn(aux, ";")] = '\0';/*Slash out ';'*/
    
                    j += strcspn(aux, "@");/*Length up to '@'*/
    
                    if( strcspn(aux, "@") < strlen(aux))
                    {
                        j += 1;/*Plus '@'*/
                    }
                }
    
                if( !j || k)
                {
                    //printf("\n\nLINE: %d\n\n",__LINE__);
                    //printf("TrxCupom::token_and_layout_init Line:%d Incomplete type:/end_type group in layout file\n",l-1);
                    return( NULL);
                }
                j += 1;/*Reserve one byte for null-terminator of receipt layout*/
            }
            j += 1;/*One more byte to indicate end-of-list */
    
            k = (i * sizeof(struct _token)) + j;
    
            if( (token = (struct _token *)((char *)calloc( 1, (size_t)k))) == NULL)
            {
                //printf("\n\nLINE: %d\n\n",__LINE__);
                //printf("TrxCupom::token_and_layout_init Error allocating memory for token list & receipt layouts\n");
                return( NULL);
            }
    
            /* Compute the begin address for the receipt layouts */
            layout_start = (char *)((struct _token *)token + i);
    
            /*
            * Now, start loading the contents from the token & layout definition file
            */
            rewind( layfp);
    
            for( wtoken = token, l = 1; fgets( aux, sizeof(aux), layfp) != NULL; l++)
            {
                if(    !strncmp( aux, "token-id:", 9))/* Look for the starting line */
                {
                    break;
                }
            }
    
            for( i = 0, ++l; fgets( aux, sizeof(aux), layfp) != NULL &&
                                (k = strncmp( aux, "end_token-id", 12)); l++)
            {
                if( aux[0] == ';')
                {
                    continue;
                }
    
                if( sscanf(aux, "%d %s %s %c %c %s %c", &ltoken_id, ltoken_name,
                                llen, &lposition, &lleft_zero, ldecimal, &lseparator) < 7)
                {
                    //printf("Line:%d Incomplete token definition line found\n", l);
                    free( token);
                    //printf("\n\nLINE: %d\n\n",__LINE__);
                    return( NULL);
                }
    
                if( strlen(ltoken_name) > sizeof(wtoken->name))
                {
                    free( token);
                    //printf("\n\nLINE: %d\n\n",__LINE__);
                    return( NULL);
                }
    
                wtoken->id = ltoken_id;
    
                sprintf( wtoken->name, "%s", ltoken_name);
    
                /* FINI & etc Added v or V for variable source string len */
                if( llen[0] == '*' || llen[0] == 'v' || llen[0] == 'V')
                {
                    wtoken->len = llen[0];
                }
                else
                {
                    wtoken->len = (char)(atoi(llen));
                }
    
                wtoken->position = lposition;
    
                wtoken->left_zero = lleft_zero;
    
                if( ldecimal[0] == '*')
                {
                    wtoken->decimal    = ldecimal[0];
                }
                else
                {
                    wtoken->decimal = (char)(atoi(ldecimal));
                }
    
                wtoken->separator    = lseparator;
    
                wtoken++;
            }
    
            wtoken->id = 999999;/*End-of-token-list indicator*/
    
            rewind( layfp);
    
            for( wlay = layout_start, l = 1; fgets( aux, sizeof(aux), layfp) != NULL; l++)
            {
                if( strncmp( aux, "type:", 5))
                {
                    continue;
                }
    
                /* Get the type name */
                aux[strlen(aux) - 1] = '\0';
                for( i = 0; aux[i] != ':' && aux[i] != ' '; i++)
                    ;
                for(      ; aux[i] == ':' || aux[i] == ' '; i++)
                    ;
    
                sprintf(buf, "%-15s", (char *)&aux[i]);
    
                memcpy( wlay, buf, 15);
    
                wlay += 15;
    
                for( ++l; fgets( aux, sizeof(aux), layfp) != NULL &&
                (k = strncmp( aux, "end_type", 8)); l++ )
                {
                    if( aux[0] == ';')/*Discard the comment line*/
                    {
                        continue;
                    }
    
                    aux[ strlen(aux) - 1] = '\0';/*Slash out 0x0a*/
    
                    aux[ strcspn(aux, ";")] = '\0';/*Slash out ';'*/
    
                    k = strcspn(aux, "@");/*Length up to '@'*/
    
                    if( strcspn(aux, "@") < strlen(aux))
                    {
                        k += 1;/*Plus '@'*/
                    }
    
                    memcpy( wlay, aux, k);
    
                    wlay += k;
                    //printf("\n\n aux: %s\n\n",aux);
                    /* Validate token, if any */
                    auxp = aux;
                    while( (x = strcspn(auxp, "#")) < strlen(auxp))
                    {
                        for( ++auxp; !isdigit(*auxp) || !isdigit(*(auxp + 1)); auxp++) ;
    
                        if( !isdigit(*(auxp + 1)) || isdigit(*(auxp + 2)))
                        {
                            //printf("\n\n auxp: %s\n\n",auxp);
                            free( token);
                            //printf("\n\nLINE: %d\n\n",__LINE__);
                            return( NULL);
                        }
    
                        strncpy( buf, auxp, 2);
    
                        buf[2] = '\0';
    
                        y = atoi( buf);
    
                        for( wtoken = token; wtoken->id != 999999; wtoken++)
                        {
                            if( wtoken->id == y)
                            {
                                break;
                            }
                        }
    
                        if( wtoken->id == 999999)
                        {
                            //printf("Line:%d Token id %d not defined on the token list\n",l,y);
    
                            free( wtoken);
                            //printf("\n\nLINE: %d\n\n",__LINE__);
                            return( NULL);
                        }
    
                        auxp += 2;
    
                        if( *auxp == '#')
                            for( ; *auxp == '#'; auxp++)
                            ;
                    }
                }
    
                *wlay = '\0';/*End-of-layout-indicator */
                wlay++;
            }
    
            *wlay = 0xff;/*End-of-layout-list-indicator */
        }
        catch( std::exception e )
        {
            std::string l_msg = "Exception in Cupom <" + std::string( e.what() )+ ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( ... )
        {
            std::string l_msg = "Exception in Cupom ";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "token" );
        return( token);
    }

    struct _token *TrxCupom::get_token( char **wlayout, int *len)
    {
        char *wlay;

        struct _token *wtoken = token;
        int i, j, k;
        char aux[5];

        wlay = *wlayout;

        /* Return NULL if there is no more token */
        if( (wlay = index(wlay, (int)'#')) == NULL)
        {
            return( NULL);
        }

        /* Set the layout pointer to the new address, where the token starts */
        *wlayout = wlay;

        /* Look for the token id and count the number of '#'s */
        for( i = 0; *wlay == '#'; i++, wlay++)
            ;

        /* Get the token id */
        memcpy( aux, wlay, 2);
        aux[2] = '\0';
        j = atoi( aux);

        /* Point to the token element on the list */
        for( wtoken = token; wtoken->id != j; wtoken++)
            ;

        /* Compupte the length of output string */
        for( i += 2, wlay += 2; *wlay == '#'; i++, wlay++)
            ;

        *len = i;

        return( wtoken);
    }

    char* TrxCupom::get_layout( char *type_key )
    {
        char *wlay;
        try{

            if ( layout_start == NULL )
            {
                if ( ( token = token_and_layout_init( ) ) == NULL )
                {   //printf("\n\nLINE: %d\n\n",__LINE__);
                    return( NULL);
                }
            }
            //printf("\n\nLINE: %d\n\n",__LINE__);
            wlay = layout_start;

            while ( memcmp( wlay, type_key, 15 ) )
            {
                if ( (wlay = index( wlay, (int) '\0' ) ) != NULL )
                {
                    wlay++;
                }
                else
                {
                    break;
                }

                if ( *wlay == '\xff' )
                {
                    break;
                }
            }
        }
        catch(exception& e)
        {

        }

        if ( wlay == NULL || *wlay == '\xff' )
        {   //printf("\n\nLINE: %d\n\n",__LINE__);
            return( NULL);
        }
        else
        {
            return( (wlay + 15 ) );
        }
        //printf("\n\nLINE: %d\n\n",__LINE__);
    }

    char *TrxCupom::format_receipt( char *type )
    {
        static char receipt[1024];
        char *wreceipt = receipt;
        char *wlayout;
        char *wlayout_saved;
        int serial = 0;

        struct _token *wtoken;
        int outstrlen = 0;
        int actuallen = 0;
        char type_key[16];
        char last_wtoken[40];

        char debugMessage[1024];

        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "format_receipt_begin" );

        sprintf( debugMessage, "type[%s]mTrailerType[%s]\n", type, m_trailerType.c_str() );
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, debugMessage );

        if( strlen(type))
        {
            if( strlen(type) > 15)
            {
                return( NULL);
            }
            strcpy( type_key, type);
        }
        else
        {
            sprintf(type_key, "m%04dp%06dv%02", ecr_msgtype, ecr_pcode, serial);
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, type_key );
        }

        if ( !strlen( m_trailerType.c_str( ) ) )
        {
            trailer[0] = '\0';
        }
        else if ( strlen( m_trailerType.c_str() ) && strcmp( type, m_trailerType.c_str() ) != 0)
        {
            char trailerType[ 16 ];
            strcpy( trailerType, m_trailerType.c_str() );
            char* wtrailer = format_receipt( trailerType );
            strcpy( trailer, wtrailer );

        sprintf( debugMessage, "trailerType[%s]trailer[%s]\n", trailerType, trailer );
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, debugMessage );

        }

        if( (wlayout = get_layout( type_key)) == NULL )
        {   //printf("\n\nLINE: %d\n\n",__LINE__);
//            if ( token != NULL )
//            {
                //printf("\n\nLINE: %d\n\n",__LINE__);
                //printf("TrxCupom::format_receipt Receipt layout not defined for m%04d/p%06d/v%02d, key=[%s]\n",
                //       ecr_msgtype, ecr_pcode, serial, type_key);
//            }

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "get_layout-NULL" );

            return( NULL);
        }

        memset( receipt, 0, sizeof(receipt));

        wlayout_saved = wlayout;

        g_promo_LinesCount = 0;

        memset( last_wtoken, 0x00, sizeof(last_wtoken) );

        while( (wtoken = get_token(&wlayout, &outstrlen)) != NULL)
        {
            //printf("\n\n wtoken: %s\n\n",wtoken);
            /*if ( !strcmp( last_wtoken, "TKN_PROMO_LINE" ) && !actuallen )
            {
                wreceipt--;
                while ( *wreceipt == ' ' && *wreceipt ) wreceipt--;
            }

            if ( !strcmp( last_wtoken, "TKN_PREMI_INST" ) && !(*prm_msg) )
            {
                wreceipt--;
                while (*wreceipt == ' ') wreceipt--;
            }*/

            /* ID_204709 - RELEASE BANDEIRAS - R4_2017 - CUPOM PDV - INICIO */
            if ( !strcmp( last_wtoken, "TKN_APP_ID" ) && !actuallen )
            {
            	/* Caso linha do AID retorne nula, entao o cupon deve desconsiderar o TOKEN */
                wreceipt--;
                while ( *wreceipt == ' ' )
                {
                    wreceipt--;
                }
            }
            /* ID_204709 - RELEASE BANDEIRAS - R4_2017 - CUPOM PDV - FIM */

            if ( !strcmp( last_wtoken, "TKN_VCHR_BALANCE" ) && !actuallen )
            {
                wreceipt--;
                while ( *wreceipt == ' ' )
                {
                    wreceipt--;
                }
                wreceipt++;
            }

            memcpy(wreceipt, wlayout_saved, (wlayout - wlayout_saved));

            wreceipt += wlayout - wlayout_saved;

            if( (actuallen = replace_token_on_receipt( wtoken, wreceipt, outstrlen )) < 0)
            {
                  logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "replace_token_on_receipt<0" );
                //printf("\n\nLINE: %d\n\n",__LINE__);
                /*
                printf("TrxCupom::format_receipt Error formatting receipt for m%04d/p%06d/v%02d\n",
                        ecr_msgtype, ecr_pcode, serial);
                */
                return( NULL);
            }

            wreceipt += actuallen;

            wlayout += outstrlen;

            wlayout_saved = wlayout;
            //printf("\n\n last_wtoken: %s\n\n",last_wtoken);
            strcpy( last_wtoken, wtoken->name );
        }

        strcpy( wreceipt, wlayout_saved);

        if( !strlen(receipt))
        {
              logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "receipt_no_strlen" );
            return( NULL);
        }
        else
        {
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "receipt_with_strlen" );
            m_receipt = receipt;
            return( receipt);
        }
    }

    int TrxCupom::replace_token_on_receipt( struct _token *wtoken, char *wreceipt, int outstrlen )
    {
        int  i;
        int  j;
        int  k;
        int  cd_ems;
        int transcode;
        unsigned long bin;
        char outstr[ 800 ];
        char wrkstr[ 800 ];
        char fmtstr[ 80 ];
        int  type;
        char pszBill[ 51 ];
        long card_exp_date;
        char tipo_iof[ 20 ];
        char buff[ 500 ];
        std::string s_aux;
        std::string localMessageName = ""; // Padronizacao Crediario PDV - INICIO
        std::string localInformationCrediario = ""; // Padronizacao Crediario PDV - INICIO
        std::string localComplementoCrediario = ""; // Padronizacao Crediario PDV - INICIO
        bool l_isVoid = false;
            
        // Padronizacao Crediario PDV - INICIO
        fieldSet::fsextr( localMessageName, messageName );
        fieldSet::fsextr( localInformationCrediario, informationCrediario );
        fieldSet::fsextr( localComplementoCrediario, complementoCrediario );
        // Padronizacao Crediario PDV - FIM

        fieldSet::fsextr( s_aux, m_versao_aplicativo );
        int versionNum = atoi( s_aux.c_str() );

        fieldSet::fsextr( cd_ems, m_cd_ems );

        fieldSet::fsextr( transcode, m_transcode );

        fieldSet::fsextr( bin, m_bin );
        
        s_aux.clear();
        fieldSet::fsextr( s_aux, m_isVoid );

        if( !s_aux.empty() )
        {
            l_isVoid =  (s_aux == "TRUE" )? true:false;
        }			

        //Adjust the output string len if necessary.
        if ( wtoken->len == 'v' || wtoken->len == 'V' )
        {
            outstrlen = sizeof( outstr );
        }
        else if ( wtoken->len != '*' && (int) wtoken->len < outstrlen )
        {
            outstrlen = (int) wtoken->len;
        }

        //Init the output string.
        if ( wtoken->left_zero != 'Z' )
        {
            memset( outstr, ' ', outstrlen );
        }
        else
        {
            memset( outstr, '0', outstrlen );
        }
        outstr[ outstrlen ] = '\0';

        //char buffer[100];
        //sprintf(buffer,"replace_token_on_receipt: wtoken->name=[%s]",wtoken->name);
        //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, buffer );

        //============================================================================================
        // Replace the token by its corresponding value
        //============================================================================================
        if      ( !strcmp( wtoken->name, "TKN_PRODUCT" ) )
        {
            //Product flag.
			
            if ( strlen( textoApplicationLabel ) != 0 )
            {	
				
				/* J06_2020 - NOVO DEBITO MASTERCARD - CUPOM PDV TRATAMENTO APPLICATION LABEL PARA MASTERCARD DEBITO - INICIO*/
				if ( cd_ems != 18 )
					strncpy( outstr, textoApplicationLabel, strlen( textoApplicationLabel ) );
				else					
					strncpy( outstr, "MASTERCARD DEBITO", strlen( "MASTERCARD DEBITO" ) );
				/* J06_2020 - NOVO DEBITO MASTERCARD - CUPOM PDV TRATAMENTO APPLICATION LABEL PARA MASTERCARD DEBITO - FIM*/			

            }
            else if ( ecr_pcode == 90000 )
            {
                strncpy( outstr, "COMPRE&SAQUE", strlen( "COMPRE&SAQUE" ) );
            }
            else if ( ecr_pcode == 170000 )
            {
                strncpy( outstr, "PARCELE MAIS", strlen( "PARCELE MAIS" ) );
            }
            else if ( transcode == 91 || transcode == 92 || transcode == 93 )
            {
                strncpy( outstr, "CELULAR", strlen( "CELULAR" ) );
            }
            else if ( cd_ems == 1 || cd_ems == 2 || cd_ems == 7 )
            {
                strncpy( outstr, "MASTERCARD", strlen( "MASTERCARD" ) );
            }
            else if ( cd_ems == 18 )
            {
                strncpy( outstr, "MASTERCARD DEBITO", strlen( "MASTERCARD DEBITO" ) );
            }
            else if ( cd_ems == 3 )
            {
                strncpy( outstr, "REDESHOP", strlen( "REDESHOP" ) );
            }
            else if ( cd_ems == 4 || cd_ems == 6 || cd_ems == 8 )
            {
                strncpy( outstr, "DINERS CLUB", strlen( "DINERS CLUB" ) );
            }
            else if ( cd_ems == 22 )
            {
                strncpy( outstr, "LOCAL CARD", strlen( "LOCAL CARD" ) );
            }
            else if ( cd_ems == 24 ) //&& transcode == 67 - BT56257
            {
                strncpy( outstr, "VOUCHER", strlen( "VOUCHER" ) );
            }
            else if ( cd_ems == 48 )
            {
                strncpy( outstr, "VISA", strlen( "VISA" ) );
            }
            else if ( cd_ems == 49 )
            {
                strncpy( outstr, "VISA ELECTRON", strlen( "VISA ELECTRON" ) );
            }
            else if ( cd_ems == 50 )
            {
                strncpy( outstr, "CABAL DEBITO", strlen( "CABAL DEBITO" ) );
            }
            else if ( cd_ems == 62 )
            {
                strncpy( outstr, "COOPERCARD CREDITO", strlen( "COOPERCARD CREDITO" ) );
            }
            else if ( cd_ems == 63 )
            {
                strncpy( outstr, "CUP CREDITO", strlen( "CUP CREDITO" ) );
            }
            else if ( cd_ems == 47 )
            {
                if (bin == 606282 )
                strncpy( outstr, "HIPERCARD", strlen( "HIPERCARD" ) );
                else
                	strncpy( outstr, "HIPER", strlen( "HIPER" ) );
            }
            else if ( cd_ems == 51 )
            {
                strncpy( outstr, "CABAL CREDITO", strlen( "CABAL CREDITO" ) );
            }
            else if ( cd_ems == 53 || cd_ems == 61 )
            {
                strncpy( outstr, "SOROCRED", strlen( "SOROCRED" ) );
            }
            else if ( cd_ems == 64 )
            {
                strncpy( outstr, "SICREDI CREDITO", strlen( "SICREDI CREDITO" ) );
            }
            else if ( cd_ems == 65 )
            {
                strncpy( outstr, "SICREDI DEBITO", strlen( "SICREDI DEBITO" ) );
            }
            else if ( cd_ems == 66 )
            {
                strncpy( outstr, "CALCARD CREDITO", strlen( "CALCARD CREDITO" ) );
            }
            else if ( cd_ems == 67 )
            {
                strncpy( outstr, "AVISTA CREDITO", strlen( "AVISTA CREDITO" ) );
            }
            else if ( cd_ems == 68 )
            {
                strncpy( outstr, "CREDSYSTEM", strlen( "CREDSYSTEM" ) );
            }
            else if ( cd_ems == 84 )
            {
                strncpy( outstr, "HIPER", strlen( "HIPER" ) );
            }
            else if ( cd_ems == 91 )
            {
                strncpy( outstr, "BANESCARD CREDITO", strlen( "BANESCARD CREDITO" ) );
            }
            else if ( cd_ems == 92 )
            {
                strncpy( outstr, "BANESCARD DEBITO", strlen( "BANESCARD DEBITO" ) );
            }
            else if ( cd_ems == 93 )
            {
                strncpy( outstr, "JCB CREDITO", strlen( "JCB CREDITO" ) );
            }
            else if ( cd_ems == 94 )
            {
                strncpy( outstr, "CREDZ CREDITO", strlen( "CREDZ CREDITO" ) );
            }
            else if ( cd_ems == 95 )
            {
                strncpy( outstr, "AMEX CREDITO", strlen( "AMEX CREDITO" ) );
            }
            else if ( cd_ems == 96 ) //credito ELO Full
            {
                strncpy( outstr, "ELO CREDITO", strlen( "ELO CREDITO" ) );
            }
            else if ( cd_ems == 97) //debito ELO Full
            {
                strncpy( outstr, "ELO DEBITO", strlen( "ELO DEBITO" ) );
            }
            // AUT2-2816 - REDECOMPRAS HUB DE BANDEIRAS - INICIO
            else if ( cd_ems == 98 )
            {
                strncpy( outstr, "AVANCARD CREDITO", strlen( "AVANCARD CREDITO" ) );
            }
            else if ( cd_ems == 99 )
            {
                strncpy( outstr, "AVANCARD DEBITO", strlen( "AVANCARD DEBITO" ) );
            }
            else if ( cd_ems == 102 )
            {
                strncpy( outstr, "BIGCARD CREDITO", strlen( "BIGCARD CREDITO" ) );
            }
            else if ( cd_ems == 103 )
            {
                strncpy( outstr, "BIGCARD DEBITO", strlen( "BIGCARD DEBITO" ) );
            }
            else if ( cd_ems == 104 )
            {
                strncpy( outstr, "BONUSCRED CREDITO", strlen( "BONUSCRED CREDITO" ) );
            }
            else if ( cd_ems == 105 )
            {
                strncpy( outstr, "CDC CARD CREDITO", strlen( "CDC CARD CREDITO" ) );
            }
            else if ( cd_ems == 106 )
            {
                strncpy( outstr, "CDC CARD DEBITO", strlen( "CDC CARD DEBITO" ) );
            }
            else if ( cd_ems == 107 )
            {
                strncpy( outstr, "COMPROCARD CREDITO", strlen( "COMPROCARD CREDITO" ) );
            }
            else if ( cd_ems == 110 )
            {
                strncpy( outstr, "CONVENIOS CARD CREDITO", strlen( "CONVENIOS CARD CREDITO" ) );
            }
            else if ( cd_ems == 111 )
            {
                strncpy( outstr, "DIAMANTE CARD CREDITO", strlen( "DIAMANTE CARD CREDITO" ) );
            }
            else if ( cd_ems == 112 )
            {
                strncpy( outstr, "EUCARD CREDITO", strlen( "EUCARD CREDITO" ) );
            }
            else if ( cd_ems == 113 )
            {
                strncpy( outstr, "EUCARD DEBITO", strlen( "EUCARD DEBITO" ) );
            }
            else if ( cd_ems == 114 )
            {
                strncpy( outstr, "FORTBRASIL CREDITO", strlen( "FORTBRASIL CREDITO" ) );
            }
            else if ( cd_ems == 115 )
            {
                strncpy( outstr, "FORTCARD CREDITO", strlen( "FORTCARD CREDITO" ) );
            }
            else if ( cd_ems == 116 )
            {
                strncpy( outstr, "GOIAS CARD CREDITO", strlen( "GOIAS CARD CREDITO" ) );
            }
            else if ( cd_ems == 117 )
            {
                strncpy( outstr, "GOODCARD CREDITO", strlen( "GOODCARD CREDITO" ) );
            }
            else if ( cd_ems == 118 )
            {
                strncpy( outstr, "CARD IDEAL CREDITO", strlen( "CARD IDEAL CREDITO" ) );
            }
            else if ( cd_ems == 119 )
            {
                strncpy( outstr, "CARD IDEAL DEBITO", strlen( "CARD IDEAL DEBITO" ) );
            }
            else if ( cd_ems == 120 )
            {
                strncpy( outstr, "CREDPAR CREDITO", strlen( "CREDPAR CREDITO" ) );
            }
            else if ( cd_ems == 121 )
            {
                strncpy( outstr, "LIBERCARD CREDITO", strlen( "LIBERCARD CREDITO" ) );
            }
            else if ( cd_ems == 122 )
            {
                strncpy( outstr, "LIBERCARD DEBITO", strlen( "LIBERCARD DEBITO" ) );
            }
            else if ( cd_ems == 123 )
            {
                strncpy( outstr, "MAXXCARD CREDITO", strlen( "MAXXCARD CREDITO" ) );
            }
            else if ( cd_ems == 124 )
            {
                strncpy( outstr, "MAXXCARD DEBITO", strlen( "MAXXCARD DEBITO" ) );
            }
            else if ( cd_ems == 125 )
            {
                strncpy( outstr, "MEGAVALE CARD CREDITO", strlen( "MEGAVALE CARD CREDITO" ) );
            }
            else if ( cd_ems == 126 )
            {
                strncpy( outstr, "MEGAVALE CARD DEBITO", strlen( "MEGAVALE CARD DEBITO" ) );
            }
            else if ( cd_ems == 127 )
            {
                strncpy( outstr, "EOVALE CREDITO", strlen( "EOVALE CREDITO" ) );
            }
            else if ( cd_ems == 128 )
            {
                strncpy( outstr, "EOVALE DEBITO", strlen( "EOVALE DEBITO" ) );
            }
            else if ( cd_ems == 131 )
            {
                strncpy( outstr, "ONECARD CREDITO", strlen( "ONECARD CREDITO" ) );
            }
            else if ( cd_ems == 132 )
            {
                strncpy( outstr, "PERSONAL CARD CREDITO", strlen( "PERSONAL CARD CREDITO" ) );
            }
            else if ( cd_ems == 133 )
            {
                strncpy( outstr, "PERSONAL CARD DEBITO", strlen( "PERSONAL CARD DEBITO" ) );
            }
            else if ( cd_ems == 134 )
            {
                strncpy( outstr, "ROMCARD CREDITO", strlen( "ROMCARD CREDITO" ) );
            }
            else if ( cd_ems == 135 )
            {
                strncpy( outstr, "ROMCARD DEBITO", strlen( "ROMCARD DEBITO" ) );
            }
            else if ( cd_ems == 138 )
            {
                strncpy( outstr, "SENFF CREDITO", strlen( "SENFF CREDITO" ) );
            }
            else if ( cd_ems == 139 )
            {
                strncpy( outstr, "SINCARD CREDITO", strlen( "SINCARD CREDITO" ) );
            }
            else if ( cd_ems == 140 )
            {
                strncpy( outstr, "SINCARD DEBITO", strlen( "SINCARD DEBITO" ) );
            }
            else if ( cd_ems == 141 )
            {
                strncpy( outstr, "SIND CREDITO", strlen( "SIND CREDITO" ) );
            }
            else if ( cd_ems == 142 )
            {
                strncpy( outstr, "SMCCARD CREDITO", strlen( "SMCCARD CREDITO" ) );
            }
            else if ( cd_ems == 145 )
            {
                strncpy( outstr, "SYSTEM FARMA CREDITO", strlen( "SYSTEM FARMA CREDITO" ) );
            }
            else if ( cd_ems == 146 )
            {
                strncpy( outstr, "TER CRED CREDITO", strlen( "TER CRED CREDITO" ) );
            }
            else if ( cd_ems == 147 )
            {
                strncpy( outstr, "VEGAS CARD CREDITO", strlen( "VEGAS CARD CREDITO" ) );
            }
            else if ( cd_ems == 148 )
            {
                strncpy( outstr, "VERANCARD CREDITO", strlen( "VERANCARD CREDITO" ) );
            }
            else if ( cd_ems == 149 )
            {
                strncpy( outstr, "VERANCARD DEBITO", strlen( "VERANCARD DEBITO" ) );
            }
            else if ( cd_ems == 150 )
            {
                strncpy( outstr, "VERDECARD CREDITO", strlen( "VERDECARD CREDITO" ) );
            }
            else if ( cd_ems == 151 )
            {
                strncpy( outstr, "VERDECARD DEBITO", strlen( "VERDECARD DEBITO" ) );
            }
            else if ( cd_ems == 152 )
            {
                strncpy( outstr, "VOLUS CREDITO", strlen( "VOLUS CREDITO" ) );
            }
            // AUT2-2816 - REDECOMPRAS HUB DE BANDEIRAS - FIM
            else if ( m_cvForPrivateLabel )
            {				
                strncpy( outstr, "PRIVATE LABEL", strlen( "PRIVATE LABEL" ) );
            }
            else
            {				
                strncpy( outstr, "-BANDEIRA-", strlen( "-BANDEIRA-" ) );
            }

            //Need to complement other flags herein when implementing more.
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_TYPE" ) )
        {      
            if ( l_isVoid )
            {
                if ( pay_code == 30 )
                {
                    if( cd_ems == 19 )
                    {
                        strncpy( outstr, "ESTORNO VENDA FININVEST", strlen( "ESTORNO VENDA FININVEST" ) );
                    }
                    else if ( cd_ems == 30 )
                    {
                        strncpy( outstr, "ESTORNO VENDA VISION PLUS", strlen( "ESTORNO VENDA VISION PLUS" ) );
                    }
                    else if ( cd_ems == 32 )
                    {
                        strncpy( outstr, "ESTORNO VENDA TAII", strlen( "ESTORNO VENDA TAII" ) );
                    }
                    else
                    {
                        strncpy( outstr, "ESTORNO VENDA PRIVATE LABEL", strlen( "ESTORNO VENDA PRIVATE LABEL" ) );
                    }
                }
                else if ( pay_code == 40 )
                {
                    strncpy( outstr, "ESTORNO SAQUE/EMPRESTIMO", strlen( "ESTORNO SAQUE/EMPRESTIMO" ) );
                }
                else
                {
                    strncpy( outstr, "ESTORNO VENDA", strlen( "ESTORNO VENDA" ) );
                }
            }
            else
            {
                //Purchase or cash - install - inquiry
                int txntype = convert_in_tpo_vda( transcode );
                if ( txntype == 0 )
                {
                    txntype = plabel_in_tpo_vda( transcode );
                }
                //Inquiry.
                if ( transcode == 75 )
                {
                    if ( pay_code == 31 )
                    {
                        if ( txntype == 1 )
                        {
                            strncpy( outstr, "CONSULTA VENDA", strlen( "CONSULTA VENDA" ) );
                        }
                        else if ( txntype == 2 )
                        {
                            strncpy( outstr, "CONSULTA VENDA FINANCIADA", strlen( "CONSULTA VENDA FINANCIADA" ) );
                        }
                        else if ( txntype == 3 )
                        {
                            strncpy( outstr, "CONSULTA VENDA PREDATADA", strlen( "CONSULTA VENDA PREDATADA" ) );
                        }
                        else if ( txntype == 4 )
                        {
                            strncpy( outstr, "CONSULTA VENDA FINANCIADA PREDATADA", strlen( "CONSULTA VENDA FINANCIADA PREDATADA" ) );
                        }
                        else
                        {
                            strncpy( outstr, "CONSULTA VENDA", strlen( "CONSULTA VENDA" ) );
                        }
                    }
                    else if ( pay_code == 41 )
                    {
                        if ( txntype == 1 )
                        {
                            strncpy( outstr, "CONSULTA SAQUE/EMPRESTIMO", strlen( "CONSULTA SAQUE/EMPRESTIMO" ) );
                        }
                        else if ( txntype == 2 )
                        {
                            strncpy( outstr, "CONSULTA SAQUE/EMPRESTIMO FINANCIADO", strlen( "CONSULTA SAQUE/EMPRESTIMO FINANCIADO" ) );
                        }
                        else
                        {
                            strncpy( outstr, "CONSULTA SAQUE", strlen( "CONSULTA SAQUE" ) );
                        }
                    }
                }
                else if ( transcode == 74 )
                {
                    if ( pay_code == 30 )
                    {
                        if ( txntype == 1 )
                        {
                            strncpy( outstr, "VENDA", strlen( "VENDA" ) );
                        }
                        else if ( txntype == 2 )
                        {
                            strncpy( outstr, "VENDA FINANCIADA", strlen( "VENDA FINANCIADA" ) );
                        }
                        else if ( txntype == 3 )
                        {
                            strncpy( outstr, "VENDA PREDATADA", strlen( "VENDA PREDATADA" ) );
                        }
                        else if ( txntype == 4 )
                        {
                            strncpy( outstr, "VENDA FINANCIADA PREDATADA", strlen(" VENDA FINANCIADA PREDATADA" ) );							
                        }
                        else
                        {
                            strncpy( outstr, "VENDA", strlen( "VENDA" ) );
                        }
                    }
                    else if ( pay_code == 40 )
                    {
                        if ( txntype == 1 )
                        {
                            strncpy( outstr, "SAQUE/EMPRESTIMO", strlen( "SAQUE/EMPRESTIMO" ) );
                        }
                        else if ( txntype == 2 )
                        {
                            strncpy( outstr, "SAQUE/EMPRESTIMO FINANCIADO", strlen( "SAQUE/EMPRESTIMO FINANCIADO" ) );
                        }
                        else
                        {
                            strncpy( outstr, "SAQUE", strlen( "SAQUE" ) );
                        }
                    }
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_CET_ANO" ) )
        {
            //Cet anual PCJ-CDC
            char* dot;
            int n;

            // Padronizacao Crediario PDV - INICIO
            if ( localMessageName.compare("CREDIARIO_VENDA") == 0 )
            {
                char debugMessage[1024] = {0};
                char valor[20] = {0};
                double cetAnualDouble = 0.0;
                
                memset(valor, 0, sizeof(valor));
                // swadd_resp.cred_redecard[0].cet_anual
                strncpy(valor, localInformationCrediario.substr(7, 6).c_str(), 6);
                // swadd_resp.complementoCrediario[0].cetAnualCrediario
                strncat(valor, localComplementoCrediario.substr(2, 6).c_str(), 6);
                
                sscanf(valor, "%12lf", &cetAnualDouble);
                cetAnualDouble /= 100;
                sprintf(debugMessage, " Valor do CET do Crediario [%s] [%f]", valor, cetAnualDouble);
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, debugMessage );

                sprintf( fmtstr, "%%%d.%df", outstrlen, 2 );
                sprintf( outstr, fmtstr, cetAnualDouble );

                if ( dot = strchr( outstr, '.' ) )
                {
                    *dot = ',';
                }
            }
            // Padronizacao Crediario PDV - FIM
            else if ( cet_anual > 0 )
            {
                n = snprintf( outstr, outstrlen, "CET ANUAL: %.3f", cet_anual );
                if ( dot = strchr( outstr, '.' ) )
                {
                    *dot = ',';
                }

                //snprintf always put a '\0' - overwrite it.
                *( outstr + n ) = '%';
            }
            else
            {
                return( 0 );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_GROUP_VOUCHER" ) )
        {
            //Voucher group flag.
            strncpy( outstr, voucher_group_name, strlen( voucher_group_name ) );
        }
        else if ( !strcmp( wtoken->name, "TKN_VOUCHER_FOOTER" ) )
        {
            if ( strlen( voucher_footer ) )
            {
                strncpy( outstr, voucher_footer, strlen( voucher_footer ) );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_REFNUM" ) )
        {
            //Reference number.
            for ( i=0; !isdigit( refnum[ i ] ) && i <= SHC_REFNUM_LEN; i++ );
            for ( ; isdigit( refnum[ i ] ) && i <= SHC_REFNUM_LEN; i++ );
            for ( --i, j = outstrlen - 1; i >= 0 && j >= 0 && isdigit( refnum[ i ] ); i--, j-- )
            {
                outstr[ j ] = refnum[ i ];
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_ORIGREFNUM" ) )
        {
            //Original reference number.
            for ( i = 0; !isdigit( origrefnum[ i ] ) && i <= SHC_REFNUM_LEN; i++ );
            for ( ; isdigit( origrefnum[ i ] ) && i <= SHC_REFNUM_LEN; i++ );
            for ( --i, j = outstrlen - 1; i >= 0 && j >= 0 && isdigit( origrefnum[ i ] ); i--, j-- )
            {
                outstr[ j ] = origrefnum[ i ];
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TOT_AMOUNT" ) )
        {
            //Total amount.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &amount8 ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_AMOUNT" ) )
        {
            //Transaction amount.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            //P236.
            if ( ( dbm_dectodbl( &amount ) > dbm_dectodbl( &amount2 ) ) &&
                ( dbm_dectodbl(&amount2 ) > 0.00 ) )
            {
                sprintf( outstr, fmtstr, dbm_dectodbl( &amount2 ) );
            }
            else
            {
                sprintf( outstr, fmtstr,dbm_dectodbl( &amount ) );
            }

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_MRATE" ) )
        {
            //Monthly interest rate.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &fee ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_INSTAMOUNT" ) )
        {
            //Estimated installment amount.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &vl_pca_ent ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_INSTDATE" ) )
        {
            //First Inst. Date.
            int dd;
            int mm;
            int yy;
            if ( settlement_date == 0 )
            {
                settlement_date = local_date;
            }
            dd = ( settlement_date % 100 );
            mm = ( settlement_date % 10000 ) / 100;
            yy = ( settlement_date / 10000 ) % 100;
            sprintf( outstr, "%02u%c%02u%c%02u", dd, wtoken->separator, mm, wtoken->separator, yy );
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_NINSTALL" ) )
        {
            //Number of Instal.
            if ( wtoken->left_zero != 'Z' )
            {
                sprintf( fmtstr, "%%%dd", outstrlen );
            }
            else
            {
                sprintf( fmtstr, "%%0%dd", outstrlen );
            }
            sprintf( outstr, fmtstr, install_num );
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_TARIFA" ) )
        {
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, atof( valor_tarifa ) / 100 );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_TRIBUTOS") )
        {
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, atof( valor_tributos ) / 100 );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr,"." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_SEGUROS" ) )
        {
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, atof( valor_seguro ) / 100 );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_OUTROS" ) )
        {
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, atof( valor_pag_terceiros ) / 100 );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_VLSAQUE" ) )
        {
            //Total amount of transaction.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &cash_back ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_VLCOMPRA" ) )
        {
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, ( dbm_dectodbl( &amount ) - dbm_dectodbl( &cash_back ) ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_INSTLL_NUM" ) )
        {
            //Installment number.
            if ( wtoken->left_zero != 'Z' )
            {
                sprintf( fmtstr, "%%%dd", outstrlen );
            }
            else
            {
                sprintf( fmtstr, "%%0%dd", outstrlen );
            }
            sprintf( outstr, fmtstr, install_num );
        }
        else if ( !strcmp( wtoken->name, "TKN_INSTLL_AMNT" ) )
        {
            //Installment amount.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &install_amt) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_INSTLL_MINTE" ) )
        {
            //Install monthly interest.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &fee ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_INSTLL_TAMNT" ) )
        {
            //Install total amount.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &actual_amount ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_MERCHANT" ) )
        {
            //Merchant code.
            for( i = 0; !isdigit( termloc[ i ] ) && i <= SHC_TERMLOC_LEN; i++ );
            for( ; isdigit( termloc[ i ] ) && i <= SHC_TERMLOC_LEN; i++ );
            for( --i, j = outstrlen - 1; i >= 0 && j >= 0 && isdigit( termloc[ i ] ); i--, j-- )
            {
                outstr[ j ] = termloc[ i ];
            }
			// Fazendo com que sempre tenha zeros Ã  esquerda, pra completar 9 digitos (igual cupom do 71)
			sprintf( outstr, "%09d", atoi(outstr) );
        }
        else if ( !strcmp( wtoken->name, "TKN_MERCHANT_NAME" ) )
        {
            //Merchant name.
            if ( outstrlen > strlen( mer_name ) )
            {
                i = strlen( mer_name );
            }
            else
            {
                i = outstrlen;
            }
            strncpy( outstr, mer_name, i );
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_DATE" ) )
        {
            //Txn local date for pre-authorization.
            if ( transcode == 68 ||
                transcode == 69 ||
                transcode == 80 ||
                transcode == 81 )
            {
                //sprintf( wrkstr, "%d", shc_local_currentdate( ) );
                time_t unix_local_current_date;
                unix_local_current_date = time( NULL );
                sprintf( wrkstr, "%d", (long) unix_local_current_date );
            }
            else
            {
                sprintf( wrkstr, "%d", local_date );
            }

            //Notice: expected to have yyyymmdd.
            if ( outstrlen >= 8 )
            {
                //Extract dd.mm. and yy or yyyy.
                strncpy( outstr, wrkstr + 6, 2 );
                outstr[ 2 ] = wtoken->separator;
                strncpy( outstr + 3, wrkstr + 4, 2 );
                outstr[ 5 ] = wtoken->separator;
                if ( outstrlen < 10 )
                {
                    strncpy( outstr + 6, wrkstr + 2, 2 );
                }
                else
                {
                    strncpy( outstr + 6, wrkstr, 4 );
                }
            }
            else
            {
                //Extract ddmmyy.
                strncpy( outstr, wrkstr + 6, 2 );
                strncpy( outstr + 2, wrkstr + 4, 2 );
                strncpy( outstr + 4, wrkstr + 2, 2 );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TXN_TIME" ) )
        {
            //Txn local time.
            sprintf( wrkstr, "%06d",( local_time % 1000000 ) );
            //Notice: expected to have hhmmss.
            if ( outstrlen >= 8 )
            {
                //Extract hh.mm.ss.
                strncpy( outstr, wrkstr, 2 );
                outstr[ 2 ] = wtoken->separator;
                strncpy( outstr + 3, wrkstr + 2, 2 );
                outstr[ 5 ] = wtoken->separator;
                strncpy( outstr + 6, wrkstr + 4, 2 );
            }
            else
            {
                //Extract hhmmss;
                strncpy( outstr, wrkstr, 6 );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_BT_DATE" ) )
        {
            //Notice: expected to have ddmmaa. data_baixa
            if ( outstrlen >= 8 )
            {
                //Extract dd.mm. and yy or yyyy.
                strncpy( outstr, data_baixa, 2 );
                outstr[ 2 ] = wtoken->separator;
                strncpy( outstr + 3, data_baixa + 2, 2 );
                outstr[ 5 ] = wtoken->separator;
                if ( outstrlen < 10 )
                {
                    strncpy( outstr + 6, data_baixa + 4, 2 );
                }
                else
                {
                    strncpy( outstr + 6, data_baixa + 4, 4 );
                }
            }
            else
            {
                //Extract ddmmyy.
                strncpy( outstr, data_baixa, 6 );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_BT_TIME" ) )
        {
            //Txn LOCAL.hora_baixa - hora_baixa

            //Notice: expected to have hhmm
            if ( outstrlen >= 5 )
            {
                //Extract hh.mm.
                strncpy( outstr, hora_baixa, 2 );
                outstr[ 2 ] = wtoken->separator;
                strncpy( outstr + 3, hora_baixa + 2, 2 );
            }
            else
            {
                //Extract hhmm;
                strncpy( outstr, hora_baixa, 4 );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TERMID" ) )
        {
            //Terminal id.
            sprintf( wrkstr, "%s", termid );
            if ( strlen( wrkstr ) > outstrlen )
            {
                wrkstr[ outstrlen ] = '\0';
            }
            strncpy( outstr, wrkstr, strlen( wrkstr ) );
        }
        else if ( !strcmp( wtoken->name, "TKN_STAN" ) )
        {
            //Stan - Bit 11.
            if ( wtoken->left_zero != 'Z' )
            {
                sprintf( fmtstr, "%%%dd", outstrlen );
            }
            else
            {
                sprintf( fmtstr, "%%0%dd", outstrlen );
            }
            sprintf( outstr, fmtstr, trace );
        }
        else if ( !strcmp( wtoken->name, "TKN_PAN" ) )
        {
		for( int cnt = 0 ; cnt < strlen( orig_pan ) - 4 ; cnt++ )
		{
			orig_pan[cnt] = 'x';
		}

            //Cardholder pan - Whatever specified in separator field, MASTERCARD has output with groups 4,4,4,4 digits.
            if ( ( ( isdigit( orig_pan[ 0 ]) || orig_pan[ 0 ]=='x' ) &&
                ( cd_ems == 1 || cd_ems == 2 || cd_ems == 7 ) ) ||
                ( isdigit( orig_pan[ 0 ] ) && m_cvForPrivateLabel ) )
            {
                for ( i = 0, j = 0, k = 0; i < outstrlen && k < strlen( orig_pan ); i++, j++, k++ )
                {
                    if ( i && !( i % 4 ) && orig_pan[ i ] != ' ' )
                    {
                        outstr[ j++ ] = '.';
                    }
                    outstr[ j ] = orig_pan[ i ];
                }
            }
            //DINERS has output with groups of 4,6,4 digits.
            else if ( ( isdigit( orig_pan[ 0 ]) || orig_pan[ 0 ]=='x' ) &&
                    ( cd_ems == 4 || cd_ems == 6 || cd_ems == 8 ) )
            {
                strncpy( outstr, orig_pan, 4 );
                outstr[ 4 ] = '.';
                strncpy( outstr + 5, orig_pan + 4, 6 );
                if ( strlen( orig_pan ) > 10 )
                {
                    outstr[ 11 ] = '.';
                    strncpy( outstr + 12, orig_pan + 10, strlen( orig_pan ) - 10 );
                }
            }
            else
            {
                strncpy( outstr, orig_pan,
                    ( ( outstrlen < strlen( orig_pan ) ) ? outstrlen : strlen( orig_pan ) ) );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TIPO_CAP" ) )
        {
            if ( strcmp( textoIsFallback, "TRUE" ) == 0 )
            {
                outstr[ 0 ] = 'F';
            }
            else if ( strcmp( textoIsContactless, "TRUE" ) == 0 )
            {
                outstr[ 0 ] = 'L';
            }
            else if ( strcmp( textoNomeModoEntrada, "CHIP" ) == 0 )
            {
                outstr[ 0 ] = 'C';
                
                // Release Bandeiras PDV - Abril 2019 - INICIO
                string indicador = "";
                fsextr( indicador, indicadorModoEntrada );
                if ( indicador.compare("1") == 0 )
                {
                    outstr[ 0 ] = 'l';
                }
                // Release Bandeiras PDV - Abril 2019 - FIM
            }
            else if ( strcmp( textoNomeModoEntrada, "MAG" ) == 0 )
            {
                outstr[ 0 ] = 'T';
            }
            else if ( strcmp( textoNomeModoEntrada, "DIG" ) == 0 )
            {
                outstr[ 0 ] = 'D';
            }
            else
            {
                outstr[ 0 ] = ' ';
            }
            outstr[ 1 ] = '\0';
        }
        else if ( !strcmp( wtoken->name, "TKN_VDDCAR" ) )
        {
            if ( *track3 )
            {
                card_exp_date = get_exp_date_track3( track3 ) * 100;
                if ( debugFlag )
                {
                    syslg( "Data de validade extraida do Track3\n" );
                }
            }
            else
            {
                //Get YYMM00 or 0.
                card_exp_date = get_exp_date( track2 ) * 100;

                if ( debugFlag )
                {
                    syslg( "Data de validade extraida do Track2\n" );
                }
            }

            memset( outstr, '\0', sizeof( outstr ) );
            sprintf( outstr, "%02d/%02d", MM( card_exp_date ), YY( card_exp_date) );
        }
        else if ( !strcmp( wtoken->name, "TKN_AUTHNUM" ) )
        {
            //Authorization number.
            for ( i = 0; authnum[ i ] == ' ' && i <= SHC_AUTHNUM_LEN; i++ );
            for ( ; authnum[ i ] != ' ' && authnum[ i ] != '\0' && i <= SHC_AUTHNUM_LEN; i++ );
            for ( --i, j = outstrlen - 1; i >= 0 && j >= 0 &&
                authnum[ i ] != ' ' && authnum[ i ] != '\0'; i--, j-- )
            {
                outstr[ j ] = authnum[ i ];
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_ISSAUTHNUM" ) )
        { 
            // Copiando todos os digitos do authnum
            strncpy(outstr, authnum, MC_AUTHCODE_LEN);
        }
        else if ( !strcmp( wtoken->name, "TKN_CARDHOLDER_NAME" ) ||
                  !strcmp( wtoken->name, "TKN_CNE" ))
        {
            //Cardholder name.
            if ( *cardholder_name )
            {
                if ( outstrlen > strlen( cardholder_name ) )
                {
                    i = strlen( cardholder_name );
                }
                else
                {
                    i = outstrlen;
                }
                strncpy( outstr, cardholder_name, i );
            }
        }/*
        else if ( !strcmp( wtoken->name, "TKN_CNE" ) )
        {
            //Cardholder name extended.
            if ( *cardholder_name )
            {
                if ( outstrlen > strlen( cardholder_name ) )
                {
                    i = strlen( cardholder_name );
                }
                else
                {
                    i = outstrlen;
                }
                strncpy( outstr, cardholder_name, i );
            }
        }*/
        else if ( !strcmp( wtoken->name, "TKN_ISSUER_TEXT" ) )
        {

            char bit63_temp[700];
            char bit63len_temp[10];
            char outstrlen_temp[10];

            sprintf( bit63_temp, "bit63_temp=[%s]\0", bit63 );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, bit63_temp );

            sprintf( bit63len_temp, "bit63len_temp=[%d]\0", bit63len );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, bit63len_temp );

            sprintf( outstrlen_temp, "outstrlen_temp=[%d]\0", outstrlen );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, outstrlen_temp );

            /*

            14.02.10 12:27:17 [acqsrv_pl:4387008]D-ACQbit63_temp=[SUCESSO]
            14.02.10 12:27:17 [acqsrv_pl:4387008]D-ACQbit63len_temp=[28224]
            14.02.10 12:27:17 [acqsrv_pl:4387008]D-ACQoutstrlen_temp=[800] ¤Þà

            */

            bit63len = strlen ( bit63 );


            //Issuer formatted text.
            if ( outstrlen > bit63len )
            {
                outstrlen = bit63len;
            }


            strncpy( outstr, bit63, outstrlen );


            sprintf( bit63_temp, "APOS_bit63_temp=[%s]\0", bit63 );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, bit63_temp );

            sprintf( bit63len_temp, "APOS_bit63len_temp=[%d]\0", bit63len );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, bit63len_temp );

            sprintf( outstrlen_temp, "APOS_outstrlen_temp=[%d]\0", outstrlen );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, outstrlen_temp );

        }
        else if ( !strcmp( wtoken->name, "TKN_PREAUTH_DATE" ) )
        {
            char DEFAULT_DT[] = "00/00/0000";
            //Preauth valid date.
            outstrlen = sprintf( wrkstr, "%08d", dt_vdd_pre_auz );
            
            // dt_vdd_pre_auz has ddmmyyyy format
            if ( outstrlen >= 8)
            {
                // Extracting dd
                strncpy( outstr, wrkstr, 2 );

                // Adding '/'
                outstr[ 2 ] = wtoken->separator;

                // Extracting mm
                strncpy( outstr + 3, wrkstr + 2, 2 ); 

                // Adding '/'
                outstr[ 5 ] = wtoken->separator;

                // Extracting yy (skipping first 2 digits, ex: 2019 -> obtains 19)
                strncpy( outstr + 6, wrkstr + 6, 2 );

                outstrlen = strlen(outstr);
            }
            else
            {
                outstrlen = sizeof(DEFAULT_DT) - 1;
                strncpy( outstr, DEFAULT_DT, outstrlen);
                
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_VCHR_BALANCE" ) )
        {
            //Voucher balance amount.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            //sprintf( outstr, fmtstr, dbm_dectodbl( &saldo_disp ) );
            double saldo;                       
            saldo = dbm_dectodbl( &saldo_disp );
            
            saldo /= 100;
            
            sprintf( outstr, fmtstr, saldo);

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {           
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }

            // Caso seja versao 6.0.0 ou maior, nao deve imprimir o VALOR do saldo, apenas a literal do token "TKN_BALANCE_MSG"
            // O valor do saldo neste caso vai no DE47.tag33
            if (versionNum >= 600)
            {
                outstrlen = 0;
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_TX_SERVICO" ) )
        {
            //Service tax - boarding - IATA.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &vl_txa ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_ENTRADA" ) )
        {
            //Input - IATA.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            sprintf( outstr, fmtstr, dbm_dectodbl( &vl_pca_ent ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_FIRST_INSTLL" ) )
        {
            //Amt first installment.
            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            // EAK-1931 - BRUM - Erro Cupom Transa��es Venda IATA PSJ - INICIO
            double installAmtAux;
            double firstInstall;
            double amountAux;
            double vlTxaAux;
            double vlEntAux;
            char wBuf[26];

            amountAux = dbm_dectodbl(&amount);
            vlTxaAux = dbm_dectodbl(&vl_txa);
            vlEntAux = dbm_dectodbl(&vl_pca_ent);

            amountAux *= 100;
            vlTxaAux *= 100;
            vlEntAux *= 100;

            installAmtAux = ( amountAux - vlEntAux ) / (double)install_num;
            installAmtAux = trunc(installAmtAux);

            firstInstall = ( amountAux - vlEntAux  -
                    (installAmtAux * install_num) +
                    installAmtAux );
            firstInstall = firstInstall + vlEntAux + vlTxaAux;
            sprintf( wBuf, "%.0f", firstInstall);
            dbm_chartodec(&amount9, wBuf, 2);
            installAmtAux /= 100;
            dbm_dbltodec(&install_amt, installAmtAux);
            // EAK-1931 - BRUM - Erro Cupom Transa��es Venda IATA PSJ - INICIO

            sprintf( outstr, fmtstr, dbm_dectodbl( &amount9 ) );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_ARQC" ) )
        {
            //Arqc - Chill full grade.
            char* p;
            for ( p = chip_full_data, i = 0;
                strncmp( chip_full_data, "9F26", 4) && i < chip_full_data_len;
                p++, i++ );

            if ( i < chip_full_data_len )
            {
                p += 4;
                strncpy( wrkstr, p, 2 );
                wrkstr[ 2 ] = '\0';
                i = atoi( wrkstr );
                strncpy( wrkstr, ( p + 2 ), i );
                if ( i > outstrlen )
                {
                    wrkstr[ outstrlen ] = '\0';
                }
                strncpy( outstr, wrkstr, strlen( wrkstr ) );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_NUMBER_SUMM" ) )
        {
            //Number Summary Pratpag.
            strncpy( outstr, filler1, 13 );
        }
        else if ( !strcmp( wtoken->name, "TKN_QTD_MONEY_SUMM" ) )
        {
            //Qtd. Money summary pratipag.
            strncpy( outstr, &filler1[ 13 ], 10 );
        }
        else if ( !strcmp( wtoken->name, "TKN_VAL_MONEY_SUMM" ) )
        {
            //Value with money of the summary Pratipag.
            strncpy( outstr, &filler1[ 23 ], 13 );
        }
        else if ( !strcmp( wtoken->name, "TKN_QTD_CARD_SUMM" ) )
        {
            //Qtd. Transaction with card Pratipag.
            strncpy( outstr, &filler1[ 36 ], 13 );
        }
        else if ( !strcmp( wtoken->name, "TKN_VAL_CARD_SUMM" ) )
        {
            //Value with card in Pratipag.
            strncpy( outstr, &filler2[ 9 ], 13 );
        }
        else if ( !strcmp( wtoken->name, "TKN_TOT_SUMM" ) )
        {
            //Value of the transaction money + card (pratipag)
            strncpy( outstr, &filler2[ 22 ], 13 );
        }
        else if ( !strcmp( wtoken->name, "TKN_DT_GRC_SUMM" ) )
        {
            char *_sptr_ = NULL;
            _sptr_ = &filler2[ 35 ];
            sprintf( outstr, "%c%c.%c%c.%c%c%c%c\0", _sptr_[ 6 ], _sptr_[ 7 ], _sptr_[ 4 ], _sptr_[ 5 ], _sptr_[ 2 ], _sptr_[ 3 ] );
        }
        else if ( !strcmp( wtoken->name, "TKN_HR_GRC_SUMM" ) )
        {
            char *_sptr_ = NULL;
            _sptr_ = &filler2[ 43 ];
            sprintf( outstr, "%c%c:%c%c:%c%c\0", _sptr_[ 0 ], _sptr_[ 1 ], _sptr_[ 2 ], _sptr_[ 3 ], _sptr_[ 4 ], _sptr_[ 5 ] );
        }
        else if ( !strcmp( wtoken->name, "TKN_CD_PNPD" ) )
        {
            //Bit 124.
            sprintf( fmtstr, "%%-%ds", outstrlen );
            sprintf( outstr, fmtstr, codver );
        }
        else if ( !strcmp( wtoken->name, "TKN_NU_ORD_SRV" ) )
        {
            char AUX_Msg[1024] = {0};
            sprintf( AUX_Msg, "TKN_NU_ORD_SRV [%s] ", cod_ocorr );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, AUX_Msg );

            sprintf( fmtstr, "%%-%ds", outstrlen );
            sprintf( outstr, fmtstr, cod_ocorr );
        }
        else if ( !strcmp( wtoken->name, "TKN_TRAILER" ) )
        {
            //Adjust token size to trailer lenght.
            if ( strlen( trailer ) > outstrlen )
            {
                outstrlen = strlen( trailer );
            }
            sprintf( fmtstr, "%%-%ds", outstrlen );
            sprintf( outstr, fmtstr, trailer );
            outstr[ outstrlen ] = '\0';
        }
        else if ( !strcmp( wtoken->name, "TKN_DT_PRDT" ) )
        {
            //Pre-date debit.
            sprintf( outstr, "%02d/%02d/%02d\0",
                ( DT_PRDT % 100 ),
                ( ( DT_PRDT % 10000 ) / 100 ),
                ( ( DT_PRDT / 10000 ) % 100 ) );
        }
        else if ( !strcmp( wtoken->name, "TKN_MSG_EMISSOR" ) )
        {
            //Sender message.
            if ( strlen( buff ) > 0 )
            {
                strncpy( outstr, buff, strlen( buff ) );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_SERVICO_FROTA" ) )
        {
            strncpy( fmtstr, &acquirer_data[ 16 ], 2 );
            fmtstr[ 2 ] = 0;

            k = atoi( fmtstr );
            if ( k == 1 )
            {
                strcpy( wrkstr, "ABASTECIMENTO" );
            }
            else if ( k == 2 )
            {
                strcpy( wrkstr, "TROCA DE OLEO" );
            }
            else if ( k == 3 )
            {
                strcpy( wrkstr, "LAVAGEM" );
            }
            else if ( k == 4 )
            {
                strcpy( wrkstr, "PEDAGIO" );
            }
            else
            {
                strcpy( wrkstr, "OUTROS" );
            }

            strcpy( outstr, wrkstr );
            outstrlen = strlen( outstr );
        }
        else if ( !strcmp( wtoken->name, "TKN_COMPR_VO_FROTA" ) )
        {
            int aux1;
            int aux2;
            int servico;
            char acAux[ 20 ];

            //Service.
            strncpy( fmtstr, &acquirer_data[ 16 ], 2 );
            fmtstr[ 2 ] = 0;
            servico = atoi( fmtstr );

            //Mont the line VEICULO: ######## CONDUTOR: ########@
            strncpy( fmtstr, acquirer_data, 8 );
            fmtstr[ 8 ] = 0;
            aux1 = atoi( fmtstr );

            strncpy( fmtstr, &acquirer_data[ 8 ], 8 );
            fmtstr[ 8 ] = 0;
            aux2 = atoi( fmtstr );

            sprintf( outstr, "VEICULO: %08d CONDUTOR: %08d@", aux1, aux2 );

            if ( servico != 3 && servico != 4 )
            {
                //Mont the line KM: ########## LITRAGEM: #########@
                strncpy( fmtstr, &acquirer_data[ 28 ], 10 );
                fmtstr[ 10 ] = 0;

                strncpy( acAux, &acquirer_data[ 20 ], 7 );
                acAux[ 7 ] = 0;

                sprintf( wrkstr, "KM: %010s QTD: %09.2f@", fmtstr, ( atof( acAux ) / 100 ) );

                //Change . for ,
                wrkstr[ strcspn( wrkstr, "." ) ] = ',';
                strcat( outstr, wrkstr );
            }

            if ( servico == 1 || servico == 5 )
            {
                //Mont the lone: COD. COMBUSTIVEL: ##@
                strncpy( fmtstr, &acquirer_data[ 18 ], 2 );
                fmtstr[ 2 ] = 0;
                aux1 = atoi( fmtstr );

                //Last line should not have @
                sprintf(wrkstr, "COD. COMBUSTIVEL: %02d", aux1 );
                strcat( outstr, wrkstr );
                outstrlen = strlen( outstr );
            }
        }
        else if ( !strcmp( wtoken->name, "TKN_APP_ID" ) )
        {
            char AUX_Msg[1024] = {0};
            memset(wrkstr, 0, sizeof(wrkstr));

            sprintf( AUX_Msg, "TKN_APP_ID [%s] ", textoApplicationIdentifier );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, AUX_Msg );

            sprintf( fmtstr, "AID: %%.%ds", sizeof( textoApplicationIdentifier ) - 1 );
            if ( strlen( textoApplicationIdentifier ) > 0 )
            {
                sprintf( wrkstr, fmtstr, textoApplicationIdentifier );
                strncpy( outstr, wrkstr, strlen( wrkstr ) );
            }

            /* atualiza tamanho do token */
            if (strlen(wrkstr) == 0)
            {
                outstrlen = strlen(wrkstr);
            }
        }
        // Token referente a mensagem de SALDO DISPONIVEL
        // Abaixo da versao 600 => Deve imprimir "SALDO DISP."" com o valor ja no cupom
        // Entre a versao 600 e 604 => Deve imprimir "[SALDOVOUCHER]" sem o valor no cupom
        // Acima ou igual a versao 604 => Deve imprimir "[SALDODISP] sem o valor no cupom"
        // Caso nao va no cupom, o valor volta no DE47.tag33
        else if ( !strcmp( wtoken->name, "TKN_BALANCE_MSG" ) )
        {
            std::string balanceMessage;

            if (versionNum < 600) 
            {
                balanceMessage.assign("SALDO DISP.");
            }
            else if (versionNum >= 604)
            {
                balanceMessage.assign("[SALDODISP]");
            }
            else // Entre 600 e 604
            {
                balanceMessage.assign("[SALDOVOUCHER]");
            }

			sprintf( outstr, "%s", balanceMessage.c_str() );
            outstrlen = strlen( outstr );
        }
        // Padronizacao Crediario PDV - INICIO
        else if ( !strcmp( wtoken->name, "TKN_DOCUMENT" ) ) // CNPJ e/ou CPF
        {
            string document = "";
            fsextr( document, merchantDocument );
            
            if ( strlen( document.c_str() ) > 11 ) // CNPJ
            {
                string formatacao = "##.###.###/####-##";
                char documentoFormatado[20] = {0};
                
                memset(documentoFormatado, 0, sizeof(documentoFormatado));
                MascararDocumento( document, formatacao, documentoFormatado );
                strncpy( outstr, documentoFormatado, strlen( documentoFormatado ) );
            }
            else // CPF
            {
                string formatacao = "###.###.###-##";
                char documentoFormatado[20] = {0};
                
                memset(documentoFormatado, 0, sizeof(documentoFormatado));
                MascararDocumento( document, formatacao, documentoFormatado );
                strncpy( outstr, documentoFormatado, strlen( documentoFormatado ) );
            }
        }
        // Padronizacao Crediario PDV - FIM
        // Padronizacao Crediario PDV - INICIO
        else if ( !strcmp( wtoken->name, "TKN_TXN_VLIOF" ) ) // IOF
        {
            double iofDouble = 0.0;

            if ( wtoken->decimal != '*' && (int) wtoken->decimal >= 0 )
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%d.%df", outstrlen, (int) wtoken->decimal );
                }
                else
                {
                    sprintf( fmtstr, "%%0%d.%df", outstrlen, (int) wtoken->decimal );
                }
            }
            else
            {
                if ( wtoken->left_zero != 'Z' )
                {
                    sprintf( fmtstr, "%%%df", outstrlen );
                }
                else
                {
                    sprintf( fmtstr, "%%0%df", outstrlen );
                }
            }

            if ( localMessageName.compare("CREDIARIO_VENDA") == 0 )
            {
                char debugMessage[1024] = {0};
                char valor[20] = {0};
                
                sprintf( fmtstr, "%%%d.%df%%", outstrlen, (int) wtoken->decimal );
                
                memset(valor, 0, sizeof(valor));
                strncpy(valor, localComplementoCrediario.substr(8, 12).c_str(), 12);
                sscanf(valor, "%12lf", &iofDouble);
                iofDouble /= 100;
                
                sprintf(debugMessage, " Valor do IOF do Crediario [%s] [%f]", valor, iofDouble);
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, debugMessage );
            }
            else
            {
                return 0;
            }
            
            sprintf( outstr, fmtstr, iofDouble );

            if ( wtoken->decimal != '*' && (int) wtoken->decimal > 0 )
            {
                if ( wtoken->separator != '*' )
                {
                    outstr[ strcspn( outstr, "." ) ] = wtoken->separator;
                }
            }
        }
        // Padronizacao Crediario PDV - FIM
        else
        {
            //Invalid token or need to handle herein.
            syslg( "Unexpected token:[ %s ] id:[ %d ]  Receipt format aborted\n", wtoken->name, wtoken->id );
            //sprintf(buffer,"replace_token_on_receipt: Unexpected token:[ %s ] id:[ %d ]  Receipt format aborted",wtoken->name,wtoken->id);
            //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, buffer );
            return( -1 );
        }

        //Lay the built string on the output string according to its justify
        if ( wtoken->position == 'C' || wtoken->position == 'R' )
        {
            //Need to shift through.
            if ( wtoken->left_zero != 'Z' )
            {
                memset( wrkstr, ' ', outstrlen );
            }
            else
            {
                memset( wrkstr, '0', outstrlen );
            }
            wrkstr[ outstrlen ] = '\0';

            for ( i = strlen( outstr) - 1; i >= 0 && outstr[ i ] == ' '; i-- );
            outstr[ ++i ] = '\0';

            if ( wtoken->position == 'C' )
            {
                i = ( ( outstrlen - strlen( outstr ) ) / 2 ) + ( ( ( outstrlen - strlen( outstr ) ) % 2 ) ? 1 : 0 );
            }
            else if ( wtoken->position == 'R' )
            {
                i = outstrlen - strlen( outstr );
            }
            else
            {
                i = 0;
            }
            strncpy( wrkstr + i, outstr, strlen( outstr ) );
            strcpy( outstr, wrkstr );
        }

        //Finally, put the string on the receipt.
        memcpy( wreceipt, outstr, outstrlen );

        return( outstrlen );
    }
    
    // Padronizacao Crediario PDV - INICIO
    /// MascararDocumento
    /// Formata a string com a mascara CPF ou CNPJ
    /// EF/ET: ET1
    /// Historico: [Data] - ET - Descricao
    /// 03/09/2019 - Andre Morishita - ET1 - Criacao da versao inicial
    /// documento: documento a ser formatado
    /// mascara: mascara da formatacao
    /// documentoFormatado: retorno do documento formatado
    int TrxCupom::MascararDocumento( const string &documento, const string &mascara, char *documentoFormatado )
    {
        char debugMessage[1024] = {0};
        char auxiliar[1024] = {0};
        int indexMascara = mascara.length();
        int indexDocumento = documento.length();
        
        memset(auxiliar, ' ', sizeof(auxiliar));
        sprintf(debugMessage, " MascararDocumento(): documento [%d][%s] mascara [%d][%s]", indexDocumento, documento.c_str(), indexMascara, mascara.c_str());
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, debugMessage );
        
        if (indexMascara <= 1 || indexDocumento <= 1)
        {
            syslg("MascararDocumento() - Tentando formatador a tag TKN_DOCUMENT com valores invalidos [%s][%s]\n", documento.c_str(), mascara.c_str());
            return 0;
        }
        
        indexMascara--;
        indexDocumento--;
        while (indexMascara >= 0)
        {
            if (mascara.c_str()[indexMascara] != '#')
            {
                auxiliar[indexMascara] = mascara.c_str()[indexMascara];
                indexMascara--;
            }
            else
            {
                if (indexDocumento >= 0)
                {
                    auxiliar[indexMascara] = documento.c_str()[indexDocumento];
                    indexMascara--;
                    indexDocumento--;
                }
                else 
                {
                    auxiliar[indexMascara] = '0';
                    indexMascara--;
                }
            }
        }
        auxiliar[mascara.length()] = '\0';
        
        strcpy(documentoFormatado, auxiliar);
        sprintf(debugMessage, " MascararDocumento(): documento formatado: [%s][%s]", auxiliar, documentoFormatado);
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, debugMessage );
        return 0;
    }
    // Padronizacao Crediario PDV - FIM
} //namespace plugins_pdv
