/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/Tbsw0102Inserter.hpp"
#include "dbaccess_pdv/Tbsw0102RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTbsw0102Inserter( )
    {
        Tbsw0102Inserter* l_new = new Tbsw0102Inserter;
        return( l_new );
    }

    Tbsw0102Inserter::Tbsw0102Inserter( )
    {
    }

    Tbsw0102Inserter::~Tbsw0102Inserter( )
    {
    }

    /// startConfiguration
    /// Prepara os parametros recebidos na chamada do plugin dentro do XML
    ///  sourceFieldPath: parametros com os dados para insercao 
    ///  targetFieldPath: parametros para enviar o status da operacao
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0102Inserter::startConfiguration( const configBase::Tag* tagParametro )
    {
        configBase::TagList tagListLocal;

        tagParametro->findTag( "sourceFieldPath", tagListLocal );
        std::string sourceLocal = tagListLocal.front( ).findProperty( "value" ).value( );
        this->SetSourceFieldPath( sourceLocal );

        tagParametro->findTag( "targetFieldPath", tagListLocal );
        std::string targetLocal = tagListLocal.front( ).findProperty( "value" ).value( );
        this->SetTargetFieldPath( targetLocal );

        return( true );
    }

    /// init
    /// Prepara os parametros de entrada e saida
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0102Inserter::init( )
    {
        result = this->navigate( targetFieldPath + ".RESULT" );

        localDate               = this->navigate( sourceFieldPath + ".shc_msg.local_date" );
        refnum                  = this->navigate( sourceFieldPath + ".shc_msg.refnum" );
        tokenAssuranceLevel     = this->navigate( sourceFieldPath + ".segments.common.tokenAssuranceLevel" );
        paymentAccountReference = this->navigate( sourceFieldPath + ".segments.common.paymentAccountReference" );

        return( true );
    }

    void Tbsw0102Inserter::finish( )
    {
    }

    /// execute
    /// Efetua o insert na TBSW0102
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    int Tbsw0102Inserter::execute( bool& stopParametro )
    {
        try
        {

            dbaccess_common::TBSW0102 table0102Local;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0102" );
            dbaccess_pdv::Tbsw0102RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0102_params params = { 0 };

            fieldSet::fsextr( params.local_date, localDate );
            fieldSet::fsextr( params.refnum, refnum );
            fieldSet::fsextr( params.tokenAssuranceLevel, tokenAssuranceLevel );
            fieldSet::fsextr( params.paymentAccountReference, paymentAccountReference );

            regrasFmt.DAT_MOV_TRAN     ( table0102Local, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC      ( table0102Local, params, acq_common::INSERT );
            regrasFmt.COD_NVL_SGRA_TKN ( table0102Local, params, acq_common::INSERT );
            regrasFmt.COD_REF_CTA_PGMN ( table0102Local, params, acq_common::INSERT );

            table0102Local.insert( );
            table0102Local.commit( );

            fieldSet::fscopy( result, "OK", 2 );
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "Exception in TBSW0102 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "std::exception in TBSW0102 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }

        stopParametro = false;
        return( 0 );
    }

    /// SetSourceFieldPath
    /// Define Source FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0102Inserter& Tbsw0102Inserter::SetSourceFieldPath( const std::string& pathParametro )
    {
        sourceFieldPath = pathParametro;
        return( *this );
    }

    /// SetTargetFieldPath
    /// Define Target FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0102Inserter& Tbsw0102Inserter::SetTargetFieldPath( const std::string& pathParametro )
    {
        targetFieldPath = pathParametro;
        return( *this );
    }

    dataManip::Command* Tbsw0102Inserter::clone( ) const
    {
        return( new Tbsw0102Inserter( *this ) );
    }

} // namespace plugins_pdv
