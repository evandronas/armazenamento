/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
/ 2021-02-01 Breder - AUT1-2821 - PIX CNPJ Owner +Refactory
*/
#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0040.hpp"
#include "plugins_pdv/TBSW0040Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0040Loader( )
    {
        TBSW0040Loader* l_new = new TBSW0040Loader;
        return l_new;
    }
    bool TBSW0040Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return true;
    }
    TBSW0040Loader::TBSW0040Loader( )
    {
    }
    TBSW0040Loader::~TBSW0040Loader( )
    {
    }
    bool TBSW0040Loader::init( )
    {
        m_RESULT                = this->navigate( m_targetFieldPath + ".RESULT"                     );
        m_TERMLOC               = this->navigate( m_sourceFieldPath + ".shc_msg.termloc"            );
        m_COD_DSTR              = this->navigate( m_sourceFieldPath + ".segments.merchant.cod_dstr" );

        m_MER_POST              = this->navigate( m_targetFieldPath + ".MER_POST"             ); // COD_CEP_PDV + COD_CEP_CPL_PDV
        m_COD_RAM_ATVD_INTER    = this->navigate( m_targetFieldPath + ".COD_RAM_ATVD_INTER"   ); // ( COD_RAM_ATVD/1000 ) % 10
        m_POS_GEO_LOC           = this->navigate( m_targetFieldPath + ".POS_GEO_LOC"          ); // COD_PAIS + m_MER_POST
        m_RESULT_DSTR           = this->navigate( m_targetFieldPath + ".RESULT_DSTR"          ); // depende de m_COD_DSTR
        m_COD_RAM_ATVD_DSTR     = this->navigate( m_targetFieldPath + ".COD_RAM_ATVD_DSTR"    ); // m_COD_DSTR ? COD_RAM_ATVD : 0

        m_NUM_PDV               = this->navigate( m_targetFieldPath + ".NUM_PDV"              );
        m_COD_TIP_ESTB_PDV      = this->navigate( m_targetFieldPath + ".COD_TIP_ESTB_PDV"     );
        m_COD_CTGR              = this->navigate( m_targetFieldPath + ".COD_CTGR"             );
        m_NOM_RZAO_SCLA_ESTB    = this->navigate( m_targetFieldPath + ".NOM_RZAO_SCLA_ESTB"   );
        m_NOM_FAT_PDV           = this->navigate( m_targetFieldPath + ".NOM_FAT_PDV"          ); //mer_name
        m_COD_CEP_PDV           = this->navigate( m_targetFieldPath + ".COD_CEP_PDV"          );
        m_COD_CEP_CPL_PDV       = this->navigate( m_targetFieldPath + ".COD_CEP_CPL_PDV"      );
        m_NOM_CID_PDV           = this->navigate( m_targetFieldPath + ".NOM_CID_PDV"          ); //mer_city
        m_NOM_ESTB_PDV          = this->navigate( m_targetFieldPath + ".NOM_ESTB_PDV"         );
        m_COD_PAIS              = this->navigate( m_targetFieldPath + ".COD_PAIS"             );
        m_COD_RAM_ATVD          = this->navigate( m_targetFieldPath + ".COD_RAM_ATVD"         );
        m_COD_RAM_ATVD_MTC      = this->navigate( m_targetFieldPath + ".COD_RAM_ATVD_MTC"     );
        m_COD_CTGR_TRAN_MTC     = this->navigate( m_targetFieldPath + ".COD_CTGR_TRAN_MTC"    );
        m_COD_RAM_ATVD_MTC_DNRS = this->navigate( m_targetFieldPath + ".COD_RAM_ATVD_MTC_DNRS");
        m_COD_MTZ_ESTB          = this->navigate( m_targetFieldPath + ".COD_MTZ_ESTB"         );
        m_COD_GRU_ESTB          = this->navigate( m_targetFieldPath + ".COD_GRU_ESTB"         );
        m_NUM_CNPJ              = this->navigate( m_targetFieldPath + ".NUM_CNPJ"             );
        m_COD_STTU_REG          = this->navigate( m_targetFieldPath + ".COD_STTU_REG"         );
        m_DAT_ATLZ_REG          = this->navigate( m_targetFieldPath + ".DAT_ATLZ_REG"         );
        m_COD_ID_DSTR           = this->navigate( m_targetFieldPath + ".COD_ID_DSTR"          );
        m_IND_PDV_CART_DGTL     = this->navigate( m_targetFieldPath + ".IND_PDV_CART_DGTL"    );
        m_COD_TIP_PES           = this->navigate( m_targetFieldPath + ".COD_TIP_PES"          );
        m_COD_GRU_CLAS_RAM      = this->navigate( m_targetFieldPath + ".COD_GRU_CLAS_RAM"     );
        m_COD_TIP_FACR          = this->navigate( m_targetFieldPath + ".COD_TIP_FACR"         );
        m_COD_MVV               = this->navigate( m_targetFieldPath + ".COD_MVV"              ); // J10_2020 - Release Outubro
        m_COD_PRCR_PSP          = this->navigate( m_targetFieldPath + ".COD_PRCR_PSP"         ); // AUT1-2121 - Codigo da Chave PIX
        m_COD_TIP_CHAV_PIX      = this->navigate( m_targetFieldPath + ".COD_TIP_CHAV_PIX"     ); // AUT1-2121 - Codigo do Parceiro PSP - PIX
        m_COD_CHAV_PIX          = this->navigate( m_targetFieldPath + ".COD_CHAV_PIX"         ); // AUT1-2320 - Codigo do tipo da Chave PIX
        m_NUM_CNPJ_PIX_OWN_CHAV = this->navigate( m_targetFieldPath + ".NUM_CNPJ_PIX_OWN_CHAV"); // AUT1-2821 - PIX CNPJ Owner

        return true;
    }
    void TBSW0040Loader::finish( )
    {
    }
    int TBSW0040Loader::execute( bool& a_stop )
    {
        try
        {
            long l_num_pdv = 0;
            fieldSet::fsextr( l_num_pdv, m_TERMLOC );

            std::ostringstream l_whereClause;
            l_whereClause << "NUM_PDV = " << l_num_pdv;

            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0040 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
            dbaccess_common::TBSW0040 l_table0040( l_whereClause.str( ) );

            l_table0040.prepare( );
            l_table0040.execute( );

            if ( !l_table0040.fetch( ) )
            {
                fieldSet::fscopy( m_RESULT, std::string( "NO ROWS" ) );
            }
            else
            {
                // m_NUM_CNPJ
                char aux_NUM_CNPJ[64];
                oasis_dec_t dec_num_cnpj = l_table0040.getNUM_CNPJ( );
                memset( aux_NUM_CNPJ, 0, sizeof( aux_NUM_CNPJ ) );
                dbm_dectochar_conv( &dec_num_cnpj, aux_NUM_CNPJ, 0 );
                // m_MER_POST
                std::string aux_MER_POST = l_table0040.getCOD_CEP_PDV( ) + l_table0040.getCOD_CEP_CPL_PDV( );
                // m_COD_RAM_ATVD_INTER
                unsigned long aux_COD_RAM_ATVD_INTER = ( l_table0040.getCOD_RAM_ATVD() / 1000 ) % 10;
                // m_aux_POS_GEO_LOC
                char aux_POS_GEO_LOC[16];
                sprintf(aux_POS_GEO_LOC, "%03hu%-10s", atoi(l_table0040.getCOD_PAIS().c_str()), aux_MER_POST.c_str());
                // m_NOM_FAT_PDV
                std::string aux_NOM_FAT_PDV;
                aux_NOM_FAT_PDV = l_table0040.getNOM_FAT_PDV( );
                if ( aux_NOM_FAT_PDV.size( ) < 23 ) // verifica se o mer_name, esta com o tamanho correto (23)
                    aux_NOM_FAT_PDV.insert( aux_NOM_FAT_PDV.end(), 23 - aux_NOM_FAT_PDV.size( ), ' ');
                else if ( aux_NOM_FAT_PDV.size( ) > 23 )
                    aux_NOM_FAT_PDV = aux_NOM_FAT_PDV.substr(0, 22);
                // m_NOM_CID_PDV
                std::string aux_NOM_CID_PDV;
                aux_NOM_CID_PDV = l_table0040.getNOM_CID_PDV( );
                if( aux_NOM_CID_PDV.size( ) < 25 ) // verifica se o mer_city, esta com o tamanho correto (25)
                    aux_NOM_CID_PDV.insert( aux_NOM_CID_PDV.end(), 25 - aux_NOM_CID_PDV.size( ), ' ');
                else if ( aux_NOM_CID_PDV.size( ) > 25 )
                    aux_NOM_CID_PDV = aux_NOM_CID_PDV.substr(0, 24);
                // m_RESULT_DSTR/m_COD_RAM_ATVD_DSTR
                std::string aux_RESULT_DSTR = "NO ROWS";
                long aux_COD_RAM_ATVD_DSTR  = 0;
                long l_cod_dstr = 0;
                fieldSet::fsextr( l_cod_dstr, m_COD_DSTR );
                if ( l_cod_dstr )
                {
                    l_whereClause.str( "" );
                    l_whereClause.clear( );
                    l_whereClause << "NUM_PDV = " << l_cod_dstr;

                    dbaccess_common::TBSW0040 l_table0040_dstr( l_whereClause.str( ) );

                    l_table0040_dstr.prepare( );
                    l_table0040_dstr.execute( );

                    if ( l_table0040_dstr.fetch( ) )
                    {
                        aux_RESULT_DSTR = "OK";
                        aux_COD_RAM_ATVD_DSTR = l_table0040_dstr.getCOD_RAM_ATVD( );
                    }
                }
                else
                {
                    aux_RESULT_DSTR = "THERE IS NOT DISTRIBUTOR";
                }
                // m_NUM_CNPJ_PIX_OWN_CHAV
                //TODOSW75 
                /***
                char aux_NUM_CNPJ_PIX[64];
                oasis_dec_t dec_num_cnpj_pix = l_table0040.getNUM_CNPJ_PIX_OWN_CHAV( );
                memset( aux_NUM_CNPJ_PIX, 0, sizeof( aux_NUM_CNPJ_PIX ) );
                dbm_dectochar_conv( &dec_num_cnpj_pix, aux_NUM_CNPJ_PIX, 0 );
                ***/

                // resultados
                fieldSet::fscopy( m_RESULT,                 std::string( "OK" )                     );
                fieldSet::fscopy( m_MER_POST,               aux_MER_POST                            ); // COD_CEP_PDV + COD_CEP_CPL_PDV
                fieldSet::fscopy( m_COD_RAM_ATVD_INTER,     aux_COD_RAM_ATVD_INTER                  ); // ( COD_RAM_ATVD/1000 ) % 10
                fieldSet::fscopy( m_POS_GEO_LOC,            std::string(aux_POS_GEO_LOC)            ); // COD_PAIS + m_MER_POST
                fieldSet::fscopy( m_RESULT_DSTR,            aux_RESULT_DSTR                         ); // depende de m_COD_DSTR
                fieldSet::fscopy( m_COD_RAM_ATVD_DSTR,      aux_COD_RAM_ATVD_DSTR                   ); // m_COD_DSTR ? COD_RAM_ATVD : 0
                // campos da TBSW0040
                fieldSet::fscopy( m_NUM_PDV,                l_table0040.getNUM_PDV( )               );
                fieldSet::fscopy( m_COD_TIP_ESTB_PDV,       l_table0040.getCOD_TIP_ESTB_PDV( )      );
                fieldSet::fscopy( m_COD_CTGR,               l_table0040.getCOD_CTGR( )              );
                fieldSet::fscopy( m_NOM_RZAO_SCLA_ESTB,     l_table0040.getNOM_RZAO_SCLA_ESTB( )    );
                fieldSet::fscopy( m_NOM_FAT_PDV,            l_table0040.getNOM_FAT_PDV( )           ); //mer_name
                fieldSet::fscopy( m_NOM_FAT_PDV,            aux_NOM_FAT_PDV                         );
                fieldSet::fscopy( m_COD_CEP_PDV,            l_table0040.getCOD_CEP_PDV( )           );
                fieldSet::fscopy( m_COD_CEP_CPL_PDV,        l_table0040.getCOD_CEP_CPL_PDV( )       ); //mer_city
                fieldSet::fscopy( m_NOM_CID_PDV,            aux_NOM_CID_PDV                         );
                fieldSet::fscopy( m_NOM_ESTB_PDV,           l_table0040.getNOM_ESTB_PDV( )          );
                fieldSet::fscopy( m_COD_PAIS,               atoi(l_table0040.getCOD_PAIS( ).c_str()));
                fieldSet::fscopy( m_COD_RAM_ATVD,           l_table0040.getCOD_RAM_ATVD( )          );
                fieldSet::fscopy( m_COD_RAM_ATVD_MTC,       l_table0040.getCOD_RAM_ATVD_MTC( )      );
                fieldSet::fscopy( m_COD_CTGR_TRAN_MTC,      l_table0040.getCOD_CTGR_TRAN_MTC( )     );
                fieldSet::fscopy( m_COD_RAM_ATVD_MTC_DNRS,  l_table0040.getCOD_RAM_ATVD_MTC_DNRS( ) );
                fieldSet::fscopy( m_COD_MTZ_ESTB,           l_table0040.getCOD_MTZ_ESTB( )          );
                fieldSet::fscopy( m_COD_GRU_ESTB,           l_table0040.getCOD_GRU_ESTB( )          );
                fieldSet::fscopy( m_NUM_CNPJ,               std::string( aux_NUM_CNPJ )             );
                fieldSet::fscopy( m_COD_STTU_REG,           l_table0040.getCOD_STTU_REG( ).c_str()  );
                fieldSet::fscopy( m_DAT_ATLZ_REG,           l_table0040.getDAT_ATLZ_REG( )          );
                fieldSet::fscopy( m_COD_ID_DSTR,            l_table0040.getCOD_ID_DSTR( )           );
                //TODOSW75 fieldSet::fscopy( m_IND_PDV_CART_DGTL,      l_table0040.getIND_PDV_CART_DGTL( )     );
                fieldSet::fscopy( m_COD_TIP_PES,            l_table0040.getCOD_TIP_PES( )           );
                fieldSet::fscopy( m_COD_GRU_CLAS_RAM,       l_table0040.getCOD_GRU_CLAS_RAM( )      );
                //TODOSW75 fieldSet::fscopy( m_COD_TIP_FACR,           l_table0040.getCOD_TIP_FACR( )          );
                //TODOSW75 fieldSet::fscopy( m_COD_MVV,                l_table0040.getCOD_MVV( )               ); // J10_2020 - Release Outubro
                fieldSet::fscopy( m_COD_PRCR_PSP,           l_table0040.getCOD_PRCR_PSP( )          ); // AUT1-2121 - Codigo da Chave PIX
                fieldSet::fscopy( m_COD_TIP_CHAV_PIX,       l_table0040.getCOD_TIP_CHAV_PIX( )      ); // AUT1-2121 - Codigo do Parceiro PSP - PIX
                fieldSet::fscopy( m_COD_CHAV_PIX,           l_table0040.getCOD_CHAV_PIX( )          ); // AUT1-2320 - Codigo do tipo da Chave PIX
                //TODOSW75 fieldSet::fscopy( m_NUM_CNPJ_PIX_OWN_CHAV,  std::string( aux_NUM_CNPJ_PIX )         ); // AUT1-2821 - PIX CNPJ Owner
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_RESULT, std::string( "ERROR" ) );
            fieldSet::fscopy( m_RESULT_DSTR, std::string( "ERROR" ) );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0040 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
            fieldSet::fscopy( m_RESULT, std::string( "ERROR" ) );
            fieldSet::fscopy( m_RESULT_DSTR, std::string( "ERROR" ) );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0040[" + l_what + "]";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }
    TBSW0040Loader& TBSW0040Loader::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW0040Loader& TBSW0040Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }
    dataManip::Command* TBSW0040Loader::clone( ) const
    {
        return new TBSW0040Loader( *this );
    }
}//namespace plugins_pdv