/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/* Copyright 2018 Rede S.A.
Autor : FIDELITY
Empresa : REDE

*********************** MODIFICACOES ************************
Autor    : Arthur Henrique 
Data     : 18/07/2018 
Empresa  : Rede 
Descrição: Correções de problemas de inspeção de código fonte 'Switch sem default'.
ID       : 227.478
************************************************************* 
*/

#pragma once
#include <ist_text.h>
#include <shcfmt.h>
#include "base/GenException.hpp"
#include "configBase/DOMTreatment.hpp"
#include "configBase/TagList.hpp"
#include "configLoader/Iso8583Config.hpp"
#include "msgConv/DataCoding.hpp"
#include "plugins_pdv/Iso8583IntellinacParser.hpp"
#include "msgConv/TextConv.hpp"
#include <sstream>
#include <iostream>

namespace msgConv
{
	FieldSetLoader* createIso8583IntellinacParser()
	{
		Iso8583IntellinacParser* l_new = new Iso8583IntellinacParser;			
		return l_new;
	}
	bool Iso8583IntellinacParser::loadXml( const std::string& a_xmlPath, const std::string& l_xmlName, configBase::Tag& a_tag )
	{
		configBase::DOMTreatment l_domTreat;
		bool l_xmlret = l_domTreat.load( a_xmlPath, l_xmlName, a_tag );
		if ( !l_xmlret )
		{
			const configBase::XMLParseErrorHandler::ERRMSGS& l_errors = l_domTreat.errors( );
            unsigned int l_count = l_errors.size( );
            std::stringstream l_logmsg;
            for ( unsigned int i = 0; i < l_count; ++i )
            {                
                l_logmsg << __FUNCTION__ << "[" << l_errors[i].systemFile( ) << "][" << l_errors[i].lineNumber( ) << "][" << l_errors[i].columnNumber( ) << "][" << l_errors[i].message( ) << "]" << std::endl;
            }
            this->setHasError( true );
			this->setErrorMessage( l_logmsg.str() );
		}
		return l_xmlret;
	}
	bool Iso8583IntellinacParser::startConfiguration( const configBase::Tag* a_tag )
	{
        configBase::TagList l_iso8583PropertiesXmltagList;
        configBase::Tag l_full;        
        if ( a_tag->findTagNotRequired( "iso8583PropertiesXml", l_iso8583PropertiesXmltagList ) )
        {
            configBase::TagList l_list;
            configLoader::Iso8583Config l_iso8583Config;
            msgConv::Iso8583Properties l_isoProperties;
            
            if(!loadXml( l_iso8583PropertiesXmltagList.front().findProperty( "filePath" ).value( ), 
                         l_iso8583PropertiesXmltagList.front().findProperty( "fileName" ).value( ), 
                         l_full ) )
            {
                return false;
            }            
            l_full.findTag( "Iso8583Properties", "label", "Iso8583Msg", l_list );            
            if (!l_iso8583Config.load( l_isoProperties, l_list.front( ) ) )
            {
                return false;
            }
            this->setIso8583Properties( l_isoProperties );           
        }
	   return true;
	}    
	Iso8583IntellinacParser::Iso8583IntellinacParser( )
	{
		const unsigned int l_buffLength = 65536;
		m_auxBuffer			= new unsigned char[l_buffLength];
		m_auxBufferLength	= l_buffLength;
	}
	Iso8583IntellinacParser::~Iso8583IntellinacParser( )
	{
		delete[]
		m_auxBuffer;
	}
	bool Iso8583IntellinacParser::open( )
	{
		return initialiseIndexers( );
	}
	void Iso8583IntellinacParser::close( )
	{
	}
	void Iso8583IntellinacParser::printHEX( std::string a_varname, const char* a_buf, unsigned int size )
	{
		char buffer[1024];
		sprintf( buffer, "%s: <", a_varname.c_str() );
		//logger::DebugWriter::getInstance()->write( logger::LEVEL_ALWAYS, buffer);
		printf("%s:", a_varname.c_str() );
		for( unsigned int i = 0 ; i < size ; i++ )
		{
			sprintf( buffer, " %02x ", (const unsigned char*)a_buf[i] );
			//logger::DebugWriter::getInstance()->write( logger::LEVEL_ALWAYS, buffer);			
			printf( " %02x ", (const unsigned char*)a_buf[i] );
		}
		//logger::DebugWriter::getInstance()->write( logger::LEVEL_ALWAYS, ">\n");
		printf("%\n");
	}		
	bool Iso8583IntellinacParser::parse( const unsigned char* a_source, unsigned int a_sourceLen )
	{
		m_dequeBitsOn.clear( );
		target( ).clearData( );
		target( ).turnOff( );
		m_isISO8583Access.field( ).input( std::string( "FALSE" ) );
		std::string l_specific;
		l_specific.assign( reinterpret_cast<const char *>( a_source ), a_sourceLen );
		target( ).input( l_specific );
		if ( this->extractPieces( l_specific ) )
		{
			bool l_ret = loadFieldSet( );
			if ( l_ret )
			{
				m_isISO8583Access.field( ).input( std::string( "TRUE" ) );
			}
		}
		return true;
	}
	bool Iso8583IntellinacParser::loadFieldSet( )
	{
		std::deque<unsigned int>::const_iterator l_it;
		char l_label[64];
		unsigned int l_current = 0;
		m_headerAccess.field( ).turnOn( ).input( m_header.data( ), m_header.length( ) );
		m_msgTypeAccess.field( ).turnOn( ).input( m_msgType.data( ), m_msgType.length( ) );

		if( m_tpdu.length( ) > 0 )
        {
            m_tpduAccess.field( ).turnOn( ).input( m_tpdu ); //EAK-2855 - Correcao TPDU com zero binario (passar objeto string como parametro, e nao array of char)
		}
        else
        {
            m_tpduAccess.field( ).turnOff( );
        }
		
		if( m_mct.length( ) > 0 )
        {		
			m_mctAccess.field( ).turnOn( ).input( m_mct.data( ), m_mct.length( ) );
		}
        else
        {
            m_mctAccess.field( ).turnOff( );
        }
		
        if( m_niip.length( ) > 0 )
        {
            m_niipAccess.field( ).turnOn( ).input( m_niip.data( ), m_niip.length( ) );
        }
        else
        {
            m_niipAccess.field( ).turnOff( );
        }
		for ( l_it = m_dequeBitsOn.begin( ); l_it != m_dequeBitsOn.end( ); ++l_it )
		{
			unsigned int l_deNumber = *l_it;
			fieldSet::Field& l_field = this->getDataElement( l_deNumber ).turnOn( );
			if ( l_deNumber == 1 )
			{            
				continue;
			}
			const DataElementProperties& l_deProp = m_iso8583Properties.dataElementsProperties( l_deNumber );
			if ( l_deProp.isLVar( ) )
			{
				unsigned int l_lvarSize = this->calculateSize( l_deProp.dataElementSize( ), l_deProp.lvarDataCoding( ) );
				std::string l_strSize;
				if ( l_current + l_lvarSize > m_dataElements.length( ) )
				{
					this->setHasError( true );
					this->setErrorMessage( "Invalid input size" );
					return false;
				}
				this->convertToAscii( l_strSize, m_dataElements.substr( l_current, l_lvarSize ), l_deProp.lvarDataCoding( ) );
                unsigned int l_valueSize = this->calculateSize( atoi( l_strSize.c_str( ) ), l_deProp.dataCoding( ) );
				l_current += l_lvarSize;
				std::string l_value;	
				
				if ( l_current + l_valueSize > m_dataElements.length( ) )
				{
					this->setHasError( true );
					this->setErrorMessage( "Invalid input size" );
					return false;
				}
				this->convertToAscii( l_value, m_dataElements.substr( l_current, l_valueSize ), l_deProp.dataCoding( ) );
                l_field.input( reinterpret_cast<const unsigned char*>( l_value.data( ) ), l_value.length( ) );
				l_current += l_valueSize;
			}
			else
			{
				unsigned int l_valueSize = this->calculateSize( l_deProp.dataElementSize( ), l_deProp.dataCoding( ) );
				std::string l_value;
			
				if ( l_current + l_valueSize > m_dataElements.length( ) )
				{
					this->setHasError( true );
					this->setErrorMessage( "Invalid input size" );
					return false;
				}				
				this->convertToAscii( l_value, m_dataElements.substr( l_current, l_valueSize ), l_deProp.dataCoding( ) );
                l_field.input( reinterpret_cast<const unsigned char*>( l_value.data( ) ), l_value.length( ) );
				l_current += l_valueSize;
	
			}
		}
		this->setHasError( false );
		this->setErrorMessage( "No error" );
		return true;
	}
	Iso8583IntellinacParser& Iso8583IntellinacParser::setIso8583Properties( const Iso8583Properties& a_iso8583Properties )
	{
		m_iso8583Properties = a_iso8583Properties;
		return *this;
	}
	bool Iso8583IntellinacParser::extractPieces( const std::string& a_specific )
	{
        unsigned int l_current = 0;
		//std::string l_header;
		//Extracting header        
		/*if ( m_iso8583Properties.headerSize( )> 0 )
		{
			if ( m_iso8583Properties.headerSize( )> a_specific.length( ) )
			{
				return false;
			}
			unsigned int l_headerSize = ( this->calculateSize( m_iso8583Properties.headerSize( ), m_iso8583Properties.headerDataType( ) ) ) * 2;
			l_header = a_specific.substr( 0, l_headerSize );
			//std::cout << "HEADER ORIGINAL: " << l_header << std::endl;
			printf( "HEADER ORIGINAL: %x\n" , l_header );
            this->convertToAscii( m_header, l_header, m_iso8583Properties.headerDataType( ) );
			l_current += l_header.length( );
			m_headerAccess.field( ).input( m_header );
			m_headerAccess.field( ).turnOn( );
		}*/
		
		//std::cout << "HEADER SIZE: " << m_iso8583Properties.headerSize( ) << " HEADER: " << m_header << std::endl;
		
		//Extraction of tpdu
		if( a_specific.length( ) - l_current >= 5 )
		{
			m_tpdu = a_specific.substr( l_current, 0x05 );
			//this->convertToAscii( m_tpdu, l_tpdu, msgConv::HEX );
			l_current += m_tpdu.length( );
			m_tpduAccess.field( ).input( m_tpdu );
			m_tpduAccess.field( ).turnOn( );
		}
		else
		{
			m_tpdu.clear();
			m_tpduAccess.field( ).turnOff( );				
		}
		
		//printHEX( "TPDU", m_tpdu.c_str( ), m_tpdu.length( ) );
		
		//Extraction of merchant type
		if( a_specific.length( ) - l_current >= 15 )
		{
			std::string l_mct = a_specific.substr( l_current, 0x0F );
			this->convertToAscii( m_mct, l_mct, msgConv::EBCDIC );
			l_current += l_mct.length( );
			m_mctAccess.field( ).input( m_mct );
			m_mctAccess.field( ).turnOn( );
		}
		else
		{
			m_mct.clear();
			m_mctAccess.field( ).turnOff( );		
		}
		
		//printHEX( "MTC", m_mct.c_str( ), m_mct.length( ) );

        //Extraction of niip        
        std::string l_niip = a_specific.substr( l_current, 0x03 );
		// Removido conforme conversa com Carlos Henrique Alves da Rocha <carlos.rocha@userede.com.br>
        /*if ( ( ( l_niip[0] == 0x00 ) && ( l_niip[1] == 0x4E ) && ( l_niip[2] == 0x23 ) ) || 
             ( ( l_niip[0] == 0x02 ) && ( l_niip[1] == 0x00 ) && ( l_niip[2] == 0x03 ) ) ||
             ( ( l_niip[0] == 0x22 ) && ( l_niip[1] == 0x20 ) && ( l_niip[2] == 0x03 ) ) ||
             ( ( l_niip[0] == 0x00 ) && ( l_niip[1] == 0x00 ) && ( 
               ( l_niip[2] == 0x50 ) || ( l_niip[2] == 0x32 ) ) ) ||
             ( ( l_niip[0] == 0x11 ) && ( l_niip[1] == 0x10 ) && ( l_niip[2] == 0x50 ) ) ||
             ( ( l_niip[0] == 0x00 ) && ( l_niip[1] == 0x01 ) && ( l_niip[2] == 0x00 ) ) )
        {*/
            this->convertToAscii( m_niip, l_niip, m_iso8583Properties.headerDataType( ) );
            l_current += 0x03;
            m_niipAccess.field( ).input( m_niip );
            m_niipAccess.field( ).turnOn( );
        /*}
        else
        {
            m_niip.clear();
            m_niipAccess.field( ).turnOff( );
        }*/
		
		//printHEX( "NIIP", m_niip.c_str( ), m_niip.length( ) );
		
		//Extracting message type
		unsigned int l_msgTypeSize = this->calculateSize( 4, m_iso8583Properties.messageTypeDataType( ) );
		if ( l_msgTypeSize > a_specific.length( ) - l_current )
		{
			this->setHasError( true );
			this->setErrorMessage( "Invalid input size" );
			return false;
		}
		std::string l_msgType = a_specific.substr( l_current, l_msgTypeSize );
		this->convertToAscii( m_msgType, l_msgType, m_iso8583Properties.messageTypeDataType( ) );
		l_current += l_msgTypeSize;
		m_msgTypeAccess.field( ).input( m_msgType );
		m_msgTypeAccess.field( ).turnOn( );
		//Extracting First bitmap
		unsigned int l_firstBitmapSize = this->calculateSize( 16, m_iso8583Properties.bitmapsDataType( ) );
		if ( l_firstBitmapSize > a_specific.length( ) - l_current )
		{
			this->setHasError( true );
			this->setErrorMessage( "Invalid input size" );
			return false;
		}
		std::string l_firstBitmap = a_specific.substr( l_current, l_firstBitmapSize );
		this->convertToHEX( m_firstBitmap, sizeof m_firstBitmap, l_firstBitmap, m_iso8583Properties.bitmapsDataType( ) );
		l_current += l_firstBitmapSize;
		if ( !this->loadBitmap( m_firstBitmap, sizeof m_firstBitmap, 1 ) )
		{
			this->setHasError( true );
			this->setErrorMessage( "Internal error extracting bitmap( 1 )" );
			return false;
		}
		m_hasSecondBitmapPart = m_dequeBitsOn.size( ) > 0 && m_dequeBitsOn[0] == 1;
		//Extracting Second bitmap if any.
		if ( m_hasSecondBitmapPart )
		{
			unsigned int l_secondBitmapSize = this->calculateSize( 16, m_iso8583Properties.bitmapsDataType( ) );
			if ( l_secondBitmapSize > a_specific.length( ) - l_current )
			{
				this->setHasError( true );
				this->setErrorMessage( "Invalid input size" );
				return false;
			}
			std::string l_secondBitmap = a_specific.substr( l_current, l_secondBitmapSize );
			this->convertToHEX( m_secondBitmap, sizeof m_secondBitmap, l_secondBitmap, m_iso8583Properties.bitmapsDataType( ) );
			l_current += l_secondBitmapSize;
			if ( !this->loadBitmap( m_secondBitmap, sizeof m_secondBitmap, 2 ) )
			{
				this->setHasError( true );
				this->setErrorMessage( "Internal error extracting bitmap( 2 )" );
				return false;
			}
		}
		//Extracting DataElementsSegment
		unsigned int l_dataElementsSize = a_specific.length( ) - l_current;
		if ( a_specific.length( ) < l_current )
		{
			this->setHasError( true );
			this->setErrorMessage( "Invalid input size" );
			return false;
		}
		m_dataElements = a_specific.substr( l_current, l_dataElementsSize );
		return true;
	}
	unsigned int Iso8583IntellinacParser::convertToHEX( unsigned char* a_hex, unsigned int a_hexSize, const std::string& a_input, DataCoding a_dataCoding )
	{
		unsigned int l_ret = 0;
		switch ( a_dataCoding )
		{
			case EBCDIC:
			{
				unsigned int l_asciiLen =
				TextConv::ebcdicToAscii( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				l_ret = TextConv::asciiToHex( a_hex, a_hexSize, m_auxBuffer, l_asciiLen );
			}
			break;
			case ASCII:
			{
				l_ret = TextConv::asciiToHex( a_hex, a_hexSize, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
			}
			break;
			case HEX:
			l_ret = a_hexSize < a_input.length( ) ? a_hexSize : a_input.length( );
			memcpy( a_hex, a_input.data( ), l_ret );
			break;
            case RAW:
			l_ret = a_hexSize < a_input.length( ) ? a_hexSize : a_input.length( );
			memcpy( a_hex, a_input.data( ), l_ret );
			break;
			case BCD:
				l_ret = TextConv::bcdToHex( a_hex, a_hexSize, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
			break;
			default:
				//default
			    break;
		}
		return l_ret;
	}
	bool Iso8583IntellinacParser::loadBitmap( const unsigned char* a_bitmapBuffer, unsigned int a_size, unsigned int a_bitMapNumber )
	{
		if ( a_size < 8
		||( a_bitMapNumber != 1 && a_bitMapNumber != 2 ) )
		{
			return false;
		}
		for ( unsigned int i = 0; i < 8; ++i )
		{
			char l_byte = a_bitmapBuffer[i];
			for ( unsigned int j = 0; j < 8; ++j )
			{
				if ( (
				l_byte & 0x80 ) == 0x80 )
				{
					unsigned int l_bitNum =( i * 8 ) +( j + 1 ) +( 64 *( a_bitMapNumber-1 ) );
					m_dequeBitsOn.push_back( l_bitNum );
				}
				l_byte <<= 1;
			}
		}
		return true;
	}
	unsigned int Iso8583IntellinacParser::calculateSize( unsigned int a_numDigits, DataCoding a_dataCoding )
	{
		unsigned int l_calc = 0;
		if ( a_dataCoding == HEX || a_dataCoding == BCD )
		{
			l_calc = (a_numDigits >> 1) + (a_numDigits % 2);
		}
		else
		{
			l_calc = a_numDigits;
		}
		return l_calc;
	}
	void Iso8583IntellinacParser::convertToAscii( std::string& a_ascii, const std::string& a_input, DataCoding a_dataCoding )
	{
		switch ( a_dataCoding )
		{
			case ASCII:
			a_ascii = a_input;
			break;
			case RAW:
			a_ascii = a_input;
			break;
			case EBCDIC:
			{
				unsigned int l_asciiLen =
				TextConv::ebcdicToAscii( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_ascii.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_asciiLen );
			}
			break;
			case HEX:
			{
				unsigned int l_asciiLen =
				TextConv::hexToAscii( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_ascii.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_asciiLen );
			}
			break;
			case BCD:
			{
				unsigned int l_asciiLen = TextConv::bcdToAscii( m_auxBuffer, m_auxBufferLength, reinterpret_cast<const unsigned char*>( a_input.data( ) ), a_input.length( ) );
				a_ascii.assign( reinterpret_cast<const char*>( m_auxBuffer ), l_asciiLen );
			}
			break;
			default:
				//default
				break;
		}
	}
	bool Iso8583IntellinacParser::initialiseIndexers( )
	{
		const unsigned int l_maxLabelSize = 128;
		char l_label[l_maxLabelSize];
		for ( unsigned int l_deNumber = 0; l_deNumber < m_deCount; ++l_deNumber )
		{
			snprintf( l_label, l_maxLabelSize, "DE%03u", l_deNumber + 1 );
			m_dataElementsAccess[l_deNumber] = fieldSet::FieldAccess( target( ), l_label );
		}
		m_headerAccess	= target( "HEADER" );
        m_tpduAccess	= target( "TPDU" );
		m_mctAccess	    = target( "MERCHANT_TYPE" );
		m_niipAccess	= target( "NIIP" );
		m_msgTypeAccess	= target( "MSG_TYPE" );
		m_isISO8583Access = target( "IS_ISO8583" );
		return true;
	}
	fieldSet::Field& Iso8583IntellinacParser::getDataElement( unsigned int a_deNumber )
	{
		base::genAssert( a_deNumber > 0 && a_deNumber <= m_deCount, __FUNCTION__, "Invalid Data Element Number" );
		return m_dataElementsAccess[a_deNumber-1].field( );
	}
}//namespace msgConv

