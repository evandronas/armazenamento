/* Copyright 2019 Rede S.A.
Autor : Fernando Brum
Empresa : Rede
*/

#pragma once
#include "base/GenException.hpp"
#include "dbaccess_pdv/Tbsw0165.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

using namespace std;

namespace dbaccess_pdv
{
    /// Tbsw0165
    /// Construtor da classe
    /// EF/ET: ET1
    /// Histórico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    Tbsw0165::Tbsw0165( )
    {
        query_fields = "NUM_SEQ_UNC,DAT_MOV_TRAN,ID_FACR_PGMN_BNDR,COD_SMRC,NOM_SMRC,DES_ENDR_SMRC,NOM_CID_SMRC,SGL_EST_SMRC,COD_PAIS_SMRC,NUM_CEP_SMRC,NUM_CNPJ_SMRC";
        table_name = "TBSW0165";
        where_condition = "";
        
        numeroSequencialUnicoPosicao = 1;
        dataMovimentoTransacaoPosicao = 2;
        paymentFacilitatorPosicao = 3;
        codigoSubLojistaPosicao = 4;
        nomeSubLojistaPosicao = 5;
        enderecoSubLojistaPosicao = 6;
        cidadeSubLojistaPosicao = 7;
        estadoSubLojistaPosicao = 8;
        paisSubLojistaPosicao = 9;
        cepSubLojistaPosicao = 10;
        cnpjSubLojistaPosicao = 11;
        
        numeroSequencialUnico = 0;
        dataMovimentoTransacao = 0;
        dbm_longtodec( &paymentFacilitator, 0 );
        codigoSubLojista = "";
        nomeSubLojista = "";
        enderecoSubLojista = "";
        cidadeSubLojista = "";
        estadoSubLojista = "";
        paisSubLojista = "";
        dbm_longtodec( &cepSubLojista, 0 );
        dbm_longtodec( &cnpjSubLojista, 0 );
        
        paymentFacilitatorNulo = DBM_NULL_DATA;
        cepSubLojistaNulo = DBM_NULL_DATA;
        cnpjSubLojistaNulo = DBM_NULL_DATA;
    }

    /// Tbsw0165
    /// Construtor da classe
    /// EF/ET: ET1
    /// Histórico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// whereParam: Clausula where da pesquisa na tabela
    Tbsw0165::Tbsw0165( string whereParam )
    {
        query_fields = "NUM_SEQ_UNC,DAT_MOV_TRAN,ID_FACR_PGMN_BNDR,COD_SMRC,NOM_SMRC,DES_ENDR_SMRC,NOM_CID_SMRC,SGL_EST_SMRC,COD_PAIS_SMRC,NUM_CEP_SMRC,NUM_CNPJ_SMRC";
        table_name = "TBSW0165";
        where_condition = whereParam;

        numeroSequencialUnicoPosicao = 1;
        dataMovimentoTransacaoPosicao = 2;
        paymentFacilitatorPosicao = 3;
        codigoSubLojistaPosicao = 4;
        nomeSubLojistaPosicao = 5;
        enderecoSubLojistaPosicao = 6;
        cidadeSubLojistaPosicao = 7;
        estadoSubLojistaPosicao = 8;
        paisSubLojistaPosicao = 9;
        cepSubLojistaPosicao = 10;
        cnpjSubLojistaPosicao = 11;
        
        numeroSequencialUnico = 0;
        dataMovimentoTransacao = 0;
        dbm_longtodec( &paymentFacilitator, 0 );
        codigoSubLojista = "";
        nomeSubLojista = "";
        enderecoSubLojista = "";
        cidadeSubLojista = "";
        estadoSubLojista = "";
        paisSubLojista = "";
        dbm_longtodec( &cepSubLojista, 0 );
        dbm_longtodec( &cnpjSubLojista, 0 );
        
        paymentFacilitatorNulo = DBM_NULL_DATA;
        cepSubLojistaNulo = DBM_NULL_DATA;
        cnpjSubLojistaNulo = DBM_NULL_DATA;
    }

    /// ~Tbsw0165
    /// Destrutor da classe
    /// EF/ET: ET1
    /// Histórico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    Tbsw0165::~Tbsw0165( )
    {
    }

    /// SetWhereCondition
    /// Atribui valor ao campo where_condition
    /// EF/ET: ET1
    /// Histórico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetWhereCondition( const string& value )
    {
        where_condition = value;
    }

    /// SetQueryFields
    /// Atribui valor ao campo query_fields
    /// EF/ET: ET1
    /// Histórico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetQueryFields( const string& value )
    {
        query_fields = value;
    }

    /// bind_columns
    /// Efetua o bind dos campos da tabela
    /// EF/ET: ET1
    /// Histórico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    void Tbsw0165::bind_columns( )
    {
        bind( dataMovimentoTransacaoPosicao, dataMovimentoTransacao );
        bind( numeroSequencialUnicoPosicao, numeroSequencialUnico );
        bind( paymentFacilitatorPosicao, paymentFacilitator, &paymentFacilitatorNulo );
        bind( codigoSubLojistaPosicao, codigoSubLojista );
        bind( nomeSubLojistaPosicao, nomeSubLojista );
        bind( enderecoSubLojistaPosicao, enderecoSubLojista );
        bind( cidadeSubLojistaPosicao, cidadeSubLojista );
        bind( estadoSubLojistaPosicao, estadoSubLojista );
        bind( paisSubLojistaPosicao, paisSubLojista );
        bind( cepSubLojistaPosicao, cepSubLojista, &cepSubLojistaNulo );
        bind( cnpjSubLojistaPosicao, cnpjSubLojista, &cnpjSubLojistaNulo );
    }
    
    /// clearFields
    /// Efetua a limpeza dos campos
    /// EF/ET: ET1
    /// Histórico: [Data] - ET - Descrição
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    void Tbsw0165::clearFields( )
    {
        numeroSequencialUnico = 0;
        dataMovimentoTransacao = 0;
        dbm_longtodec( &paymentFacilitator, 0 );
        codigoSubLojista = "";
        nomeSubLojista = "";
        enderecoSubLojista = "";
        cidadeSubLojista = "";
        estadoSubLojista = "";
        paisSubLojista = "";
        dbm_longtodec( &cepSubLojista, 0 );
        dbm_longtodec( &cnpjSubLojista, 0 );
        
        paymentFacilitatorNulo = DBM_NULL_DATA;
        cepSubLojistaNulo = DBM_NULL_DATA;
        cnpjSubLojistaNulo = DBM_NULL_DATA;
    }

    /// SetDataMovimentoTransacao
    /// Atribui novo valor ao campo DAT_MOV_TRAN
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido ao campo DAT_MOV_TRAN
    void Tbsw0165::SetDataMovimentoTransacao( const unsigned long value )
    {
        dataMovimentoTransacao = value;
    }    
    /// GetDataMovimentoTransacao
    /// Obtem o valor do campo DAT_MOV_TRAN
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    const unsigned long Tbsw0165::GetDataMovimentoTransacao() const
    {
        return dataMovimentoTransacao;
    }

    /// SetNumeroSequencialUnico
    /// Atribui novo valor ao campo NUM_SEQ_UNC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido ao campo NUM_SEQ_UNC
    void Tbsw0165::SetNumeroSequencialUnico( const unsigned long value )
    {
        numeroSequencialUnico = value;
    }
    /// GetNumeroSequencialUnico
    /// Obtem o valor do campo NUM_SEQ_UNC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 19/11/2018 - Andre Morishita - ET1 - Criacao da versao inicial
    const unsigned long Tbsw0165::GetNumeroSequencialUnico() const
    {
        return numeroSequencialUnico;
    }
    
    /// SetPaymentFacilitator
    /// Atribui novo valor ao campo ID_FACR_PGMN_BNDR
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetPaymentFacilitator( oasis_dec_t value )
    {
        dbm_deccopy( &paymentFacilitator, &value );
        paymentFacilitatorNulo = 0;
    }
    /// GetPaymentFacilitator
    /// Obtem o valor do campo ID_FACR_PGMN_BNDR
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    oasis_dec_t Tbsw0165::GetPaymentFacilitator() const
    {
        return paymentFacilitator;
    }

    /// SetCodigoSubLojista
    /// Atribui novo valor ao campo COD_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetCodigoSubLojista( const string& value )
    {
        codigoSubLojista = value;
    }
    /// GetCodigoSubLojista
    /// Obtem o valor do campo COD_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    const string& Tbsw0165::GetCodigoSubLojista() const
    {
        return codigoSubLojista;
    }
    
    /// SetNomeSubLojista
    /// Atribui novo valor ao campo NOM_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetNomeSubLojista( const string& value )
    {
        nomeSubLojista = value;
    }
    /// GetNomeSubLojista
    /// Obtem o valor do campo NOM_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    const string& Tbsw0165::GetNomeSubLojista() const
    {
        return nomeSubLojista;
    }
    
    /// SetEnderecoSubLojista
    /// Atribui novo valor ao campo DES_ENDR_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetEnderecoSubLojista( const string& value )
    {
        enderecoSubLojista = value;
    }
    /// GetEnderecoSubLojista
    /// Obtem o valor do campo DES_ENDR_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    const string& Tbsw0165::GetEnderecoSubLojista() const
    {
        return enderecoSubLojista;
    }

    /// SetCidadeSubLojista
    /// Atribui novo valor ao campo NOM_CID_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetCidadeSubLojista( const string& value )
    {
        cidadeSubLojista = value;
    }
    /// GetCidadeSubLojista
    /// Obtem o valor do campo NOM_CID_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    const string& Tbsw0165::GetCidadeSubLojista() const
    {
        return cidadeSubLojista;
    }
    
    /// SetEstadoSubLojista
    /// Atribui novo valor ao campo SGL_EST_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetEstadoSubLojista( const string& value )
    {
        estadoSubLojista = value;
    }
    /// GetEstadoSubLojista
    /// Obtem o valor do campo SGL_EST_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    const string& Tbsw0165::GetEstadoSubLojista() const
    {
        return estadoSubLojista;
    }
    
    /// SetPaisSubLojista
    /// Atribui novo valor ao campo COD_PAIS_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetPaisSubLojista( const string& value )
    {
        paisSubLojista = value;
    }
    /// GetPaisSubLojista
    /// Obtem o valor do campo COD_PAIS_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    const string& Tbsw0165::GetPaisSubLojista() const
    {
        return paisSubLojista;
    }
    
    /// SetCepSubLojista
    /// Atribui novo valor ao campo NUM_CEP_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetCepSubLojista( oasis_dec_t value )
    {
        dbm_deccopy( &cepSubLojista, &value );
        cepSubLojistaNulo = 0;
    }
    /// GetCepSubLojista
    /// Obtem o valor do campo NUM_CEP_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    oasis_dec_t Tbsw0165::GetCepSubLojista() const
    {
        return cepSubLojista;
    }
    
    /// SetCnpjSubLojista
    /// Atribui novo valor ao campo NUM_CNPJ_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void Tbsw0165::SetCnpjSubLojista( oasis_dec_t value )
    {
        dbm_deccopy( &cnpjSubLojista, &value );
        cnpjSubLojistaNulo = 0;
    }
    /// GetCnpjSubLojista
    /// Obtem o valor do campo NUM_CNPJ_SMRC
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 28/08/2019 - Fernando Brum - ET1 - Criacao da versao inicial
    oasis_dec_t Tbsw0165::GetCnpjSubLojista() const
    {
        return cnpjSubLojista;
    }
    
} //namespace dbaccess_pdv
