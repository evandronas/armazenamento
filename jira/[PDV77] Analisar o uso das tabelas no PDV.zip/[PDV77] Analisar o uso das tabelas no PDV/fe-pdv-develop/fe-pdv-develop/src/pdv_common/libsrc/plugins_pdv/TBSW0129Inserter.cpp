#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0129Inserter.hpp"
#include "dbaccess_pdv/TBSW0129RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0129Inserter( )
    {
        TBSW0129Inserter* l_new = new TBSW0129Inserter;
        return( l_new );
    }

    TBSW0129Inserter::TBSW0129Inserter( )
    {
    }

    TBSW0129Inserter::~TBSW0129Inserter( )
    {
    }

    bool TBSW0129Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_source = l_tagList.front( ).findProperty( "value" ).value( );
        this->setSourceFieldPath( l_source );

        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_target = l_tagList.front( ).findProperty( "value" ).value( );
        this->setTargetFieldPath( l_target );

        return( true );
    }

    bool TBSW0129Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =  this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =      this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_local_time =  this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_termid =      this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
        m_termloc =     this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );

        return( true );
    }

    void TBSW0129Inserter::finish( )
    {
    }

    int TBSW0129Inserter::execute( bool& a_stop )
    {
        try
        {

            dbaccess_common::TBSW0129 l_table0129;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0129" );
            dbaccess_pdv::TBSW0129RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0129_params params = { 0 };

            fieldSet::fsextr( params.local_date,    m_local_date );
            fieldSet::fsextr( params.refnum,        m_refnum );
            fieldSet::fsextr( params.local_time,    m_local_time );
            fieldSet::fsextr( params.termid,        m_termid );
            fieldSet::fsextr( params.termloc,       m_termloc );
            params.nom_site_acqr =  std::string( getenv( "NOM_SITE_ACQR" ) );
            params.nom_host_acqr =  std::string( getenv( "NOM_HOST_ACQR" ) );
            params.nom_fe_acqr =    std::string( getenv( "NOM_FE_ACQR" ) );

            regrasFmt.DAT_MOV_TRAN          ( l_table0129, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC           ( l_table0129, params, acq_common::INSERT );
            regrasFmt.DTH_INI_TRAN          ( l_table0129, params, acq_common::INSERT );
            regrasFmt.COD_TERM              ( l_table0129, params, acq_common::INSERT );
            regrasFmt.NUM_ESTB              ( l_table0129, params, acq_common::INSERT );
            regrasFmt.NOM_SITE_ACQR_ORGL    ( l_table0129, params, acq_common::INSERT );
            regrasFmt.NOM_HOST_ACQR_ORGL    ( l_table0129, params, acq_common::INSERT );
            regrasFmt.NOM_FE_ACQR_ORGL      ( l_table0129, params, acq_common::INSERT );

            l_table0129.insert( );
            l_table0129.commit( );

            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "NOT INSERTED", 12 );
            std::string l_msg = "Exception in TBSW0129 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "NOT INSERTED", 12 );
            std::string l_msg = "std::exception in TBSW0129 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }

    TBSW0129Inserter& TBSW0129Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    TBSW0129Inserter& TBSW0129Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0129Inserter::clone( ) const
    {
        return( new TBSW0129Inserter( *this ) );
    }

} // namespace plugins_pdv
