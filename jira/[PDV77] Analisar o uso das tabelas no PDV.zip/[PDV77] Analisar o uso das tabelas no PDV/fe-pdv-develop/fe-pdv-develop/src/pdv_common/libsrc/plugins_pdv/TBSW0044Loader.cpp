#pragma once
#include "plugins_pdv/TBSW0044Loader.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0044Loader( )
    {
        TBSW0044Loader* l_new = new TBSW0044Loader;
        return l_new;
    }

    bool TBSW0044Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        a_tag->findTag( "targetFieldPath", l_tagList );
        m_targetFieldPath = l_tagList.front( ).findProperty( "value" ).value( );
        a_tag->findTag( "sourceFieldPath", l_tagList );
        m_sourceFieldPath = l_tagList.front( ).findProperty( "value" ).value( );

        return (true);
    }

    TBSW0044Loader::TBSW0044Loader( )
    {
    }

    TBSW0044Loader::~TBSW0044Loader( )
    {
    }

    bool TBSW0044Loader::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_pan = this->navigate( m_sourceFieldPath + ".segments.common.orig_pan" );

        return (true);
    }

    void TBSW0044Loader::finish( )
    {
    }

    int TBSW0044Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;

            unsigned long l_termloc;
            fieldSet::fsextr( l_termloc, m_termloc );

            std::string l_pan;
            fieldSet::fsextr( l_pan, m_pan );

            std::stringstream lss_pan;

            lss_pan << std::setw( 19 ) << std::setfill( '0' ) << std::left << l_pan;

            l_whereClause << " NUM_PDV = " << l_termloc;
            l_whereClause << " AND ( " << lss_pan.str( );
            l_whereClause << " BETWEEN NUM_BIN_INI AND NUM_BIN_FIM )";
            l_whereClause << " AND IND_STTU_REG = 'A'";
            
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0044Loader ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );

            dbaccess_common::TBSW0044 l_44Loader( l_whereClause.str() );

            l_44Loader.prepare();
            l_44Loader.execute();
            int ret = l_44Loader.fetch();
            if( ret )
            {
                fieldSet::fscopy( m_result, "OK", 2 );
            }
            else
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }//else
        }//try
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0044Loader <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception  e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0044Loader <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return (0);
    }

    dataManip::Command* TBSW0044Loader::clone( ) const
    {
        return new TBSW0044Loader( *this );
    }
}//namespace plugins_pdv
