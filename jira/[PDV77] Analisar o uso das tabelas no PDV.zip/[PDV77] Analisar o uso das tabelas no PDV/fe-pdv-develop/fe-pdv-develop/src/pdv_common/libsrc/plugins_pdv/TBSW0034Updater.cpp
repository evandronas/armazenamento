#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0034.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0034Updater.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "dbaccess_pdv/TBSW0034RegrasFormatacao.hpp"

namespace plugins_pdv
{
	base::Identificable* createTBSW0034Updater()
	{
		TBSW0034Updater* l_new = new TBSW0034Updater;
		return l_new;
	}

	TBSW0034Updater::TBSW0034Updater()
	{
	}

	TBSW0034Updater::~TBSW0034Updater()
	{
	}

	bool TBSW0034Updater::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;

		a_tag->findTag( "sourceFieldPath", l_tagList );
		this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );

		a_tag->findTag( "targetFieldPath", l_tagList );
		this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

		return true;
	}

	bool TBSW0034Updater::init()
	{
    m_result = this->navigate( m_targetFieldPath + ".RESULT" );

		m_isr_date = this->navigate( m_sourceFieldPath + ".segments.chip.isr_date" );
		m_isr_nsu = this->navigate( m_sourceFieldPath + ".segments.chip.isr_nsu" );
        m_2ndGAC_date = this->navigate( m_sourceFieldPath + ".segments.chip.2ndGAC_date" );
		m_2ndGAC_nsu = this->navigate( m_sourceFieldPath + ".segments.chip.2ndGAC_nsu" );
		m_txt_info_cmpm_chip = this->navigate( m_sourceFieldPath + ".segments.chip.second_gen_ac" );
		m_txt_rstd_atlz_chip = this->navigate( m_sourceFieldPath + ".segments.chip.isr" );
		return true;
	}

	void TBSW0034Updater::finish()
	{
	}

    // Returns true if both NSU and Date are valid for TBSW0034 standards
    //  NSU must not have any alphabetic characters
    //  Date must have 8 digits (YYYYMMDD)
    bool TBSW0034Updater::validateDateNSU(std::string nsu, unsigned long date) {
       
        // less than 8 digits
        if (date < 10000000)
            return false;

        if (nsu.length()) 
            for (int i = 0; i < nsu.length(); i++) {
                if (isalpha(nsu.at(i)))  
                    return false;
            }
        else
            return false;

        return true;
    }

	int TBSW0034Updater::execute( bool& a_stop )
	{
        dbaccess_common::TBSW0034 tbsw0034;
		try
		{
            char debugBuffer[1024] = {0};
            dbaccess_pdv::TBSW0034RegrasFormatacao regrasFormatacao;
            acq_common::tbsw0034_params tbsw0034_params = { 0 };
            
			std::ostringstream l_whereClause;
			unsigned long l_isr_date, l_2ndGAC_date;
            bool l_isSameReg = false;
            bool validISR = false;
            bool valid2ndGAC = false;
            std::string l_txt_info_cmpm_chip, l_isr_nsu, l_2ndGAC_nsu, l_txt_rstd_atlz_chip;
            
            fieldSet::fsextr( l_isr_date, m_isr_date );
			fieldSet::fsextr( l_isr_nsu, m_isr_nsu );
            fieldSet::fsextr( l_2ndGAC_date, m_2ndGAC_date );
			fieldSet::fsextr( l_2ndGAC_nsu, m_2ndGAC_nsu );
            fieldSet::fsextr( l_txt_rstd_atlz_chip, m_txt_rstd_atlz_chip );
            fieldSet::fsextr( l_txt_info_cmpm_chip, m_txt_info_cmpm_chip );
            l_isSameReg = ( l_isr_nsu == l_2ndGAC_nsu ) && ( l_isr_date == l_2ndGAC_date );
            
            // EAK-3434
            // If DE47.010/011 from PDV(pinpad) are not correct we may parse a EMV Tag instead of the NSU/Date, eg: 9F26
            // This validation assures we won't have a fatal error in query because of letters
            // Since "date" is already unsigned-long we don't have to check for letters in it
            validISR = validateDateNSU(l_isr_nsu, l_isr_date);
            valid2ndGAC = validateDateNSU(l_2ndGAC_nsu, l_2ndGAC_date);

            // t689049@FIS - Data: 01/05/2014 - TAGs 010 e 011 sao independentes ..
            // TAG 011 ..
            if(validISR)
            {
                l_whereClause << "DAT_MOV_TRAN = " << l_isr_date << " AND NUM_SEQ_UNC = " << l_isr_nsu;
                
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where [ISR] TBSW0034 ==========" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );

                tbsw0034.setWhereClause( l_whereClause.str() );

                tbsw0034.prepare_for_update();
                tbsw0034.execute();
                int ret = tbsw0034.fetch();
                if( !ret )
                {
                    fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
                }
                else
                {     
                    tbsw0034.let_as_is();
                    if( l_txt_rstd_atlz_chip.length() > 18 )
                        tbsw0034_params.isr = l_txt_rstd_atlz_chip.substr(18);
                    else 
                        tbsw0034_params.isr = "";
                    regrasFormatacao.TXT_RSTD_ATLZ_CHIP( tbsw0034, tbsw0034_params, acq_common::UPDATE );
                    if( l_isSameReg )
                    {
                        if( l_txt_info_cmpm_chip.length() > 18 )
                            tbsw0034_params.second_gen_ac = l_txt_info_cmpm_chip.substr(18);
                        else
                            tbsw0034_params.second_gen_ac = "";
                        regrasFormatacao.TXT_INFO_CMPM_CHIP( tbsw0034, tbsw0034_params, acq_common::UPDATE );
                    }
                    tbsw0034.update();
                }
            } 
            else if (l_txt_rstd_atlz_chip.length()) // Only log error if DE47.011 exists
            {
                snprintf(debugBuffer, sizeof(debugBuffer) - 1, " ISR :: NSU: [%s], Data: [%lu]", l_isr_nsu.c_str(), l_isr_date);
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, " ========= TBSW0034Updater :: NSU/DATA DO ISR (DE047.011) INVALIDOS ==========" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, debugBuffer );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, " ==== DE047.011:" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, l_txt_rstd_atlz_chip.c_str() );
            }

            // TAG 010 ..
            if( !l_isSameReg && valid2ndGAC) 
            {
                l_whereClause.str( "" );
                l_whereClause.clear( );

                l_whereClause << "DAT_MOV_TRAN = " << l_2ndGAC_date << " AND NUM_SEQ_UNC = " << l_2ndGAC_nsu;

                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where [2ndGAC] TBSW0034 ==========" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );

                tbsw0034.setWhereClause( l_whereClause.str() );

                tbsw0034.prepare_for_update();
                tbsw0034.execute();
                int ret = tbsw0034.fetch();
                if( !ret )
                {
                    fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
                }
                else
                {
                    if( l_txt_info_cmpm_chip.length() > 18 )
                        tbsw0034_params.second_gen_ac = l_txt_info_cmpm_chip.substr(18);
                    else
                        tbsw0034_params.second_gen_ac = "";
                    regrasFormatacao.TXT_INFO_CMPM_CHIP( tbsw0034, tbsw0034_params, acq_common::UPDATE );
                    tbsw0034.update();
                }
            }
            else if (!valid2ndGAC && l_txt_info_cmpm_chip.length()) // Only log if DE47.010 exists and is not valid - even if its the same nsu/date
            {
                snprintf(debugBuffer, sizeof(debugBuffer) - 1, " 2ndGAC :: NSU: [%s], Data: [%lu]", l_2ndGAC_nsu.c_str(), l_2ndGAC_date);
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, " ========= TBSW0034Updater :: NSU/DATA DO 2nd GAC (DE047.010) INVALIDOS ==========" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, debugBuffer );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, " ==== DE047.010:" );
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, l_txt_info_cmpm_chip.c_str() );
            }

            if (!validISR && !valid2ndGAC) 
            {
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, " ========= TBSW0034Updater.cpp :: TBSW0034 NAO FOI ALTERADA, TAGS 047.10 e 047.11 INVALIDAS ==========" );
                return 0;
            }

            if( m_result.value().compare( "NOT UPDATED" ) )
            {
				tbsw0034.show(0);
                tbsw0034.commit();
                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
		catch( base::GenException e )
		{
			fieldSet::fscopy( m_result, "ERROR", 5 );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0034 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			fieldSet::fscopy( m_result, "ERROR", 5 );
			std::string l_what( e.what( ) );
			std::string l_msg = "std::exception in TBSW0034 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		a_stop = false;
		return 0;
	}

	TBSW0034Updater& TBSW0034Updater::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	TBSW0034Updater& TBSW0034Updater::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}

	dataManip::Command* TBSW0034Updater::clone() const
	{
		  return new TBSW0034Updater(*this);
	}
}//namespace standardAcqPlugins
