#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "plugins_pdv/TBSW0153Inserter.hpp"
#include "dbaccess_pdv/TBSW0153RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0153Inserter( )
    {
        TBSW0153Inserter* l_new = new TBSW0153Inserter;
        return( l_new );
    }

    TBSW0153Inserter::TBSW0153Inserter( )
    {
    }
    TBSW0153Inserter::~TBSW0153Inserter( )
    {
    }

    bool TBSW0153Inserter::startConfiguration( const configBase::Tag* tagParametro )
    {
        configBase::TagList tagListLocal;
        std::string sourceLocal;

        tagParametro->findTag( "sourceFieldPath", tagListLocal );
        for ( unsigned int contador = 0; contador < tagListLocal.size(); contador++ )
        {
            sourceLocal = tagListLocal.at( contador ).findProperty( "value" ).value();
            if ( sourceLocal == "LOCAL" )
            {
                this->SetLocalFieldPath( sourceLocal );
            }
            else
            {
                this->setSourceFieldPath( sourceLocal );
            }
        }

        tagParametro->findTag( "targetFieldPath", tagListLocal );
        this->setTargetFieldPath( tagListLocal.front( ).findProperty( "value" ).value( ) );

        return( true );
    }

    bool TBSW0153Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =          this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =              this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_cd_ems =              this->navigate( m_sourceFieldPath + ".segments.common.cd_ems" );                //TO DO: remover (descontinuado)
        m_bin =                 this->navigate( m_sourceFieldPath + ".segments.common.bin" );
        m_track2 =              this->navigate( m_sourceFieldPath + ".shc_msg.track2" );
        m_local_time =          this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_ind_mot_aprov_chip =  this->navigate( m_sourceFieldPath + ".segments.voucher.ind_mot_aprov_chip" );
        m_iss_name =            this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );              //TO DO: remover (descontinuado)
        m_cod_emsr =            this->navigate( m_sourceFieldPath + ".segments.common.cod_emsr" );
        numeroRoteamento =      this->navigate( localFieldPath + ".num_rtdr" );

        return( true );
    }

    void TBSW0153Inserter::finish( )
    {
    }

    int TBSW0153Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0153 l_table0153;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0153" );
            dbaccess_pdv::TBSW0153RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0153_params params = { 0 };

            fieldSet::fsextr( params.local_date,            m_local_date );
            fieldSet::fsextr( params.refnum,                m_refnum );
            fieldSet::fsextr( params.cd_ems,                m_cd_ems );
            fieldSet::fsextr( params.bin,                   m_bin );
            fieldSet::fsextr( params.track2,                m_track2 );
            fieldSet::fsextr( params.local_time,            m_local_time );
            fieldSet::fsextr( params.ind_mot_aprov_chip,    m_ind_mot_aprov_chip );
            fieldSet::fsextr( params.iss_name,              m_iss_name );
            fieldSet::fsextr( params.cod_emsr,              m_cod_emsr );
            fieldSet::fsextr( params.num_rtdr,              numeroRoteamento );

            regrasFmt.DAT_MOV_TRAN          ( l_table0153, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC           ( l_table0153, params, acq_common::INSERT );
            regrasFmt.IND_VAL_APR_SLDO_DSPL ( l_table0153, params, acq_common::INSERT );
            regrasFmt.NUM_EMSR              ( l_table0153, params, acq_common::INSERT );
            regrasFmt.NUM_RTDR_TRK          ( l_table0153, params, acq_common::INSERT );
            regrasFmt.DTH_VD_TERM           ( l_table0153, params, acq_common::INSERT );
            regrasFmt.COD_MOT_APRV_OFLN     ( l_table0153, params, acq_common::INSERT );

            l_table0153.insert( );
            l_table0153.commit( );
            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "NOT INSERTED", 12 );
            std::string l_msg = "Exception in TBSW0153 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "NOT INSERTED", 12 );
            std::string l_msg = "std::exception in TBSW0153 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return( 0 );
    }

    TBSW0153Inserter& TBSW0153Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0153Inserter& TBSW0153Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    TBSW0153Inserter& TBSW0153Inserter::SetLocalFieldPath( const std::string& pathParametro )
    {
        localFieldPath = pathParametro;
        return( *this );
    }

    dataManip::Command* TBSW0153Inserter::clone( ) const
    {
        return( new TBSW0153Inserter( *this ) );
    }

} // namespace plugins_pdv
