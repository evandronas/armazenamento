/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0071.hpp"
#include "plugins_pdv/TBSW0071Loader.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
	base::Identificable* createTBSW0071Loader( )
	{
		TBSW0071Loader* l_new = new TBSW0071Loader;
		return l_new;
	}
	bool TBSW0071Loader::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "sourceFieldPath", l_tagList );
		std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "targetFieldPath", l_tagList );
		std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setSourceFieldPath( l_sourcePath );
		this->setTargetFieldPath( l_targetPath );
		return true;
	}
	TBSW0071Loader::TBSW0071Loader( )
	{
	}
	TBSW0071Loader::~TBSW0071Loader( )
	{
	}
	bool TBSW0071Loader::init( )
	{
		std::string tb_components[]
		=
		{
			"RESULT", "NUM_PDV", "COD_STTU_REG", "DAT_ATLZ_REG", "COD_SERV", "NUM_PDV_BCO_ARCD", "TIP_MDLD_PGMN", "COD_BLTO_BCO_ARCD", "VAL_MN_VD", "VAL_MX_SQUE"
		};
		for ( unsigned int i = 0; i < LAST_TB_FIELD; i++ )
		{
			m_targetField[i]
			= this->navigate( m_targetFieldPath + "." + tb_components[i] );
			if ( !m_targetField[i] )
			{
				std::string l_errorMsg( "Field not found <" + m_targetFieldPath + "." + tb_components[i]
				+ ">" );
				this->enableError( true );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		std::string source_components[]
		=
		{
			"shc_msg.termloc", "segments.common.transcode", "segments.common.subtranscode"
		};
		for ( unsigned int i = 0; i < LAST_SOURCE_FIELD; i++ )
		{
			m_sourceField[i]
			= this->navigate( m_sourceFieldPath + "." + source_components[i] );
			if ( !m_sourceField[i] )
			{
				std::string l_errorMsg( "Field not found <" + m_sourceFieldPath + "." + source_components[i]
				+ ">" );
				this->enableError( true );
				this->setErrorMessage( l_errorMsg );
				return false;
			}
		}
		return true;
	}
	void TBSW0071Loader::finish( )
	{
	}
	int TBSW0071Loader::execute( bool& a_stop )
	{
		try
		{
			std::ostringstream l_whereClause;
			long l_num_pdv = 0;
            long l_transcode = 0;
            long l_subtranscode = 0;
            long l_service_code = 0;
			fieldSet::fsextr( l_num_pdv, m_sourceField[TERMLOC] );
            fieldSet::fsextr( l_transcode, m_sourceField[TRANSCODE] );
            fieldSet::fsextr( l_subtranscode, m_sourceField[SUBTRANSCODE] );
            
            switch(l_transcode)
            {
                case 01: 
                    if (l_subtranscode==3)  /* CASHBACK */
                        l_service_code = 304;
                    break;

                case 10:        /*Serasa*/
                    l_service_code = 1;
                    break;

                case 68:        /* confirmation preauthorization */
                case 69:
                case 70:        /* void preauthorization */
                case 72:        /* Preauthorization*/
                case 73:
                case 77:        /* Void Preauthorization */
                case 80:        /* confirmation preauthorization */
                case 81:
                case 105:       /* Preauthorization */
                case 106:       /* Preauthorization */
                    l_service_code = 200;
                    break;

                case 17:        /* AVS transaction */
                    l_service_code = 204;
                    break;

                case 82:        /* Capture Function */
                case 83:
                case 84:
                case 85:
                case 86:
                case 87:
                    l_service_code = 303;
                    break;

                case 89:    /* Crediario Loja */
                    l_service_code = 999;
                    break;

                case 90:    /* FONESHOP */
                case 91:
                case 92:
                case 93:
                case 94:
                    l_service_code = 205;
                    break;
            }
            if ( l_subtranscode == 17 ) l_service_code = 204;

            l_whereClause << "NUM_PDV = " << l_num_pdv << " AND COD_SERV = " << l_service_code;
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0071 ==========" );
            logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );

			dbaccess_common::TBSW0071 l_table0071( l_whereClause.str( ) );
			l_table0071.prepare( );
			l_table0071.execute( );
			int ret = l_table0071.fetch( );
			if ( !ret )
			{
				this->setResult( "NO ROWS" );
			}
			else
			{
				char l_valMnVd[64];
				char l_valMxSque[64];
				oasis_dec_t l_decTmp;
				memset( l_valMnVd, 0, sizeof( l_valMnVd ) );
				memset( l_valMxSque, 0, sizeof( l_valMxSque ) );
				l_decTmp = l_table0071.getVAL_MN_VD( );
				dbm_dectochar( &l_decTmp, l_valMnVd );
				l_decTmp = l_table0071.getVAL_MX_SQUE( );
				dbm_dectochar( &l_decTmp, l_valMxSque );
				setResult( "OK" );
				fieldSet::fscopy( m_targetField[NUM_PDV], l_table0071.getNUM_PDV( ) );
				fieldSet::fscopy( m_targetField[COD_STTU_REG], l_table0071.getCOD_STTU_REG( ) );
				fieldSet::fscopy( m_targetField[DAT_ATLZ_REG], l_table0071.getDAT_ATLZ_REG( ) );
				fieldSet::fscopy( m_targetField[COD_SERV], l_table0071.getCOD_SERV( ) );
				fieldSet::fscopy( m_targetField[NUM_PDV_BCO_ARCD], l_table0071.getNUM_PDV_BCO_ARCD( ) );
				fieldSet::fscopy( m_targetField[TIP_MDLD_PGMN], l_table0071.getTIP_MDLD_PGMN( ) );
				fieldSet::fscopy( m_targetField[COD_BLTO_BCO_ARCD], l_table0071.getCOD_BLTO_BCO_ARCD( ) );
				fieldSet::fscopy( m_targetField[VAL_MN_VD], l_valMnVd );
				fieldSet::fscopy( m_targetField[VAL_MX_SQUE], l_valMxSque );
			}
		}
		catch( base::GenException e )
		{
			this->setResult( "ERROR" );
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0071 <" + l_what + ">";
			this->enableError( true );
			this->setErrorMessage( l_msg );
		}
		catch( std::exception  e )
		{
			std::string l_what( e.what( ) );
			std::string l_msg = "Exception in TBSW0071[" + l_what + "]";
		}
		fieldSet::fscopy( m_targetField[RESULT], getResult( ) );
		a_stop = false;
		return 0;
	}
	std::string TBSW0071Loader::getResult( )
	{
		return m_result;
	}
	TBSW0071Loader& TBSW0071Loader::setResult( const std::string& a_result )
	{
		m_result = a_result;
		return *this;
	}
	TBSW0071Loader& TBSW0071Loader::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	TBSW0071Loader& TBSW0071Loader::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	dataManip::Command* TBSW0071Loader::clone( ) const
	{
		return new TBSW0071Loader( *this );
	}
}//namespace plugins_pdv

