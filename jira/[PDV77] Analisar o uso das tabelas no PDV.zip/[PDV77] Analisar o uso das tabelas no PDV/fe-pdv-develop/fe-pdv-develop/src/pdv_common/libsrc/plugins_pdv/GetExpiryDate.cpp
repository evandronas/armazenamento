/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descri��o: Plugin para parsear o track2
/ Conte�do:
/ Autor: t694450, Lauro Sanches
/ Data de Cria��o: 2013, 28 de maio
/ Hist�rico Mudan�as: 2013, 28 de maio, t694450, Lauro Sanches
/ -------------------------------------------------------------------------------------------------
*/

#pragma once
#include <sstream>
#include <cstring>
#include <security.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "msgConv/TextConv.hpp"
#include "plugins_pdv/GetExpiryDate.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createGetExpiryDate( )
    {
        GetExpiryDate* l_new = new GetExpiryDate;
        return l_new;
    }

    bool GetExpiryDate::startConfiguration( const configBase::Tag* a_tag )
    {
         configBase::TagList l_tagList;
         a_tag->findTag( "sourceFieldPath", l_tagList );
         this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );
         a_tag->findTag( "targetFieldPath", l_tagList );
         this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );
         return true;
    }

    GetExpiryDate::GetExpiryDate( )
    {
    }

    GetExpiryDate::~GetExpiryDate( )
    {
    }

    bool GetExpiryDate::init( )
    {
        m_track2      = this->navigate( m_sourceFieldPath + ".track2" );
        m_track3      = this->navigate( m_sourceFieldPath + ".track3" );
        m_expiry_date = this->navigate( m_targetFieldPath + ".expiry_date" );

        return true;
    }

    void GetExpiryDate::finish( )
    {
    }

    int GetExpiryDate::execute( bool& a_stop )
    {
        try
        {
            /* Extract the needed fields */
            std::string l_track2;
            std::string l_track3;
            std::size_t sepPos;
            
            fieldSet::fsextr( l_track2, m_track2 );
            fieldSet::fsextr( l_track3, m_track3 );

            if ( strlen( l_track2.c_str() ) > 16 )
            {
                sepPos = l_track2.find_first_of("=DF");
                // A trilha 2 pode estar criptografado ainda ..
                //sepPos = l_track2.substr( 16 ).find_first_of("=DF") + 16;
                if ( ( sepPos != std::string::npos ) && ( (sepPos + 5) < strlen(l_track2.c_str()) ) )
                {
                    std::string l_expiry_date = l_track2.substr( sepPos + 1, 4 );
                    fieldSet::fscopy( m_expiry_date, l_expiry_date );
                }
            }
            else
            if ( strlen( l_track3.c_str() ) )
            {
                sepPos = l_track3.find( '^' );
                sepPos = l_track3.find( '^', sepPos + 1 );
                if ( ( sepPos != std::string::npos ) && ( (sepPos + 5) < strlen(l_track3.c_str()) ) )
                {
                    std::string l_expiry_date = l_track3.substr( sepPos + 1, 4 );
                    fieldSet::fscopy( m_expiry_date, l_expiry_date );
                }
            }
        }
        catch( base::GenException e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in GetExpiryDate <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in GetExpiryDate <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    GetExpiryDate& GetExpiryDate::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    GetExpiryDate& GetExpiryDate::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    dataManip::Command* GetExpiryDate::clone( ) const
    {
        return new GetExpiryDate(*this);
    }

}//namespace plugins_pdv
