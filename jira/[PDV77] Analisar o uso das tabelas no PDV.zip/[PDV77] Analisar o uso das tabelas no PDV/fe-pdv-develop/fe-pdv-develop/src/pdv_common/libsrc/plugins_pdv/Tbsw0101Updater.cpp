/* Copyright 2018 Rede S.A.
Autor : Celso Sato
Empresa : FIS
*/
#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "plugins_pdv/Tbsw0101Updater.hpp"
#include "dbaccess_pdv/Tbsw0101RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTbsw0101Updater( )
    {
        Tbsw0101Updater* objetoLocal = new Tbsw0101Updater;
        return objetoLocal;
    }

    Tbsw0101Updater::Tbsw0101Updater( )
    {
    }

    Tbsw0101Updater::~Tbsw0101Updater( )
    {
    }

    /// startConfiguration
    /// Prepara os parametros recebidos na chamada do plugin dentro do XML
    ///  sourceFieldPath: parametros para clausula WHERE 
    ///  targetFieldPath: parametro de retorno da operacao de UPDATE
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0101Updater::startConfiguration( const configBase::Tag* tagParametro )
    {
        configBase::TagList tagListLocal;
        std::string nomeTagLocal;
        
        tagParametro->findTag( "sourceFieldPath", tagListLocal );
        for ( unsigned int i = 0; i < tagListLocal.size( ); i++ )
        {
            nomeTagLocal = tagListLocal.at( i ).findProperty( "value" ).value( );
            if ( nomeTagLocal == "LOCAL" )
            {
                this->SetLocalFieldPath( nomeTagLocal );
            }
            else
            {
                this->SetSourceFieldPath( nomeTagLocal );
            }
        }

        tagParametro->findTag( "targetFieldPath", tagListLocal );
        this->SetTargetFieldPath( tagListLocal.front( ).findProperty( "value" ).value( ) );

        return true;
    }

    /// init
    /// Prepara os parametros de entrada e saida
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    bool Tbsw0101Updater::init( )
    {
        result = this->navigate( targetFieldPath + ".RESULT" );
    
        localDateSource   = this->navigate( sourceFieldPath + ".shc_msg.local_date" );
        refnumSource      = this->navigate( sourceFieldPath + ".shc_msg.refnum" );
        msgtypeSource     = this->navigate( sourceFieldPath + ".shc_msg.msgtype" );
        origDateSource    = this->navigate( sourceFieldPath + ".shc_msg.origdate" );
        origRefnumSource  = this->navigate( sourceFieldPath + ".shc_msg.origrefnum" );

        codigoNivelSegurancaToken      = this->navigate( sourceFieldPath + ".segments.common.tokenAssuranceLevel" );
        codigoReferenciaContaPagamento = this->navigate( sourceFieldPath + ".segments.common.paymentAccountReference" );

        return true;
    }

    void Tbsw0101Updater::finish( )
    {
    }

    /// execute
    /// Efetua o update da TBSW0101, passando no where a 
    ///  DATA e REFNUM da transcao 
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    int Tbsw0101Updater::execute( bool& stopParam )
    {
        try
        {
            // Montando a clausula where
            std::ostringstream  whereClauseLocal;
            unsigned long       msgtypeLocal = 0;
            unsigned long       dataAtualLocal = 0;
            unsigned long       refnumLocal = 0;
            unsigned long       origRefnumLocal = 0;
            unsigned long       origDateLocal = 0;

            fieldSet::fsextr( dataAtualLocal,    localDateSource );
            fieldSet::fsextr( refnumLocal,       refnumSource );
            fieldSet::fsextr( msgtypeLocal,      msgtypeSource );
            fieldSet::fsextr( origRefnumLocal,   origRefnumSource );
            fieldSet::fsextr( origDateLocal,     origDateSource );

            switch ( msgtypeLocal )
            {
                case 110 :
                case 210 :
                case 230 :
                case 410 :
                case 430 :
                    whereClauseLocal << "DAT_MOV_TRAN = " << dataAtualLocal << " AND NUM_SEQ_UNC = " << refnumLocal;
                    break;
                //case 430 :  <= No necessary to modify the original txn - only the current one
                //  whereClauseLocal << "DAT_MOV_TRAN = " << origDateLocal << " AND NUM_SEQ_UNC = " << origRefnumLocal;
                //  break;
                default:
                    fieldSet::fscopy( result, "EMPTY QUERY", 11 );
                    stopParam = false;
                    return 0;
                    break;
            }

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0101 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, whereClauseLocal.str( ).c_str( ) );

            dbaccess_common::TBSW0101 tabela0101Local( whereClauseLocal.str( ) );
            dbaccess_pdv::Tbsw0101RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0101_params paramsTbsw0101 = { 0 };

            tabela0101Local.prepare_for_update( );
            tabela0101Local.execute( );
            int retornoLocal = tabela0101Local.fetch( );
            if( !retornoLocal )
            {
                fieldSet::fscopy( result, "NOT UPDATED", 11 );
            }
            else
            {
                fieldSet::fsextr( paramsTbsw0101.tokenAssuranceLevel     , codigoNivelSegurancaToken );
                fieldSet::fsextr( paramsTbsw0101.paymentAccountReference , codigoReferenciaContaPagamento );

                regrasFmt.COD_NVL_SGRA_TKN( tabela0101Local, paramsTbsw0101, acq_common::UPDATE );
                regrasFmt.COD_REF_CTA_PGMN( tabela0101Local, paramsTbsw0101, acq_common::UPDATE );

                tabela0101Local.update( );
                tabela0101Local.commit( );

                fieldSet::fscopy( result, "OK", 2 );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "Exception in TBSW0101 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( result, "ERROR", 5 );
            std::string msgLocal = "std::exception in TBSW0101 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( msgLocal );
        }
        stopParam = false;
        return 0;
    }

    /// SetSourceFieldPath
    /// Define Source FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0101Updater& Tbsw0101Updater::SetSourceFieldPath( const std::string& pathParam )
    {
        sourceFieldPath = pathParam;
        return *this;
    }

    /// SetTargetFieldPath
    /// Define Source FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0101Updater& Tbsw0101Updater::SetTargetFieldPath( const std::string& pathParam )
    {
        targetFieldPath = pathParam;
        return *this;
    }

    /// SetLocalFieldPath
    /// Define Source FieldPath
    /// EF/ET: 000
    /// Historico: 03/05/2018 - 000 - Implementacao inicial
    Tbsw0101Updater& Tbsw0101Updater::SetLocalFieldPath( const std::string& pathParam )
    {
        localFieldPath = pathParam;
        return( *this );
    }

    dataManip::Command* Tbsw0101Updater::clone( ) const
    {
        return new Tbsw0101Updater( *this );
    }
} // namespace plugins_pdv
