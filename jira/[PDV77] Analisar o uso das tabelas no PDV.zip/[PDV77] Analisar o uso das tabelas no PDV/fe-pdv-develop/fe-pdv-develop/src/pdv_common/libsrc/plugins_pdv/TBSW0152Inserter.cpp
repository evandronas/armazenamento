#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0152.hpp"
#include "plugins_pdv/TBSW0152Inserter.hpp"
#include "dbaccess_pdv/TBSW0152RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0152Inserter( )
    {
        TBSW0152Inserter* l_new = new TBSW0152Inserter;            
        return( l_new );
    }
    
    TBSW0152Inserter::TBSW0152Inserter( )
    {
    }
    
    TBSW0152Inserter::~TBSW0152Inserter( )
    {
    }
    
    bool TBSW0152Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        
        return( true );
    }
    
    bool TBSW0152Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_install_num = this->navigate( m_sourceFieldPath + ".segments.common.install_num" );  
        m_install_amt = this->navigate( m_sourceFieldPath + ".segments.credit.install_amt" );
        m_msg_name = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        m_vl_pca_ent = this->navigate( m_sourceFieldPath + ".segments.common.vl_pca_ent" );
        m_iss_name = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );

        return( true );
    }
    
    void TBSW0152Inserter::finish( )
    {
    }
    
    int TBSW0152Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0152 table0152;
            dbaccess_pdv::TBSW0152RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0152_params params = { 0 };

            fieldSet::fsextr( params.local_date,    m_local_date );
            fieldSet::fsextr( params.refnum,        m_refnum );
            fieldSet::fsextr( params.install_num,   m_install_num );
            fieldSet::fsextr( params.msg_name,      m_msg_name );
            fieldSet::fsextr( params.install_amt,   m_install_amt );
            fieldSet::fsextr( params.vl_pca_ent,    m_vl_pca_ent );
            fieldSet::fsextr( params.iss_name,      m_iss_name );

            regrasFmt.DAT_MOV_TRAN              ( table0152, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC               ( table0152, params, acq_common::INSERT );
            regrasFmt.QTD_PRCL                  ( table0152, params, acq_common::INSERT );
            regrasFmt.VAL_PRCL                  ( table0152, params, acq_common::INSERT );
            regrasFmt.VAL_PRCL_ENTR             ( table0152, params, acq_common::INSERT );
            regrasFmt.PRCN_TX_JURO              ( table0152, params, acq_common::INSERT );
            regrasFmt.PRCN_TX_JURO_MES          ( table0152, params, acq_common::INSERT );
            regrasFmt.PRCN_TX_JURO_ANO          ( table0152, params, acq_common::INSERT );
            regrasFmt.PRCN_TX_JURO_MORA         ( table0152, params, acq_common::INSERT );
            regrasFmt.QTD_CICL_CRNC_PRMR_PRCL   ( table0152, params, acq_common::INSERT );

            table0152.insert( );
            table0152.commit( );
            
            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0152 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0152 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return( 0 );
    }
    
    TBSW0152Inserter& TBSW0152Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0152Inserter& TBSW0152Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    
    dataManip::Command* TBSW0152Inserter::clone( ) const
    {
        return( new TBSW0152Inserter( *this ) );
    }

}//namespace standardAcqPlugins
