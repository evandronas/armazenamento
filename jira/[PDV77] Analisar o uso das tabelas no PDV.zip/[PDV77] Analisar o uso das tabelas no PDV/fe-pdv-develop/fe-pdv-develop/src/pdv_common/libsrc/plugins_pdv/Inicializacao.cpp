/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::Inicializacao>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pdv::Inicializacao>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689068, Jos� Augusto T. Gavazza>
/ Data de Cria��o: <2013, 01 de Fevereiro>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ . . .
/ <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <shcdef.h>
#include <stdio.h>
#include <stdlib.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/SeekInitFile.hpp"
#include "plugins_pdv/Inicializacao.hpp"	

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
  base::Identificable* createInicializacao()
  {
    Inicializacao* l_new = new Inicializacao;     
    return l_new;
  }

  Inicializacao::Inicializacao()
  {
  }

  Inicializacao::~Inicializacao()
  {
  }
  
  bool Inicializacao::startConfiguration( const configBase::Tag* a_tag )
  {
    configBase::TagList l_tagList;
    std::string l_source;

    a_tag->findTag( "sourceFieldPath", l_tagList );    
    for ( unsigned int i = 0; i < l_tagList.size(); i++ )
    {
        l_source = l_tagList.at( i ).findProperty( "value" ).value();
        if ( l_source == "INITIALIZATION" )
		{
            this->setInitializationFieldPath( l_source );
		}
        else
		{
            this->setShcMsgFieldPath( l_source );
		}
    }

    a_tag->findTag( "targetFieldPath", l_tagList );
    this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );
        
    return true;
  }
  
  bool Inicializacao::init()
  {
    m_result = this->navigate( m_targetFieldPath + ".result" );
    if( !m_result )
		{
            std::string l_errorMsg( "Invalid field path <" + 
                                    m_targetFieldPath +
                                    ".result>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}    

	m_ecrInitDir = this->navigate( m_initializationFieldPath + ".ecrInitDir" );
    if( !m_ecrInitDir )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_initializationFieldPath +
                                    ".ecrInitDir>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
	m_ecrInitDirTmp = this->navigate( m_initializationFieldPath + ".ecrInitDirTmp" );  
    if( !m_ecrInitDirTmp )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_initializationFieldPath +
                                    ".ecrInitDirTmp>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}

	m_de48 = this->navigate( m_shcmsgFieldPath + ".segments.common.bit48" );
    if( !m_de48 )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".segments.common.bit48>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
    m_de48Len = this->navigate( m_shcmsgFieldPath + ".segments.common.bit48len" );
    if( !m_de48Len )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".segments.common.m_de48Len>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}         
    m_termloc = this->navigate( m_shcmsgFieldPath + ".shc_msg.termloc" );
    if( !m_termloc )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".shc_msg.termloc>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
	m_termid = this->navigate( m_shcmsgFieldPath + ".shc_msg.termid" );
    if( !m_termid )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".shc_msg.termid>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
	m_verid = this->navigate( m_shcmsgFieldPath + ".segments.common.ecr_sftw_verid" );
    if( !m_verid )
		{
			std::string l_errorMsg( "Invalid field path <" + 
                                    m_shcmsgFieldPath +
                                    ".segments.common.ecr_sftw_verid>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		} 
    
    return true;
  }

  void Inicializacao::finish()
  {
  }

  int Inicializacao::execute( bool& a_stop )
  {
	std::string l_de48;
	std::string l_data;	
	int l_msgSeq = 0;	



	fieldSet::fsextr( l_de48, m_de48 );

	std::string l_de48Indicator = l_de48.substr(0, 2);
	//std::string l_currentVersion = l_de48.substr(2,10);

	SeekInitFile l_seekInitFile;	

	// bit48 brings the last message sequence that was sent if the case
	l_msgSeq = atoi(l_de48.substr(3, 3).c_str());

	if(l_de48.compare("") != 0 && l_de48Indicator.compare("IN") == 0)
	{
		std::string l_line;
		std::string l_ddmmaaaass;	


		std::string l_buf, l_verid, l_termid, l_termloc, l_ecrInitDir, l_ecrInitDirTmp;

		char l_tmp[17];
		memset(l_tmp,0,17);
		sprintf(l_tmp, "%-16s", l_de48.c_str());
		l_de48 = l_tmp;

		fieldSet::fsextr( l_ecrInitDir, m_ecrInitDir );
		fieldSet::fsextr( l_ecrInitDirTmp, m_ecrInitDirTmp );
		fieldSet::fsextr( l_verid, m_verid );
		fieldSet::fsextr( l_termid, m_termid );
		fieldSet::fsextr( l_termloc, m_termloc );

		if (l_seekInitFile.seekFile( l_ecrInitDir, l_ecrInitDirTmp, l_verid, l_termid, l_termloc) < 0)
		{
		
			//memset(aux,0,sizeof(aux));
			//sprintf ( aux, " \n *******    ARQUIVO 1 = %s   ******* \n ",  l_tmp);		
			logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "\n ************** NAO ACHOU NENHUM ARQUIVO ******************* \n " );		
		
			fieldSet::fscopy( m_result, "ERROR", 5 );		
		
			l_de48[2] = 'F';   // Set the status "final message" 
		}
		else
		{
			std::ifstream l_file(l_seekInitFile.getCurrentInitInfoFileName().c_str());
			if( l_file.is_open() == 0 )
            {
				fieldSet::fscopy( m_result, "ERROR", 5 );				


				a_stop = false;
				return 0;
            }
			else
			{
				//First record: '*VER*ddmmaaaass' identifying init table version
				while(1)
				{
					std::getline(l_file, l_buf);
					if( l_buf.compare("") == 0 )
					{
						l_file.close();
						fieldSet::fscopy( m_result, "ERROR", 5 );
						
						a_stop = false;
						return 0;
					}
					// Ignore comment line
					if(l_buf[0] != '#')
					{
						break;
					}

					if(l_buf.compare(0, 5, "*VER*") == 0)
					{
						break;
					}
				}

				l_ddmmaaaass = l_buf.substr(5, 10);
				
				int l_num_msgs = 0;
				int l_data_len = 0;
				std::string l_tbl_type = "";
				std::string l_buf = "";

				while(1)
				{
					std::getline(l_file, l_buf);
					if(l_buf.compare("") == 0)
					{
						break;
					}

					if( l_buf[0] == '#')          // Ignore comment line
					{
						continue;
					}
					
					if( l_buf[l_buf.length()-1] == '\x0a')     // Slash out LF 
					{
						l_buf[l_buf.length()-1] = '\0';
					}

					if( l_tbl_type.compare("") == 0)       // <-- 1st time - save the table type
					{
						l_tbl_type = l_buf.substr(0, 2);

						l_data = l_buf;
						
						continue;
					}
					else if( l_buf.substr(0, 2).compare(l_tbl_type) > 0) // <-- Table type break
					{
						l_num_msgs++;                     // Count one sent/to-send msg
						l_tbl_type = l_buf.substr(0, 2);
					}
					else if( ( l_data.length() + l_buf.length()) + 16 <= 880) // The same table type - verify data len; 880 = de63 max length; 16 for the DE48 w/o the message
					{
						l_data.append(l_buf);
						continue;
					}
					else                            // <-- Had already fulfilled one msg
					{
						l_num_msgs++;                 // Count one sent/to-send msg
					}

					// Check if the number of sent messages & next block have reached
					if( l_num_msgs > l_msgSeq)
					{
						break;
					}
					else
					{
						l_data = l_buf;
					}
				}

				// If have not reached the next block nor the sent number of msgs
				if( l_num_msgs <= l_msgSeq)
				{
					if( !l_data.length() || l_num_msgs < l_msgSeq)
					{
						l_file.close();
						fieldSet::fscopy( m_result, "ERROR", 5 );
								
						a_stop = false;
						return 0;
					}
				}

				if( !l_file.eof())//!( feof( initfd))
				{
					if( l_buf.compare(0, 5, "*VER*") != 0) // Not the former version set of tables
					{
						if( !l_file.eof())//is_not_feof( initfd, buf)
						{
							l_de48[2] = 'A';  // Set the status "on process"
							fieldSet::fscopy( m_result, "PROCESSING", 10 );
						}
						else
						{
							l_de48[2] = 'F';  // Set the status "final message"
							fieldSet::fscopy( m_result, "FINISH", 6 );
						}
					}
					else
					{
						l_de48[2] = 'F';  // Set the status "final message"
						fieldSet::fscopy( m_result, "FINISH", 6 );
					}
				}
				else
				{                

					l_de48[2] = 'F';      // Set the status "final message"
					fieldSet::fscopy( m_result, "FINISH", 6 );
				}

				//close file 
				l_file.close();
			}
		}

		// Add 1 to the message sequence number
		l_msgSeq++;
		sprintf( l_tmp, "%03d", l_msgSeq);
		l_de48[3] = l_tmp[0];
		l_de48[4] = l_tmp[1];
		l_de48[5] = l_tmp[2];

		// Put the version id of tables
		l_de48 = l_de48.substr(0,6);
		l_de48.append(l_ddmmaaaass);
                
        l_de48.append(l_data);

		fieldSet::fscopy( m_de48, l_de48);

        fieldSet::fscopy( m_de48Len, l_de48.length() );
	}

    a_stop = false;
    return 0;
  }

  Inicializacao& Inicializacao::setShcMsgFieldPath( const std::string& a_path )
  {
    m_shcmsgFieldPath = a_path;

    return *this;
  }
  
  Inicializacao& Inicializacao::setTargetFieldPath( const std::string& a_path )
  {
    m_targetFieldPath = a_path;
    return *this;
  }
  
  Inicializacao& Inicializacao::setInitializationFieldPath( const std::string& a_path )
  {
    m_initializationFieldPath = a_path;
    return *this;
  }
  
  dataManip::Command* Inicializacao::clone() const
  {
    return new Inicializacao(*this);
  }
  
}//namespace plugins_pdv

