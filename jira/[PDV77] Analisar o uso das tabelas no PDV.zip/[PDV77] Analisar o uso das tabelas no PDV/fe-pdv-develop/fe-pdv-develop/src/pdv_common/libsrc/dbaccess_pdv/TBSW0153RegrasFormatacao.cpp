#include <dbaccess_pdv/TBSW0153RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    TBSW0153RegrasFormatacao::TBSW0153RegrasFormatacao( )
    {
    }

    TBSW0153RegrasFormatacao::~TBSW0153RegrasFormatacao( )
    {
    }
    
    void TBSW0153RegrasFormatacao::update_VAL_EFTV_APRV( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
    {
        oasis_dec_t dectLocal;
        if( ( params.pb_reason_code == 87 ) && ( atoi( params.respcode.c_str( ) ) == 0 ) )
        {
            dbm_chartodec( &dectLocal, params.aval_balance.c_str( ), 0 );
        }
        else
        {
            dbm_chartodec( &dectLocal, "0", 0 );
        }
        tbsw0153.set_VAL_EFTV_APRV( dectLocal );
    }
    
    void TBSW0153RegrasFormatacao::update_IND_VAL_APR_SLDO_DSPL( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
    {
        tbsw0153.set_IND_VAL_APR_SLDO_DSPL( params.pb_reason_code == 87 ? "S" : "N" );
    }
}