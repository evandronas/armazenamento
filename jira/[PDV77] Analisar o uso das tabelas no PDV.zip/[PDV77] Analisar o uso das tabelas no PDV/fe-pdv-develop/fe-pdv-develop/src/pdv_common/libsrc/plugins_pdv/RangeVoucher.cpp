/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: .
/ Data de Cria��o: .
/ Hist�rico Mudan�as: ., Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "plugins_pdv/RangeVoucher.hpp"

namespace plugins_pdv
{
	RangeVoucher::RangeVoucher()
	{
	}
	RangeVoucher::~RangeVoucher()
	{
	}

	//--------------------------- GET ---------------------------
    // TBSW0113
    const std::string& RangeVoucher::get_COD_STTU_REG() const
    {
        return m_COD_STTU_REG;
    }
    unsigned long RangeVoucher::get_NUM_RTDR() const
    {
        return m_NUM_RTDR;
    }
    unsigned long RangeVoucher::get_COD_SBPD() const
    {
        return m_COD_SBPD;
    }
    unsigned long RangeVoucher::get_COD_EMSR() const
    {
        return m_COD_EMSR;
    }
    const std::string& RangeVoucher::get_NOM_EMSR() const
    {
        return m_NOM_EMSR;
    }
    unsigned long RangeVoucher::get_COD_TRAN_GE() const
    {
        return m_COD_TRAN_GE;
    }
    const std::string& RangeVoucher::get_NOM_PROD_CPOM() const
    {
        return m_NOM_PROD_CPOM;
    }
    const std::string& RangeVoucher::get_TXT_RDPE_CPOM() const
    {
        return m_TXT_RDPE_CPOM;
    }
    const std::string& RangeVoucher::get_COD_USR_ATLZ_REG() const
    {
        return m_COD_USR_ATLZ_REG;
    }
    dbm_datetime_t RangeVoucher::get_DAT_ATLZ_REG() const
    {
        return m_DAT_ATLZ_REG;
    }
    dbm_datetime_t RangeVoucher::get_DAT_ATVC_VOCH() const
    {
        return m_DAT_ATVC_VOCH;
    }
    const std::string& RangeVoucher::get_NTWKID() const
    {
        return m_NTWKID;
    }
    unsigned long RangeVoucher::get_NUM_BIN() const
    {
        return m_NUM_BIN;
    }
    // TBSW2011
    unsigned long RangeVoucher::get_COD_ISSR_SW() const
    {
        return m_COD_ISSR_SW;
    }
    const std::string& RangeVoucher::get_NOM_EMSR_SW( ) const
    {
        return m_NOM_EMSR_SW;
    }
    long RangeVoucher::get_COD_EMSR_SW( ) const
    {
        return m_COD_EMSR_SW;
    }
    long RangeVoucher::get_COD_BNDR( ) const
    {
        return m_COD_BNDR;
    }
    long RangeVoucher::get_COD_FE_EMSR( ) const
    {
        return m_COD_FE_EMSR;
    }

    bool RangeVoucher::getIS_VALID() const
    {
        return m_IS_VALID;
    }

	//--------------------------- SET ---------------------------
    // TBSW0113
    void RangeVoucher::set_COD_STTU_REG( const std::string&  a_COD_STTU_REG )
    {
        m_COD_STTU_REG = a_COD_STTU_REG;
    }
    void RangeVoucher::set_NUM_RTDR( unsigned long  a_NUM_RTDR )
    {
        m_NUM_RTDR = a_NUM_RTDR;
    }
    void RangeVoucher::set_COD_SBPD( unsigned long a_COD_SBPD )
    {
        m_COD_SBPD = a_COD_SBPD;
    }
    void RangeVoucher::set_COD_EMSR( unsigned long a_COD_EMSR )
    {
        m_COD_EMSR = a_COD_EMSR;
    }
    void RangeVoucher::set_NOM_EMSR( const std::string& a_NOM_EMSR )
    {
        m_NOM_EMSR = a_NOM_EMSR;
    }
    void RangeVoucher::set_COD_TRAN_GE( unsigned long a_COD_TRAN_GE )
    {
        m_COD_TRAN_GE = a_COD_TRAN_GE;
    }
    void RangeVoucher::set_NOM_PROD_CPOM( const std::string& a_NOM_PROD_CPOM )
    {
        m_NOM_PROD_CPOM = a_NOM_PROD_CPOM;
    }
    void RangeVoucher::set_TXT_RDPE_CPOM( const std::string& a_TXT_RDPE_CPOM )
    {
        m_TXT_RDPE_CPOM = a_TXT_RDPE_CPOM;
    }
    void RangeVoucher::set_COD_USR_ATLZ_REG( const std::string& a_COD_USR_ATLZ_REG )
    {
        m_COD_USR_ATLZ_REG = a_COD_USR_ATLZ_REG;
    }
    void RangeVoucher::set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
    {
        m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    void RangeVoucher::set_DAT_ATVC_VOCH( dbm_datetime_t a_DAT_ATVC_VOCH )
    {
        m_DAT_ATVC_VOCH = a_DAT_ATVC_VOCH;
    }
    void RangeVoucher::set_NTWKID( const std::string& a_NTWKID )
    {
        m_NTWKID = a_NTWKID;
    }
    void RangeVoucher::set_NUM_BIN( unsigned long a_NUM_BIN )
    {
        m_NUM_BIN = a_NUM_BIN;
    }
    // TBSW2011
    void RangeVoucher::set_COD_ISSR_SW( unsigned long a_COD_ISSR_SW )
    {
        m_COD_ISSR_SW = a_COD_ISSR_SW;
    }
    void RangeVoucher::set_NOM_EMSR_SW( const std::string& a_NOM_EMSR_SW )
    {
        m_NOM_EMSR_SW = a_NOM_EMSR_SW;
    }
    void RangeVoucher::set_COD_EMSR_SW( long a_COD_EMSR_SW )
    {
        m_COD_EMSR_SW = a_COD_EMSR_SW;
    }
    void RangeVoucher::set_COD_BNDR( long a_COD_BNDR )
    {
        m_COD_BNDR = a_COD_BNDR;
    }
    void RangeVoucher::set_COD_FE_EMSR( long a_COD_FE_EMSR )
    {
        m_COD_FE_EMSR = a_COD_FE_EMSR;
    }
    
	void RangeVoucher::setIS_VALID( bool a_boolean )
	{
		m_IS_VALID = a_boolean;
	}

}

