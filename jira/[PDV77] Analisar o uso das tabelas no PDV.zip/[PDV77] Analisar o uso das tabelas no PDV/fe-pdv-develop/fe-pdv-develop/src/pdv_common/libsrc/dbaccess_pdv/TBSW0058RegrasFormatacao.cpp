#include<dbaccess_pdv/TBSW0058RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
	TBSW0058RegrasFormatacao::TBSW0058RegrasFormatacao( )
	{
	}

	TBSW0058RegrasFormatacao::~TBSW0058RegrasFormatacao( )
	{
	}

    void TBSW0058RegrasFormatacao::insert_IND_RD_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
    {
        tbsw0058.set_IND_RD_CPTR( "2" );
    }
}
