/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descrição:
/ Conteúdo:
/ Autor: t694530, Iuri Fabiano Martins
/ Data de Criação: 2014, 04 de Fevereiro
/ Histórico Mudanças: 2014, 04 de Fevereiro, t694530, Iuri Fabiano Martins, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include <ctime>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/GetGMTDate.hpp"
#include "logger/DebugWriter.hpp"


namespace plugins_pdv
{
	base::Identificable* createGetGMTDate( )
	{
		GetGMTDate* l_new = new GetGMTDate;
		return l_new;
	}
	GetGMTDate::GetGMTDate( )
	{
	}
	GetGMTDate::~GetGMTDate( )
	{
	}
	bool GetGMTDate::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "targetFieldPath", l_tagList );
		std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setTargetFieldPath( l_targetPath );
		return true;
	}
	bool GetGMTDate::init( )
	{
		
		m_targetFieldDate = this->navigate( m_targetFieldPath + ".shc_msg.trandate" );
		m_targetFieldTime = this->navigate( m_targetFieldPath + ".shc_msg.trantime" );
		
		return true;
	}
	void GetGMTDate::finish( )
	{
	}
	int GetGMTDate::execute( bool& a_stop )
	{
		char buff[500];
		struct tm *ptm, gmt_time;
		time_t t;
		std::string l_date, l_time;

		t = time(NULL);
		ptm = gmtime(&t);
		
		memcpy( &gmt_time, ptm, sizeof(gmt_time) );
		
		sprintf( buff, "%02d%02d%02d"	, gmt_time.tm_year +1900, gmt_time.tm_mon +1, gmt_time.tm_mday );
		l_date = buff;
		sprintf( buff, "%02d%02d%02d"	, gmt_time.tm_hour, gmt_time.tm_min, gmt_time.tm_sec );
		l_time = buff;
		
		fieldSet::fscopy( m_targetFieldDate, l_date );
		fieldSet::fscopy( m_targetFieldTime, l_time );
		
		a_stop = false;
		return 0;
	}
    
	GetGMTDate& GetGMTDate::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	dataManip::Command* GetGMTDate::clone( ) const
	{
		return new GetGMTDate( *this );
	}
	
	/*void GetGMTDate::setNewGMTDate( const std::string& a_newPan )
	{
		int posF, posD, posI, posC, pos =19;
		char srv_cd[30];
	
		posD = a_newPan.find("D");
		posF = a_newPan.find("F");
		posI = a_newPan.find("=");
		posC = a_newPan.find("^");
		
		if( (posD != std::string::npos) && ( posD < pos ) ) {
            pos = posD;
		}
		else if( (posI != std::string::npos) && ( posI < pos ) ) {
            pos = posI;
		}
		if( (posF != std::string::npos) && ( posF < pos ) ) {
            pos = posF;
			
		}
		if( (posC != std::string::npos) && ( posC < pos ) ) {
			pos = posC;
		}

		strncpy(srv_cd, a_newPan.c_str(), pos);
		srv_cd[pos]=0;
	
		this->setTargetFieldPath( std::string(srv_cd) );
		fieldSet::fscopy( m_targetField, m_targetFieldPath );
	}
	*/
}//namespace plugins_pdv

