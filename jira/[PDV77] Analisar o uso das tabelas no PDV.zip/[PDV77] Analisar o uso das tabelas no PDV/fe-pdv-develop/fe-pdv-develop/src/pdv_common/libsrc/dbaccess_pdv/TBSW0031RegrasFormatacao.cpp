#include <dbaccess_pdv/TBSW0031RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    TBSW0031RegrasFormatacao::TBSW0031RegrasFormatacao( )
    {
    }

    TBSW0031RegrasFormatacao::~TBSW0031RegrasFormatacao( )
    {
    }
}
