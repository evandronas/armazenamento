#pragma once
#include <cstdio>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/DEsEnviados.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <iostream>

using namespace std;

namespace plugins_pos
{
    base::Identificable* createDEsEnviados( )
    {
        DEsEnviados* l_new = new DEsEnviados;
        return( l_new );
    }

    DEsEnviados::DEsEnviados( )
    {
    }

    DEsEnviados::~DEsEnviados( )
    {
    }
    
    std::string DEsEnviados::obterTag(std::string de)
    {
        std::string retorno = "";
        
        int comeco = de.find('.');
        int fim = de.find('[');
        
        if(comeco!=-1)
        {        
            if(fim==-1)
            {
                retorno = de.substr(comeco+1,de.length()-(comeco+1));
            }
            else
            {
                retorno = de.substr(comeco+1,fim-(comeco+1));
            }
        }
        
        return retorno;
    }
   
    
   
    int DEsEnviados::execute( bool& a_stop )
    {
        std::string l_listaDEsValidar;
        std::string arrayDEsLista[128];
        std::string arrayCondicoes[354];

       try
        {                                                           
            fieldSet::fsextr( arrayCondicoes[1], m_COND001 );
            fieldSet::fsextr( arrayCondicoes[2], m_COND002 );
            fieldSet::fsextr( arrayCondicoes[3], m_COND003 );
            fieldSet::fsextr( arrayCondicoes[4], m_COND004 );
            fieldSet::fsextr( arrayCondicoes[5], m_COND005 );
            fieldSet::fsextr( arrayCondicoes[6], m_COND006 );
            fieldSet::fsextr( arrayCondicoes[7], m_COND007 );
            fieldSet::fsextr( arrayCondicoes[8], m_COND008 );
            fieldSet::fsextr( arrayCondicoes[9], m_COND009 );
            fieldSet::fsextr( arrayCondicoes[10], m_COND010 );
            fieldSet::fsextr( arrayCondicoes[11], m_COND011 );
            fieldSet::fsextr( arrayCondicoes[12], m_COND012 );
            fieldSet::fsextr( arrayCondicoes[13], m_COND013 );
            fieldSet::fsextr( arrayCondicoes[14], m_COND014 );
            fieldSet::fsextr( arrayCondicoes[15], m_COND015 );
            fieldSet::fsextr( arrayCondicoes[16], m_COND016 );
            fieldSet::fsextr( arrayCondicoes[17], m_COND017 );
            fieldSet::fsextr( arrayCondicoes[18], m_COND018 );
            fieldSet::fsextr( arrayCondicoes[19], m_COND019 );
            fieldSet::fsextr( arrayCondicoes[20], m_COND020 );
            fieldSet::fsextr( arrayCondicoes[21], m_COND021 );
            fieldSet::fsextr( arrayCondicoes[22], m_COND022 );
            fieldSet::fsextr( arrayCondicoes[23], m_COND023 );
            fieldSet::fsextr( arrayCondicoes[24], m_COND024 );
            fieldSet::fsextr( arrayCondicoes[25], m_COND025 );
            fieldSet::fsextr( arrayCondicoes[26], m_COND026 );
            fieldSet::fsextr( arrayCondicoes[27], m_COND027 );
            fieldSet::fsextr( arrayCondicoes[28], m_COND028 );
            fieldSet::fsextr( arrayCondicoes[29], m_COND029 );
            fieldSet::fsextr( arrayCondicoes[30], m_COND030 );
            fieldSet::fsextr( arrayCondicoes[31], m_COND031 );
            fieldSet::fsextr( arrayCondicoes[32], m_COND032 );
            fieldSet::fsextr( arrayCondicoes[33], m_COND033 );
            fieldSet::fsextr( arrayCondicoes[34], m_COND034 );
            fieldSet::fsextr( arrayCondicoes[35], m_COND035 );
            fieldSet::fsextr( arrayCondicoes[36], m_COND036 );
            fieldSet::fsextr( arrayCondicoes[37], m_COND037 );
            fieldSet::fsextr( arrayCondicoes[38], m_COND038 );
            fieldSet::fsextr( arrayCondicoes[39], m_COND039 );
            fieldSet::fsextr( arrayCondicoes[40], m_COND040 );
            fieldSet::fsextr( arrayCondicoes[41], m_COND041 );
            fieldSet::fsextr( arrayCondicoes[42], m_COND042 );
            fieldSet::fsextr( arrayCondicoes[43], m_COND043 );
            fieldSet::fsextr( arrayCondicoes[44], m_COND044 );
            fieldSet::fsextr( arrayCondicoes[45], m_COND045 );
            fieldSet::fsextr( arrayCondicoes[46], m_COND046 );
            fieldSet::fsextr( arrayCondicoes[47], m_COND047 );
            fieldSet::fsextr( arrayCondicoes[48], m_COND048 );
            fieldSet::fsextr( arrayCondicoes[49], m_COND049 );
            fieldSet::fsextr( arrayCondicoes[50], m_COND050 );
            fieldSet::fsextr( arrayCondicoes[51], m_COND051 );
            fieldSet::fsextr( arrayCondicoes[52], m_COND052 );
            fieldSet::fsextr( arrayCondicoes[53], m_COND053 );
            fieldSet::fsextr( arrayCondicoes[54], m_COND054 );
            fieldSet::fsextr( arrayCondicoes[55], m_COND055 );
            fieldSet::fsextr( arrayCondicoes[56], m_COND056 );
            fieldSet::fsextr( arrayCondicoes[57], m_COND057 );
            fieldSet::fsextr( arrayCondicoes[58], m_COND058 );
            fieldSet::fsextr( arrayCondicoes[59], m_COND059 );
            fieldSet::fsextr( arrayCondicoes[60], m_COND060 );
            fieldSet::fsextr( arrayCondicoes[61], m_COND061 );
            fieldSet::fsextr( arrayCondicoes[62], m_COND062 );
            fieldSet::fsextr( arrayCondicoes[63], m_COND063 );
            fieldSet::fsextr( arrayCondicoes[64], m_COND064 );
            fieldSet::fsextr( arrayCondicoes[65], m_COND065 );
            fieldSet::fsextr( arrayCondicoes[66], m_COND066 );
            fieldSet::fsextr( arrayCondicoes[67], m_COND067 );
            fieldSet::fsextr( arrayCondicoes[68], m_COND068 );
            fieldSet::fsextr( arrayCondicoes[69], m_COND069 );
            fieldSet::fsextr( arrayCondicoes[70], m_COND070 );
            fieldSet::fsextr( arrayCondicoes[71], m_COND071 );
            fieldSet::fsextr( arrayCondicoes[72], m_COND072 );
            fieldSet::fsextr( arrayCondicoes[73], m_COND073 );
            fieldSet::fsextr( arrayCondicoes[74], m_COND074 );
            fieldSet::fsextr( arrayCondicoes[75], m_COND075 );
            fieldSet::fsextr( arrayCondicoes[76], m_COND076 );
            fieldSet::fsextr( arrayCondicoes[77], m_COND077 );
            fieldSet::fsextr( arrayCondicoes[78], m_COND078 );
            fieldSet::fsextr( arrayCondicoes[79], m_COND079 );
            fieldSet::fsextr( arrayCondicoes[80], m_COND080 );
            fieldSet::fsextr( arrayCondicoes[81], m_COND081 );
            fieldSet::fsextr( arrayCondicoes[82], m_COND082 );
            fieldSet::fsextr( arrayCondicoes[83], m_COND083 );
            fieldSet::fsextr( arrayCondicoes[84], m_COND084 );
            fieldSet::fsextr( arrayCondicoes[85], m_COND085 );
            fieldSet::fsextr( arrayCondicoes[86], m_COND086 );
            fieldSet::fsextr( arrayCondicoes[87], m_COND087 );
            fieldSet::fsextr( arrayCondicoes[88], m_COND088 );
            fieldSet::fsextr( arrayCondicoes[89], m_COND089 );
            fieldSet::fsextr( arrayCondicoes[90], m_COND090 );
            fieldSet::fsextr( arrayCondicoes[91], m_COND091 );
            fieldSet::fsextr( arrayCondicoes[92], m_COND092 );
            fieldSet::fsextr( arrayCondicoes[93], m_COND093 );
            fieldSet::fsextr( arrayCondicoes[94], m_COND094 );
            fieldSet::fsextr( arrayCondicoes[95], m_COND095 );
            fieldSet::fsextr( arrayCondicoes[96], m_COND096 );
            fieldSet::fsextr( arrayCondicoes[97], m_COND097 );
            fieldSet::fsextr( arrayCondicoes[98], m_COND098 );
            fieldSet::fsextr( arrayCondicoes[99], m_COND099 );
            fieldSet::fsextr( arrayCondicoes[100], m_COND100 );
            fieldSet::fsextr( arrayCondicoes[101], m_COND101 );
            fieldSet::fsextr( arrayCondicoes[102], m_COND102 );
            fieldSet::fsextr( arrayCondicoes[103], m_COND103 );
            fieldSet::fsextr( arrayCondicoes[104], m_COND104 );
            fieldSet::fsextr( arrayCondicoes[105], m_COND105 );
            fieldSet::fsextr( arrayCondicoes[106], m_COND106 );
            fieldSet::fsextr( arrayCondicoes[107], m_COND107 );
            fieldSet::fsextr( arrayCondicoes[108], m_COND108 );
            fieldSet::fsextr( arrayCondicoes[109], m_COND109 );
            fieldSet::fsextr( arrayCondicoes[110], m_COND110 );
            fieldSet::fsextr( arrayCondicoes[111], m_COND111 );
            fieldSet::fsextr( arrayCondicoes[112], m_COND112 );
            fieldSet::fsextr( arrayCondicoes[113], m_COND113 );
            fieldSet::fsextr( arrayCondicoes[114], m_COND114 );
            fieldSet::fsextr( arrayCondicoes[115], m_COND115 );
            fieldSet::fsextr( arrayCondicoes[116], m_COND116 );
            fieldSet::fsextr( arrayCondicoes[117], m_COND117 );
            fieldSet::fsextr( arrayCondicoes[118], m_COND118 );
            fieldSet::fsextr( arrayCondicoes[119], m_COND119 );            
            fieldSet::fsextr( arrayCondicoes[120], m_COND120 ); 
            fieldSet::fsextr( arrayCondicoes[121], m_COND121 ); 
            fieldSet::fsextr( arrayCondicoes[122], m_COND122 ); 
            fieldSet::fsextr( arrayCondicoes[123], m_COND123 ); 
            fieldSet::fsextr( arrayCondicoes[124], m_COND124 ); 
            fieldSet::fsextr( arrayCondicoes[125], m_COND125 ); 
            fieldSet::fsextr( arrayCondicoes[126], m_COND126 ); 
            fieldSet::fsextr( arrayCondicoes[127], m_COND127 ); 
            fieldSet::fsextr( arrayCondicoes[128], m_COND128 ); 
            fieldSet::fsextr( arrayCondicoes[129], m_COND129 ); 
            fieldSet::fsextr( arrayCondicoes[130], m_COND130 ); 
            fieldSet::fsextr( arrayCondicoes[131], m_COND131 ); 
            fieldSet::fsextr( arrayCondicoes[132], m_COND132 ); 
            fieldSet::fsextr( arrayCondicoes[133], m_COND133 ); 
            fieldSet::fsextr( arrayCondicoes[134], m_COND134 ); 
            fieldSet::fsextr( arrayCondicoes[135], m_COND135 ); 
            fieldSet::fsextr( arrayCondicoes[136], m_COND136 ); 
            fieldSet::fsextr( arrayCondicoes[137], m_COND137 ); 
            fieldSet::fsextr( arrayCondicoes[138], m_COND138 ); 
            fieldSet::fsextr( arrayCondicoes[139], m_COND139 ); 
            fieldSet::fsextr( arrayCondicoes[140], m_COND140 ); 
            fieldSet::fsextr( arrayCondicoes[141], m_COND141 ); 
            fieldSet::fsextr( arrayCondicoes[142], m_COND142 ); 
            fieldSet::fsextr( arrayCondicoes[143], m_COND143 ); 
            fieldSet::fsextr( arrayCondicoes[144], m_COND144 ); 
            fieldSet::fsextr( arrayCondicoes[145], m_COND145 ); 
            fieldSet::fsextr( arrayCondicoes[146], m_COND146 ); 
            fieldSet::fsextr( arrayCondicoes[147], m_COND147 ); 
            fieldSet::fsextr( arrayCondicoes[148], m_COND148 ); 
            fieldSet::fsextr( arrayCondicoes[149], m_COND149 ); 
            fieldSet::fsextr( arrayCondicoes[150], m_COND150 ); 
            fieldSet::fsextr( arrayCondicoes[151], m_COND151 ); 
            fieldSet::fsextr( arrayCondicoes[152], m_COND152 ); 
            fieldSet::fsextr( arrayCondicoes[153], m_COND153 ); 
            fieldSet::fsextr( arrayCondicoes[154], m_COND154 ); 
            fieldSet::fsextr( arrayCondicoes[155], m_COND155 ); 
            fieldSet::fsextr( arrayCondicoes[156], m_COND156 ); 
            fieldSet::fsextr( arrayCondicoes[157], m_COND157 ); 
            fieldSet::fsextr( arrayCondicoes[158], m_COND158 ); 
            fieldSet::fsextr( arrayCondicoes[159], m_COND159 ); 
            fieldSet::fsextr( arrayCondicoes[160], m_COND160 ); 
            fieldSet::fsextr( arrayCondicoes[161], m_COND161 ); 
            fieldSet::fsextr( arrayCondicoes[162], m_COND162 ); 
            fieldSet::fsextr( arrayCondicoes[163], m_COND163 ); 
            fieldSet::fsextr( arrayCondicoes[164], m_COND164 ); 
            fieldSet::fsextr( arrayCondicoes[165], m_COND165 ); 
            fieldSet::fsextr( arrayCondicoes[166], m_COND166 ); 
            fieldSet::fsextr( arrayCondicoes[167], m_COND167 ); 
            fieldSet::fsextr( arrayCondicoes[168], m_COND168 ); 
            fieldSet::fsextr( arrayCondicoes[169], m_COND169 ); 
            fieldSet::fsextr( arrayCondicoes[170], m_COND170 ); 
            fieldSet::fsextr( arrayCondicoes[171], m_COND171 ); 
            fieldSet::fsextr( arrayCondicoes[172], m_COND172 ); 
            fieldSet::fsextr( arrayCondicoes[173], m_COND173 ); 
            fieldSet::fsextr( arrayCondicoes[174], m_COND174 ); 
            fieldSet::fsextr( arrayCondicoes[175], m_COND175 ); 
            fieldSet::fsextr( arrayCondicoes[176], m_COND176 ); 
            fieldSet::fsextr( arrayCondicoes[177], m_COND177 ); 
            fieldSet::fsextr( arrayCondicoes[178], m_COND178 ); 
            fieldSet::fsextr( arrayCondicoes[179], m_COND179 ); 
            fieldSet::fsextr( arrayCondicoes[180], m_COND180 ); 
            fieldSet::fsextr( arrayCondicoes[181], m_COND181 ); 
            fieldSet::fsextr( arrayCondicoes[182], m_COND182 ); 
            fieldSet::fsextr( arrayCondicoes[183], m_COND183 ); 
            fieldSet::fsextr( arrayCondicoes[184], m_COND184 ); 
            fieldSet::fsextr( arrayCondicoes[185], m_COND185 ); 
            fieldSet::fsextr( arrayCondicoes[186], m_COND186 ); 
            fieldSet::fsextr( arrayCondicoes[187], m_COND187 ); 
            fieldSet::fsextr( arrayCondicoes[188], m_COND188 ); 
            fieldSet::fsextr( arrayCondicoes[189], m_COND189 ); 
            fieldSet::fsextr( arrayCondicoes[190], m_COND190 ); 
            fieldSet::fsextr( arrayCondicoes[191], m_COND191 ); 
            fieldSet::fsextr( arrayCondicoes[192], m_COND192 ); 
            fieldSet::fsextr( arrayCondicoes[193], m_COND193 ); 
            fieldSet::fsextr( arrayCondicoes[194], m_COND194 ); 
            fieldSet::fsextr( arrayCondicoes[195], m_COND195 ); 
            fieldSet::fsextr( arrayCondicoes[196], m_COND196 ); 
            fieldSet::fsextr( arrayCondicoes[197], m_COND197 ); 
            fieldSet::fsextr( arrayCondicoes[198], m_COND198 ); 
            fieldSet::fsextr( arrayCondicoes[199], m_COND199 ); 
            fieldSet::fsextr( arrayCondicoes[200], m_COND200 ); 
            fieldSet::fsextr( arrayCondicoes[201], m_COND201 ); 
            fieldSet::fsextr( arrayCondicoes[202], m_COND202 ); 
            fieldSet::fsextr( arrayCondicoes[203], m_COND203 ); 
            fieldSet::fsextr( arrayCondicoes[204], m_COND204 ); 
            fieldSet::fsextr( arrayCondicoes[205], m_COND205 ); 
            fieldSet::fsextr( arrayCondicoes[206], m_COND206 ); 
            fieldSet::fsextr( arrayCondicoes[207], m_COND207 ); 
            fieldSet::fsextr( arrayCondicoes[208], m_COND208 ); 
            fieldSet::fsextr( arrayCondicoes[209], m_COND209 ); 
            fieldSet::fsextr( arrayCondicoes[210], m_COND210 ); 
            fieldSet::fsextr( arrayCondicoes[211], m_COND211 ); 
            fieldSet::fsextr( arrayCondicoes[212], m_COND212 ); 
            fieldSet::fsextr( arrayCondicoes[213], m_COND213 ); 
            fieldSet::fsextr( arrayCondicoes[214], m_COND214 ); 
            fieldSet::fsextr( arrayCondicoes[215], m_COND215 ); 
            fieldSet::fsextr( arrayCondicoes[216], m_COND216 ); 
            fieldSet::fsextr( arrayCondicoes[217], m_COND217 ); 
            fieldSet::fsextr( arrayCondicoes[218], m_COND218 ); 
            fieldSet::fsextr( arrayCondicoes[219], m_COND219 ); 
            fieldSet::fsextr( arrayCondicoes[220], m_COND220 ); 
            fieldSet::fsextr( arrayCondicoes[221], m_COND221 ); 
            fieldSet::fsextr( arrayCondicoes[222], m_COND222 ); 
            fieldSet::fsextr( arrayCondicoes[223], m_COND223 ); 
            fieldSet::fsextr( arrayCondicoes[224], m_COND224 ); 
            fieldSet::fsextr( arrayCondicoes[225], m_COND225 ); 
            fieldSet::fsextr( arrayCondicoes[226], m_COND226 ); 
            fieldSet::fsextr( arrayCondicoes[227], m_COND227 ); 
            fieldSet::fsextr( arrayCondicoes[228], m_COND228 ); 
            fieldSet::fsextr( arrayCondicoes[229], m_COND229 ); 
            fieldSet::fsextr( arrayCondicoes[230], m_COND230 ); 
            fieldSet::fsextr( arrayCondicoes[231], m_COND231 ); 
            fieldSet::fsextr( arrayCondicoes[232], m_COND232 ); 
            fieldSet::fsextr( arrayCondicoes[233], m_COND233 ); 
            fieldSet::fsextr( arrayCondicoes[234], m_COND234 ); 
            fieldSet::fsextr( arrayCondicoes[235], m_COND235 ); 
            fieldSet::fsextr( arrayCondicoes[236], m_COND236 ); 
            fieldSet::fsextr( arrayCondicoes[237], m_COND237 ); 
            fieldSet::fsextr( arrayCondicoes[238], m_COND238 ); 
            fieldSet::fsextr( arrayCondicoes[239], m_COND239 ); 
            fieldSet::fsextr( arrayCondicoes[240], m_COND240 ); 
            fieldSet::fsextr( arrayCondicoes[241], m_COND241 ); 
            fieldSet::fsextr( arrayCondicoes[242], m_COND242 ); 
            fieldSet::fsextr( arrayCondicoes[243], m_COND243 ); 
            fieldSet::fsextr( arrayCondicoes[244], m_COND244 ); 
            fieldSet::fsextr( arrayCondicoes[245], m_COND245 ); 
            fieldSet::fsextr( arrayCondicoes[246], m_COND246 ); 
            fieldSet::fsextr( arrayCondicoes[247], m_COND247 ); 
            fieldSet::fsextr( arrayCondicoes[248], m_COND248 ); 
            fieldSet::fsextr( arrayCondicoes[249], m_COND249 ); 
            fieldSet::fsextr( arrayCondicoes[250], m_COND250 ); 
            fieldSet::fsextr( arrayCondicoes[251], m_COND251 ); 
            fieldSet::fsextr( arrayCondicoes[252], m_COND252 ); 
            fieldSet::fsextr( arrayCondicoes[253], m_COND253 ); 
            fieldSet::fsextr( arrayCondicoes[254], m_COND254 ); 
            fieldSet::fsextr( arrayCondicoes[255], m_COND255 ); 
            fieldSet::fsextr( arrayCondicoes[256], m_COND256 ); 
            fieldSet::fsextr( arrayCondicoes[257], m_COND257 ); 
            fieldSet::fsextr( arrayCondicoes[258], m_COND258 ); 
            fieldSet::fsextr( arrayCondicoes[259], m_COND259 ); 
            fieldSet::fsextr( arrayCondicoes[260], m_COND260 ); 
            fieldSet::fsextr( arrayCondicoes[261], m_COND261 ); 
            fieldSet::fsextr( arrayCondicoes[262], m_COND262 ); 
            fieldSet::fsextr( arrayCondicoes[263], m_COND263 ); 
            fieldSet::fsextr( arrayCondicoes[264], m_COND264 ); 
            fieldSet::fsextr( arrayCondicoes[265], m_COND265 ); 
            fieldSet::fsextr( arrayCondicoes[266], m_COND266 ); 
            fieldSet::fsextr( arrayCondicoes[267], m_COND267 ); 
            fieldSet::fsextr( arrayCondicoes[268], m_COND268 ); 
            fieldSet::fsextr( arrayCondicoes[269], m_COND269 ); 
            fieldSet::fsextr( arrayCondicoes[270], m_COND270 );             
            fieldSet::fsextr( arrayCondicoes[271], m_COND271 );
            fieldSet::fsextr( arrayCondicoes[272], m_COND272 );
            fieldSet::fsextr( arrayCondicoes[273], m_COND273 );
            fieldSet::fsextr( arrayCondicoes[274], m_COND274 );
            fieldSet::fsextr( arrayCondicoes[275], m_COND275 );
            fieldSet::fsextr( arrayCondicoes[276], m_COND276 );
            fieldSet::fsextr( arrayCondicoes[277], m_COND277 );
            fieldSet::fsextr( arrayCondicoes[278], m_COND278 );
            fieldSet::fsextr( arrayCondicoes[279], m_COND279 );
            fieldSet::fsextr( arrayCondicoes[280], m_COND280 );
            fieldSet::fsextr( arrayCondicoes[281], m_COND281 );
            fieldSet::fsextr( arrayCondicoes[282], m_COND282 );
            fieldSet::fsextr( arrayCondicoes[283], m_COND283 );
            fieldSet::fsextr( arrayCondicoes[284], m_COND284 );
            fieldSet::fsextr( arrayCondicoes[285], m_COND285 );
            fieldSet::fsextr( arrayCondicoes[286], m_COND286 );
            fieldSet::fsextr( arrayCondicoes[287], m_COND287 );
            fieldSet::fsextr( arrayCondicoes[288], m_COND288 );
            fieldSet::fsextr( arrayCondicoes[289], m_COND289 );
            fieldSet::fsextr( arrayCondicoes[290], m_COND290 );
            fieldSet::fsextr( arrayCondicoes[291], m_COND291 );
            fieldSet::fsextr( arrayCondicoes[292], m_COND292 );
            fieldSet::fsextr( arrayCondicoes[293], m_COND293 );
            fieldSet::fsextr( arrayCondicoes[294], m_COND294 );
            fieldSet::fsextr( arrayCondicoes[295], m_COND295 );
            fieldSet::fsextr( arrayCondicoes[296], m_COND296 );
            fieldSet::fsextr( arrayCondicoes[297], m_COND297 );
            fieldSet::fsextr( arrayCondicoes[298], m_COND298 );
            fieldSet::fsextr( arrayCondicoes[299], m_COND299 );
            fieldSet::fsextr( arrayCondicoes[300], m_COND300 );          
            fieldSet::fsextr( arrayCondicoes[301], m_COND301 ); 
            fieldSet::fsextr( arrayCondicoes[302], m_COND302 ); 
            fieldSet::fsextr( arrayCondicoes[303], m_COND303 ); 
            fieldSet::fsextr( arrayCondicoes[304], m_COND304 ); 
            fieldSet::fsextr( arrayCondicoes[305], m_COND305 ); 
            fieldSet::fsextr( arrayCondicoes[306], m_COND306 ); 
            fieldSet::fsextr( arrayCondicoes[307], m_COND307 ); 
            fieldSet::fsextr( arrayCondicoes[308], m_COND308 ); 
            fieldSet::fsextr( arrayCondicoes[309], m_COND309 ); 
            fieldSet::fsextr( arrayCondicoes[310], m_COND310 ); 
            fieldSet::fsextr( arrayCondicoes[311], m_COND311 ); 
            fieldSet::fsextr( arrayCondicoes[312], m_COND312 ); 
            fieldSet::fsextr( arrayCondicoes[313], m_COND313 ); 
            fieldSet::fsextr( arrayCondicoes[314], m_COND314 ); 
            fieldSet::fsextr( arrayCondicoes[315], m_COND315 ); 
            fieldSet::fsextr( arrayCondicoes[316], m_COND316 ); 
            fieldSet::fsextr( arrayCondicoes[317], m_COND317 ); 
            fieldSet::fsextr( arrayCondicoes[318], m_COND318 ); 
            fieldSet::fsextr( arrayCondicoes[319], m_COND319 ); 
            fieldSet::fsextr( arrayCondicoes[320], m_COND320 ); 
            fieldSet::fsextr( arrayCondicoes[321], m_COND321 ); 
            fieldSet::fsextr( arrayCondicoes[322], m_COND322 ); 
            fieldSet::fsextr( arrayCondicoes[323], m_COND323 ); 
            fieldSet::fsextr( arrayCondicoes[324], m_COND324 ); 
            fieldSet::fsextr( arrayCondicoes[325], m_COND325 ); 
            fieldSet::fsextr( arrayCondicoes[326], m_COND326 ); 
            fieldSet::fsextr( arrayCondicoes[327], m_COND327 ); 
            fieldSet::fsextr( arrayCondicoes[328], m_COND328 ); 
            fieldSet::fsextr( arrayCondicoes[329], m_COND329 ); 
            fieldSet::fsextr( arrayCondicoes[330], m_COND330 ); 
            fieldSet::fsextr( arrayCondicoes[331], m_COND331 ); 
            fieldSet::fsextr( arrayCondicoes[332], m_COND332 ); 
            fieldSet::fsextr( arrayCondicoes[333], m_COND333 ); 
            fieldSet::fsextr( arrayCondicoes[334], m_COND334 ); 
            fieldSet::fsextr( arrayCondicoes[335], m_COND335 ); 
            fieldSet::fsextr( arrayCondicoes[336], m_COND336 ); 
            fieldSet::fsextr( arrayCondicoes[337], m_COND337 ); 
            fieldSet::fsextr( arrayCondicoes[338], m_COND338 ); 
            fieldSet::fsextr( arrayCondicoes[339], m_COND339 ); 
            fieldSet::fsextr( arrayCondicoes[340], m_COND340 ); 
            fieldSet::fsextr( arrayCondicoes[341], m_COND341 ); 
            fieldSet::fsextr( arrayCondicoes[342], m_COND342 ); 
            fieldSet::fsextr( arrayCondicoes[343], m_COND343 ); 
            fieldSet::fsextr( arrayCondicoes[344], m_COND344 ); 
            fieldSet::fsextr( arrayCondicoes[345], m_COND345 ); 
            fieldSet::fsextr( arrayCondicoes[346], m_COND346 ); 
            fieldSet::fsextr( arrayCondicoes[347], m_COND347 ); 
            fieldSet::fsextr( arrayCondicoes[348], m_COND348 ); 
            fieldSet::fsextr( arrayCondicoes[349], m_COND349 ); 
            fieldSet::fsextr( arrayCondicoes[350], m_COND350 );             
            fieldSet::fsextr( arrayCondicoes[351], condicao351 );  // Padronizacao Crediario PDV
			fieldSet::fsextr( arrayCondicoes[352], condicao352 );
            fieldSet::fsextr( arrayCondicoes[353], condicao353 );  // Padronizacao Negadas ABECS

            fieldSet::fsextr( l_listaDEsValidar, m_listaDEsValidar );   
            setArrayDEsMensagem(l_listaDEsValidar, arrayDEsLista, arrayCondicoes);
 
            int DES[] =  { 2, 3, 4, 7, 11, 12, 13, 14, 15, 22, 23, 32, 33, 35, 38, 39, 41, 42, 45, 47, 48, 49, 52, 54, 55, 56, 60, 61, 62, 63, 67, 70, 90, 104, 123, 124, 125, 127 };
            int DEStam = sizeof(DES)/sizeof(int);
            
            char buff[100];
            //std::cout << "LISTA SetBits [" << l_listaDEsValidar.c_str() << "]" << std::endl;
            bool bitmap2 = false;
            //Liga so os bits informados no mapping
            for(int i=0;i<DEStam;i++)
            {

                if(arrayDEsLista[DES[i]].compare("TRUE")==0)
                {
                    sprintf(buff,"DE%03d", DES[i]);  
                    //std::cout << "SetBit[" << buff << "]" << std::endl;
                    
                    if(!bitmap2 && DES[i]>=64)
                    {
                        bitmap2 = true;
                        m_DE001.field().turnOn();
                    }
                    
                    switch(DES[i])
                    {
                        case 2:
                            m_DE002.field().turnOn();
                            break;

                        case 3:
                            m_DE003.field().turnOn();
                            break;

                        case 4:
                            m_DE004.field().turnOn();
                            break;

                        case 7:
                            m_DE007.field().turnOn();
                            break;

                        case 11:
                            m_DE011.field().turnOn();
                            break;

                        case 12:
                            m_DE012.field().turnOn();
                            break;

                        case 13:
                            m_DE013.field().turnOn();
                            break;

                        case 14:
                            m_DE014.field().turnOn();
                            break;

                        case 15:
                            m_DE015.field().turnOn();
                            break;

                        case 22:
                            m_DE022.field().turnOn();
                            break;

                        case 23:
                            m_DE023.field().turnOn();
                            break;

                        case 32:
                            m_DE032.field().turnOn();
                            break;

                        case 33:
                            m_DE033.field().turnOn();
                            break;

                        case 35:
                            m_DE035.field().turnOn();
                            break;

                        case 38:
                            m_DE038.field().turnOn();
                            break;

                        case 39:
                            m_DE039.field().turnOn();
                            break;

                        case 41:
                            m_DE041.field().turnOn();
                            break;

                        case 42:
                            m_DE042.field().turnOn();
                            break;

                        case 45:
                            m_DE045.field().turnOn();
                            break;

                        case 47:
                            m_DE047.field().turnOn();
                            break;

                        case 48:
                            m_DE048.field().turnOn();
                            break;

                        case 49:
                            m_DE049.field().turnOn();
                            break;

                        case 52:
                            m_DE052.field().turnOn();
                            break;

                        case 54:
                            m_DE054.field().turnOn();
                            break;

                        case 55:
                            m_DE055.field().turnOn();
                            break;

                        case 56:
                            m_DE056.field().turnOn();
                            break;

                        case 60:
                            m_DE060.field().turnOn();
                            break;

                        case 61:
                            m_DE061.field().turnOn();
                            break;

                        case 62:
                            m_DE062.field().turnOn();
                            break;

                        case 63:
                            m_DE063.field().turnOn();
                            break;

                        case 67:
                            m_DE067.field().turnOn();
                            break;

                        case 70:
                            m_DE070.field().turnOn();
                            break;

                        case 90:
                            m_DE090.field().turnOn();
                            break;

                        case 104:
                            m_DE104.field().turnOn();
                            break;

                        case 123:
                            m_DE123.field().turnOn();
                            break;

                        case 124:
                            m_DE124.field().turnOn();
                            break;

                        case 125:
                            m_DE125.field().turnOn();
                            break;

                        case 127:
                            m_DE127.field().turnOn();
                            break;
                    }                    
                }                
            }
        }
        catch ( base::GenException e )
        {

            std::string l_msg = "Gen Exception in DEsEnviados <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            std::string l_msg = "std::exception in DEsEnviados <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( true );
    }

    
    
    void DEsEnviados::trataTags(int de, std::string bit)
    {                
        std::string tag;  


        switch(de)
        {
            case 47:
                tag = obterTag(bit);                
                //std::cout << "LIGA TAG: "<< bit.c_str() << std::endl;

                if(tag.compare("02")==0)
                {
                
                    //std::cout << "Ligando a tag 47 33: "<< bit.c_str() << std::endl;
                    fieldSet::fscopy( de47Tag02, "TRUE", 4 );
                }
                // Padronizacao Crediario PDV - INICIO
                else if (tag.compare("29")==0)
                {
                    fieldSet::fscopy( dataElement47Tag29, "TRUE", 4 );
                }
                // Padronizacao Crediario PDV - FIM
                else if(tag.compare("33")==0)
                {
                
                    //std::cout << "Ligando a tag 47 33: "<< bit.c_str() << std::endl;
                    fieldSet::fscopy( de47Tag33, "TRUE", 4 );
                }
                else if(tag.compare("55")==0)
                {
                
                    //std::cout << "Ligando a tag 47 33: "<< bit.c_str() << std::endl;
                    fieldSet::fscopy( de47Tag55, "TRUE", 4 );
                }                
                break;
            case 56:
                tag = obterTag(bit);
                //std::cout << "LIGA TAG: "<< bit.c_str() << std::endl;
                if(tag.compare("07")==0)
                {
                    fieldSet::fscopy( m_TAG56_07, "TRUE", 4 );
                }
                else if(tag.compare("08")==0)
                {
                    fieldSet::fscopy( m_TAG56_08, "TRUE", 4 );
                }
                else if(tag.compare("0D")==0)
                {
                    fieldSet::fscopy( m_TAG56_0D, "TRUE", 4 );
                }
                else if(tag.compare("16")==0)
                {
                    fieldSet::fscopy( m_TAG56_16, "TRUE", 4 );
                }               
                break;
        }    
    }
    
    void DEsEnviados::setArrayDEsMensagem( std::string lista, std::string arrayDEsLista[],std::string arrayCondicoes[] )
    {
        
        int comeco = 0;
        int de = 0;
        int cond = 0;
        std::string bit;

        int tam = lista.length();

        for(int i=0;i<tam;i++)
        {            
            if(lista[i]==',' || i == tam-1) //separa por virgulas ou quando chega o final da string
            {			
            
                if(i == tam-1)
                {
                    bit = lista.substr(comeco,tam-comeco);
                }
                else
                {
                    bit = lista.substr(comeco,i-comeco);
                   // trataTags(de,bit);
                }
                cond = -1;
                
                int inicioCond = bit.find('[');
                if(inicioCond==-1)
                {
                    //obtem parte numerica do DE sem condicao
                    de = atoi(bit.c_str());
                    arrayDEsLista[de]="TRUE";

                    trataTags(de, bit);
                    //std::cout << "DE simples: [" << bit.c_str() << "]" << std::endl;                    
                }
                else
                {
                    int fimCond = bit.find_last_of(']');
                    
                    //obtem parte numerica do DE com condicao
                    de = atoi(bit.substr(0,inicioCond).c_str());
                    //std::cout << bit.substr(0,inicioCond).c_str();
                    
                    //ultimo elemento nao tem virgula
                    if(fimCond==-1 &&  i == tam-1)
                    {
                        fimCond=bit.length()+1;
                    }
                    
                    if(fimCond-inicioCond>3)
                    {
                        //aceita C ou c como indicador de condicao
                        inicioCond = bit.find_last_of('C');					
                        if(inicioCond==-1)
                            inicioCond = bit.find_last_of('c');
                        inicioCond++;
                        //std::cout << "[" << bit.substr(inicioCond,fimCond-inicioCond).c_str() << "]" << std::endl;
                        //obtem a parte numerica da condicao
                        cond = atoi(bit.substr(inicioCond,fimCond-inicioCond).c_str());
                    }
                    else
                    {                        
                        cond = 0;
                    }				
                }
                //O ou C000 sao indiferentes para a validacao
                if(cond==0)
                {
                    arrayDEsLista[de]="indiferente";
                    trataTags(de, bit);
                }
                else
                {
                    //Se for condicional e essa transacao se enquadra dentro dos parametros
                    //dessa condicao, a presenca desse DE torna-se obrigatoria
                    if(cond!=-1 && arrayCondicoes[cond].compare("TRUE")==0)
                    {
                        arrayDEsLista[de] = "TRUE";
                        trataTags(de, bit);
                    }
                }
                //marca o comeco do proximo DE                
                comeco=i+1;
                //se tiver espacos entre a virgula e o proximo DE, pula estes espacos
                while(comeco<tam -1 && lista[comeco]==' ')
                    comeco++;                
            }
        }
    }
    
    bool DEsEnviados::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value( );
            if ( l_source == "DESENVIADOS" )
            {
                this->setLocalFieldPath( l_source );
            }
            else if( l_source == "CONDICOES" )
            {
                this->setCondFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value( );
            if ( l_source == "ENVIATAGS_DE047" )
            {
                this->setTagsDE047FieldPath( l_source );
            }
            else if( l_source == "ENVIATAGS_DE056" )
            {
                this->setTagsDE056FieldPath( l_source );
            }
            else
            {
                this->setTargetFieldPath( l_source );    
            }
        }                

        return true;
    }

    bool DEsEnviados::init( )
    {               
        m_listaDEsValidar = this->navigate( m_localFieldPath + ".LISTADES" );             
        
        m_DE001 = this->navigate( m_targetFieldPath + ".DE001" );
        m_DE002 = this->navigate( m_targetFieldPath + ".DE002" );
        m_DE003 = this->navigate( m_targetFieldPath + ".DE003" );
        m_DE004 = this->navigate( m_targetFieldPath + ".DE004" );
        m_DE007 = this->navigate( m_targetFieldPath + ".DE007" );
        m_DE011 = this->navigate( m_targetFieldPath + ".DE011" );
        m_DE012 = this->navigate( m_targetFieldPath + ".DE012" );
        m_DE013 = this->navigate( m_targetFieldPath + ".DE013" );
        m_DE014 = this->navigate( m_targetFieldPath + ".DE014" );
        m_DE015 = this->navigate( m_targetFieldPath + ".DE015" );
        m_DE022 = this->navigate( m_targetFieldPath + ".DE022" );
        m_DE023 = this->navigate( m_targetFieldPath + ".DE023" );
        m_DE032 = this->navigate( m_targetFieldPath + ".DE032" );
        m_DE033 = this->navigate( m_targetFieldPath + ".DE033" );
        m_DE035 = this->navigate( m_targetFieldPath + ".DE035" );
        m_DE038 = this->navigate( m_targetFieldPath + ".DE038" );
        m_DE039 = this->navigate( m_targetFieldPath + ".DE039" );
        m_DE041 = this->navigate( m_targetFieldPath + ".DE041" );
        m_DE042 = this->navigate( m_targetFieldPath + ".DE042" );
        m_DE045 = this->navigate( m_targetFieldPath + ".DE045" );
        m_DE047 = this->navigate( m_targetFieldPath + ".DE047" );
        m_DE048 = this->navigate( m_targetFieldPath + ".DE048" );
        m_DE049 = this->navigate( m_targetFieldPath + ".DE049" );
        m_DE052 = this->navigate( m_targetFieldPath + ".DE052" );
        m_DE054 = this->navigate( m_targetFieldPath + ".DE054" );
        m_DE055 = this->navigate( m_targetFieldPath + ".DE055" );
        m_DE056 = this->navigate( m_targetFieldPath + ".DE056" );
        m_DE060 = this->navigate( m_targetFieldPath + ".DE060" );
        m_DE061 = this->navigate( m_targetFieldPath + ".DE061" );
        m_DE062 = this->navigate( m_targetFieldPath + ".DE062" );
        m_DE063 = this->navigate( m_targetFieldPath + ".DE063" );
        m_DE067 = this->navigate( m_targetFieldPath + ".DE067" );
        m_DE070 = this->navigate( m_targetFieldPath + ".DE070" );
        m_DE090 = this->navigate( m_targetFieldPath + ".DE090" );
        m_DE104 = this->navigate( m_targetFieldPath + ".DE104" );
        m_DE123 = this->navigate( m_targetFieldPath + ".DE123" );
        m_DE124 = this->navigate( m_targetFieldPath + ".DE124" );
        m_DE125 = this->navigate( m_targetFieldPath + ".DE125" );
        m_DE127 = this->navigate( m_targetFieldPath + ".DE127" );

        m_COND001 = this->navigate( m_condFieldPath + ".C001" );
        m_COND002 = this->navigate( m_condFieldPath + ".C002" );
        m_COND003 = this->navigate( m_condFieldPath + ".C003" );
        m_COND004 = this->navigate( m_condFieldPath + ".C004" );
        m_COND005 = this->navigate( m_condFieldPath + ".C005" );
        m_COND006 = this->navigate( m_condFieldPath + ".C006" );
        m_COND007 = this->navigate( m_condFieldPath + ".C007" );
        m_COND008 = this->navigate( m_condFieldPath + ".C008" );
        m_COND009 = this->navigate( m_condFieldPath + ".C009" );
        m_COND010 = this->navigate( m_condFieldPath + ".C010" );
        m_COND011 = this->navigate( m_condFieldPath + ".C011" );
        m_COND012 = this->navigate( m_condFieldPath + ".C012" );
        m_COND013 = this->navigate( m_condFieldPath + ".C013" );
        m_COND014 = this->navigate( m_condFieldPath + ".C014" );
        m_COND015 = this->navigate( m_condFieldPath + ".C015" );
        m_COND016 = this->navigate( m_condFieldPath + ".C016" );
        m_COND017 = this->navigate( m_condFieldPath + ".C017" );
        m_COND018 = this->navigate( m_condFieldPath + ".C018" );
        m_COND019 = this->navigate( m_condFieldPath + ".C019" );
        m_COND020 = this->navigate( m_condFieldPath + ".C020" );
        m_COND021 = this->navigate( m_condFieldPath + ".C021" );
        m_COND022 = this->navigate( m_condFieldPath + ".C022" );
        m_COND023 = this->navigate( m_condFieldPath + ".C023" );
        m_COND024 = this->navigate( m_condFieldPath + ".C024" );
        m_COND025 = this->navigate( m_condFieldPath + ".C025" );
        m_COND026 = this->navigate( m_condFieldPath + ".C026" );
        m_COND027 = this->navigate( m_condFieldPath + ".C027" );
        m_COND028 = this->navigate( m_condFieldPath + ".C028" );
        m_COND029 = this->navigate( m_condFieldPath + ".C029" );
        m_COND030 = this->navigate( m_condFieldPath + ".C030" );
        m_COND031 = this->navigate( m_condFieldPath + ".C031" );
        m_COND032 = this->navigate( m_condFieldPath + ".C032" );
        m_COND033 = this->navigate( m_condFieldPath + ".C033" );
        m_COND034 = this->navigate( m_condFieldPath + ".C034" );
        m_COND035 = this->navigate( m_condFieldPath + ".C035" );
        m_COND036 = this->navigate( m_condFieldPath + ".C036" );
        m_COND037 = this->navigate( m_condFieldPath + ".C037" );
        m_COND038 = this->navigate( m_condFieldPath + ".C038" );
        m_COND039 = this->navigate( m_condFieldPath + ".C039" );
        m_COND040 = this->navigate( m_condFieldPath + ".C040" );
        m_COND041 = this->navigate( m_condFieldPath + ".C041" );
        m_COND042 = this->navigate( m_condFieldPath + ".C042" );
        m_COND043 = this->navigate( m_condFieldPath + ".C043" );
        m_COND044 = this->navigate( m_condFieldPath + ".C044" );
        m_COND045 = this->navigate( m_condFieldPath + ".C045" );
        m_COND046 = this->navigate( m_condFieldPath + ".C046" );
        m_COND047 = this->navigate( m_condFieldPath + ".C047" );
        m_COND048 = this->navigate( m_condFieldPath + ".C048" );
        m_COND049 = this->navigate( m_condFieldPath + ".C049" );
        m_COND050 = this->navigate( m_condFieldPath + ".C050" );
        m_COND051 = this->navigate( m_condFieldPath + ".C051" );
        m_COND052 = this->navigate( m_condFieldPath + ".C052" );
        m_COND053 = this->navigate( m_condFieldPath + ".C053" );
        m_COND054 = this->navigate( m_condFieldPath + ".C054" );
        m_COND055 = this->navigate( m_condFieldPath + ".C055" );
        m_COND056 = this->navigate( m_condFieldPath + ".C056" );
        m_COND057 = this->navigate( m_condFieldPath + ".C057" );
        m_COND058 = this->navigate( m_condFieldPath + ".C058" );
        m_COND059 = this->navigate( m_condFieldPath + ".C059" );
        m_COND060 = this->navigate( m_condFieldPath + ".C060" );
        m_COND061 = this->navigate( m_condFieldPath + ".C061" );
        m_COND062 = this->navigate( m_condFieldPath + ".C062" );
        m_COND063 = this->navigate( m_condFieldPath + ".C063" );
        m_COND064 = this->navigate( m_condFieldPath + ".C064" );
        m_COND065 = this->navigate( m_condFieldPath + ".C065" );
        m_COND066 = this->navigate( m_condFieldPath + ".C066" );
        m_COND067 = this->navigate( m_condFieldPath + ".C067" );
        m_COND068 = this->navigate( m_condFieldPath + ".C068" );
        m_COND069 = this->navigate( m_condFieldPath + ".C069" );
        m_COND070 = this->navigate( m_condFieldPath + ".C070" );
        m_COND071 = this->navigate( m_condFieldPath + ".C071" );
        m_COND072 = this->navigate( m_condFieldPath + ".C072" );
        m_COND073 = this->navigate( m_condFieldPath + ".C073" );
        m_COND074 = this->navigate( m_condFieldPath + ".C074" );
        m_COND075 = this->navigate( m_condFieldPath + ".C075" );
        m_COND076 = this->navigate( m_condFieldPath + ".C076" );
        m_COND077 = this->navigate( m_condFieldPath + ".C077" );
        m_COND078 = this->navigate( m_condFieldPath + ".C078" );
        m_COND079 = this->navigate( m_condFieldPath + ".C079" );
        m_COND080 = this->navigate( m_condFieldPath + ".C080" );
        m_COND081 = this->navigate( m_condFieldPath + ".C081" );
        m_COND082 = this->navigate( m_condFieldPath + ".C082" );
        m_COND083 = this->navigate( m_condFieldPath + ".C083" );
        m_COND084 = this->navigate( m_condFieldPath + ".C084" );
        m_COND085 = this->navigate( m_condFieldPath + ".C085" );
        m_COND086 = this->navigate( m_condFieldPath + ".C086" );
        m_COND087 = this->navigate( m_condFieldPath + ".C087" );
        m_COND088 = this->navigate( m_condFieldPath + ".C088" );
        m_COND089 = this->navigate( m_condFieldPath + ".C089" );
        m_COND090 = this->navigate( m_condFieldPath + ".C090" );
        m_COND091 = this->navigate( m_condFieldPath + ".C091" );
        m_COND092 = this->navigate( m_condFieldPath + ".C092" );
        m_COND093 = this->navigate( m_condFieldPath + ".C093" );
        m_COND094 = this->navigate( m_condFieldPath + ".C094" );
        m_COND095 = this->navigate( m_condFieldPath + ".C095" );
        m_COND096 = this->navigate( m_condFieldPath + ".C096" );
        m_COND097 = this->navigate( m_condFieldPath + ".C097" );
        m_COND098 = this->navigate( m_condFieldPath + ".C098" );
        m_COND099 = this->navigate( m_condFieldPath + ".C099" );
        m_COND100 = this->navigate( m_condFieldPath + ".C100" );
        m_COND101 = this->navigate( m_condFieldPath + ".C101" );
        m_COND102 = this->navigate( m_condFieldPath + ".C102" );
        m_COND103 = this->navigate( m_condFieldPath + ".C103" );
        m_COND104 = this->navigate( m_condFieldPath + ".C104" );
        m_COND105 = this->navigate( m_condFieldPath + ".C105" );
        m_COND106 = this->navigate( m_condFieldPath + ".C106" );
        m_COND107 = this->navigate( m_condFieldPath + ".C107" );
        m_COND108 = this->navigate( m_condFieldPath + ".C108" );
        m_COND109 = this->navigate( m_condFieldPath + ".C109" );
        m_COND110 = this->navigate( m_condFieldPath + ".C110" );
        m_COND111 = this->navigate( m_condFieldPath + ".C111" );
        m_COND112 = this->navigate( m_condFieldPath + ".C112" );
        m_COND113 = this->navigate( m_condFieldPath + ".C113" );
        m_COND114 = this->navigate( m_condFieldPath + ".C114" );
        m_COND115 = this->navigate( m_condFieldPath + ".C115" );
        m_COND116 = this->navigate( m_condFieldPath + ".C116" );
        m_COND117 = this->navigate( m_condFieldPath + ".C117" );
        m_COND118 = this->navigate( m_condFieldPath + ".C118" );
        m_COND119 = this->navigate( m_condFieldPath + ".C119" );
        m_COND120 = this->navigate( m_condFieldPath + ".C120" );
        m_COND121 = this->navigate( m_condFieldPath + ".C121" );
        m_COND122 = this->navigate( m_condFieldPath + ".C122" );
        m_COND123 = this->navigate( m_condFieldPath + ".C123" );
        m_COND124 = this->navigate( m_condFieldPath + ".C124" );
        m_COND125 = this->navigate( m_condFieldPath + ".C125" );
        m_COND126 = this->navigate( m_condFieldPath + ".C126" );
        m_COND127 = this->navigate( m_condFieldPath + ".C127" );
        m_COND128 = this->navigate( m_condFieldPath + ".C128" );
        m_COND129 = this->navigate( m_condFieldPath + ".C129" );
        m_COND130 = this->navigate( m_condFieldPath + ".C130" );
        m_COND131 = this->navigate( m_condFieldPath + ".C131" );
        m_COND132 = this->navigate( m_condFieldPath + ".C132" );
        m_COND133 = this->navigate( m_condFieldPath + ".C133" );
        m_COND134 = this->navigate( m_condFieldPath + ".C134" );
        m_COND135 = this->navigate( m_condFieldPath + ".C135" );
        m_COND136 = this->navigate( m_condFieldPath + ".C136" );
        m_COND137 = this->navigate( m_condFieldPath + ".C137" );
        m_COND138 = this->navigate( m_condFieldPath + ".C138" );
        m_COND139 = this->navigate( m_condFieldPath + ".C139" );
        m_COND140 = this->navigate( m_condFieldPath + ".C140" );
        m_COND141 = this->navigate( m_condFieldPath + ".C141" );
        m_COND142 = this->navigate( m_condFieldPath + ".C142" );
        m_COND143 = this->navigate( m_condFieldPath + ".C143" );
        m_COND144 = this->navigate( m_condFieldPath + ".C144" );
        m_COND145 = this->navigate( m_condFieldPath + ".C145" );
        m_COND146 = this->navigate( m_condFieldPath + ".C146" );
        m_COND147 = this->navigate( m_condFieldPath + ".C147" );
        m_COND148 = this->navigate( m_condFieldPath + ".C148" );
        m_COND149 = this->navigate( m_condFieldPath + ".C149" );
        m_COND150 = this->navigate( m_condFieldPath + ".C150" );
        m_COND151 = this->navigate( m_condFieldPath + ".C151" );
        m_COND152 = this->navigate( m_condFieldPath + ".C152" );
        m_COND153 = this->navigate( m_condFieldPath + ".C153" );
        m_COND154 = this->navigate( m_condFieldPath + ".C154" );
        m_COND155 = this->navigate( m_condFieldPath + ".C155" );
        m_COND156 = this->navigate( m_condFieldPath + ".C156" );
        m_COND157 = this->navigate( m_condFieldPath + ".C157" );
        m_COND158 = this->navigate( m_condFieldPath + ".C158" );
        m_COND159 = this->navigate( m_condFieldPath + ".C159" );
        m_COND160 = this->navigate( m_condFieldPath + ".C160" );
        m_COND161 = this->navigate( m_condFieldPath + ".C161" );
        m_COND162 = this->navigate( m_condFieldPath + ".C162" );
        m_COND163 = this->navigate( m_condFieldPath + ".C163" );
        m_COND164 = this->navigate( m_condFieldPath + ".C164" );
        m_COND165 = this->navigate( m_condFieldPath + ".C165" );
        m_COND166 = this->navigate( m_condFieldPath + ".C166" );
        m_COND167 = this->navigate( m_condFieldPath + ".C167" );
        m_COND168 = this->navigate( m_condFieldPath + ".C168" );
        m_COND169 = this->navigate( m_condFieldPath + ".C169" );
        m_COND170 = this->navigate( m_condFieldPath + ".C170" );
        m_COND171 = this->navigate( m_condFieldPath + ".C171" );
        m_COND172 = this->navigate( m_condFieldPath + ".C172" );
        m_COND173 = this->navigate( m_condFieldPath + ".C173" );
        m_COND174 = this->navigate( m_condFieldPath + ".C174" );
        m_COND175 = this->navigate( m_condFieldPath + ".C175" );
        m_COND176 = this->navigate( m_condFieldPath + ".C176" );
        m_COND177 = this->navigate( m_condFieldPath + ".C177" );
        m_COND178 = this->navigate( m_condFieldPath + ".C178" );
        m_COND179 = this->navigate( m_condFieldPath + ".C179" );
        m_COND180 = this->navigate( m_condFieldPath + ".C180" );
        m_COND181 = this->navigate( m_condFieldPath + ".C181" );
        m_COND182 = this->navigate( m_condFieldPath + ".C182" );
        m_COND183 = this->navigate( m_condFieldPath + ".C183" );
        m_COND184 = this->navigate( m_condFieldPath + ".C184" );
        m_COND185 = this->navigate( m_condFieldPath + ".C185" );
        m_COND186 = this->navigate( m_condFieldPath + ".C186" );
        m_COND187 = this->navigate( m_condFieldPath + ".C187" );
        m_COND188 = this->navigate( m_condFieldPath + ".C188" );
        m_COND189 = this->navigate( m_condFieldPath + ".C189" );
        m_COND190 = this->navigate( m_condFieldPath + ".C190" );
        m_COND191 = this->navigate( m_condFieldPath + ".C191" );
        m_COND192 = this->navigate( m_condFieldPath + ".C192" );
        m_COND193 = this->navigate( m_condFieldPath + ".C193" );
        m_COND194 = this->navigate( m_condFieldPath + ".C194" );
        m_COND195 = this->navigate( m_condFieldPath + ".C195" );
        m_COND196 = this->navigate( m_condFieldPath + ".C196" );
        m_COND197 = this->navigate( m_condFieldPath + ".C197" );
        m_COND198 = this->navigate( m_condFieldPath + ".C198" );
        m_COND199 = this->navigate( m_condFieldPath + ".C199" );
        m_COND200 = this->navigate( m_condFieldPath + ".C200" );
        m_COND201 = this->navigate( m_condFieldPath + ".C201" );
        m_COND202 = this->navigate( m_condFieldPath + ".C202" );
        m_COND203 = this->navigate( m_condFieldPath + ".C203" );
        m_COND204 = this->navigate( m_condFieldPath + ".C204" );
        m_COND205 = this->navigate( m_condFieldPath + ".C205" );
        m_COND206 = this->navigate( m_condFieldPath + ".C206" );
        m_COND207 = this->navigate( m_condFieldPath + ".C207" );
        m_COND208 = this->navigate( m_condFieldPath + ".C208" );
        m_COND209 = this->navigate( m_condFieldPath + ".C209" );
        m_COND210 = this->navigate( m_condFieldPath + ".C210" );
        m_COND211 = this->navigate( m_condFieldPath + ".C211" );
        m_COND212 = this->navigate( m_condFieldPath + ".C212" );
        m_COND213 = this->navigate( m_condFieldPath + ".C213" );
        m_COND214 = this->navigate( m_condFieldPath + ".C214" );
        m_COND215 = this->navigate( m_condFieldPath + ".C215" );
        m_COND216 = this->navigate( m_condFieldPath + ".C216" );
        m_COND217 = this->navigate( m_condFieldPath + ".C217" );
        m_COND218 = this->navigate( m_condFieldPath + ".C218" );
        m_COND219 = this->navigate( m_condFieldPath + ".C219" );
        m_COND220 = this->navigate( m_condFieldPath + ".C220" );
        m_COND221 = this->navigate( m_condFieldPath + ".C221" );
        m_COND222 = this->navigate( m_condFieldPath + ".C222" );
        m_COND223 = this->navigate( m_condFieldPath + ".C223" );
        m_COND224 = this->navigate( m_condFieldPath + ".C224" );
        m_COND225 = this->navigate( m_condFieldPath + ".C225" );
        m_COND226 = this->navigate( m_condFieldPath + ".C226" );
        m_COND227 = this->navigate( m_condFieldPath + ".C227" );
        m_COND228 = this->navigate( m_condFieldPath + ".C228" );
        m_COND229 = this->navigate( m_condFieldPath + ".C229" );
        m_COND230 = this->navigate( m_condFieldPath + ".C230" );
        m_COND231 = this->navigate( m_condFieldPath + ".C231" );
        m_COND232 = this->navigate( m_condFieldPath + ".C232" );
        m_COND233 = this->navigate( m_condFieldPath + ".C233" );
        m_COND234 = this->navigate( m_condFieldPath + ".C234" );
        m_COND235 = this->navigate( m_condFieldPath + ".C235" );
        m_COND236 = this->navigate( m_condFieldPath + ".C236" );
        m_COND237 = this->navigate( m_condFieldPath + ".C237" );
        m_COND238 = this->navigate( m_condFieldPath + ".C238" );
        m_COND239 = this->navigate( m_condFieldPath + ".C239" );
        m_COND240 = this->navigate( m_condFieldPath + ".C240" );
        m_COND241 = this->navigate( m_condFieldPath + ".C241" );
        m_COND242 = this->navigate( m_condFieldPath + ".C242" );
        m_COND243 = this->navigate( m_condFieldPath + ".C243" );
        m_COND244 = this->navigate( m_condFieldPath + ".C244" );
        m_COND245 = this->navigate( m_condFieldPath + ".C245" );
        m_COND246 = this->navigate( m_condFieldPath + ".C246" );
        m_COND247 = this->navigate( m_condFieldPath + ".C247" );
        m_COND248 = this->navigate( m_condFieldPath + ".C248" );
        m_COND249 = this->navigate( m_condFieldPath + ".C249" );
        m_COND250 = this->navigate( m_condFieldPath + ".C250" );
        m_COND251 = this->navigate( m_condFieldPath + ".C251" );
        m_COND252 = this->navigate( m_condFieldPath + ".C252" );
        m_COND253 = this->navigate( m_condFieldPath + ".C253" );
        m_COND254 = this->navigate( m_condFieldPath + ".C254" );
        m_COND255 = this->navigate( m_condFieldPath + ".C255" );
        m_COND256 = this->navigate( m_condFieldPath + ".C256" );
        m_COND257 = this->navigate( m_condFieldPath + ".C257" );
        m_COND258 = this->navigate( m_condFieldPath + ".C258" );
        m_COND259 = this->navigate( m_condFieldPath + ".C259" );
        m_COND260 = this->navigate( m_condFieldPath + ".C260" );
        m_COND261 = this->navigate( m_condFieldPath + ".C261" );
        m_COND262 = this->navigate( m_condFieldPath + ".C262" );
        m_COND263 = this->navigate( m_condFieldPath + ".C263" );
        m_COND264 = this->navigate( m_condFieldPath + ".C264" );
        m_COND265 = this->navigate( m_condFieldPath + ".C265" );
        m_COND266 = this->navigate( m_condFieldPath + ".C266" );
        m_COND267 = this->navigate( m_condFieldPath + ".C267" );
        m_COND268 = this->navigate( m_condFieldPath + ".C268" );
        m_COND269 = this->navigate( m_condFieldPath + ".C269" );
        m_COND270 = this->navigate( m_condFieldPath + ".C270" );
        m_COND271 = this->navigate( m_condFieldPath + ".C271" );
        m_COND272 = this->navigate( m_condFieldPath + ".C272" );
        m_COND273 = this->navigate( m_condFieldPath + ".C273" );
        m_COND274 = this->navigate( m_condFieldPath + ".C274" );
        m_COND275 = this->navigate( m_condFieldPath + ".C275" );
        m_COND276 = this->navigate( m_condFieldPath + ".C276" );
        m_COND277 = this->navigate( m_condFieldPath + ".C277" );
        m_COND278 = this->navigate( m_condFieldPath + ".C278" );
        m_COND279 = this->navigate( m_condFieldPath + ".C279" );
        m_COND280 = this->navigate( m_condFieldPath + ".C280" );
        m_COND281 = this->navigate( m_condFieldPath + ".C281" );
        m_COND282 = this->navigate( m_condFieldPath + ".C282" );
        m_COND283 = this->navigate( m_condFieldPath + ".C283" );
        m_COND284 = this->navigate( m_condFieldPath + ".C284" );
        m_COND285 = this->navigate( m_condFieldPath + ".C285" );
        m_COND286 = this->navigate( m_condFieldPath + ".C286" );
        m_COND287 = this->navigate( m_condFieldPath + ".C287" );
        m_COND288 = this->navigate( m_condFieldPath + ".C288" );
        m_COND289 = this->navigate( m_condFieldPath + ".C289" );
        m_COND290 = this->navigate( m_condFieldPath + ".C290" );
        m_COND291 = this->navigate( m_condFieldPath + ".C291" );
        m_COND292 = this->navigate( m_condFieldPath + ".C292" );
        m_COND293 = this->navigate( m_condFieldPath + ".C293" );
        m_COND294 = this->navigate( m_condFieldPath + ".C294" );
        m_COND295 = this->navigate( m_condFieldPath + ".C295" );
        m_COND296 = this->navigate( m_condFieldPath + ".C296" );
        m_COND297 = this->navigate( m_condFieldPath + ".C297" );
        m_COND298 = this->navigate( m_condFieldPath + ".C298" );
        m_COND299 = this->navigate( m_condFieldPath + ".C299" );
        m_COND300 = this->navigate( m_condFieldPath + ".C300" );      
        m_COND301 = this->navigate( m_condFieldPath + ".C301" );
        m_COND302 = this->navigate( m_condFieldPath + ".C302" );
        m_COND303 = this->navigate( m_condFieldPath + ".C303" );
        m_COND304 = this->navigate( m_condFieldPath + ".C304" );
        m_COND305 = this->navigate( m_condFieldPath + ".C305" );
        m_COND306 = this->navigate( m_condFieldPath + ".C306" );
        m_COND307 = this->navigate( m_condFieldPath + ".C307" );
        m_COND308 = this->navigate( m_condFieldPath + ".C308" );
        m_COND309 = this->navigate( m_condFieldPath + ".C309" );
        m_COND310 = this->navigate( m_condFieldPath + ".C310" );
        m_COND311 = this->navigate( m_condFieldPath + ".C311" );
        m_COND312 = this->navigate( m_condFieldPath + ".C312" );
        m_COND313 = this->navigate( m_condFieldPath + ".C313" );
        m_COND314 = this->navigate( m_condFieldPath + ".C314" );
        m_COND315 = this->navigate( m_condFieldPath + ".C315" );
        m_COND316 = this->navigate( m_condFieldPath + ".C316" );
        m_COND317 = this->navigate( m_condFieldPath + ".C317" );
        m_COND318 = this->navigate( m_condFieldPath + ".C318" );
        m_COND319 = this->navigate( m_condFieldPath + ".C319" );
        m_COND320 = this->navigate( m_condFieldPath + ".C320" );
        m_COND321 = this->navigate( m_condFieldPath + ".C321" );
        m_COND322 = this->navigate( m_condFieldPath + ".C322" );
        m_COND323 = this->navigate( m_condFieldPath + ".C323" );
        m_COND324 = this->navigate( m_condFieldPath + ".C324" );
        m_COND325 = this->navigate( m_condFieldPath + ".C325" );
        m_COND326 = this->navigate( m_condFieldPath + ".C326" );
        m_COND327 = this->navigate( m_condFieldPath + ".C327" );
        m_COND328 = this->navigate( m_condFieldPath + ".C328" );
        m_COND329 = this->navigate( m_condFieldPath + ".C329" );
        m_COND330 = this->navigate( m_condFieldPath + ".C330" );
        m_COND331 = this->navigate( m_condFieldPath + ".C331" );
        m_COND332 = this->navigate( m_condFieldPath + ".C332" );
        m_COND333 = this->navigate( m_condFieldPath + ".C333" );
        m_COND334 = this->navigate( m_condFieldPath + ".C334" );
        m_COND335 = this->navigate( m_condFieldPath + ".C335" );
        m_COND336 = this->navigate( m_condFieldPath + ".C336" );
        m_COND337 = this->navigate( m_condFieldPath + ".C337" );
        m_COND338 = this->navigate( m_condFieldPath + ".C338" );
        m_COND339 = this->navigate( m_condFieldPath + ".C339" );
        m_COND340 = this->navigate( m_condFieldPath + ".C340" );
        m_COND341 = this->navigate( m_condFieldPath + ".C341" );
        m_COND342 = this->navigate( m_condFieldPath + ".C342" );
        m_COND343 = this->navigate( m_condFieldPath + ".C343" );
        m_COND344 = this->navigate( m_condFieldPath + ".C344" );
        m_COND345 = this->navigate( m_condFieldPath + ".C345" );
        m_COND346 = this->navigate( m_condFieldPath + ".C346" );
        m_COND347 = this->navigate( m_condFieldPath + ".C347" );
        m_COND348 = this->navigate( m_condFieldPath + ".C348" );
        m_COND349 = this->navigate( m_condFieldPath + ".C349" );
        m_COND350 = this->navigate( m_condFieldPath + ".C350" );        
        condicao351 = this->navigate( string(m_condFieldPath).append(".C351") );
		condicao352 = this->navigate( string(m_condFieldPath).append(".C352") );
        condicao353 = this->navigate( string(m_condFieldPath).append(".C353") );
        
        de47Tag02 = this->navigate( m_tagsDE047FieldPath + ".02" );
        dataElement47Tag29 = this->navigate( string(m_tagsDE047FieldPath).append(".29") );
        de47Tag33 = this->navigate( m_tagsDE047FieldPath + ".33" );
        de47Tag55 = this->navigate( m_tagsDE047FieldPath + ".55" );

        m_TAG56_07 = this->navigate( m_tagsDE056FieldPath + ".07" );
        m_TAG56_08 = this->navigate( m_tagsDE056FieldPath + ".08" );
        m_TAG56_0D = this->navigate( m_tagsDE056FieldPath + ".0D" );
        m_TAG56_16 = this->navigate( m_tagsDE056FieldPath + ".16" );

        return( true );
    }

    void DEsEnviados::finish( )
    {
    }

    DEsEnviados& DEsEnviados::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    DEsEnviados& DEsEnviados::setCondFieldPath( const std::string& a_path )
    {
        m_condFieldPath = a_path;
        return( *this );
    }
   
    DEsEnviados& DEsEnviados::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    DEsEnviados& DEsEnviados::setTagsDE047FieldPath( const std::string& a_path )
    {
        m_tagsDE047FieldPath = a_path;
        return( *this );
    }
    
        DEsEnviados& DEsEnviados::setTagsDE056FieldPath( const std::string& a_path )
    {
        m_tagsDE056FieldPath = a_path;
        return( *this );
    }
    
    DEsEnviados& DEsEnviados::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }
 
    dataManip::Command* DEsEnviados::clone( ) const
    {
        return( new DEsEnviados( *this ) );
    }
    
    
}