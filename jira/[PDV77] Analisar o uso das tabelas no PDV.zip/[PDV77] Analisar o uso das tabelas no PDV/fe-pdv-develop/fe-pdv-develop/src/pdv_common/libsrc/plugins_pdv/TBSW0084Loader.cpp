#pragma once
#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbaccess_pdv/TBSW0084RegrasFormatacao.hpp"
#include "plugins_pdv/TBSW0084Loader.hpp"

namespace plugins_pdv
{

    base::Identificable* createTBSW0084Loader()
    {
        TBSW0084Loader* l_new = new TBSW0084Loader;
        return l_new;
    }

    bool TBSW0084Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    TBSW0084Loader::TBSW0084Loader()
    {
    }

    TBSW0084Loader::~TBSW0084Loader()
    {
    }

    bool TBSW0084Loader::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_dat_mov_tran = this->navigate( m_targetFieldPath + ".DAT_MOV_TRAN" );
        m_cod_term = this->navigate( m_targetFieldPath + ".COD_TERM" );
        m_num_stan = this->navigate( m_targetFieldPath + ".NUM_STAN" );
        m_dth_ini_tran = this->navigate( m_targetFieldPath + ".DTH_INI_TRAN" );
        m_num_estb = this->navigate( m_targetFieldPath + ".NUM_ESTB" );
        m_cod_pnpd_pdv = this->navigate( m_targetFieldPath + ".COD_PNPD_PDV" );
        m_nom_fbrc_pnpd = this->navigate( m_targetFieldPath + ".NOM_FBRC_PNPD" );
        m_num_sre_pnpd = this->navigate( m_targetFieldPath + ".NUM_SRE_PNPD" );
        m_cod_vers_hdw_pnpd = this->navigate( m_targetFieldPath + ".COD_VERS_HDW_PNPD" );
        m_cod_vers_frwr_pnpd = this->navigate( m_targetFieldPath + ".COD_VERS_FRWR_PNPD" );
        m_nom_fbrc_tef = this->navigate( m_targetFieldPath + ".NOM_FBRC_TEF" );
        m_cod_vers_sftw_tef = this->navigate( m_targetFieldPath + ".COD_VERS_SFTW_TEF" );
        m_nom_fbrc_atmc = this->navigate( m_targetFieldPath + ".NOM_FBRC_ATMC" );
        m_cod_vers_sftw_atmc = this->navigate( m_targetFieldPath + ".COD_VERS_SFTW_ATMC" );
        m_qtd_leit_magn = this->navigate( m_targetFieldPath + ".QTD_LEIT_MAGN" );
        m_qtd_err_leit_magn = this->navigate( m_targetFieldPath + ".QTD_ERR_LEIT_MAGN" );
        m_qtd_snha_magn = this->navigate( m_targetFieldPath + ".QTD_SNHA_MAGN" );
        m_qtd_err_snha_magn = this->navigate( m_targetFieldPath + ".QTD_ERR_SNHA_MAGN" );
        m_qtd_snha_chip_onln = this->navigate( m_targetFieldPath + ".QTD_SNHA_CHIP_ONLN" );
        m_qtd_err_snha_chip_onln = this->navigate( m_targetFieldPath + ".QTD_ERR_SNHA_CHIP_ONLN" );
        m_qtd_snha_chip_ofln = this->navigate( m_targetFieldPath + ".QTD_SNHA_CHIP_OFLN" );
        m_qtd_err_snha_chip_ofln = this->navigate( m_targetFieldPath + ".QTD_ERR_SNHA_CHIP_OFLN" );
        m_qtd_blqd_chip = this->navigate( m_targetFieldPath + ".QTD_BLQD_CHIP" );
        m_qtd_leit_chip = this->navigate( m_targetFieldPath + ".QTD_LEIT_CHIP" );
        m_qtd_fallback_cre = this->navigate( m_targetFieldPath + ".QTD_FALLBACK_CRE" );
        m_qtd_fallback_deb = this->navigate( m_targetFieldPath + ".QTD_FALLBACK_DEB" );
        m_cod_vers_sftw_pnpd = this->navigate( m_targetFieldPath + ".COD_VERS_SFTW_PNPD" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_terminal_pdv = this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );

        return true;
    }

    void TBSW0084Loader::finish()
    {
    }

    int TBSW0084Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_local_date, l_msgtype;
            std::string l_terminal_pdv, l_num_stan, l_refnum, l_origrefnum;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_terminal_pdv, m_terminal_pdv );
            fieldSet::fsextr( l_num_stan, m_num_stan );
            fieldSet::fsextr( l_refnum, m_refnum );
            fieldSet::fsextr( l_msgtype, m_msgtype );
            fieldSet::fsextr( l_origrefnum, m_origrefnum );

            l_whereClause << "DAT_MOV_TRAN = " << l_local_date;
            if( strlen( l_refnum.c_str() ) > 0 && ( l_msgtype == 100 || l_msgtype == 200 ) )
            {
                l_whereClause << " AND NUM_SEQ_UNC = " << l_refnum;
            }
            else if ( strlen( l_origrefnum.c_str() ) > 0 )
            {
                l_whereClause << " AND NUM_SEQ_UNC = " << l_origrefnum;
            }
            if( strlen( l_terminal_pdv.c_str() ) > 0 )
            {
                l_whereClause << " AND COD_TERM = '" << l_terminal_pdv << "'";
            }
            dbaccess_common::TBSW0084 l_TBSW0084( l_whereClause.str() );

            l_TBSW0084.prepare();
            l_TBSW0084.execute();
            int ret = l_TBSW0084.fetch();
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "OK", 2 );

                fieldSet::fscopy( m_dat_mov_tran, l_TBSW0084.get_DAT_MOV_TRAN() );
                fieldSet::fscopy( m_cod_term, l_TBSW0084.get_COD_TERM() );
                fieldSet::fscopy( m_dth_ini_tran, l_TBSW0084.get_DTH_INI_TRAN() );
                fieldSet::fscopy( m_num_estb, l_TBSW0084.get_NUM_ESTB() );
                fieldSet::fscopy( m_cod_pnpd_pdv, l_TBSW0084.get_COD_PNPD_PDV() );
                fieldSet::fscopy( m_nom_fbrc_pnpd, l_TBSW0084.get_NOM_FBRC_PNPD() );
                fieldSet::fscopy( m_num_sre_pnpd, l_TBSW0084.get_NUM_SRE_PNPD() );
                fieldSet::fscopy( m_cod_vers_hdw_pnpd, l_TBSW0084.get_COD_VERS_HDW_PNPD() );
                fieldSet::fscopy( m_cod_vers_frwr_pnpd, l_TBSW0084.get_COD_VERS_FRWR_PNPD() );
                fieldSet::fscopy( m_nom_fbrc_tef, l_TBSW0084.get_NOM_FBRC_TEF() );
                fieldSet::fscopy( m_cod_vers_sftw_tef, l_TBSW0084.get_COD_VERS_SFTW_TEF() );
                fieldSet::fscopy( m_nom_fbrc_atmc, l_TBSW0084.get_NOM_FBRC_ATMC() );
                fieldSet::fscopy( m_cod_vers_sftw_atmc, l_TBSW0084.get_COD_VERS_SFTW_ATMC() );
                fieldSet::fscopy( m_qtd_leit_magn, l_TBSW0084.get_QTD_LEIT_MAGN() );
                fieldSet::fscopy( m_qtd_err_leit_magn, l_TBSW0084.get_QTD_ERR_LEIT_MAGN() );
                fieldSet::fscopy( m_qtd_snha_magn, l_TBSW0084.get_QTD_SNHA_MAGN() );
                fieldSet::fscopy( m_qtd_err_snha_magn, l_TBSW0084.get_QTD_ERR_SNHA_MAGN() );
                fieldSet::fscopy( m_qtd_snha_chip_onln, l_TBSW0084.get_QTD_SNHA_CHIP_ONLN() );
                fieldSet::fscopy( m_qtd_err_snha_chip_onln, l_TBSW0084.get_QTD_ERR_SNHA_CHIP_ONLN() );
                fieldSet::fscopy( m_qtd_snha_chip_ofln, l_TBSW0084.get_QTD_SNHA_CHIP_OFLN() );
                fieldSet::fscopy( m_qtd_err_snha_chip_ofln, l_TBSW0084.get_QTD_ERR_SNHA_CHIP_OFLN() );
                fieldSet::fscopy( m_qtd_blqd_chip, l_TBSW0084.get_QTD_BLQD_CHIP() );
                fieldSet::fscopy( m_qtd_leit_chip, l_TBSW0084.get_QTD_LEIT_CHIP() );
                fieldSet::fscopy( m_qtd_fallback_cre, l_TBSW0084.get_QTD_FALLBACK_CRE() );
                fieldSet::fscopy( m_qtd_fallback_deb, l_TBSW0084.get_QTD_FALLBACK_DEB() );
                fieldSet::fscopy( m_cod_vers_sftw_pnpd, l_TBSW0084.get_COD_VERS_SFTW_PNPD() );

                char l_bufferTemp[64];
                oasis_dec_t l_dec_temp;

                l_dec_temp = l_TBSW0084.get_NUM_STAN( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_stan, std::string( l_bufferTemp ) );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0084 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0084 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW0084Loader& TBSW0084Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0084Loader& TBSW0084Loader::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0084Loader::clone() const
    {
        return new TBSW0084Loader(*this);
    }

}//namespace plugins_pdv
