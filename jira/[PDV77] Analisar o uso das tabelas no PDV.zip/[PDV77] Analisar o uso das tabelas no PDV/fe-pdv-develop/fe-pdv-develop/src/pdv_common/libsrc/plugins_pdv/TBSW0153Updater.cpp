#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "plugins_pdv/TBSW0153Updater.hpp"
#include "dbaccess_pdv/TBSW0153RegrasFormatacao.hpp"
//TODOSW75 #include "dualHandler.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0153Updater( )
    {
        TBSW0153Updater* l_new = new TBSW0153Updater;     
        return( l_new );
    }
    
    TBSW0153Updater::TBSW0153Updater( )
    {
    }
    
    TBSW0153Updater::~TBSW0153Updater( )
    {
    }
    
    bool TBSW0153Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );
        
        return( true );
    }
    
    bool TBSW0153Updater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =      this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =          this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_pb_reason_code =  this->navigate( m_sourceFieldPath + ".segments.common.pb_reason_code" ); // TO DO: DUVIDA NA PLANILHA "Controle de Questoes Respostas"
        m_aval_balance =    this->navigate( m_sourceFieldPath + ".shc_msg.aval_balance" );
        modoEntrada =       this->navigate( m_sourceFieldPath + ".segments.common.msg_entrymode" );
        respcode =          this->navigate( m_sourceFieldPath + ".shc_msg.respcode" );
        
        return( true );
    }
    
    void TBSW0153Updater::finish( )
    {
    }
    
    int TBSW0153Updater::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream  l_whereClause;
            unsigned long       l_local_date = 0;
            unsigned long       l_refnum = 0;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum,     m_refnum );

            l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0153 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );

            dbaccess_common::TBSW0153 l_table0153( l_whereClause.str( ) );
            dbaccess_pdv::TBSW0153RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0153_params params = { 0 };

            l_table0153.prepare_for_update( );
            l_table0153.execute( );
            //TODOSW75 
            /***
            dbaccess_common::DualHandler  l_dualHand( &l_table0153 );
            int ret = l_dualHand.fetch();
            ***/
            int ret = l_table0153.fetch();
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {
                fieldSet::fsextr( params.pb_reason_code,    m_pb_reason_code );
                fieldSet::fsextr( params.aval_balance,      m_aval_balance );
                fieldSet::fsextr( params.msg_entrymode,     modoEntrada );
                fieldSet::fsextr( params.respcode,          respcode );

                regrasFmt.IND_VAL_APR_SLDO_DSPL ( l_table0153, params, acq_common::UPDATE );
                regrasFmt.VAL_EFTV_APRV         ( l_table0153, params, acq_common::UPDATE );

                l_table0153.update( );
                l_table0153.commit( );
                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            std::string l_msg = "Exception in TBSW0153 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            std::string l_msg = "std::exception in TBSW0153 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return( 0 );
    }
    
    TBSW0153Updater& TBSW0153Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
    TBSW0153Updater& TBSW0153Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    
    dataManip::Command* TBSW0153Updater::clone( ) const
    {
        return( new TBSW0153Updater( *this ) );
    }

} // namespace plugins_pdv
