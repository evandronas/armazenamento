#include <dbaccess_pdv/TBSW0084RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    TBSW0084RegrasFormatacao::TBSW0084RegrasFormatacao( )
    {
    }

    TBSW0084RegrasFormatacao::~TBSW0084RegrasFormatacao( )
    {
    }
}