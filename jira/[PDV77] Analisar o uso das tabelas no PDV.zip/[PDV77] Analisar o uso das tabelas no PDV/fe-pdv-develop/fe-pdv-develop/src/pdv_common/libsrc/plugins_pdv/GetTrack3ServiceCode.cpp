#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "msgConv/TextConv.hpp"
#include "plugins_pdv/GetTrack3ServiceCode.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
	base::Identificable* createGetTrack3ServiceCode( )
	{
		GetTrack3ServiceCode* l_new = new GetTrack3ServiceCode;
		return( l_new );
	}
	
	GetTrack3ServiceCode::GetTrack3ServiceCode( )
	{
	}
	GetTrack3ServiceCode::~GetTrack3ServiceCode( )
	{
	}
	dataManip::Command* GetTrack3ServiceCode::clone( ) const
    {
        return( new GetTrack3ServiceCode( *this ) );
    }
	
	bool GetTrack3ServiceCode::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		
		a_tag->findTag( "sourceFieldPath", l_tagList );
		std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setSourceFieldPath( l_sourcePath );
		
		a_tag->findTag( "targetFieldPath", l_tagList );
		std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setTargetFieldPath( l_targetPath );
		
		return( true );
	}
	
	bool GetTrack3ServiceCode::init( )
    {
        m_track3  = this->navigate( m_sourceFieldPath + ".track3" );
        m_service_code = this->navigate( m_targetFieldPath + ".service_code" );
        return( true );
    }	
	void GetTrack3ServiceCode::finish( )
	{
	}
	
	int GetTrack3ServiceCode::execute( bool& a_stop )
    {
        try
        {
			std::string l_track3;
            fieldSet::fsextr( l_track3, m_track3 );
            if ( strlen( l_track3.c_str( ) ) )
            {
				std::size_t sepPos;
                sepPos = l_track3.find( '^' );
                sepPos = l_track3.find( '^', sepPos + 1 );
				//+01 (^) +04 (ExpiryDate) +03 (ServiceCode) = 8
                if ( ( sepPos != std::string::npos ) && ( ( sepPos + 8 ) < strlen( l_track3.c_str( ) ) ) )
                {
					//+1 (^) +04 (ExpiryDate) = 5
					std::string l_service_code = l_track3.substr( sepPos + 5, 3 );
                    fieldSet::fscopy( m_service_code, l_service_code );
                }
            }
        }
        catch ( base::GenException e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in GetTrack3ServiceCode <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in GetTrack3ServiceCode <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
		
        a_stop = false;
        return( 0 );
    }
	
	GetTrack3ServiceCode& GetTrack3ServiceCode::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    GetTrack3ServiceCode& GetTrack3ServiceCode::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }
}


