#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "plugins_pdv/TBSW0031Updater.hpp"
#include "dbaccess_pdv/TBSW0031RegrasFormatacao.hpp"
//TODOSW75 #include "dualHandler.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0031Updater( )
    {
        TBSW0031Updater* l_new = new TBSW0031Updater;
        return l_new;
    }

    TBSW0031Updater::TBSW0031Updater( )
    {
    }

    TBSW0031Updater::~TBSW0031Updater( )
    {
    }

    bool TBSW0031Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size( ); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value( );
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return true;
    }

    bool TBSW0031Updater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =          this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =              this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_msgtype =             this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_origrefnum =          this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_origdate =            this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_iss_name =            this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_ext_refnum =          this->navigate( m_sourceFieldPath + ".segments.common.ext_refnum" );
        m_status =              this->navigate( m_sourceFieldPath + ".segments.common.status" );
        m_is_van =              this->navigate( m_sourceFieldPath + ".segments.common.is_van" );
        m_mc_info_prod_code =   this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_prod_code" );
        m_mc_info_region =      this->navigate( m_sourceFieldPath + ".segments.credit.mc_info_region" );
        m_num_ref_tran =        this->navigate( m_sourceFieldPath + ".segments.credit.numeroTransacaoEmissor" );
        m_cod_cpcd_term =       this->navigate( m_sourceFieldPath + ".segments.credit.codigoCapacidadeTerminalEmissor" );

        return true;
    }

    void TBSW0031Updater::finish( )
    {
    }

    int TBSW0031Updater::execute( bool& a_stop )
    {
        try
        {
            // Montando a clausula where
            std::ostringstream  l_whereClause;
            unsigned long       l_msgtype = 0;
            unsigned long       l_local_date = 0;
            unsigned long       l_origdate = 0;
            unsigned long       l_refnum = 0;
            unsigned long       l_origrefnum = 0;

            fieldSet::fsextr( l_local_date,         m_local_date );
            fieldSet::fsextr( l_refnum,             m_refnum );
            fieldSet::fsextr( l_msgtype,            m_msgtype );
            fieldSet::fsextr( l_origrefnum,         m_origrefnum );
            fieldSet::fsextr( l_origdate,           m_origdate );

            switch ( l_msgtype )
            {
                case 110 :
                case 210 :
                case 230 :
                case 410 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
                    break;
                case 430 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
                    break;
                default:
                    fieldSet::fscopy( m_result, "EMPTY QUERY", 11 );
                    a_stop = false;
                    return 0;
                    break;
            }

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0031 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );

            dbaccess_common::TBSW0031 l_table0031( l_whereClause.str( ) );
            dbaccess_pdv::TBSW0031RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0031_params params = { 0 };

            l_table0031.prepare_for_update( );
            l_table0031.execute( );
            //TODOSW75 
            /***
            dbaccess_common::DualHandler l_dualHand( &l_table0031 );
            int ret = l_dualHand.fetch( );
            ***/
            int ret = l_table0031.fetch( );
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {
                fieldSet::fsextr( params.iss_name,          m_iss_name );
                fieldSet::fsextr( params.ext_refnum,        m_ext_refnum );
                fieldSet::fsextr( params.status,            m_status );
                fieldSet::fsextr( params.is_van,            m_is_van );
                fieldSet::fsextr( params.mc_info_prod_code, m_mc_info_prod_code );
                fieldSet::fsextr( params.mc_info_region,    m_mc_info_region );
                fieldSet::fsextr( params.num_ref_tran,      m_num_ref_tran );
                fieldSet::fsextr( params.cod_cpcd_term,     m_cod_cpcd_term );

                regrasFmt.NUM_SEQ_UNC_RD_AUT( l_table0031, params, acq_common::UPDATE );
                regrasFmt.COD_PROD_MTC      ( l_table0031, params, acq_common::UPDATE );
                regrasFmt.COD_RGAO_MTC      ( l_table0031, params, acq_common::UPDATE );
                regrasFmt.NUM_REF_TRAN      ( l_table0031, params, acq_common::UPDATE );
                regrasFmt.COD_CPCD_TERM     ( l_table0031, params, acq_common::UPDATE );

                l_table0031.update( );
                l_table0031.commit( );

                fieldSet::fscopy( m_result, "OK", 2 );
            }

        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0031 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0031 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW0031Updater& TBSW0031Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    TBSW0031Updater& TBSW0031Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    TBSW0031Updater& TBSW0031Updater::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0031Updater::clone( ) const
    {
        return new TBSW0031Updater( *this );
    }
} // namespace plugins_pdv
