#include<dbaccess_pdv/TBSW0035RegrasFormatacao.hpp>
#include <algorithm>
#include <cstring>

namespace dbaccess_pdv
{
	TBSW0035RegrasFormatacao::TBSW0035RegrasFormatacao( )
	{
	}

	TBSW0035RegrasFormatacao::~TBSW0035RegrasFormatacao( )
	{
	}
	
	bool isNotDigit( char c )
	{
		return ( isdigit( c ) == 0 );
	}
	// Tratamentos de INSERTS
	
	void TBSW0035RegrasFormatacao::insert_DTH_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
        //DTH_BXA_TEC
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			struct tm l_dattim;
			memset( &l_dattim, 0, sizeof( l_dattim ) );
			l_dattim.tm_sec = 0;
			l_dattim.tm_min = atoi( params.bit63.substr( 81, 2 ).c_str() );
			l_dattim.tm_hour = atoi( params.bit63.substr( 79, 2 ).c_str() );
			l_dattim.tm_mday = atoi( params.bit63.substr( 73, 2 ).c_str() );
			l_dattim.tm_mon = atoi( params.bit63.substr( 75, 2 ).c_str() ) - 1;
			l_dattim.tm_year = atoi( params.bit63.substr( 77, 2 ).c_str() ) + 100;
			l_dattim.tm_isdst = -1;
			tbsw0035.set_DTH_BXA_TEC( mktime( &l_dattim ) );
		}
	}
	
	void TBSW0035RegrasFormatacao::insert_COD_ORDM_SERV( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
		//COD_ORDM_SERV
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			tbsw0035.set_COD_ORDM_SERV( params.bit63.substr(0,8) );
		}
	}
	
	void TBSW0035RegrasFormatacao::insert_COD_OCOR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
		//COD_OCOR
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			tbsw0035.set_COD_OCOR( params.bit63.substr(103,8) );
		}
	}
	
	void TBSW0035RegrasFormatacao::insert_NUM_TEL_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
		//NUM_TEL_ESTB 
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			std::string l_numTelEstb;
			oasis_dec_t l_dect;
			l_numTelEstb.assign( params.bit63.substr(53,20).c_str() );                
			l_numTelEstb.erase( std::remove_if( l_numTelEstb.begin(), 
												l_numTelEstb.end(), 
												isNotDigit ), 
							    l_numTelEstb.end() );   

			if ( l_numTelEstb.length() > 12 )
			{
				l_numTelEstb = l_numTelEstb.substr(0, 12);
			}
			             
			dbm_chartodec( &l_dect, l_numTelEstb.c_str() , 0 ); 
			tbsw0035.set_NUM_TEL_ESTB( l_dect );        
		}
	}
	
	void TBSW0035RegrasFormatacao::insert_TXT_ENDR_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
		//TXT_ENDR_ESTB
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			tbsw0035.set_TXT_ENDR_ESTB( params.bit63.substr(33,20) );
		}
	}

	void TBSW0035RegrasFormatacao::insert_COD_ID_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
		//COD_ID_TEC
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			tbsw0035.set_COD_ID_TEC( params.bit63.substr(8,5) );
		}
	}
	
	void TBSW0035RegrasFormatacao::insert_COD_EPS( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
		//COD_EPS
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			tbsw0035.set_COD_EPS( params.bit63.substr(111,20) );
		}
	}

	void TBSW0035RegrasFormatacao::insert_COD_VERS_KRN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{	
		//COD_VERS_KRN
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			tbsw0035.set_COD_VERS_KRN( params.bit63.substr(83,20) );
		}
	}

	void TBSW0035RegrasFormatacao::insert_NOM_FNTS_PT_DE_VD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
		//NOM_FNTS_PT_DE_VD
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			tbsw0035.set_NOM_FNTS_PT_DE_VD( params.bit63.substr(13,20) );
		}
	}

	void TBSW0035RegrasFormatacao::insert_NUM_TEL_ADIC_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
	{
		//NUM_TEL_ADIC_ESTB
		if ( strlen( params.bit63.c_str() ) > 100 )
		{
			tbsw0035.set_NUM_TEL_ADIC_ESTB( params.bit63.substr(53,20) );
		}
	}
}