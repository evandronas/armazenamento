/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

#pragma once

#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "plugins_pdv/DefineNomeTrn.hpp"
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include <debug.h>
#include <ist_otrace.h>
#include <iomanip>

namespace plugins_pdv
{
    base::Identificable* createDefineNomeTrn( )
    {
        DefineNomeTrn* l_new = new DefineNomeTrn;
        return( l_new );
    }

    DefineNomeTrn::DefineNomeTrn( )
    {
    }

    DefineNomeTrn::~DefineNomeTrn( )
    {
    }

    bool DefineNomeTrn::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

        return( true );
    }

    bool DefineNomeTrn::init( )
    {
        m_msg_name      = this->navigate( m_targetFieldPath + ".segments.common.msg_name" );
        
        m_msgtype         = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_pcode           = this->navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        
        m_pdv_trn_id      = this->navigate( m_sourceFieldPath + ".segments.common.pdv_trn_id" );
        m_install_num     = this->navigate( m_sourceFieldPath + ".segments.common.install_num" );
        m_origmsg         = this->navigate( m_sourceFieldPath + ".shc_msg.origmsg" );        
        m_transactionId   = this->navigate( m_sourceFieldPath + ".segments.common.transactionId" );
        m_idPagFatura     = this->navigate( m_sourceFieldPath + ".segments.debt.idPagFatura" );        
        m_settlement_date = this->navigate( m_localFieldPath  + ".shc_msg.settlement_date" );
        m_loadInit        = this->navigate( m_localFieldPath  + ".LoadInit" );
        
        return( true );
    }

    void DefineNomeTrn::finish( )
    {
    }

    int DefineNomeTrn::execute( bool& a_stop )
    {        
        try
        {        
            long        l_msgtype;
            long        l_pcode;
            std::string l_pdv_trn_id;
            int         l_install_num;
            std::string l_origmsg;
            std::string l_transactionId;
            std::string l_settlement_date;
            int         l_idPagFatura; // nao esquecer de mudar o Advice de Pagamento de fatura    220    2000
            int         l_loadInit;    //220    2000    C1 = DO *1    ADV_VEND_DBT arrumar o *1
            char        l_log_buffer[ 1024 ] = { 0 };
            
            std::string nome_transacao("TRANSACAO_INVALIDA");
            
            fieldSet::fsextr( l_msgtype,         m_msgtype );
            fieldSet::fsextr( l_pcode,           m_pcode );
            fieldSet::fsextr( l_pdv_trn_id,      m_pdv_trn_id );
            fieldSet::fsextr( l_install_num,     m_install_num );
            fieldSet::fsextr( l_origmsg,         m_origmsg );
            fieldSet::fsextr( l_transactionId,   m_transactionId );
            fieldSet::fsextr( l_settlement_date, m_settlement_date );
            fieldSet::fsextr( l_idPagFatura,     m_idPagFatura );
            fieldSet::fsextr( l_loadInit,        m_loadInit );
            
            std::stringstream ss_origMsg;
            ss_origMsg << std::setw( 4 ) << std::setfill( '0' ) << l_origmsg;
            l_origmsg = ss_origMsg.str( );
            
            std::stringstream ss_transactionId;
            ss_transactionId << std::setw( 4 ) << std::setfill( '0' ) << l_transactionId;
            l_transactionId = ss_transactionId.str( );
            
            bool l_trnParcelada = false;
            bool l_settlementDatePresente = false;
            bool l_idPagFaturaPresente = false;
            
            if( l_install_num > 0 )
            {
                l_trnParcelada = true;
            }
            
            // verificar corretamente o que vai fazer com o l_settlement_date...
            //if( !l_settlement_date.empty( ) && std::atol( l_settlement_date.c_str( ) ) > 0 )
            //{
            //    l_settlementDatePresente = true;
            //}
            
            if( l_idPagFatura > 0 )
            {
                l_idPagFaturaPresente = true;
            }
            
            std::ostringstream l_log;
            l_log.clear();   
            
            defineNome( l_msgtype, 
                        l_pcode, 
                        l_pdv_trn_id,
                        l_trnParcelada,
                        l_origmsg,
                        l_transactionId,
                        l_idPagFaturaPresente,
                        l_settlementDatePresente,
                        l_loadInit,
                        nome_transacao,
                        l_log ); 
                        
            if ( nome_transacao.compare ( "TRANSACAO_INVALIDA" ) == 0 )
            {
                std::string aux = "<########## Erro plugin DefineNomeTrn ##########>\n"; 
                OTraceDebug( aux.c_str( ) );               
                
                std::ostringstream osAux;
                osAux.clear();
                osAux << "Dados de entrada: ";
                osAux << "msgtype["         << l_msgtype         << "],";
                osAux << "pcode["           << l_pcode           << "],";
                osAux << "pdv_trn_id["      << l_pdv_trn_id      << "],";
                osAux << "install_num["     << l_install_num     << "],";
                osAux << "origmsg["         << l_origmsg         << "],";
                osAux << "transactionId["   << l_transactionId   << "],";
                osAux << "idPagFatura["     << l_idPagFatura     << "],";
                osAux << "settlement_date[" << l_settlement_date << "],";
                osAux << "loadInit["        << l_loadInit        << "].\n";
                aux = osAux.str( );
                OTraceDebug( aux.c_str( ) );   
                aux = "</########## Erro plugin DefineNomeTrn ##########>\n";
                OTraceDebug( aux.c_str( ) );
            }
            
            fieldSet::fscopy( m_msg_name, nome_transacao.c_str( ), nome_transacao.length( ) );        
        }
        catch( base::GenException e )
        {
            std::string l_msg = "Exception in DefineNomeTrn <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            std::string l_msg = "std::exception in DefineNomeTrn <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }
    
    bool DefineNomeTrn::defineNome( const long &l_msgtype,
                                    const long &l_pcode,
                                    const std::string &l_pdv_trn_id,
                                    const bool &l_trnParcelada,
                                    const std::string &l_origMsg,
                                    const std::string &l_transactionId,
                                    const bool &l_idPagFaturaPresente,
                                    const bool &l_settlementDatePresente,
                                    const int  &l_loadInit,
                                    std::string &nome_transacao,
                                    std::ostringstream &l_log )
    {    
        // DEFINE NOME DA TRN E A CATEGORIA
        switch( l_msgtype )
        {
            //100    3000        C1 = (R1 ou R2 ou P) PREAUT / C1 = (AU) AUT_IATA
            //100    393000        C1 = ( AVS )         CONS_AVS
            //100    399000                             CONS_PL_VEND
            case 100:
            {
                if( l_pcode == 3000 )
                {
                    if( l_pdv_trn_id == "AU" )
                    {
                        nome_transacao = "AUT_IATA";
                    }
                    else
                    {
                        if(l_trnParcelada)
                        {
                            nome_transacao = "PREAUT_PARC_SJURO";
                        }
                        else
                        {
                            nome_transacao = "PREAUT";
                        }
                    }
                }
                else if( l_pcode == 393000 )
                {
                    nome_transacao = "CONS_AVS";
                }
                else if( l_pcode == 399000 )
                {
                    nome_transacao = "CONS_PL_VEND";
                }
                // Padronizacao Crediario PDV - INICIO
                else if ( l_pcode == 23000 )
                {
                    nome_transacao = "CREDIARIO_SIMUL";
                }
                // Padronizacao Crediario PDV - FIM
            }
            break;
            // Padronizacao Crediario PDV - INICIO
            case 102:
            {
                if ( l_pcode == 23000 )
                {
                    nome_transacao = "CONF_CREDIARIO_SIMUL";
                }
            }
            break;
            // Padronizacao Crediario PDV - FIM
            case 200:
            {
                if( l_pcode == 2000 )
                {
                    //200   2000    C1 = CP && DE047.031 presente   PAG_FATURA
                    //200   2000    C1 = CP ou AD (versoes obsol.)  VEND_DBT_AVISTA
                    //200   2000    C1 = PM                         VEND_PARC_MAIS Descontinuada
                    //200|2000|C1 = PC && C4 = 0316|VEND_DBT_CORBAN
                    if ( l_pdv_trn_id == "AD" )
                    {
                        nome_transacao = "VEND_DBT_AVISTA";
                    }
                    if ( l_pdv_trn_id == "PM" )
                    {
                        nome_transacao = "VEND_PARC_MAIS";
                    }
                    if( l_pdv_trn_id == "CP" )
                    {
                        if ( l_idPagFaturaPresente )
                        {
                            nome_transacao = "PAG_FATURA_DBT";
                        }
                        else
                        {
                            nome_transacao = "VEND_DBT_AVISTA";
                        }
                   }
                   if(l_pdv_trn_id == "PC" )
                   {
                        if( l_transactionId == "0316" )
                        {
                            nome_transacao = "VEND_DBT_CORBAN";
                        }
                   }
                }
                else if( l_pcode == 2800 )
                {
                    //200   2800        PAG_CON_DEB Descontinuada
                    nome_transacao = "PAG_CON_DEB";
                }
                else if( l_pcode == 2900 )
                {
                    //200   2900        VEND_DBT_PREDAT
                    nome_transacao = "VEND_DBT_PREDAT";
                }
                else if( l_pcode == 3000 )
                {
                    //200   3000    C1 = (R1 ou R2) && C2 = True    VEND_CRT_PARC_SJURO
                    //200   3000    C1 = (R1 ou R2)                 VEND_CRT
                    if ( l_trnParcelada )
                    {
                        nome_transacao = "VEND_CRT_PARC_SJURO";
                    }
                    else
                    {
                        nome_transacao = "VEND_CRT";
                    }
					
					if( l_pdv_trn_id == "CP" )
                    {
                        if ( l_idPagFaturaPresente )
                        {
                            nome_transacao = "PAG_FATURA_CRT";
                        }
                    }
                }
                else if( l_pcode == 3009 )
                {
                    //200   3009    C1 = (R1 ou R2) && C2 = True    VEND_IATA_PARC_SJURO
                    //200   3009    C1 = (R1 ou R2)                    VEND_IATA_AVISTA
                    if ( l_trnParcelada )
                    {
                        nome_transacao = "VEND_IATA_PARC_SJURO";
                    }
                    else
                    {
                        nome_transacao = "VEND_IATA_AVISTA";
                    }
                }    
                // Padronizacao Crediario PDV - INICIO
                else if ( l_pcode == 3700 )
                {
                    nome_transacao = "CREDIARIO_VENDA";
                }    
                // Padronizacao Crediario PDV - FIM
                else if( l_pcode == 3800 )
                {
                    //200    3800    C1 = (R1 ou R2)    VEND_CRT_PARC_CJURO
                    nome_transacao = "VEND_CRT_PARC_CJURO";
                }    
                else if( l_pcode == 3900 )
                {
                    //200    3900    C1 = (R1 ou R2)    VEND_IATA_PARC_CJURO
                    nome_transacao = "VEND_IATA_PARC_CJURO";
                }
                else if( l_pcode == 9000 )
                {
                    //200|9000|C1 = DA|VEND_PL
                    nome_transacao = "VEND_PL";
                }    
                else if( l_pcode == 90000 )
                {
                    //200|90000|C1 = CP|VEND_CSAQ
                    nome_transacao = "VEND_CSAQ";
                }
                else if( l_pcode == 182000 )
                {
                    //200    182000    C1 = VF    VEND_VCH_FROT    
                    nome_transacao = "VEND_VCH_FROT";
                }
                else if( l_pcode == 183000 )
                {
                    //200    183000    C1 = VO    VEND_VCH    
                    nome_transacao = "VEND_VCH";
                }

            }
            break;
            case 202:
            {            
            
                if( l_pcode == 2000 )
                {
                    //202|2000 |    |CONF_VEND_DBT_GEN
                    nome_transacao = "CONF_VEND_DBT_GEN";
                }
                else if( l_pcode == 2900 )
                {
                    //202|2900 |    |CONF_VEND_DBT_PREDAT
                    nome_transacao = "CONF_VEND_DBT_PREDAT";
                }
                else if( l_pcode == 3000 )
                {
                    //202|3000  |C2 = true|CONF_VEND_CRT    
                    nome_transacao = "CONF_VEND_CRT";
                }
                else if( l_pcode == 3009 )
                {
                    //202|3009  |         |CONF_VEND_IATA
                    nome_transacao = "CONF_VEND_IATA";
                }
                else if( l_pcode == 3900 )
                {
                    //202|3900  |C2 = true|CONF_VEND_IATA_PARC_CJURO
                    nome_transacao = "CONF_VEND_IATA_PARC_CJURO";
                }
                // Padronizacao Crediario PDV - INICIO
                else if ( l_pcode == 3700 )
                {
                    nome_transacao = "CONF_CREDIARIO_VENDA";
                }    
                // Padronizacao Crediario PDV - FIM
                else if( l_pcode == 3800 )
                {
                    //202|3800  |C2 = true|CONF_VEND_CRT_PARC_CJURO
                    nome_transacao = "CONF_VEND_CRT_PARC_CJURO";
                }
                else if( l_pcode == 9000 )
                {
                    //202|9000  |         |CONF_VEND_PL
                    nome_transacao = "CONF_VEND_PL";
                }
                else if( l_pcode == 90000 )
                {
                    //202|90000 |         |CONF_VEND_CSAQ
                    nome_transacao = "CONF_VEND_CSAQ";
                }
                else if( l_pcode == 182000 )
                {
                    //202|182000|         |CONF_VEND_VCH_FROT
                    nome_transacao = "CONF_VEND_VCH_FROT";
                }
                else if( l_pcode == 183000 )
                {
                    //202|183000|         |CONF_VEND_VCH
                    nome_transacao = "CONF_VEND_VCH";
                }    
            }
            break;
            case 220:
            {
                if( l_pcode == 2000 )
                {
                    if( l_pdv_trn_id == "DO" )
                    {
                        //220|2000|C1 = DO && settlement_date|ADV_PAG_FATURA
                        //220|2000|C1 = DO                   |ADV_VEND_DBT
                        if( l_idPagFaturaPresente )
                        {
                            nome_transacao = "ADV_PAG_FATURA_DBT";
                        }
                        else
                        {
                            nome_transacao = "ADV_VEND_DBT";
                        }
                    }
                    if( l_pdv_trn_id == "NE" )
                    {
                        //220|2000|C1 = NE && C4 = 0301|ADV_VEND_DBT_NEG
                        //220|2000|C1 = NE && C4 = 0303|ADV_VEND_DBT_PREDAT_NEG
                        if( l_transactionId == "0301" )
                        {
                            nome_transacao = "ADV_VEND_DBT_NEG";
                        }
                        else if( l_transactionId == "0303" )
                        {
                            nome_transacao = "ADV_VEND_DBT_PREDAT_NEG";
                        }
                    }
                }
                else if( l_pcode == 3000 )
                {
                    if( l_pdv_trn_id == "PA" || l_pdv_trn_id == "P" )
                    {
                        //220|3000|C1 = (PA ou P) && C2 = true|CONF_PREAUT_PARC_SJURO
                        //220|3000|C1 = (PA ou P)             |CONF_PREAUT
                        if( l_trnParcelada )
                        {
                            nome_transacao = "CONF_PREAUT_PARC_SJURO";
                        }
                        else
                        {
                            nome_transacao = "CONF_PREAUT";
                        }
                    }
                    else if( l_pdv_trn_id == "CO" )
                    {
						if( l_idPagFaturaPresente )
                        {
                            nome_transacao = "ADV_PAG_FATURA_CRT";
                        }
                        else
                        {
                        //220|3000|C1 = CO             |ADV_VEND_CRT
							nome_transacao = "ADV_VEND_CRT";
						}
                    }
                    else if( l_pdv_trn_id == "NE" )
                    {
                        //220|3000|C1 = NE && C4 = 0020|ADV_PREAUT_NEG
                        //220|3000|C1 = NE && C4 = 0350|ADV_VEND_CRT_NEG
                        //220|3000|C1 = NE && C4 = 0351|ADV_VEND_CRT_PARC_CJUROS_NEG
                        //220|3000|C1 = NE && C4 = 0352|ADV_VEND_CRT_PARC_SJUROS_NEG
                        //220|3000|C1 = NE && C4 = 0454|ADV_CONF_PREAUT_NEG
                        //220|3000|C1 = NE && C4 = 0455|ADV_CONF_PREAUT_PARC_NEG
                        if( l_transactionId == "0020" )
                        {
                            nome_transacao = "ADV_PREAUT_NEG";
                        }
                        else if( l_transactionId == "0021" )
                        {
                            nome_transacao = "ADV_PREAUT_PSJ_NEG";
                        }
                        else if( l_transactionId == "0350" )
                        {
                            nome_transacao = "ADV_VEND_CRT_NEG";
                        }
                        else if( l_transactionId == "0351" )
                        {
                            nome_transacao = "ADV_VEND_CRT_PARC_CJUROS_NEG";
                        }
                        else if( l_transactionId == "0352" )
                        {
                            nome_transacao = "ADV_VEND_CRT_PARC_SJUROS_NEG";
                        }
                        else if( l_transactionId == "0454" )
                        {
                            nome_transacao = "ADV_CONF_PREAUT_NEG";
                        }
                        else if( l_transactionId == "0455" )
                        {
                            nome_transacao = "ADV_CONF_PREAUT_PARC_NEG";
                        }
                    }
                }
                else if( l_pcode == 9000 )
                {
                    nome_transacao = "ADV_VEND_PL";
                }
                else if( l_pcode == 183000 )
                {
                    //220|183000|C1 = NE|ADV_VEND_VCH_NEG
                    //220|183000|C1 = V1|ADV_VEND_VCH
                    if( l_pdv_trn_id == "NE" )
                    {
                        nome_transacao = "ADV_VEND_VCH_NEG";
                    }
                    else if( l_pdv_trn_id == "V1" )
                    {
                        nome_transacao = "ADV_VEND_VCH";
                    }
                }
                else if( l_pcode == 182000 )
                {
                    //220|182000|C1 = NE|ADV_VEND_VCH_FROT_NEG
                    if( l_pdv_trn_id == "NE" )
                    {
                        nome_transacao = "ADV_VEND_VCH_FROT_NEG";
                    }
                }
            }
            break;                
            case 222:
            {
                //222|3000|CONF_PREAUT_3PERNA
                nome_transacao = "CONF_PREAUT_3PERNA";
            }
            break;
            case 400:
            {
                    
                if( l_pcode == 3000 )
                {
                    //400|3000|C1 = PA && C3 = 0100|EST_PREAUT
                    //400|3000|C1 = PA && C3 = 0220|EST_CONF_PREAUT_GEN
                    if( l_origMsg == "0100" )
                    {
                        nome_transacao = "EST_PREAUT";
                    }
                    else if( l_origMsg == "0220" )
                    {
                        nome_transacao = "EST_CONF_PREAUT_GEN";
                    }
                }
                // Padronizacao Crediario PDV - INICIO
                else if ( l_pcode == 3700 )
                {
                    nome_transacao = "EST_VEND_CRT_GEN";
                }
                // Padronizacao Crediario PDV - FIM
                else if( l_pcode == 9000 )
                {
                    //400|9000||EST_VEND_PL
                    nome_transacao = "EST_VEND_PL";
                }
                else if( l_pcode == 200000 )
                {
                    //400|200000||EST_VEND_CSAQ
                    nome_transacao = "EST_VEND_CSAQ";
                }
                else if( l_pcode == 200020 )
                {
                    //400|200020|C3 = 0200|EST_VEND_DBT_GEN
                    //400|200020|C3 = 0220|EST_ADV_VEND_DBT
                    //400|200020|C3 = 0200 && C4 = 0316|EST_VEND_DBT_CORBAN
                    if( l_origMsg == "0200" )
                    {
                        if( l_transactionId == "0316" )
                        {
                            nome_transacao = "EST_VEND_DBT_CORBAN";
                        }
                        else
                        {
                            nome_transacao = "EST_VEND_DBT_GEN";
                        }
                    }
                    else if( l_origMsg == "0220" )
                    {
                        nome_transacao = "EST_ADV_VEND_DBT";
                    }
                }
                else if( l_pcode == 200030 )
                {
                    //400|200030|C3 = 0200|EST_VEND_CRT_GEN
                    //400|200030|C3 = 0220|EST_ADV_VEND_CRT
                    if( l_origMsg == "0200" )
                    {
                        nome_transacao = "EST_VEND_CRT_GEN";
                    }
                    else if( l_origMsg == "0220" )
                    {
                        nome_transacao = "EST_ADV_VEND_CRT";
                    }
                }
                else if( l_pcode == 290020 )
                {
                    //400|290020||EST_VEND_VCH_FROT
                    nome_transacao = "EST_VEND_VCH_FROT";
                }
                else if( l_pcode == 290030 )
                {
                    //400|290030|C3 = 0200|EST_VEND_VCH
                    //400|290030|C3 = 0220|EST_ADV_VEND_VCH
                    if( l_origMsg == "0200" )
                    {
                        nome_transacao = "EST_VEND_VCH";
                    }
                    else if( l_origMsg == "0220" )
                    {
                        nome_transacao = "EST_ADV_VEND_VCH";
                    }
                }
            }
            break;
            case 420:
            {
                if( l_pcode == 2000 )
                {
                    //420|2000|C3 = 0200|DESF_VEND_DBT_GEN
                    //420|2000|C4 = 0316|DESF_VEND_DBT_CORBAN
                    if( l_transactionId == "0316" )
                    {
                        nome_transacao = "DESF_VEND_DBT_CORBAN";
                    }
                    else
                    {
                        nome_transacao = "DESF_VEND_DBT_GEN";
                    }
                }
                else if( l_pcode == 2900 )
                {
                    //420|2900|C3 = 0200|DESF_VEND_DBT_PREDAT
                    nome_transacao = "DESF_VEND_DBT_PREDAT";
                }
                else if( l_pcode == 3000 )
                {
                    //420|3000|C1 = PA && C3 = 0100|DESF_PREAUT
                    //420|3000|C1 = ?? && C3 = 0200|DESF_VEND_CRT_GEN
                    //420|3000|C1 = PA && C3 = 0220|DESF_CONF_PREAUT_GEN
                    //420|3000|C1 = PA && C3 = 0400|DESF_EST_CAT_PREAUT_GEN 
                    if( l_origMsg == "0100" )
                    {
                        nome_transacao = "DESF_PREAUT";
                    }
                    else if( l_origMsg == "0200" )
                    {
                        nome_transacao = "DESF_VEND_CRT_GEN";
                    }
                    else if( l_origMsg == "0220" )
                    {
                        nome_transacao = "DESF_CONF_PREAUT_GEN";
                    }
                    else if( l_origMsg == "0400" )
                    {
                        nome_transacao = "DESF_EST_CAT_PREAUT_GEN";
                    }
                }
                else if( l_pcode == 3009 )
                {
                    //420|3009|C3 = 0200|DESF_VEND_IATA_GEN
                    nome_transacao = "DESF_VEND_IATA_GEN";
                }
                // Padronizacao Crediario PDV - INICIO
                else if ( l_pcode == 3700 )
                {
                    if( l_origMsg == "0200" )
                    {
                        nome_transacao = "DESF_VEND_CRT_PARC_CJURO";
                    }
                    else if( l_origMsg == "0400" )
                    {
                        nome_transacao = "DESF_EST_VEND_CRT_GEN";
                    }
                }
                // Padronizacao Crediario PDV - FIM
                else if( l_pcode == 3800 )
                {
                    //420|3800|C3 = 0200|DESF_VEND_CRT_PARC_CJURO
                    nome_transacao = "DESF_VEND_CRT_PARC_CJURO";
                }
                else if( l_pcode == 3900 )
                {
                    //420|3900|C2 = true && C3 = 0200|DESF_VEND_IATA_PARC_CJURO
                    nome_transacao = "DESF_VEND_IATA_PARC_CJURO";
                }
                else if( l_pcode == 9000 )
                {
                    //420|9000|C3 = 0200|DESF_VEND_PL
                    //420|9000|C3 = 0400|DESF_EST_VEND_PL
                    if( l_origMsg == "0200" )
                    {
                        nome_transacao = "DESF_VEND_PL";
                    }
                    else if( l_origMsg == "0400" )
                    {
                        nome_transacao = "DESF_EST_VEND_PL";
                    }
                }
                else if( l_pcode == 90000 )
                {
                    //420|90000|C3 = 0200|DESF_VEND_CSAQ
                    nome_transacao = "DESF_VEND_CSAQ";
                }
                else if( l_pcode == 173000 )
                {
                    //420|173000|C3 = 0200|DESF_VEND_VCH_FROT
                    nome_transacao = "DESF_VEND_VCH_FROT";
                }
                else if( l_pcode == 182000 )
                {
                    if( l_origMsg == "0200" )
                    {
                        nome_transacao = "DESF_VEND_VCH_FROT";
                    }
                }
                else if( l_pcode == 183000 )
                {
                    //420|183000|C3 = 0200|DESF_VEND_VCH
                    //420|183000|C3 = 0220|DESF_ADV_VEND_VCH
                    //420|183000|C3 = 9080|DESF_TROCA_SENHA_VCH_CHIP
                    if( l_origMsg == "0200" )
                    {
                        nome_transacao = "DESF_VEND_VCH";
                    }
                    else if( l_origMsg == "0220" )
                    {
                        nome_transacao = "DESF_ADV_VEND_VCH";
                    }
                    else if( l_origMsg == "9080" )
                    {
                        nome_transacao = "DESF_TROCA_SENHA_VCH_CHIP";
                    }                       
                }
                else if( l_pcode == 200000 )
                {
                    //420|200000||DESF_EST_VEND_CSAQ
                    nome_transacao = "DESF_EST_VEND_CSAQ";
                }
                else if( l_pcode == 200020 )
                {
                    //420|200020|C3 = 0400|DESF_EST_VEND_DBT_GEN
                    //420|200020|C4 = 0316|EST_VEND_DBT_CORBAN
                    if( l_transactionId == "0316" )
                    {
                        nome_transacao = "DESF_EST_VEND_DBT_CORBAN";
                    }
                    else
                    {
                        nome_transacao = "DESF_EST_VEND_DBT_GEN";
                    }
                }
                else if( l_pcode == 200030 )
                {
                    //420|200030|C3 = 0400|DESF_EST_VEND_CRT_GEN
                    nome_transacao = "DESF_EST_VEND_CRT_GEN";
                }
                else if( l_pcode == 290020 )
                {
                    //420|290020|C3 = 0400|DESF_EST_VEND_VCH_FROT
                    nome_transacao = "DESF_EST_VEND_VCH_FROT";
                }
                else if( l_pcode == 290030 )
                {
                    //420|290030|C3 = 0400|DESF_EST_VEND_VCH_GEN
                    nome_transacao = "DESF_EST_VEND_VCH_GEN";
                }
            }
            break;
            case 600:
            case 610:
            {
                nome_transacao = "SONDA";
            }
            break;
            case 800:
            {
                if( l_pcode == 910000 )
                {
                    //800    910000    XX    ESTATISTICA
                    nome_transacao = "ESTATISTICA";
                }
                else if ( l_pcode == 990000 )
                {
                    nome_transacao = "TEST_COMUNICACAO";
                }
                else if ( l_pdv_trn_id == "IN" )
                {
                //800    -    C1 = IN    INICIALIZACAO
                    nome_transacao = "INICIALIZACAO";
                }
                else if( l_loadInit == 1 )
                {
                    //800    -    LOCAL.LoadInit DE070 = 01    SIGN_ON
                    nome_transacao = "SIGN_ON";
                }
                else if( l_loadInit == 2 )
                {
                    //800    -    LOCAL.LoadInit DE070 = 02    SIGN_OFF
                    nome_transacao = "SIGN_OFF";
                }
                else if( l_pcode == 940000)
                {
                    //800   940000  XX  INJECAO_CHAVES
                    nome_transacao = "INJECAO_CHAVES";
                }
            }
            break;
            case 9060:
            {
                //9060    -        RES_VEND
                nome_transacao = "RES_VEND";
            }
            break;
            case 9062:
            {
                //9062    -        CONF_RES_VEND
                nome_transacao = "CONF_RES_VEND";
            }
            break;
            case 9080:
            {
                //9080    183000        TROCA_SENHA_VCH_CHIP
                nome_transacao = "TROCA_SENHA_VCH_CHIP";
            }
            break;
            case 9092:
            {
                //9092    183000        CONF_TROCA_SENHA_VCH_CHIP    
                nome_transacao = "CONF_TROCA_SENHA_VCH_CHIP";
            }
            break;
            case 9100:
            {
                //9100            REIMPR_COMPROV    Descontinuada
                nome_transacao = "REIMPR_COMPROV";
            }
            break;
            case 9200:
            {
                //9200  900800  PAG_CON_DIN Descontinuada
                if( l_pcode == 900800 )
                {
                    nome_transacao = "PAG_CON_DIN";
                }
            }
            break;
            case 9202:
            {
                //9202         CONF_PAG_CON Descontinuada
                nome_transacao = "CONF_PAG_CON";
            }
            break;
            case 9300:
            {
                //9300    293000        DESF_VEND_VCH_APROV_SALDO_DISP
                nome_transacao = "DESF_VEND_VCH_APROV_SALDO_DISP";
            }
            break;
            case 9600:
            {
                //9600    -        BAIXA_OS
                nome_transacao = "BAIXA_OS";
            }
            break;            
            default:
                l_log << "Nao foi possivel mapear a transacao msgtype[";
                l_log << l_msgtype;
                l_log << "] - pcode[";
                l_log << l_pcode;
                l_log << "]\n";
                return false;
            break;
        }
        return true;
    }
    
    DefineNomeTrn& DefineNomeTrn::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    DefineNomeTrn& DefineNomeTrn::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    DefineNomeTrn& DefineNomeTrn::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* DefineNomeTrn::clone( ) const
    {
        return( new DefineNomeTrn( *this ) );
    }

}//namespace plugins_pdv

