#pragma once

#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>
#include <algorithm>

#include "base/GenException.hpp"
#include "configBase/ConfigBase.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "defines.hpp"
#include "TBSW0030.hpp"
#include "AcqUtils.hpp"
#include "plugins_pdv/TBSW0030Inserter.hpp"
#include "dbaccess_pdv/TBSW0030RegrasFormatacao.hpp"

// Release Bandeiras PDV - Abril 2019
using namespace std;

namespace plugins_pdv
{
    base::Identificable* createTBSW0030Inserter( )
    {
        TBSW0030Inserter* l_new = new TBSW0030Inserter;
        return( l_new );
    }

    TBSW0030Inserter::TBSW0030Inserter( )
    {
    }

    TBSW0030Inserter::~TBSW0030Inserter( )
    {
    }

    bool TBSW0030Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

        return( true );
    }

    bool TBSW0030Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_pcode = this->navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_transcode = this->navigate( m_sourceFieldPath + ".segments.common.transcode" );
        m_termloc = this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );
        m_termid = this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
        m_status = this->navigate( m_sourceFieldPath + ".segments.common.status" );
        m_pos_entry_code = this->navigate( m_sourceFieldPath + ".shc_msg.pos_entry_code" );
        m_cd_ems = this->navigate( m_sourceFieldPath + ".segments.common.cd_ems" );
        m_amount = this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
        m_mer_cat_code = this->navigate( m_sourceFieldPath + ".segments.merchant.mer_cat_code" );
        m_orig_pan = this->navigate( m_sourceFieldPath + ".segments.common.orig_pan" );
        m_expiry_date = this->navigate( m_sourceFieldPath + ".shc_data.expiry_date" );
        m_bin = this->navigate( m_sourceFieldPath + ".segments.common.bin" );
        m_cod_bndr = this->navigate( m_sourceFieldPath + ".segments.common.cod_bndr" );
        m_is_reversal = this->navigate( m_sourceFieldPath + ".segments.common.is_reversal" );
        m_is_void = this->navigate( m_sourceFieldPath + ".segments.common.is_void" );
        m_local_time = this->navigate( m_sourceFieldPath + ".shc_msg.local_time" );
        m_trace = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
        m_in_tpo_tcn = this->navigate( m_sourceFieldPath + ".segments.merchant.in_tpo_tcn" );
        m_cd_tpo_trm = this->navigate( m_sourceFieldPath + ".segments.merchant.cd_tpo_trm" );
        m_track2 = this->navigate( m_sourceFieldPath + ".shc_msg.track2" );
        m_cvv2 = this->navigate( m_sourceFieldPath + ".shc_msg.cvv2" );
        m_cod_mtv_sw = this->navigate( m_sourceFieldPath + ".segments.common.cod_mtv_sw" );
        m_orig_transcode = this->navigate( m_sourceFieldPath + ".segments.common.orig_transcode" );
        m_subtranscode = this->navigate( m_sourceFieldPath + ".segments.common.subtranscode" );
        m_track3 = this->navigate( m_sourceFieldPath + ".shc_msg.track3" );
        m_is_van = this->navigate( m_localFieldPath + ".isVAN" );
        m_acceptorname = this->navigate( m_sourceFieldPath + ".shc_msg.acceptorname" );
        m_tip_dtlh_tran = this->navigate( m_sourceFieldPath + ".segments.credit.in_dbt_cre_ete" );
        //m_is_cod_serv_trk_car = this->navigate( m_localFieldPath + ".IS_COD_SERV_TRK_CAR" );
        m_dat_rsmo_vd = this->navigate( m_sourceFieldPath + ".segments.common.dt_rv" );
        m_cod_item = this->navigate( m_sourceFieldPath + ".segments.private_label.cod_item" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_issuer = this->navigate( m_sourceFieldPath + ".shc_msg.issuer" );
        m_ind_tran_refd = this->navigate( m_localFieldPath + ".IND_TRAN_REFD" );
        m_pb_reason_code = this->navigate( m_sourceFieldPath + ".segments.common.pb_reason_code" );
        m_receive_inst_id = this->navigate( m_sourceFieldPath + ".shc_msg.receive_inst_id" );
        m_codTranCad = this->navigate( m_sourceFieldPath + ".segments.acq_common.COD_TRAN_CAD" );
        m_local_cod_sgl_pai = this->navigate( m_localFieldPath + ".countryDiners" );
        m_merchant_type = this->navigate( m_sourceFieldPath + ".shc_msg.merchant_type" );
        m_cd_ctg_trx = this->navigate( m_sourceFieldPath + ".segments.common.cd_ctg_trx" );
        m_cod_cndc_cptr = this->navigate( m_sourceFieldPath + ".segments.common.cod_cndc_cptr" );
        m_l_cod_serv = this->navigate( m_localFieldPath + ".L_COD_SERV" );
        m_value_cod_serv_trk_car = this->navigate( m_localFieldPath + ".VALUE_COD_SERV_TRK_CAR" );
        m_chip_full_data_len = this->navigate( m_sourceFieldPath + ".segments.chip.chip_full_data_len" );
        m_l_cod_trk_car = this->navigate( m_localFieldPath + ".L_COD_TRK_CAR" );
        m_l_ind_trk = this->navigate( m_localFieldPath + ".L_IND_TRK" );
        m_ind_term_ltro_chip = this->navigate( m_localFieldPath + ".IND_TERM_LTRO_CHIP" );
        m_local_num_car = this->navigate( m_localFieldPath + ".L_NUM_CAR" );
        m_cod_mot_aut_pauz = this->navigate( m_localFieldPath + ".cod_mot_aut_pauz" );
        m_cod_cndc_cptr_pauz = this->navigate( m_localFieldPath + ".cod_cndc_cptr_pauz" );
        m_tip_ent_pauz = this->navigate( m_localFieldPath + ".tip_ent_pauz" );
        m_dat_pauz = this->navigate( m_localFieldPath + ".dat_pauz" );
        m_iss_name = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
        m_msg_category = this->navigate( m_sourceFieldPath + ".segments.common.msg_category" );
        m_acq_name = this->navigate( m_sourceFieldPath + ".segments.common.acq_name" );
        m_msg_name = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        m_is_pre_auth = this->navigate( m_sourceFieldPath + ".segments.common.is_pre_auth" );
        m_origtrace = this->navigate( m_sourceFieldPath + ".shc_msg.origtrace" );
        m_plano_pagamento = this->navigate( m_sourceFieldPath + ".segments.private_label.plano_pagamento" );
        m_has_pin = this->navigate( m_sourceFieldPath + ".segments.common.has_pin" );
        m_trandate = this->navigate( m_sourceFieldPath + ".shc_msg.trandate" );
        m_trantime = this->navigate( m_sourceFieldPath + ".shc_msg.trantime" );
        m_trn_tem_original = this->navigate( m_localFieldPath + ".trn_tem_original" );
        m_ind_pagt_fatura = this->navigate( m_sourceFieldPath + ".segments.debt.idPagFatura" );
        m_ecr_sftw_verid = this->navigate( m_sourceFieldPath + ".segments.common.ecr_sftw_verid" );
        m_mer_name = this->navigate( m_sourceFieldPath + ".segments.merchant.mer_name" );
        m_mer_city = this->navigate( m_sourceFieldPath + ".segments.merchant.mer_city" );
        m_form_factor = this->navigate( m_sourceFieldPath + ".segments.chip.form_factor" );
        m_cod_service = this->navigate( m_sourceFieldPath + ".segments.service.cod_service" );
        m_is_nfc = this->navigate( m_sourceFieldPath + ".segments.common.is_nfc" );
        m_common_vl_txa = this->navigate( m_sourceFieldPath + ".segments.common.vl_txa" );
        m_cod_mot_rsps_ext = this->navigate( m_targetFieldPath + ".COD_MOT_RSPS_EXT" );
        m_is_desfaz_estorno = this->navigate( m_sourceFieldPath + ".segments.common.is_desfaz_estorno" );
        m_orig_ind_da_rlcd_chip = this->navigate( m_localFieldPath + ".orig_ind_da_rlcd_chip" );
        m_ind_da_rlcd_iata = this->navigate( m_localFieldPath + ".ind_da_rlcd_iata" );
        m_cod_gru_clas_ram = this->navigate( m_localFieldPath + ".cod_gru_clas_ram" );
        tokenIdentifier = this->navigate( m_sourceFieldPath + ".segments.common.tokenIdentifier" );
        codigoOrigemRespostaAutorizacao = this->navigate( m_sourceFieldPath + ".segments.common.codigoOrigemRespostaAutorizacao" );
        m_cod_prod_cdst = this->navigate( m_sourceFieldPath + ".segments.acq_common.COD_TRAN_CAD" );
       
        // Release Bandeiras PDV - Abril 2019 - INICIO
        indicadorModoEntrada = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorModoEntrada") );
        indicadorPresencaPortador = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorPresencaPortador") );
        indicadorTecnologiaTerminal = this->navigate( string(m_sourceFieldPath).append(".segments.common.indicadorTecnologiaTerminal") );
        // Release Bandeiras PDV - Abril 2019 - FIM

        // BRUM - EAK-1657 - 27/08/2019 - MCC Dinamico - Inicio
        merchantCategoryCodeSubLojista = this->navigate( string(m_sourceFieldPath).append(".segments.sublojista.merchantCategoryCode") );
        // BRUM - EAK-1657 - Fim

        indicadorTrilha3Len = this->navigate( m_sourceFieldPath + ".segments.common.track3Len" );
        
        codigoRoteamentoTransacao = this->navigate( m_sourceFieldPath + ".shc_msg.netcode" );

        return( true );
    }

    void TBSW0030Inserter::finish( )
    {
    }

    int TBSW0030Inserter::execute( bool& a_stop )
    {
        int l_lastLine = __LINE__;
        
        try
        {
            dbaccess_common::TBSW0030 tbsw0030;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Inserting in TBSW0030 =========" );
            dbaccess_pdv::TBSW0030RegrasFormatacao regrasFmt;
            acq_common::tbsw0030_params st_tbsw0030 = { 0 };
            string indTermLtroChip;

            fieldSet::fsextr( st_tbsw0030.local_date, m_local_date );
            fieldSet::fsextr( st_tbsw0030.refnum, m_refnum );
            fieldSet::fsextr( st_tbsw0030.origrefnum, m_origrefnum );
            fieldSet::fsextr( st_tbsw0030.local_time, m_local_time );
            fieldSet::fsextr( st_tbsw0030.msgtype, m_msgtype );
            fieldSet::fsextr( st_tbsw0030.pcode, m_pcode );
            fieldSet::fsextr( st_tbsw0030.transcode, m_transcode );
            fieldSet::fsextr( st_tbsw0030.tip_dtlh_tran, m_tip_dtlh_tran );
            fieldSet::fsextr( st_tbsw0030.cd_ctg_trx, m_cd_ctg_trx );
            fieldSet::fsextr( st_tbsw0030.subtranscode, m_subtranscode );
            fieldSet::fsextr( st_tbsw0030.termloc, m_termloc );
            fieldSet::fsextr( st_tbsw0030.termid, m_termid );
            fieldSet::fsextr( st_tbsw0030.trace, m_trace );
            fieldSet::fsextr( st_tbsw0030.cd_tpo_trm, m_cd_tpo_trm );
            fieldSet::fsextr( st_tbsw0030.mer_cat_code, m_mer_cat_code );
            fieldSet::fsextr( st_tbsw0030.pos_entry_code, m_pos_entry_code );
            fieldSet::fsextr( st_tbsw0030.cod_bndr, m_cod_bndr );
            fieldSet::fsextr( st_tbsw0030.bin, m_bin );
            fieldSet::fsextr( st_tbsw0030.num_car, m_local_num_car );
            fieldSet::fsextr( st_tbsw0030.orig_pan, m_orig_pan );
            fieldSet::fsextr( st_tbsw0030.countryDiners, m_local_cod_sgl_pai );
            fieldSet::fsextr( st_tbsw0030.expiry_date, m_expiry_date );
            fieldSet::fsextr( st_tbsw0030.cod_trk_car, m_l_cod_trk_car );
            fieldSet::fsextr( st_tbsw0030.ind_trk, m_l_ind_trk );
            fieldSet::fsextr( st_tbsw0030.orig_transcode, m_orig_transcode );
            fieldSet::fsextr( st_tbsw0030.track2, m_track2 );
            fieldSet::fsextr( st_tbsw0030.track3, m_track3 );
            fieldSet::fsextr( st_tbsw0030.isVan, m_is_van );
            fieldSet::fsextr( st_tbsw0030.cvv2, m_cvv2 );
            fieldSet::fsextr( st_tbsw0030.local_cod_serv, m_l_cod_serv );
            fieldSet::fsextr( st_tbsw0030.status, m_status );
            fieldSet::fsextr( st_tbsw0030.amount, m_amount );
            fieldSet::fsextr( st_tbsw0030.cod_mot_aut_pauz, m_cod_mot_aut_pauz );
            fieldSet::fsextr( st_tbsw0030.pb_reason_code, m_pb_reason_code );
            fieldSet::fsextr( st_tbsw0030.acceptorname, m_acceptorname );
            fieldSet::fsextr( indTermLtroChip, m_ind_term_ltro_chip );
            std::transform(indTermLtroChip.begin(), indTermLtroChip.end(),indTermLtroChip.begin(), ::toupper);
            st_tbsw0030.ind_term_ltro_chip = indTermLtroChip;
            fieldSet::fsextr( st_tbsw0030.isReversal, m_is_reversal );
            fieldSet::fsextr( st_tbsw0030.isVoid, m_is_void );
            fieldSet::fsextr( st_tbsw0030.chip_full_data_len, m_chip_full_data_len );
            fieldSet::fsextr( st_tbsw0030.local_ind_tran_refd, m_ind_tran_refd );
            fieldSet::fsextr( st_tbsw0030.cod_cndc_cptr_pauz, m_cod_cndc_cptr_pauz );
            fieldSet::fsextr( st_tbsw0030.tip_ent_pauz, m_tip_ent_pauz );
            //fieldSet::fsextr( st_tbsw0030.is_cod_serv_trk_car, m_is_cod_serv_trk_car );
            fieldSet::fsextr( st_tbsw0030.value_cod_serv_trk_car, m_value_cod_serv_trk_car );
            fieldSet::fsextr( st_tbsw0030.date_pauz, m_dat_pauz );
            fieldSet::fsextr( st_tbsw0030.cod_tran_cad, m_codTranCad );
            fieldSet::fsextr( st_tbsw0030.receive_inst_id, m_receive_inst_id );
            fieldSet::fsextr( st_tbsw0030.issuer, m_issuer );
            fieldSet::fsextr( st_tbsw0030.merchant_type, m_merchant_type );
            fieldSet::fsextr( st_tbsw0030.dt_rv, m_dat_rsmo_vd );
            fieldSet::fsextr( st_tbsw0030.cd_ems, m_cd_ems );
            fieldSet::fsextr( st_tbsw0030.iss_name, m_iss_name );
            fieldSet::fsextr( st_tbsw0030.msg_category, m_msg_category );
            fieldSet::fsextr( st_tbsw0030.acq_name, m_acq_name );
            fieldSet::fsextr( st_tbsw0030.origtrace, m_origtrace);
            fieldSet::fsextr( st_tbsw0030.msg_name, m_msg_name );
            fieldSet::fsextr( st_tbsw0030.in_tpo_tcn, m_in_tpo_tcn );
            fieldSet::fsextr( st_tbsw0030.is_pre_auth, m_is_pre_auth );
            fieldSet::fsextr( st_tbsw0030.pl_cod_item, m_cod_item );
            fieldSet::fsextr( st_tbsw0030.cod_mtv_sw, m_cod_mtv_sw );
            fieldSet::fsextr( st_tbsw0030.has_pin, m_has_pin );
            fieldSet::fsextr( st_tbsw0030.plano_pagamento, m_plano_pagamento );
            fieldSet::fsextr( st_tbsw0030.trandate, m_trandate );
            fieldSet::fsextr( st_tbsw0030.trantime, m_trantime );
            fieldSet::fsextr( st_tbsw0030.cod_cndc_cptr, m_cod_cndc_cptr );
            fieldSet::fsextr( st_tbsw0030.trn_tem_original, m_trn_tem_original );
            fieldSet::fsextr( st_tbsw0030.ind_pagt_fatura, m_ind_pagt_fatura );
            fieldSet::fsextr( st_tbsw0030.ecr_sftw_verid, m_ecr_sftw_verid );
            fieldSet::fsextr( st_tbsw0030.merchant_mer_name, m_mer_name );
            fieldSet::fsextr( st_tbsw0030.merchant_mer_city, m_mer_city );
            fieldSet::fsextr( st_tbsw0030.form_factor, m_form_factor );
            fieldSet::fsextr( st_tbsw0030.cod_serv_corp, m_cod_service );
            fieldSet::fsextr( st_tbsw0030.is_nfc, m_is_nfc );
            fieldSet::fsextr( st_tbsw0030.common_vl_txa, m_common_vl_txa );
            fieldSet::fsextr( st_tbsw0030.cod_mot_rsps_ext, m_cod_mot_rsps_ext );
            fieldSet::fsextr( st_tbsw0030.is_desfaz_estorno, m_is_desfaz_estorno );
            fieldSet::fsextr( st_tbsw0030.orig_ind_da_rlcd_chip, m_orig_ind_da_rlcd_chip );
            fieldSet::fsextr( st_tbsw0030.ind_da_rlcd_iata, m_ind_da_rlcd_iata );
            fieldSet::fsextr( st_tbsw0030.cod_gru_clas_ram, m_cod_gru_clas_ram );
            fieldSet::fsextr( st_tbsw0030.tokenIdentifier, tokenIdentifier );
            fieldSet::fsextr( st_tbsw0030.codigoOrigemRespostaAutorizacao, codigoOrigemRespostaAutorizacao );
            fieldSet::fsextr( st_tbsw0030.cod_prod_cdst, m_cod_prod_cdst );

            if ( configBase::ConfigBase::getInstance( )->findFirst( "NUM_REDE_ORIGEM", st_tbsw0030.netcodex ) == false )
            {
                st_tbsw0030.netcodex = "2";
            }
            
            // Release Bandeiras PDV - Abril 2019 - INICIO
            string localIndicadorModoEntrada = "";
            fieldSet::fsextr( localIndicadorModoEntrada, indicadorModoEntrada );
            fieldSet::fsextr( st_tbsw0030.indicadorPresencaPortador, indicadorPresencaPortador );
            fieldSet::fsextr( st_tbsw0030.indicadorTecnologiaTerminal, indicadorTecnologiaTerminal );

            if ( ( ( st_tbsw0030.iss_name.compare("ELO_CRT_FULL") == 0 ) 
                    || ( st_tbsw0030.iss_name.compare("ELO_DBT_FULL") == 0 ) )
                && (localIndicadorModoEntrada.compare("1") == 0) )
            {
                st_tbsw0030.pos_entry_code = 861;
            }
            // Release Bandeiras PDV - Abril 2019 - FIM

            // BRUM - EAK-1657 - 27/08/2019 - MCC Dinamico - Inicio
            fieldSet::fsextr( st_tbsw0030.merchantCategoryCodeSubLojista, merchantCategoryCodeSubLojista );
            // BRUM - EAK-1657 - Fim
            
            fieldSet::fsextr( st_tbsw0030.indicadorTrilha3Len, indicadorTrilha3Len );
            fieldSet::fsextr( st_tbsw0030.codigoRoteamentoTransacao, codigoRoteamentoTransacao );

            //CAMPOS NOT NULL
            regrasFmt.DAT_MOV_TRAN      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC       ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.TIP_TRAN          ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_MOT_RSPS      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.TIP_TCNL          ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_ESTB          ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_TERM          ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.TIP_TERM          ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_RD_ORG        ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_RAM_ATVD      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_CTGR_TRAN     ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_CNDC_CPTR     ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.DAT_CTB_TRAN      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_TRAN_REFD     ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_TRK           ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_MOT_SW        ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_CPTR_CVC_2    ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_TERM_RLCD_CHIP( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NOM_LOC_ESTB      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_MSG_ISO       ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_PCM_ISO       ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_DFZM          ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_ESTR          ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_CPTRDO        ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_AGND_TRAN     ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_IMPR_CPOM     ( tbsw0030, st_tbsw0030, acq_common::INSERT ); // DUVIDA REDE
            regrasFmt.DTH_INI_TRAN      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.DTH_STTU_TRAN     ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_STAN          ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_EMSR_MTC      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_DA_RLCD_CHIP  ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.TIP_DTLH_TRAN     ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_DA_RLCD_IATA  ( tbsw0030, st_tbsw0030, acq_common::INSERT ); // DUVIDA REDE
            regrasFmt.IND_STTU_TRAN     ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NOM_SITE_ACQR_ORGL( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NOM_HOST_ACQR_ORGL( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NOM_FE_ACQR_ORGL  ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_GRU_CLAS_RAM  ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_TRAN_TKN      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_ORG_APRV      ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_PROD_CDST     ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            // Release Bandeiras PDV - Abril 2019 - INICIO
            regrasFmt.IndicadorPresencaPortador( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IndicadorTecnologiaTerminal( tbsw0030, st_tbsw0030, acq_common::INSERT );
            // Release Bandeiras PDV - Abril 2019 - FIM
            
            //CAMPO NULL
            regrasFmt.COD_POS_ENTR_MODO( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_EMSR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.TIP_VD( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.VAL_TRAN( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_CAR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_MOT_RSPS_EXT( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.VAL_TX( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.DAT_VLD_CAR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_TRK_CAR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_MOED( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_CV( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_ID_CAR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_ID_PREV( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_PROD( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_CTR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_EMSR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_BNDR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_REF_RESTANTE( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_SERV( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_SERV_SNHA( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.VAL_TX_RISC( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.TIP_TRAN_ORGL( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.TIP_PLN_PGMN( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_CMPM_TRAN( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.PRCN_TX_RISC( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_CNDC_CPTR_PAUZ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.TIP_ENT_PAUZ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_OPER_CNFR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.DTH_GMT( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_MOT_AUT( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.VAL_TOTL_TRAN( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_RSTD_NUM_CVC_2( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_SERV_TRK_CAR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_VLDC_EMSR( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_AUT( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_DA_RLCD_KMRC( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.IND_TRAN_SEM_ORGL( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.DAT_PAUZ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC_PAUZ( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_TRAN_CAD( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_NTWK_ID_ACQR_ORGL( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_NTWK_ID_ROUT_ORGL( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_NTWK_ID_ISSR_ORGL( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_RAM_MCC( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_DSPO_NFC( tbsw0030, st_tbsw0030, acq_common::INSERT );
            regrasFmt.COD_SERV_CORP( tbsw0030, st_tbsw0030, acq_common::INSERT );

            tbsw0030.set_COD_EMP_ADQT( 0 ); // campo novo

            regrasFmt.CodigoRoteamentoTransacao( tbsw0030, st_tbsw0030, acq_common::INSERT );
            
            tbsw0030.insert( );
            tbsw0030.commit( );
            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch( base::GenException e )
        {
            char l_line[10];
            fieldSet::fscopy( m_result, "ERROR", 5 );
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            std::string l_msg = "Exception in TBSW0030 <" + std::string( e.what() ) +
                                "> at <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            char l_line[10];
            fieldSet::fscopy( m_result, "ERROR", 5 );
            memset( l_line, 0, sizeof( l_line ) );
            snprintf( l_line, sizeof( l_line ), "%d", l_lastLine );
            std::string l_msg = "Exception in TBSW0030 <" + std::string( e.what() ) +
                                "> at <" + std::string( l_line ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }
    TBSW0030Inserter& TBSW0030Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    TBSW0030Inserter& TBSW0030Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    TBSW0030Inserter& TBSW0030Inserter::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0030Inserter::clone( ) const
    {
        return( new TBSW0030Inserter( *this ) );
    }

}//namespace plugins_pdv

