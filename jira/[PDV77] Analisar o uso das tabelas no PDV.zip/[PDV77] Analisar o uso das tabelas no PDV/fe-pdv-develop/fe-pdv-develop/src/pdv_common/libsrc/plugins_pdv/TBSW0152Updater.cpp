#pragma once
#include <sstream>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "TBSW0152.hpp"
#include "plugins_pdv/TBSW0152Updater.hpp"
#include "dbaccess_pdv/TBSW0152RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0152Updater( )
    {
        TBSW0152Updater* l_new = new TBSW0152Updater;
        return( l_new );
    }

    bool TBSW0152Updater::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );

        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );

        this->setSourceFieldPath( l_sourcePath );
        this->setTargetFieldPath( l_targetPath );

        return( true );
    }

    TBSW0152Updater::TBSW0152Updater( )
    {
    }

    TBSW0152Updater::~TBSW0152Updater( )
    {
    }

    bool TBSW0152Updater::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_orig_local_date = this->navigate( m_sourceFieldPath + ".segments.common.orig_local_date" );
        m_install_amt = this->navigate( m_sourceFieldPath + ".segments.credit.install_amt" );
        m_applied_fee = this->navigate( m_sourceFieldPath + ".segments.credit.applied_fee" );
        m_fee = this->navigate( m_sourceFieldPath + ".segments.credit.fee" );
        m_status = this->navigate( m_sourceFieldPath + ".segments.common.status" );
        m_msg_name = this->navigate( m_sourceFieldPath + ".segments.common.msg_name" );
        m_iss_name = this->navigate( m_sourceFieldPath + ".segments.common.iss_name" );
		m_amount = this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
		m_install_num = this->navigate( m_sourceFieldPath + ".segments.common.install_num" );
		
        return( true );
    }

    void TBSW0152Updater::finish( )
    {
    }

    int TBSW0152Updater::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_msgtype;
            unsigned long l_local_date;
            unsigned long l_orig_local_date;
            unsigned long l_refnum;
            unsigned long l_origrefnum;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );
            fieldSet::fsextr( l_msgtype, m_msgtype );
            fieldSet::fsextr( l_origrefnum, m_origrefnum );
            fieldSet::fsextr( l_orig_local_date, m_orig_local_date );

            switch ( l_msgtype )
            {
                case 110 :
                case 210 :
                case 230 :

                    l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
                    break;
                case 410 :
                case 430 :

                    l_whereClause << "DAT_MOV_TRAN = " << l_orig_local_date << " AND NUM_SEQ_UNC = " << l_origrefnum;
                    break;
                default:

                    logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " EMPTY QUERY" );
                    fieldSet::fscopy( m_result, "ERROR", 5 );
                    a_stop = false;
                    return( 0 );
                    break;
            }

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0152 ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );

            dbaccess_common::TBSW0152 tbsw0152( l_whereClause.str( ) );
            struct acq_common::tbsw0152_params params = { 0 };
            dbaccess_pdv::TBSW0152RegrasFormatacao regrasFmt;

            tbsw0152.prepare_for_update( );
            tbsw0152.execute( );
            int ret = tbsw0152.fetch( );
            if ( !ret )
            {
                logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " NOT UPDATED" );
                fieldSet::fscopy( m_result, "ERROR", 5 );
            }
            else
            {
                tbsw0152.let_as_is( );

                fieldSet::fsextr( params.install_amt,   m_install_amt );
                fieldSet::fsextr( params.applied_fee,   m_applied_fee );
                fieldSet::fsextr( params.fee,           m_fee );
                fieldSet::fsextr( params.status,        m_status );
                fieldSet::fsextr( params.msg_name,      m_msg_name );
                fieldSet::fsextr( params.iss_name,      m_iss_name );
				fieldSet::fsextr( params.amount,        m_amount );
				fieldSet::fsextr( params.install_num,   m_install_num );
				
                regrasFmt.VAL_PRCL      ( tbsw0152, params, acq_common::UPDATE );
                regrasFmt.VAL_TX_EFTV   ( tbsw0152, params, acq_common::UPDATE );
                regrasFmt.VAL_TX_MNSL   ( tbsw0152, params, acq_common::UPDATE );

                // tbsw0152.show( 0 );
                tbsw0152.update( );
                tbsw0152.commit( );

                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch ( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0152 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch ( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0152 <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return( 0 );
    }

    TBSW0152Updater& TBSW0152Updater::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }
    TBSW0152Updater& TBSW0152Updater::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* TBSW0152Updater::clone( ) const
    {
        return( new TBSW0152Updater( *this ) );
    }
}//namespace plugins_pdv
