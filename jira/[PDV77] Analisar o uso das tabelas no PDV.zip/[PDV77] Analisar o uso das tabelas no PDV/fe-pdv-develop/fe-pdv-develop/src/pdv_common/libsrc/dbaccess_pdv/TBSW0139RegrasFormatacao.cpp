#include <dbaccess_pdv/TBSW0139RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    TBSW0139RegrasFormatacao::TBSW0139RegrasFormatacao( )
    {
    }

    TBSW0139RegrasFormatacao::~TBSW0139RegrasFormatacao( )
    {
    }

    void TBSW0139RegrasFormatacao::insert_NUM_VERS_SRVD_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
    {
        if( params.termid_type != "HY8583" )
        {
            if ( params.ecr_sftw_verid.size( ) > 0 )
            {
                tbsw0139.set_NUM_VERS_SRVD_PDV( params.ecr_sftw_verid.substr( 0, 5 ) );
            }
        }
    }
	
    void TBSW0139RegrasFormatacao::insert_NUM_PDV( dbaccess_common::TBSW0139 &tbsw0139, const struct acq_common::tbsw0139_params &params )
    {
		if ( params.termloc > 0 )
		{
			//Aqui, o campo termloc foi definido como long e 
			//seu conteudo, no PDV, � o conteudo da posicao
			//6 ao 15 do campo original IMF.
			tbsw0139.set_NUM_PDV( params.termloc );
		}
    }	
}
