/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/------------------------------------------------------------------------------
/Sigla: SW - FE-PDV
/Descri��o:
/Conte�do:
/Autor: t689066, Alexandre Teodoro Guimaraes
/Data de Cria��o: 2013, 07 de fevereiro
/Hist�rico Mudan�as: 2013, 07 de fevereiro, t689066, Alexandre Teodoro Guimaraes
                                                               , Versao Inicial
/------------------------------------------------------------------------------
*/
#pragma once

#include <ist_ipc.h>
#include <ist_cfg.h>
#include <tsk.h>
#include <tm.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fsextr.hpp"
#include "fieldSet/fscopy.hpp"
#include "plugins_pdv/ProtomServer.hpp"
#include "configBase/ConfigBase.hpp"
#include <unistd.h>
#include <algorithm>

//todo: debug - remover iostream e os std::cout apos finalizar testes
//#define ENABLESTDCOUT
#ifdef ENABLESTDCOUT
#include <iostream>
#endif

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createProtomServer()
    {
        ProtomServer* l_new = new ProtomServer;
        return l_new;
    }
    ProtomServer::ProtomServer()
    {     
#ifdef ENABLESTDCOUT            
            std::cout << __FUNCTION__ << std::endl;
#endif          
    
        m_ecrshmHdr = NULL; 
		m_ecrsemId = -1;
        m_ecrsemsrvId = -1;
		m_ecrshmId = -1; 
        m_ecrprotHdr = (struct _ecrprothdr *)&m_ecrmsg.ecrprothdr_buf;
        m_ecrprotHdr2 = (struct _ecrprothdr2 *)&m_ecrmsg.ecrprothdr_buf;
        m_isProtomMsg = true;        
        memset( (char *) &m_portTbl, 0, sizeof( m_portTbl ) );
    }
    ProtomServer::~ProtomServer()
    {
#ifdef ENABLESTDCOUT            
            std::cout << __FUNCTION__ << std::endl;
#endif              
        if( m_ecrshmHdr )
        {
            sh_detach( reinterpret_cast<char *>(m_ecrshmHdr) );
            m_ecrshmHdr = NULL;
        }
    }
    bool ProtomServer::startConfiguration( const configBase::Tag* a_tag )
    {
#ifdef ENABLESTDCOUT            
            std::cout << __FUNCTION__ << std::endl;
#endif              
        char * l_headerSize = getenv ( "MSG_HEADER_SIZE" );
        m_isProtomMsg = ( ( l_headerSize != NULL ) && 
                          ( strcmp( l_headerSize, "20" ) == 0 ) );     
        if( !m_isProtomMsg )
        {
            return true;
        }
        configBase::TagList l_tagList;
        a_tag->findTag( "args", l_tagList );
        std::string l_argsPath = l_tagList.front().findProperty( "value" ).value();
        this->setArgsFieldPath( l_argsPath );
        if ( a_tag->findTagNotRequired( "sourceFieldPath", l_tagList ) )
        {
            std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
            this->setSourceFieldPath( l_sourcePath );
        }
        else
        {
            this->setSourceFieldPath( "" );
        }
        if ( a_tag->findTagNotRequired( "targetFieldPath", l_tagList ) )
        {
            std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );        
            this->setTargetFieldPath( l_targetPath );
        }
        else
        {
            this->setTargetFieldPath( "" );
        }
        return true;
    }    
    bool ProtomServer::init()
    {
#ifdef ENABLESTDCOUT            
            std::cout << __FUNCTION__ << std::endl;
#endif          
        if( !m_isProtomMsg )
        {
            return true;
        }
        char l_evdata[6] = "*CHK*";
        char l_aux[100];
        int l_created = -1;
        int l_currTskSfx = 0;
        std::string l_errorMsg( NOERROR );
        if( m_sourceFieldPath.compare("") ) 
        {
            m_sourceField = this->navigate( m_sourceFieldPath );
            if ( !m_sourceField )
            {
                l_errorMsg.assign( "Invalid sourceField path <" + m_sourceFieldPath + ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
        }
        if( m_targetFieldPath.compare("") ) 
        {
            m_targetField = this->navigate( m_targetFieldPath );
            if ( !m_targetField )
            {
                l_errorMsg.assign( "Invalid targetField path <" + m_targetFieldPath + ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
        }
        fieldSet::FieldAccess l_operation = this->navigate( m_argsFieldPath + ".Operation" );
		if( !l_operation )
		{
			l_errorMsg.assign( "Invalid field path <" + 
                                    m_argsFieldPath +
                                    ".Operation>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}         
        fieldSet::FieldAccess l_routerInstance = this->navigate( m_argsFieldPath + ".RouterInstance" );
		if( !l_routerInstance )
		{
			l_errorMsg.assign( "Invalid field path <" + 
                                    m_argsFieldPath +
                                    ".RouterInstance>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}                         
        m_netcodexField = this->navigate( m_argsFieldPath + ".Netcodex" );
		if( !m_netcodexField )
		{
			l_errorMsg.assign( "Invalid field path <" + 
                                    m_argsFieldPath +
                                    ".Netcodex>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}               
        fieldSet::FieldAccess l_protomMbName = this->navigate( m_argsFieldPath + ".ProtomMbName" );
		if( !l_protomMbName )
		{
			l_errorMsg.assign( "Invalid field path <" + 
                                    m_argsFieldPath +
                                    ".ProtomMbName>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}                   
        fieldSet::FieldAccess l_activeTableFilepath = this->navigate( m_argsFieldPath + ".ActiveTableFilepath" );
		if( !l_activeTableFilepath )
		{
			l_errorMsg.assign( "Invalid field path <" + 
                                    m_argsFieldPath +
                                    ".ActiveTableFilepath>" );
			this->enableError( true );
			this->setErrorMessage( l_errorMsg ); 
			return false;
		}                           
        fieldSet::fsextr( m_operation, l_operation );
        fieldSet::fsextr( m_routerInstance, l_routerInstance );        
        fieldSet::fsextr( m_protomMbName, l_protomMbName );
        fieldSet::fsextr( m_activeTableFilepath, l_activeTableFilepath );
        std::transform( m_operation.begin(), m_operation.end(), m_operation.begin(), tolower);
        if ( ( m_ecrsemsrvId = sem_create( ECRPROTSRV_SEM_SRV, 1 ) ) == -1 )
        {
            if ( ( m_ecrsemsrvId = sem_connect( ECRPROTSRV_SEM_SRV, 1 ) ) == -1 )
            {
                l_errorMsg.assign( std::string( __FUNCTION__ ) +
                                        ": Erro ao criar/conectar semaforo <" +
                                        std::string( ECRPROTSRV_SEM_SRV ) +
                                        ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
        }                
        if ( gainResource( m_ecrsemsrvId, 1, 0 ) == -1 )
        {
            l_errorMsg.assign( std::string( __FUNCTION__ ) +
                                        ": Error trying to gain resouce - semaphore <" +
                                        ECRPROTSRV_SEM_SRV +
                                        ">" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;       
        }
      	cf_open( "istparam.cfg" );
        if ( ( l_errorMsg.assign( determinePorts() ) ).compare( NOERROR ) != 0 )
        {
            sem_release( m_ecrsemsrvId );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
#ifdef ENABLESTDCOUT            
            std::cout << "l_errorMsg: " <<l_errorMsg << "-line " << __LINE__ << std::endl;
#endif            

        if ( ( m_ecrsemId = sem_create( ECRPROTSRV_SEM, 1 ) ) == -1 )
        {
            if ( ( m_ecrsemId = sem_connect( ECRPROTSRV_SEM, 1 ) ) == -1 )
            {
                l_errorMsg.assign( std::string( __FUNCTION__ ) +
                                   ": Erro ao criar/conectar semaforo <" +
                                   std::string( ECRPROTSRV_SEM ) +
                                   ">" );
                this->enableError( true );
                this->setErrorMessage( l_errorMsg );
                return false;
            }
        }   
        m_ecrShmTotalSize = sizeof( struct _ecrshm_hdr ) +
                           ( ECR_MAX_CONN * sizeof( struct _ecrshm ) );
         
        if ( ( m_ecrshmId = sh_getmem( ECRPROTSRV_SHM, 0, 0 ) ) == -1 )
        {
            l_created = 1;
#ifdef ENABLESTDCOUT            
            std::cout << __LINE__ << "-shm criada" << std::endl;
#endif   
            if ( ( m_ecrshmId = sh_getmem( ECRPROTSRV_SHM, m_ecrShmTotalSize, 1 ) ) == -1 )
            {
#ifdef ENABLESTDCOUT            
            std::cout << __LINE__ << "=shm alocada"<< std::endl;
#endif   
            
                if ( ( m_ecrshmId = sh_getmem( ECRPROTSRV_SHM, 0, 0) ) == -1 )
                {
                    sem_release( m_ecrsemsrvId );
                    std::string l_errorMsg( std::string( __FUNCTION__ ) + 
                                            ":  Erro ao criar shared memory <" +
                                            ECRPROTSRV_SHM + 
                                            ">" );
                    this->enableError( true );
                    this->setErrorMessage( l_errorMsg );
                    return false;
                }
            }    
        }
        else
        {
#ifdef ENABLESTDCOUT            
            std::cout << __LINE__ << "-shm encontrada" << std::endl;
#endif   
        
            l_created = 0;
        }

        if ( ( m_ecrshmHdr = (struct _ecrshm_hdr *) sh_attach( m_ecrshmId ) ) == 0 )
		{
			sem_release( m_ecrsemsrvId );
            std::string l_errorMsg( std::string( __FUNCTION__ ) + 
                                    ":  Erro no attach da shared memory criada <" +
                                    ECRPROTSRV_SHM + 
                                    ">" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
		}
        
        m_ecrshm = ( struct _ecrshm * )( ( char * ) m_ecrshmHdr +
                   sizeof( struct _ecrshm ) );
        if( l_created )
        {	
            memset( ( char * ) m_ecrshmHdr, 0, sizeof( _ecrshm_hdr ) );
			m_ecrshmHdr->id = m_ecrshmId;
			m_ecrshmHdr->datetime_creat = time( NULL);
			m_ecrshmHdr->conn_primary = 0;
			m_ecrshmHdr->conn_secondary = 0;
			m_ecrshmHdr->max_elems_num = ECR_MAX_CONN;
			m_ecrshmHdr->elem_len = sizeof(struct _ecrshm);
			memset( ( char * ) m_ecrshm , 
                    0,
					( m_ecrshmHdr->max_elems_num * m_ecrshmHdr->elem_len ) );
        }   
        else
		{	
			if( m_ecrshmHdr->datetime_creat < mbstarttime())
			{
				m_ecrshmHdr->datetime_creat = time( NULL);
				m_ecrshmHdr->conn_primary = 0;
				m_ecrshmHdr->conn_secondary = 0;
				memset( (char *)m_ecrshm, 0,
					    ( m_ecrshmHdr->max_elems_num * m_ecrshmHdr->elem_len));
			}
		}
        sem_release( m_ecrsemsrvId );        
        if ( ( m_ecrprotsrvMbid = mb_locatemailbox( m_protomMbName.c_str() ) ) < 0 )
        {
            std::string l_errorMsg( std::string( __FUNCTION__ ) + 
                                    ": Unable to find ProtomMbName <" +
                                    m_protomMbName + 
                                    ">" );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }
        snprintf( l_aux,
                  sizeof l_aux,
                  "mbcmd clear event `tmlook |grep %s |cut -f2 -d'[' |cut -f1 -d']'`",
                  m_protomMbName.c_str() );
        system( l_aux );
        
        //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "tm_enqueue - Enfileiramento no Protom" );               
        /* tocheck - fluxo de operation evento apenas eh chamado quando o evento eh expirado  */
        /* task ECRProtomServer precisa estar rodando para consumir evento expirado*/

        if( ( tm_enqueue( m_ecrprotsrvMbid, 
                          time( NULL ) + ECRPROTSRV_EVENT_TIMEOUT,
                          TM_NOTIFY_ONCE, 
                          getpid(), 
                          l_evdata, 
                          sizeof( l_evdata ) ) ) < 0 )
        {
            std::string l_errorMsg( std::string( __FUNCTION__ ) + 
                                    ": Unable to create the event." );
            this->enableError( true );
            this->setErrorMessage( l_errorMsg );
            return false;
        }        
        
        
        return true;
    }
    int ProtomServer::gainResource( int a_resourceid, int a_waituntil, int a_waitinterval )
    {
        int l_i = 0, l_retval = 0;
        if( a_waituntil )
        {
            sem_acquire( a_resourceid );
        }
        else
        {
            do
            {
                if( ( l_retval = sem_lock( a_resourceid, 0, 0 ) ) < 0 )
                {
                    if( errno == EAGAIN )
                    {
                        if( a_waitinterval )
                        {                            
                            sleep( 1 );
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        return -1;                        
                    }
                }
                else
                {
                    break;
                }
            } while( ( ++l_i ) <= a_waitinterval );
        }
        return( l_retval );
    }
    std::string ProtomServer::determinePorts()
    {
        char l_aux[1024];
        char l_aux2[30];
        std::string l_cfgLines;
        std::string l_xngePortname;  
        int l_instBySffx = -1;
        int l_i, l_j, l_k;
        struct _inst_tbl {
            int		portnum;
            char	instance_id;
         } *l_instTbl;
        struct _inst_tbl *l_instElem;
        char * l_auxp;
        int l_lastOcc;
        int	l_begPort, l_endPort;
        
        snprintf( l_aux, sizeof l_aux, "exit `mbcmd task |grep mbport |wc -l`");
        for( l_i = ( system( l_aux ) >> 8); 
             !( system( l_aux ) >> 8) && ( l_i < 12); l_i++)
        {
            sleep( 5 );
        }
        if( l_i && ( l_i < 12 ) )
        {
            sleep( 15 );
        }
        else
        {
            return std::string( __FUNCTION__ ) + ": Can not find mbport in mbcmd tasks.";
        }


        if ( configBase::ConfigBase::getInstance()->findFirst( "port.name", l_cfgLines ) )
        {
            do
            {
                if ( l_cfgLines.find( m_protomMbName ) != std::string::npos )
                {
                    l_xngePortname.assign( l_cfgLines.substr( 0, l_cfgLines.find(' ') ) );
    #ifdef ENABLESTDCOUT                                
                    std::cout << __LINE__ <<"-name:["<< l_cfgLines.substr( 0, l_cfgLines.find(' ') ) << "]" << std::endl;    
    #endif                                  
                }
            } while ( configBase::ConfigBase::getInstance()->findNext( l_cfgLines ) );
        }
        if( l_i > 1)
        {
            return std::string( __FUNCTION__ ) + ": Can not find ports defined on istparam.cfg";
        }
        else if ( l_i > 0)
        {
            int l_portid;            
            l_portid = mb_locateport( l_xngePortname.c_str() );
            if( l_portid < 0 )
            {
                return std::string( __FUNCTION__ ) + ": Can not find l_portid for <"+
                       l_xngePortname + ">";
            }
            m_xngePortmbid = mb_locatemailbox( l_xngePortname.c_str() );
            if( m_xngePortmbid < 0)
            {                
                m_xngePortmbid = mbPortMailBox( l_portid );
            }            
            m_xngePort = mb_getportentry( l_portid );
            if( !memcmp( m_xngePort->address.a.address, "localhost.", 10))
            {
                m_xngePortIsLocal = 1;
            }
            else
            {
                m_xngePortIsLocal = 0;
            }
        }
        else
        {
            m_xngePortmbid = -1;
        }
        l_i = 0;
        if ( configBase::ConfigBase::getInstance()->findFirst( "port.name", l_cfgLines ) )
        {
        
            do
            {
                if ( ( l_cfgLines.find( "fmt_protom" ) != std::string::npos ) &&
                     ( l_cfgLines.find( "accept-" ) != std::string::npos ) )
                {
    #ifdef ENABLESTDCOUT                                
                    std::cout << __LINE__ <<"-name:["<< l_cfgLines.substr( 0, l_cfgLines.find(' ') ) << "]" << std::endl;    
    #endif                                  
                
                    snprintf( m_portTbl[ l_i ].portname, 
                              MB_MAX_NAME + 1, "%s" , 
                              l_cfgLines.substr( 0, l_cfgLines.find(' ') ).c_str() );
                    l_i++;                          
                }
            } while ( configBase::ConfigBase::getInstance()->findNext( l_cfgLines ) );
        }        
        cf_locatenum( "ecrprotsrv.port_instance_by_suffix", &l_instBySffx);
#ifdef ENABLESTDCOUT                                    
                    std::cout << __LINE__ <<"-l_instBySffx:["<< l_instBySffx << "]" << std::endl;    
#endif          
        if( l_instBySffx <= 0)
        {
            if( (l_instTbl = (struct _inst_tbl *)((char *)calloc( 1,
                                        (500 * sizeof(struct _inst_tbl))))) == NULL)
            {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif                      
                return std::string( __FUNCTION__ ) + ": Unable to allocate memory for temporary space";
            }
            cf_rewind();            
            l_i = 0;
            l_instElem = l_instTbl;
            snprintf( l_aux2, sizeof l_aux2, "ecrprotsrv.port_instance");
            if( cf_locate( l_aux2, l_aux) > 0)
            do
            {
                l_auxp = l_aux;
                l_lastOcc = 0;
                l_j = atoi( l_aux );	
                for( ; *l_auxp >= '0' && *l_auxp <= '9'; l_auxp++ )
                    ;
                l_auxp++;
                for( ; ; )
                {
                    for( l_k=0; 
                         *( l_auxp + l_k ) != ',' && *( l_auxp + l_k ) != '-' && l_k < strlen( l_auxp );
                         l_k++)
                        ;
                    if( ( l_k < strlen( l_auxp ) && *( l_auxp + l_k ) == ',' )
                         ||	l_k >= strlen( l_auxp ) )
                    {
                        if( l_k < strlen( l_auxp ) )
                        {
                            *( l_auxp + l_k ) = '\0';
                        }
                        else
                        {
                            l_lastOcc = 1;
                        }
                        l_instElem->portnum = atoi( l_auxp );
                        l_instElem->instance_id = (char) l_j;
                        l_i++;
                        l_instElem++;
                        if( l_lastOcc)
                        {
                            break;
                        }
                        l_auxp += ( l_k + 1 );
                        l_k = 0;
                    }
                    else
                    {
                        if( *( l_auxp + l_k ) == '-' )
                        {
                            *( l_auxp + l_k ) = '\0';
                            l_begPort = atoi( l_auxp);
                            l_auxp += ( l_k + 1);
                            for( l_k = 0; 
                                 *( l_auxp + l_k ) != ',' && l_k <= strlen( l_auxp ); 
                                 l_k++)
                                ;
                            if( l_k < strlen( l_auxp ) )
                            {
                                *( l_auxp + l_k ) = '\0';
                            }
                            else
                            {
                                l_lastOcc = 1;
                            }
                            l_endPort = atoi( l_auxp);
                            for( ; l_begPort <= l_endPort; l_begPort++, l_i++, l_instElem++ )
                            {
                                l_instElem->portnum = l_begPort;  
                                l_instElem->instance_id = (char)l_j;
                            }
                            if( l_lastOcc)
                            {
                                break;
                            }
                            l_auxp += ( l_k + 1 );
                            l_k = 0;
                        }
                    }
                }            
            } while( cf_nextparm( l_aux2, l_aux) > 0 && l_i < 500);
            if( l_i > 499)
            {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif          
                return std::string( __FUNCTION__ ) + ":Exceeded max number of ports configuration";
            }
            l_instElem->portnum = -999999;	
        }
        else        
        {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif                  
            l_instTbl = NULL;
        }
        
        for( l_i = 0; strlen(m_portTbl[l_i].portname) && l_i < MAX_PORT_TBL_ELEM; l_i++ )
        {
            
            m_portTbl[ l_i ].client_mbid = mb_locatemailbox( m_portTbl[ l_i ].portname );
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << "-l_i:" << l_i << "-m_portTbl[ l_i ].portname:" << m_portTbl[ l_i ].portname << "-m_portTbl[ l_i ].client_mbid :" << m_portTbl[ l_i ].client_mbid  << std::endl;    
#endif                      
            if( m_portTbl[ l_i ].client_mbid < 0 )
            {
                m_portTbl[ l_i ].client_portid = mb_locateport( m_portTbl[ l_i ].portname );
                if(m_portTbl[ l_i ].client_portid < 0 )
                {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << "-l_i:" << l_i << "-m_portTbl[ l_i ].portname:" << m_portTbl[ l_i ].portname << std::endl;    
#endif          
                    return std::string( __FUNCTION__ ) + ": Invalid port-name:" + 
                           std::string( m_portTbl[ l_i ].portname );
                }
                m_portTbl[ l_i ].client_mbid = mbPortMailBox( m_portTbl[ l_i ].client_portid );
            }
            m_portTbl[ l_i ].client_portid = mb_locateport( m_portTbl[ l_i ].portname );
            if( m_portTbl[ l_i ].client_portid < 0 )
            {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif                      
                return std::string( __FUNCTION__ ) + ": Invalid <" + m_portTbl[ l_i ].portname +
                       "> client port id <" + std::string( m_portTbl[ l_i ].portname ) + ">";
            }
            m_portTbl[ l_i ].client_port = mb_getportentry( m_portTbl[ l_i ].client_portid );
            if( l_instBySffx > 0 )
            {
                if ( strstr( m_portTbl[ l_i ].portname, "237" ) )
                {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif                          
                    m_portTbl[ l_i ].instance_id = (char)1;
                }
                else
                {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif          
                    m_portTbl[ l_i ].instance_id = (char)0;
                }
#ifdef ENABLESTDCOUT                
                std::cout << "l_i[" << l_i <<"] NEW PORT [" <<  m_portTbl[ l_i].portname << "] mbid[" << m_portTbl[ l_i ].client_mbid << "] portid[" << m_portTbl[ l_i ].client_portid << "]";
                if ( m_portTbl[ l_i ].instance_id == (char) 0 )
                    std::cout << " inst[0]" << std::endl;
                else
                    std::cout << " inst[1]" << std::endl;
#endif                
            }
            else
            {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif             
                l_auxp = m_portTbl[ l_i ].client_port->address.a.address;
                l_auxp += ( strcspn( l_auxp, ".") + 1 );
                l_begPort = atoi( l_auxp );
                for( l_instElem = l_instTbl; l_instElem->portnum != -999999; l_instElem++)
                {
                    if( l_instElem->portnum == l_begPort)
                    {
                        m_portTbl[ l_i ].instance_id = l_instElem->instance_id;
                        break;
                    }
                }
            }
        }
        if( l_instTbl != NULL )
        {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif                  
            free( l_instTbl );
        }
        if( !l_i )
        {
#ifdef ENABLESTDCOUT                                    
                std::cout << __LINE__ << std::endl;    
#endif                  
            return std::string( __FUNCTION__ ) + ":Port to ECR X.25-TCP/IP Router could not be determined";
        }     
        return NOERROR;
    }
    void ProtomServer::finish()
    {        
#ifdef ENABLESTDCOUT            
            std::cout << __FUNCTION__ << std::endl;
#endif              
        if( m_ecrshmHdr )
        {
            sh_detach( reinterpret_cast<char *>(m_ecrshmHdr) );
            m_ecrshmHdr = NULL;
        }
        
        
        
        char l_aux[100];
        snprintf( l_aux,
                  sizeof l_aux,
                  "mbcmd clear event `tmlook |grep %s |cut -f2 -d'[' |cut -f1 -d']'`",
                  m_protomMbName.c_str() );
        system( l_aux );
        
        //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "finish - mbcmd clear event - Limpeza de eventos no protom" );       
        //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_aux );
        
        
        
    }
    void ProtomServer::updateEcrShm( short a_netcode, int a_mbid, char a_status )
    {
        if ( gainResource( m_ecrsemsrvId, 1, 0 ) != -1 )
        {
            m_ecrshm[ a_netcode ].status = a_status;
            m_ecrshm[ a_netcode ].mbid = a_mbid;
#ifdef ENABLESTDCOUT        
            std::cout <<"a_netcode ["<< a_netcode << "] a_status [" << a_status << "] a_mbid[" << a_mbid << "]" << std::endl;
#endif            
            sem_release( m_ecrsemsrvId );                  
        }        
    }
    void ProtomServer::setNetstatus( short a_netcode, int a_fromportMbid, int a_status)
    {
        char l_status;
        l_status = a_status ? 0x40 : 0x00;
        l_status |= strstr( mbtab[ a_fromportMbid].name , "237") ? 0x20 : 0x00;
        l_status |= ( m_ecrprotHdr->instance_id & 0x03) << 3;
        l_status |= 0x07;
        updateEcrShm( a_netcode, a_fromportMbid, l_status);        
    }    
    time_t ProtomServer::mbstarttime()
    {
        FILE * l_fp;
        char l_tmpf[200];
        char l_buf[30];
        static time_t l_starttime = 0;
        if( !l_starttime )
        {
            snprintf( l_tmpf, sizeof l_tmpf, "%s/mb.uptime", getenv( "OTMPDIR" ) );
            if( ( l_fp = fopen( l_tmpf ,"r" ) ) != NULL )
            {
                fgets( l_buf, sizeof( l_buf ), l_fp );
                fclose( l_fp );
                l_starttime = atol( l_buf );
            }            
        }
        return( l_starttime);
    } 
    void ProtomServer::processEvent()
    {
        int		l_i, l_j;
        long	l_eventid;
        time_t	l_nexttime;
        int		*l_connStatus;
        int		toreset = 1;
        int		l_connections = 0;
        l_connStatus = m_routerInstance ? (int *)&m_ecrshmHdr->conn_secondary : (int *)&m_ecrshmHdr->conn_primary;
        if( !( *l_connStatus ) )
        {
#ifdef ENABLESTDCOUT        
            std::cout<<"Protom disconnected: Check for connections..." << std::endl;
#endif            
            for( l_i = 0; strlen( m_portTbl[ l_i ].portname); l_i++ )
            {
#ifdef ENABLESTDCOUT                    
                std::cout << "l_i:" << l_i << "-portname:" << m_portTbl[ l_i ].portname;
                if( m_portTbl[ l_i ].instance_id == (char)0 )
                    std::cout<< "-instance_id:0";
                else
                    std::cout<< "-instance_id:1";
                    
                if( (char)m_routerInstance == (char) 0 )    
                    std::cout << "-m_routerInstance:0" << std::endl;
                else
                    std::cout << "-m_routerInstance:1" << std::endl;
#endif                            
                if ( (char)m_portTbl[ l_i ].instance_id != (char)m_routerInstance )
                {
                    continue;
                }
#ifdef ENABLESTDCOUT                    
                    std::cout << "m_portTbl[ l_i ].client_port->flags:"<< m_portTbl[ l_i ].client_port->flags << "-MB_PORT_CONNECTED:" << MB_PORT_CONNECTED << std::endl;
#endif                
                if( m_portTbl[ l_i ].client_port->flags & MB_PORT_CONNECTED )
                {
                    *l_connStatus = 1; 
#ifdef ENABLESTDCOUT                    
                    std::cout << "CONNECT Protom instance "<< m_routerInstance << std::endl;
#endif                    
                    sendInquiryMsg();
                    break;
                }
            }
        }
        else
        {
#ifdef ENABLESTDCOUT        
            std::cout << "Protom instance connected: Check ports..." << std::endl;
#endif            
            for( l_i = 0; strlen( m_portTbl[ l_i ].portname ); l_i++)
            {
                if ( m_portTbl[ l_i ].instance_id != (char)m_routerInstance )
                {
                    continue;
                }                
                if( m_portTbl[ l_i ].client_port->flags & MB_PORT_CONNECTED)
                {
                    l_connections++;
                }
                else
                {
                    for( l_j = 0; l_j < m_ecrshmHdr->max_elems_num; l_j++ )
                    {
                        if ( m_ecrshm[ l_j ].status & 0xC0 &&
                             m_ecrshm[ l_j ].mbid == m_portTbl[ l_i ].client_mbid )
                        {
#ifdef ENABLESTDCOUT                        
                            std::cout << "CLEAR net["<<l_j<<"] status["<<m_ecrshm[l_j].status<<"] port["<<m_portTbl[l_i].portname<<"] mbid["<<m_ecrshm[l_j].mbid<<"]"<<std::endl;
#endif                            
                            m_ecrshm[ l_j ].status = 0x00;
                            m_ecrshm[ l_j ].mbid = 0;
                        }
                    }
                    while( mb_readnw( m_portTbl[ l_i ].client_mbid,
                           (char *)&m_ecrmsg.data,
                            sizeof( m_ecrmsg.data ) ) >= 0 )
                        ;
                }
            }
            if ( ! l_connections )
            {
                *l_connStatus = 0;
#ifdef ENABLESTDCOUT                
                std::cout<<"DISCONNECT Protom instance"<<std::endl;
#endif                
            }
        }
        l_eventid = mbLastEvent();
        l_nexttime = time( NULL) + ECRPROTSRV_EVENT_TIMEOUT;
        tm_requeue( l_eventid, l_nexttime);
        //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "tm_requeue" );
        //logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, itoa( l_eventid) );
        if (PRINTOUT_ACTIVETABLE)
        {
            printoutActivetable();
        }
    }
    void ProtomServer::printoutActivetable()
    {
        FILE * l_wfp;
        time_t l_timenow;
        struct tm l_local;
        int	l_elemsNum;
        struct _ecrshm * l_ecrshmptr;
        l_ecrshmptr = m_ecrshm;
        l_elemsNum = m_ecrshmHdr->max_elems_num;
        if( (l_wfp = fopen( m_activeTableFilepath.c_str() , "w")) == NULL)
        {
            return;
        }
        time( &l_timenow);
        l_local = *localtime( &l_timenow);
        fprintf( l_wfp, "%02d/%02d/%04d %02d:%02d:%02d %42s        \n\n",
                 l_local.tm_mday, 
                 l_local.tm_mon + 1, 
                 1900 + l_local.tm_year,
                 l_local.tm_hour, 
                 l_local.tm_min, 
                 l_local.tm_sec,
                 "Dados da Tabela de Conexoes PDV" );

        fprintf( l_wfp, "NetCd I p St    NetCd I p St    NetCd I p St    NetCd I p St    NetCd I p St    NetCd I p St    NetCd I p St\n");
        for( int i = 0; i < l_elemsNum; )
        {
            for( int j = 0; j < 7 && i < l_elemsNum; i++ )
            {
                if( !( l_ecrshmptr[i].status & 0xC0 ) )
                {
                    continue;
                }
                fprintf( l_wfp, "%5d %02x%c %c     ", i,
                    ( ( l_ecrshmptr[i].status & 0x18 ) >> 3 ),
                    ( ( l_ecrshmptr[i].status & 0x20 ) ? 's' : 'p' ) ,
                    ( ( l_ecrshmptr[i].status & 0x40 ) ? 'U' : 'D' ) );
                j++;
            }
            fprintf( l_wfp, "\n");
        }
        fprintf( l_wfp, "_______________________________________________end-of-list____________________________________________\n");
        fclose(l_wfp);
    }      
    void ProtomServer::sendInquiryMsg()
    {
        int l_portTblElem = 0;       
        for( ; strlen( m_portTbl[ l_portTblElem ].portname); l_portTblElem++)
            {
            if( ( m_portTbl[ l_portTblElem ].client_port->flags & MB_PORT_CONNECTED )
                  && m_portTbl[ l_portTblElem ].instance_id == ( char ) m_routerInstance )
                {
                break;
                }
            }                
        if( !strlen( m_portTbl[ l_portTblElem ].portname ) && !l_portTblElem  )
        {
            return;
        }
        memset( (char * ) m_ecrprotHdr, 0, sizeof( struct _ecrprothdr ) );
        m_ecrprotHdr->type = (char) 8;
        while( mb_readnw( m_ecrprotsrvMbid, 
                          ( char * ) &m_ecrmsg.data,
                          sizeof( m_ecrmsg.data ) ) >= 0 )
        mb_write( m_portTbl[ l_portTblElem ].client_mbid, 
                  m_ecrprotsrvMbid, 
                  ( char * ) m_ecrprotHdr,
                  sizeof( struct _ecrprothdr ) );
    } 
    void ProtomServer::cleanUpConnAll()
    {
        if( ( m_ecrsemsrvId, 0, 30 ) < 0 )
        {
            sem_release( m_ecrsemsrvId );
            sem_acquire( m_ecrsemsrvId );
        }
        if( gainResource( m_ecrsemId, 0, 30 ) < 0 )
        {
            sem_release( m_ecrsemId );
            sem_acquire( m_ecrsemId );
        }
        memset( (char *) m_ecrshm, 0,
                 ( m_ecrshmHdr->max_elems_num * m_ecrshmHdr->elem_len ) );
        sem_release( m_ecrsemId );
        sem_release( m_ecrsemsrvId );
    }    
    void ProtomServer::cleanUpConnDown()
    {
        int l_i;
        int l_j;
        int l_numElems;
        if( gainResource( m_ecrsemsrvId, 0, 30 ) < 0 )
        {
            sem_release( m_ecrsemsrvId );
            sem_acquire( m_ecrsemsrvId );
        }
        if( gainResource( m_ecrsemId, 0, 30 ) < 0 )
        {
            sem_release( m_ecrsemId);
            sem_acquire( m_ecrsemId);
        }
        for( l_i = 0, l_numElems = m_ecrshmHdr->max_elems_num; 
             l_i < l_numElems; l_i++)
        {
            if( m_ecrshm[ l_i ].status & 0x80 )
            {
                m_ecrshm[ l_i ].status = 0x00;
            }
        }
        sem_release( m_ecrsemId);
        sem_release( m_ecrsemsrvId);
    }    
    void ProtomServer::procApplicationCommand( char *a_cmmdmsg )
    {
        char l_cmmd[100];
        if( strlen( a_cmmdmsg ) )
        {
            snprintf( l_cmmd, sizeof l_cmmd, "%s", a_cmmdmsg );
        }
#ifdef ENABLESTDCOUT        
        std::cout << "Received an application command:[" << l_cmmd << "]" << std::endl;
#endif        
        if( !strncmp( l_cmmd, "refresh", strlen( "refresh" ) ) )
        {
            sendInquiryMsg();
#ifdef ENABLESTDCOUT            
            std::cout << "Refresh command. " << std::endl;
#endif            
        }
        else if( !strncmp( l_cmmd, "cleanup all", strlen( "cleanup all") ) )
        {
            cleanUpConnAll();
#ifdef ENABLESTDCOUT            
            std::cout << "Cleanup all connections command." << std::endl;
#endif            
        }
        else if( !strncmp( l_cmmd, "cleanup", strlen( "cleanup" ) ) )
        {
            cleanUpConnDown();
#ifdef ENABLESTDCOUT            
            std::cout << "Cleanup inactive connections command." << std::endl;
#endif            
        }
        else if( !strncmp( l_cmmd, "clear sem", strlen( "clear sem" ) ) )
        {
            if( m_ecrsemsrvId > 0)
            {
                sem_release( m_ecrsemsrvId );
            }
            if( m_ecrsemId > 0)
            {
                sem_release( m_ecrsemId );
            }
#ifdef ENABLESTDCOUT            
            std::cout << "Semaphores clean up done." << std::endl;
#endif            
        }
        else if( !strncmp( l_cmmd, "list active", strlen( "list active" ) ) )
        {
            printoutActivetable();
        }
        else
        {
#ifdef ENABLESTDCOUT        
            std::cout << "Unexpected command:[" << l_cmmd << "]. Ignored" << std::endl;
#endif            
        }
    }    
    bool ProtomServer::msgtype01or02()
    {
        char l_fromportname[ MB_MAX_NAME + 1 ];
        short l_netcode = 0;
#ifdef ENABLESTDCOUT        
        std::cout << __FUNCTION__ << std::endl;
#endif        
        
        memcpy( ( char * ) &l_netcode, m_ecrprotHdr->net_codex, 2 );
#ifdef ENABLESTDCOUT        
        std::cout << __LINE__ << "-m_fromPortmbid:" << m_fromPortmbid << "-mb->nboxes:" << mb->nboxes << std::endl;
#endif  

#ifdef ENABLESTDCOUT        
    for( int ix=0; ix < mb->nboxes; ix++)
    {
//        std::cout << __LINE__ << "-mbtab["<<ix<<"|"<<mb->nboxes<<"].name:" << mbtab[ ix ].name << std::endl;
    }
#endif      
        strcpy( l_fromportname, mbtab[ m_fromPortmbid ].name );
#ifdef ENABLESTDCOUT        
        std::cout << "From port [" << m_fromPortmbid << "]-l_fromportname[" << l_fromportname << "]" <<std::endl;
#endif        
        if( m_ecrprotHdr->type == (char) 1 ) 	
        {
            setNetstatus( l_netcode, m_fromPortmbid, 1 );
        }
        else if ( m_ecrprotHdr->type == (char) 2 ) 
        {
            m_ecrshm[ l_netcode ].status = 0x00;
            m_ecrshm[ l_netcode ].mbid = 0;
#ifdef ENABLESTDCOUT            
            std::cout << "CLEAR STATUS net[" << l_netcode <<"] port[" << mbtab[ m_fromPortmbid ].name <<"] mbid[" << m_fromPortmbid << "]" << std::endl;
#endif            
        }        
        else
        {
#ifdef ENABLESTDCOUT                    
            printf("\nLine: %d Type: %u/%x/%d\n", __LINE__,(unsigned char) m_ecrprotHdr->type, (unsigned char) m_ecrprotHdr->type, (unsigned char) m_ecrprotHdr->type );
#endif            
            return false;            
        }

        return true;
    }
    bool ProtomServer::msgtype16()
    {
        char l_fromportname[ MB_MAX_NAME + 1 ];
        short l_netcode;
        int l_i;
        int l_totalRecsNum = 0;
        memset( ( char * ) &l_totalRecsNum, 0, sizeof( l_totalRecsNum ) );
        memcpy( ( char * ) &l_totalRecsNum + 2, ( char * ) &m_ecrprotHdr2->total_conns, 2); 
        if( (l_totalRecsNum < 0 ) || ( ( l_totalRecsNum * sizeof( struct _conn_info ) + 
             sizeof( struct _ecrprothdr2 ) ) > m_sourceField.field().length() ) )
        {            
        #ifdef ENABLESTDCOUT        
            std::cout << "l_totalRecsNum[" << l_totalRecsNum << "] sizeof( struct _conn_info )[" << sizeof( struct _conn_info ) << "] sizeof( struct _ecrprothdr2 )[" << sizeof( struct _ecrprothdr2 ) << "]" << std::endl;
            std::cout << "sum:" << ( l_totalRecsNum * sizeof( struct _conn_info ) + sizeof( struct _ecrprothdr2 ) ) << std::endl;
            std::cout << "m_sourceField.field().length():"<< m_sourceField.field().length() << std::endl;
        #endif        
        
            return false;
        }
        m_connInfoElem = ( struct _conn_info * )
                         ( (char *) m_ecrprotHdr2 + sizeof( struct _ecrprothdr2 ) );
        strcpy( l_fromportname, mbtab[ m_fromPortmbid ].name);
#ifdef ENABLESTDCOUT        
        std::cout << "From port name [" << l_fromportname << "]" << std::endl;
#endif        
        for( l_i = l_totalRecsNum; l_i; l_i--, m_connInfoElem++)
        {
            memcpy( ( char * ) &l_netcode, m_connInfoElem->net_codex, 2 );
            setNetstatus( l_netcode, m_fromPortmbid, 1 );
#ifdef ENABLESTDCOUT        
        std::cout << "l_i [" << l_i << "] l_netcode[" << l_netcode << "] m_fromPortmbid[" << m_fromPortmbid << "]" << std::endl;
#endif
        }
        return true;
    }       
    int ProtomServer::execute( bool& a_stop )
    {
        if( !m_isProtomMsg )
        {
            return 0;
        }
        if( !m_operation.compare( "getstatus" ) )
        {       
            short l_netcodex = 0;
            l_netcodex = (int) strtol( (const char *) m_netcodexField.data(), 
                                       NULL, 16);
#ifdef ENABLESTDCOUT     
        std::cout << __LINE__ << "-l_netcodex[" << l_netcodex << "]"<< std::endl;
#endif        
            if( l_netcodex >= 0  && l_netcodex < ECR_MAX_CONN )
            {
                fieldSet::fscopy( m_targetField, 
                                  m_ecrshm[ l_netcodex ].status & 0x40 ? "true" : "false" );            
            }
            else
            {
                this->enableError( true );
                this->setErrorMessage( "Netcodex <" +
                                       m_netcodexField.value() +
                                       "> is out of bounds. " );
            }
        }
        else if( !m_operation.compare( "protomforward" ) ) 
        {
            int	l_len = m_sourceField.field().length();
            int l_lastSenderId = mbLastSenderId();
            fieldSet::fsextr( ( char * ) &m_ecrmsg, sizeof( m_ecrmsg ), m_sourceField.field() );
 
            memcpy((char *)&m_ecrmsg + l_len,(char *)&l_lastSenderId + 2, 2);
            memcpy((char *)&m_ecrmsg + l_len + 2,(char *)&m_routerInstance + 2, 2);
   
            if( mb_write( m_ecrprotsrvMbid, l_lastSenderId, (char *)&m_ecrmsg, l_len + 4) < 0)
            {
                this->enableError( true );
                this->setErrorMessage( "Error writing msg to protom mailbox " );
            }
#ifdef ENABLESTDCOUT                
            else
            {
                std::cout << "FORWARDED protommbid[" << m_ecrprotsrvMbid <<"] lastsenderid[" << mbLastSenderId() <<"] len[" << l_len << "] sizeof( m_ecrmsg ) [" << sizeof( m_ecrmsg ) << "]" << std::endl;
            }
#endif                    
        }
        else if( !m_operation.compare( "forwardmsg" ) ) 
        {
            int l_i;
            int	l_len = m_sourceField.field().length();
            char l_destportname[10];
            int l_netcodex = 0;
            fieldSet::fsextr( ( char * ) &m_ecrmsg, sizeof( m_ecrmsg ), m_sourceField.field() );
            memcpy( (char *) &l_netcodex + 2 , m_ecrprotHdr->net_codex, 2 );                        
#ifdef ENABLESTDCOUT        
        std::cout << __LINE__ << "-l_netcodex [" << l_netcodex << "] "<< std::endl;
#endif                    

            if( !( m_ecrshm[ l_netcodex ].status & 0x40 ) )
            {
                this->enableError( true );
                this->setErrorMessage( "Destination Net down. Routed msg discarded" );
                return 0;
            }
            strcpy( l_destportname, mbMailBoxName( m_ecrshm[ l_netcodex ].mbid ) );
            for( l_i = 0; strlen( m_portTbl[ l_i ].portname) &&
                 strcmp( m_portTbl[ l_i ].portname,l_destportname); l_i++)
                ;
            if( !( strlen( m_portTbl[ l_i ].portname ) ) ||
                !( m_portTbl[ l_i ].client_port->flags & MB_PORT_CONNECTED ) )
            {
                if(	!( strlen( m_portTbl[ l_i ].portname ) ) )
                {
                    this->enableError( true );
                    this->setErrorMessage( "Port " +
                                           std::string( l_destportname ) +
                                           "not found. Routed msg discarded" );
                }
                else
                {
                    this->enableError( true );
                    this->setErrorMessage( "Port " +
                                           std::string( l_destportname ) +
                                           "down. Routed msg discarded" );
                }
                return 0;
            }
            
#ifdef ENABLESTDCOUT        
        std::cout << __LINE__ << "-m_ecrmsg("<<m_sourceField.field().length()<<") [" << m_sourceField.field().c_str() << "] "<< std::endl;
#endif                    
            if( mb_write( m_portTbl[ l_i ].client_mbid, m_ecrprotsrvMbid, (char *)&m_ecrmsg, l_len) < 0)
            {
                this->enableError( true );
                this->setErrorMessage( "Error writing msg to formatter mailbox " );
            }
#ifdef ENABLESTDCOUT            
            std::cout << "FORWARDED net[" << l_netcodex <<"] port[" << l_destportname <<"] mbid[" << m_portTbl[ l_i ].client_mbid << "] len[" << l_len << "]" << std::endl;          
#endif            
        }
        else if( !m_operation.compare( "message" ) ) 
        {   
            int	l_len = m_sourceField.field().length();
            fieldSet::fsextr( ( char * ) &m_ecrmsg, sizeof( m_ecrmsg ), m_sourceField.field() );
#ifdef ENABLESTDCOUT        
        std::cout << __LINE__ << "-m_ecrmsg("<<m_sourceField.field().length()<<") [" << m_sourceField.field().c_str() << "] "<< std::endl;
#endif                    
            m_fromPortmbid = 0; 
            memcpy( ( char * )&m_fromPortmbid + 2, ( char * )&m_ecrmsg + ( l_len - 4 ), 2 );
            if ( m_fromPortmbid >= mb->nboxes )
            {
                char l_error[100];
                snprintf( l_error, 
                          sizeof l_error, 
                          "Outbound port mailbox id from protom message <%d/%d>", 
                          m_fromPortmbid, 
                          mb->nboxes );
                this->enableError( true );
                this->setErrorMessage( l_error );  
                return 0;
            }
#ifdef ENABLESTDCOUT                    
                    std::cout << __LINE__ <<"-m_fromPortmbid:" << m_fromPortmbid << std::endl;
#endif                  
            m_fromRouterInstance = 0;
            memcpy( ( char * )&m_fromRouterInstance + 2, ( char * )&m_ecrmsg + ( l_len - 2 ), 2 );
#ifdef ENABLESTDCOUT                    
                    std::cout << "m_fromRouterInstance:" << m_fromRouterInstance << std::endl;
#endif                
            l_len -= 4;
            if( m_ecrprotHdr->type == (char) 32 )
            {
#ifdef ENABLESTDCOUT                    
                    std::cout << "msgtype TYPE:[32]" << std::endl;
#endif              
                if( !memcmp( ( char * )&m_ecrmsg + sizeof( struct _ecrprothdr ),
                             "00001", 5 ) )
                {	
#ifdef ENABLESTDCOUT                    
                    std::cout << __LINE__ << std::endl;
#endif              
                
                    int l_netcodei = 0;
                    memcpy( ( char * )&l_netcodei + 2, 
                            ( char * )&m_ecrmsg + sizeof(struct _ecrprothdr) + 12 + 2 + 3,
                            2 );
                    m_ecrshm[ l_netcodei].status = 0x00;
                    m_ecrshm[ l_netcodei].mbid = 0;
#ifdef ENABLESTDCOUT                    
                    std::cout << "CLEAR net[" << l_netcodei << "]" << std::endl;
#endif                    
                }                
                this->enableWarning( true );
                this->setWarningMessage( "Error message from Protom" );
                
            }
            else if( m_ecrprotHdr->type != (char) 16 )
            {
#ifdef ENABLESTDCOUT                    
                    std::cout << "msgtype TYPE:[!16]" << std::endl;
                    std::cout << "m_ecrprotHdr->type != (char) 16:" << ((m_ecrprotHdr->type != (char) 16 )? '1' : '0') << std::endl;
                    std::cout << "m_ecrprotHdr->type != (unsigned char) 16:" << ((m_ecrprotHdr->type != (unsigned char) 16 )  ? '1' : '0' ) << std::endl;
                    std::cout << "m_ecrprotHdr->type != 0x16:" << ((m_ecrprotHdr->type != 0x16 ) ? '1' : '0' )<< std::endl;
                    std::cout << "m_ecrprotHdr->type != 16:" << ((m_ecrprotHdr->type != 16 ) ? '1' : '0' )<< std::endl;
#endif                          
                if ( !msgtype01or02() )
                {
                    this->enableWarning( true );
                    this->setWarningMessage( "Invalid protom msg type." );
#ifdef ENABLESTDCOUT                    
                    std::cout << "Invalid TYPE:[" << m_ecrprotHdr->type << "] from ECR Protom. Msg discarded" << std::endl;
#endif                    
                }
            }
            else
            {
#ifdef ENABLESTDCOUT                    
                std::cout << "msgtype TYPE:[16]" << std::endl;
#endif                          
                if ( !msgtype16() )
                {
                    this->enableWarning( true );
                    this->setWarningMessage( "Unexpected value for Number-Of-Records in total_conns" );                 
                }
            }
            if( PRINTOUT_ACTIVETABLE && m_ecrprotHdr->type != (char) 32 )
            {
                printoutActivetable();
            }
        } 
        else if( !m_operation.compare( "command" ) )
        {   
            fieldSet::fsextr( ( char * ) &m_ecrmsg, sizeof( m_ecrmsg ), m_sourceField.field() );            
#ifdef ENABLESTDCOUT        
        std::cout << __LINE__ << "-m_ecrmsg("<<m_sourceField.field().length()<<") [" << m_sourceField.field().c_str() << "] "<< std::endl;
#endif                    
            procApplicationCommand( ( char * ) &m_ecrmsg );
        } 
        else if( !m_operation.compare( "event") )
        {               
            processEvent();
        } 
        else
        {
            this->enableError( true );
            this->setErrorMessage( "Unexpected Protom Server operation <" +
                                   m_operation + ">" );  
        }
		a_stop = false;
		return 0;
    }    
	ProtomServer& ProtomServer::setArgsFieldPath( const std::string& a_path )
	{
		m_argsFieldPath = a_path;
		return *this;
	}     
	ProtomServer& ProtomServer::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}    
    ProtomServer& ProtomServer::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    dataManip::Command* ProtomServer::clone() const
    {
        return new ProtomServer(*this);
    }
}//namespace plugins_pdv
