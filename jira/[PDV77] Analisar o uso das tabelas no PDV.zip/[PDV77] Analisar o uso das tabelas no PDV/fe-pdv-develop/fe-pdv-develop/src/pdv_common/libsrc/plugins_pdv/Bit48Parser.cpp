#pragma once

#include <cstdio>
#include <ctime>
#include <sstream>
#include <cstring>
#include <shcdef.h>
#include "plugins_pdv/Bit48Parser.hpp"
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include <debug.h>
#include <ist_otrace.h>
#include <iomanip>

namespace plugins_pdv
{
    base::Identificable* createBit48Parser( )
    {
        Bit48Parser* l_new = new Bit48Parser;
        return( l_new );
    }

    Bit48Parser::Bit48Parser( )
    {
    }

    Bit48Parser::~Bit48Parser( )
    {
    }

    Bit48Parser& Bit48Parser::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return( *this );
    }

    Bit48Parser& Bit48Parser::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return( *this );
    }

    Bit48Parser& Bit48Parser::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return( *this );
    }

    dataManip::Command* Bit48Parser::clone( ) const
    {
        return( new Bit48Parser( *this ) );
    }

    bool Bit48Parser::init( )
    {
        m_common_is_reversal = this->navigate( m_sourceFieldPath + ".segments.common.is_reversal" );
        m_common_is_void = this->navigate( m_sourceFieldPath + ".segments.common.is_void" );
        m_shc_msg_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_shc_msg_pcode = this->navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        m_common_bit48 = this->navigate( m_sourceFieldPath + ".segments.common.bit48" );
        m_common_versao_aplicativo = this->navigate( m_sourceFieldPath + ".segments.common.versao_aplicativo" );
        m_cvv2 = this->navigate( m_targetFieldPath + ".shc_msg.cvv2" );
        m_indCripto = this->navigate( m_targetFieldPath + ".segments.merchant.indCripto" );
        m_tipoCriptLegado = this->navigate( m_targetFieldPath + ".segments.merchant.tipoCriptLegado" );
        m_cartCriptLegado = this->navigate( m_targetFieldPath + ".segments.merchant.cartCriptLegado" );
        m_id_pedido = this->navigate( m_targetFieldPath + ".segments.common.id_pedido" );
        m_pdv_trn_id = this->navigate( m_targetFieldPath + ".segments.common.pdv_trn_id" );
        m_avs_cep = this->navigate( m_targetFieldPath + ".segments.credit.avs_cep" );
        m_avs_end_fat = this->navigate( m_targetFieldPath + ".segments.credit.avs_end_fat" );
        m_avs_cpf = this->navigate( m_targetFieldPath + ".segments.credit.avs_cpf" );
        m_transactionId = this->navigate( m_targetFieldPath + ".segments.common.transactionId" );
        m_req_signature = this->navigate( m_targetFieldPath + ".segments.credit.req_signature" );
        m_cap_positive_conf = this->navigate( m_targetFieldPath + ".segments.debt.cap_positive_conf" );
        m_cap_data_positive_conf = this->navigate( m_targetFieldPath + ".segments.debt.cap_data_positive_conf" );
        m_num_prompts_cp = this->navigate( m_targetFieldPath + ".segments.debt.num_prompts_cp" );
        m_dados_coletados = this->navigate( m_targetFieldPath + ".segments.debt.dados_coletados" );
        m_vl_txa = this->navigate( m_targetFieldPath + ".segments.common.vl_txa" );
        m_vl_pca_ent = this->navigate( m_targetFieldPath + ".segments.common.vl_pca_ent" );
        m_cap_referal = this->navigate( m_targetFieldPath + ".segments.credit.cap_referal" );
        m_num_prompts_rf = this->navigate( m_targetFieldPath + ".segments.credit.num_prompts_rf" );
        m_saldo_parcial = this->navigate( m_targetFieldPath + ".segments.voucher.saldo_parcial" );
        m_cod_veiculo = this->navigate( m_targetFieldPath + ".segments.voucher.cod_veiculo" );
        m_cod_condutor = this->navigate( m_targetFieldPath + ".segments.voucher.cod_condutor" );
        m_tipo_servico = this->navigate( m_targetFieldPath + ".segments.voucher.tipo_servico" );
        m_cod_combustivel = this->navigate( m_targetFieldPath + ".segments.voucher.cod_combustivel" );
        m_litragem = this->navigate( m_targetFieldPath + ".segments.voucher.litragem" );
        m_quilometragem = this->navigate( m_targetFieldPath + ".segments.voucher.quilometragem" );
        m_statistics = this->navigate( m_targetFieldPath + ".segments.adm.statistics" );
        m_bit63 = this->navigate( m_targetFieldPath + ".segments.common.bit63" );
        return( true );
    }
    
    void Bit48Parser::finish( )
    {
    }

    int Bit48Parser::execute( bool& a_stop )
    {        
        try
        {        
            std::ostringstream l_log;

            if ( processa_bit48( l_log ) == false )
            {
                std::ostringstream osAux;
                std::string aux;
                
                osAux.clear();
                osAux << "          Dados de entrada:\n";
                osAux << "          msgtype[" << m_msgtype             << "]\n";
                osAux << "          pcode["   << m_pcode               << "]\n";
                osAux << "          de48["    << m_bit48.substr( 0, 2) << "]\n";
                osAux << "\n<########## Erro plugin Bit48Parser ##########>\n";                
                osAux << l_log.str( );
                osAux << "</########## Erro plugin Bit48Parser ##########>\n";
                OTraceDebug( osAux.str( ).c_str() );
            }
        }
        catch( base::GenException e )
        {
            std::string l_msg = "Exception in Bit48Parser <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            std::string l_msg = "std::exception in Bit48Parser <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return( 0 );
    }

    bool Bit48Parser::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

        return( true );
    }

    bool Bit48Parser::processa_bit48( std::ostringstream &l_log )
    {
        std::vector<Prompt> l_prompt;
        Bit48 l_fields;
        std::string s_tipoCriptLegado;
        std::string s_cartCriptLegado;
        std::string s_indCripto;
		std::string s_cap_positive_conf;
		std::string s_cap_data_positive_conf;
		std::string s_dados_coletados;
		std::string s_cvv2;
        
        memset( (char *)&l_fields, '\0', sizeof( l_fields ) );
        fieldSet::fsextr( m_is_reversal, m_common_is_reversal );
        fieldSet::fsextr( m_is_void, m_common_is_void );
        fieldSet::fsextr( m_msgtype, m_shc_msg_msgtype );
        fieldSet::fsextr( m_pcode, m_shc_msg_pcode );
        fieldSet::fsextr( m_bit48, m_common_bit48 );        
        fieldSet::fsextr( m_versao_aplicativo, m_common_versao_aplicativo );        

        if( m_versao_aplicativo < 205 )  // Versao anterior a 2.05 nao tem transacao referida
            fieldSet::fscopy( m_cap_referal, "N", 1 );

        if( m_versao_aplicativo < 500 ) // Limpa as variaveis para colocar valores default no final se ainda estiverem vazias
        {
		    fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
		    fieldSet::fscopy( m_cartCriptLegado, "", 1 );
		    fieldSet::fscopy( m_indCripto, "", 1 );
		    fieldSet::fscopy( m_cap_positive_conf, "", 1 );
		    fieldSet::fscopy( m_cap_data_positive_conf, "", 1 );
		    fieldSet::fscopy( m_dados_coletados, "", 1 );
		    fieldSet::fscopy( m_cvv2, "", 1 );
        }

        if ( ( m_bit48.substr( 0, 2 ) == "AD" ) && ( m_msgtype == 200 ) && ( m_pcode == 3009 || m_pcode == 3900 ) &&
             ( ( m_versao_aplicativo < 202 && ( sizeof( ADIII ) - 17 <= m_bit48.length( ) ) ) || // Adicionados 3 campos na versao 2.02
               sizeof( ADIII ) <= m_bit48.length( ) ) )
        { // Credito IATA (versoes anteriores a 2.05 do PDV)
            processa_bit48_adiii( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_adiii( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "AD" ) && ( m_msgtype == 200 ) && ( m_pcode == 3000 ) &&
                  ( ( m_versao_aplicativo < 202 && ( sizeof( ADII ) - 17 <= m_bit48.length( ) ) ) || // Adicionados 3 campos na versao 2.02
                    sizeof( ADII ) <= m_bit48.length( ) ) )
        { // Credito (nao IATA - versoes anteriores a 2.05 do PDV)
            processa_bit48_adii( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_adii( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "AD" ) &&  // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT056
                  ( ( m_versao_aplicativo < 202 && ( sizeof( AD ) - 2 - 3 - 2 - 14  <= m_bit48.length( ) ) ) || // Adicionados dos campos na versao 2.02
                    ( m_versao_aplicativo < 205 && ( sizeof( AD ) - 2 - 3 <= m_bit48.length( ) ) ) || // Adicionado CVC2 de tamanho 3 na versao 2.05
                    ( m_versao_aplicativo < 500 && ( sizeof( AD ) - 2 <= m_bit48.length( ) ) ) || // CVC2 aumentou tamanho de 3 para 5 na versao 5.00
                    sizeof( AD ) <= m_bit48.length( ) ) )
        { // Demais transacoes com DE048 iniciado com AD
            processa_bit48_ad( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_ad( l_fields, m_pcode, m_versao_aplicativo );
        }
        else if ( ( m_bit48.substr( 0, 3 ) == "AUT" ) && ( ( m_msgtype == 100 ) && ( m_pcode == 3000 ) ) && ( 3 <= m_bit48.length( ) ) ) // Reconhecer Autorizacao IATA Descontinuada
        {
            fieldSet::fscopy( m_pdv_trn_id, "AU", 2 );
        }
        else if ( ( m_bit48.substr( 0, 3 ) == "AVS" ) && ( sizeof( AVS ) <= m_bit48.length( ) ) ) // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT056
        {
            processa_bit48_avs( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_avs( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "CO" ) && ( sizeof( CO ) <= m_bit48.length( ) ) ) // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT056
        {
            processa_bit48_co( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_co( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "CP") && (( sizeof( CP ) - 17 ) <= m_bit48.length( ) ) ) // tam min do cpo que eh variavel - Evidencia: FIS Gaps QA 04_03_2016/PDV/CT_1221
        {
            processa_bit48_cp(  m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_cp( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "NE" ) && ( sizeof( NE ) <= m_bit48.length( ) ) )// Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT056
        {
            processa_bit48_ne( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_ne( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "PA" ) && ( sizeof( PA ) <= m_bit48.length( ) ) ) // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT056
        {
            processa_bit48_pa( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_pa( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "PA" ) && ( sizeof( PAA ) <= m_bit48.length( ) ) ) // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT056
        {
            processa_bit48_paa( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_paa( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "PC" ) && ( sizeof( PC ) <= m_bit48.length( ) ) )
        {
            processa_bit48_pc( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_pc( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "PM" ) && ( ( m_msgtype == 200 ) && ( m_pcode == 2000 ) ) && ( 2 <= m_bit48.length( ) ) ) // Reconhecer Parcele Mais Descontinuada
        {
            fieldSet::fscopy( m_pdv_trn_id, "PM", 2 );
        }
        else if ( ( m_bit48.substr( 0, 1 ) == "P" ) && 
                  ( (m_bit48.length() == 1) || ( ( m_bit48.substr( 1, 1 ) == " " ) || ( m_bit48.substr( 1, 1 ) >= "0" && m_bit48.substr( 1, 1 ) <= "9" ) ) ) &&
                  ( m_msgtype == 100 ) && ( m_pcode == 3000 ) && 
                  ( ( m_versao_aplicativo < 201 && ( sizeof( PI ) - 2 - 3 <= m_bit48.length() ) ) || // Adicionado CVC2 com 3 posicoes na versao 2.01
                    ( m_versao_aplicativo < 202 && ( sizeof( PI ) - 2 <= m_bit48.length() ) ) || // Adicionadas informacoes de criptografia na versao 2.02
                    ( sizeof( PI ) <= m_bit48.length( ) ) ) )
        {
            processa_bit48_pi( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_pi( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 1 ) == "P" ) && ( m_bit48.substr( 1, 1 ) == "0" || m_bit48.substr( 1, 1 ) == "1" ) &&
                  ( m_msgtype == 220 || m_msgtype == 400 || m_msgtype == 420 ) && ( m_pcode == 3000 ) &&
                  (  m_versao_aplicativo <= 201 && sizeof( PIV ) <= m_bit48.length( ) ) ) 
        {
            processa_bit48_piv( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_piv( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 1 ) == "P" ) && ( m_bit48.substr( 1, 1 ) == "0" || m_bit48.substr( 1, 1 ) == "1" ) &&
                  ( m_msgtype == 220 ) && ( m_pcode == 3000 ) && 
                  (  m_versao_aplicativo <= 205 && sizeof( PII ) <= m_bit48.length( ) ) )
        {
            processa_bit48_pii( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_pii( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 1 ) == "P" ) && ( m_bit48.substr( 1, 1 ) == "0" || m_bit48.substr( 1, 1 ) == "1" ) &&
                  ( m_msgtype == 400 || m_msgtype == 420 ) && ( m_pcode == 3000 ) && 
                  ( ( m_versao_aplicativo < 202 && ( sizeof( PIII ) - 2 <= m_bit48.length( ) ) ) || // Adicionadas informacoes de criptografia na versao 2.02
                    ( sizeof( PIII ) <= m_bit48.length( ) ) ) )
        {
            processa_bit48_piii( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_piii( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "R1" ) && ( m_pcode != 3009 ) && ( m_pcode != 3900 ) && ( sizeof( R1 ) <= m_bit48.length( ) )  ) // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT009
        {
            processa_bit48_r1( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_r1( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "R1" ) && ( ( m_pcode == 3009 ) || ( m_pcode == 3900 ) ) && ( sizeof( R1_Iata ) <= m_bit48.length( ) ) ) // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT057
        {
            processa_bit48_r1_iata( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_r1_iata( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "R2" ) && ( m_pcode != 3009 ) && ( m_pcode != 3900 ) && ( sizeof( R2 ) <= m_bit48.length( ) ) ) // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT009
        {
            processa_bit48_r2( m_bit48, l_fields, l_prompt, m_versao_aplicativo );
            processaFieldSet_r2( l_fields, l_prompt );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "R2" ) && ( ( m_pcode == 3009 ) || ( m_pcode == 3900 ) ) && ( sizeof( R2_Iata ) <= m_bit48.length( ) ) ) // Evidencia: FIS TravasIATA 2015/TRAVAS PDV/CT057
        {
            processa_bit48_r2_iata( m_bit48, l_fields, l_prompt, m_versao_aplicativo );
            processaFieldSet_r2_iata( l_fields, l_prompt );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "TS" ) && ( sizeof( TS ) <= m_bit48.length( ) ) )
        {
            processa_bit48_ts( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_ts( l_fields );
        }
        else if  ( ( m_bit48.substr( 0, 2 ) == "VF" ) && ( sizeof( VF ) <= m_bit48.length( ) ) )// Evidencia: FIS Gaps 7.5 t719924/GAP018/CT_0213
        {
            processa_bit48_vf( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_vf( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "VO" ) &&  // Evidencia: FIS Gaps QA 04_03_2016/PDV/CT_0126
                  ( ( m_versao_aplicativo < 500 && ( sizeof( VO ) - 2 ) <= m_bit48.length( ) ) ||
                    ( sizeof( VO ) <= m_bit48.length( ) ) ) )  // Voucher versao anteriores a 5.00 tem CVC2 3 digitos
        {
            processa_bit48_vo( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_vo( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "V1" ) && ( sizeof( VI ) <= m_bit48.length( ) ) )
        {
            processa_bit48_vi( m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_vi( l_fields );
        }
        else if ( ( m_bit48.substr( 0, 2 ) == "DO") && (( sizeof( DO ) - 17 ) <= m_bit48.length( ) ) ) // tam min do cpo que eh variavel - Evidencia: FIS Gaps QA 04_03_2016/PDV/CT_1221
        {
            processa_bit48_do(  m_bit48, l_fields, m_versao_aplicativo );
            processaFieldSet_do( l_fields );
        }
        else if ( m_msgtype == 9600 )
        {
            processa_bit48_baixaOS( m_bit48 );
        }
        else if ( ( m_msgtype == 800 ) && ( m_pcode == 910000 ) )
        {
            processa_bit48_estatistica( m_bit48, m_versao_aplicativo );
        }
        else if ( ( m_msgtype == 800 ) && ( m_bit48.substr( 0, 2 ) == "IN" ) )
        {
            fieldSet::fscopy( m_pdv_trn_id, "IN", 2 );
        }
        else if ( ( m_msgtype == 200 ) && ( m_pcode == 3009 || m_pcode == 3900 ) && // Este teste tem que ficar no final porque nao ha identificador
                  ( ( m_versao_aplicativo < 201 ) && ( sizeof( NOIDI ) <= m_bit48.length( ) ) ) ) // Credito IATA (versoes anteriores a 2.01 do PDV)
        {
            processa_bit48_noidi( m_bit48, l_fields );
            processaFieldSet_noidi( l_fields );
        }
        else if ( ( m_msgtype == 200 ) && // Este teste tem que ficar depois do IATA porque nao ha identificador, e engloba todas as 0200 exceto IATA
                  ( ( m_versao_aplicativo < 201 ) && ( sizeof( NOIDII ) <= m_bit48.length( ) ) ) ) // Credito, Debito, Voucher e Private Label
        {
            processa_bit48_noidii( m_bit48, l_fields );
            processaFieldSet_noidii( l_fields );
        }
        else
        {
            l_log << "N�o foi possivel parsear DE048 msgtype[";
            l_log << m_msgtype;
            l_log << "] - pcode[";
            l_log << m_pcode;
            l_log << "]\n";
            return false;
        }
        if( m_versao_aplicativo < 500 )
        { // Nas versoes anteriores a 5.00, considerar o padrao como sendo sem criptografia, sem confirmacao positiva e sem CVV2
            fieldSet::fsextr( s_tipoCriptLegado, m_tipoCriptLegado );
            fieldSet::fsextr( s_cartCriptLegado, m_cartCriptLegado );
            fieldSet::fsextr( s_indCripto, m_indCripto );
		    fieldSet::fsextr( s_cap_positive_conf, m_cap_positive_conf );
		    fieldSet::fsextr( s_cap_data_positive_conf, m_cap_data_positive_conf );
		    fieldSet::fsextr( s_dados_coletados, m_dados_coletados );
		    fieldSet::fsextr( s_cvv2, m_cvv2 );
            if ( s_tipoCriptLegado.length() == 0 && s_cartCriptLegado.length() == 0 && s_indCripto.length() == 0 )
            {
		        fieldSet::fscopy( m_indCripto, "0N", 2 );
		        fieldSet::fscopy( m_cartCriptLegado, "N", 1 );
		        fieldSet::fscopy( m_tipoCriptLegado, "0", 1 );
            }
            if ( s_cap_positive_conf.length() == 0 )
            {
		        fieldSet::fscopy( m_cap_positive_conf, "N", 1 );
            }
            if ( s_cap_data_positive_conf.length() == 0 )
            {
		        fieldSet::fscopy( m_cap_data_positive_conf, "N", 1 );
            }
            if ( s_dados_coletados.length() == 0 )
            {
		        fieldSet::fscopy( m_dados_coletados, "N", 1 );
            }
            if ( s_cvv2.length() == 0 )
            {
		        fieldSet::fscopy( m_cvv2, "     ", 5 );
            }
        }

        return true;
    }

    void Bit48Parser::processa_bit48_ad( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    { // Todas as transacoes com DE048 iniciando com AD, exceto Credito e Credito IATA, tratadas pelas funcoes seguintes

		if( m_versao_aplicativo < 202 ) // Na versao 2.01, havia o CVC2 pois o mesmo formato era usado tambem para credito
        {
            memcpy( l_fields.ad.id ,       "AD",                            sizeof(l_fields.ad.id) );
            memset( l_fields.ad.cvv2,      ' ',                             sizeof(l_fields.ad.cvv2) );
            memcpy( l_fields.ad.cvv2,      m_bit48.substr( 2, 3 ).c_str(),  3 );
        }
		else if( m_versao_aplicativo < 205 ) // Na versao 2.02, foi retirado o CVC2 pois era so para Debito, Voucher e PL
        {
            memcpy( l_fields.ad.id ,       "AD",                            sizeof(l_fields.ad.id) );
            obtem_indCripto_ad( m_bit48, l_fields, m_versao_aplicativo );
            memcpy( l_fields.ad.id_pedido, m_bit48.substr( 4, 14 ).c_str(), sizeof(l_fields.ad.id_pedido) );
        }
        else if( m_versao_aplicativo < 500 ) // Na versao 2.05, foi incluido o CVC2 com 3 posicoes
        {
            memcpy( l_fields.ad.id ,       "AD",                            sizeof(l_fields.ad.id) );
            obtem_indCripto_ad( m_bit48, l_fields, m_versao_aplicativo );
            memset( l_fields.ad.cvv2,      ' ',                             sizeof(l_fields.ad.cvv2) );
            memcpy( l_fields.ad.cvv2,      m_bit48.substr( 4, 3 ).c_str(),  3 );
            memcpy( l_fields.ad.id_pedido, m_bit48.substr( 7, 14 ).c_str(), sizeof(l_fields.ad.id_pedido) );
        }
        else // Na versao 5.00, o CVC2 aumentou para 5 posicoes
        {
            memcpy( l_fields.ad.id ,       "AD",                            sizeof(l_fields.ad.id) );
            obtem_indCripto_ad( m_bit48, l_fields, m_versao_aplicativo );
            memcpy( l_fields.ad.cvv2,      m_bit48.substr( 4, 5 ).c_str(),  sizeof(l_fields.ad.cvv2) );
            memcpy( l_fields.ad.id_pedido, m_bit48.substr( 9, 14 ).c_str(), sizeof(l_fields.ad.id_pedido) );
        }
    }

    void Bit48Parser::processa_bit48_adii( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    { // Credito (nao IATA)
        if( m_versao_aplicativo < 202 )
        {
            memcpy( l_fields.adii.id ,           "AD",                            sizeof(l_fields.adii.id) );
            memcpy( l_fields.adii.cvv2,          m_bit48.substr( 2, 3 ).c_str(),  sizeof(l_fields.adii.cvv2) );
        }
        else
        {
            memcpy( l_fields.adii.id ,           "AD",                            sizeof(l_fields.adii.id) );
            memcpy( l_fields.adii.cvv2,          m_bit48.substr( 2, 3 ).c_str(),  sizeof(l_fields.adii.cvv2) );
            obtem_indCripto_adii( m_bit48, l_fields );
            memcpy( l_fields.adii.id_pedido,     m_bit48.substr( 7, 14 ).c_str(), sizeof(l_fields.adii.id_pedido) );
            memcpy( l_fields.adii.req_signature, m_bit48.substr( 21, 1 ).c_str(), sizeof(l_fields.adii.req_signature) );
        }
    }

    void Bit48Parser::processa_bit48_adiii( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    { // Credito IATA
        if( m_versao_aplicativo < 202 )
        {
            memcpy( l_fields.adiii.id ,           "AD",                             sizeof(l_fields.adiii.id) );
            memcpy( l_fields.adiii.cvv2,          m_bit48.substr( 2, 3 ).c_str(),   sizeof(l_fields.adiii.cvv2) );
            memcpy( l_fields.adiii.vl_txa,        m_bit48.substr( 5, 12 ).c_str(),  sizeof(l_fields.adiii.vl_txa) );
            memcpy( l_fields.adiii.vl_pca_ent,    m_bit48.substr( 17, 12 ).c_str(), sizeof(l_fields.adiii.vl_pca_ent) );
        }
        else
        {
            memcpy( l_fields.adiii.id ,           "AD",                             sizeof(l_fields.adiii.id) );
            memcpy( l_fields.adiii.cvv2,          m_bit48.substr( 2, 3 ).c_str(),   sizeof(l_fields.adiii.cvv2) );
            memcpy( l_fields.adiii.vl_txa,        m_bit48.substr( 5, 12 ).c_str(),  sizeof(l_fields.adiii.vl_txa) );
            memcpy( l_fields.adiii.vl_pca_ent,    m_bit48.substr( 17, 12 ).c_str(), sizeof(l_fields.adiii.vl_pca_ent) );
            obtem_indCripto_adiii( m_bit48, l_fields );
            memcpy( l_fields.adiii.id_pedido,     m_bit48.substr( 31, 14 ).c_str(), sizeof(l_fields.adiii.id_pedido) );
            memcpy( l_fields.adiii.req_signature, m_bit48.substr( 45, 1 ).c_str(),  sizeof(l_fields.adiii.req_signature) );
        }
    }

    void Bit48Parser::processa_bit48_avs( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        if( m_versao_aplicativo < 202 )
        {
            memcpy( l_fields.avs.id,          "AVS",                            sizeof(l_fields.avs.id) );
            memcpy( l_fields.avs.avs_cep,     m_bit48.substr( 3, 9 ).c_str(),   sizeof(l_fields.avs.avs_cep) );
            memcpy( l_fields.avs.avs_end_fat, m_bit48.substr( 12, 8 ).c_str(),  sizeof(l_fields.avs.avs_end_fat) );
            memcpy( l_fields.avs.avs_cpf,     m_bit48.substr( 21, 11 ).c_str(), sizeof(l_fields.avs.avs_cpf) );
        }
        else
        {
            memcpy( l_fields.avs.id,          "AVS",                            sizeof(l_fields.avs.id) );
            memcpy( l_fields.avs.avs_cep,     m_bit48.substr( 3, 9 ).c_str(),   sizeof(l_fields.avs.avs_cep) );
            memcpy( l_fields.avs.avs_end_fat, m_bit48.substr( 12, 8 ).c_str(),  sizeof(l_fields.avs.avs_end_fat) );
            memcpy( l_fields.avs.avs_cpf,     m_bit48.substr( 21, 11 ).c_str(), sizeof(l_fields.avs.avs_cpf) );
            obtem_indCripto_avs( m_bit48, l_fields, m_versao_aplicativo );
        }
    }

    void Bit48Parser::processa_bit48_co( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.co.id ,           "CO",                             sizeof(l_fields.co.id) );
        memcpy( l_fields.co.transactionId, m_bit48.substr( 2, 4 ).c_str(),   sizeof(l_fields.co.transactionId) );
        memcpy( l_fields.co.cvv2,          m_bit48.substr( 6, 3 ).c_str(),   sizeof(l_fields.co.cvv2) );
        obtem_indCripto_co( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.co.id_pedido,     m_bit48.substr( 11, 14 ).c_str(), sizeof(l_fields.co.id_pedido) );
        memcpy( l_fields.co.req_signature, m_bit48.substr( 25, 1 ).c_str(),  sizeof(l_fields.co.req_signature) );
    }

    void Bit48Parser::processa_bit48_cp( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        int tamanho = 0;
        
        memcpy( l_fields.cp.id , "CP", sizeof(l_fields.cp.id) );
        obtem_indCripto_cp( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.cp.cvv2,                   m_bit48.substr( 4, 5 ).c_str(),  sizeof(l_fields.cp.cvv2) );
        memcpy( l_fields.cp.id_pedido,              m_bit48.substr( 9, 14 ).c_str(), sizeof(l_fields.cp.id_pedido) );
        memcpy( l_fields.cp.cap_positive_conf,      m_bit48.substr( 23, 1 ).c_str(), sizeof(l_fields.cp.cap_positive_conf) );
        memcpy( l_fields.cp.num_prompts_cp,         m_bit48.substr( 24, 2 ).c_str(), sizeof(l_fields.cp.num_prompts_cp) );
        memcpy( l_fields.cp.cap_data_positive_conf, m_bit48.substr( 26, 1 ).c_str(), sizeof(l_fields.cp.cap_data_positive_conf) );

        if (m_bit48.substr( 26, 1 ) == "S")
        {
            tamanho = ((int)m_bit48.substr( 28, 1 )[0])/2; 
            if (tamanho > 0)
            {
                memcpy( l_fields.cp.dados_coletados, &m_bit48[27], tamanho + 2 ); //incluido o identificador 'P' e o propio tamanho 
            }
        }
    }

    void Bit48Parser::processa_bit48_do( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        int tamanho = 0;
        
        memcpy( l_fields.doff.id , "DO", sizeof(l_fields.cp.id) );
        memcpy( l_fields.doff.transactionId,          m_bit48.substr( 2, 4 ).c_str(),  sizeof(l_fields.doff.transactionId) );
        obtem_indCripto_do( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.doff.cvv2,                   m_bit48.substr( 8, 5 ).c_str(),  sizeof(l_fields.doff.cvv2) );
        memcpy( l_fields.doff.id_pedido,              m_bit48.substr( 13, 14 ).c_str(), sizeof(l_fields.doff.id_pedido) );
        memcpy( l_fields.doff.cap_positive_conf,      m_bit48.substr( 27, 1 ).c_str(), sizeof(l_fields.doff.cap_positive_conf) );
        memcpy( l_fields.doff.num_prompts_cp,         m_bit48.substr( 28, 2 ).c_str(), sizeof(l_fields.doff.num_prompts_cp) );
        memcpy( l_fields.doff.cap_data_positive_conf, m_bit48.substr( 30, 1 ).c_str(), sizeof(l_fields.doff.cap_data_positive_conf) );

        if (m_bit48.substr( 30, 1 ) == "S")
        {
            tamanho = ((int)m_bit48.substr( 32, 1 )[0])/2; 
            if (tamanho > 0)
            {
                memcpy( l_fields.doff.dados_coletados, &m_bit48[31], tamanho + 2 ); //incluido o identificador 'P' e o propio tamanho 
            }
        }
    }

    void Bit48Parser::processa_bit48_ne( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.ne.id ,           "NE",                             sizeof(l_fields.ne.id) );
        memcpy( l_fields.ne.transactionId, m_bit48.substr( 2, 4 ).c_str(),   sizeof(l_fields.ne.transactionId) );
        obtem_indCripto_ne( m_bit48, l_fields, m_versao_aplicativo );
    }

    void Bit48Parser::processa_bit48_pa( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.pa.id ,       "PA",                           sizeof(l_fields.pa.id) );
        obtem_indCripto_pa( m_bit48, l_fields, m_versao_aplicativo );
        if ( ( m_is_void != "TRUE" ) && ( m_is_reversal != "TRUE" ) )
        {
            memcpy( l_fields.pa.cvv2,      m_bit48.substr( 4, 3 ).c_str(),  sizeof(l_fields.pa.cvv2) );
            memcpy( l_fields.pa.id_pedido, m_bit48.substr( 7, 14 ).c_str(), sizeof(l_fields.pa.id_pedido) );
        }
    }

    void Bit48Parser::processa_bit48_paa( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.paa.id ,       "PA",                           sizeof(l_fields.paa.id) );
        obtem_indCripto_paa( m_bit48, l_fields, m_versao_aplicativo );
    }

    void Bit48Parser::processa_bit48_pc( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.pc.id ,           "PC",                             sizeof(l_fields.pc.id) );
        memcpy( l_fields.pc.transactionId, m_bit48.substr( 2, 4 ).c_str(),   sizeof(l_fields.pc.transactionId) );
        obtem_indCripto_pc( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.pc.cvv2,          m_bit48.substr( 8, 3 ).c_str(),   sizeof(l_fields.pc.cvv2) );
    }

    void Bit48Parser::processa_bit48_pi( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    { // Solicitacao de Preh
        if ( m_versao_aplicativo < 201 )
        {
            memcpy( l_fields.pi.id ,         "P",                            sizeof(l_fields.pi.id) );
            memset( l_fields.pi.cvv2,        ' ',                            sizeof(l_fields.pi.cvv2) );
        }
        else if ( m_versao_aplicativo < 202 )
        {
            memcpy( l_fields.pi.id ,         "P",                            sizeof(l_fields.pi.id) );
            memcpy( l_fields.pi.cvv2,        m_bit48.substr( 1, 3 ).c_str(), sizeof(l_fields.pi.cvv2) );
        }
        else
        {
            memcpy( l_fields.pi.id ,         "P",                            sizeof(l_fields.pi.id) );
            memcpy( l_fields.pi.cvv2,        m_bit48.substr( 1, 3 ).c_str(), sizeof(l_fields.pi.cvv2) );
            obtem_indCripto_pi( m_bit48, l_fields );
        }
    }

    void Bit48Parser::processa_bit48_pii( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo  )
    { // Confirmacao de Preh
        if( m_versao_aplicativo < 205 )
        {
            memcpy( l_fields.pii.id ,         "P",                             sizeof(l_fields.pii.id) );
            memcpy( l_fields.pii.dt_preaut,   m_bit48.substr( 1, 4 ).c_str(),  sizeof(l_fields.pii.dt_preaut) );
            obtem_indCripto_pii( m_bit48, l_fields );
            memcpy( l_fields.pii.id_pedido,   m_bit48.substr( 7, 14 ).c_str(), sizeof(l_fields.pii.id_pedido) );
        }
        else
        {
            memcpy( l_fields.pii.id ,         "P",                              sizeof(l_fields.pii.id) );
            memcpy( l_fields.pii.dt_preaut,   m_bit48.substr( 1, 4 ).c_str(),   sizeof(l_fields.pii.dt_preaut) );
            obtem_indCripto_pii( m_bit48, l_fields );
            memcpy( l_fields.pii.cvv2,        m_bit48.substr( 7, 3 ).c_str(),   sizeof(l_fields.pii.cvv2) );
            memcpy( l_fields.pii.id_pedido,   m_bit48.substr( 10, 14 ).c_str(), sizeof(l_fields.pii.id_pedido) );
        }
    }

    void Bit48Parser::processa_bit48_piii( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    { // Estornos e Desfazimentos de Preh e Conf. Preh
        memcpy( l_fields.piii.id ,       "P",                            sizeof(l_fields.piii.id) );
        memcpy( l_fields.piii.dt_preaut, m_bit48.substr( 1, 4 ).c_str(), sizeof(l_fields.piii.dt_preaut) );
        obtem_indCripto_piii( m_bit48, l_fields );
    }

    void Bit48Parser::processa_bit48_piv( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    { // Estornos e Desfazimentos de Preh e Conf. Preh
        memcpy( l_fields.piv.id ,       "P",                            sizeof(l_fields.piv.id) );
        memcpy( l_fields.piv.dt_preaut, m_bit48.substr( 1, 4 ).c_str(), sizeof(l_fields.piv.dt_preaut) );
    }

    void Bit48Parser::processa_bit48_r1( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.r1.id,             "R1",                            sizeof(l_fields.r1.id) );
        memcpy( l_fields.r1.cvv2,           m_bit48.substr( 2, 3 ).c_str(),  sizeof(l_fields.r1.cvv2) );
        obtem_indCripto_r1( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.r1.id_pedido,      m_bit48.substr( 7, 14 ).c_str(), sizeof(l_fields.r1.id_pedido) );
        memcpy( l_fields.r1.req_signature,  m_bit48.substr( 21, 1 ).c_str(), sizeof(l_fields.r1.req_signature) );
        memcpy( l_fields.r1.cap_referal,    m_bit48.substr( 22, 1 ).c_str(), sizeof(l_fields.r1.cap_referal) );
        memcpy( l_fields.r1.num_prompts_rf, m_bit48.substr( 23, 2 ).c_str(), sizeof(l_fields.r1.num_prompts_rf) );
    }

    void Bit48Parser::processa_bit48_r1_iata( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.r1_iata.id,             "R1",                             sizeof(l_fields.r1_iata.id) );
        memcpy( l_fields.r1_iata.cvv2,           m_bit48.substr( 2, 3 ).c_str(),   sizeof(l_fields.r1_iata.cvv2) );
        memcpy( l_fields.r1_iata.vl_txa,         m_bit48.substr( 5, 12 ).c_str(),  sizeof(l_fields.r1_iata.vl_txa) );
        memcpy( l_fields.r1_iata.vl_pca_ent,     m_bit48.substr( 17, 12 ).c_str(), sizeof(l_fields.r1_iata.vl_pca_ent) );
        obtem_indCripto_r1_iata( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.r1_iata.id_pedido,      m_bit48.substr( 31, 14 ).c_str(), sizeof(l_fields.r1_iata.id_pedido) );
        memcpy( l_fields.r1_iata.req_signature,  m_bit48.substr( 45, 1 ).c_str(),  sizeof(l_fields.r1_iata.req_signature) );
        memcpy( l_fields.r1_iata.cap_referal,    m_bit48.substr( 46, 1 ).c_str(),  sizeof(l_fields.r1_iata.cap_referal) );
        memcpy( l_fields.r1_iata.num_prompts_rf, m_bit48.substr( 47, 2 ).c_str(),  sizeof(l_fields.r1_iata.num_prompts_rf) );
    }

    void Bit48Parser::processa_bit48_r2( const std::string &m_bit48, Bit48 &l_fields, std::vector<Prompt> l_prompt, int m_versao_aplicativo )
    {
        memcpy( l_fields.r2.id,             "R2",                            sizeof(l_fields.r2.id) );
        memcpy( l_fields.r2.cvv2,           m_bit48.substr( 2, 3 ).c_str(),  sizeof(l_fields.r2.cvv2) );
        obtem_indCripto_r2( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.r2.id_pedido,      m_bit48.substr( 7, 14 ).c_str(), sizeof(l_fields.r2.id_pedido) );
        memcpy( l_fields.r2.req_signature,  m_bit48.substr( 21, 1 ).c_str(), sizeof(l_fields.r2.req_signature) );
        memcpy( l_fields.r2.id_prompt,      m_bit48.substr( 22, 4 ).c_str(), sizeof(l_fields.r2.id_prompt) );
        memcpy( l_fields.r2.size_prompt,    m_bit48.substr( 26, 4 ).c_str(), sizeof(l_fields.r2.size_prompt) );
        memcpy( l_fields.r2.qtd_prompt,     m_bit48.substr( 30, 4 ).c_str(), sizeof(l_fields.r2.qtd_prompt) );
        processa_prompt( m_bit48.substr( 34 ), l_prompt );
    }

    void Bit48Parser::processa_bit48_r2_iata( const std::string &m_bit48, Bit48 &l_fields, std::vector<Prompt> l_prompt, int m_versao_aplicativo )
    {
        memcpy( l_fields.r2_iata.id,             "R2",                             sizeof(l_fields.r2_iata.id) );
        memcpy( l_fields.r2_iata.cvv2,           m_bit48.substr( 2, 3 ).c_str(),   sizeof(l_fields.r2_iata.cvv2) );
        memcpy( l_fields.r2_iata.vl_txa,         m_bit48.substr( 5, 12 ).c_str(),  sizeof(l_fields.r2_iata.vl_txa) );
        memcpy( l_fields.r2_iata.vl_pca_ent,     m_bit48.substr( 17, 12 ).c_str(), sizeof(l_fields.r2_iata.vl_pca_ent) );
        obtem_indCripto_r2_iata( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.r2_iata.id_pedido,      m_bit48.substr( 31, 14 ).c_str(), sizeof(l_fields.r2_iata.id_pedido) );
        memcpy( l_fields.r2_iata.req_signature,  m_bit48.substr( 45, 1 ).c_str(),  sizeof(l_fields.r2_iata.req_signature) );
        memcpy( l_fields.r2_iata.id_prompt,      m_bit48.substr( 46, 4 ).c_str(), sizeof(l_fields.r2_iata.id_prompt) );
        memcpy( l_fields.r2_iata.size_prompt,    m_bit48.substr( 50, 4 ).c_str(), sizeof(l_fields.r2_iata.size_prompt) );
        memcpy( l_fields.r2_iata.qtd_prompt,     m_bit48.substr( 54, 4 ).c_str(), sizeof(l_fields.r2_iata.qtd_prompt) );
        processa_prompt( m_bit48.substr( 58 ), l_prompt );
    }

    void Bit48Parser::processa_bit48_ts( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.ts.id ,           "TS",                             sizeof(l_fields.ts.id) );
        memcpy( l_fields.ts.transactionId, m_bit48.substr( 2, 4 ).c_str(),   sizeof(l_fields.ts.transactionId) );
        obtem_indCripto_ts( m_bit48, l_fields, m_versao_aplicativo );
    }

    void Bit48Parser::processa_bit48_vf( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.vf.id ,             "VF", sizeof(l_fields.cp.id) );
        obtem_indCripto_vf( m_bit48, l_fields, m_versao_aplicativo );
        memcpy( l_fields.vf.cvv2,            m_bit48.substr( 4, 5 ).c_str(),   sizeof(l_fields.vf.cvv2) );
        memcpy( l_fields.vf.id_pedido,       m_bit48.substr( 9, 14 ).c_str(),  sizeof(l_fields.vf.id_pedido) );
        memcpy( l_fields.vf.saldo_parcial,   m_bit48.substr( 23, 1 ).c_str(),  sizeof(l_fields.vf.saldo_parcial) );
        memcpy( l_fields.vf.cod_veiculo,     m_bit48.substr( 24, 8 ).c_str(),  sizeof(l_fields.vf.cod_veiculo ) );
        memcpy( l_fields.vf.cod_condutor,    m_bit48.substr( 32, 8 ).c_str(),  sizeof(l_fields.vf.cod_condutor ) );
        memcpy( l_fields.vf.tipo_servico,    m_bit48.substr( 40, 2 ).c_str(),  sizeof(l_fields.vf.tipo_servico ) );
        memcpy( l_fields.vf.cod_combustivel, m_bit48.substr( 42, 2 ).c_str(),  sizeof(l_fields.vf.cod_combustivel ) );
        memcpy( l_fields.vf.litragem,        m_bit48.substr( 44, 7 ).c_str(),  sizeof(l_fields.vf.litragem ) );
        memcpy( l_fields.vf.quilometragem,   m_bit48.substr( 51, 10 ).c_str(), sizeof(l_fields.vf.quilometragem ) );
    }

    void Bit48Parser::processa_bit48_vi( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        memcpy( l_fields.vi.id ,           "V1",                             sizeof(l_fields.vi.id) );
        memcpy( l_fields.vi.transactionId, m_bit48.substr( 2, 4 ).c_str(),   sizeof(l_fields.vi.transactionId) );
        obtem_indCripto_vi( m_bit48, l_fields, m_versao_aplicativo );
    }

    void Bit48Parser::processa_bit48_vo( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_fields.vo.id ,           "VO",                            sizeof(l_fields.cp.id) );
            obtem_indCripto_vo( m_bit48, l_fields, m_versao_aplicativo );
            memset( l_fields.vo.cvv2,          ' ',                             sizeof(l_fields.vo.cvv2) );
            memcpy( l_fields.vo.cvv2,          m_bit48.substr( 4, 3 ).c_str(),  3 );
            memcpy( l_fields.vo.id_pedido,     m_bit48.substr( 7, 14 ).c_str(), sizeof(l_fields.vo.id_pedido) );
            memcpy( l_fields.vo.saldo_parcial, m_bit48.substr( 21, 1 ).c_str(), sizeof(l_fields.vo.saldo_parcial) );
        }
        else
        {
            memcpy( l_fields.vo.id ,           "VO",                            sizeof(l_fields.cp.id) );
            obtem_indCripto_vo( m_bit48, l_fields, m_versao_aplicativo );
            memcpy( l_fields.vo.cvv2,          m_bit48.substr( 4, 5 ).c_str(),  sizeof(l_fields.vo.cvv2) );
            memcpy( l_fields.vo.id_pedido,     m_bit48.substr( 9, 14 ).c_str(), sizeof(l_fields.vo.id_pedido) );
            memcpy( l_fields.vo.saldo_parcial, m_bit48.substr( 23, 1 ).c_str(), sizeof(l_fields.vo.saldo_parcial) );
        }
    }

    void Bit48Parser::processa_bit48_baixaOS( const std::string &m_bit48 )
    {
        fieldSet::fscopy( m_bit63, processa_tag( m_bit48, "080" ) );
    }

    void Bit48Parser::processa_bit48_estatistica( const std::string &m_bit48, int m_versao_aplicativo )
    {
        if( m_versao_aplicativo < 401 )
        {
            fieldSet::fscopy( m_indCripto, "0N", 2 );
        }
        else
        {
            fieldSet::fscopy( m_indCripto, "0N", 2 );
            fieldSet::fscopy( m_statistics, processa_tag( m_bit48, "084" ) );
        }
    }

    void Bit48Parser::processa_bit48_noidi( const std::string &m_bit48, Bit48 &l_fields )
    {
        memcpy( l_fields.noidi.vl_txa,     m_bit48.substr( 0, 12 ).c_str(),   sizeof(l_fields.noidi.vl_txa) );
        memcpy( l_fields.noidi.vl_pca_ent, m_bit48.substr( 12, 12 ).c_str(),  sizeof(l_fields.noidi.vl_pca_ent) );
    }

    void Bit48Parser::processa_bit48_noidii( const std::string &m_bit48, Bit48 &l_fields )
    {
        memcpy( l_fields.noidii.vl_txa,    m_bit48.substr( 0, 12 ).c_str(),   sizeof(l_fields.noidii.vl_txa) );
    }

    void Bit48Parser::processa_prompt( const std::string &m_bit48, std::vector<Prompt> l_prompt )
    {
        int l_pos;
        
        l_pos = 0;
        while ( l_pos < m_bit48.length( ) )
        {
            insere_prompt( m_bit48.substr( l_pos ), l_prompt );
            l_pos += sizeof( Prompt );
        }
    }
    
    void Bit48Parser::insere_prompt( const std::string &m_bit48, std::vector<Prompt> l_prompt )
    {
        Prompt prompt;
        
        memcpy( prompt.id,   m_bit48.substr( 0, sizeof(prompt.id) ).c_str(),                                         sizeof(prompt.id) );
        memcpy( prompt.size, m_bit48.substr( sizeof(prompt.id), sizeof(prompt.size) ).c_str(),                       sizeof(prompt.size) );
        memcpy( prompt.data, m_bit48.substr( sizeof(prompt.id) + sizeof(prompt.size), sizeof(prompt.data) ).c_str(), sizeof(prompt.data) );
        l_prompt.push_back( prompt );
    }
    
    std::string Bit48Parser::processa_tag( const std::string &m_bit48, const std::string &m_tag )
    {
        std::string tag;
        int ptr;
        int len;

        ptr = 0;
        while ( ptr < m_bit48.length( ) )
        {
            tag = m_bit48.substr( ptr, 3 );
            ptr += 3;
            len = atoi( m_bit48.substr( ptr, 3 ).c_str( ) );
            ptr += 3;
            if ( tag == m_tag )
            {
                return( m_bit48.substr( ptr, len ) );
            }
            ptr += len;
        }
        return( "" );
    }

    void Bit48Parser::obtem_indCripto_ad( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 2, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 3, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.ad.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.ad.indCripto, m_bit48.substr( 2, 2 ).c_str(), sizeof(l_fields.ad.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_adii( const std::string &m_bit48, Bit48 &l_fields )
    {
        CriptLegado l_legado;

        memcpy( l_legado.tipo, m_bit48.substr( 5, 1 ).c_str(), 1 );
        memcpy( l_legado.cart, m_bit48.substr( 6, 1 ).c_str(), 1 );
        monta_indCripto( l_legado, (unsigned char *)&l_fields.adii.indCripto );
    }

    void Bit48Parser::obtem_indCripto_adiii( const std::string &m_bit48, Bit48 &l_fields )
    {
        CriptLegado l_legado;

        memcpy( l_legado.tipo, m_bit48.substr( 29, 1 ).c_str(), 1 );
        memcpy( l_legado.cart, m_bit48.substr( 30, 1 ).c_str(), 1 );
        monta_indCripto( l_legado, (unsigned char *)&l_fields.adiii.indCripto );
    }

    void Bit48Parser::obtem_indCripto_avs( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 32, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 33, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.avs.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.avs.indCripto, m_bit48.substr( 32, 2 ).c_str(), sizeof(l_fields.avs.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_co( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 9, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 10, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.co.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.co.indCripto, m_bit48.substr( 9, 2 ).c_str(), sizeof(l_fields.co.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_cp( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 2, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 3, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.cp.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            if ( m_bit48.substr( 2, 1 ) == "0")
				memcpy( l_fields.cp.indCripto , "0N" , sizeof(l_fields.cp.indCripto) );
            else
            if( m_bit48.substr( 2, 1 ) >= "1" && m_bit48.substr( 2, 1 ) <= "9" )
            {
                std::string aux;
                aux = "S" + m_bit48.substr( 2, 1 );
				memcpy( l_fields.cp.indCripto , aux.c_str( ) , sizeof(l_fields.cp.indCripto) );
            }
            else
                memcpy( l_fields.cp.indCripto, m_bit48.substr( 2, 2 ).c_str(), sizeof(l_fields.cp.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_do( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 6, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 7, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.doff.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            if ( m_bit48.substr( 6, 1 ) == "0")
				memcpy( l_fields.doff.indCripto , "0N" , sizeof(l_fields.doff.indCripto) );
            else
            if( m_bit48.substr( 6, 1 ) >= "1" && m_bit48.substr( 6, 1 ) <= "9" )
            {
                std::string aux;
                aux = "S" + m_bit48.substr( 6, 1 );
				memcpy( l_fields.doff.indCripto , aux.c_str( ) , sizeof(l_fields.doff.indCripto) );
            }
            else
                memcpy( l_fields.doff.indCripto, m_bit48.substr( 6, 2 ).c_str(), sizeof(l_fields.doff.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_ne( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 6, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 7, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.ne.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.ne.indCripto, m_bit48.substr( 6, 2 ).c_str(), sizeof(l_fields.ne.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_pa( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 2, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 3, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.pa.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.pa.indCripto, m_bit48.substr( 2, 2 ).c_str(), sizeof(l_fields.pa.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_paa( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 2, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 3, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.paa.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.paa.indCripto, m_bit48.substr( 2, 2 ).c_str(),  sizeof(l_fields.paa.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_pi( const std::string &m_bit48, Bit48 &l_fields )
    {
        CriptLegado l_legado;

        memcpy( l_legado.tipo, m_bit48.substr( 4, 1 ).c_str(), 1 );
        memcpy( l_legado.cart, m_bit48.substr( 5, 1 ).c_str(), 1 );
        monta_indCripto( l_legado, (unsigned char *)&l_fields.pi.indCripto );
    }

    void Bit48Parser::obtem_indCripto_pii( const std::string &m_bit48, Bit48 &l_fields )
    {
        CriptLegado l_legado;

        memcpy( l_legado.tipo, m_bit48.substr( 5, 1 ).c_str(), 1 );
        memcpy( l_legado.cart, m_bit48.substr( 6, 1 ).c_str(), 1 );
        monta_indCripto( l_legado, (unsigned char *)&l_fields.pii.indCripto );
    }

    void Bit48Parser::obtem_indCripto_piii( const std::string &m_bit48, Bit48 &l_fields )
    {
        CriptLegado l_legado;

        memcpy( l_legado.tipo, m_bit48.substr( 5, 1 ).c_str(), 1 );
        memcpy( l_legado.cart, m_bit48.substr( 6, 1 ).c_str(), 1 );
        monta_indCripto( l_legado, (unsigned char *)&l_fields.piii.indCripto );
    }

    void Bit48Parser::obtem_indCripto_pc( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 6, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 7, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.pc.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.pc.indCripto, m_bit48.substr( 6, 2 ).c_str(), sizeof(l_fields.pc.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_r1( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 5, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 6, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.r1.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.r1.indCripto, m_bit48.substr( 5, 2 ).c_str(), sizeof(l_fields.r1.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_r1_iata( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 29, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 30, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.r1_iata.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.r1_iata.indCripto, m_bit48.substr( 29, 2 ).c_str(), sizeof(l_fields.r1_iata.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_r2( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 5, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 6, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.r2.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.r2.indCripto, m_bit48.substr( 5, 2 ).c_str(), sizeof(l_fields.r2.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_r2_iata( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 29, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 30, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.r2_iata.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.r2_iata.indCripto, m_bit48.substr( 29, 2 ).c_str(), sizeof(l_fields.r2_iata.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_ts( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 6, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 7, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.ts.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.ts.indCripto, m_bit48.substr( 6, 2 ).c_str(), sizeof(l_fields.ts.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_vf( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 2, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 3, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.vf.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.vf.indCripto, m_bit48.substr( 2, 2 ).c_str(), sizeof(l_fields.vf.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_vi( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 6, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 7, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.vi.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.vi.indCripto, m_bit48.substr( 6, 2 ).c_str(), sizeof(l_fields.vi.indCripto) );
        }
    }

    void Bit48Parser::obtem_indCripto_vo( const std::string &m_bit48, Bit48 &l_fields, int m_versao_aplicativo )
    {
        CriptLegado l_legado;

        if( m_versao_aplicativo < 500 )
        {
            memcpy( l_legado.tipo, m_bit48.substr( 2, 1 ).c_str(), 1 );
            memcpy( l_legado.cart, m_bit48.substr( 3, 1 ).c_str(), 1 );
            monta_indCripto( l_legado, (unsigned char *)&l_fields.vo.indCripto );
        }
        else
        {
            fieldSet::fscopy( m_tipoCriptLegado, "", 1 );
            fieldSet::fscopy( m_cartCriptLegado, "", 1 );
            memcpy( l_fields.vo.indCripto, m_bit48.substr( 2, 2 ).c_str(), sizeof(l_fields.vo.indCripto) );
        }
    }

    void Bit48Parser::monta_indCripto( CriptLegado &l_legado, unsigned char *indCripto )
    {
        std::string stipo;
        std::string scart;

        stipo.assign ( l_legado.tipo, 1 );
        scart.assign ( l_legado.cart, 1 );

		fieldSet::fscopy( m_tipoCriptLegado, l_legado.tipo, 1 );
		fieldSet::fscopy( m_cartCriptLegado, l_legado.cart, 1 );

        if ( stipo == "0" )
            memcpy( indCripto, "0N" , 2 );
        else
        if ( stipo == "1" && scart == "S" )
            memcpy( indCripto, "S7" , 2 );
        else
        if ( stipo == "2" && scart == "S" )
            memcpy( indCripto, "S3" , 2 );
        else
        if ( stipo == "1" && scart == "N" )
            memcpy( indCripto, "S1" , 2 );
        else
        if ( stipo == "2" && scart == "N" )
            memcpy( indCripto, "S2" , 2 );
        else
            memset( indCripto, '\0', 2 );
    }

    void Bit48Parser::processaFieldSet_ad( Bit48 &l_fields, const long &m_pcode, int m_versao_aplicativo )
    {
        if ( m_pcode == 183000 && m_versao_aplicativo < 401 )
            fieldSet::fscopy( m_saldo_parcial, "N", 1 );
        fieldSet::fscopy( m_cvv2,       l_fields.ad.cvv2,      sizeof( l_fields.ad.cvv2 ) );
        fieldSet::fscopy( m_indCripto,  l_fields.ad.indCripto, sizeof( l_fields.ad.indCripto ) );
        fieldSet::fscopy( m_id_pedido,  l_fields.ad.id_pedido, sizeof( l_fields.ad.id_pedido ) );
        fieldSet::fscopy( m_pdv_trn_id, l_fields.ad.id,        sizeof( l_fields.ad.id ) );
    }
    
    void Bit48Parser::processaFieldSet_adii( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,       l_fields.adii.cvv2,      sizeof( l_fields.adii.cvv2 ) );
        fieldSet::fscopy( m_indCripto,  l_fields.adii.indCripto, sizeof( l_fields.adii.indCripto ) );
        fieldSet::fscopy( m_id_pedido,  l_fields.adii.id_pedido, sizeof( l_fields.adii.id_pedido ) );
        fieldSet::fscopy( m_pdv_trn_id, l_fields.adii.id,        sizeof( l_fields.adii.id ) );
    }

    void Bit48Parser::processaFieldSet_adiii( Bit48 &l_fields )
    {
        std::string saux;
        char sbuf[16];
        long laux;

        fieldSet::fscopy( m_cvv2,       l_fields.adiii.cvv2,       sizeof( l_fields.adiii.cvv2 ) );
        saux.assign ( l_fields.adiii.vl_txa, sizeof( l_fields.adiii.vl_txa ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_txa, sbuf );
        saux.assign ( l_fields.adiii.vl_pca_ent, sizeof( l_fields.adiii.vl_pca_ent ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_pca_ent, sbuf );
        fieldSet::fscopy( m_indCripto,  l_fields.adiii.indCripto,  sizeof( l_fields.adiii.indCripto ) );
        fieldSet::fscopy( m_id_pedido,  l_fields.adiii.id_pedido,  sizeof( l_fields.adiii.id_pedido ) );
        fieldSet::fscopy( m_pdv_trn_id, l_fields.adiii.id,         sizeof( l_fields.adiii.id ) );
    }

    void Bit48Parser::processaFieldSet_avs( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_avs_cep,     l_fields.avs.avs_cep,     sizeof( l_fields.avs.avs_cep ) );
        fieldSet::fscopy( m_avs_end_fat, l_fields.avs.avs_end_fat, sizeof( l_fields.avs.avs_end_fat ) );
        fieldSet::fscopy( m_avs_cpf,     l_fields.avs.avs_cpf,     sizeof( l_fields.avs.avs_cpf ) );
        fieldSet::fscopy( m_indCripto,   l_fields.avs.indCripto,   sizeof( l_fields.avs.indCripto ) );
        fieldSet::fscopy( m_pdv_trn_id,  l_fields.avs.id,          sizeof( l_fields.avs.id ) - 1 );
    }
    
    void Bit48Parser::processaFieldSet_co( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,          l_fields.co.cvv2,          sizeof( l_fields.co.cvv2 ) );
        fieldSet::fscopy( m_indCripto,     l_fields.co.indCripto,     sizeof( l_fields.co.indCripto ) );
        fieldSet::fscopy( m_id_pedido,     l_fields.co.id_pedido,     sizeof( l_fields.co.id_pedido ) );
        fieldSet::fscopy( m_transactionId, l_fields.co.transactionId, sizeof( l_fields.co.transactionId ) );
        fieldSet::fscopy( m_req_signature, l_fields.co.req_signature, sizeof( l_fields.co.req_signature ) );
        fieldSet::fscopy( m_pdv_trn_id,    l_fields.co.id,            sizeof( l_fields.co.id ) );
    }
    
    void Bit48Parser::processaFieldSet_cp( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,                   l_fields.cp.cvv2,              sizeof( l_fields.cp.cvv2 ) );
        fieldSet::fscopy( m_indCripto,              l_fields.cp.indCripto,         sizeof( l_fields.cp.indCripto ) );
        fieldSet::fscopy( m_id_pedido,              l_fields.cp.id_pedido,         sizeof( l_fields.cp.id_pedido ) );
        fieldSet::fscopy( m_cap_positive_conf,      l_fields.cp.cap_positive_conf, sizeof( l_fields.cp.cap_positive_conf ) );
        fieldSet::fscopy( m_num_prompts_cp,         l_fields.cp.num_prompts_cp,    sizeof( l_fields.cp.num_prompts_cp) );
        fieldSet::fscopy( m_cap_data_positive_conf, l_fields.cp.cap_data_positive_conf, sizeof( l_fields.cp.cap_data_positive_conf ) );
        fieldSet::fscopy( m_dados_coletados,        l_fields.cp.dados_coletados,   sizeof( l_fields.cp.dados_coletados ) );
        fieldSet::fscopy( m_pdv_trn_id,             l_fields.cp.id,                sizeof( l_fields.cp.id ) );
    }
    
    void Bit48Parser::processaFieldSet_do( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,                   l_fields.doff.cvv2,              sizeof( l_fields.doff.cvv2 ) );
        fieldSet::fscopy( m_indCripto,              l_fields.doff.indCripto,         sizeof( l_fields.doff.indCripto ) );
        fieldSet::fscopy( m_transactionId,          l_fields.doff.transactionId,     sizeof( l_fields.doff.transactionId ) );
        fieldSet::fscopy( m_id_pedido,              l_fields.doff.id_pedido,         sizeof( l_fields.doff.id_pedido ) );
        fieldSet::fscopy( m_cap_positive_conf,      l_fields.doff.cap_positive_conf, sizeof( l_fields.doff.cap_positive_conf ) );
        fieldSet::fscopy( m_num_prompts_cp,         l_fields.doff.num_prompts_cp,    sizeof( l_fields.doff.num_prompts_cp) );
        fieldSet::fscopy( m_cap_data_positive_conf, l_fields.doff.cap_data_positive_conf, sizeof( l_fields.doff.cap_data_positive_conf ) );
        fieldSet::fscopy( m_dados_coletados,        l_fields.doff.dados_coletados,   sizeof( l_fields.doff.dados_coletados ) );
        fieldSet::fscopy( m_pdv_trn_id,             l_fields.doff.id,                sizeof( l_fields.doff.id ) );
    }
    
    void Bit48Parser::processaFieldSet_ne( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_indCripto,     l_fields.ne.indCripto,     sizeof( l_fields.ne.indCripto ) );
        fieldSet::fscopy( m_transactionId, l_fields.ne.transactionId, sizeof( l_fields.ne.transactionId ) );
        fieldSet::fscopy( m_pdv_trn_id,    l_fields.ne.id,            sizeof( l_fields.ne.id ) );
    }
    
    void Bit48Parser::processaFieldSet_pa( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_indCripto,  l_fields.pa.indCripto, sizeof( l_fields.pa.indCripto ) );
        fieldSet::fscopy( m_pdv_trn_id, l_fields.pa.id,        sizeof( l_fields.pa.id ) );
        if ( ( m_is_void != "TRUE" ) && ( m_is_reversal != "TRUE" ) )
        {
            fieldSet::fscopy( m_cvv2,      l_fields.pa.cvv2,      sizeof( l_fields.pa.cvv2 ) );
            fieldSet::fscopy( m_id_pedido, l_fields.pa.id_pedido, sizeof( l_fields.pa.id_pedido ) );
        }
    }
    
    void Bit48Parser::processaFieldSet_paa( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_indCripto,  l_fields.paa.indCripto, sizeof( l_fields.paa.indCripto ) );
        fieldSet::fscopy( m_pdv_trn_id, l_fields.paa.id,        sizeof( l_fields.paa.id ) );
    }
    
    void Bit48Parser::processaFieldSet_pi( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,       l_fields.pi.cvv2,        sizeof( l_fields.pi.cvv2 ) );
        fieldSet::fscopy( m_indCripto,  l_fields.pi.indCripto,   sizeof( l_fields.pi.indCripto ) );
        fieldSet::fscopy( m_pdv_trn_id, l_fields.pi.id,          sizeof( l_fields.pi.id ) );
    }

    void Bit48Parser::processaFieldSet_pii( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_indCripto,  l_fields.pii.indCripto,   sizeof( l_fields.pii.indCripto ) );
        fieldSet::fscopy( m_cvv2,       l_fields.pii.cvv2,        sizeof( l_fields.pii.cvv2 ) );
        fieldSet::fscopy( m_id_pedido,  l_fields.pii.id_pedido,   sizeof( l_fields.pii.id_pedido ) );
        fieldSet::fscopy( m_pdv_trn_id, l_fields.pii.id,          sizeof( l_fields.pii.id ) );
    }

    void Bit48Parser::processaFieldSet_piii( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_indCripto,  l_fields.piii.indCripto,   sizeof( l_fields.piii.indCripto ) );
        fieldSet::fscopy( m_pdv_trn_id, l_fields.piii.id,          sizeof( l_fields.piii.id ) );
    }

    void Bit48Parser::processaFieldSet_piv( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_pdv_trn_id, l_fields.piv.id,          sizeof( l_fields.piv.id ) );
    }

    void Bit48Parser::processaFieldSet_pc( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,          l_fields.pc.cvv2,          sizeof( l_fields.pc.cvv2 ) );
        fieldSet::fscopy( m_indCripto,     l_fields.pc.indCripto,     sizeof( l_fields.pc.indCripto ) );
        fieldSet::fscopy( m_transactionId, l_fields.pc.transactionId, sizeof( l_fields.pc.transactionId ) );
        fieldSet::fscopy( m_pdv_trn_id,    l_fields.pc.id,            sizeof( l_fields.pc.id ) );
    }
    
    void Bit48Parser::processaFieldSet_r1( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,           l_fields.r1.cvv2,           sizeof( l_fields.r1.cvv2 ) );
        fieldSet::fscopy( m_indCripto,      l_fields.r1.indCripto,      sizeof( l_fields.r1.indCripto ) );
        fieldSet::fscopy( m_id_pedido,      l_fields.r1.id_pedido,      sizeof( l_fields.r1.id_pedido ) );
        fieldSet::fscopy( m_req_signature,  l_fields.r1.req_signature,  sizeof( l_fields.r1.req_signature ) );
        fieldSet::fscopy( m_cap_referal,    l_fields.r1.cap_referal,    sizeof( l_fields.r1.cap_referal) );
        fieldSet::fscopy( m_num_prompts_rf, l_fields.r1.num_prompts_rf, sizeof( l_fields.r1.num_prompts_rf ) );
        fieldSet::fscopy( m_pdv_trn_id,     l_fields.r1.id,             sizeof( l_fields.r1.id ) );
    }
    
    void Bit48Parser::processaFieldSet_r1_iata( Bit48 &l_fields )
    {
        std::string saux;
        char sbuf[16];
        long laux;

        fieldSet::fscopy( m_cvv2,           l_fields.r1_iata.cvv2,           sizeof( l_fields.r1_iata.cvv2 ) );
        fieldSet::fscopy( m_indCripto,      l_fields.r1_iata.indCripto,      sizeof( l_fields.r1_iata.indCripto ) );
        fieldSet::fscopy( m_id_pedido,      l_fields.r1_iata.id_pedido,      sizeof( l_fields.r1_iata.id_pedido ) );
        fieldSet::fscopy( m_req_signature,  l_fields.r1_iata.req_signature,  sizeof( l_fields.r1_iata.req_signature ) );
        fieldSet::fscopy( m_cap_referal,    l_fields.r1_iata.cap_referal,    sizeof( l_fields.r1_iata.cap_referal) );
        fieldSet::fscopy( m_num_prompts_rf, l_fields.r1_iata.num_prompts_rf, sizeof( l_fields.r1_iata.num_prompts_rf ) );
        fieldSet::fscopy( m_pdv_trn_id,     l_fields.r1_iata.id,             sizeof( l_fields.r1_iata.id ) );
        saux.assign ( l_fields.r1_iata.vl_txa, sizeof( l_fields.r1_iata.vl_txa ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_txa, sbuf );
        saux.assign ( l_fields.r1_iata.vl_pca_ent, sizeof( l_fields.r1_iata.vl_pca_ent ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_pca_ent, sbuf );
    }
    
    void Bit48Parser::processaFieldSet_r2( Bit48 &l_fields, std::vector<Prompt> l_prompt )
    {
        fieldSet::fscopy( m_cvv2,           l_fields.r2.cvv2,           sizeof( l_fields.r2.cvv2 ) );
        fieldSet::fscopy( m_indCripto,      l_fields.r2.indCripto,      sizeof( l_fields.r2.indCripto ) );
        fieldSet::fscopy( m_id_pedido,      l_fields.r2.id_pedido,      sizeof( l_fields.r2.id_pedido ) );
        fieldSet::fscopy( m_req_signature,  l_fields.r2.req_signature,  sizeof( l_fields.r2.req_signature ) );
        fieldSet::fscopy( m_pdv_trn_id,     l_fields.r2.id,             sizeof( l_fields.r2.id ) );
    }
    
    void Bit48Parser::processaFieldSet_r2_iata( Bit48 &l_fields, std::vector<Prompt> l_prompt )
    {
        std::string saux;
        char sbuf[16];
        long laux;

        fieldSet::fscopy( m_cvv2,           l_fields.r2_iata.cvv2,           sizeof( l_fields.r2_iata.cvv2 ) );
        fieldSet::fscopy( m_indCripto,      l_fields.r2_iata.indCripto,      sizeof( l_fields.r2_iata.indCripto ) );
        fieldSet::fscopy( m_id_pedido,      l_fields.r2_iata.id_pedido,      sizeof( l_fields.r2_iata.id_pedido ) );
        fieldSet::fscopy( m_req_signature,  l_fields.r2_iata.req_signature,  sizeof( l_fields.r2_iata.req_signature ) );
        fieldSet::fscopy( m_pdv_trn_id,     l_fields.r2_iata.id,             sizeof( l_fields.r2_iata.id ) );
        saux.assign ( l_fields.r2_iata.vl_txa, sizeof( l_fields.r1_iata.vl_txa ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_txa, sbuf );
        saux.assign ( l_fields.r2_iata.vl_pca_ent, sizeof( l_fields.r1_iata.vl_pca_ent ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_pca_ent, sbuf );
    }
    
    void Bit48Parser::processaFieldSet_ts( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_indCripto,     l_fields.ts.indCripto,     sizeof( l_fields.ts.indCripto ) );
        fieldSet::fscopy( m_transactionId, l_fields.ts.transactionId, sizeof( l_fields.ts.transactionId ) );
        fieldSet::fscopy( m_pdv_trn_id,    l_fields.ts.id,            sizeof( l_fields.ts.id ) );
    }
    
    void Bit48Parser::processaFieldSet_vf( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,            l_fields.vf.cvv2,            sizeof( l_fields.vf.cvv2 ) );
        fieldSet::fscopy( m_indCripto,       l_fields.vf.indCripto,       sizeof( l_fields.vf.indCripto ) );
        fieldSet::fscopy( m_id_pedido,       l_fields.vf.id_pedido,       sizeof( l_fields.vf.id_pedido ) );
        fieldSet::fscopy( m_saldo_parcial,   l_fields.vf.saldo_parcial,   sizeof( l_fields.vf.saldo_parcial ) );
        fieldSet::fscopy( m_cod_veiculo,     l_fields.vf.cod_veiculo,     sizeof( l_fields.vf.cod_veiculo ) );
        fieldSet::fscopy( m_cod_condutor,    l_fields.vf.cod_condutor,    sizeof( l_fields.vf.cod_condutor ) );
        fieldSet::fscopy( m_tipo_servico,    l_fields.vf.tipo_servico,    sizeof( l_fields.vf.tipo_servico ) );
        fieldSet::fscopy( m_cod_combustivel, l_fields.vf.cod_combustivel, sizeof( l_fields.vf.cod_combustivel ) );
        fieldSet::fscopy( m_litragem,        l_fields.vf.litragem,        sizeof( l_fields.vf.litragem ) );
        fieldSet::fscopy( m_quilometragem,   l_fields.vf.quilometragem,   sizeof( l_fields.vf.quilometragem ) );
        fieldSet::fscopy( m_pdv_trn_id,      l_fields.vf.id,              sizeof( l_fields.vf.id ) );
    }
    
    void Bit48Parser::processaFieldSet_vi( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_indCripto,     l_fields.vi.indCripto,     sizeof( l_fields.vi.indCripto ) );
        fieldSet::fscopy( m_transactionId, l_fields.vi.transactionId, sizeof( l_fields.vi.transactionId ) );
        fieldSet::fscopy( m_pdv_trn_id,    l_fields.vi.id,            sizeof( l_fields.vi.id ) );
    }
    
    void Bit48Parser::processaFieldSet_vo( Bit48 &l_fields )
    {
        fieldSet::fscopy( m_cvv2,          l_fields.vo.cvv2,          sizeof( l_fields.vo.cvv2 ) );
        fieldSet::fscopy( m_indCripto,     l_fields.vo.indCripto,     sizeof( l_fields.vo.indCripto ) );
        fieldSet::fscopy( m_id_pedido,     l_fields.vo.id_pedido,     sizeof( l_fields.vo.id_pedido ) );
        fieldSet::fscopy( m_saldo_parcial, l_fields.vo.saldo_parcial, sizeof( l_fields.vo.saldo_parcial ) );
        fieldSet::fscopy( m_pdv_trn_id,    l_fields.vo.id,            sizeof( l_fields.vo.id ) );
    }

    void Bit48Parser::processaFieldSet_noidi( Bit48 &l_fields )
    {
        std::string saux;
        char sbuf[16];
        long laux;

        saux.assign ( l_fields.noidi.vl_txa, sizeof( l_fields.noidi.vl_txa ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_txa, sbuf );
        saux.assign ( l_fields.noidi.vl_pca_ent, sizeof( l_fields.noidi.vl_pca_ent ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_pca_ent, sbuf );
    }

    void Bit48Parser::processaFieldSet_noidii( Bit48 &l_fields )
    {
        std::string saux;
        char sbuf[16];
        long laux;

        saux.assign ( l_fields.noidii.vl_txa, sizeof( l_fields.noidii.vl_txa ) );
        sprintf( sbuf, "%.2f", atof( saux.c_str( ) ) / 100 );
        fieldSet::fscopy( m_vl_txa, sbuf );
    }
}

