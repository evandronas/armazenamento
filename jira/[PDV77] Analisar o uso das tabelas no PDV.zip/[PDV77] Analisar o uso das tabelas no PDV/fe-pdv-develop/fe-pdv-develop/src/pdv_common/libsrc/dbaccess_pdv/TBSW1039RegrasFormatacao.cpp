#include <dbaccess_pdv/TBSW1039RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
    TBSW1039RegrasFormatacao::TBSW1039RegrasFormatacao( )
    {
    }

    TBSW1039RegrasFormatacao::~TBSW1039RegrasFormatacao( )
    {
    }

    void TBSW1039RegrasFormatacao::insert_COD_ISTT_ACQR_ORGL( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params )
    {
        oasis_dec_t l_dect;
        dbm_chartodec( &l_dect, params.ecr_acqinst_id.c_str( ), 0 );
        tbsw1039.set_COD_ISTT_ACQR_ORGL( l_dect );
    }

}
