#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include "plugins_pdv/TBSW1039Inserter.hpp"
#include "dbaccess_pdv/TBSW1039RegrasFormatacao.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW1039Inserter( )
    {
        TBSW1039Inserter* l_new = new TBSW1039Inserter;
        return ( l_new );
    }

    TBSW1039Inserter::TBSW1039Inserter( )
    {
    }

    TBSW1039Inserter::~TBSW1039Inserter( )
    {
    }

    bool TBSW1039Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front( ).findProperty( "value" ).value( ) );

        return true;    
    }
    
    bool TBSW1039Inserter::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_origpcode = this->navigate( m_sourceFieldPath + ".shc_msg.origpcode" );
        m_origmsg = this->navigate( m_sourceFieldPath + ".shc_msg.origmsg" );        
        m_origtrace = this->navigate( m_sourceFieldPath + ".shc_msg.origtrace" );
        m_ecr_acqinst_id = this->navigate( m_sourceFieldPath + ".segments.common.ecr_acqinst_id" );
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_origtime = this->navigate( m_sourceFieldPath + ".shc_msg.origtime" );
        
        return true;
    }
    
    void TBSW1039Inserter::finish( )
    {
    }
    
    int TBSW1039Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW1039 l_table1039;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW1039" );
            dbaccess_pdv::TBSW1039RegrasFormatacao regrasFmt;
            struct acq_common::tbsw1039_params params = { 0 };

            fieldSet::fsextr( params.local_date,        m_local_date );
            fieldSet::fsextr( params.refnum,            m_refnum );
            fieldSet::fsextr( params.origpcode,         m_origpcode );
            fieldSet::fsextr( params.origmsg,           m_origmsg );
            fieldSet::fsextr( params.origtrace,         m_origtrace );
            fieldSet::fsextr( params.ecr_acqinst_id,    m_ecr_acqinst_id );
            fieldSet::fsextr( params.origdate,          m_origdate );
            fieldSet::fsextr( params.origtime,          m_origtime );

            regrasFmt.DAT_MOV_TRAN      ( l_table1039, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC       ( l_table1039, params, acq_common::INSERT );
            regrasFmt.COD_MSG_ISO_ORGL  ( l_table1039, params, acq_common::INSERT );
            regrasFmt.NUM_STAN_ORGL     ( l_table1039, params, acq_common::INSERT );
            regrasFmt.DTH_STTU_TRAN_ORGL( l_table1039, params, acq_common::INSERT );
            regrasFmt.COD_ISTT_ACQR_ORGL( l_table1039, params, acq_common::INSERT );

            l_table1039.insert( );
            l_table1039.commit( );
    
            fieldSet::fscopy( m_result, "OK", 2 );
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW1039 . < " + std::string( e.what( ) ) + " > ";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW1039 <" + std::string( e.what( ) ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW1039Inserter& TBSW1039Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    TBSW1039Inserter& TBSW1039Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW1039Inserter::clone( ) const
    {
        return new TBSW1039Inserter(*this);
    }
  
} // namespace plugins_pdv
