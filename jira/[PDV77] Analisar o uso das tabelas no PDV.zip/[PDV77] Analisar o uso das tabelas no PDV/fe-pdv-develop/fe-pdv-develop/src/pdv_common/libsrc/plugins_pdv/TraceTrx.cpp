/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-pdv
/ Descri��o:
/ Conte�do:
/ Autor: t682566, Jairo Jardel Borba Junior
/ Data de Cria��o: 2012, 06 de setembro
/ Hist�rico Mudan�as: 2012, 06 de setembro, t682566, Jairo Jardel Borba Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*********************** MODIFICACOES ************************
Autor    : Daniel Nava
Data     : 22/10/2019
Empresa  : Leega
Descricao: Inclusao dos milisegundos na log
ID       : EAK-1854
*************************************************************
Autor    : Renato de Camargo
Data     : 29.05.2020
Empresa  : Rede
Descricao: Tratamento do Motivo SW
ID       : EAK-2267
*************************************************************
*/
#pragma once

#include <unistd.h>
#include <ctime>
#include <cstring>
#include <sys/timeb.h>
#include "base/GenException.hpp"
#include "logger/LoggerGen.hpp"
#include "plugins_pdv/TraceTrx.hpp"
#include "configBase/TagList.hpp"

namespace plugins_pdv
{
	base::Identificable* createTraceTrx( )
	{
		TraceTrx* l_new = new TraceTrx;
		return l_new;
	}
	TraceTrx::TraceTrx( )
	{
		m_logger = 0;
	}
	TraceTrx::~TraceTrx( )
	{
	}
	bool TraceTrx::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "sourceFieldPath", l_tagList );
		m_sourceFieldPath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "engineFieldPath", l_tagList );
		m_engineFieldPath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "portNamePath", l_tagList );
		m_portNamePath = l_tagList.front( ).findProperty( "value" ).value( );
		
		return true;
	}
	bool TraceTrx::init( )
	{
		m_pid = getpid();

		m_msgType = navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
		m_pcode = navigate( m_sourceFieldPath + ".shc_msg.pcode" );
        m_terminal_pdv = navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
		m_termloc = navigate( m_sourceFieldPath + ".shc_msg.termloc" );
		m_stanTerm = navigate( m_sourceFieldPath + ".shc_msg.trace" );
		m_amount = navigate( m_sourceFieldPath + ".shc_msg.amount" );
		m_stanIssuer = navigate( m_sourceFieldPath + ".shc_msg.refnum" );
		m_pan = navigate( m_sourceFieldPath + ".shc_msg.pan" );
		m_posEntryCode = navigate( m_sourceFieldPath + ".shc_msg.pos_entry_code" );
		m_azReasonCode = navigate( m_sourceFieldPath + ".segments.common.az_reason_code" );
		m_transcode = navigate( m_sourceFieldPath + ".segments.common.transcode" );
        m_issuer = navigate( m_sourceFieldPath + ".shc_msg.issuer" );
        m_codMtvSw = navigate( m_sourceFieldPath + ".segments.common.cod_mtv_sw" );   
        m_authNum = navigate( m_sourceFieldPath + ".shc_msg.authnum" );   
		m_direction = navigate( m_engineFieldPath + ".MESSAGE_DIRECTION" );
		m_portName = navigate( m_portNamePath );
		m_origRefNum = navigate( m_sourceFieldPath + ".segments.common.origrefnum"  );
		
		m_logger = logger::LoggerGen::getInstance( );
		m_logger->init( );
		
		return true;
	}
	void TraceTrx::finish( )
	{
	}

/// execute
/// Monta o texto da log
/// EF/ET: EAK-1854
/// Hist�rico: 22/10/2019
/// Alteracao para buscar a data e hora pela biblioteca sys/timeb para buscar os milissegundos
	int TraceTrx::execute( bool& a_stop )
	{
		base::genAssertPtr( m_logger, __FUNCTION__, "Logger not initialised" );
		
		timeb nowTimePoint;
		time_t l_rawtime;
		struct tm * l_timeinfo;
		char l_timeAscii[128];
		
		memset(l_timeAscii, 0, sizeof(l_timeAscii) );
		//time ( &l_rawtime );
		ftime(&nowTimePoint);
		l_rawtime =  nowTimePoint.time;
		l_timeinfo = localtime ( &l_rawtime );
		
		unsigned short milli = nowTimePoint.millitm;
		
		base::genAssertPtr( l_timeinfo, __FUNCTION__, "Invalid timeinfo" );

		snprintf(
			l_timeAscii,
			sizeof l_timeAscii,
			"%04d.%02d.%02d %02d:%02d:%02d.%03d",
			l_timeinfo->tm_year + 1900,
			l_timeinfo->tm_mon + 1,
			l_timeinfo->tm_mday,
			l_timeinfo->tm_hour,
			l_timeinfo->tm_min,
			l_timeinfo->tm_sec,
			milli
		);
		std::string l_trimmedPan;
        l_trimmedPan = m_pan.value();
        std::size_t found = l_trimmedPan.find_first_of(" ");
        while (found!=std::string::npos)
        {
            l_trimmedPan.erase (l_trimmedPan.begin()+found);
            found = l_trimmedPan.find_first_of(" ");
        }

		size_t l_posIni = l_trimmedPan.find_first_not_of( "0" );
		if ( l_posIni != std::string::npos )
		{
			l_trimmedPan = l_trimmedPan.substr( l_posIni );
		}
		std::string l_beginPan;
		std::string l_endPan;
		std::string l_mask;
		if ( strlen( l_trimmedPan.c_str() ) > 10 )
		{
			l_beginPan = l_trimmedPan.substr( 0, 6 );
			l_endPan = l_trimmedPan.substr( strlen( l_trimmedPan.c_str() ) - 4, 4 );
			l_mask.assign( strlen( l_trimmedPan.c_str() ) - 10, '*' );
		}
		std::string l_maskedPan = l_beginPan + l_mask + l_endPan;        
        
        const char* l_networkIdPorta = getenv( "NETWORKID" );		
        std::string l_amount;
        l_amount.assign( m_amount.value( ) );
        std::size_t l_pos = l_amount.find('.');
        if ( l_pos != std::string::npos )
        {
            l_amount.erase( l_pos, 1 );
        }
        l_amount.insert( 0, 12 - l_amount.length(), '0' );        
        
		char l_buffer[256];        
		snprintf( l_buffer, sizeof l_buffer, "%s %20.20s %10.10s %10.10s %0.8d %1.1s %0.4d %0.6d %9.9s %8.8s %0.6ld %0.9ld %6.6s %19.19s %12.12s %3.3s %0.3d %3.3s %0.2d\n",
			l_timeAscii,
			( m_portName.value( ).length( ) ? m_portName.value().c_str( ) : "-" ),
            ( l_networkIdPorta ? l_networkIdPorta : "-" ),
            ( m_issuer.value( ).length( ) ? m_issuer.value().c_str( ) : "-" ),
			m_pid,
			m_direction.value( ) == "FROM_NET" ? "I" : "O",
			atoi( m_msgType.value().c_str( ) ),
			atoi( m_pcode.value().c_str( ) ),
			( m_termloc.value( ).length( ) ? m_termloc.value( ).c_str( ) : "-" ),
            ( m_terminal_pdv.value( ).length( ) ? m_terminal_pdv.value( ).c_str( ) : "-" ),
			atol( m_stanTerm.value( ).c_str( ) ),
			( ( atoi( m_msgType.value().c_str( ) ) != 610 ) ? atol( m_stanIssuer.value( ).c_str( ) ) : atol( m_origRefNum.value( ).c_str( ) ) ),
            ( m_authNum.value( ).length( ) ? m_authNum.value( ).c_str( ) : "-" ),
			( l_maskedPan.length( ) ? l_maskedPan.c_str( ) : "-" ),
			( l_amount.length( ) ? l_amount.c_str( ) : "-" ),
			( m_transcode.value( ).length( ) ? m_transcode.value( ).c_str( ) : "-" ),
			atoi( m_posEntryCode.value( ).c_str( ) ),
            ( m_codMtvSw.value( ).length() ? m_codMtvSw.value( ).c_str( ): "-" ),
			atoi( m_azReasonCode.value( ).c_str( ) )
        ); 

		m_logger->print( logger::LEVEL_TRACE, l_buffer );

		a_stop = false;
		return 0;
	}
	dataManip::Command* TraceTrx::clone( ) const
	{
		return new TraceTrx(*this);
	}
}//namespace plugins_pdv
