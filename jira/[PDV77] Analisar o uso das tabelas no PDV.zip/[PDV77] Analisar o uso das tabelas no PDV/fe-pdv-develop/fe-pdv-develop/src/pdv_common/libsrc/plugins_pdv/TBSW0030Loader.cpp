#pragma once
#include <sstream>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

#include "TBSW0030.hpp"
//TODOSW75 #include "dualHandler.hpp"
#include "plugins_pdv/TBSW0030Loader.hpp"

// Release Bandeiras PDV - Abril 2019
using namespace std;

namespace plugins_pdv
{
    base::Identificable* createTBSW0030Loader( )
    {
        TBSW0030Loader* l_new = new TBSW0030Loader;
        return l_new;
    }

    bool TBSW0030Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        std::string l_source;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        for ( unsigned int i = 0; i < l_tagList.size(); i++ )
        {
            l_source = l_tagList.at( i ).findProperty( "value" ).value();
            if ( l_source == "LOCAL" )
            {
                this->setLocalFieldPath( l_source );
            }
            else
            {
                this->setSourceFieldPath( l_source );
            }
        }

        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );
        return true;
    }

    TBSW0030Loader::TBSW0030Loader( )
    {
    }

    TBSW0030Loader::~TBSW0030Loader( )
    {
    }

    bool TBSW0030Loader::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        m_target_dat_mov_tran = this->navigate( m_targetFieldPath + ".DAT_MOV_TRAN" );
        m_target_num_seq_unc = this->navigate( m_targetFieldPath + ".NUM_SEQ_UNC" );
        m_target_tip_tran = this->navigate( m_targetFieldPath + ".TIP_TRAN" );
        m_target_num_mot_rsps = this->navigate( m_targetFieldPath + ".NUM_MOT_RSPS" );
        m_target_tip_tcnl = this->navigate( m_targetFieldPath + ".TIP_TCNL" );
        m_target_num_estb = this->navigate( m_targetFieldPath + ".NUM_ESTB" );
        m_target_cod_term = this->navigate( m_targetFieldPath + ".COD_TERM" );
        m_target_tip_term = this->navigate( m_targetFieldPath + ".TIP_TERM" );
        m_target_num_rd_org = this->navigate( m_targetFieldPath + ".NUM_RD_ORG" );
        m_target_cod_pos_entr_modo = this->navigate( m_targetFieldPath + ".COD_POS_ENTR_MODO" );
        m_target_cod_emsr = this->navigate( m_targetFieldPath + ".COD_EMSR" );
        m_target_tip_vd = this->navigate( m_targetFieldPath + ".TIP_VD" );
        m_target_val_tran = this->navigate( m_targetFieldPath + ".VAL_TRAN" );
        m_target_cod_ram_atvd = this->navigate( m_targetFieldPath + ".COD_RAM_ATVD" );
        m_target_num_car = this->navigate( m_targetFieldPath + ".NUM_CAR" );
        m_target_cod_mot_rsps_ext = this->navigate( m_targetFieldPath + ".COD_MOT_RSPS_EXT" );
        m_target_num_aut = this->navigate( m_targetFieldPath + ".NUM_AUT" );
        m_target_val_tx = this->navigate( m_targetFieldPath + ".VAL_TX" );
        m_target_val_cot_dlr = this->navigate( m_targetFieldPath + ".VAL_COT_DLR" );
        m_target_dat_vld_car = this->navigate( m_targetFieldPath + ".DAT_VLD_CAR" );
        m_target_cod_trk_car = this->navigate( m_targetFieldPath + ".COD_TRK_CAR" );
        m_target_cod_moed = this->navigate( m_targetFieldPath + ".COD_MOED" );
        m_target_num_cv = this->navigate( m_targetFieldPath + ".NUM_CV" );
        m_target_val_tran_dlr = this->navigate( m_targetFieldPath + ".VAL_TRAN_DLR" );
        m_target_cod_ctgr_tran = this->navigate( m_targetFieldPath + ".COD_CTGR_TRAN" );
        m_target_num_bin_car = this->navigate( m_targetFieldPath + ".NUM_ID_CAR" );
        m_target_cod_pais_car = this->navigate( m_targetFieldPath + ".COD_PAIS_CAR" );
        m_target_ind_id_prev = this->navigate( m_targetFieldPath + ".IND_ID_PREV" );
        m_target_cod_prod = this->navigate( m_targetFieldPath + ".COD_PROD" );
        m_target_cod_ctr = this->navigate( m_targetFieldPath + ".COD_CTR" );
        m_target_cod_cndc_cptr = this->navigate( m_targetFieldPath + ".COD_CNDC_CPTR" );
        m_target_num_emsr = this->navigate( m_targetFieldPath + ".NUM_EMSR" );
        m_target_dat_ctb_tran = this->navigate( m_targetFieldPath + ".DAT_CTB_TRAN" );
        m_target_cod_bndr = this->navigate( m_targetFieldPath + ".COD_BNDR" );
        m_target_dat_rsmo_vd = this->navigate( m_targetFieldPath + ".DAT_RSMO_VD" );
        m_target_ind_tran_refd = this->navigate( m_targetFieldPath + ".IND_TRAN_REFD" );
        m_target_cod_ref_restante = this->navigate( m_targetFieldPath + ".COD_REF_RESTANTE" );
        m_target_ind_trk = this->navigate( m_targetFieldPath + ".IND_TRK" );
        m_target_cod_mot_sw = this->navigate( m_targetFieldPath + ".COD_MOT_SW" );
        m_target_ind_cptr_cvc_2 = this->navigate( m_targetFieldPath + ".IND_CPTR_CVC_2" );
        m_target_ind_term_rlcd_chip = this->navigate( m_targetFieldPath + ".IND_TERM_RLCD_CHIP" );
        m_target_cod_serv = this->navigate( m_targetFieldPath + ".COD_SERV" );
        m_target_cod_serv_snha = this->navigate( m_targetFieldPath + ".COD_SERV_SNHA" );
        m_target_val_tx_risc = this->navigate( m_targetFieldPath + ".VAL_TX_RISC" );
        m_target_nom_loc_estb = this->navigate( m_targetFieldPath + ".NOM_LOC_ESTB" );
        m_target_cod_msg_iso = this->navigate( m_targetFieldPath + ".COD_MSG_ISO" );
        m_target_cod_pcm_iso = this->navigate( m_targetFieldPath + ".COD_PCM_ISO" );
        m_target_ind_dfzm = this->navigate( m_targetFieldPath + ".IND_DFZM" );
        m_target_ind_estr = this->navigate( m_targetFieldPath + ".IND_ESTR" );
        m_target_ind_cptrdo = this->navigate( m_targetFieldPath + ".IND_CPTRDO" );
        m_target_tip_tran_orgl = this->navigate( m_targetFieldPath + ".TIP_TRAN_ORGL" );
        m_target_tip_pln_pgmn = this->navigate( m_targetFieldPath + ".TIP_PLN_PGMN" );
        m_target_dat_expc_tran = this->navigate( m_targetFieldPath + ".DAT_EXPC_TRAN" );
        m_target_ind_agnd_tran = this->navigate( m_targetFieldPath + ".IND_AGND_TRAN" );
        m_target_cod_cmpm_tran = this->navigate( m_targetFieldPath + ".COD_CMPM_TRAN" );
        m_target_ind_impr_cpom = this->navigate( m_targetFieldPath + ".IND_IMPR_CPOM" );
        m_target_dth_ini_tran = this->navigate( m_targetFieldPath + ".DTH_INI_TRAN" );
        m_target_dth_sttu_tran = this->navigate( m_targetFieldPath + ".DTH_STTU_TRAN" );
        m_target_prcn_tx_risc = this->navigate( m_targetFieldPath + ".PRCN_TX_RISC" );
        m_target_num_stan = this->navigate( m_targetFieldPath + ".NUM_STAN" );
        m_target_cod_cndc_cptr_pauz = this->navigate( m_targetFieldPath + ".COD_CNDC_CPTR_PAUZ" );
        m_target_tip_ent_pauz = this->navigate( m_targetFieldPath + ".TIP_ENT_PAUZ" );
        m_target_cod_oper_cnfr = this->navigate( m_targetFieldPath + ".COD_OPER_CNFR" );
        m_target_ind_emsr_mtc = this->navigate( m_targetFieldPath + ".IND_EMSR_MTC" );
        m_target_ind_da_rlcd_chip = this->navigate( m_targetFieldPath + ".IND_DA_RLCD_CHIP" );
        m_target_tip_dtlh_tran = this->navigate( m_targetFieldPath + ".TIP_DTLH_TRAN" );
        m_target_ind_da_rlcd_iata = this->navigate( m_targetFieldPath + ".IND_DA_RLCD_IATA" );
        m_target_dth_gmt = this->navigate( m_targetFieldPath + ".DTH_GMT" );
        m_target_cod_mot_aut = this->navigate( m_targetFieldPath + ".COD_MOT_AUT" );
        m_target_num_cvc_2 = this->navigate( m_targetFieldPath + ".NUM_CVC_2" );
        m_target_val_totl_tran = this->navigate( m_targetFieldPath + ".VAL_TOTL_TRAN" );
        m_target_ind_sttu_tran = this->navigate( m_targetFieldPath + ".IND_STTU_TRAN" );
        m_target_num_rsmo_vd = this->navigate( m_targetFieldPath + ".NUM_RSMO_VD" );
        m_target_nom_site_acqr_orgl = this->navigate( m_targetFieldPath + ".NOM_SITE_ACQR_ORGL" );
        m_target_nom_host_acqr_orgl = this->navigate( m_targetFieldPath + ".NOM_HOST_ACQR_ORGL" );
        m_target_nom_fe_acqr_orgl = this->navigate( m_targetFieldPath + ".NOM_FE_ACQR_ORGL" );
        m_target_nom_site_issr = this->navigate( m_targetFieldPath + ".NOM_SITE_ISSR" );
        m_target_nom_host_issr = this->navigate( m_targetFieldPath + ".NOM_HOST_ISSR" );
        m_target_nom_fe_issr = this->navigate( m_targetFieldPath + ".NOM_FE_ISSR" );
        m_target_nom_site_acqr_atlz = this->navigate( m_targetFieldPath + ".NOM_SITE_ACQR_ATLZ" );
        m_target_nom_host_acqr_atlz = this->navigate( m_targetFieldPath + ".NOM_HOST_ACQR_ATLZ" );
        m_target_nom_fe_acqr_atlz = this->navigate( m_targetFieldPath + ".NOM_FE_ACQR_ATLZ" );
        m_target_txt_da_adic_emsr = this->navigate( m_targetFieldPath + ".TXT_DA_ADIC_EMSR");
        m_target_tip_modl_cptr = this->navigate( m_targetFieldPath + ".TIP_MODL_CPTR");
        m_target_dth_tran_emsr = this->navigate( m_targetFieldPath + ".DTH_TRAN_EMSR");
        m_target_dat_lqdc_emsr = this->navigate( m_targetFieldPath + ".DAT_LQDC_EMSR");
        m_target_cod_istt_acqr = this->navigate( m_targetFieldPath + ".COD_ISTT_ACQR");
        m_target_cod_istt_frwd = this->navigate( m_targetFieldPath + ".COD_ISTT_FRWD");
        m_target_cod_rsps_dtlh_emsr = this->navigate( m_targetFieldPath + ".COD_RSPS_DTLH_EMSR");
        m_target_cod_rstd_num_cvc_2 = this->navigate( m_targetFieldPath + ".COD_RSTD_NUM_CVC_2");
        m_target_cod_serv_trk_car = this->navigate( m_targetFieldPath + ".COD_SERV_TRK_CAR");
        m_target_cod_vldc_emsr = this->navigate( m_targetFieldPath + ".COD_VLDC_EMSR");
        m_target_ind_aut = this->navigate( m_targetFieldPath + ".IND_AUT");
        m_target_ind_da_rlcd_kmrc = this->navigate( m_targetFieldPath + ".IND_DA_RLCD_KMRC");
        //m_target_val_eftv_aprv = this->navigate( m_targetFieldPath + ".VAL_EFTV_APRV" );

        // t694446@FIS_BEGIN - Data: 06/01/2014 - 13:35 - Ref. ao BT53.136
           m_target_cod_aut_emsr = this->navigate( m_targetFieldPath + ".COD_AUT_EMSR");
        // t694446@FIS_END - Data: 06/01/2014 - 13:35 - Ref. ao BT53.136

        //cr689721@FIS_BEGIN - Data: 20/02/2014 - Ref. ao BT55.769
        m_target_cod_tran_cad = this->navigate( m_targetFieldPath + ".COD_TRAN_CAD" );
		m_target_COD_TRAN_CAD = this->navigate( m_targetFieldPath + ".COD_TRAN_CAD");
		//cr689721@FIS - Data: 23/10/2014 - Ref. Recuperar dados para Estorno ou Desfazimento de confirma��o de pre-autoriza��o
		m_target_DAT_PAUZ = this->navigate( m_targetFieldPath + ".DAT_PAUZ");
		m_target_NUM_SEQ_UNC_PAUZ = this->navigate( m_targetFieldPath + ".NUM_SEQ_UNC_PAUZ");

        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_origpan = this->navigate( m_sourceFieldPath + ".segments.common.orig_pan" );
        m_origtrace = this->navigate( m_sourceFieldPath + ".shc_msg.origtrace" );
        m_origmsg = this->navigate( m_sourceFieldPath + ".shc_msg.origmsg" );
        m_termid = this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        m_is_3a_perna = this->navigate( m_sourceFieldPath + ".segments.common.is_3a_perna" );
        m_acquirer_data = this->navigate( m_sourceFieldPath + ".shc_msg.acquirer_data" );
        m_pan = this->navigate( m_sourceFieldPath + ".shc_msg.pan" );
        m_amount = this->navigate( m_sourceFieldPath + ".shc_msg.amount" );
        settlementDate = this->navigate( m_sourceFieldPath + ".shc_msg.settlement_date" );
        if ( !m_localFieldPath.empty( ) )
        {
            m_referralCondition = this->navigate( m_localFieldPath + ".REFERRAL_CONDITION" );
        }
        m_cod_ram_mcc = this->navigate( m_targetFieldPath + ".COD_RAM_MCC");

        m_target_COD_NTWK_ID_ISSR_ORGL = this->navigate( m_targetFieldPath + ".COD_NTWK_ID_ISSR_ORGL");
        m_target_COD_NTWK_ID_ACQR_ORGL = this->navigate( m_targetFieldPath + ".COD_NTWK_ID_ACQR_ORGL");
        
        m_target_cod_prod_cdst = this->navigate( m_targetFieldPath + ".COD_PROD_CDST");
        m_target_cod_prod_prcr = this->navigate( m_targetFieldPath + ".COD_PROD_PRCR" );        
        indicadorTransacaoTokenizada = this->navigate( m_targetFieldPath + ".IND_TRAN_TKN" );
        
        // Release Bandeiras PDV - Abril 2019 - INICIO
        indicadorPresencaPortador = this->navigate( string(m_targetFieldPath).append(".COD_PORT_PRES_VLDC_BNDR") );
        indicadorTecnologiaTerminal = this->navigate( string(m_targetFieldPath).append(".COD_CPCD_TERM_VLDC_BNDR") );
        // Release Bandeiras PDV - Abril 2019 - FIM
        
        return true;
    }

    void TBSW0030Loader::finish( )
    {
    }

    int TBSW0030Loader::execute( bool& a_stop )
    {
    try
    {
        std::ostringstream l_whereClause;
        unsigned long l_msgtype, l_local_date, l_origdate, l_origtrace, l_origmsg;
        std::string l_is_3a_perna, l_origpan, l_termid, l_refnum, l_origrefnum;
        std::string l_acquirer_data;
        std::string l_pan;
        std::string l_amount;
        std::string l_val_tran;
        std::string settleDate;

        fieldSet::fsextr( l_local_date, m_local_date );
        fieldSet::fsextr( l_refnum, m_refnum );
        fieldSet::fsextr( l_msgtype, m_msgtype );
        fieldSet::fsextr( l_origrefnum, m_origrefnum );
        fieldSet::fsextr( l_origdate, m_origdate );
        fieldSet::fsextr( l_origpan, m_origpan );
        fieldSet::fsextr( l_origtrace, m_origtrace );
        fieldSet::fsextr( l_termid, m_termid );
        fieldSet::fsextr( l_is_3a_perna, m_is_3a_perna );
        fieldSet::fsextr( l_acquirer_data, m_acquirer_data );
        fieldSet::fsextr( l_pan, m_pan );
        fieldSet::fsextr( l_amount, m_amount );
        fieldSet::fsextr( l_val_tran, m_target_val_tran );
        fieldSet::fsextr( l_origmsg, m_origmsg );
        fieldSet::fsextr( settleDate, settlementDate );

	std::size_t found = l_pan.find_first_not_of(" 0");
	if ( found != std::string::npos )
	{
	 l_pan = l_pan.substr( found, l_pan.size() );
	}


        bool l_isReferral;

        if ( !m_referralCondition )
        {
            l_isReferral = false;
        }
        else
        {
            l_isReferral = m_referralCondition.field( ).value( ) == "true" || m_referralCondition.field( ).value( ) == "TRUE";
        }

        if( strlen(l_origrefnum.c_str()) == 0 )
            l_origrefnum = "0";

        if ( !l_is_3a_perna.compare("TRUE") )
        {
            l_whereClause << " IND_STTU_TRAN = '0' "
                << " AND DAT_MOV_TRAN = " << settleDate << " AND NUM_SEQ_UNC = " << l_origrefnum;
        }
        else
        {
			// t689066@FIS_BEGIN - Data: 30/12/2013 - BT53125: cartoes menores que 16 estavam gravando NUM_CAR com separador.
            size_t l_pos = l_pan.find_first_of("=DF^");
            if( l_pos != std::string::npos )
            {
                l_pan.erase( l_pos, std::string::npos );
            }
			// t689066@FIS_END - Data: 30/12/2013 - BT53125: cartoes menores que 16 estavam gravando NUM_CAR com separador.
            switch ( l_msgtype )
            {
                case 610 :
                case 100 :
                case 200 :
                    if ( l_isReferral )//REFERRAL OU DESBLOQUEIO AUTOMATICO
                    {
                        l_whereClause
                            << " DAT_MOV_TRAN = "  << l_local_date
                            << " AND COD_TERM = '" << l_termid << "'"
                            << " AND NUM_CAR = '" << l_pan << "'"
                            << " AND VAL_TRAN = '" << l_amount << "'"
                        ;
                    }
                    else
                    {
                        l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
                    }
                    break;

                case 220 :
                    l_whereClause << " DAT_MOV_TRAN=" << l_origdate
                        << " AND (( NUM_STAN = "  << l_origtrace
                        << " AND COD_TERM = '" << l_termid << "')"
                        << " OR NUM_SEQ_UNC=" << l_origrefnum << ")";
                    break;
                case 400 :
                    l_whereClause << " IND_STTU_TRAN IN ('0', '1', '4')"
                        << " AND COD_MSG_ISO = " << l_origmsg
                        << " AND DAT_MOV_TRAN=" << l_origdate
                        << " AND NUM_STAN = "  << l_origtrace
                        << " AND COD_TERM = '" << l_termid << "'";
                    break;
                case 420 :
                case 9300 :
                    l_whereClause << " DAT_MOV_TRAN=" << l_origdate
                        << " AND NUM_STAN = "  << l_origtrace
                        << " AND COD_TERM = '" << l_termid << "'";
                    if( l_origmsg != 0 )
                    {
                        l_whereClause << " AND COD_MSG_ISO = " << l_origmsg;
                    }
                    break;

                default:
                    fieldSet::fscopy( m_result, "EMPTY QUERY", 11 );
                    a_stop = false;
                    return 0;
                    break;
            }
        }

        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0030 ==========" );
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.str().c_str() );
        dbaccess_common::TBSW0030 l_TBSW0030( l_whereClause.str() );
        l_TBSW0030.prepare();
        l_TBSW0030.execute();

        //TODOSW75 
        /***
        dbaccess_common::DualHandler l_dualHand( &l_TBSW0030 );
        if ( l_msgtype == 610 )
        {
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " l_dualHand.setIsStatusInq( ) " );
            l_dualHand.setIsStatusInq( );
        }
        int ret = l_dualHand.fetch();
        ***/
        int ret = l_TBSW0030.fetch();
        if( !ret )
        {
            fieldSet::fscopy( m_result, "NO ROWS", 7 );
        }
        else
        {
            fieldSet::fscopy( m_result, "OK", 2 );
            char l_bufferTemp[64];
            oasis_dec_t l_dec_temp;

            fieldSet::fscopy( m_target_dat_mov_tran, l_TBSW0030.get_DAT_MOV_TRAN( ) );
			//t689066@FIS-BEGIN - Data:20/08/2013 - NUM_SEQ_UNC declarado como long ao invez de dect na TBSW0030
			fieldSet::fscopy( m_target_num_seq_unc, l_TBSW0030.get_NUM_SEQ_UNC( ) );
			//t689066@FIS-END - Data:20/08/2013 - NUM_SEQ_UNC declarado como long ao invez de dect na TBSW0030

            fieldSet::fscopy( m_target_tip_tran, l_TBSW0030.get_TIP_TRAN( ) );
            fieldSet::fscopy( m_target_num_mot_rsps, l_TBSW0030.get_NUM_MOT_RSPS( ) );
            fieldSet::fscopy( m_target_tip_tcnl, l_TBSW0030.get_TIP_TCNL( ) );
            fieldSet::fscopy( m_target_num_estb, l_TBSW0030.get_NUM_ESTB( ) );
            fieldSet::fscopy( m_target_cod_term, l_TBSW0030.get_COD_TERM( ) );
            fieldSet::fscopy( m_target_tip_term, l_TBSW0030.get_TIP_TERM( ) );
            if( l_TBSW0030.get_NUM_RD_ORG( ) != NULL )
            {
                char l_netcodex[5];
                memset( (char *) &l_netcodex, 0, sizeof l_netcodex );
                snprintf( l_netcodex, sizeof l_netcodex, "%04X", l_TBSW0030.get_NUM_RD_ORG( ));
                fieldSet::fscopy( m_target_num_rd_org, l_netcodex );
            }
            fieldSet::fscopy( m_target_cod_pos_entr_modo, l_TBSW0030.get_COD_POS_ENTR_MODO( ) );
            fieldSet::fscopy( m_target_cod_emsr, l_TBSW0030.get_COD_EMSR( ) );
            fieldSet::fscopy( m_target_tip_vd, l_TBSW0030.get_TIP_VD( ) );

            //fieldSet::fscopy( m_target_val_tran, l_TBSW0030.get_VAL_TRAN( ) );
            l_dec_temp = l_TBSW0030.get_VAL_TRAN( );
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
            fieldSet::fscopy( m_target_val_tran, std::string( l_bufferTemp ) );

            fieldSet::fscopy( m_target_cod_ram_atvd, l_TBSW0030.get_COD_RAM_ATVD( ) );
            fieldSet::fscopy( m_target_num_car, l_TBSW0030.get_NUM_CAR( ) );
            fieldSet::fscopy( m_target_cod_mot_rsps_ext, l_TBSW0030.get_COD_MOT_RSPS_EXT( ) );
            fieldSet::fscopy( m_target_num_aut, l_TBSW0030.get_NUM_AUT( ) );

            //fieldSet::fscopy( m_target_val_tx, l_TBSW0030.get_VAL_TX( ) );
            l_dec_temp = l_TBSW0030.get_VAL_TX( );
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
            fieldSet::fscopy( m_target_val_tx, std::string( l_bufferTemp ) );

            //fieldSet::fscopy( m_target_val_cot_dlr, l_TBSW0030.get_VAL_COT_DLR( ) );
            l_dec_temp = l_TBSW0030.get_VAL_COT_DLR( );
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 4 );
            fieldSet::fscopy( m_target_val_cot_dlr, std::string( l_bufferTemp ) );


            fieldSet::fscopy( m_target_dat_vld_car, l_TBSW0030.get_DAT_VLD_CAR( ).date );
            fieldSet::fscopy( m_target_cod_trk_car, l_TBSW0030.get_COD_TRK_CAR( ) );
            fieldSet::fscopy( m_target_cod_moed, l_TBSW0030.get_COD_MOED( ) );

			//t689066@FIS-BEGIN - Data:20/08/2013 - NUM_CV declarado como long ao invez de dect na TBSW0030
			fieldSet::fscopy( m_target_num_cv, l_TBSW0030.get_NUM_CV( ) );
			//t689066@FIS-END - Data:20/08/2013 - NUM_CV declarado como long ao invez de dect na TBSW0030

            //fieldSet::fscopy( m_target_val_tran_dlr, l_TBSW0030.get_VAL_TRAN_DLR( ) );
            l_dec_temp = l_TBSW0030.get_VAL_TRAN_DLR( );
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
            fieldSet::fscopy( m_target_val_tran_dlr, std::string( l_bufferTemp ) );

            fieldSet::fscopy( m_target_cod_ctgr_tran, l_TBSW0030.get_COD_CTGR_TRAN( ) );

			//t689066@FIS-BEGIN - Data:03/08/2013 - NUM_ID_CAR declarado como long ao invez de dect na TBSW0030 (estourando limite)
            l_dec_temp = l_TBSW0030.get_NUM_ID_CAR( );
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
            fieldSet::fscopy( m_target_num_bin_car, std::string( l_bufferTemp ) );
			//t689066@FIS-END - Data:03/08/2013 - NUM_ID_CAR declarado como long ao invez de dect na TBSW0030 (estourando limite)

            fieldSet::fscopy( m_target_cod_pais_car, l_TBSW0030.get_COD_PAIS_CAR( ) );
            fieldSet::fscopy( m_target_ind_id_prev, l_TBSW0030.get_IND_ID_PREV( ) );
            fieldSet::fscopy( m_target_cod_prod, l_TBSW0030.get_COD_PROD( ) );
            fieldSet::fscopy( m_target_cod_ctr, l_TBSW0030.get_COD_CTR( ) );
            fieldSet::fscopy( m_target_cod_cndc_cptr, l_TBSW0030.get_COD_CNDC_CPTR( ) );
            fieldSet::fscopy( m_target_num_emsr, l_TBSW0030.get_NUM_EMSR( ) );
            fieldSet::fscopy( m_target_dat_ctb_tran, l_TBSW0030.get_DAT_CTB_TRAN( ) );
            fieldSet::fscopy( m_target_cod_bndr, l_TBSW0030.get_COD_BNDR( ) );
            fieldSet::fscopy( m_target_dat_rsmo_vd, l_TBSW0030.get_DAT_RSMO_VD( ) );
            fieldSet::fscopy( m_target_ind_tran_refd, l_TBSW0030.get_IND_TRAN_REFD( ) );
            fieldSet::fscopy( m_target_cod_ref_restante, l_TBSW0030.get_COD_REF_RESTANTE( ) );
            fieldSet::fscopy( m_target_ind_trk, l_TBSW0030.get_IND_TRK( ) );
            fieldSet::fscopy( m_target_cod_mot_sw, l_TBSW0030.get_COD_MOT_SW( ) );
            fieldSet::fscopy( m_target_ind_cptr_cvc_2, l_TBSW0030.get_IND_CPTR_CVC_2( ) );
            fieldSet::fscopy( m_target_ind_term_rlcd_chip, l_TBSW0030.get_IND_TERM_RLCD_CHIP( ) );
            fieldSet::fscopy( m_target_cod_serv, l_TBSW0030.get_COD_SERV( ) );
            fieldSet::fscopy( m_target_cod_serv_snha, l_TBSW0030.get_COD_SERV_SNHA( ) );

            //fieldSet::fscopy( m_target_val_tx_risc, l_TBSW0030.get_VAL_TX_RISC( ) );
            l_dec_temp = l_TBSW0030.get_VAL_TX_RISC( );
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
            fieldSet::fscopy( m_target_val_tx_risc, std::string( l_bufferTemp ) );

            fieldSet::fscopy( m_target_nom_loc_estb, l_TBSW0030.get_NOM_LOC_ESTB( ) );
            fieldSet::fscopy( m_target_cod_msg_iso, l_TBSW0030.get_COD_MSG_ISO( ) );
            fieldSet::fscopy( m_target_cod_pcm_iso, l_TBSW0030.get_COD_PCM_ISO( ) );
            fieldSet::fscopy( m_target_ind_dfzm, l_TBSW0030.get_IND_DFZM( ) );
            fieldSet::fscopy( m_target_ind_estr, l_TBSW0030.get_IND_ESTR( ) );
            fieldSet::fscopy( m_target_ind_cptrdo, l_TBSW0030.get_IND_CPTRDO( ) );
            fieldSet::fscopy( m_target_tip_tran_orgl, l_TBSW0030.get_TIP_TRAN_ORGL( ) );
            fieldSet::fscopy( m_target_tip_pln_pgmn, l_TBSW0030.get_TIP_PLN_PGMN( ) );
            fieldSet::fscopy( m_target_dat_expc_tran, l_TBSW0030.get_DAT_EXPC_TRAN( ) );
            fieldSet::fscopy( m_target_ind_agnd_tran, l_TBSW0030.get_IND_AGND_TRAN( ) );
            fieldSet::fscopy( m_target_cod_cmpm_tran, l_TBSW0030.get_COD_CMPM_TRAN( ) );

            //fieldSet::fscopy( m_target_val_eftv_aprv, l_TBSW0030.get_VAL_EFTV_APRV( ) );
            //l_dec_temp = l_TBSW0030.get_VAL_EFTV_APRV( );
            //memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            //dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
            //fieldSet::fscopy( m_target_val_eftv_aprv, std::string( l_bufferTemp ) );

            fieldSet::fscopy( m_target_ind_impr_cpom, l_TBSW0030.get_IND_IMPR_CPOM( ) );
            fieldSet::fscopy( m_target_dth_ini_tran, l_TBSW0030.get_DTH_INI_TRAN( ) );
            fieldSet::fscopy( m_target_dth_sttu_tran, l_TBSW0030.get_DTH_STTU_TRAN( ) );

            //fieldSet::fscopy( m_target_prcn_tx_risc, l_TBSW0030.get_PRCN_TX_RISC( ) );
            l_dec_temp = l_TBSW0030.get_PRCN_TX_RISC( );
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
            fieldSet::fscopy( m_target_prcn_tx_risc, std::string( l_bufferTemp ) );

			//t689066@FIS-BEGIN - Data:20/08/2013 - NUM_STAN declarado como long ao invez de dect na TBSW0030
			fieldSet::fscopy( m_target_num_stan, l_TBSW0030.get_NUM_STAN( ) );
			//t689066@FIS-END - Data:20/08/2013 - NUM_STAN declarado como long ao invez de dect na TBSW0030

            fieldSet::fscopy( m_target_cod_cndc_cptr_pauz, l_TBSW0030.get_COD_CNDC_CPTR_PAUZ( ) );
            fieldSet::fscopy( m_target_tip_ent_pauz, l_TBSW0030.get_TIP_ENT_PAUZ( ) );
			//cr689721@FIS - Data: 23/10/2014 - Ref. Recuperar dados para estorno ou desfazimento de 
			//confirma��o de pre-autoriza��o, DAT_PAUZ e NUM_SEQ_UNC_PAUZ
            fieldSet::fscopy( m_target_DAT_PAUZ, l_TBSW0030.get_DAT_PAUZ( ) );
            fieldSet::fscopy( m_target_NUM_SEQ_UNC_PAUZ, l_TBSW0030.get_NUM_SEQ_UNC_PAUZ( ) );
            fieldSet::fscopy( m_target_cod_oper_cnfr, l_TBSW0030.get_COD_OPER_CNFR( ) );
            fieldSet::fscopy( m_target_ind_emsr_mtc, l_TBSW0030.get_IND_EMSR_MTC( ) );
            fieldSet::fscopy( m_target_ind_da_rlcd_chip, l_TBSW0030.get_IND_DA_RLCD_CHIP( ) );
            fieldSet::fscopy( m_target_tip_dtlh_tran, l_TBSW0030.get_TIP_DTLH_TRAN( ) );
            fieldSet::fscopy( m_target_ind_da_rlcd_iata, l_TBSW0030.get_IND_DA_RLCD_IATA( ) );
            fieldSet::fscopy( m_target_dth_gmt, l_TBSW0030.get_DTH_GMT( ) );
            fieldSet::fscopy( m_target_cod_mot_aut, l_TBSW0030.get_COD_MOT_AUT( ) );
		
			std::ostringstream l_msgdump;
			std::string l_dado;
			fieldSet::fsextr( l_dado, 	m_target_DAT_PAUZ );

			fieldSet::fsextr( l_dado, 	m_target_NUM_SEQ_UNC_PAUZ );

			//t689066@FIS-BEGIN - Data:20/08/2013 - NUM_CVC_2 declarado como long ao invez de dect na TBSW0030
			//t689066@FIS-BEGIN - Data:10/01/2014 - BT53044: PDV nao grava o cvc2 e deve retornar vazio e nao zero
            //l_dec_temp = l_TBSW0030.get_NUM_CVC_2( );
            //memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            //dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
            //fieldSet::fscopy( m_target_num_cvc_2, std::string( l_bufferTemp ) );
            fieldSet::fscopy( m_target_num_cvc_2, "   " );
			//t689066@FIS-END - Data:10/01/2014 - BT53044: PDV nao grava o cvc2 e deve retornar vazio e nao zero
			//t689066@FIS-END - Data:20/08/2013 - NUM_CVC_2 declarado como long ao invez de dect na TBSW0030

            //fieldSet::fscopy( m_target_val_totl_tran, l_TBSW0030.get_VAL_TOTL_TRAN( ) );
            l_dec_temp = l_TBSW0030.get_VAL_TOTL_TRAN( );
            memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
            dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 2 );
            fieldSet::fscopy( m_target_val_totl_tran, std::string( l_bufferTemp ) );

            fieldSet::fscopy( m_target_ind_sttu_tran, l_TBSW0030.get_IND_STTU_TRAN( ) );

			//t689066@FIS-BEGIN - Data:20/08/2013 - NUM_RSMO_VD declarado como long ao invez de dect na TBSW0030
			fieldSet::fscopy( m_target_num_rsmo_vd, l_TBSW0030.get_NUM_RSMO_VD( ) );
			//t689066@FIS-END - Data:20/08/2013 - NUM_RSMO_VD declarado como long ao invez de dect na TBSW0030

            fieldSet::fscopy( m_target_nom_site_acqr_orgl, l_TBSW0030.get_NOM_SITE_ACQR_ORGL( ) );
            fieldSet::fscopy( m_target_nom_host_acqr_orgl, l_TBSW0030.get_NOM_HOST_ACQR_ORGL( ) );
            fieldSet::fscopy( m_target_nom_fe_acqr_orgl, l_TBSW0030.get_NOM_FE_ACQR_ORGL( ) );
            fieldSet::fscopy( m_target_nom_site_issr, l_TBSW0030.get_NOM_SITE_ISSR( ) );
            fieldSet::fscopy( m_target_nom_host_issr, l_TBSW0030.get_NOM_HOST_ISSR( ) );
            fieldSet::fscopy( m_target_nom_fe_issr, l_TBSW0030.get_NOM_FE_ISSR( ) );
            fieldSet::fscopy( m_target_nom_site_acqr_atlz, l_TBSW0030.get_NOM_SITE_ACQR_ATLZ( ) );
            fieldSet::fscopy( m_target_nom_host_acqr_atlz, l_TBSW0030.get_NOM_HOST_ACQR_ATLZ( ) );
            fieldSet::fscopy( m_target_nom_fe_acqr_atlz, l_TBSW0030.get_NOM_FE_ACQR_ATLZ( ) );

            fieldSet::fscopy( m_target_txt_da_adic_emsr, l_TBSW0030.get_TXT_DA_ADIC_EMSR( ) );
            fieldSet::fscopy( m_target_tip_modl_cptr, l_TBSW0030.get_TIP_MODL_CPTR( ) );
            fieldSet::fscopy( m_target_dth_tran_emsr, l_TBSW0030.get_DTH_TRAN_EMSR( ) );
            fieldSet::fscopy( m_target_dat_lqdc_emsr, l_TBSW0030.get_DAT_LQDC_EMSR( ) );

            //t689066@FIS-BEGIN - Data:20/08/2013 - COD_ISTT_ACQR declarado como long ao invez de dect na TBSW0030
            fieldSet::fscopy( m_target_cod_istt_acqr, l_TBSW0030.get_COD_ISTT_ACQR( ) );
            //t689066@FIS-END - Data:20/08/2013 - COD_ISTT_ACQR declarado como long ao invez de dect na TBSW0030

            //t689066@FIS-BEGIN - Data:20/08/2013 - COD_ISTT_FRWD declarado como long ao invez de dect na TBSW0030
            fieldSet::fscopy( m_target_cod_istt_frwd, l_TBSW0030.get_COD_ISTT_FRWD( ) );
            //t689066@FIS-END - Data:20/08/2013 - COD_ISTT_FRWD declarado como long ao invez de dect na TBSW0030

            fieldSet::fscopy( m_target_cod_rsps_dtlh_emsr, l_TBSW0030.get_COD_RSPS_DTLH_EMSR( ) );
            fieldSet::fscopy( m_target_cod_rstd_num_cvc_2, l_TBSW0030.get_COD_RSTD_NUM_CVC_2( ) );
            fieldSet::fscopy( m_target_cod_serv_trk_car, l_TBSW0030.get_COD_SERV_TRK_CAR( ) );
            fieldSet::fscopy( m_target_cod_vldc_emsr, l_TBSW0030.get_COD_VLDC_EMSR( ) );
            fieldSet::fscopy( m_target_ind_aut, l_TBSW0030.get_IND_AUT( ) );
            fieldSet::fscopy( m_target_ind_da_rlcd_kmrc, l_TBSW0030.get_IND_DA_RLCD_KMRC( ) );

			fieldSet::fscopy( m_target_COD_TRAN_CAD, l_TBSW0030.get_COD_TRAN_CAD( ) );
			
            // t694446@FIS_BEGIN - Data: 06/01/2014 - 13:35 - Ref. ao BT53.136
               fieldSet::fscopy( m_target_cod_aut_emsr, l_TBSW0030.get_COD_AUT_EMSR( ) );
            // t694446@FIS_END - Data: 06/01/2014 - 13:35 - Ref. ao BT53.136

            // t689721@FIS_BEGIN - Data: 20/02/2014 - Ref. BT55.769
            fieldSet::fscopy( m_target_cod_tran_cad, l_TBSW0030.get_COD_TRAN_CAD( ) );
            // t689721@FIS_END - Data: 20/02/2014 - Ref. BT55.769

            fieldSet::fscopy( m_target_cod_prod_cdst, l_TBSW0030.get_COD_PROD_CDST( ) );
            fieldSet::fscopy( m_target_cod_prod_prcr, l_TBSW0030.get_COD_PROD_PRCR( ) );
            fieldSet::fscopy( indicadorTransacaoTokenizada,  l_TBSW0030.get_IND_TRAN_TKN( ) );
			
            if( !m_target_COD_NTWK_ID_ISSR_ORGL )
            {
                this->enableWarning( true );
                this->setWarningMessage( "Cant find COD_NTWK_ID_ISSR_ORGL to copy field." );
            }
            else
            {
                fieldSet::fscopy( m_target_COD_NTWK_ID_ISSR_ORGL, l_TBSW0030.get_NTWK_ID_ISSR_ORGL( ) );
            }

            if( !m_target_COD_NTWK_ID_ACQR_ORGL )
            {
                this->enableWarning( true );
                this->setWarningMessage( "Cant find COD_NTWK_ID_ACQR_ORGL to copy field." );
            }
            else
            {
                fieldSet::fscopy( m_target_COD_NTWK_ID_ACQR_ORGL, l_TBSW0030.get_NTWK_ID_ACQR_ORGL( ) );
            }

            fieldSet::fscopy( m_cod_ram_mcc, l_TBSW0030.get_COD_RAM_MCC( ) );
            
            // J4_2019 - Release Bandeiras Abril 2019 - INICIO
            fieldSet::fscopy( indicadorPresencaPortador, l_TBSW0030.GetIndicadorPresencaPortador( ) );
            fieldSet::fscopy( indicadorTecnologiaTerminal, l_TBSW0030.GetIndicadorTecnologiaTerminal( ) );
            // J4_2019 - Release Bandeiras Abril 2019 - FIM
        }
    }
    catch( base::GenException e )
    {
      fieldSet::fscopy( m_result, "ERROR", 5 );
      std::string l_msg = "Exception in TBSW0030 <" + std::string( e.what() ) + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }
    catch( std::exception e )
    {
      fieldSet::fscopy( m_result, "ERROR", 5 );
      std::string l_msg = "std::exception in TBSW0030 <" + std::string( e.what() ) + ">";
      this->enableError( true );
      this->setErrorMessage( l_msg );
    }

      a_stop = false;
      return 0;
    }

    TBSW0030Loader& TBSW0030Loader::setTargetFieldPath( const std::string& a_path )
    {
      m_targetFieldPath = a_path;
      return *this;
    }
    TBSW0030Loader& TBSW0030Loader::setSourceFieldPath( const std::string& a_path )
    {
      m_sourceFieldPath = a_path;
      return *this;
    }
    TBSW0030Loader& TBSW0030Loader::setLocalFieldPath( const std::string& a_path )
    {
        m_localFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0030Loader::clone( ) const
    {
      return new TBSW0030Loader(*this);
    }
} //namespace plugins_pdv


