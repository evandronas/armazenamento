#include<dbaccess_pdv/TBSW0093RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
	TBSW0093RegrasFormatacao::TBSW0093RegrasFormatacao( )
	{
	}
	
	TBSW0093RegrasFormatacao::~TBSW0093RegrasFormatacao( )
	{
	}
}