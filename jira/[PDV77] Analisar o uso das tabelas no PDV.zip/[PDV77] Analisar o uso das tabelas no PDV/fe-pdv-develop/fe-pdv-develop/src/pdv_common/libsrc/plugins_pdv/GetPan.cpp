/*
*******************************************************************
* (c) Copyright 2013 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-PDV
/ Descrição:
/ Conteúdo:
/ Autor: t694530, Iuri Fabiano Martins
/ Data de Criação: 2013, 08 de Junho
/ Histórico Mudanças: 2013, 08 de Junho, t694530, Iuri Fabiano Martins, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <sstream>
#include <ctime>
#include <cstring>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/GetPan.hpp"

#include "logger/DebugWriter.hpp"

namespace plugins_pdv
{
	base::Identificable* createGetPan( )
	{
		GetPan* l_new = new GetPan;
		return l_new;
	}
	GetPan::GetPan( )
	{
	}
	GetPan::~GetPan( )
	{
	}
	bool GetPan::startConfiguration( const configBase::Tag* a_tag )
	{
		configBase::TagList l_tagList;
		a_tag->findTag( "sourceFieldPath", l_tagList );
		std::string l_sourcePath = l_tagList.front( ).findProperty( "value" ).value( );
		a_tag->findTag( "targetFieldPath", l_tagList );
		std::string l_targetPath = l_tagList.front( ).findProperty( "value" ).value( );
		this->setSourceFieldPath( l_sourcePath );
		this->setTargetFieldPath( l_targetPath );
		return true;
	}
	bool GetPan::init( )
	{
		
		m_targetField = this->navigate( m_targetFieldPath );
		
		//TRACK2
		m_track2 = this->navigate( m_sourceFieldPath + ".shc_msg.track2" );
		
		//TRACK3
		m_track3 = this->navigate( m_sourceFieldPath + ".shc_msg.track3" );
		
		return true;
	}
	void GetPan::finish( )
	{
	}
	int GetPan::execute( bool& a_stop )
	{
		std::string l_pan, l_track2, l_track3;

		fieldSet::fsextr( l_pan, m_targetField );
		fieldSet::fsextr( l_track2, m_track2 );
		fieldSet::fsextr( l_track3, m_track3 );
     
		if( ( l_pan.length() == 0 ) && ( strlen( l_track2.c_str() ) >= 16 ) )
		{
                    setNewPan( l_track2 );
		}
		else if( ( l_pan.length() == 0 ) && ( strlen( l_track3.c_str() ) >= 16 ) )
		{
                    setNewPan( l_track3.substr( 1 ) );
		}
                else	
                   logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, "GetPan: nao chamou setNewPan... " );

		a_stop = false;
		return 0;
	}
  
	GetPan& GetPan::setSourceFieldPath( const std::string& a_path )
	{
		m_sourceFieldPath = a_path;
		return *this;
	}
	GetPan& GetPan::setTargetFieldPath( const std::string& a_path )
	{
		m_targetFieldPath = a_path;
		return *this;
	}
	dataManip::Command* GetPan::clone( ) const
	{
		return new GetPan( *this );
	}
	
	void GetPan::setNewPan( const std::string& a_newPan )
	{
		int pos;
		char srv_cd[30];

        for( pos = 0; pos < 19; ++pos )
        {
            char carac = a_newPan[pos];
            if( isdigit( carac ) )
            {
                srv_cd[pos] = carac;
            }
            else if( carac == 'D' || carac == 'F' || carac == '=' || carac == '^' )
            {
                break;
            }
            else
            {
                logger::DebugWriter::getInstance()->write( logger::LEVEL_ERROR, "GetPan: nao encontrou delimitador, trilha errada!!! " );
            }
        }
        srv_cd[pos] = '\0';
        
		this->setTargetFieldPath( std::string(srv_cd) );
		fieldSet::fscopy( m_targetField, m_targetFieldPath );
	}
	
}//namespace plugins_pdv

