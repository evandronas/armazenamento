/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pdv::TBSW0156Loader>
/ Descrição: <Arquivo de implementação da classe plugins_pdv::TBSW0156Loader>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: < 698224, Raphael Ferreira Gomes>
/ Data de Criação: <2013, 21 de Fevereiro>
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ . . .
/ <Data, Módulo, Autor, Descrição da Mudança>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "TBSW0156.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0156Loader.hpp"

namespace plugins_pdv
{
 base::Identificable* createTBSW0156Loader()
 {
  TBSW0156Loader* l_new = new TBSW0156Loader;   
  return l_new;
 }

 TBSW0156Loader::TBSW0156Loader()
 {
 }

 TBSW0156Loader::~TBSW0156Loader()
 {
 }
 
 bool TBSW0156Loader::startConfiguration( const configBase::Tag* a_tag )
 {
  configBase::TagList l_tagList;

  a_tag->findTag( "sourceFieldPath", l_tagList );
  this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );
  
  a_tag->findTag( "targetFieldPath", l_tagList );
  this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

  return true;  
 }
 
 bool TBSW0156Loader::init()
 {
    m_result = this->navigate( m_targetFieldPath + ".RESULT" );
	
	COD_TERM = this->navigate( m_sourceFieldPath + ".shc_msg.termid" );
	NUM_STAN = this->navigate( m_sourceFieldPath + ".shc_msg.trace" );
             
	return true;
 }

 void TBSW0156Loader::finish()
 {
 }

 int TBSW0156Loader::execute( bool& a_stop )
 {
  try
  {
		std::string l_string = "";
		unsigned long l_ulong;
		std::ostringstream l_ostring;
		std::ostringstream l_whereClause;
		
		fieldSet::fsextr( l_string, COD_TERM );
		
		fieldSet::fsextr( l_ulong, NUM_STAN );
		l_ostring << l_ulong;
		
		//testes
		/*
		l_string="100000";
		l_ulong = 100;
		l_ostring << l_ulong;
		
		printf("\TBSW0156Loader::execute: COD_TERM: %s\n", l_string.c_str());
		printf("\TBSW0156Loader::execute: NUM_STAN: %s\n", l_ostring.str().c_str());
		*/
		
		l_whereClause << "COD_TERM = '" << l_string << "' AND NUM_STAN = " << l_ostring.str();

		dbaccess_common::TBSW0156 l_TBSW0156( l_whereClause.str() );

		l_TBSW0156.prepare();
		
		l_TBSW0156.execute();
		
		int ret = l_TBSW0156.fetch();
		
		if( !ret )
		{
			fieldSet::fscopy( m_result, "NO ROWS", 7 );
		}
		else
		{
			//apenas informa que o registro ja existe.			
			fieldSet::fscopy( m_result, "OK", 2 );
		}
    
  }  
  catch( base::GenException e )
  {
   fieldSet::fscopy( m_result, "ERROR", 5 );
   std::string l_what( e.what( ) );
   std::string l_msg = "Exception in TBSW0156 Loader <" + l_what + ">";
   this->enableError( true );
   this->setErrorMessage( l_msg );
  }
  catch( std::exception e )
  {
   fieldSet::fscopy( m_result, "ERROR", 5 );
   std::string l_what( e.what( ) );
   std::string l_msg = "std::exception in TBSW0156 Loader <" + l_what + ">";
   this->enableError( true );
   this->setErrorMessage( l_msg );
  }
  a_stop = false;
  return 0;
 }

 TBSW0156Loader& TBSW0156Loader::setSourceFieldPath( const std::string& a_path )
 {
  m_sourceFieldPath = a_path;
  return *this;
 }
 TBSW0156Loader& TBSW0156Loader::setTargetFieldPath( const std::string& a_path )
 {
  m_targetFieldPath = a_path;
  return *this;
 }
 
 dataManip::Command* TBSW0156Loader::clone() const
 {
  return new TBSW0156Loader(*this);
 }
}//namespace standardAcqPlugins


