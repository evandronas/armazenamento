#include "plugins_pdv/ConfirmacaoTBSW0139.hpp"

namespace plugins_pdv
{
    base::Identificable* createConfirmacaoTBSW0139()
    {
        ConfirmacaoTBSW0139* l_new = new ConfirmacaoTBSW0139;
        return l_new;
    }

    bool ConfirmacaoTBSW0139::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_sourcePath = l_tagList.front().findProperty( "value" ).value();
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_targetPath = l_tagList.front().findProperty( "value" ).value();

        this->setSourceFieldPath( l_sourcePath );

        this->setTargetFieldPath( l_targetPath );

        return true;
    }

    ConfirmacaoTBSW0139::ConfirmacaoTBSW0139( )
    {
    }

    ConfirmacaoTBSW0139::~ConfirmacaoTBSW0139( )
    {
    }

    bool ConfirmacaoTBSW0139::init( )
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =      this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_termid =          this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );

        return true;
    }

    void ConfirmacaoTBSW0139::finish()
    {
    }

    int ConfirmacaoTBSW0139::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream  l_whereClause;
            unsigned long   l_local_date = 0;
            std::string     l_termid( "" );

            fieldSet::fsextr( l_local_date,     m_local_date );
            fieldSet::fsextr( l_termid,         m_termid );

            l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND ";
            l_whereClause << "COD_TERM = '" << l_termid << "'";

            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW0139 Confirmacao ==========" );
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, l_whereClause.str( ).c_str( ) );

            dbaccess_common::TBSW0139 l_table0139( l_whereClause.str( ) );
            dbaccess_pdv::TBSW0139RegrasFormatacao regrasFmt;
            struct acq_common::tbsw0139_params params;

            l_table0139.prepare_for_update( );
            l_table0139.execute( );
            int ret = l_table0139.fetch( );

            if ( !ret )
            {
                fieldSet::fscopy( m_result, "NOT UPDATED", 11 );
            }
            else
            {
                params.nom_site_acqr_atlz =  std::string( getenv( "NOM_SITE_ACQR" ) );
                params.nom_host_acqr_atlz =  std::string( getenv( "NOM_HOST_ACQR" ) );
                params.nom_fe_acqr_atlz =    std::string( getenv( "NOM_FE_ACQR" ) );

                regrasFmt.NOM_SITE_ACQR_ATLZ    ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NOM_HOST_ACQR_ATLZ    ( l_table0139, params, acq_common::UPDATE );
                regrasFmt.NOM_FE_ACQR_ATLZ      ( l_table0139, params, acq_common::UPDATE );

                l_table0139.update();
                l_table0139.commit();

                fieldSet::fscopy( m_result, "OK", 2 );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "Exception in TBSW0139 Confirmacao <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_what( e.what( ) );
            std::string l_msg = "std::exception in TBSW0139 Confirmacao <" + l_what + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;

        return 0;
    }

    ConfirmacaoTBSW0139& ConfirmacaoTBSW0139::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    ConfirmacaoTBSW0139& ConfirmacaoTBSW0139::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }

    dataManip::Command* ConfirmacaoTBSW0139::clone() const
    {
        return new ConfirmacaoTBSW0139(*this);
    }

} // namespace plugins_pdv
