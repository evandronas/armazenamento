#include <sstream>
#include <string>
#include <iomanip>
#include<dbaccess_pdv/TBSW0033RegrasFormatacao.hpp>

namespace dbaccess_pdv
{
	TBSW0033RegrasFormatacao::TBSW0033RegrasFormatacao( )
	{
	}

	TBSW0033RegrasFormatacao::~TBSW0033RegrasFormatacao( )
	{
	}

	void TBSW0033RegrasFormatacao::insert_TXT_MSG_1( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
	{
        std::stringstream l_streamstring;
        l_streamstring.str( "" );

        if ( tbsw0033_params.msg_category == "DESFAZIMENTO" || tbsw0033_params.msg_category == "ESTORNO" )
        {
            // STAN
            l_streamstring << std::setw( 6 ) << std::setfill( '0' )  << tbsw0033_params.trace;
    
            // Tipo msg (msgtype)
            l_streamstring << std::setw( 4 ) << std::setfill( '0' )  << tbsw0033_params.origmsg;
            
            // STAN Orig
            l_streamstring << std::setw( 6 ) << std::setfill( '0' )  << tbsw0033_params.origtrace;
            
            // Data MMDD
            if( tbsw0033_params.dataLocalOriginal.length() >= 8)
            {
                l_streamstring << tbsw0033_params.dataLocalOriginal.substr( 4, 4 );
            }
            else
            {
                l_streamstring << "0000";
            }
            
            // Hora HHMMDD
            l_streamstring << std::setw( 6 ) << std::setfill( '0' )  << tbsw0033_params.horaLocalOriginal;
            
            tbsw0033.set_TXT_MSG_1( l_streamstring.str( ) );
        }
        else
        if( tbsw0033_params.msg_name == "CONS_AVS" )
        {
            if( tbsw0033_params.nomeEmissor == "VISA_CREDITO" || tbsw0033_params.nomeEmissor == "VISA_ELECTRON" )
            {
                l_streamstring << "AVS" ;
                l_streamstring << std::setw( 11 )  << std::setfill( '0' )  << tbsw0033_params.cartao.substr( 0, 6 ) ;
                l_streamstring << "        " ;
            }
            else
            if( tbsw0033_params.nomeEmissor == "MASTERCARD"    || tbsw0033_params.nomeEmissor == "MASTER_HIPER_CRT"  ||
                tbsw0033_params.nomeEmissor == "HIPERCARD_CRT" || tbsw0033_params.nomeEmissor == "HIPERCARD_CRT_HMV" ||
                tbsw0033_params.nomeEmissor == "MAESTRO"       || tbsw0033_params.nomeEmissor == "MASTER_HIPER_DBT"  ||
                tbsw0033_params.nomeEmissor == "HIPERCARD_DBT" || tbsw0033_params.nomeEmissor == "HIPERCARD_DBT_HMV" )
            {
                l_streamstring << "AVS" ;
                l_streamstring << "00000000000" ;
                l_streamstring << "        " ;
            }

            if( ( l_streamstring.str( ) ).size( ) > 0 )
            {
                tbsw0033.set_TXT_MSG_1( l_streamstring.str( ) );
            }
        }
	}

	void TBSW0033RegrasFormatacao::insert_TXT_MSG_2( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
	{ 
        if( tbsw0033_params.msg_name == "CONS_AVS" )
        {
            std::string valor = " ";
            valor.append( tbsw0033_params.enderecoFantasia );
            valor.append( "C" );
            valor.append( tbsw0033_params.cpf );
            valor.append( "         " );
            
            tbsw0033.set_TXT_MSG_2( valor );
        }
        else
        {
            tbsw0033.set_TXT_MSG_2( " " );
        }
	}

    void TBSW0033RegrasFormatacao::update_TXT_MSG_1( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
    {
        std::stringstream l_streamstring;
        l_streamstring.str( "" );

        if( tbsw0033_params.nomeEmissor == "CONS_AVS" &&
            ( tbsw0033_params.nomeEmissor == "MASTERCARD"    || tbsw0033_params.nomeEmissor == "MASTER_HIPER_CRT"  ||
              tbsw0033_params.nomeEmissor == "HIPERCARD_CRT" || tbsw0033_params.nomeEmissor == "HIPERCARD_CRT_HMV" ||
              tbsw0033_params.nomeEmissor == "MAESTRO"       || tbsw0033_params.nomeEmissor == "MASTER_HIPER_DBT"  ||
              tbsw0033_params.nomeEmissor == "HIPERCARD_DBT" || tbsw0033_params.nomeEmissor == "HIPERCARD_DBT_HMV" ) )
        {
            l_streamstring << "AVS" ;
            l_streamstring << std::setw( 11 ) << std::setfill( '0' ) << tbsw0033_params.codigoMembroBandeira;
            l_streamstring << "        " ;

             tbsw0033.set_TXT_MSG_1( l_streamstring.str( ) );
        }
    }
    
	void TBSW0033RegrasFormatacao::update_TXT_MSG_2( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
	{ 
        if( tbsw0033_params.msg_name == "CONS_AVS" )
        {
            std::string avs_respcode_ajustado;
            
            if( tbsw0033_params.respcode == "" )
            {
                avs_respcode_ajustado = " ";
            }
            else if( tbsw0033_params.respcode != "A" &&
                     tbsw0033_params.respcode != "N" &&
                     tbsw0033_params.respcode != "S" && 
                     tbsw0033_params.respcode != "U" &&
                     tbsw0033_params.respcode != "W" &&
                     tbsw0033_params.respcode != "X" &&
                     tbsw0033_params.respcode != "Y" &&
                     tbsw0033_params.respcode != "Z" )
            {
                avs_respcode_ajustado = "R";
            }
            else
            {
                avs_respcode_ajustado = tbsw0033_params.respcode;
            }
        
            std::string valor = " ";
            valor.append( tbsw0033_params.enderecoFantasia );
            valor.append( "C" );
            valor.append( tbsw0033_params.cpf );
            valor.append( avs_respcode_ajustado );
            valor.append( "        " );
            
            tbsw0033.set_TXT_MSG_2( valor );
        }
        else
        {
            tbsw0033.set_TXT_MSG_2( " " );
        }
	}
}
