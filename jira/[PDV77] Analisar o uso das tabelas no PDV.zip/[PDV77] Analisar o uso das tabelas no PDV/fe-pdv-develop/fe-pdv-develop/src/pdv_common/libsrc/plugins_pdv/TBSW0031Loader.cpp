#pragma once
#include <cstdio>
#include <ctime>
#include <cstring>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "dbaccess_pdv/TBSW0031RegrasFormatacao.hpp"
#include "plugins_pdv/TBSW0031Loader.hpp"
//TODOSW75 #include "dualHandler.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0031Loader()
    {
        TBSW0031Loader* l_new = new TBSW0031Loader;     
        return l_new;
    }

    TBSW0031Loader::TBSW0031Loader()
    {
    }

    TBSW0031Loader::~TBSW0031Loader()
    {
    }

    bool TBSW0031Loader::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;

        a_tag->findTag( "sourceFieldPath", l_tagList );
        this->setSourceFieldPath( l_tagList.front().findProperty( "value" ).value() );
        
        a_tag->findTag( "targetFieldPath", l_tagList );
        this->setTargetFieldPath( l_tagList.front().findProperty( "value" ).value() );

        return true;
    }
  
    bool TBSW0031Loader::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );
        m_num_adm = this->navigate( m_targetFieldPath + ".NUM_ADM" );
        m_val_mn_car = this->navigate( m_targetFieldPath + ".VAL_MN_CAR" );
        m_cod_ctr = this->navigate( m_targetFieldPath + ".COD_CTR" );
        m_cod_crt_ecm = this->navigate( m_targetFieldPath + ".COD_CRT_ECM" );
        m_dat_mov_tran = this->navigate( m_targetFieldPath + ".DAT_MOV_TRAN" );
        m_num_seq_unc = this->navigate( m_targetFieldPath + ".NUM_SEQ_UNC" );
        m_qtd_dia_crnc = this->navigate( m_targetFieldPath + ".QTD_DIA_CRNC" );           
        m_num_seq_unc_rd_aut = this->navigate( m_targetFieldPath + ".NUM_SEQ_UNC_RD_AUT" );
        m_cod_prod_mtc = this->navigate( m_targetFieldPath + ".COD_PROD_MTC");
        m_cod_rgao_mtc = this->navigate( m_targetFieldPath + ".COD_RGAO_MTC");        
        m_num_ref_tran = this->navigate( m_targetFieldPath + ".NUM_REF_TRAN");        

        m_local_date = this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum = this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_msgtype = this->navigate( m_sourceFieldPath + ".shc_msg.msgtype" );
        m_origdate = this->navigate( m_sourceFieldPath + ".shc_msg.origdate" );
        m_origrefnum = this->navigate( m_sourceFieldPath + ".segments.common.origrefnum" );

        return true;
    }

    void TBSW0031Loader::finish()
    {
    }

    int TBSW0031Loader::execute( bool& a_stop )
    {
        try
        {
            std::ostringstream l_whereClause;
            unsigned long l_local_date, l_origdate,  l_msgtype, l_refnum, l_origrefnum;

            fieldSet::fsextr( l_local_date, m_local_date );
            fieldSet::fsextr( l_refnum, m_refnum );
            fieldSet::fsextr( l_msgtype, m_msgtype );
            fieldSet::fsextr( l_origdate, m_origdate );
            fieldSet::fsextr( l_origrefnum, m_origrefnum );

            switch ( l_msgtype )
            {
                case 100 :
                case 200 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_local_date << " AND NUM_SEQ_UNC = " << l_refnum;
                    break;

                case 220 :
                case 400 :
                case 420 :
                    l_whereClause << "DAT_MOV_TRAN = " << l_origdate << " AND NUM_SEQ_UNC = " << l_origrefnum;
                    break;
                    default:
                    fieldSet::fscopy( m_result, "EMPTY QUERY", 11 );
                    a_stop = false;
                    return 0;
                    break;
            }

            dbaccess_common::TBSW0031 l_TBSW0031( l_whereClause.str() );

            l_TBSW0031.prepare();
            l_TBSW0031.execute();
            //TODOSW75 
            /***
            dbaccess_common::DualHandler l_dualHand( &l_TBSW0031 );
            int ret = l_dualHand.fetch( );
            ***/
            int ret = l_TBSW0031.fetch( );
            if( !ret )
            {
                fieldSet::fscopy( m_result, "NO ROWS", 7 );
            }
            else
            {
                fieldSet::fscopy( m_result, "OK", 2 );

                fieldSet::fscopy( m_num_adm, l_TBSW0031.get_NUM_ADM( ) );
                fieldSet::fscopy( m_cod_ctr, l_TBSW0031.get_COD_CTR( ) );
                fieldSet::fscopy( m_cod_crt_ecm, l_TBSW0031.get_COD_CRT_ECM( ) );
                fieldSet::fscopy( m_dat_mov_tran, l_TBSW0031.get_DAT_MOV_TRAN( ) );
                fieldSet::fscopy( m_qtd_dia_crnc, l_TBSW0031.get_QTD_DIA_CRNC( ) );
                fieldSet::fscopy( m_cod_prod_mtc, l_TBSW0031.get_COD_PROD_MTC( ) );
                fieldSet::fscopy( m_cod_rgao_mtc, l_TBSW0031.get_COD_RGAO_MTC( ) );
                fieldSet::fscopy( m_num_ref_tran, l_TBSW0031.get_NUM_REF_TRAN( ) );

                char l_bufferTemp[64];
                oasis_dec_t l_dec_temp;

                l_dec_temp = l_TBSW0031.get_NUM_SEQ_UNC( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_seq_unc, std::string( l_bufferTemp ) );

                l_dec_temp = l_TBSW0031.get_NUM_SEQ_UNC_RD_AUT( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_num_seq_unc_rd_aut, std::string( l_bufferTemp ) );

                l_dec_temp = l_TBSW0031.get_VAL_MN_CAR( );
                memset( l_bufferTemp, 0, sizeof( l_bufferTemp ) );
                dbm_dectochar_conv( &l_dec_temp, l_bufferTemp, 0 );
                fieldSet::fscopy( m_val_mn_car, std::string( l_bufferTemp ) );
            }
        }
        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0031 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0031 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }
        a_stop = false;
        return 0;
    }

    TBSW0031Loader& TBSW0031Loader::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    TBSW0031Loader& TBSW0031Loader::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0031Loader::clone() const
    {
        return new TBSW0031Loader(*this);
    }

} // namespace plugins_pdv
