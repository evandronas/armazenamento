#pragma once
#include <cstdio>
#include <ctime>
#include <sstream>
#include <shcdef.h>
#include "base/GenException.hpp"
#include "configBase/TagList.hpp"
#include "fieldSet/ConstFieldAccess.hpp"
#include "fieldSet/FieldSet.hpp"
#include "fieldSet/fscopy.hpp"
#include "fieldSet/fsextr.hpp"
#include "plugins_pdv/TBSW0035Inserter.hpp"
#include "dbaccess_pdv/TBSW0035RegrasFormatacao.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace plugins_pdv
{
    base::Identificable* createTBSW0035Inserter()
    {
        TBSW0035Inserter* l_new = new TBSW0035Inserter;
        return l_new;
    }

    TBSW0035Inserter::TBSW0035Inserter()
    {
    }

    TBSW0035Inserter::~TBSW0035Inserter()
    {
    }

    bool TBSW0035Inserter::startConfiguration( const configBase::Tag* a_tag )
    {
        configBase::TagList l_tagList;
        
        a_tag->findTag( "sourceFieldPath", l_tagList );
        std::string l_source = l_tagList.front().findProperty( "value" ).value();
        this->setSourceFieldPath( l_source );

        a_tag->findTag( "targetFieldPath", l_tagList );
        std::string l_target = l_tagList.front().findProperty( "value" ).value();
        this->setTargetFieldPath( l_target );

        return true;
    }

    bool TBSW0035Inserter::init()
    {
        m_result = this->navigate( m_targetFieldPath + ".RESULT" );

        m_local_date =          this->navigate( m_sourceFieldPath + ".shc_msg.local_date" );
        m_refnum =              this->navigate( m_sourceFieldPath + ".shc_msg.refnum" );
        m_num_bxa_tec =         this->navigate( m_sourceFieldPath + ".segments.adm.num_bxa_tec" );
        m_in_tpo_tcn =          this->navigate( m_sourceFieldPath + ".segments.merchant.in_tpo_tcn" );
        m_termloc =             this->navigate( m_sourceFieldPath + ".shc_msg.termloc" );      
        m_termid =              this->navigate( m_sourceFieldPath + ".segments.common.terminal_pdv" );
        m_num_sre_term =        this->navigate( m_sourceFieldPath + ".segments.adm.num_sre_term" );
        m_num_sre_pnpd_ext =    this->navigate( m_sourceFieldPath + ".segments.adm.num_sre_pnpd_ext" );
        m_cod_id_pnpd =         this->navigate( m_sourceFieldPath + ".segments.adm.cod_id_pnpd" );
        m_cod_aplv_pnpd =       this->navigate( m_sourceFieldPath + ".segments.adm.cod_aplv_pnpd" );
        m_cod_vers_sftw =       this->navigate( m_sourceFieldPath + ".segments.merchant.cod_vers_sftw" );       
        m_nom_modl_chip =       this->navigate( m_sourceFieldPath + ".segments.adm.nom_modl_chip" );
        m_num_sre_smcrd =       this->navigate( m_sourceFieldPath + ".segments.adm.num_sre_smcrd" );
        m_nom_oper =            this->navigate( m_sourceFieldPath + ".segments.adm.nom_oper" );
        m_cod_ip_prmi =         this->navigate( m_sourceFieldPath + ".segments.adm.cod_ip_prmi" );
        m_num_prta_prmi =       this->navigate( m_sourceFieldPath + ".segments.adm.num_prta_prmi" );
        m_cod_ip_secd =         this->navigate( m_sourceFieldPath + ".segments.adm.cod_ip_secd" );
        m_num_prta_secd =       this->navigate( m_sourceFieldPath + ".segments.adm.num_prta_secd" );
        m_nom_url_cnfr =        this->navigate( m_sourceFieldPath + ".segments.adm.nom_url_cnfr" );
        m_qtd_tran_gprs_prmi =  this->navigate( m_sourceFieldPath + ".segments.adm.qtd_tran_gprs_prmi" );
        m_qtd_tran_gsm_prmi =   this->navigate( m_sourceFieldPath + ".segments.adm.qtd_tran_gsm_prmi" );
        m_qtd_tran_gprs_secd =  this->navigate( m_sourceFieldPath + ".segments.adm.qtd_tran_gprs_secd" );
        m_qtd_tran_gsm_secd =   this->navigate( m_sourceFieldPath + ".segments.adm.qtd_tran_gsm_secd" );
        m_qtd_tnta_prmi =       this->navigate( m_sourceFieldPath + ".segments.adm.qtd_tnta_prmi" );
        m_qtd_tnta_secd =       this->navigate( m_sourceFieldPath + ".segments.adm.qtd_tnta_secd" );
       
		// t689049
        m_bit63 =               this->navigate( m_sourceFieldPath + ".segments.common.bit63" );
        return true;
    }

    void TBSW0035Inserter::finish()
    {
    }

    int TBSW0035Inserter::execute( bool& a_stop )
    {
        try
        {
            dbaccess_common::TBSW0035 l_table0035;
            logger::DebugWriter::getInstance( )->write( logger::LEVEL_DEBUG, "Inserting in TBSW0035" );
            dbaccess_pdv::TBSW0035RegrasFormatacao regrasFmt;

            unsigned long   l_local_date = 0;
            unsigned long   l_refnum = 0;
            std::string     l_num_bxa_tec( "" );
            std::string     l_in_tpo_tcn( "" );
            unsigned long   l_termloc = 0;            
            std::string     l_termid( "" );
            std::string     l_num_sre_term( "" );
            std::string     l_num_sre_pnpd_ext( "" );
            std::string     l_cod_id_pnpd( "" );
            std::string     l_cod_aplv_pnpd( "" );
            std::string     l_cod_vers_sftw( "" );           
            std::string     l_nom_modl_chip( "" );
            std::string     l_num_sre_smcrd( "" );
            std::string     l_nom_oper( "" );
            std::string     l_cod_ip_prmi( "" );
            unsigned long   l_num_prta_prmi = 0;
            std::string     l_cod_ip_secd( "" );
            unsigned long   l_num_prta_secd = 0;
            std::string     l_nom_url_cnfr( "" );
            unsigned long   l_qtd_tran_gprs_prmi = 0;
            unsigned long   l_qtd_tran_gsm_prmi = 0;
            unsigned long   l_qtd_tran_gprs_secd = 0;
            unsigned long   l_qtd_tran_gsm_secd = 0;
            unsigned long   l_qtd_tnta_prmi = 0;
            unsigned long   l_qtd_tnta_secd = 0;
           
			// t689049
			std::string     l_bit63( "" );

            fieldSet::fsextr( l_local_date,         m_local_date );
            fieldSet::fsextr( l_refnum,             m_refnum );
            fieldSet::fsextr( l_num_bxa_tec,        m_num_bxa_tec );
            fieldSet::fsextr( l_in_tpo_tcn,         m_in_tpo_tcn );
            fieldSet::fsextr( l_termloc,            m_termloc );
            fieldSet::fsextr( l_termid,             m_termid );
            fieldSet::fsextr( l_num_sre_term,       m_num_sre_term );
            fieldSet::fsextr( l_num_sre_pnpd_ext,   m_num_sre_pnpd_ext );
            fieldSet::fsextr( l_cod_id_pnpd,        m_cod_id_pnpd );
            fieldSet::fsextr( l_cod_aplv_pnpd,      m_cod_aplv_pnpd );
            fieldSet::fsextr( l_cod_vers_sftw,      m_cod_vers_sftw );
            fieldSet::fsextr( l_nom_modl_chip,      m_nom_modl_chip );
            fieldSet::fsextr( l_num_sre_smcrd,      m_num_sre_smcrd );
            fieldSet::fsextr( l_nom_oper,           m_nom_oper );
            fieldSet::fsextr( l_cod_ip_prmi,        m_cod_ip_prmi );
            fieldSet::fsextr( l_num_prta_prmi,      m_num_prta_prmi );
            fieldSet::fsextr( l_cod_ip_secd,        m_cod_ip_secd );
            fieldSet::fsextr( l_num_prta_secd,      m_num_prta_secd );
            fieldSet::fsextr( l_nom_url_cnfr,       m_nom_url_cnfr );
            fieldSet::fsextr( l_qtd_tran_gprs_prmi, m_qtd_tran_gprs_prmi );
            fieldSet::fsextr( l_qtd_tran_gsm_prmi,  m_qtd_tran_gsm_prmi );
            fieldSet::fsextr( l_qtd_tran_gprs_secd, m_qtd_tran_gprs_secd );
            fieldSet::fsextr( l_qtd_tran_gsm_secd,  m_qtd_tran_gsm_secd );
            fieldSet::fsextr( l_qtd_tnta_prmi,      m_qtd_tnta_prmi );
            fieldSet::fsextr( l_qtd_tnta_secd,      m_qtd_tnta_secd );

			//t689049
			fieldSet::fsextr( l_bit63,              m_bit63 );

            struct acq_common::tbsw0035_params params = { 0 };

            params.local_date =              l_local_date;
            params.refnum =                  l_refnum;
            params.adm_num_bxa_tec =         l_num_bxa_tec;
            params.merchant_in_tpo_tcn =     l_in_tpo_tcn;
            params.termloc =                 l_termloc;
            params.termid =                  l_termid;
            params.adm_num_sre_term =        l_num_sre_term;
            params.adm_num_sre_pnpd_ext =    l_num_sre_pnpd_ext;
            params.adm_cod_id_pnpd =         l_cod_id_pnpd;
            params.adm_cod_aplv_pnpd =       l_cod_aplv_pnpd;
            params.merchant_cod_vers_sftw =  l_cod_vers_sftw;
            params.adm_nom_modl_chip =       l_nom_modl_chip;
            params.adm_num_sre_smcrd =       l_num_sre_smcrd;
            params.adm_nom_oper =            l_nom_oper;
            params.adm_cod_ip_prmi =         l_cod_ip_prmi;
            params.adm_num_prta_prmi =       l_num_prta_prmi;
            params.adm_cod_ip_secd =         l_cod_ip_secd;
            params.adm_num_prta_secd =       l_num_prta_secd;
            params.adm_nom_url_cnfr =        l_nom_url_cnfr;
            params.adm_qtd_tran_gprs_prmi =  l_qtd_tran_gprs_prmi;
            params.adm_qtd_tran_gsm_prmi =   l_qtd_tran_gsm_prmi;
            params.adm_qtd_tran_gprs_secd =  l_qtd_tran_gprs_secd;
            params.adm_qtd_tran_gsm_secd =   l_qtd_tran_gsm_secd;
            params.adm_qtd_tnta_prmi =       l_qtd_tnta_prmi;
            params.adm_qtd_tnta_secd =       l_qtd_tnta_secd;

			// t689049
            params.bit63 =                   l_bit63;

            regrasFmt.DAT_MOV_TRAN       ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_SEQ_UNC        ( l_table0035, params, acq_common::INSERT );
            regrasFmt.DTH_BXA_TEC        ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_BXA_TEC        ( l_table0035, params, acq_common::INSERT );
            regrasFmt.TIP_TCNL           ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_ORDM_SERV      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_OCOR           ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_ESTB           ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NOM_FNTS_PT_DE_VD  ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_TEL_ESTB       ( l_table0035, params, acq_common::INSERT );
            regrasFmt.TXT_ENDR_ESTB      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_TERM           ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_SRE_TERM       ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_SRE_PNPD_EXT   ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_ID_PNPD        ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_APLV_PNPD      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_VERS_SFTW      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_VERS_KRN       ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NOM_MODL_CHIP      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_SRE_SMCRD      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NOM_OPER           ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_ID_TEC         ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_EPS            ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_IP_PRMI        ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_PRTA_PRMI      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_IP_SECD        ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_PRTA_SECD      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NOM_URL_CNFR       ( l_table0035, params, acq_common::INSERT );
            regrasFmt.QTD_TRAN_GPRS_PRMI ( l_table0035, params, acq_common::INSERT );
            regrasFmt.QTD_TRAN_GSM_PRMI  ( l_table0035, params, acq_common::INSERT );
            regrasFmt.QTD_TRAN_GPRS_SECD ( l_table0035, params, acq_common::INSERT );
            regrasFmt.QTD_TRAN_GSM_SECD  ( l_table0035, params, acq_common::INSERT );
            regrasFmt.COD_STTU_RPLC      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.QTD_TNTA_PRMI      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.QTD_TNTA_SECD      ( l_table0035, params, acq_common::INSERT );
            regrasFmt.NUM_TEL_ADIC_ESTB  ( l_table0035, params, acq_common::INSERT );

            l_table0035.insert( );
            l_table0035.commit( );

            fieldSet::fscopy( m_result, "OK", 2 );
        }

        catch( base::GenException e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "Exception in TBSW0035 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        catch( std::exception e )
        {
            fieldSet::fscopy( m_result, "ERROR", 5 );
            std::string l_msg = "std::exception in TBSW0035 <" + std::string( e.what() ) + ">";
            this->enableError( true );
            this->setErrorMessage( l_msg );
        }

        a_stop = false;
        return 0;
    }

    TBSW0035Inserter& TBSW0035Inserter::setSourceFieldPath( const std::string& a_path )
    {
        m_sourceFieldPath = a_path;
        return *this;
    }
    
    TBSW0035Inserter& TBSW0035Inserter::setTargetFieldPath( const std::string& a_path )
    {
        m_targetFieldPath = a_path;
        return *this;
    }

    dataManip::Command* TBSW0035Inserter::clone() const
    {
        return new TBSW0035Inserter(*this);
    }

} // namespace plugins_pdv