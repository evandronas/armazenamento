
#ifndef __DB_OBJECT_H__
#define __DB_OBJECT_H__

static char _db_object_h_what[] = "@(#) db_object.h 1.4 09/12/16 10:26:24";

#include <stl/map.h>
#include <swgen/swtrace.h>
#include <swgen/dbexception.h>
#include <swgen/storage_dev.h>
#include <swgen/statement.h>

namespace SWITCH
{
#define MAX_VARCHAR 512

class db_object
{
protected: 
	db_object(); // Using standard storage device
	db_object( storage_dev &stdev ); // Using a specific storage device
	virtual ~db_object();

	void handle_fetch( void );	// Perform some conversion in types that 
								// are not supported by DBM low level API such as
								// OCString and OCMoney

	void bind_resultset( void );


	void handle_parameters( void );	// Perform some conversion in types that 
									// are not supported by DBM low level API such as
									// OCString and OCMoney
	void bind_parameters( void );

public:
	virtual void prepare( void ) throw( dbexception );
	virtual void prepare( statement * ) throw( dbexception );
	void execute( void ) throw ( dbexception );
	virtual bool fetch( void ) throw ( dbexception );
	virtual void close_fetch( void ) throw ( dbexception );

	void commit( void ) throw ( dbexception );
	void rollback( void ) throw ( dbexception );


	bool is_null( int &var ) const throw ();
	bool is_null( char &var ) const throw ();
	bool is_null( char *var ) const throw ();
	bool is_null( OCString &var ) const throw ();
	bool is_null( OCDateTime &var ) const throw ();
	bool is_null( unsigned int &var ) const throw ();
	bool is_null( unsigned char &var ) const throw ();
	bool is_null( long &var ) const throw ();
	bool is_null( unsigned long &var ) const throw ();
	bool is_null( float &var ) const throw ();
	bool is_null( double &var ) const throw ();
	bool is_null( oasis_dec_t &var ) const throw ();

	
	void bind( const unsigned int pos, int &var ) throw ( swexception, dbexception );
	void bind( const unsigned int pos, char &var ) throw ( swexception, dbexception );
	void bind( const unsigned int pos, char *var, const size_t capacity ) throw ( swexception, dbexception );
	void bind( const unsigned int pos, OCString &var, const size_t capacity=MAX_VARCHAR  ) throw ( swexception, dbexception );
	void bind( const unsigned int pos, unsigned int &var ) throw ( swexception, dbexception );
	void bind( const unsigned int pos, unsigned char &var ) throw ( swexception, dbexception );
	void bind( const unsigned int pos, long &var ) throw ( swexception, dbexception );
	void bind( const unsigned int pos, unsigned long &var ) throw ( swexception, dbexception );
//	void bind( const unsigned int pos, unsigned long long &var ) throw ( dbexception );
	void bind( const unsigned int pos, float &var ) throw ( swexception, dbexception );
	void bind( const unsigned int pos, double &var ) throw ( swexception, dbexception );
//	void bind( const unsigned int pos, OCDecimal &var ) throw ( dbexception );
//	void bind( const unsigned int pos, OCMoney &var ) throw ( dbexception );
	void bind( const unsigned int pos, OCDateTime &var ) throw ( dbexception );
	void bind( const unsigned int pos, oasis_dec_t &var ) throw ( swexception, dbexception );

protected:
	trace_stream &deb;
	bool is_null( void *ptr ) const;

	virtual void bind_columns( void );
	int rec_num;

	virtual OCString get_sql_statement( void ) = 0;

	void clean_output_bindings( void );

	bool stmt_is_prepared( void ) throw ();
	bool stmt_is_executed( void ) throw ();
	bool resultset_is_valid( void ) throw ();
	statement *get_stmt( void ) throw ();
	storage_dev *get_stdev( void ) throw ();
	connection *get_connection( void ) throw ();

	// For derived classes to perform some action 
	virtual void do_release_bindings( void );
	virtual void do_release_statement( void );

	char *get_buff( const OCString &var, const size_t capacity );
	void register_buff_in( OCString &var, char *str, size_t len );
	void register_buff_out( OCString &var, char *str, size_t len );
	void handle_OCString_out( void );
	void handle_OCString_in( void );

	time_t *get_buff( const OCDateTime &var );
	void register_buff_in( OCDateTime &var, time_t *str );
	void register_buff_out( OCDateTime &var, time_t *str );
	void handle_OCDateTime_out( void );
	void handle_OCDateTime_in( void );

	virtual int translate_pos( int pos ) const throw();

	statement *stmt;

	bool is_valid( void ) const throw();

	void release_bindings( void );
	void release_statement( void );
	connection *conn;

private:
	bool result_is_valid;
	
	typedef map<int, int*> status_t;
	status_t vstatus;

	typedef map<void*, int*> status_by_ptr_t;
	status_by_ptr_t vstatus_by_ptr;

	typedef struct 
	{
		char *ptr;
		size_t allocated_len;
	} ptr_len_t;
	typedef map<OCString *, ptr_len_t *> string_bindings_t;
	string_bindings_t str_binds_in;
	string_bindings_t str_binds_out;

	typedef map<OCDateTime *, time_t *> time_bindings_t;
	time_bindings_t time_binds_in;
	time_bindings_t time_binds_out;

	storage_dev &stdev;

	bool is_prepared;
	bool is_executed;
};

}

#endif // __DB_OBJECT_H__
