	
#ifndef __STPROC_H__
#define __STPROC_H__

static char _stproc_h_what[] = "@(#) stfunc.h 1.2 09/02/17 11:30:16";

#include <stl/map.h>
#include <oc/oc_exception.h>
#include <swgen/swtrace.h>
#include <swgen/dbexception.h>
#include <swgen/storage_dev.h>
#include <swgen/statement.h>
#include <swgen/db_object.h>
#include <swgen/resultset.h>


namespace SWITCH
{

//! \class stfunc.
/*!
	\brief Responsible for Stored Procedure call, Pipelined Table Function call and Stored Function call.

	\details 
	\details This module makes use of assertions. In order to activate assertions during development 
	\details process, create an environment variable SW_DEBUG as follows:
	\details 
	\details export SW_DEBUG=-DSW_DEBUGON
	\details 
	\details Then add it to the CPPFLAGS directive on your Makefile :
	\details 
	\details CPPFLAGS=$(SW_DEBUG) ...   
	\details 
	\details By doing that, assertions will only work when you compile on your own environment.
	\details 
*/

class stfunc : public db_object
{
public:
	//! Constructor.
	/*!
		\param stdev	Use a specific database connection.
		\param funcname	Database function / procedure to be called.
	*/
	stfunc( storage_dev &stdev, const OCString &funcname );

	//! Constructor.
	/*!
		\param funcname	Database function / procedure to be called.
	*/
	stfunc( const OCString &funcname );

	virtual ~stfunc();

	typedef enum { RESULTSET, SINGLE_VALUE, NONE } ret_t;


	//! Return value binding.
	/*!
		Bind Pipelined Table Functions' resultset.

		\param res	ONLY Pipelined table functions returns resultsets
		\attention  This function must be called BEFORE bind_param()
		\sa resultset
	*/
	void bind_ret( resultset &res ) throw ( OCException, swexception, dbexception );


	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( short &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( int &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( char &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\param size	Maximum length allowed for a return value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( char *var, const size_t size ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( unsigned short &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( unsigned int &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( unsigned char &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( long &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( unsigned long &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( float &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( double &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\attention  This function must be called BEFORE bind_param()
	*/
	void bind_ret( oasis_dec_t &var ) throw ( OCException, swexception, dbexception );

	//! Return value binding.
	/*!
		Bind Stored Functions return value.

		\param var	Variable name to hold the resulting value
		\param max_len	Maximum length allowed for a return value (optional)
		\attention  This function must be called BEFORE bind_param()
		\attention  Return value will be truncated whenever its length is longer than max_len.
	*/
	void bind_ret( OCString &var, const size_t max_len=MAX_VARCHAR  ) throw ( OCException, swexception, dbexception );



	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, short &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, int &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, char &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, char *var, const size_t size ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, unsigned short &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, unsigned int &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, unsigned char &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, long &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, unsigned long &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, float &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, double &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, oasis_dec_t &var ) throw ( OCException, swexception, dbexception );

	//! Parameter binding.
	/*!
		Bind Stored Functions / Procedures parameters.

		\param pos	Parameter position.
		\param var	Binding variable name.
		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  Parameter bindings are ALWAYS INPUT PARAMETERS
	*/
	void bind_param( const unsigned int pos, OCString &var, const size_t max_len=MAX_VARCHAR  ) throw ( OCException, swexception, dbexception );

	//! Prepare database statement.
	/*!
		Performs database PREPARE statement.

		\details	A database statement is "prepared" once, then can be executed n times.

		\attention  This function must be called AFTER bind_ret(), except for stored procedures
		\attention  This function must be called AFTER bind_param()

	*/
	void prepare( void ) throw( dbexception );


protected:
	OCString function;
	virtual OCString get_sql_statement( void ) throw( dbexception );
	OCString get_funcname( const OCString &fname );
	bool any_binding_exists( void ) const throw();
	void add_parameter( void );
	void bind_columns( void );

private:
	void init( void );
	OCString get_bindparams_str( void );
	ret_t retval_binding_type;
	OCString bindparams_str;
	int translate_pos( int pos ) throw();
	bool parameter_binding_exists;
	resultset *res;
};

}

#endif // __STPROC_H__
