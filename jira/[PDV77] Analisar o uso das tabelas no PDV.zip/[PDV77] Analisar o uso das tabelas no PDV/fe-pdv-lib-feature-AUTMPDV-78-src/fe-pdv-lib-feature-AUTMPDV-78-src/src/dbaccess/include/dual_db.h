
#ifndef __DUAL_DB_H__
#define __DUAL_DB_H__

static char _dual_db_h_what[] = "@(#) dual_db.h 1.2 09/02/17 11:30:10";

#include <swgen/storage_dev.h>
#include <swgen/connection.h>

namespace SWITCH
{

class dual_db : public storage_dev 
{
public:
	connection *get_first( void );
	connection *get_next( void );
};

}

#endif // __DUAL_DB_H__
