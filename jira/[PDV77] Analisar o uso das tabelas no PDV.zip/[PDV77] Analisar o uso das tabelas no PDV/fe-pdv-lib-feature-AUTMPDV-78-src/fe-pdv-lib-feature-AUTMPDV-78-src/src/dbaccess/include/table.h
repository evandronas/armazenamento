
#ifndef __TABLE_H__
#define __TABLE_H__

static char _table_h_what[] = "@(#) table.h 1.2 09/02/17 11:30:19";

#include <stl/map.h>
#include <swgen/db_object.h>
#include <swgen/swtrace.h>
#include <swgen/dbexception.h>
#include <swgen/storage_dev.h>
#include <swgen/statement.h>

namespace SWITCH
{

class table : public db_object
{
public:
	table(); 
	table( storage_dev &stdev ); // Using a specific storage device
	virtual ~table();

	void prepare_for_update( void ) throw( dbexception );
	void insert( void ) throw( dbexception );
	void update( void ) throw( dbexception );
	void delete_record( void ) throw( dbexception );
	void prepare_insert( void ) throw( dbexception );
	typedef enum { SELECT, INSERT, UPDATE, DELETE, NONE } operation_t;
	void prepare( void ) throw( dbexception );
	void CloseCursor( void ) throw( dbexception );

protected:
	OCString query_fields;
	OCString table_name;
	OCString where_condition;

	virtual OCString get_sql_statement( void ) throw( dbexception );
	virtual OCString get_sql_insert( void ) throw( dbexception );
	virtual OCString get_sql_select( void ) throw( dbexception );
	virtual OCString get_sql_update( void ) throw( dbexception );
	virtual OCString get_sql_delete( void ) throw( dbexception );

	void prepare_update( void ) throw( dbexception );
	void prepare_delete( void ) throw( dbexception );

	void execute_update( void ) throw( dbexception );
	void execute_delete( void ) throw( dbexception );
	void execute_insert( void ) throw( dbexception );

	virtual void close_fetch( void ) throw ( dbexception );
	virtual void bind_params( void ) throw ( dbexception );

	virtual OCString parse_fields_for_update( const OCString &query_fields ) const throw ( dbexception ) ;
	virtual OCString get_insert_values_string( const OCString &query_fields ) const throw ( dbexception ) ;

	// Called by db_object whenever db_object::release_bindings()  
	// and db_object::release_statements() are executed.
	virtual void do_release_bindings( void );
	virtual void do_release_statement( void );

	void set_operation( operation_t op );
	operation_t get_operation( void );

	void handle_bindings( void );


private:
	statement *upd_stmt;
	statement *ins_stmt;
	statement *del_stmt;

	bool update_already_prepared;
	bool insert_already_prepared;
	bool delete_already_prepared;

	void release_update_statement( void );
	void release_insert_statement( void );
	void release_delete_statement( void );

	OCString update_addendum;
	operation_t operation;

};

}

#endif // __TABLE_H__
