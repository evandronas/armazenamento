
#ifndef __CONNECTION_H__
#define __CONNECTION_H__

static char _connection_h_what[] = "@(#) connection.h 1.1 08/07/30 14:55:30";

#include <stl/list.h>
#include <DBM3.h>
#include <swgen/swtrace.h>
#include <swgen/dbexception.h>


namespace SWITCH
{

class connection
{
public:
	connection();
	virtual ~connection();

	void connect( void ) throw( dbexception ) ; // Connect using istparam.cfg information
	void connect( const OCString &server, const OCString &user,
					const OCString &password ) throw( dbexception ) ;

	void disconnect( void ) throw( dbexception );

	DBMHSTMT *get_new_statement( void );
	void drop_statement( DBMHSTMT *stmt );


	void commit( void ) throw ( dbexception );
	void rollback( void ) throw ( dbexception );


private:
	DBMHDBC conn;
	typedef list<DBMHSTMT> statements_t;
	statements_t statements;

	void drop_statements( void );

protected:
	trace_stream &trace;

};

}

#endif // __CONNECTION_H__
