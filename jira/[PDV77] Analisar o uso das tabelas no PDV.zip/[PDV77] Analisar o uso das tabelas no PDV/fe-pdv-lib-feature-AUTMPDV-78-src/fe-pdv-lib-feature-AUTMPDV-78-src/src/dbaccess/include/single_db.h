
#ifndef __SINGLE_DB_H__
#define __SINGLE_DB_H__

static char _single_db_h_what[] = "@(#) single_db.h 1.3 09/08/04 16:57:15";

#include <swgen/storage_dev.h>
#include <swgen/connection.h>

namespace SWITCH
{

class single_db : public storage_dev 
{
private:
	single_db();
	~single_db();

	// Singleton
	static single_db *_Instance;

	connection *conn;

public:
	
	static single_db *get_instance( void );
	
	connection *get_first( void );
	connection *get_next( void );
};

}

#endif // __SINGLE_DB_H__
