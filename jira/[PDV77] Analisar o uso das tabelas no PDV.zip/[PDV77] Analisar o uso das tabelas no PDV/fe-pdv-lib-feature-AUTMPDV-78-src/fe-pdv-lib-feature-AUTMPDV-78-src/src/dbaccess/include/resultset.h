
#ifndef __RESULTSET_H__
#define __RESULTSET_H__

static char _resultset_h_what[] = "@(#) resultset.h 1.3 09/12/16 10:26:28";

#include <stl/map.h>
#include <swgen/db_object.h>
#include <swgen/swtrace.h>
#include <swgen/dbexception.h>
#include <swgen/storage_dev.h>
#include <swgen/statement.h>

namespace SWITCH
{


//! \class resultset.
/*!
	\brief Responsible for Resultset handling (Pipelined Table Function).

	\details 
	\details This module makes use of assertions. In order to activate assertions during development 
	\details process, create an environment variable SW_DEBUG as follows:
	\details 
	\details export SW_DEBUG=-DSW_DEBUGON
	\details 
	\details Then add it to the CPPFLAGS directive on your Makefile :
	\details 
	\details CPPFLAGS=$(SW_DEBUG) ...   
	\details 
	\details By doing that, assertions will only work when you compile on your own environment.
	\details 
*/

class resultset 
{
public:
	resultset(); 
	//resultset( storage_dev &stdev ); // Using a specific storage device
	virtual ~resultset();
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, int &var ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, char &var ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, char *var, const size_t capacity ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
		\param capacity	Maximum length allowed for var.
		\attention  Resulting value will be truncated whenever its length is longer than capacity.
	*/
	void bind_col( const OCString &field, OCString &var, const size_t capacity=MAX_VARCHAR  ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
		\attention		New datatype OCDateTime
	*/
	void bind_col( const OCString &field, OCDateTime &var ) throw ( swexception, dbexception );
	

	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, unsigned int &var ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, unsigned char &var ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, long &var ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, unsigned long &var ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, float &var ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, double &var ) throw ( swexception, dbexception );
	
	//! Column binding.
	/*!
		Bind Pipelined Table Functions' resultset column.

		\param field	Field name to bind.
		\param var		Variable name.
	*/
	void bind_col( const OCString &field, oasis_dec_t &var ) throw ( swexception, dbexception );

	OCString get_query_fields( void );

	void set_current_db_object( db_object *ob ) throw();

	//! Performs database Fetch command.
	/*!
		Performs database Fetch for a Pipelined Table Function' Resultset.

		\return  true	There're more rows in resultset.
		\return  false	There're no more rows in resultset.
		\attention  This function must be called AFTER execute()
	*/
	bool fetch( void ) throw ( dbexception );

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( int &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( char &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( char *var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( OCString &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( OCDateTime &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( unsigned int &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( unsigned char &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( long &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( unsigned long &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( float &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( double &var ) const throw ();

	//! Checks whether a bind variable is NULL or not.
	/*!
		Checks whether a bind variable is NULL or not.

		\return  true	The variable (column) is NULL for the current row.
		\return  false	The variable (column) is NOT NULL for the current row.
	*/
	bool is_null( oasis_dec_t &var ) const throw ();

protected:
	trace_stream &deb;
	OCString query_fields;
	int last_field_nbr;

	int add_new_field( const OCString &field ); 
	virtual void close_fetch( void ) throw ( dbexception );

	db_object *db_obj;

};

}

#endif // __RESULTSET_H__
