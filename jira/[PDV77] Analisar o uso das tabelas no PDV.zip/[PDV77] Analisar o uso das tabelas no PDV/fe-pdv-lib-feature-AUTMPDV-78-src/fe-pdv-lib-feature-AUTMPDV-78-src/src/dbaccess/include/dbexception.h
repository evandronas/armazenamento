
#ifndef __DBEXCEPTION_H__
#define __DBEXCEPTION_H__

static char _dbexception_h_what[] = "@(#) dbexception.h 1.2 09/02/17 11:30:09";

#include<DBM3.h>
#include<oc/oc_string.h>
#include<swgen/swexception.h>


namespace SWITCH
{

class dbexception : public swexception
{
public:
	explicit dbexception( const OCString &msg );
	explicit dbexception( const OCString &method, 
		const DBMHANDLE handle, const bool is_connection = false );

};

}

#endif // __EXCEPTION_H__
