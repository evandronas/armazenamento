
#ifndef __STATEMENT_H__
#define __STATEMENT_H__

static char _statement_h_what[] = "@(#) statement.h 1.3 09/12/16 10:26:29";

#include <stl/map.h>
#include <oc/oc_string.h>
#include <swgen/swtrace.h>
#include <swgen/connection.h>

namespace SWITCH
{

class statement
{
public:
	statement( connection &c ) throw ( dbexception );
	virtual ~statement();

	void bind( const unsigned int pos, short &var, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, int &var, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, char &var, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, char *var, const size_t capacity, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, time_t *var, int *status ) throw ( dbexception );
//	void bind( const unsigned int pos, OCString &var ) throw ( dbexception );
	void bind( const unsigned int pos, unsigned short &var, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, unsigned int &var, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, unsigned char &var, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, long &var, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, unsigned long &var, int *status ) throw ( dbexception );
//	void bind( const unsigned int pos, long long &var, int &status ) throw ( dbexception );
//	void bind( const unsigned int pos, unsigned long long &var, int &status ) throw ( dbexception );
	void bind( const unsigned int pos, float &var, int *status ) throw ( dbexception );
	void bind( const unsigned int pos, double &var, int *status ) throw ( dbexception );
//	void bind( const unsigned int pos, OCDecimal &var ) throw ( dbexception );
//	void bind( const unsigned int pos, OCMoney &var ) throw ( dbexception );
	void bind( const unsigned int pos, oasis_dec_t &var, int *status ) throw ( dbexception );

//	void bind( const unsigned int pos, long long &var ) throw ( dbexception );
//	void bind( const unsigned int pos, long long &var ) throw ( dbexception );

	void bind_param( const unsigned int pos, short &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, int &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, char &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, char *var, const size_t size, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, unsigned short &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, unsigned int &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, unsigned char &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, long &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, unsigned long &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, float &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, double &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
	void bind_param( const unsigned int pos, oasis_dec_t &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
//	void bind_param( const unsigned int pos, OCString &var, int inout = DBM_PARAM_INPUT ) throw ( dbexception );
//	void bind_param( const unsigned int pos, const OCString &var ) throw ( dbexception );


	void prepare( const OCString &str ) throw ( dbexception );
	void execute( void ) throw ( dbexception );
	bool fetch( void ) throw ( dbexception );

	// prepare_positioned() for "update" purposes
	void prepare_positioned( statement *pstmt, const OCString &sql ) throw (dbexception);

	void commit( void ) throw ( dbexception );
	void rollback( void ) throw ( dbexception );
	void close( void ) throw ( dbexception );

protected:
	trace_stream &deb;
	DBMHSTMT *stmt;
	connection *con;

	void handle_retval( const char *, const DBMRETURN ret );


public:
	// Binding information
	typedef struct
	{
		int type;
		void *buff;
		int buff_len;
		int *status;
	} bind_t;

	typedef map<int, bind_t> bindings_t;

	//const bindings_t::iterator get_begin_bind( void ) const;
	//const bindings_t::iterator get_end_bind( void ) const;


protected:
	bindings_t bindings;

public:
	void positioned_upd_bind( statement *stmt );

};

}

#endif // __STATEMENT_H__
