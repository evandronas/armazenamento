
#ifndef __DBACCESS_H__
#define __DBACCESS_H__

static char _dbaccess_h_what[] = "@(#) dbaccess.h 1.2 09/02/17 11:30:08";


#include <swgen/table.h>
#include <swgen/db_object.h>
#include <swgen/storage_dev.h>
#include <swgen/single_db.h>
#include <swgen/stfunc.h>

#endif // __DBACCESS_H__
