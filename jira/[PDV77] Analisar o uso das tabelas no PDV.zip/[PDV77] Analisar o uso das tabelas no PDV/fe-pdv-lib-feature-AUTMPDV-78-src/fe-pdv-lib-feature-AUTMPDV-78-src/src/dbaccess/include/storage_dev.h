
#ifndef __STORAGE_DEV_H__
#define __STORAGE_DEV_H__

static char _storage_dev_h_what[] = "@(#) storage_dev.h 1.2 09/02/17 11:30:18";

#include <swgen/connection.h>

namespace SWITCH
{

class storage_dev 
{
public:
	virtual connection *get_first( void ) = 0;
	virtual connection *get_next( void );
};

}

#endif // __STORAGE_DEV_H__
