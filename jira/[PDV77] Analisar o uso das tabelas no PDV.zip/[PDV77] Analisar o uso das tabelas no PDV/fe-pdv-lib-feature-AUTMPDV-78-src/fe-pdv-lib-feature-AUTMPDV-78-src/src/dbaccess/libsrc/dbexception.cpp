
static char _dbexception_cpp_what[] = "@(#) dbexception.cpp 1.2 09/02/17 11:30:24";

#include <swgen/ocstring_helper.h>
#include <swgen/dbexception.h>

/* ID_22849 - SWLOGGER - INI */
#include <swgen/LibSWLogger.hpp>

using namespace SWLOGGER;
using namespace std;
/* ID_22849 - SWLOGGER - FIM */

namespace SWITCH
{

dbexception::dbexception( const OCString &msg )
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "DB", "dbexception", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */
	
	message = OCString("Database error. ") + msg;
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "DB", "dbexception", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */	
}



dbexception::dbexception( const OCString &method, 
					const DBMHANDLE handle, const bool is_connection )
{
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "DB", "dbexception", "I" ) );
	/* ID_22849 - SWLOGGER - FIM */
	
	DBMRETURN ret;
	char sqlstate[50];
	int native_error;
	int rec_num;
	int finish;
	char msg_text[200];

	message = OCString("DBM method ") + method + " returned error message: ";

	int handle_type = is_connection ? DBM_HANDLE_DBC : DBM_HANDLE_STMT;
	OCString type_text = is_connection ? "Connection" : "Statement";

	finish = 0;
	for (rec_num = 1; !finish; rec_num++)
	{
		ret = DBMGetDiagRec( handle_type, handle, rec_num, sqlstate,
				&native_error, msg_text, sizeof(msg_text), NULL);

		switch (ret)
		{
			case DBM_SUCCESS_WITH_INFO:
			case DBM_SUCCESS:
			message += type_text + " error: sqlstate=" + sqlstate + " native_error=" +
				native_error + " msg=" + msg_text; 
			break;

			case DBM_INVALID_HANDLE:
			message += OCString("DBMGetDiagRec: ") + type_text + 
				" error: invalid handle";
			finish = 1;
			break;

			case DBM_NO_DATA:
			finish = 1;
			break;

			case DBM_ERROR:
			message += "DBMGetDiagRec: invalid argument";
			finish = 1;
			break;

			default:
			message += "DBMGetDiagRec: returned unexpected retcode: " + ret;
			finish = 1;
			break;
		}
	}
	
	/* ID_22849 - SWLOGGER - INI */
	executeLogger (  new (nothrow) GenericFunction( "DB", "dbexception", "O" ) );
	/* ID_22849 - SWLOGGER - FIM */	
}


}
