
static char _dual_db_cpp_what[] = "@(#) dual_db.cpp 1.2 09/02/17 11:30:26";

#include <swgen/dual_db.h>

namespace SWITCH
{

}
