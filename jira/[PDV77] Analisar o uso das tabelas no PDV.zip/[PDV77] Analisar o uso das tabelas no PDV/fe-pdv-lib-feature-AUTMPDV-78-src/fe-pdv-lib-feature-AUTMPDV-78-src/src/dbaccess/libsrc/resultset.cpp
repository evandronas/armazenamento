static char _resultset_cpp_what[] = "@(#) resultset.cpp 1.3 09/12/16 10:26:31";

#include <swgen/swassert.h>
#include <swgen/swtrace.h>
#include <swgen/resultset.h>


namespace SWITCH
{


resultset::resultset() : deb( (*trace::get_instance())(DBMTRACE) )
{
	deb << "In " << __FUNCTION__ << send;

	last_field_nbr = 0;
	db_obj = NULL;
} 

resultset::~resultset()
{
	deb << "In " << __FUNCTION__ << send;

	close_fetch();
}


bool resultset::fetch( void ) throw ( dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	return db_obj->fetch();
}


void resultset::close_fetch( void ) throw ( dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	// Execute db_obj member function 
	if( db_obj != NULL )
		db_obj->close_fetch();
}


int resultset::add_new_field( const OCString &field ) 
{
	deb << "In " << __FUNCTION__ << send;

	// Precondition: field must not be NULL
	if( field.isNull() )
		throw dbexception( OCString(__FUNCTION__) + " received an invalid EMPTY string" );

	if( last_field_nbr++ != 0 )
	{
		// This is NOT the first field in the list, add a comma.
		query_fields += ", ";
	}

	query_fields += field;

	return last_field_nbr;
}

OCString resultset::get_query_fields( void )
{
	deb << "In " << __FUNCTION__ << send;

	return query_fields;
}

void resultset::bind_col( const OCString &field, int &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );
	
	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, char &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, char *var, const size_t capacity ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var, capacity );
}

void resultset::bind_col( const OCString &field, OCString &var, const size_t capacity  ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, OCDateTime &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, unsigned int &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, unsigned char &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, long &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, unsigned long &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, float &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, double &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

void resultset::bind_col( const OCString &field, oasis_dec_t &var ) throw ( swexception, dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	ASSERT( db_obj != NULL );

	int field_nbr = add_new_field( field );

	db_obj->bind( field_nbr, var );
}

bool resultset::is_null( int &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( char &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( char *var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( OCString &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( OCDateTime &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( unsigned int &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( unsigned char &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( long &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( unsigned long &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( float &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( double &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}

bool resultset::is_null( oasis_dec_t &var ) const throw ()
{
	ASSERT( db_obj != NULL );

	return db_obj->is_null( var );
}


void resultset::set_current_db_object( db_object *ob ) throw()
{
	db_obj = ob;
}


}
