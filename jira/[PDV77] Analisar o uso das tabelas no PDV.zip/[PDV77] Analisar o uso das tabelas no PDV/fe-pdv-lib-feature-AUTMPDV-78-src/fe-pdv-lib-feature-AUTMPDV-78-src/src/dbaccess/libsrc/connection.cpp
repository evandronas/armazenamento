
static char _connection_cpp_what[] = "@(#) connection.cpp 1.2 09/02/17 11:30:22";

#include <swgen/swassert.h>
#include <swgen/connection.h>

namespace SWITCH 
{

connection::connection() : trace( (*trace::get_instance())(DBMTRACE) )
{
	static const char *fname = "connection::connection()";

	trace << "In " << fname << send;

	conn = 0;
}

connection::~connection()
{
	static const char *fname = "connection::~connection()";

	trace << "In " << fname << send;

	try
	{
		rollback();
		drop_statements();
		disconnect();
	}
	catch( const dbexception &e )
	{
		// Ignores the exception.
	}
}

void connection::drop_statements( void )
{
	static const char *fname = "connection::drop_statements()";

	trace << "In " << fname << send;

	statements_t::iterator it = statements.begin();
	statements_t::iterator end = statements.end();

	for( ; it != end; it ++ )
		delete *it;

	statements.clear();
}

void connection::disconnect( void ) throw( dbexception )
{
	static const char *fname = "connection::disconnect()";

	trace << "In " << fname << send;

	if( conn != 0 )
	{
		DBMRETURN ret = DBMDisconnect( conn );

		if( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
			throw dbexception( "DBMAllocConnect()", conn, true );

		DBMFreeConnect( conn );

		conn = 0;
	}
}

void connection::connect( const OCString &server, const OCString &user,
					const OCString &password ) throw( dbexception )
{
	static const char *fname = "connection::connect()";

	trace << "In " << fname << send;

	DBMRETURN ret = DBMAllocConnect(&conn);

	if( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
		throw dbexception( "DBMAllocConnect()", conn, true );


	ret = DBMConnect( conn, server.data(), user.data(), password.data() );
	if( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
		throw dbexception( "DBMConnect()", conn, true );
}

DBMHSTMT *connection::get_new_statement( void )
{
	static const char *fname = "connection::get_new_statement()";

	trace << "In " << fname << send;

	DBMHSTMT *sh = new DBMHSTMT;

	if( sh == NULL )
		throw dbexception( OCString(fname) + " - unable to allocate DBMHSTMT" );

	DBMRETURN ret = DBMAllocStmt( conn, sh );
	if( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
		throw dbexception( "DBMAllocStmt()", conn, true );
	
	statements.push_back( sh );

	return sh;
}


void connection::drop_statement( DBMHSTMT *stmt )
{
	static const char *fname = "connection::drop_statement()";

	trace << "In " << fname << send;

	ASSERT( stmt != NULL );

	statements.remove( stmt );

	delete stmt;
}

void connection::commit( void ) throw ( dbexception )
{
	static char *fname = "connection::commit()";
	
	trace << "In " << fname << send;

	DBMRETURN ret = DBMEndTran(conn, DBM_COMMIT);

	if( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
		throw dbexception( "DBMEndTran( DBM_COMMIT )", conn, true );
}


void connection::rollback( void ) throw ( dbexception )
{
	static char *fname = "connection::rollback()";

	trace << "In " << fname << send;

	DBMRETURN ret = DBMEndTran(conn, DBM_ROLLBACK);

	if( ret != DBM_SUCCESS && ret != DBM_SUCCESS_WITH_INFO )
		throw dbexception( "DBMEndTran( DBM_ROLLBACK )", conn, true );
}

}
