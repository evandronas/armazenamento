
static char _db_object_cpp_what[] = "@(#) db_object.cpp 1.5 09/12/16 10:26:30";

#include <swgen/swassert.h>
#include <swgen/swtrace.h>
#include <swgen/single_db.h>
#include <swgen/db_object.h>


namespace SWITCH
{

db_object::db_object() : db_object::stdev(*single_db::get_instance()),
	deb( (*trace::get_instance())(DBMTRACE) )
{
	deb << "In " << __FUNCTION__ << send;

	stmt = NULL;
	is_prepared = false;
	is_executed = false;

	conn = stdev.get_first();

	rec_num = 0;
	result_is_valid = false;
}



db_object::db_object( storage_dev &stdev ) : db_object::stdev(stdev), 
	deb( (*trace::get_instance())(DBMTRACE) )
{
	deb << "In " << __FUNCTION__ << send;

	stmt = NULL;
	is_prepared = false;
	is_executed = false;
	
	conn = stdev.get_first();

	rec_num = 0;
	result_is_valid = false;
}

bool db_object::is_valid( void ) const throw()
{
	if( conn != NULL && stmt != NULL )
		return true;

	return false;
}


db_object::~db_object()
{
	deb << "In " << __FUNCTION__ << send;

	release_bindings();
	release_statement();
}


void db_object::handle_fetch( void )
{
	deb << "In " << __FUNCTION__ << send;


	// Some data types are not supported by DBM low level API. Ie: OCString	
	// and OCMoney. So here is where we handle this data types any time
	// a new fetch() is performed for this resultset.

	handle_OCString_out();
//	handle_OCMoney();
//	handle_OCDecimal();
	handle_OCDateTime_out();
}


void db_object::prepare( statement *pstmt ) throw( dbexception )
{
	deb << "In " << __FUNCTION__ << send;


	ASSERT( stmt != NULL );

	if( stmt != NULL && stmt != pstmt )
	{
		release_bindings();
		release_statement();
	}

	stmt = pstmt;


	stmt->prepare( get_sql_statement() );

	is_prepared = true;
}



void db_object::prepare( void ) throw( dbexception )
{
	deb << "In " << __FUNCTION__ << send;


	if( stmt != NULL )
	{
		release_bindings();
		release_statement();
	}

	stmt = new statement( *conn );

	if( stmt == NULL )
		throw dbexception( OCString(__FUNCTION__) + " unable to get new statement" );

	stmt->prepare( get_sql_statement() );

	is_prepared = true;
}


void db_object::bind_resultset( void )
{
	// Call custom bind from derived classes
	bind_columns();
}


void db_object::bind_columns( void )
{
	deb << "In "  << __FUNCTION__ << send;

}


void db_object::bind_parameters( void )
{
	// Call custom bind from derived classes
	handle_parameters();
}


void db_object::handle_parameters( void )
{
	deb << "In "  << __FUNCTION__ << send;

	handle_OCString_in();
	handle_OCDateTime_in();
}




void db_object::bind( const unsigned int pos, int &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;
}

void db_object::bind( const unsigned int pos, char &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;
}

void db_object::bind( const unsigned int pos, char *var, const size_t capacity ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, capacity-1, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;

}

void db_object::bind( const unsigned int pos, OCString &var, const size_t capacity ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	// OCString is not supported by DBM 

	int *status = new int;

	char *str = get_buff( var, capacity + 1 );
	register_buff_out( var, str, capacity );
	register_buff_in( var, str, capacity );
	
	stmt->bind( pos, str, capacity, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;

}

void db_object::bind( const unsigned int pos, unsigned int &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;

}

void db_object::bind( const unsigned int pos, unsigned char &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;

}

void db_object::bind( const unsigned int pos, long &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;

}

void db_object::bind( const unsigned int pos, unsigned long &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;

}

void db_object::bind( const unsigned int pos, float &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;

}

void db_object::bind( const unsigned int pos, double &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;

}

//void db_object::bind( const unsigned int pos, OCDecimal &var ) throw ( dbexception )
//{
	// OCDecimal is not supported by DBM 

//	oasis_dec_t *buff = get_buff( var );
//	register_buff( var, str );
	
//	vstatus[pos] = 0;
	
//	stmt->bind( pos, buff, vstatus[pos] );
//}

//void db_object::bind( const unsigned int pos, OCMoney &var ) throw ( dbexception )
//{
	// OCMoney is not supported by DBM 

//	oasis_dec_t *buff = get_buff( var );
//	register_buff( var, str );
	
//	vstatus[pos] = 0;
	
//	stmt->bind( pos, buff, vstatus[pos] );
//}

void db_object::bind( const unsigned int pos, OCDateTime &var ) throw ( dbexception )
{
	// OCDateTime is not supported by DBM 

    ASSERT( stmt != NULL );

    // OCString is not supported by DBM

    int *status = new int;

    time_t *time = get_buff( var );
    register_buff_out( var, time );
    register_buff_in( var, time );

    stmt->bind( pos, time, status );

    vstatus[pos] = status;
    vstatus_by_ptr[&var] = status;
}

void db_object::bind( const unsigned int pos, oasis_dec_t &var ) throw ( swexception, dbexception )
{
	ASSERT( stmt != NULL );

	int *status = new int;

	stmt->bind( pos, var, status );

	vstatus[pos] = status;
	vstatus_by_ptr[&var] = status;
}


/*

void db_object::bind_param( const unsigned int pos, short &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, int &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, char &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, char *var, const size_t size ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var, size );
}

void db_object::bind_param( const unsigned int pos, OCString &var  ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var, var.length() );
}

void db_object::bind_param( const unsigned int pos, unsigned short &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, unsigned int &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, unsigned char &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, long &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, unsigned long &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, float &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, double &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

void db_object::bind_param( const unsigned int pos, oasis_dec_t &var ) throw ( dbexception )
{
	stmt->bind_param( translate_pos(pos), var );
}

*/

/*
bool db_object::is_null( int pos ) const
{
	ASSERT( vstatus.find(pos) != vstatus.end() );

	int *status = (*vstatus.find(pos)).second;
	bool res =  *status == (int)DBM_NULL_DATA;

	return res;
}
*/


bool db_object::is_null( int &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( char &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( char *var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( OCString &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( OCDateTime &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( unsigned int &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( unsigned char &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( long &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( unsigned long &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( float &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( double &var ) const throw ()
{
	return is_null( (void*)&var );
}

bool db_object::is_null( oasis_dec_t &var ) const throw ()
{
	return is_null( (void*)&var );
}




bool db_object::is_null( void *ptr ) const
{
	ASSERT( vstatus_by_ptr.find(ptr) != vstatus.end() );

	int *status = (*vstatus_by_ptr.find(ptr)).second;
	bool res =  *status == (int)DBM_NULL_DATA;

	return res;
}


void db_object::release_bindings( void )
{
	deb << "In " << __FUNCTION__ << send;

	// First call do_release_bindings() from derived classes
	do_release_bindings();


	
	// String bindings. Buffers have to be freed
	status_t::iterator vsit = vstatus.begin();
	status_t::iterator vsend = vstatus.end();

	for( ; vsit != vsend; vsit ++ )
		delete (*vsit).second;
	
	vstatus.clear();
	vstatus_by_ptr.clear();

	// String bindings. Buffers have to be freed
	string_bindings_t::iterator it = str_binds_in.begin();
	string_bindings_t::iterator end = str_binds_in.end();

	for( ; it != end; it ++ )
	{
		delete[] ((*it).second)->ptr;
		delete (*it).second;
	}

	string_bindings_t::iterator oit = str_binds_out.begin();
	string_bindings_t::iterator oend = str_binds_out.end();

	for( ; oit != oend; oit ++ )
	{
		delete[] ((*oit).second)->ptr;
		delete (*oit).second;
	}

	str_binds_in.clear();
	str_binds_out.clear();

	// DateTime bindings. Buffers have to be freed
	time_bindings_t::iterator tit = time_binds_in.begin();
	time_bindings_t::iterator tend = time_binds_in.end();

	for( ; tit != tend; tit ++ )
	{
		delete (*tit).second;
	}

	time_bindings_t::iterator toit = time_binds_out.begin();
	time_bindings_t::iterator toend = time_binds_out.end();

	for( ; toit != toend; toit ++ )
	{
		delete (*toit).second;
	}

	time_binds_in.clear();
	time_binds_out.clear();
}

void db_object::release_statement( void )
{
	deb << "In " << __FUNCTION__ << send;

	// First call do_release_statement() from derived classes
	do_release_statement();

	if( stmt != NULL )
	{
		delete stmt;
		stmt = NULL;
	}

	is_prepared = false;
	is_executed = false;
	rec_num = 0;
}


void db_object::execute( void ) throw ( dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	if( ! is_prepared )
		throw dbexception( OCString(__FUNCTION__) + ": prepare() method must be invoked before this method" );

	if( is_executed )
	{
		// Remove all pending results
		stmt->close();
	}

	bind_parameters();

	clean_output_bindings();

	stmt->execute();

	bind_resultset();

	is_executed = true;
}


bool db_object::fetch( void ) throw ( dbexception )
{
	deb << "In " << __FUNCTION__ << send;

	if( ! is_executed )
		throw dbexception( OCString(__FUNCTION__) + ": execute() method must be invoked before this method" );

	result_is_valid = stmt->fetch();
	if( result_is_valid ) 
		handle_fetch();

	rec_num ++;

	return result_is_valid;
}


void db_object::close_fetch( void ) throw ( dbexception )
{
	//static char *fname = "db_object::close_fetch()";
	
	deb << "In " << __FUNCTION__ << send;

	release_bindings();
	release_statement();

	result_is_valid = false;
	rec_num = 0;
}

bool db_object::stmt_is_prepared( void ) throw	()
{
	return is_prepared;
}

bool db_object::stmt_is_executed( void ) throw	()
{
	return is_executed;
}

bool db_object::resultset_is_valid( void ) throw ()
{
	return result_is_valid;
}

statement *db_object::get_stmt( void ) throw ()
{
	return stmt;
}

storage_dev *db_object::get_stdev( void ) throw ()
{
	return &stdev;
}

connection *db_object::get_connection( void ) throw ()
{
	return conn;
}

void db_object::commit( void ) throw ( dbexception )
{
	stmt->commit();
}


void db_object::rollback( void ) throw ( dbexception )
{
	stmt->rollback();
}



void db_object::do_release_bindings( void )
{
	// Do Nothing, to be implemented by derived classes
}

void db_object::do_release_statement( void )
{
	// Do Nothing, to be implemented by derived classes
}


char *db_object::get_buff( const OCString &var, const size_t capacity )
{
	char *str;
	
	str = new char[capacity];

	if( str == 0 )
		throw dbexception( OCString(__FUNCTION__) + " Out of memory trying to allocate a new buffer" );

	return str;
}

time_t *db_object::get_buff( const OCDateTime &var )
{
	time_t *time;
	
	time = new time_t;

	if( time == 0 )
		throw dbexception( OCString(__FUNCTION__) + " Out of memory trying to allocate a new buffer" );

	return time;
}


void db_object::register_buff_out( OCString &var, char *str, size_t len )
{
	ptr_len_t *node = new ptr_len_t;

	if( node == 0 )
		throw dbexception( OCString(__FUNCTION__) + " Out of memory trying to allocate a new buffer" );

	node->allocated_len = len;
	node->ptr = str;

	str_binds_out[&var] = node;
}


void db_object::register_buff_in( OCString &var, char *str, size_t len )
{
	ptr_len_t *node = new ptr_len_t;

	if( node == 0 )
		throw dbexception( OCString(__FUNCTION__) + " Out of memory trying to allocate a new buffer" );

	node->allocated_len = len;
	node->ptr = str;

	str_binds_in[&var] = node;
}

void db_object::register_buff_out( OCDateTime &var, time_t *time )
{
	time_binds_out[&var] = time;
}


void db_object::register_buff_in( OCDateTime &var, time_t *time )
{
	time_binds_in[&var] = time;
}



void db_object::handle_OCString_out( void )
{
	deb << "In " << __FUNCTION__ << send;

	// String bindings. 
	string_bindings_t::iterator it = str_binds_out.begin();
	string_bindings_t::iterator end = str_binds_out.end();

	for( ; it != end; it ++ )
	{
		deb << __FUNCTION__ << " - char * [" << ((*it).second)->ptr << "] / OCString [" << *((*it).first) << "]" << send;
		(*((*it).first)) = ((*it).second)->ptr ;
	}
}

void db_object::handle_OCDateTime_out( void )
{
	deb << "In " << __FUNCTION__ << send;
	struct tm *tm;

	// String bindings. 
	time_bindings_t::iterator it = time_binds_out.begin();
	time_bindings_t::iterator end = time_binds_out.end();

	for( ; it != end; it ++ )
	{
		tm = localtime((*it).second);

		deb << __FUNCTION__ << " - time_t [" << OCDateTime( tm ) << "] / OCDateTime [" << *((*it).first) << "]" << send;
		(*((*it).first)) = tm;
	}
}

void db_object::clean_output_bindings( void )
{
	deb << "In " << __FUNCTION__ << send;

	// String bindings. 
	string_bindings_t::iterator it = str_binds_out.begin();
	string_bindings_t::iterator end = str_binds_out.end();

	for( ; it != end; it ++ )
		memset( ((*it).second)->ptr, 0, ((*it).second)->allocated_len );

	// DateTime bindings. 
	time_bindings_t::iterator tit = time_binds_out.begin();
	time_bindings_t::iterator tend = time_binds_out.end();

	for( ; tit != tend; it ++ )
		memset( (*it).second, 0, sizeof(time_t) );

}

void db_object::handle_OCString_in( void )
{
	deb << "In " << __FUNCTION__ << send;

	// String bindings. 
	string_bindings_t::iterator it = str_binds_in.begin();
	string_bindings_t::iterator end = str_binds_in.end();

	for( ; it != end; it ++ )
	{
		size_t len = ((*it).second)->allocated_len;

		//deb << __FUNCTION__ << " - OCString [" << (*((*it).first))(0,len) << "] / char * [" << (*it).second << "]" << send;
		deb << __FUNCTION__ << " - OCString [" << *((*it).first) << "] / char * [" << (*it).second << "]" << send;
		if( len < (*it).first->length() )
			deb << __FUNCTION__ << " - WARNING OCString length is longer than " << len << send;


		//strcpy( ((*it).second)->ptr, (*((*it).first))(0,len) );
		strncpy( ((*it).second)->ptr, *((*it).first),len );
		((*it).second)->ptr[len] = '\0';
	}

}

void db_object::handle_OCDateTime_in( void )
{
	deb << "In " << __FUNCTION__ << send;

	// String bindings. 
	time_bindings_t::iterator it = time_binds_in.begin();
	time_bindings_t::iterator end = time_binds_in.end();

	for( ; it != end; it ++ )
	{
		deb << __FUNCTION__ << " - OCDateTime [" << *((*it).first) << "] / time_t * [" << (*it).second << "]" << send;

		(*(*it).second) = (*(*it).first).seconds();
	}
}

// The following function is meant to be overriden by derived
// classes which perform parameter bindings for stored function calls
// In those cases, the first parameter binding is the stored function' return code itself.
int db_object::translate_pos( int pos ) const throw()
{
	return pos;
}

} // namespace SWITCH
