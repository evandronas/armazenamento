
static char _single_db_cpp_what[] = "@(#) single_db.cpp 1.3 09/08/04 16:57:17";

#include "dbm.h"
#include <ist_cfg.h> 
#include <swgen/single_db.h>

namespace SWITCH
{

single_db *single_db::_Instance = NULL;

single_db *single_db::get_instance( void )
{
	if( _Instance == NULL )
	{
		_Instance = new single_db;
	}

	return _Instance;
}

single_db::single_db() 
{
	conn = NULL;
}

single_db::~single_db() {}


connection *single_db::get_first( void )
{
	if( conn == NULL )
	{
		conn = new connection;

    	char dBuser[128];
    	char dBpasswd[128];

    	cf_open ("cfg/istparam.cfg"); 
		dbm_get_user_passwd(dBuser, dBpasswd);

		strtok(	dBuser, "@" );
		char *pserver = strtok(	NULL, "@" );

		conn->connect( pserver, dBuser, dBpasswd );
	}

	return conn;
}

connection *single_db::get_next( void )
{
	return NULL;
}

}
