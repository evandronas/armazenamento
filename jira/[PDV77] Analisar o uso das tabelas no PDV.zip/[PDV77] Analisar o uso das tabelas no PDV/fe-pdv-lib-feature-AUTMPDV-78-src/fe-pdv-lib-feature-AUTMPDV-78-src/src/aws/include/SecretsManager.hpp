/**
* Copyright 2020 REDE
*
* Internal AWS library which allow access to AWS Secrets Manager
*/


#include <string>
#include "logger/Logger.hpp"

namespace internalAws {
namespace sm {

    /**
     Class which provides access to AWS Secrets Manager
    */
    class SecretsManager {
    public:
        SecretsManager();
        ~SecretsManager();

        /**
         * Retrieve the key value of a secret from Secrets Manager.
         * @param secret String which contains secret's name stored on Secrets Manager
         * @param key The key to be retrieved from the secret
         * @return A string if the secret and key exist otherwise empty string.
         */
        std::string RetrieveSecretName(std::string secret, const char * key);

    private:
        logger::Logger * logger;
    };

} // namespace sm
} // namespace internalAws
