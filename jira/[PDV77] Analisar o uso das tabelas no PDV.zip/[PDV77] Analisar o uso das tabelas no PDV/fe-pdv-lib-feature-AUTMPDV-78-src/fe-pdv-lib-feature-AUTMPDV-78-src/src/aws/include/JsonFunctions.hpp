/*
* Copyright 2021 REDE
*
* Internal AWS library which allow access to AWS DynamoDB
*/

#include "logger/Logger.hpp"

namespace internalAws {
namespace json {

    /**
     Class which provides access to AWS Secrets Manager
    */
    class JsonFunctions {
    public:
        JsonFunctions();
        ~JsonFunctions();

        std::string GetAsString(std::string jsonstr, std::string key) ;
        int GetAsInteger(std::string jsonstr, std::string key);
    private:
        logger::Logger * logger;
    };

} // namespace json
} // namespace internalAws
