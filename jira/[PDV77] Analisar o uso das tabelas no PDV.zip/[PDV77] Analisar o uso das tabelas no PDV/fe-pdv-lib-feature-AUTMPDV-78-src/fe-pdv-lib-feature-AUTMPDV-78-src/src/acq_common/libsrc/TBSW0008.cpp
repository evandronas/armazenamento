/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#include "TBSW0008.hpp"

namespace dbaccess_common
{

    TBSW0008::TBSW0008() {
        
        query_fields = "COD_BIN_INFR, COD_BIN_SUPR, COD_ID_MMBR, COD_RGAO, COD_PAIS, COD_PROD, DAT_INCL_REG, COD_STTU_REG, IND_BIN_TKN";
        table_name = "TBSW0008";

        codigoBinInferiorPosicao = 1;
        codigoBinSuperiorPosicao = 2;
        codigoIcaPosicao = 3;
        codigoRegiaoPosicao = 4;
        codigoPaisPosicao = 5;
        codigoProdutoPosicao = 6;
        dataInclusaoRegistroPosicao = 7;
        codigoSituacaoRegistroPosicao = 8;
        indicadorTokenPosicao = 9;

        codigoBinInferior = "";
        codigoBinSuperior = "";
        dbm_deccopy(&codigoIca, 0);
        codigoRegiao = "";
        codigoPais = "";
        codigoProduto = "";
        codigoSituacaoRegistro = "";
        indicadorToken = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0008::TBSW0008(const std::string& where) {
    
        query_fields = "COD_BIN_INFR, COD_BIN_SUPR, COD_ID_MMBR, COD_RGAO, COD_PAIS, COD_PROD, DAT_INCL_REG, COD_STTU_REG, IND_BIN_TKN";
        table_name = "TBSW0008";
        where_condition = where;

        codigoBinInferiorPosicao = 1;
        codigoBinSuperiorPosicao = 2;
        codigoIcaPosicao = 3;
        codigoRegiaoPosicao = 4;
        codigoPaisPosicao = 5;
        codigoProdutoPosicao = 6;
        dataInclusaoRegistroPosicao = 7;
        codigoSituacaoRegistroPosicao = 8;
        indicadorTokenPosicao = 9;

        codigoBinInferior = "";
        codigoBinSuperior = "";
        dbm_deccopy(&codigoIca, 0);
        codigoRegiao = "";
        codigoPais = "";
        codigoProduto = "";
        codigoSituacaoRegistro = "";
        indicadorToken = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0008::~TBSW0008() {
    }

    void TBSW0008::bind_columns() {
        bind(codigoBinInferiorPosicao, codigoBinInferior);
        bind(codigoBinSuperiorPosicao, codigoBinSuperior);
        bind(codigoIcaPosicao, codigoIca);
        bind(codigoRegiaoPosicao, codigoRegiao);
        bind(codigoPaisPosicao, codigoPais);
        bind(codigoProdutoPosicao, codigoProduto);
        bind(dataInclusaoRegistroPosicao, &dataInclusaoRegistro);
        bind(codigoSituacaoRegistroPosicao, codigoSituacaoRegistro);
        bind(indicadorTokenPosicao, indicadorToken);
    }

    // Getters
    const std::string& TBSW0008::GetCodigoBinInferior() const {
        return codigoBinInferior;
    }

    const std::string& TBSW0008::GetCodigoBinSuperior() const {
        return codigoBinSuperior;
    }

    const oasis_dec_t& TBSW0008::GetCodigoIca() const {
        return codigoIca;
    }

    const std::string& TBSW0008::GetCodigoRegiao() const {
        return codigoRegiao;
    }

    const std::string& TBSW0008::GetCodigoPais() const {
        return codigoPais;
    }

    const std::string& TBSW0008::GetCodigoProduto() const {
        return codigoProduto;
    }

    const dbm_datetime_t& TBSW0008::GetDataInclusaoRegistro() const {
        return dataInclusaoRegistro;
    }

    const std::string& TBSW0008::GetCodigoSituacaoRegistro() const {
        return codigoSituacaoRegistro;
    }

    const std::string& TBSW0008::GetIndicadorToken() const {
        return indicadorToken;
    }

    // Setters
    void TBSW0008::SetCodigoBinInferior(const std::string& value) {
        codigoBinInferior = value;
    }

    void TBSW0008::SetCodigoBinSuperior(const std::string& value) {
        codigoBinSuperior = value;
    }

    void TBSW0008::SetCodigoIca(const oasis_dec_t& value) {
        codigoIca = value;
    }

    void TBSW0008::SetCodigoRegiao(const std::string& value) {
        codigoRegiao = value;
    }

    void TBSW0008::SetCodigoPais(const std::string& value) {
        codigoPais = value;
    }

    void TBSW0008::SetCodigoProduto(const std::string& value) {
        codigoProduto = value;
    }

    void TBSW0008::SetDataInclusaoRegistro(const dbm_datetime_t& value) {
        dataInclusaoRegistro = value;
    }

    void TBSW0008::SetCodigoSituacaoRegistro(const std::string& value) {
        codigoSituacaoRegistro = value;
    }

    void TBSW0008::SetIndicadorToken(const std::string& value) {
        indicadorToken = value;
    }

}
