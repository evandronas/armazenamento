#include "TBSW0051.hpp"

namespace dbaccess_common
{
	TBSW0051::TBSW0051()
	{

		query_fields = "NUM_PDV, COD_STTU_REG";

		table_name = "TBSW0051";

		m_NUM_PDV_pos = 1;
		m_COD_STTU_REG_pos = 2;
		m_NUM_PDV = 0;
		m_COD_STTU_REG = "";

		where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0051::TBSW0051( const std::string& whereClause )
	{

		query_fields = "NUM_PDV, COD_STTU_REG";

		table_name = "TBSW0051";

		m_NUM_PDV_pos = 1;
		m_COD_STTU_REG_pos = 2;

		m_NUM_PDV = 0;
		m_COD_STTU_REG = "";

		where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0051::~TBSW0051()
	{
	}

	void TBSW0051::bind_columns()
	{
		bind( m_NUM_PDV_pos, m_NUM_PDV );
		bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
	}
	void TBSW0051::set_NUM_PDV( unsigned long a_NUM_PDV )
	{
		m_NUM_PDV = a_NUM_PDV;
	}
	void TBSW0051::set_COD_STTU_REG( const std::string& a_COD_STTU_REG )
	{
		m_COD_STTU_REG = a_COD_STTU_REG;
	}
	unsigned long TBSW0051::get_NUM_PDV() const
	{
		return m_NUM_PDV;
	}
	const std::string& TBSW0051::get_COD_STTU_REG() const
	{
		return m_COD_STTU_REG;
	}

} //namespace dbaccess_common

