#include "TBSW0030MAX.hpp"

namespace dbaccess_common
{
    TBSW0030MAX::TBSW0030MAX()
    {
        initialize( );
        
        where_condition = " 1=1 ORDER BY DTH_INI_TRAN DESC";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0030MAX::TBSW0030MAX( const std::string& whereClause )
    {
        initialize( );
        
        where_condition = whereClause + std::string(" ORDER BY DTH_INI_TRAN DESC");
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    void TBSW0030MAX::initialize( )
    {
        query_fields = "NUM_SEQ_UNC, IND_STTU_TRAN, DAT_MOV_TRAN";
        table_name = "TBSW0030";
        
        m_NUM_SEQ_UNC_pos = 1;
        m_IND_STTU_TRAN_pos = 2;
        m_DAT_MOV_TRAN_pos = 3;
        m_NUM_SEQ_UNC = 0;
        m_IND_STTU_TRAN = "";
        m_DAT_MOV_TRAN = 0;
    }
    
    TBSW0030MAX::~TBSW0030MAX()
    {
    }

    void TBSW0030MAX::bind_columns()
    {
        bind(m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind(m_IND_STTU_TRAN_pos, m_IND_STTU_TRAN);
        bind(m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN);
    }
    void TBSW0030MAX::set_NUM_SEQ_UNC(unsigned long a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }
    void TBSW0030MAX::set_IND_STTU_TRAN(const std::string& a_IND_STTU_TRAN)
    {
        m_IND_STTU_TRAN = a_IND_STTU_TRAN;
    }
    void TBSW0030MAX::set_DAT_MOV_TRAN(unsigned long a_DAT_MOV_TRAN)
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    unsigned long TBSW0030MAX::get_NUM_SEQ_UNC() const
    {
        return m_NUM_SEQ_UNC;
    }
    const std::string& TBSW0030MAX::get_IND_STTU_TRAN() const
    {
        return m_IND_STTU_TRAN;
    }
    unsigned long TBSW0030MAX::get_DAT_MOV_TRAN() const
    {
        return m_DAT_MOV_TRAN;
    }
} //namespace dbaccess_common

