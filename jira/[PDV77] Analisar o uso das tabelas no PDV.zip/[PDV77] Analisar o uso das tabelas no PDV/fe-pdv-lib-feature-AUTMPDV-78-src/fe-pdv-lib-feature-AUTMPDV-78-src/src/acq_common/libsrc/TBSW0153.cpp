#include "TBSW0153.hpp"

namespace dbaccess_common
{
    TBSW0153::TBSW0153( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW0153::TBSW0153( const std::string& whereClause )
    {
        initialize( );
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0153::~TBSW0153( )
    {
    }
    
    void TBSW0153::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, NUM_EMSR, IND_VAL_APR_SLDO_DSPL, VAL_EFTV_APRV, NUM_RTDR_TRK, DTH_VD_TERM, COD_MOT_APRV_OFLN";

        table_name = "TBSW0153";
        
        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_NUM_EMSR_pos = 3;
        m_IND_VAL_APR_SLDO_DSPL_pos = 4;
        m_VAL_EFTV_APRV_pos = 5;
        m_NUM_RTDR_TRK_pos = 6;
        m_DTH_VD_TERM_pos = 7;
        m_COD_MOT_APRV_OFLN_pos = 8;

        m_NUM_EMSR = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_NUM_RTDR_TRK = 0;
        m_DAT_MOV_TRAN = 0;
        m_DTH_VD_TERM = 0;
        dbm_chartodec( &m_VAL_EFTV_APRV, "0.00", 2 );
        m_COD_MOT_APRV_OFLN = " ";
        m_IND_VAL_APR_SLDO_DSPL = " ";

        m_VAL_EFTV_APRV_ind_null = DBM_NULL_DATA;
    }
    
	void TBSW0153::let_as_is( )
	{
		m_VAL_EFTV_APRV_ind_null = is_null( m_VAL_EFTV_APRV ) ? DBM_NULL_DATA : 0;
	}

    void TBSW0153::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_NUM_EMSR_pos, m_NUM_EMSR );
        bind( m_IND_VAL_APR_SLDO_DSPL_pos, m_IND_VAL_APR_SLDO_DSPL );
        bind( m_VAL_EFTV_APRV_pos, m_VAL_EFTV_APRV, &m_VAL_EFTV_APRV_ind_null );
        bind( m_NUM_RTDR_TRK_pos, m_NUM_RTDR_TRK );
        bind( m_DTH_VD_TERM_pos, &m_DTH_VD_TERM );
        bind( m_COD_MOT_APRV_OFLN_pos, m_COD_MOT_APRV_OFLN );
    }

    void TBSW0153::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0153::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    void TBSW0153::set_NUM_EMSR( unsigned long a_NUM_EMSR )
    {
        m_NUM_EMSR = a_NUM_EMSR;
    }
    void TBSW0153::set_IND_VAL_APR_SLDO_DSPL( const std::string& a_IND_VAL_APR_SLDO_DSPL )
    {
        m_IND_VAL_APR_SLDO_DSPL = a_IND_VAL_APR_SLDO_DSPL;
    }
    void TBSW0153::set_VAL_EFTV_APRV( oasis_dec_t a_VAL_EFTV_APRV )
    {
        dbm_deccopy( &m_VAL_EFTV_APRV, &a_VAL_EFTV_APRV );
        m_VAL_EFTV_APRV_ind_null = 0;
    }
    void TBSW0153::set_NUM_RTDR_TRK( unsigned long a_NUM_RTDR_TRK )
    {
        m_NUM_RTDR_TRK = a_NUM_RTDR_TRK;
    }    
    void TBSW0153::set_DTH_VD_TERM( dbm_datetime_t a_DTH_VD_TERM )
    {
        m_DTH_VD_TERM = a_DTH_VD_TERM;
    }      
    void TBSW0153::set_COD_MOT_APRV_OFLN( const std::string& a_COD_MOT_APRV_OFLN )
    {
        m_COD_MOT_APRV_OFLN = a_COD_MOT_APRV_OFLN;
    }
    
    unsigned long TBSW0153::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    oasis_dec_t TBSW0153::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }
    unsigned long TBSW0153::get_NUM_EMSR( ) const
    {
        return( m_NUM_EMSR );
    }
    const std::string& TBSW0153::get_IND_VAL_APR_SLDO_DSPL( ) const
    {
        return( m_IND_VAL_APR_SLDO_DSPL );
    }
    oasis_dec_t TBSW0153::get_VAL_EFTV_APRV( ) const
    {
        return( m_VAL_EFTV_APRV );
    }
    unsigned long TBSW0153::get_NUM_RTDR_TRK( ) const
    {
        return( m_NUM_RTDR_TRK );
    }
    dbm_datetime_t TBSW0153::get_DTH_VD_TERM( ) const
    {
        return( m_DTH_VD_TERM );
    }
    const std::string& TBSW0153::get_COD_MOT_APRV_OFLN( ) const
    {
        return m_COD_MOT_APRV_OFLN;
    }

} // namespace dbaccess_common


