#include "TBSW0032.hpp"

namespace dbaccess_common
{
    TBSW0032::TBSW0032( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW0032::TBSW0032( const std::string& whereClause )
    {
        initialize( );
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0032::~TBSW0032( )
    {
    }
    
    void TBSW0032::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, NUM_BCO_ESTB, NUM_BCO_DEB, NUM_EMSR, NUM_AGE_ESTB, COD_CTA_ESTB, COD_VD_BCO, VAL_SQUE, IND_CNFR_PSTV, IND_IMPR_CPOM, QTD_DIA_CRNC, IND_CAR_MLTP,VAL_LQDC,VAL_RPSS,TIP_RPSS_VAL,VAL_RCD,COD_RVDA_PROD_MTC";
        
        table_name = "TBSW0032";
        
        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_NUM_BCO_ESTB_pos = 3;
        m_NUM_BCO_DEB_pos = 4;
        m_NUM_EMSR_pos = 5;
        m_NUM_AGE_ESTB_pos = 6;
        m_COD_CTA_ESTB_pos = 7;
        m_COD_VD_BCO_pos = 8;
        m_VAL_SQUE_pos = 9;
        m_IND_CNFR_PSTV_pos = 10;
        m_IND_IMPR_CPOM_pos = 11;
        m_QTD_DIA_CRNC_pos = 12;
        m_IND_CAR_MLTP_pos = 13;
        m_VAL_LQDC_pos = 14;
        m_VAL_RPSS_pos = 15;
        m_TIP_RPSS_VAL_pos = 16;
        m_VAL_RCD_pos = 17;
        m_COD_RVDA_PROD_MTC_pos = 18;

        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_NUM_BCO_ESTB = 0;
        m_NUM_BCO_DEB = 0;
        m_NUM_EMSR = 0;
        dbm_longtodec( &m_NUM_AGE_ESTB, 0 );
        m_COD_CTA_ESTB = " ";
        m_COD_VD_BCO = " ";
        dbm_chartodec( &m_VAL_SQUE, "0.00", 2 );
        m_IND_CNFR_PSTV = " ";
        m_IND_IMPR_CPOM = " ";
        m_IND_CAR_MLTP = "";
        dbm_chartodec( &m_VAL_RPSS, "0.00", 2 );
        m_TIP_RPSS_VAL = "";
        m_COD_RVDA_PROD_MTC = "";
        m_QTD_DIA_CRNC = 0;
        dbm_chartodec( &m_VAL_LQDC, "0.00", 2 );
        dbm_chartodec( &m_VAL_RCD, "0.00", 2 );

        m_QTD_DIA_CRNC_ind_null = DBM_NULL_DATA;
        m_VAL_LQDC_ind_null = DBM_NULL_DATA;
        m_VAL_RCD_ind_null =  DBM_NULL_DATA;
        m_VAL_RPSS_ind_null = DBM_NULL_DATA;
    }
    
	void TBSW0032::let_as_is( )
	{
        m_QTD_DIA_CRNC_ind_null =   is_null( m_QTD_DIA_CRNC ) ? DBM_NULL_DATA : 0;
        m_VAL_LQDC_ind_null =       is_null( m_VAL_LQDC ) ? DBM_NULL_DATA : 0;
        m_VAL_RPSS_ind_null =       is_null( m_VAL_RPSS ) ? DBM_NULL_DATA : 0;
        m_VAL_RCD_ind_null =        is_null( m_VAL_RCD ) ? DBM_NULL_DATA : 0;
	}
	
    void TBSW0032::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_NUM_BCO_ESTB_pos, m_NUM_BCO_ESTB );
        bind( m_NUM_BCO_DEB_pos, m_NUM_BCO_DEB );
        bind( m_NUM_EMSR_pos, m_NUM_EMSR );
        bind( m_NUM_AGE_ESTB_pos, m_NUM_AGE_ESTB );
        bind( m_COD_CTA_ESTB_pos, m_COD_CTA_ESTB );
        bind( m_COD_VD_BCO_pos, m_COD_VD_BCO );
        bind( m_VAL_SQUE_pos, m_VAL_SQUE );
        bind( m_IND_CNFR_PSTV_pos, m_IND_CNFR_PSTV );
        bind( m_IND_IMPR_CPOM_pos, m_IND_IMPR_CPOM );
        bind( m_IND_CAR_MLTP_pos, m_IND_CAR_MLTP );
        bind( m_TIP_RPSS_VAL_pos, m_TIP_RPSS_VAL );
        bind( m_COD_RVDA_PROD_MTC_pos, m_COD_RVDA_PROD_MTC );
        bind( m_QTD_DIA_CRNC_pos, m_QTD_DIA_CRNC, &m_QTD_DIA_CRNC_ind_null );
        bind( m_VAL_LQDC_pos, m_VAL_LQDC, &m_VAL_LQDC_ind_null );
        bind( m_VAL_RPSS_pos, m_VAL_RPSS, &m_VAL_RPSS_ind_null );
        bind( m_VAL_RCD_pos, m_VAL_RCD, &m_VAL_RCD_ind_null );
    }
    void TBSW0032::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0032::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    void TBSW0032::set_NUM_BCO_ESTB( unsigned long a_NUM_BCO_ESTB )
    {
        m_NUM_BCO_ESTB = a_NUM_BCO_ESTB;
    }
    void TBSW0032::set_NUM_BCO_DEB( unsigned long a_NUM_BCO_DEB )
    {
        m_NUM_BCO_DEB = a_NUM_BCO_DEB;
    }
    void TBSW0032::set_NUM_EMSR( unsigned long a_NUM_EMSR )
    {
        m_NUM_EMSR = a_NUM_EMSR;
    }
    void TBSW0032::set_NUM_AGE_ESTB( oasis_dec_t a_NUM_AGE_ESTB )
    {
        dbm_deccopy( &m_NUM_AGE_ESTB, &a_NUM_AGE_ESTB );
    }
    void TBSW0032::set_COD_CTA_ESTB( const std::string& a_COD_CTA_ESTB )
    {
        m_COD_CTA_ESTB = a_COD_CTA_ESTB;
    }
    void TBSW0032::set_COD_VD_BCO( const std::string& a_COD_VD_BCO )
    {
        m_COD_VD_BCO = a_COD_VD_BCO;
    }
    void TBSW0032::set_VAL_SQUE( oasis_dec_t a_VAL_SQUE )
    {
        dbm_deccopy( &m_VAL_SQUE, &a_VAL_SQUE );
    }
    void TBSW0032::set_IND_CNFR_PSTV( const std::string& a_IND_CNFR_PSTV )
    {
        m_IND_CNFR_PSTV = a_IND_CNFR_PSTV;
    }
    void TBSW0032::set_IND_IMPR_CPOM( const std::string& a_IND_IMPR_CPOM )
    {
        m_IND_IMPR_CPOM = a_IND_IMPR_CPOM;
    }
    void TBSW0032::set_IND_CAR_MLTP( const std::string& a_IND_CAR_MLTP )
    {
        m_IND_CAR_MLTP = a_IND_CAR_MLTP;
    }
    void TBSW0032::set_TIP_RPSS_VAL( const std::string& a_TIP_RPSS_VAL )
    {
        m_TIP_RPSS_VAL = a_TIP_RPSS_VAL;
    }
    void TBSW0032::set_COD_RVDA_PROD_MTC( const std::string& a_COD_RVDA_PROD_MTC )
    {
        m_COD_RVDA_PROD_MTC = a_COD_RVDA_PROD_MTC;
    }
    void TBSW0032::set_QTD_DIA_CRNC( unsigned long a_QTD_DIA_CRNC )
    {
        m_QTD_DIA_CRNC = a_QTD_DIA_CRNC;
        m_QTD_DIA_CRNC_ind_null = 0;
    }
    void TBSW0032::set_VAL_LQDC( oasis_dec_t a_VAL_LQDC )
    {
        dbm_deccopy( &m_VAL_LQDC, &a_VAL_LQDC );
        m_VAL_LQDC_ind_null = 0;
    }
    void TBSW0032::set_VAL_RCD( oasis_dec_t a_VAL_RCD )
    {
        m_VAL_RCD = a_VAL_RCD;
        m_VAL_RCD_ind_null = 0;
    } 
    void TBSW0032::set_VAL_RPSS( oasis_dec_t a_VAL_RPSS )
    {
        dbm_deccopy( &m_VAL_RPSS, &a_VAL_RPSS );
        m_VAL_RPSS_ind_null = 0;
    }
    
    unsigned long TBSW0032::get_DAT_MOV_TRAN( ) const
    {
        return m_DAT_MOV_TRAN;
    }
    oasis_dec_t TBSW0032::get_NUM_SEQ_UNC( ) const
    {
        return m_NUM_SEQ_UNC;
    }
    unsigned long TBSW0032::get_NUM_BCO_ESTB( ) const
    {
        return m_NUM_BCO_ESTB;
    }
    unsigned long TBSW0032::get_NUM_BCO_DEB( ) const
    {
        return m_NUM_BCO_DEB;
    }
    unsigned long TBSW0032::get_NUM_EMSR( ) const
    {
        return m_NUM_EMSR;
    }
    oasis_dec_t TBSW0032::get_NUM_AGE_ESTB( ) const
    {
        return m_NUM_AGE_ESTB;
    }
    const std::string& TBSW0032::get_COD_CTA_ESTB( ) const
    {
        return m_COD_CTA_ESTB;
    }
    const std::string& TBSW0032::get_COD_VD_BCO( ) const
    {
        return m_COD_VD_BCO;
    }
    oasis_dec_t TBSW0032::get_VAL_SQUE( ) const
    {
        return m_VAL_SQUE;
    }
    const std::string& TBSW0032::get_IND_CNFR_PSTV( ) const
    {
        return m_IND_CNFR_PSTV;
    }
    const std::string& TBSW0032::get_IND_IMPR_CPOM( ) const
    {
        return m_IND_IMPR_CPOM;
    }
    unsigned long TBSW0032::get_QTD_DIA_CRNC( ) const
    {
        return m_QTD_DIA_CRNC;
    }
    const std::string& TBSW0032::get_IND_CAR_MLTP( ) const
    {
        return m_IND_CAR_MLTP;
    }
    oasis_dec_t TBSW0032::get_VAL_LQDC( ) const
    {
        return m_VAL_LQDC;
    }
    oasis_dec_t TBSW0032::get_VAL_RPSS( ) const
    {
        return m_VAL_RPSS;
    }    
    const std::string& TBSW0032::get_TIP_RPSS_VAL( ) const
    {
        return m_TIP_RPSS_VAL;
    }
    oasis_dec_t TBSW0032::get_VAL_RCD( ) const
    {
        return m_VAL_RCD;
    }    
    const std::string& TBSW0032::get_COD_RVDA_PROD_MTC( ) const
    {
        return m_COD_RVDA_PROD_MTC;
    }

} //namespace dbaccess_common
