/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#include "TBSW2017.hpp"

namespace dbaccess_common
{

    TBSW2017::TBSW2017() {
        
        query_fields = "COD_SIT_REG, DES_ORG_BLQO, COD_USR_ULT_ATLZ, DTH_ULT_ATLZ";
		table_name = "TBSW2017";

        codigoSituacaoRegistroPosicao = 1;
        descricaoBloqueioPosicao = 2;
        codigoUsuarioUltimaAlteracaoPosicao = 3;
        dataUltimaAlteracaoRegistroPosicao = 4;

        codigoSituacaoRegistro = "";
        descricaoBloqueio = "" ; 
        codigoUsuarioUltimaAlteracao = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW2017::TBSW2017(const std::string& where) {

        query_fields = "COD_SIT_REG, DES_ORG_BLQO, COD_USR_ULT_ATLZ, DTH_ULT_ATLZ";
        table_name = "TBSW2017";
        where_condition = where;

        codigoSituacaoRegistroPosicao = 1;
        descricaoBloqueioPosicao = 2;
        codigoUsuarioUltimaAlteracaoPosicao = 3;
        dataUltimaAlteracaoRegistroPosicao = 4;

        codigoSituacaoRegistro = "";
        descricaoBloqueio = "" ; 
        codigoUsuarioUltimaAlteracao = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW2017::~TBSW2017() {
    }

    void TBSW2017::bind_columns() {
        bind(codigoSituacaoRegistroPosicao, codigoSituacaoRegistro);
        bind(descricaoBloqueioPosicao, descricaoBloqueio);
        bind(codigoUsuarioUltimaAlteracaoPosicao, codigoUsuarioUltimaAlteracao);
        bind(dataUltimaAlteracaoRegistroPosicao, &dataAlteracaoRegistro);

    }

    // Getters
    const std::string& TBSW2017::GetCodigoSituacaoRegistro() const {
        return codigoSituacaoRegistro;
    }

    const std::string& TBSW2017::GetDescricaoBloqueio() const {
        return descricaoBloqueio;
    }    

    const std::string& TBSW2017::GetCodigoUsuarioUltimaAlteracao() const {
        return codigoUsuarioUltimaAlteracao;
    }

    const dbm_datetime_t& TBSW2017::GetDataUltimaAlteracaoRegistro() const {
        return dataAlteracaoRegistro;
    }


    // Setters
    void TBSW2017::SetCodigoSituacaoRegistro(const std::string& value) {
        codigoSituacaoRegistro = value;
    }

    void TBSW2017::SetDescricaoBloqueio(const std::string& value) {
        descricaoBloqueio = value;
    }    
        
    void TBSW2017::SetCodigoUsuarioUltimaAlteracao(const std::string& value) {
        codigoUsuarioUltimaAlteracao = value;
    }

    void TBSW2017::SetDataUltimaAlteracaoRegistro(const dbm_datetime_t& value) {
        dataAlteracaoRegistro = value;
    }

}
