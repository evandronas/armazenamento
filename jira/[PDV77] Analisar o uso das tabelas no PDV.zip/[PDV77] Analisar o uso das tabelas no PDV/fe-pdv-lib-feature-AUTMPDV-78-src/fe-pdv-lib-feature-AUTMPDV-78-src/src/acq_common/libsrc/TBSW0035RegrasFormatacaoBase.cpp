#include <cstring>
#include<TBSW0035RegrasFormatacaoBase.hpp>

TBSW0035RegrasFormatacaoBase::TBSW0035RegrasFormatacaoBase( )
{
}

TBSW0035RegrasFormatacaoBase::~TBSW0035RegrasFormatacaoBase( )
{
}

void TBSW0035RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::DTH_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_BXA_TEC( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_BXA_TEC( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_BXA_TEC( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_BXA_TEC( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::TIP_TCNL( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_TCNL( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_TCNL( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_ORDM_SERV( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_ORDM_SERV( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_ORDM_SERV( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_OCOR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_OCOR( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_OCOR( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ESTB( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ESTB( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NOM_FNTS_PT_DE_VD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FNTS_PT_DE_VD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FNTS_PT_DE_VD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_TEL_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_TEL_ESTB( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_TEL_ESTB( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::TXT_ENDR_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_ENDR_ESTB( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_ENDR_ESTB( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_TERM( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TERM( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TERM( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_SRE_TERM( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SRE_TERM( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SRE_TERM( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_SRE_PNPD_EXT( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SRE_PNPD_EXT( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SRE_PNPD_EXT( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_ID_PNPD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_ID_PNPD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_ID_PNPD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_APLV_PNPD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_APLV_PNPD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_APLV_PNPD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_VERS_SFTW( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_SFTW( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_SFTW( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_VERS_KRN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_KRN( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_KRN( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NOM_MODL_CHIP( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_MODL_CHIP( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_MODL_CHIP( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_SRE_SMCRD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SRE_SMCRD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SRE_SMCRD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NOM_OPER( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_OPER( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_OPER( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_ID_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_ID_TEC( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_ID_TEC( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_EPS( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_EPS( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_EPS( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_IP_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_IP_PRMI( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_IP_PRMI( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_PRTA_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_PRTA_PRMI( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_PRTA_PRMI( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_IP_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_IP_SECD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_IP_SECD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_PRTA_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_PRTA_SECD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_PRTA_SECD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NOM_URL_CNFR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_URL_CNFR( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_URL_CNFR( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::QTD_TRAN_GPRS_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_TRAN_GPRS_PRMI( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_TRAN_GPRS_PRMI( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::QTD_TRAN_GSM_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_TRAN_GSM_PRMI( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_TRAN_GSM_PRMI( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::QTD_TRAN_GPRS_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_TRAN_GPRS_SECD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_TRAN_GPRS_SECD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::QTD_TRAN_GSM_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_TRAN_GSM_SECD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_TRAN_GSM_SECD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::COD_STTU_RPLC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_STTU_RPLC( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_STTU_RPLC( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::QTD_TNTA_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_TNTA_PRMI( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_TNTA_PRMI( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::QTD_TNTA_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_TNTA_SECD( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_TNTA_SECD( tbsw0035, params );
    }
}

void TBSW0035RegrasFormatacaoBase::NUM_TEL_ADIC_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_TEL_ADIC_ESTB( tbsw0035, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_TEL_ADIC_ESTB( tbsw0035, params );
    }
}

// Tratamentos genericos

void TBSW0035RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
	oasis_dec_t dect;
	dbm_longtodec( &dect, params.refnum );
    tbsw0035.set_NUM_SEQ_UNC( dect );
}

void TBSW0035RegrasFormatacaoBase::gen_DTH_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_DTH_BXA_TEC( 0 );
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    oasis_dec_t l_dect;

    dbm_chartodec( &l_dect, params.adm_num_bxa_tec.c_str( ), 0 );
    tbsw0035.set_NUM_BXA_TEC( l_dect );
}

void TBSW0035RegrasFormatacaoBase::gen_TIP_TCNL( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.merchant_in_tpo_tcn.empty( ) || strlen( params.merchant_in_tpo_tcn.c_str( ) ) == 0 )
    {
        tbsw0035.set_TIP_TCNL( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_TIP_TCNL( params.merchant_in_tpo_tcn );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_COD_ORDM_SERV( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_COD_ORDM_SERV( std::string( " " ) );
}

void TBSW0035RegrasFormatacaoBase::gen_COD_OCOR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_COD_OCOR( std::string( " " ) );
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_NUM_ESTB( params.termloc );
}

void TBSW0035RegrasFormatacaoBase::gen_NOM_FNTS_PT_DE_VD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.merchant_mer_name.empty( ) || strlen( params.merchant_mer_name.c_str( ) ) == 0 )
    {
        tbsw0035.set_NOM_FNTS_PT_DE_VD( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_NOM_FNTS_PT_DE_VD( params.merchant_mer_name );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_TEL_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    oasis_dec_t l_dect;

    dbm_chartodec( &l_dect, " " , 0 );
    tbsw0035.set_NUM_TEL_ESTB( l_dect );
}

void TBSW0035RegrasFormatacaoBase::gen_TXT_ENDR_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_TXT_ENDR_ESTB( std::string( " " ) );
}

void TBSW0035RegrasFormatacaoBase::gen_COD_TERM( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.termid.empty( ) || strlen( params.termid.c_str( ) ) == 0 )
    {
        tbsw0035.set_COD_TERM( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_COD_TERM( params.termid );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_SRE_TERM( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_num_sre_term.empty( ) || strlen( params.adm_num_sre_term.c_str( ) ) == 0 )
    {
        tbsw0035.set_NUM_SRE_TERM( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_NUM_SRE_TERM( params.adm_num_sre_term );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_SRE_PNPD_EXT( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_num_sre_pnpd_ext.empty( ) || strlen( params.adm_num_sre_pnpd_ext.c_str( ) ) == 0 )
    {
        tbsw0035.set_NUM_SRE_PNPD_EXT( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_NUM_SRE_PNPD_EXT( params.adm_num_sre_pnpd_ext );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_COD_ID_PNPD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_cod_id_pnpd.empty( ) || strlen( params.adm_cod_id_pnpd.c_str( ) ) == 0 )
    {
        tbsw0035.set_COD_ID_PNPD( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_COD_ID_PNPD( params.adm_cod_id_pnpd );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_COD_APLV_PNPD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_cod_aplv_pnpd.empty( ) || strlen( params.adm_cod_aplv_pnpd.c_str( ) ) == 0 )
    {
        tbsw0035.set_COD_APLV_PNPD( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_COD_APLV_PNPD( params.adm_cod_aplv_pnpd );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_COD_VERS_SFTW( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if( !params.merchant_cod_vers_sftw.empty( ) )
    {
        tbsw0035.set_COD_VERS_SFTW( params.merchant_cod_vers_sftw.substr( 0, 10 ) );
    }
    else
    {
        tbsw0035.set_COD_VERS_SFTW( std::string( "" ) );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_COD_VERS_KRN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_cod_vers_krn.empty( ) || strlen( params.adm_cod_vers_krn.c_str( ) ) == 0 )
    {
        tbsw0035.set_COD_VERS_KRN( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_COD_VERS_KRN( params.adm_cod_vers_krn );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_NOM_MODL_CHIP( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_nom_modl_chip.empty( ) || strlen( params.adm_nom_modl_chip.c_str( ) ) == 0 )
    {
        tbsw0035.set_NOM_MODL_CHIP( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_NOM_MODL_CHIP( params.adm_nom_modl_chip );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_SRE_SMCRD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_num_sre_smcrd.empty( ) || strlen( params.adm_num_sre_smcrd.c_str( ) ) == 0 )
    {
        tbsw0035.set_NUM_SRE_SMCRD( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_NUM_SRE_SMCRD( params.adm_num_sre_smcrd );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_NOM_OPER( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_nom_oper.empty( ) || strlen( params.adm_nom_oper.c_str( ) ) == 0 )
    {
        tbsw0035.set_NOM_OPER( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_NOM_OPER( params.adm_nom_oper );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_COD_ID_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
}

void TBSW0035RegrasFormatacaoBase::gen_COD_EPS( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
}

void TBSW0035RegrasFormatacaoBase::gen_COD_IP_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_cod_ip_prmi.empty( ) || strlen( params.adm_cod_ip_prmi.c_str( ) ) == 0 )
    {
        tbsw0035.set_COD_IP_PRMI( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_COD_IP_PRMI( params.adm_cod_ip_prmi );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_PRTA_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_NUM_PRTA_PRMI( params.adm_num_prta_prmi );
}

void TBSW0035RegrasFormatacaoBase::gen_COD_IP_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_cod_ip_secd.empty( ) || strlen( params.adm_cod_ip_secd.c_str( ) ) == 0 )
    {
        tbsw0035.set_COD_IP_SECD( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_COD_IP_SECD( params.adm_cod_ip_secd );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_PRTA_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_NUM_PRTA_SECD( params.adm_num_prta_secd );
}

void TBSW0035RegrasFormatacaoBase::gen_NOM_URL_CNFR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    if ( params.adm_nom_url_cnfr.empty( ) || strlen( params.adm_nom_url_cnfr.c_str( ) ) == 0 )
    {
        tbsw0035.set_NOM_URL_CNFR( std::string( " " ) );
    }
    else
    {
        tbsw0035.set_NOM_URL_CNFR( params.adm_nom_url_cnfr );
    }
}

void TBSW0035RegrasFormatacaoBase::gen_QTD_TRAN_GPRS_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_QTD_TRAN_GPRS_PRMI( params.adm_qtd_tran_gprs_prmi );
}

void TBSW0035RegrasFormatacaoBase::gen_QTD_TRAN_GSM_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_QTD_TRAN_GSM_PRMI( params.adm_qtd_tran_gsm_prmi );
}

void TBSW0035RegrasFormatacaoBase::gen_QTD_TRAN_GPRS_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_QTD_TRAN_GPRS_SECD( params.adm_qtd_tran_gprs_secd );
}

void TBSW0035RegrasFormatacaoBase::gen_QTD_TRAN_GSM_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_QTD_TRAN_GSM_SECD( params.adm_qtd_tran_gsm_secd );
}

void TBSW0035RegrasFormatacaoBase::gen_COD_STTU_RPLC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_COD_STTU_RPLC( std::string( "N" ) );
}

void TBSW0035RegrasFormatacaoBase::gen_QTD_TNTA_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_QTD_TNTA_PRMI( params.adm_qtd_tnta_prmi );
}

void TBSW0035RegrasFormatacaoBase::gen_QTD_TNTA_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_QTD_TNTA_SECD( params.adm_qtd_tnta_secd );
}

void TBSW0035RegrasFormatacaoBase::gen_NUM_TEL_ADIC_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    tbsw0035.set_NUM_TEL_ADIC_ESTB( params.local_num_tel_adic_estb );
}

// Tratamentos de INSERTS

void TBSW0035RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_DAT_MOV_TRAN( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_SEQ_UNC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_DTH_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_DTH_BXA_TEC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_BXA_TEC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_TIP_TCNL( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_TIP_TCNL( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_ORDM_SERV( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_ORDM_SERV( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_OCOR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_OCOR( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_ESTB( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NOM_FNTS_PT_DE_VD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NOM_FNTS_PT_DE_VD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_TEL_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_TEL_ESTB( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_TXT_ENDR_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_TXT_ENDR_ESTB( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_TERM( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_TERM( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_SRE_TERM( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_SRE_TERM( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_SRE_PNPD_EXT( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_SRE_PNPD_EXT( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_ID_PNPD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_ID_PNPD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_APLV_PNPD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_APLV_PNPD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_VERS_SFTW( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_VERS_SFTW( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_VERS_KRN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_VERS_KRN( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NOM_MODL_CHIP( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NOM_MODL_CHIP( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_SRE_SMCRD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_SRE_SMCRD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NOM_OPER( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NOM_OPER( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_ID_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_ID_TEC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_EPS( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_EPS( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_IP_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_IP_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_PRTA_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_PRTA_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_IP_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_IP_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_PRTA_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_PRTA_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NOM_URL_CNFR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NOM_URL_CNFR( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_QTD_TRAN_GPRS_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TRAN_GPRS_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_QTD_TRAN_GSM_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TRAN_GSM_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_QTD_TRAN_GPRS_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TRAN_GPRS_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_QTD_TRAN_GSM_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TRAN_GSM_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_COD_STTU_RPLC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_STTU_RPLC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_QTD_TNTA_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TNTA_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_QTD_TNTA_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TNTA_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::insert_NUM_TEL_ADIC_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_TEL_ADIC_ESTB( tbsw0035, params );
}


// Tratamentos de UPDATES

void TBSW0035RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_DAT_MOV_TRAN( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_SEQ_UNC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_DTH_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_DTH_BXA_TEC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_BXA_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_BXA_TEC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_TIP_TCNL( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_TIP_TCNL( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_ORDM_SERV( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_ORDM_SERV( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_OCOR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_OCOR( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_ESTB( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NOM_FNTS_PT_DE_VD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NOM_FNTS_PT_DE_VD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_TEL_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_TEL_ESTB( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_TXT_ENDR_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_TXT_ENDR_ESTB( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_TERM( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_TERM( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_SRE_TERM( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_SRE_TERM( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_SRE_PNPD_EXT( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_SRE_PNPD_EXT( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_ID_PNPD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_ID_PNPD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_APLV_PNPD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_APLV_PNPD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_VERS_SFTW( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_VERS_SFTW( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_VERS_KRN( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_VERS_KRN( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NOM_MODL_CHIP( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NOM_MODL_CHIP( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_SRE_SMCRD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_SRE_SMCRD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NOM_OPER( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NOM_OPER( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_ID_TEC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_ID_TEC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_EPS( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_EPS( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_IP_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_IP_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_PRTA_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_PRTA_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_IP_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_IP_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_PRTA_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_PRTA_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NOM_URL_CNFR( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NOM_URL_CNFR( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_QTD_TRAN_GPRS_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TRAN_GPRS_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_QTD_TRAN_GSM_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TRAN_GSM_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_QTD_TRAN_GPRS_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TRAN_GPRS_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_QTD_TRAN_GSM_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TRAN_GSM_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_COD_STTU_RPLC( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_COD_STTU_RPLC( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_QTD_TNTA_PRMI( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TNTA_PRMI( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_QTD_TNTA_SECD( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_QTD_TNTA_SECD( tbsw0035, params );
}

void TBSW0035RegrasFormatacaoBase::update_NUM_TEL_ADIC_ESTB( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params )
{
    gen_NUM_TEL_ADIC_ESTB( tbsw0035, params );
}
