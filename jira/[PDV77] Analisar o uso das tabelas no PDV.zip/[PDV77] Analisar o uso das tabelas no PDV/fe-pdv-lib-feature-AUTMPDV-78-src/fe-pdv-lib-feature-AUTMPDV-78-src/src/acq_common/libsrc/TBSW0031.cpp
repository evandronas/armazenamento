#include "TBSW0031.hpp"

namespace dbaccess_common
{
    TBSW0031::TBSW0031( )
    {
        initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0031::TBSW0031( const std::string& whereClause )
    {
        initialize();
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0031::~TBSW0031( )
    {
    }
    
    void TBSW0031::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, NUM_ADM, VAL_MN_CAR, COD_CRT_ECM, COD_CTR, QTD_DIA_CRNC, NUM_SEQ_UNC_RD_AUT, IND_TERM_FATR_EXPS, COD_CTAH_VOCH,COD_PROD_MTC,COD_RGAO_MTC, COD_CPCD_TERM, NUM_REF_TRAN, COD_RET_VLDC_SGRA, NUM_ESTB_PAUZ, COD_TERM_PAUZ";
        table_name = "TBSW0031";

        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_NUM_ADM_pos = 3;
        m_VAL_MN_CAR_pos = 4;
        m_COD_CRT_ECM_pos = 5;
        m_COD_CTR_pos = 6;
        m_QTD_DIA_CRNC_pos = 7;
        m_NUM_SEQ_UNC_RD_AUT_pos = 8;
        m_IND_TERM_FATR_EXPS_pos = 9;
        m_COD_CTAH_VOCH_pos = 10;
        m_COD_PROD_MTC_pos = 11;
        m_COD_RGAO_MTC_pos = 12;
        m_COD_CPCD_TERM_pos = 13;
        m_NUM_REF_TRAN_pos = 14;
        // R10_2018 - Release Outubro - INICIO 
        printedCardSecurityCodePosicao = 15;
        // R10_2018 - Release Outubro - FIM
        numeroEstabelecimentoPreAutorizacaoPosicao = 16;
        codigoTerminalPreAutorizacaoPosicao = 17;
        
        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_NUM_ADM = 0;
        dbm_longtodec( &m_VAL_MN_CAR, 0 );
        m_COD_CRT_ECM = "";
        m_COD_CTR = "";
        m_QTD_DIA_CRNC = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC_RD_AUT, 0 );
        m_IND_TERM_FATR_EXPS = " ";
        m_COD_CTAH_VOCH = "";
        m_COD_PROD_MTC = "";
        m_COD_RGAO_MTC = "";
        m_COD_CPCD_TERM = "";
        m_NUM_REF_TRAN = "";
        // R10_2018 - Release Outubro - INICIO 
        printedCardSecurityCode = "";
        // R10_2018 - Release Outubro - FIM
        numeroEstabelecimentoPreAutorizacao = 0;
        codigoTerminalPreAutorizacao = "";
        
        m_NUM_SEQ_UNC_RD_AUT_ind_null = DBM_NULL_DATA;
        m_QTD_DIA_CRNC_ind_null = DBM_NULL_DATA;
    }

	void TBSW0031::let_as_is( )
	{
        m_NUM_SEQ_UNC_RD_AUT_ind_null = is_null( m_NUM_SEQ_UNC_RD_AUT ) ? DBM_NULL_DATA : 0;
        m_QTD_DIA_CRNC_ind_null = is_null( m_QTD_DIA_CRNC ) ? DBM_NULL_DATA : 0;
	}
	
    void TBSW0031::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_NUM_ADM_pos, m_NUM_ADM );
        bind( m_VAL_MN_CAR_pos, m_VAL_MN_CAR );
        bind( m_COD_CRT_ECM_pos, m_COD_CRT_ECM );
        bind( m_COD_CTR_pos, m_COD_CTR );
        bind( m_QTD_DIA_CRNC_pos, m_QTD_DIA_CRNC, &m_QTD_DIA_CRNC_ind_null );
        bind( m_NUM_SEQ_UNC_RD_AUT_pos, m_NUM_SEQ_UNC_RD_AUT, &m_NUM_SEQ_UNC_RD_AUT_ind_null );
        bind( m_IND_TERM_FATR_EXPS_pos, m_IND_TERM_FATR_EXPS );
        bind( m_COD_CTAH_VOCH_pos, m_COD_CTAH_VOCH );
        bind( m_COD_PROD_MTC_pos, m_COD_PROD_MTC );
        bind( m_COD_RGAO_MTC_pos, m_COD_RGAO_MTC );
        bind( m_COD_CPCD_TERM_pos, m_COD_CPCD_TERM );
        bind( m_NUM_REF_TRAN_pos, m_NUM_REF_TRAN );
        // R10_2018 - Release Outubro - INICIO 
        bind( printedCardSecurityCodePosicao, printedCardSecurityCode );
        // R10_2018 - Release Outubro - FIM
        bind( numeroEstabelecimentoPreAutorizacaoPosicao, numeroEstabelecimentoPreAutorizacao );
        bind( codigoTerminalPreAutorizacaoPosicao, codigoTerminalPreAutorizacao );
    }

    void TBSW0031::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0031::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    void TBSW0031::set_NUM_ADM( unsigned long a_NUM_ADM )
    {
        m_NUM_ADM = a_NUM_ADM;
    }
    void TBSW0031::set_VAL_MN_CAR( oasis_dec_t a_VAL_MN_CAR )
    {
        dbm_deccopy( &m_VAL_MN_CAR, &a_VAL_MN_CAR );
    }
    void TBSW0031::set_COD_CRT_ECM( const std::string& a_COD_CRT_ECM )
    {
        m_COD_CRT_ECM = a_COD_CRT_ECM;
    }
    void TBSW0031::set_COD_CTR( const std::string& a_COD_CTR )
    {
        m_COD_CTR = a_COD_CTR;
    }
    void TBSW0031::set_QTD_DIA_CRNC( unsigned long a_QTD_DIA_CRNC )
    {
        m_QTD_DIA_CRNC = a_QTD_DIA_CRNC;
        m_QTD_DIA_CRNC_ind_null = 0;
    }
    void TBSW0031::set_NUM_SEQ_UNC_RD_AUT( oasis_dec_t a_NUM_SEQ_UNC_RD_AUT )
    {
        m_NUM_SEQ_UNC_RD_AUT=a_NUM_SEQ_UNC_RD_AUT;
        m_NUM_SEQ_UNC_RD_AUT_ind_null = 0;
    }
    void TBSW0031::set_IND_TERM_FATR_EXPS( const std::string& a_IND_TERM_FATR_EXPS )
    {
        m_IND_TERM_FATR_EXPS = a_IND_TERM_FATR_EXPS;
    }
    void TBSW0031::set_COD_CTAH_VOCH( const std::string& a_COD_CTAH_VOCH )
    {
        m_COD_CTAH_VOCH = a_COD_CTAH_VOCH;
    }
    void TBSW0031::set_COD_PROD_MTC( const std::string& a_COD_PROD_MTC )
    {
        m_COD_PROD_MTC = a_COD_PROD_MTC;
    }
    void TBSW0031::set_COD_RGAO_MTC( const std::string& a_COD_RGAO_MTC )
    {
        m_COD_RGAO_MTC = a_COD_RGAO_MTC;
    }
    void TBSW0031::set_COD_CPCD_TERM( const std::string& a_COD_CPCD_TERM )
    {
        m_COD_CPCD_TERM = a_COD_CPCD_TERM;
    }
    void TBSW0031::set_NUM_REF_TRAN( const std::string& a_NUM_REF_TRAN )
    {
        m_NUM_REF_TRAN = a_NUM_REF_TRAN;
    }
    // R10_2018 - Release Outubro - INICIO 
	/// SetPrintedCardSecurityCode
	/// Atribui novo valor ao campo COD_RET_VLDC_SGRA
	/// EF/ET : ET1
	/// Historico: [Data] - ET - Descricao
	/// 22/08/2018 - ET1 - Release Outubro 2018
	/// value: Valor a ser atribuido ao campo COD_RET_VLDC_SGRA
	void TBSW0031::SetPrintedCardSecurityCode(const std::string& value)
	{
		printedCardSecurityCode = value;
	}
    // R10_2018 - Release Outubro - FIM
    void TBSW0031::SetNumeroEstabelecimentoPreAutorizacao( unsigned long value )
    {
        numeroEstabelecimentoPreAutorizacao = value;
    }
    void TBSW0031::SetCodigoTerminalPreAutorizacao( const std::string& value )
    {
        codigoTerminalPreAutorizacao = value;
    }

    unsigned long TBSW0031::get_DAT_MOV_TRAN( ) const
    {
        return m_DAT_MOV_TRAN;
    }
    oasis_dec_t TBSW0031::get_NUM_SEQ_UNC( ) const
    {
        return m_NUM_SEQ_UNC;
    }
    unsigned long TBSW0031::get_NUM_ADM( ) const
    {
        return m_NUM_ADM;
    }
    oasis_dec_t TBSW0031::get_VAL_MN_CAR( ) const
    {
        return m_VAL_MN_CAR;
    }
    const std::string& TBSW0031::get_COD_CRT_ECM( ) const
    {
        return m_COD_CRT_ECM;
    }
    const std::string& TBSW0031::get_COD_CTR( ) const
    {
        return m_COD_CTR;
    }
    unsigned long TBSW0031::get_QTD_DIA_CRNC( ) const
    {
        return m_QTD_DIA_CRNC;
    }
    oasis_dec_t TBSW0031::get_NUM_SEQ_UNC_RD_AUT() const
    {
        return m_NUM_SEQ_UNC_RD_AUT;
    }
    const std::string& TBSW0031::get_IND_TERM_FATR_EXPS( ) const
    {
        return m_IND_TERM_FATR_EXPS;
    }
    const std::string& TBSW0031::get_COD_CTAH_VOCH( ) const
    {
        return( m_COD_CTAH_VOCH );
    }
    const std::string& TBSW0031::get_COD_PROD_MTC() const
    {
        return m_COD_PROD_MTC;
    }
    const std::string& TBSW0031::get_COD_RGAO_MTC() const
    {
        return m_COD_RGAO_MTC;
    }
    const std::string& TBSW0031::get_COD_CPCD_TERM() const
    {
        return m_COD_CPCD_TERM;
    }
    const std::string& TBSW0031::get_NUM_REF_TRAN() const
    {
        return m_NUM_REF_TRAN;
    }
    
    // R10_2018 - Release Outubro - INICIO 
    /// GetPrintedCardSecurityCode
	/// Obtem o valor do campo COD_RET_VLDC_SGRA
	/// EF/ET : ET1
	/// Historico: [Data] - ET - Descricao
	/// 22/08/2018 - ET1 - Release Outubro 2018
	const std::string& TBSW0031::GetPrintedCardSecurityCode() const
	{
		return printedCardSecurityCode;
	}
    // R10_2018 - Release Outubro - FIM
    unsigned long TBSW0031::GetNumeroEstabelecimentoPreAutorizacao( ) const
    {
        return numeroEstabelecimentoPreAutorizacao;
    }
    const std::string& TBSW0031::GetCodigoTerminalPreAutorizacao() const
    {
        return codigoTerminalPreAutorizacao;
    }

} // namespace dbaccess_common

