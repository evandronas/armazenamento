#include <cstring>
#include<sstream>
#include<TBSW0032RegrasFormatacaoBase.hpp>
#include <iostream>

TBSW0032RegrasFormatacaoBase::TBSW0032RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0032RegrasFormatacaoBase::~TBSW0032RegrasFormatacaoBase( )
{
}

void TBSW0032RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::NUM_BCO_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_BCO_ESTB( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_BCO_ESTB( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::NUM_BCO_DEB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_BCO_DEB( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_BCO_DEB( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::NUM_EMSR( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_EMSR( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_EMSR( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::NUM_AGE_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_AGE_ESTB( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_AGE_ESTB( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::COD_CTA_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CTA_ESTB( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CTA_ESTB( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::COD_VD_BCO( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VD_BCO( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VD_BCO( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_SQUE( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_SQUE( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::IND_CNFR_PSTV( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_CNFR_PSTV( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_CNFR_PSTV( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::IND_IMPR_CPOM( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_IMPR_CPOM( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_IMPR_CPOM( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::QTD_DIA_CRNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_DIA_CRNC( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_DIA_CRNC( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::IND_CAR_MLTP( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_CAR_MLTP( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_CAR_MLTP( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::VAL_LQDC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_LQDC( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_LQDC( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::VAL_RPSS( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_RPSS( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_RPSS( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::TIP_RPSS_VAL( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_RPSS_VAL( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_RPSS_VAL( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::VAL_RCD( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_RCD( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_RCD( tbsw0032, params );
    }
}

void TBSW0032RegrasFormatacaoBase::COD_RVDA_PROD_MTC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_RVDA_PROD_MTC( tbsw0032, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_RVDA_PROD_MTC( tbsw0032, params );
    }
}


void TBSW0032RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_NUM_BCO_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_NUM_BCO_DEB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_NUM_EMSR( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_NUM_AGE_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_COD_CTA_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_COD_VD_BCO( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_IND_CNFR_PSTV( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_IND_IMPR_CPOM( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_QTD_DIA_CRNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_IND_CAR_MLTP( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_VAL_LQDC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_VAL_RPSS( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_TIP_RPSS_VAL( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_VAL_RCD( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::gen_COD_RVDA_PROD_MTC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    if ( params.iss_name == "MAESTRO"  || params.iss_name == "HIPERCARD_DBT"  || params.iss_name == "HIPERCARD_DBT_HMV"  || params.iss_name == "MASTER_HIPER_DBT" )
    {
        if ( params.mc_info_cod_rvda_prod.length( ) ) 
        {
            tbsw0032.set_COD_RVDA_PROD_MTC( params.mc_info_cod_rvda_prod );
        }
    }
}


void TBSW0032RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    tbsw0032.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0032RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw0032.set_NUM_SEQ_UNC( l_dect );
}

void TBSW0032RegrasFormatacaoBase::insert_NUM_BCO_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    tbsw0032.set_NUM_BCO_ESTB( params.nu_bco_etb );
}

void TBSW0032RegrasFormatacaoBase::insert_NUM_BCO_DEB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    tbsw0032.set_NUM_BCO_DEB( 999 );
}

void TBSW0032RegrasFormatacaoBase::insert_NUM_EMSR( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    if( params.iss_name == "MAESTRO" || params.iss_name == "HIPERCARD_DBT" || params.iss_name == "HIPERCARD_DBT_HMV" || params.iss_name == "MASTER_HIPER_DBT" )
    {
        tbsw0032.set_NUM_EMSR( 18 );
    }
    else
    {
        tbsw0032.set_NUM_EMSR( atol( params.bin.substr( 0 , 2 ).c_str( ) ) );
    }
}

void TBSW0032RegrasFormatacaoBase::insert_NUM_AGE_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.nu_age_etb );
    tbsw0032.set_NUM_AGE_ESTB( l_dect );
}

void TBSW0032RegrasFormatacaoBase::insert_COD_CTA_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    if ( strlen( params.cd_cta_etb.c_str( ) ) > 10 )
    {
        tbsw0032.set_COD_CTA_ESTB( params.cd_cta_etb.substr( 0 , 10 ).c_str( ) );
    }
    else if ( strlen( params.cd_cta_etb.c_str( ) ) > 0 )
    {
        tbsw0032.set_COD_CTA_ESTB( std::string( 10 - strlen( params.cd_cta_etb.c_str( ) ), '0' ).append( params.cd_cta_etb ).c_str( ) );
    }
    else
    {
        tbsw0032.set_COD_CTA_ESTB( " " );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0032RegrasFormatacaoBase::insert_COD_VD_BCO( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    tbsw0032.set_COD_VD_BCO( std::string(" ") );
}

void TBSW0032RegrasFormatacaoBase::insert_VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::insert_IND_CNFR_PSTV( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    oasis_dec_t l_dect_amount;
    oasis_dec_t l_dect_aux;

    dbm_dbltodec( &l_dect_aux, ( double ) 50.00 );

    if ( strlen( params.amount.c_str( ) ) > 0 )
    {
        dbm_chartodec( &l_dect_amount, params.amount.c_str( ), 0 );
    }

    if ( strlen( params.cap_positive_conf.c_str( ) ) && !params.cap_positive_conf.compare( "S" ) )
    {
        if ( !params.cap_data_positive_conf.compare( "N" ) )
        {
            if ( ( dbm_deccmp( &l_dect_amount, &l_dect_aux ) ) <= 0 )
            {
                tbsw0032.set_IND_CNFR_PSTV( "1" );
            }
            else
            {
                tbsw0032.set_IND_CNFR_PSTV( "4" );
            }
        }
        else if ( !params.cap_data_positive_conf.compare( "S" ) )
        {
            tbsw0032.set_IND_CNFR_PSTV( "2" );
        }
        else
        {
            tbsw0032.set_IND_CNFR_PSTV( "3" );
        }
    } 
    else 
    {
        if ( !strlen( params.cap_positive_conf.c_str( ) ) || !params.cap_positive_conf.compare( "N" ) )
        {
            tbsw0032.set_IND_CNFR_PSTV( "0" );
        }
        else
        {
            tbsw0032.set_IND_CNFR_PSTV( "3" );
        }
    }
}

void TBSW0032RegrasFormatacaoBase::insert_IND_IMPR_CPOM( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    tbsw0032.set_IND_IMPR_CPOM( "S" );
}

void TBSW0032RegrasFormatacaoBase::insert_QTD_DIA_CRNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    tbsw0032.set_QTD_DIA_CRNC( 0 );
}

void TBSW0032RegrasFormatacaoBase::insert_IND_CAR_MLTP( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::insert_VAL_LQDC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::insert_VAL_RPSS( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
	/*oasis_dec_t val_rpss;
	
	dbm_chartodec( &val_rpss, params.val_cob_tran.c_str( ), 0 );
	
	tbsw0032.set_VAL_RPSS( val_rpss );*/
	WARNING_INVALID_FUNCTION;
 }

void TBSW0032RegrasFormatacaoBase::insert_TIP_RPSS_VAL( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    // t719926 - GAPS Revisao do MER - 13/07/2016 - Inicio
	if( params.msg_category.compare( "ADV_NEGADO" ) == 0 )
    {
        tbsw0032.set_TIP_RPSS_VAL( std::string(" ") );
    }
    else
    {
        if ( params.tip_cob_tran_mtc.length() )
        {
            tbsw0032.set_TIP_RPSS_VAL( params.tip_cob_tran_mtc );
        }
    }
    // t719926 - GAPS Revisao do MER - 13/07/2016 - Fim
}

void TBSW0032RegrasFormatacaoBase::insert_VAL_RCD( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    oasis_dec_t null_value;
    dbm_inttodec( &null_value, 0 );
    tbsw0032.set_VAL_RCD( null_value );
}

void TBSW0032RegrasFormatacaoBase::insert_COD_RVDA_PROD_MTC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    gen_COD_RVDA_PROD_MTC( tbsw0032, params );
}


void TBSW0032RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_NUM_BCO_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_NUM_BCO_DEB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    if ( params.iss_name == "CABAL_DBT" && strlen( params.mc_info_prod_code.c_str( ) ) )
    {
        tbsw0032.set_NUM_BCO_DEB( atol( params.mc_info_prod_code.c_str( ) ) );
    }
    else
    {
        tbsw0032.set_NUM_BCO_DEB( 999 );
    }
}

void TBSW0032RegrasFormatacaoBase::update_NUM_EMSR( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_NUM_AGE_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_COD_CTA_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_COD_VD_BCO( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_IND_CNFR_PSTV( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_IND_IMPR_CPOM( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_QTD_DIA_CRNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_IND_CAR_MLTP( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{   //a variavel ind_car_mltp ja vem preenchida do emissor...
    //a regra descrita no MER descreve como o EMISSOR faz para preencher a variavel
    //aqui no ACQ basta inserir o que o emissor mandou...
    tbsw0032.set_IND_CAR_MLTP( *(params.ind_car_mltp.c_str()) == 'S' ?  params.ind_car_mltp.c_str() : "N" );
}

void TBSW0032RegrasFormatacaoBase::update_VAL_LQDC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
	// t689066 (723417) - GAPS Revisao do MER - 15/05/2017 - Inicio

   	if(  params.status != 2 )
	{
        if( tbsw0032.get_TIP_RPSS_VAL( ).compare( "X" ) == 0 )
        {
            oasis_dec_t zero_value;
            dbm_inttodec( &zero_value, 0 );
            tbsw0032.set_VAL_LQDC( zero_value );
        }
        else
        {
            oasis_dec_t l_dect;
            //oasis_dec_t l_val_rpss = tbsw0032.get_VAL_RPSS( );
			oasis_dec_t l_val_rpss;
            dbm_chartodec( &l_val_rpss, params.vlTrfTxaMtc.c_str( ), 0 );
            if( tbsw0032.get_TIP_RPSS_VAL( ).compare( "T" ) == 0 )
            {
                dbm_chartodec( &l_dect, params.amount.c_str( ), 0 );
                dbm_decmul( &l_dect, &l_dect, &l_val_rpss );
                dbm_decnmul( &l_dect, 0.01 );
            }
            else if( tbsw0032.get_TIP_RPSS_VAL( ).compare( "V" ) == 0 )
            {
                dbm_deccopy( &l_dect, &l_val_rpss );
            }
            else
            {
                WARNING_FLOW_ERROR;
            }
            
            double d_val_lqdc = 0;
            d_val_lqdc = dbm_dectodbl( &l_dect );

            //Arredondando a terceira casa decimal
            double diff = 0;
            diff = ( int( d_val_lqdc * 1000 ) % 10 );
            if( diff >= 5 )
            {
                d_val_lqdc += ( 0.01 - ( diff / 1000 ) );
            }
            else
            {
                d_val_lqdc -= ( diff / 1000 );
            }
            
            //Dividindo por 2 e truncando o valor em 2 cadas decimais
            d_val_lqdc /= 2;
            d_val_lqdc = int( d_val_lqdc * 100 ) / 100.0;

            dbm_dbltodec( &l_dect, d_val_lqdc );
            tbsw0032.set_VAL_LQDC( l_dect );
        }
    }
    // t689066 (723417) - GAPS Revisao do MER - 15/05/2017 - Fim
}

void TBSW0032RegrasFormatacaoBase::update_VAL_RPSS( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
	oasis_dec_t val_rpss;
    // t689066 (723417) - GAPS Revisao do MER - 15/05/2017 - Inicio

    if( params.status != 2 )
	{
        // o campo "val_cob_tran" jah estah ajustado com o seguinte algoritmo
        // SE DATA do DIA maior igual TBSW0041.DAT_INI_COB_ATU
        //      atribui o valor de TBSW0041.VAL_COB_TRAN_ATU
        // SENAO
        //      atribui o valor de TBSW0041.VAL_COB_TRAN_ANT
        // Isto jah esta sendo feito nos DataManip "EnriquecimentoTBSW0041Debito" dos "acqsrv_dbt" dos FEPOS e FEPDV
		// No request o valor estah trafegando por evento
        dbm_chartodec( &val_rpss, params.vlTrfTxaMtc.c_str( ), 0 );
		tbsw0032.set_VAL_RPSS( val_rpss );
	}
    // se transacao negada deixa NULL
    // t689066 (723417) - GAPS Revisao do MER - 15/05/2017 - Fim
}

void TBSW0032RegrasFormatacaoBase::update_TIP_RPSS_VAL( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_VAL_RCD( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0032RegrasFormatacaoBase::update_COD_RVDA_PROD_MTC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params )
{
    gen_COD_RVDA_PROD_MTC( tbsw0032, params );
}
