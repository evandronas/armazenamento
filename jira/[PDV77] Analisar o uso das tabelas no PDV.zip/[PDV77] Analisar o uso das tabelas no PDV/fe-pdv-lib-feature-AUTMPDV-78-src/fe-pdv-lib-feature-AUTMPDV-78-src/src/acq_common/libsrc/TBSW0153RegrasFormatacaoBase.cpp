/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo de Souza
Data     : 20/09/2018
Empresa  : Rede
Descricao: Correcao para gravar o campo valor efetivo aprovado
ID       : BIP 234.996
*************************************************************
Autor    : Fernando Brum
Data     : 17/10/2019
Empresa  : Rede
Descricao: Alteracao do valor do campo de roteamento voucher no BD
ID       : EAK-1848
*************************************************************
*/
#include<TBSW0153RegrasFormatacaoBase.hpp>

TBSW0153RegrasFormatacaoBase::TBSW0153RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0153RegrasFormatacaoBase::~TBSW0153RegrasFormatacaoBase( )
{
}

void TBSW0153RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0153, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0153, params );
    }
}

void TBSW0153RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0153, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0153, params );
    }
}

void TBSW0153RegrasFormatacaoBase::IND_VAL_APR_SLDO_DSPL( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_VAL_APR_SLDO_DSPL( tbsw0153, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_VAL_APR_SLDO_DSPL( tbsw0153, params );
    }
}

void TBSW0153RegrasFormatacaoBase::NUM_EMSR( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_EMSR( tbsw0153, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_EMSR( tbsw0153, params );
    }
}

void TBSW0153RegrasFormatacaoBase::VAL_EFTV_APRV( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_EFTV_APRV( tbsw0153, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_EFTV_APRV( tbsw0153, params );
    }
}

void TBSW0153RegrasFormatacaoBase::NUM_RTDR_TRK( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_RTDR_TRK( tbsw0153, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_RTDR_TRK( tbsw0153, params );
    }
}

void TBSW0153RegrasFormatacaoBase::DTH_VD_TERM( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_VD_TERM( tbsw0153, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_VD_TERM( tbsw0153, params );
    }
}

void TBSW0153RegrasFormatacaoBase::COD_MOT_APRV_OFLN( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MOT_APRV_OFLN( tbsw0153, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MOT_APRV_OFLN( tbsw0153, params );
    }
}

// Metodos utilizados por campos que tem input generico (INSERT/UPDATE)

void TBSW0153RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::gen_IND_VAL_APR_SLDO_DSPL( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::gen_NUM_EMSR( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::gen_VAL_EFTV_APRV( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::gen_NUM_RTDR_TRK( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::gen_DTH_VD_TERM( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::gen_COD_MOT_APRV_OFLN( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

// Metodos especificos para INSERT

void TBSW0153RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    tbsw0153.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0153RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw0153.set_NUM_SEQ_UNC( l_dect );
}

void TBSW0153RegrasFormatacaoBase::insert_IND_VAL_APR_SLDO_DSPL( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    tbsw0153.set_IND_VAL_APR_SLDO_DSPL( "N" );
}

void TBSW0153RegrasFormatacaoBase::insert_NUM_EMSR( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    tbsw0153.set_NUM_EMSR( params.bin / 10000 );
}

void TBSW0153RegrasFormatacaoBase::insert_VAL_EFTV_APRV( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    oasis_dec_t dect;
    dbm_chartodec( &dect, params.valEftvAprv.c_str( ), 0 );
    if( dbm_cmpzero( &dect ) > 0 )
    {
    	tbsw0153.set_VAL_EFTV_APRV( dect );
    }
}

void TBSW0153RegrasFormatacaoBase::insert_NUM_RTDR_TRK( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    /* BRUM - EAK-1848 - 17/10/2019 - Alteração do valor do campo de roteamento voucher no BD */
    tbsw0153.set_NUM_RTDR_TRK( params.num_rtdr );
}

void TBSW0153RegrasFormatacaoBase::insert_DTH_VD_TERM( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    tbsw0153.set_DTH_VD_TERM( AcqUtils::dateTime( params.local_date, params.local_time ) );
}

void TBSW0153RegrasFormatacaoBase::insert_COD_MOT_APRV_OFLN( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    if( params.ind_mot_aprov_chip != "" )
    {
        std::string cod_mot_aprv_ofln("");
        if( ( params.ind_mot_aprov_chip != "1" ) && ( params.tentativa_offline == "TRUE" ) )
        {
            cod_mot_aprv_ofln = "3";
        }
        else if( params.ind_mot_aprov_chip == "1" )
        {
            cod_mot_aprv_ofln = "2";
        }
        else
        {
            cod_mot_aprv_ofln = "1";
        }
        
        tbsw0153.set_COD_MOT_APRV_OFLN( cod_mot_aprv_ofln );
    }
    else
    {
        tbsw0153.set_COD_MOT_APRV_OFLN( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

// Metodos especificos para UPDATE

void TBSW0153RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::update_IND_VAL_APR_SLDO_DSPL( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::update_NUM_EMSR( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::update_VAL_EFTV_APRV( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::update_NUM_RTDR_TRK( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::update_DTH_VD_TERM( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0153RegrasFormatacaoBase::update_COD_MOT_APRV_OFLN( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params )
{
    WARNING_INVALID_FUNCTION;
}
