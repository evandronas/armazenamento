/* Copyright 2018 Rede S.A.
Autor : Danilo Oliveira
Empresa : FIS
*/

#include<Tbsw0162RegrasFormatacaoBase.hpp>
#include <sstream>
#include <AcqUtils.hpp>
#include <string>

/// Tbsw0162RegrasFormatacaoBase
/// Construtor padrao da classe
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
Tbsw0162RegrasFormatacaoBase::Tbsw0162RegrasFormatacaoBase( )
{
}

/// ~Tbsw0162RegrasFormatacaoBase
/// Destrutor padrao da classe
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
Tbsw0162RegrasFormatacaoBase::~Tbsw0162RegrasFormatacaoBase( )
{
}

/// DataMovimentoTransacao
/// Interface para que os plugins possam solicitar formatacao do campo DAT_MOV_TRAN
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
/// operacao: informa se a formatacao eh para INSERT ou UPDATE
void Tbsw0162RegrasFormatacaoBase::DataMovimentoTransacao( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao )
{
    // Chama o respectivo metodo, de acordo com a operacao informada
    if( operacao == acq_common::INSERT )
    {
        InsertDataMovimentoTransacao( tbsw0162, paramsTbsw0162 );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateDataMovimentoTransacao( tbsw0162, paramsTbsw0162 );
    }
}

/// NumeroSequencialUnico
/// Interface para que os plugins possam solicitar formatacao do campo NUM_SEQ_UNC
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
/// operacao: informa se a formatacao eh para INSERT ou UPDATE
void Tbsw0162RegrasFormatacaoBase::NumeroSequencialUnico( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao )
{
    // Chama o respectivo metodo, de acordo com a operacao informada
    if( operacao == acq_common::INSERT )
    {
        InsertNumeroSequencialUnico( tbsw0162, paramsTbsw0162 );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateNumeroSequencialUnico( tbsw0162, paramsTbsw0162 );
    }
}

/// CodigoTerminal
/// Interface para que os plugins possam solicitar formatacao do campo COD_TERM
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
/// operacao: informa se a formatacao eh para INSERT ou UPDATE
void Tbsw0162RegrasFormatacaoBase::CodigoTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao )
{
    // Chama o respectivo metodo, de acordo com a operacao informada
    if( operacao == acq_common::INSERT )
    {
        InsertCodigoTerminal( tbsw0162, paramsTbsw0162 );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateCodigoTerminal( tbsw0162, paramsTbsw0162 );
    }
}

/// NumeroEstabelecimento
/// Interface para que os plugins possam solicitar formatacao do campo NUM_ESTB
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
/// operacao: informa se a formatacao eh para INSERT ou UPDATE
void Tbsw0162RegrasFormatacaoBase::NumeroEstabelecimento( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao )
{
    // Chama o respectivo metodo, de acordo com a operacao informada
    if( operacao == acq_common::INSERT )
    {
        InsertNumeroEstabelecimento( tbsw0162, paramsTbsw0162 );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateNumeroEstabelecimento( tbsw0162, paramsTbsw0162 );
    }
}

/// NumeroSerieTerminal
/// Interface para que os plugins possam solicitar formatacao do campo NUM_SRE_TERM
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
/// operacao: informa se a formatacao eh para INSERT ou UPDATE
void Tbsw0162RegrasFormatacaoBase::NumeroSerieTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao )
{
    // Chama o respectivo metodo, de acordo com a operacao informada
    if( operacao == acq_common::INSERT )
    {
        InsertNumeroSerieTerminal( tbsw0162, paramsTbsw0162 );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateNumeroSerieTerminal( tbsw0162, paramsTbsw0162 );
    }
}

/// UpdateDataMovimentoTransacao
/// Metodo para formatar o campo DAT_MOV_TRAN antes de um update
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::UpdateDataMovimentoTransacao( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// UpdateNumeroSequencialUnico
/// Metodo para formatar o campo NUM_SEQ_UNC antes de um update
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::UpdateNumeroSequencialUnico( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// UpdateCodigoTerminal
/// Metodo para formatar o campo COD_TERM antes de um update
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::UpdateCodigoTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// UpdateNumeroEstabelecimento
/// Metodo para formatar o campo NUM_ESTB antes de um update
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::UpdateNumeroEstabelecimento( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// UpdateNumeroSerieTerminal
/// Metodo para formatar o campo NUM_SRE_TERM antes de um update
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::UpdateNumeroSerieTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// InsertDataMovimentoTransacao
/// Metodo para formatar o campo DAT_MOV_TRAN antes de um insert
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::InsertDataMovimentoTransacao( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    // CAMPO APENAS PARA PDV
    WARNING_INVALID_FUNCTION;
}

/// InsertNumeroSequencialUnico
/// Metodo para formatar o campo NUM_SEQ_UNC antes de um insert
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::InsertNumeroSequencialUnico( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    // CAMPO APENAS PARA PDV
    WARNING_INVALID_FUNCTION;
}

/// InsertCodigoTerminal
/// Metodo para formatar o campo COD_TERM antes de um insert
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::InsertCodigoTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    // CAMPO APENAS PARA PDV
    WARNING_INVALID_FUNCTION;
}

/// InsertNumeroEstabelecimento
/// Metodo para formatar o campo NUM_ESTB antes de um insert
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::InsertNumeroEstabelecimento( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    // CAMPO APENAS PARA PDV
    WARNING_INVALID_FUNCTION;
}

/// InsertNumeroSerieTerminal
/// Metodo para formatar o campo NUM_SRE_TERM antes de um insert
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::InsertNumeroSerieTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    // CAMPO APENAS PARA PDV
    WARNING_INVALID_FUNCTION;
}

/// GenDataMovimentoTransacao
/// Metodo para formatar o campo DAT_MOV_TRAN (implementado quando Insert e Update forem iguais)
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::GenDataMovimentoTransacao( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// GenNumeroSequencialUnico
/// Metodo para formatar o campo NUM_SEQ_UNC (implementado quando Insert e Update forem iguais)
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::GenNumeroSequencialUnico( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// GenCodigoTerminal
/// Metodo para formatar o campo COD_TERM (implementado quando Insert e Update forem iguais)
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::GenCodigoTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// GenNumeroEstabelecimento
/// Metodo para formatar o campo NUM_ESTB (implementado quando Insert e Update forem iguais)
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::GenNumeroEstabelecimento( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

/// GenNumeroSerieTerminal
/// Metodo para formatar o campo NUM_SRE_TERM (implementado quando Insert e Update forem iguais)
/// EF/ET: 000
/// Historico: 04/05/2018 - 000 - Implementacao inicial
/// tbsw0162: estrutura que devera conter o valor apos a formatacao
/// paramsTbsw0162: estrutura que contem os valores da transacao que sao necessarios para formatacao do campo
void Tbsw0162RegrasFormatacaoBase::GenNumeroSerieTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}
