#include "TBSW0152.hpp"

namespace dbaccess_common
{
    TBSW0152::TBSW0152( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0152::TBSW0152( const std::string& whereClause )
    {
        initialize( );
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0152::~TBSW0152( )
    {
    }
    
    void TBSW0152::initialize( )
    {
        m_log = logger::DebugWriter::getInstance();
        query_fields = "QTD_CICL_CRNC_PRMR_PRCL, QTD_PRCL, DAT_VCTO_PRMR_PRCL, VAL_PRCL_ENTR, VAL_PRCL, PRCN_TX_JURO, PRCN_TX_JURO_MES, PRCN_TX_JURO_ANO, PRCN_TX_JURO_MORA, VAL_PRES_BRTO, VAL_TX_EFTV, VAL_TX_MNSL, DAT_MOV_TRAN, NUM_SEQ_UNC";
        
        table_name = "TBSW0152";
        
        int idx = 1;
        m_QTD_CICL_CRNC_PRMR_PRCL_pos = idx++;
        m_QTD_PRCL_pos = idx++;
        m_DAT_VCTO_PRMR_PRCL_pos = idx++;
        m_VAL_PRCL_ENTR_pos = idx++;
        m_VAL_PRCL_pos = idx++;
        m_PRCN_TX_JURO_pos = idx++;
        m_PRCN_TX_JURO_MES_pos = idx++;
        m_PRCN_TX_JURO_ANO_pos = idx++;
        m_PRCN_TX_JURO_MORA_pos = idx++;
        m_VAL_PRES_BRTO_pos = idx++;
        m_VAL_TX_EFTV_pos = idx++;
        m_VAL_TX_MNSL_pos = idx++;
        m_DAT_MOV_TRAN_pos = idx++;
        m_NUM_SEQ_UNC_pos = idx++;

        m_QTD_CICL_CRNC_PRMR_PRCL = 0;
        m_QTD_PRCL = 0;
        m_DAT_VCTO_PRMR_PRCL = 0;
        dbm_chartodec( &m_VAL_PRCL_ENTR, "0.00", 2 );
        dbm_chartodec( &m_VAL_PRCL, "0.00", 2 );
        dbm_chartodec( &m_PRCN_TX_JURO, "0.00", 2 );
        dbm_chartodec( &m_PRCN_TX_JURO_MES, "0.00", 2 );
        dbm_chartodec( &m_PRCN_TX_JURO_ANO, "0.00", 2 );
        dbm_chartodec( &m_PRCN_TX_JURO_MORA, "0.00", 2 );
        dbm_chartodec( &m_VAL_PRES_BRTO, "0.00", 2 );
        dbm_chartodec( &m_VAL_TX_EFTV, "0.00000", 5 );
        dbm_chartodec( &m_VAL_TX_MNSL, "0.00000", 5 );
        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );

        m_DAT_VCTO_PRMR_PRCL_ind_null = DBM_NULL_DATA;
    }
    
	void TBSW0152::let_as_is( )
	{
		m_DAT_VCTO_PRMR_PRCL_ind_null = is_null( &m_DAT_VCTO_PRMR_PRCL ) ? DBM_NULL_DATA : 0;
	}
	
    void TBSW0152::bind_columns( )
    {
        bind( m_QTD_CICL_CRNC_PRMR_PRCL_pos, m_QTD_CICL_CRNC_PRMR_PRCL );
        bind( m_QTD_PRCL_pos, m_QTD_PRCL );
        bind( m_DAT_VCTO_PRMR_PRCL_pos, &m_DAT_VCTO_PRMR_PRCL, &m_DAT_VCTO_PRMR_PRCL_ind_null );
        bind( m_VAL_PRCL_ENTR_pos, m_VAL_PRCL_ENTR );
        bind( m_VAL_PRCL_pos, m_VAL_PRCL );
        bind( m_PRCN_TX_JURO_pos, m_PRCN_TX_JURO );
        bind( m_PRCN_TX_JURO_MES_pos, m_PRCN_TX_JURO_MES );
        bind( m_PRCN_TX_JURO_ANO_pos, m_PRCN_TX_JURO_ANO );
        bind( m_PRCN_TX_JURO_MORA_pos, m_PRCN_TX_JURO_MORA );
        bind( m_VAL_PRES_BRTO_pos, m_VAL_PRES_BRTO );
        bind( m_VAL_TX_EFTV_pos, m_VAL_TX_EFTV );
        bind( m_VAL_TX_MNSL_pos, m_VAL_TX_MNSL );
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
    }
    
    void TBSW0152::set_QTD_CICL_CRNC_PRMR_PRCL( unsigned long a_QTD_CICL_CRNC_PRMR_PRCL )
    {
        m_QTD_CICL_CRNC_PRMR_PRCL = a_QTD_CICL_CRNC_PRMR_PRCL;
    }
    void TBSW0152::set_QTD_PRCL( unsigned long a_QTD_PRCL )
    {
        m_QTD_PRCL = a_QTD_PRCL;
    }
    void TBSW0152::set_DAT_VCTO_PRMR_PRCL( dbm_datetime_t a_DAT_VCTO_PRMR_PRCL )
    {
        m_DAT_VCTO_PRMR_PRCL = a_DAT_VCTO_PRMR_PRCL;
        m_DAT_VCTO_PRMR_PRCL_ind_null = 0;
    }
    void TBSW0152::set_VAL_PRCL_ENTR( oasis_dec_t a_VAL_PRCL_ENTR )
    {
        dbm_deccopy( &m_VAL_PRCL_ENTR, &a_VAL_PRCL_ENTR );
    }
    void TBSW0152::set_VAL_PRCL( oasis_dec_t a_VAL_PRCL )
    {
        dbm_deccopy( &m_VAL_PRCL, &a_VAL_PRCL );
    }
    void TBSW0152::set_PRCN_TX_JURO( oasis_dec_t a_PRCN_TX_JURO )
    {
        dbm_deccopy( &m_PRCN_TX_JURO, &a_PRCN_TX_JURO );
    }
    void TBSW0152::set_PRCN_TX_JURO_MES( oasis_dec_t a_PRCN_TX_JURO_MES )
    {
        dbm_deccopy( &m_PRCN_TX_JURO_MES, &a_PRCN_TX_JURO_MES );
    }
    void TBSW0152::set_PRCN_TX_JURO_ANO( oasis_dec_t a_PRCN_TX_JURO_ANO )
    {
        dbm_deccopy( &m_PRCN_TX_JURO_ANO, &a_PRCN_TX_JURO_ANO );
    }
    void TBSW0152::set_PRCN_TX_JURO_MORA( oasis_dec_t a_PRCN_TX_JURO_MORA )
    {
        dbm_deccopy( &m_PRCN_TX_JURO_MORA, &a_PRCN_TX_JURO_MORA );
    }
    void TBSW0152::set_VAL_PRES_BRTO( oasis_dec_t a_VAL_PRES_BRTO )
    {
        dbm_deccopy( &m_VAL_PRES_BRTO, &a_VAL_PRES_BRTO );
    }
    void TBSW0152::set_VAL_TX_EFTV( oasis_dec_t a_VAL_TX_EFTV )
    {
        dbm_deccopy( &m_VAL_TX_EFTV, &a_VAL_TX_EFTV );
    }
    void TBSW0152::set_VAL_TX_MNSL( oasis_dec_t a_VAL_TX_MNSL )
    {
        dbm_deccopy( &m_VAL_TX_MNSL, &a_VAL_TX_MNSL );
    }
    void TBSW0152::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0152::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    
    unsigned long TBSW0152::get_QTD_CICL_CRNC_PRMR_PRCL( ) const
    {
        return( m_QTD_CICL_CRNC_PRMR_PRCL );
    }
    unsigned long TBSW0152::get_QTD_PRCL( ) const
    {
        return( m_QTD_PRCL );
    }
    dbm_datetime_t TBSW0152::get_DAT_VCTO_PRMR_PRCL( ) const
    {
        return( m_DAT_VCTO_PRMR_PRCL );
    }
    oasis_dec_t TBSW0152::get_VAL_PRCL_ENTR( ) const
    {
        return( m_VAL_PRCL_ENTR );
    }
    oasis_dec_t TBSW0152::get_VAL_PRCL( ) const
    {
        return( m_VAL_PRCL );
    }
    oasis_dec_t TBSW0152::get_PRCN_TX_JURO( ) const
    {
        return( m_PRCN_TX_JURO );
    }
    oasis_dec_t TBSW0152::get_PRCN_TX_JURO_MES( ) const
    {
        return( m_PRCN_TX_JURO_MES );
    }
    oasis_dec_t TBSW0152::get_PRCN_TX_JURO_ANO( ) const
    {
        return( m_PRCN_TX_JURO_ANO );
    }
    oasis_dec_t TBSW0152::get_PRCN_TX_JURO_MORA( ) const
    {
        return( m_PRCN_TX_JURO_MORA );
    }
    oasis_dec_t TBSW0152::get_VAL_PRES_BRTO( ) const
    {
        return( m_VAL_PRES_BRTO );
    }
    oasis_dec_t TBSW0152::get_VAL_TX_EFTV( ) const
    {
        return( m_VAL_TX_EFTV );
    }
    oasis_dec_t TBSW0152::get_VAL_TX_MNSL( ) const
    {
        return( m_VAL_TX_MNSL );
    }
    unsigned long TBSW0152::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    oasis_dec_t TBSW0152::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }


    void TBSW0152::showxxx( const char *name, unsigned long campo )
    {
        char buf[1000] = {0};
        sprintf(buf, " - %s : [%ld]", name, campo );
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0152::showxxx( const char *name, dbm_datetime_t campo )
    {
        char buf[1000] = {0};
        sprintf(buf, " - %s : [%ld]", name, campo );
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0152::showxxx( const char *name, const std::string& campo )
    {
        char buf[1000] = {0};
        if( campo.size() > 0 )
        {
            sprintf(buf, " - %s : [%s]", name, campo.c_str() );
            m_log->write( logger::LEVEL_DEBUG, buf );
        }
    }
    void TBSW0152::showxxx( const char *name, oasis_dec_t campo )
    {
        char buf[1000] = {0};
        char buf_aux[1000] = {0};
        dbm_dectochar( &campo, buf_aux);
        sprintf(buf, " - %s : [%s]", name, buf_aux );
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0152::show(int nvl)
    {
        char buf[1000];
        sprintf( buf, " <##[%s]##>", table_name.c_str() );
        m_log->write( logger::LEVEL_DEBUG, buf );
        showxxx( "m_DAT_MOV_TRAN",            m_DAT_MOV_TRAN );
        showxxx( "m_NUM_SEQ_UNC",             m_NUM_SEQ_UNC );
        showxxx( "m_QTD_PRCL",                m_QTD_PRCL );
        showxxx( "m_VAL_PRCL",                m_VAL_PRCL );
        showxxx( "m_QTD_CICL_CRNC_PRMR_PRCL", m_QTD_CICL_CRNC_PRMR_PRCL );
        showxxx( "m_DAT_VCTO_PRMR_PRCL",      m_DAT_VCTO_PRMR_PRCL );
        showxxx( "m_PRCN_TX_JURO",            m_PRCN_TX_JURO );
        showxxx( "m_PRCN_TX_JURO_MES",        m_PRCN_TX_JURO_MES );
        showxxx( "m_PRCN_TX_JURO_ANO",        m_PRCN_TX_JURO_ANO );
        showxxx( "m_PRCN_TX_JURO_MORA",       m_PRCN_TX_JURO_MORA );
        showxxx( "m_VAL_TX_EFTV",             m_VAL_TX_EFTV );
        showxxx( "m_VAL_TX_MNSL",             m_VAL_TX_MNSL );
        showxxx( "m_VAL_PRES_BRTO",           m_VAL_PRES_BRTO );
    }
    
} //namespace dbaccess_common
