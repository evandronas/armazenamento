#include "TBSW0113.hpp"

namespace dbaccess_common
{
    TBSW0113::TBSW0113( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0113::TBSW0113( const std::string& whereClause )
    {
        initialize( );
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0113::~TBSW0113( )
    {
    }
    
    void TBSW0113::initialize( )
    {
        query_fields = "COD_STTU_REG, NUM_RTDR, COD_SBPD, COD_EMSR, NOM_EMSR, COD_TRAN_GE, NOM_PROD_CPOM, TXT_RDPE_CPOM, COD_USR_ATLZ_REG, DAT_ATLZ_REG, DAT_ATVC_VOCH, NTWKID, NUM_BIN";

        table_name = "TBSW0113";

        m_COD_STTU_REG_pos = 1;
        m_NUM_RTDR_pos = 2;
        m_COD_SBPD_pos = 3;
        m_COD_EMSR_pos = 4;
        m_NOM_EMSR_pos = 5;
        m_COD_TRAN_GE_pos = 6;
        m_NOM_PROD_CPOM_pos = 7;
        m_TXT_RDPE_CPOM_pos = 8;
        m_COD_USR_ATLZ_REG_pos = 9;
        m_DAT_ATLZ_REG_pos = 10;
        m_DAT_ATVC_VOCH_pos = 11;
        m_NTWKID_pos = 12;
        m_NUM_BIN_pos = 13;

        m_COD_STTU_REG = " ";
        m_NUM_RTDR = 0;
        m_COD_SBPD = 0;
        m_COD_EMSR = 0;
        m_NOM_EMSR = " ";
        m_COD_TRAN_GE = 0;
        m_NOM_PROD_CPOM = " ";
        m_TXT_RDPE_CPOM = "";
        m_COD_USR_ATLZ_REG = " ";
        m_DAT_ATLZ_REG = 0;
        m_DAT_ATVC_VOCH = 0;
        m_NTWKID = "";
        m_NUM_BIN = 0;
    }

    void TBSW0113::bind_columns( )
    {
        bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
        bind( m_NUM_RTDR_pos, m_NUM_RTDR );
        bind( m_COD_SBPD_pos, m_COD_SBPD );
        bind( m_COD_EMSR_pos, m_COD_EMSR );
        bind( m_NOM_EMSR_pos, m_NOM_EMSR );
        bind( m_COD_TRAN_GE_pos, m_COD_TRAN_GE );
        bind( m_NOM_PROD_CPOM_pos, m_NOM_PROD_CPOM );
        bind( m_TXT_RDPE_CPOM_pos, m_TXT_RDPE_CPOM );
        bind( m_COD_USR_ATLZ_REG_pos, m_COD_USR_ATLZ_REG );
        bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
        bind( m_DAT_ATVC_VOCH_pos, &m_DAT_ATVC_VOCH );
        bind( m_NTWKID_pos, m_NTWKID );
        bind( m_NUM_BIN_pos, m_NUM_BIN );
    }
    void TBSW0113::set_COD_STTU_REG( const std::string& a_COD_STTU_REG )
    {
        m_COD_STTU_REG = a_COD_STTU_REG;
    }
    void TBSW0113::set_NUM_RTDR( unsigned long a_NUM_RTDR )
    {
        m_NUM_RTDR = a_NUM_RTDR;
    }
    void TBSW0113::set_COD_SBPD( unsigned long a_COD_SBPD )
    {
        m_COD_SBPD = a_COD_SBPD;
    }
    void TBSW0113::set_COD_EMSR( unsigned long a_COD_EMSR )
    {
        m_COD_EMSR = a_COD_EMSR;
    }
    void TBSW0113::set_NOM_EMSR( const std::string& a_NOM_EMSR )
    {
        m_NOM_EMSR = a_NOM_EMSR;
    }
    void TBSW0113::set_COD_TRAN_GE( unsigned long a_COD_TRAN_GE )
    {
        m_COD_TRAN_GE = a_COD_TRAN_GE;
    }
    void TBSW0113::set_NOM_PROD_CPOM( const std::string& a_NOM_PROD_CPOM )
    {
        m_NOM_PROD_CPOM = a_NOM_PROD_CPOM;
    }
    void TBSW0113::set_TXT_RDPE_CPOM( const std::string& a_TXT_RDPE_CPOM )
    {
        m_TXT_RDPE_CPOM = a_TXT_RDPE_CPOM;
    }
    void TBSW0113::set_COD_USR_ATLZ_REG( const std::string& a_COD_USR_ATLZ_REG )
    {
        m_COD_USR_ATLZ_REG = a_COD_USR_ATLZ_REG;
    }
    void TBSW0113::set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
    {
        m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    void TBSW0113::set_DAT_ATVC_VOCH( dbm_datetime_t a_DAT_ATVC_VOCH )
    {
        m_DAT_ATVC_VOCH = a_DAT_ATVC_VOCH;
    }
    void TBSW0113::set_NTWKID( const std::string& a_NTWKID )
    {
        m_NTWKID = a_NTWKID;
    }
    void TBSW0113::set_NUM_BIN( unsigned long a_NUM_BIN )
    {
        m_NUM_BIN = a_NUM_BIN;
    }
    const std::string& TBSW0113::get_COD_STTU_REG( ) const
    {
        return m_COD_STTU_REG;
    }
    unsigned long TBSW0113::get_NUM_RTDR( ) const
    {
        return m_NUM_RTDR;
    }
    unsigned long TBSW0113::get_COD_SBPD( ) const
    {
        return m_COD_SBPD;
    }
    unsigned long TBSW0113::get_COD_EMSR( ) const
    {
        return m_COD_EMSR;
    }
    const std::string& TBSW0113::get_NOM_EMSR( ) const
    {
        return m_NOM_EMSR;
    }
    unsigned long TBSW0113::get_COD_TRAN_GE( ) const
    {
        return m_COD_TRAN_GE;
    }
    const std::string& TBSW0113::get_NOM_PROD_CPOM( ) const
    {
        return m_NOM_PROD_CPOM;
    }
    const std::string& TBSW0113::get_TXT_RDPE_CPOM( ) const
    {
        return m_TXT_RDPE_CPOM;
    }
    const std::string& TBSW0113::get_COD_USR_ATLZ_REG( ) const
    {
        return m_COD_USR_ATLZ_REG;
    }
    dbm_datetime_t TBSW0113::get_DAT_ATLZ_REG( ) const
    {
        return m_DAT_ATLZ_REG;
    }
    dbm_datetime_t TBSW0113::get_DAT_ATVC_VOCH( ) const
    {
        return m_DAT_ATVC_VOCH;
    }
    const std::string& TBSW0113::get_NTWKID( ) const
    {
        return m_NTWKID;
    }
    unsigned long TBSW0113::get_NUM_BIN( ) const
    {
        return m_NUM_BIN;
    }

} //namespace dbaccess_common
