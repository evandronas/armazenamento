/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#include "TBSW0268.hpp"

namespace dbaccess_common
{

    TBSW0268::TBSW0268() {
        
        query_fields = "COD_BIN_INFR, COD_BIN_SUPR, COD_POS_ENTR_MODO, COD_PROD_BLQO, DAT_INCL_REG, COD_STTU_REG";
		table_name = "TBSW0268";

        codigoBinInferiorPosicao = 1;
        codigoBinSuperiorPosicao = 2;
        codigoEntryModePosicao = 3;
        codigoProdutoPosicao = 4;
        dataInclusaoRegistroPosicao = 5;
        codigoSituacaoRegistroPosicao = 6;

        codigoBinInferior = "";
        codigoBinSuperior = "";
        codigoEntryMode = "" ; 
        codigoProduto = "";
        codigoSituacaoRegistro = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0268::TBSW0268(const std::string& where) {
    
        query_fields = "COD_BIN_INFR, COD_BIN_SUPR, COD_POS_ENTR_MODO, COD_PROD_BLQO, DAT_INCL_REG, COD_STTU_REG";
        table_name = "TBSW0268";
        where_condition = where;

        codigoBinInferiorPosicao = 1;
        codigoBinSuperiorPosicao = 2;
        codigoEntryModePosicao = 3;
        codigoProdutoPosicao = 4;
        dataInclusaoRegistroPosicao = 5;
        codigoSituacaoRegistroPosicao = 6;

        codigoBinInferior = "";
        codigoBinSuperior = "";
        codigoEntryMode = "" ; 
        codigoProduto = "";
        codigoSituacaoRegistro = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0268::~TBSW0268() {
    }

    void TBSW0268::bind_columns() {
        bind(codigoBinInferiorPosicao, codigoBinInferior);
        bind(codigoBinSuperiorPosicao, codigoBinSuperior);
        bind(codigoEntryModePosicao, codigoEntryMode);
        bind(codigoProdutoPosicao, codigoProduto);
        bind(dataInclusaoRegistroPosicao, &dataInclusaoRegistro);
        bind(codigoSituacaoRegistroPosicao, codigoSituacaoRegistro);
    }

    // Getters
    const std::string& TBSW0268::GetCodigoBinInferior() const {
        return codigoBinInferior;
    }

    const std::string& TBSW0268::GetCodigoBinSuperior() const {
        return codigoBinSuperior;
    }

    const std::string& TBSW0268::GetCodigoEntryMode() const {
        return codigoEntryMode;
    }    

    const std::string& TBSW0268::GetCodigoProduto() const {
        return codigoProduto;
    }

    const dbm_datetime_t& TBSW0268::GetDataInclusaoRegistro() const {
        return dataInclusaoRegistro;
    }

    const std::string& TBSW0268::GetCodigoSituacaoRegistro() const {
        return codigoSituacaoRegistro;
    }


    // Setters
    void TBSW0268::SetCodigoBinInferior(const std::string& value) {
        codigoBinInferior = value;
    }

    void TBSW0268::SetCodigoBinSuperior(const std::string& value) {
        codigoBinSuperior = value;
    }

    void TBSW0268::SetCodigoEntryMode(const std::string& value) {
        codigoEntryMode = value;
    }    
        
    void TBSW0268::SetCodigoProduto(const std::string& value) {
        codigoProduto = value;
    }

    void TBSW0268::SetDataInclusaoRegistro(const dbm_datetime_t& value) {
        dataInclusaoRegistro = value;
    }

    void TBSW0268::SetCodigoSituacaoRegistro(const std::string& value) {
        codigoSituacaoRegistro = value;
    }

}
