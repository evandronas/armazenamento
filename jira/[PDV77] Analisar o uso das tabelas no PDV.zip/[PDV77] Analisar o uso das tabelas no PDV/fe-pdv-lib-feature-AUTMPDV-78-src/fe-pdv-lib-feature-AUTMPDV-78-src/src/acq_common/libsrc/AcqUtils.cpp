#include <cstring>
#include<AcqUtils.hpp>
#include<string>
#include <sstream>

AcqUtils::AcqUtils( )
{
}

AcqUtils::~AcqUtils( )
{
}

dbm_datetime_t AcqUtils::dateTime( long a_data, long a_time )
{
    struct tm l_dattim;
    char l_szdate[20], l_sztime[20];
    std::string l_date, l_time;

    memset( &l_dattim, 0, sizeof( l_dattim ) );
    sprintf( l_szdate, "%08ld", a_data );

    if ( strncmp( l_szdate, "0000", 4 ) == 0 )  // Data sem o ano
    {
        time_t now = time( 0 );
        struct tm *l_localtm = localtime( &now );
        int  l_year = l_localtm->tm_year + 1900 ;
        sprintf( l_szdate, "%04d%04ld", l_year, a_data );
    }
    sprintf( l_sztime, "%06ld", a_time );
    l_date = l_szdate;
    l_time = l_sztime;
    l_dattim.tm_sec   = atoi( l_time.substr( 4, 2 ).c_str( ) );
    l_dattim.tm_min   = atoi( l_time.substr( 2, 2 ).c_str( ) );
    l_dattim.tm_hour  = atoi( l_time.substr( 0, 2 ).c_str( ) );
    l_dattim.tm_mday  = atoi( l_date.substr( 6, 2 ).c_str( ) );
    l_dattim.tm_mon   = atoi( l_date.substr( 4, 2 ).c_str( ) ) - 1;
    l_dattim.tm_year  = atoi( l_date.substr( 0, 4 ).c_str( ) ) - 1900;
    l_dattim.tm_isdst = -1;

    return( mktime( &l_dattim ) );
}

dbm_datetime_t AcqUtils::dateTimeGMT( long a_data, long a_time )
{
    struct tm l_dattim;
    struct tm *ptr_dattim;
    time_t l_tim;
    char l_szdate[20], l_sztime[20];
    std::string l_date, l_time;

    memset( &l_dattim, 0, sizeof( l_dattim ) );
    sprintf( l_szdate, "%08ld", a_data );
    sprintf( l_sztime, "%06ld", a_time );
    l_date = l_szdate;
    l_time = l_sztime;
    l_dattim.tm_sec   = atoi( l_time.substr( 4, 2 ).c_str( ) );
    l_dattim.tm_min   = atoi( l_time.substr( 2, 2 ).c_str( ) );
    l_dattim.tm_hour  = atoi( l_time.substr( 0, 2 ).c_str( ) );
    l_dattim.tm_mday  = atoi( l_date.substr( 6, 2 ).c_str( ) );
    l_dattim.tm_mon   = atoi( l_date.substr( 4, 2 ).c_str( ) ) - 1;
    l_dattim.tm_year  = atoi( l_date.substr( 0, 4 ).c_str( ) ) - 1900;
    l_dattim.tm_isdst = -1;

    l_tim = mktime( &l_dattim );
    ptr_dattim = gmtime( &l_tim );
    ptr_dattim->tm_isdst = -1;
    
    return( mktime( ptr_dattim ) );
}

std::string AcqUtils::getServiceCode( std::string track2, std::string track3 )
{
    std::size_t l_pos;
    std::string l_track;
    std::string l_serviceCode;

    //Get posicao baseada na trilha passada.
    if ( strlen( track2.c_str( ) ) > 0 )
    {
        //Track02
        l_pos = track2.find_first_of( "=DF");
        l_track.assign ( track2 );
    }
    else if ( strlen( track3.c_str( ) ) > 0 )
    {
        //Track03
        l_pos = track3.find( '^' );
        l_pos = track3.find( '^', l_pos + 1 );
        l_track.assign ( track3 );
    }

    //Get service code pela posicao fixada.
    if ( ( l_pos != std::string::npos ) && ( ( l_pos + 5 + 3 ) < strlen( l_track.c_str( ) ) ) )
    {
        l_serviceCode.assign( l_track.substr( l_pos + 5, 3 ) );
    }
    else
    {
        l_serviceCode.assign( " " );
    }

    return( l_serviceCode );
}

std::string AcqUtils::format_cd_cnd_cpt( const std::string & de061, const unsigned long & modo_entrada, const std::string & iss_name, const std::string & msg_name, const std::string & modelo_terminal, const std::string & tipo_tecnologia )
{
    if( de061.empty( ) )
    {
        return "00000000000";
    }

    std::string fe_acq( getenv( "NOM_FE_ACQR" ) );
    std::string conteudo_de061 = de061;
    std::stringstream s_modo_entrada; // modo de entrada pode conter ate 3 digitos
    std::string cod_cndc_cptr;
    int digt_modo_entrada;
    
	s_modo_entrada << modo_entrada;
    digt_modo_entrada = atoi( s_modo_entrada.str( ).substr( 0, 1 ).c_str( ) );
    if( ( (digt_modo_entrada == 7) || (digt_modo_entrada == 8) ) && ( s_modo_entrada.str( ).length( ) > 1))
    {
        digt_modo_entrada = atoi( s_modo_entrada.str( ).substr( 0, 2 ).c_str( ) );
    }

    if( de061.length( ) <= 8 && fe_acq == "FEPDV" )
    {
        if( digt_modo_entrada == 5 )
        {
            conteudo_de061 = "00000000008";
        }
        else
        {
            conteudo_de061 = "00000000007";
        }
    }
    
    //posicao 1
    if( conteudo_de061.substr( 0, 1 ) == "1" )
    {
        cod_cndc_cptr = conteudo_de061.substr( 0, 1 );
    }
    else
    {
        cod_cndc_cptr = "0";
    }
    
    //posicao 2
    if( conteudo_de061.substr( 1, 1 ) == "0" || conteudo_de061.substr( 1, 1 ) == "9" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 1, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }

    //posicao 3
    if( conteudo_de061.substr( 2, 1 ) == "0" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 2, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }
    
    //posicao 4
    if( conteudo_de061.substr( 3, 1 ) == "0" && 
        !( digt_modo_entrada == 1 || digt_modo_entrada == 79 || digt_modo_entrada == 81 || digt_modo_entrada == 3 ) )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 3, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }
    
    //posicao 5
    if( conteudo_de061.substr( 4, 1 ) == "0" && 
        !( digt_modo_entrada == 1 || digt_modo_entrada == 79 || digt_modo_entrada == 81 || digt_modo_entrada == 3 ) )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 4, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }
    
    //posicao 6
    if( conteudo_de061.substr( 5, 1 ) == "1" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 5, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }
    
    //posicao 7
    if( conteudo_de061.substr( 6, 1 ) == "4" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 6, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }
    
    //posicao 8
    if( conteudo_de061.substr( 7, 1 ) == "1" || conteudo_de061.substr( 7, 1 ) == "2" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 7, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }
    
    //posicao 9
    if( fe_acq == "FEPOS" )
    {
        cod_cndc_cptr.append( "0" );
    }
    else
    {
        if( conteudo_de061.substr( 8, 1 ) == "1" || conteudo_de061.substr( 8, 1 ) == "2" )
        {
            cod_cndc_cptr.append( conteudo_de061.substr( 8, 1 ) );
        }
        else
        {
            cod_cndc_cptr.append( "0" );
        }    
    }
    
    //posicao 10
    if ( fe_acq == "FEPOS" )
    {
        if ( ( ( msg_name.compare( "VEND_CRT" ) == 0 ) || 
                ( msg_name.compare( "VEND_CRT_RECARGA" ) == 0 ) || 
                ( msg_name.compare( "CONF_VEND_CRT_RECARGA" ) == 0 ) || 
                ( msg_name.compare( "VEND_CRT_PARC_CJURO" ) == 0 ) || 
                ( msg_name.compare( "SIMU_CREDIARIO" ) == 0 ) || 
                ( msg_name.compare( "CONTRA_CRED" ) == 0 ) || 
                ( msg_name.compare( "CONF_VEND_CRT_PARC_CJURO" ) == 0 ) || 
                ( msg_name.compare( "VEND_IATA_PARC_CJURO" ) == 0 ) || 
                ( msg_name.compare( "CONF_VEND_IATA_PARC_CJURO" ) == 0 ) || 
                ( msg_name.compare( "VEND_CRT_PARC_SJURO" ) == 0 ) || 
                ( msg_name.compare( "CONF_VEND_CRT" ) == 0 ) || 
                ( msg_name.compare( "VEND_DBT_AVISTA" ) == 0 ) ||
                ( msg_name.compare( "VEND_DBT_DIST_AVISTA" ) == 0 ) ||
                ( msg_name.compare( "VEND_DBT_RECARGA" ) == 0 ) ||
                ( msg_name.compare( "CONF_VEND_DBT_RECARGA" ) == 0 ) ||
                ( msg_name.compare( "CONF_VEND_DBT_GEN" ) == 0 ) ||
                ( msg_name.compare( "CONF_VEND_DBT_PREDAT" ) == 0 ) ||
                ( msg_name.compare( "VEND_CSAQ" ) == 0 ) ||
                ( msg_name.compare( "CONF_VEND_CSAQ" ) == 0 ) ||
                ( msg_name.compare( "VEND_DBT_PREDAT" ) == 0 ) ) &&
            ( ( iss_name.compare( "MASTERCARD" ) == 0 ) || 
                ( iss_name.compare( "MAESTRO" ) == 0 ) || 
                ( iss_name.compare( "DINERS_INTERNAC" ) == 0 ) || 
                ( iss_name.compare( "DINERS_NACIONAL" ) == 0 ) || 
                ( iss_name.compare( "VISA_CREDITO" ) == 0 ) || 
                ( iss_name.compare( "VISA_ELECTRON" ) == 0 ) || 
                ( iss_name.compare( "UPI" ) == 0 ) ) &&
            ( ( modelo_terminal.compare( 0, 2, "MP") == 0 ) || 
                ( modelo_terminal.compare( 0, 2, "MD") == 0 ) || 
                ( tipo_tecnologia.compare( 0, 3, "154" ) == 0 ) ) )
        {
            cod_cndc_cptr.append( "9" );
        }
        else
        {
            cod_cndc_cptr.append( "0" );
        }
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }
    
    //posicao 11
    if( ( fe_acq == "FEPOS" ) && ( conteudo_de061.length( ) < 11 ))
    {
            cod_cndc_cptr.append( "0" );
    }
    else
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 10, 1 ) );
    }
    
    return cod_cndc_cptr;
}

void AcqUtils::cfsextr( base::date_t &target, fieldSet::ConstFieldAccess &field )
{
    long value = 0;
    fieldSet::fsextr( value, field );
    target = value;
}

void AcqUtils::cfsextr( char *target, fieldSet::ConstFieldAccess &field )
{
    std::string value("");
    fieldSet::fsextr( value, field );
    strncpy( target, value.c_str( ), sizeof( target ) );
}

void AcqUtils::cfsextr( oasis_dec_t &target, fieldSet::ConstFieldAccess &field )
{
    std::string value("");
    fieldSet::fsextr( value, field );
    dbm_chartodec( &target, value.c_str( ), 0 );
}

static void cfscopy( fieldSet::FieldAccess &field, oasis_dec_t &source )
{
    char l_bufferTemp[ 1024 ] = { 0 };
    dbm_dectochar_conv( &source, l_bufferTemp, 0 );
    fieldSet::fscopy( field, std::string( l_bufferTemp ) );
}

static void cfscopy( fieldSet::FieldAccess &field, base::date_t &source )
{
    unsigned long ulong = 0;
    ulong = source;
    fieldSet::fscopy( field, ulong );
}

std::string AcqUtils::converteAuthnum( const std::string& value )
{
    std::string l_result = "";
    std::string l_authnum = value.c_str( );
    char l_byte;

    if( l_authnum.size() > 0 )
    {
        std::string l_message;

        for ( std::string::iterator it=l_authnum.begin( ); it!=l_authnum.end( ); ++it )
        {
            l_byte =( char )*it;
            if ( isalpha( *it ) )
            {
                l_byte =( *it ) % 16;
                l_byte =( l_byte % 10 ) + 48;
            }
            l_result.push_back( l_byte );
        }
    }
    
    return l_result;
}

std::string AcqUtils::trim( const std::string& source, const std::string& trimmingChar, const bool& leftTrimming, const bool& rightTrimming )
{
    std::string l_target = source;

    if ( leftTrimming == true )
    {
        size_t l_startpos = l_target.find_first_not_of( trimmingChar );

        if ( l_startpos != 0 )
        {
            if ( l_startpos != std::string::npos )
            {
                l_target = l_target.substr( l_startpos );
            }
            else
            {
                l_target = "";
            }
        }
    }
    if ( rightTrimming == true )
    {
        size_t l_endpos = l_target.find_last_not_of( trimmingChar );

        if ( std::string::npos != l_endpos )
        {
            l_target = l_target.substr( 0, l_endpos + 1 );
        }
        else
        {
            l_target = "";
        }
    }
    return l_target;
}

bool AcqUtils::findChip( std::string buffer_de55, std::string nome_tag, std::string &conteudo_tag )
{
    std::string l_tag;
    bool achou_tag;
    int l_len;
    int l_pos;

    achou_tag = false;
    l_pos = 0;
    while( ( l_pos < buffer_de55.size( ) ) && ( achou_tag == false ) )
    {
        l_tag = findChipTag( buffer_de55, l_pos );
        if ( l_tag.empty( ) == true )
        {
            break;
        }
        l_len = findChipLen( buffer_de55, l_pos );
        if ( l_len <= 0 )
        {
            break;
        }
        conteudo_tag = findChipConteudo( buffer_de55, l_pos, l_len );
        if ( conteudo_tag.empty( ) == true )
        {
            break;
        }
        if ( nome_tag.compare( l_tag ) == 0 )
        {
            achou_tag = true;
        }
    }
    return( achou_tag );
}

std::string AcqUtils::findChipTag( std::string l_de55, int &l_pos )
{
    std::string l_aux;
    
    l_aux = std::string( "" );
    if ( l_de55.size( ) <  ( l_pos + 2 ) )
    {
        return( l_aux );
    }
    else if ( ( l_de55.substr( l_pos, 2 ).compare( "5F" ) != 0 ) && ( l_de55.substr( l_pos, 2 ).compare( "9F" ) != 0 ) )
    {
        l_aux =  l_de55.substr( l_pos, 2 );
    }
    else if ( l_de55.size( ) <  ( l_pos + 4 ) )
    {
        return( l_aux );
    }
    else 
    {
        l_aux =  l_de55.substr( l_pos, 4 );
    }
    l_pos += l_aux.size( );
    return( l_aux );
}

std::string AcqUtils::findChipConteudo( std::string l_de55, int &l_pos, int l_len )
{
    std::string l_aux;
    
    l_aux = std::string( "" );
    l_len *= 2;
    if ( l_de55.size( ) <  ( l_pos + l_len ) )
    {
        return( l_aux );
    }
    else
    {
        l_aux =  l_de55.substr( l_pos, l_len );
    }
    l_pos += l_aux.size( );
    return( l_aux );
}

int AcqUtils::findChipLen( std::string l_de55, int &l_pos )
{
    std::string l_aux;

    l_aux = std::string( "0" );
    if ( l_de55.size( ) <  ( l_pos + 2 ) )
    {
        return( 0 );
    }
    else
    {
        l_aux =  l_de55.substr( l_pos, 2 );
    }
    l_pos += l_aux.size( );
    return( strtoul( l_aux.c_str( ), NULL, 16 ) );
}
