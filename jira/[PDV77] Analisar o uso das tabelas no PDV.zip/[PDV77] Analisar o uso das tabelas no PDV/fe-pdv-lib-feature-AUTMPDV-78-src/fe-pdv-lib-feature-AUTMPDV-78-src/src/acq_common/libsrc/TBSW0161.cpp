#include "TBSW0161.hpp"

namespace dbaccess_common
{
    TBSW0161::TBSW0161( )
    {
        initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0161::TBSW0161( const std::string& whereClause )
    {
        initialize();
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0161::~TBSW0161( )
    {
    }
    
    void TBSW0161::initialize()
    {
        query_fields = "NUM_PDV, COD_BNDR_CORP, NUM_PDV_BNDR, DAT_ATLZ_REG";

        table_name = "TBSW0161";

        m_NUM_PDV_pos = 1;
        m_COD_BNDR_CORP_pos = 2;
        m_NUM_PDV_BNDR_pos = 3;
        m_DAT_ATLZ_REG_pos = 4;

        m_NUM_PDV = 0;
        m_COD_BNDR_CORP =  0;
        m_NUM_PDV_BNDR =  " ";
        m_DAT_ATLZ_REG = 0;
        
    }
    
    void TBSW0161::setWhereClause( const std::string& whereClause )
    {
        where_condition = whereClause;
    }

    void TBSW0161::bind_columns( )
    {
        bind( m_NUM_PDV_pos, m_NUM_PDV );
        bind( m_COD_BNDR_CORP_pos, m_COD_BNDR_CORP );
        bind( m_NUM_PDV_BNDR_pos, m_NUM_PDV_BNDR );
        bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
    }
    
    void TBSW0161::set_NUM_PDV( unsigned long a_NUM_PDV )
    {
        m_NUM_PDV = a_NUM_PDV;
    }
    void TBSW0161::set_COD_BNDR_CORP( unsigned long a_COD_BNDR_CORP )
    {
        m_COD_BNDR_CORP = a_COD_BNDR_CORP;
    }
    void TBSW0161::set_NUM_PDV_BNDR( const std::string& a_NUM_PDV_BNDR )
    {
        m_NUM_PDV_BNDR = a_NUM_PDV_BNDR;
    }
    void TBSW0161::set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
    {
        m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    
    unsigned long TBSW0161::get_NUM_PDV( ) const
    {
        return m_NUM_PDV;
    }
    unsigned long TBSW0161::get_COD_BNDR_CORP( ) const
    {
        return m_COD_BNDR_CORP;
    }
    const std::string& TBSW0161::get_NUM_PDV_BNDR( ) const
    {
        return m_NUM_PDV_BNDR;
    }
    dbm_datetime_t TBSW0161::get_DAT_ATLZ_REG( ) const
    {
        return m_DAT_ATLZ_REG;
    }

} //namespace dbaccess_common
