/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#include "TBSW2001.hpp"

namespace dbaccess_common
{

        TBSW2001::TBSW2001()
        {
                query_fields = "COD_CHAV_SUPR, TIP_BIN, COD_CHAV_INFR, TIP_ISSR, COD_BIN_ISSR, TIP_CHCK_DIG_VRFC, TAM_RNG_CTA, TIP_CAR, TIP_USO, COD_BIN_PRCS, COD_DOM_CAR, COD_RGAO_EMSR, COD_PAIS_EMSR, IND_SERV_CAR_CMC, IND_TCNL, COD_RGAO_CAR, COD_PAIS_CAR, IND_DA_NVL_2, IND_DA_NVL_3, IND_MSG_CAR_CMC, IND_TX_VAL_AGRD, IND_VAL_ORGL, IND_EXTN_TIP_PROD, IND_TRSF_MNTR, IND_JOG_ONLN, COD_PROD, TIP_USO_INT_1, IND_AMB, TIP_USO_INT_2, COD_ID_MMBR_VISA, DAT_INCL_REG_VISA, TIP_CAR_MLTP";
                table_name = "TBSW2001";
                        
                codChavSuprPos = 1;
                tipBinPos = 2;
                codChavInfrPos = 3;        
                tipIssrPos = 4;
                codBinIssrPos = 5;
                tipChckDigVrfcPos = 6;
                tamRngCtaPos = 7;
                tipCarPos = 8;
                tipUsoPos = 9;
                codBinPrcsPos = 10;
                codDomCarPos = 11;
                codRgaoEmsrPos = 12;
                codPaisEmsrPos = 13;
                indServCarCmcPos = 14;
                indTcnlPos = 15;
                codRgaoCarPos = 16;
                codPaisCarPos = 17;
                indDaNvl2Pos = 18;
                indDaNvl3Pos = 19;
                indMsgCarCmcPos = 20;
                indTxValAgrdPos = 21;
                indValOrglPos = 22;
                indExtnTipProdPos = 23;
                indTrsfMntrPos = 24;
                indJogOnlnPos = 25;
                codProdPos = 26;
                tipUsoInt1Tos = 27;
                indAmbPos = 28;
                tipUsoInt2Tos = 29;
                codIdMmbrVisaPos = 30;
                datInclRegVisaPos = 31;
                tipCarMltpPos = 32;
                        
                codChavSupr = "";
                tipBin = "";
                codChavInfr = "";
                tipIssr = "";
                codBinIssr = "";
                tipChckDigVrfc = "";
                tamRngCta = "";
                tipCar = "";
                tipUso = "";
                codBinPrcs = "";
                codDomCar = "";
                codRgaoEmsr = "";
                codPaisEmsr = "";
                indServCarCMC = "";
                indTcnl = "";
                codRgaoCar = "";
                codPaisCar = "";
                indDaNvl2 = "";
                indDaNvl3 = "";
                indMsgCarCmc = "";
                indTxValAgrd = "";
                indValOrgl = "";
                indExtnTipProd = "";
                indTrsfMntr = "";
                indJogOnln = "";
                codProd = "";
                tipUsoInt1 = "";
                indAmb = "";
                tipUsoInt2 = "";
                codIdMmbrVisa = 0;
                datInclRegVisa = 0;
                tipCarMltp = "";

                where_condition = "";

                update_database_id(dbaccess::endpoint::DB_CAPTURA);
        }

        TBSW2001::TBSW2001( const std::string& str )
        {
                query_fields = "COD_CHAV_SUPR, TIP_BIN, COD_CHAV_INFR, TIP_ISSR, COD_BIN_ISSR, TIP_CHCK_DIG_VRFC, TAM_RNG_CTA, TIP_CAR, TIP_USO, COD_BIN_PRCS, COD_DOM_CAR, COD_RGAO_EMSR, COD_PAIS_EMSR, IND_SERV_CAR_CMC, IND_TCNL, COD_RGAO_CAR, COD_PAIS_CAR, IND_DA_NVL_2, IND_DA_NVL_3, IND_MSG_CAR_CMC, IND_TX_VAL_AGRD, IND_VAL_ORGL, IND_EXTN_TIP_PROD, IND_TRSF_MNTR, IND_JOG_ONLN, COD_PROD, TIP_USO_INT_1, IND_AMB, TIP_USO_INT_2, COD_ID_MMBR_VISA, DAT_INCL_REG_VISA, TIP_CAR_MLTP";
                table_name = "TBSW2001";
                        
                codChavSuprPos = 1;        
                tipBinPos = 2;              
                codChavInfrPos = 3;        
                tipIssrPos = 4;             
                codBinIssrPos = 5;         
                tipChckDigVrfcPos = 6;    
                tamRngCtaPos = 7;          
                tipCarPos = 8;              
                tipUsoPos = 9;              
                codBinPrcsPos = 10;        
                codDomCarPos = 11;         
                codRgaoEmsrPos = 12;       
                codPaisEmsrPos = 13;       
                indServCarCmcPos = 14;    
                indTcnlPos = 15;            
                codRgaoCarPos = 16;        
                codPaisCarPos = 17;        
                indDaNvl2Pos = 18;        
                indDaNvl3Pos = 19;        
                indMsgCarCmcPos = 20;     
                indTxValAgrdPos = 21;     
                indValOrglPos = 22;        
                indExtnTipProdPos = 23;   
                indTrsfMntrPos = 24;       
                indJogOnlnPos = 25;        
                codProdPos = 26;            
                tipUsoInt1Tos = 27;       
                indAmbPos = 28;             
                tipUsoInt2Tos = 29;       
                codIdMmbrVisaPos = 30;    
                datInclRegVisaPos = 31;   
                tipCarMltpPos = 32;   
                        
                codChavSupr = "";
                tipBin = "";
                codChavInfr = "";
                tipIssr = "";
                codBinIssr = "";
                tipChckDigVrfc = "";
                tamRngCta = "";
                tipCar = "";
                tipUso = "";
                codBinPrcs = "";
                codDomCar = "";
                codRgaoEmsr = "";
                codPaisEmsr = "";
                indServCarCMC = "";
                indTcnl = "";
                codRgaoCar = "";
                codPaisCar = "";
                indDaNvl2 = "";
                indDaNvl3 = "";
                indMsgCarCmc = "";
                indTxValAgrd = "";
                indValOrgl = "";
                indExtnTipProd = "";
                indTrsfMntr = "";
                indJogOnln = "";
                codProd = "";
                tipUsoInt1 = "";
                indAmb = "";
                tipUsoInt2 = "";
                codIdMmbrVisa = 0;
                datInclRegVisa = 0;
                tipCarMltp = "";

                where_condition = str;

                update_database_id(dbaccess::endpoint::DB_CAPTURA);	
        }

        TBSW2001::~TBSW2001()
        {
        }

        void TBSW2001::bind_columns()
        {
                bind (codChavSuprPos, codChavSupr);
                bind (tipBinPos, tipBin);
                bind (codChavInfrPos, codChavInfr);
                bind (tipIssrPos, tipIssr);
                bind (codBinIssrPos, codBinIssr);
                bind (tipChckDigVrfcPos, tipChckDigVrfc);
                bind (tamRngCtaPos, tamRngCta);
                bind (tipCarPos, tipCar);
                bind (tipUsoPos, tipUso);
                bind (codBinPrcsPos,codBinPrcs);
                bind (codDomCarPos, codDomCar);
                bind (codRgaoEmsrPos, codRgaoEmsr);
                bind (codPaisEmsrPos, codPaisEmsr);
                bind (indServCarCmcPos, indServCarCMC);
                bind (indTcnlPos, indTcnl);
                bind (codRgaoCarPos, codRgaoCar);
                bind (codPaisCarPos, codPaisCar);
                bind (indDaNvl2Pos, indDaNvl2);
                bind (indDaNvl3Pos, indDaNvl3);
                bind (indMsgCarCmcPos, indMsgCarCmc);
                bind (indTxValAgrdPos, indTxValAgrd);
                bind (indValOrglPos, indValOrgl);
                bind (indExtnTipProdPos, indExtnTipProd);
                bind (indTrsfMntrPos, indTrsfMntr);
                bind (indJogOnlnPos, indJogOnln);
                bind (codProdPos, codProd);
                bind (tipUsoInt1Tos, tipUsoInt1);
                bind(indAmbPos, indAmb);
                bind (tipUsoInt2Tos, tipUsoInt2);
                bind (codIdMmbrVisaPos, codIdMmbrVisa);
                bind (datInclRegVisaPos, datInclRegVisa);
                bind (tipCarMltpPos, tipCarMltp);
        }
				     
        // Setters
        void TBSW2001::SetCodChavSupr( const std::string& a_COD_CHAV_SUPR )
        {
                codChavSupr = a_COD_CHAV_SUPR;
        }

	void TBSW2001::SetTipBin( const std::string& a_TIP_BIN )
        {
                tipBin = a_TIP_BIN;
        }

        void TBSW2001::SetCodChavInfr( const std::string& a_COD_CHAV_INFR )
        {
                codChavInfr = a_COD_CHAV_INFR;
        }

        void TBSW2001::SetTipIssr( const std::string& a_TIP_ISSR )
        {
                tipIssr = a_TIP_ISSR;
        }

        void TBSW2001::SetCodBinIssr( const std::string& a_COD_BIN_ISSR )
        {
                codBinIssr = a_COD_BIN_ISSR;
        }

        void TBSW2001::SetTipChckDigVrfc( const std::string& a_TIP_CHCK_DIG_VRFC )
        {
                tipChckDigVrfc = a_TIP_CHCK_DIG_VRFC;
        }

        void TBSW2001::SetTamRngCta( const std::string& a_TAM_RNG_CTA )
        {
                tamRngCta = a_TAM_RNG_CTA;
        }

        void TBSW2001::SetTipCar( const std::string& a_TIP_CAR )
        {
                tipCar = a_TIP_CAR;
        }

        void TBSW2001::SetTipUso( const std::string& a_TIP_USO )
        {
                tipUso = a_TIP_USO;
        }

        void TBSW2001::SetCodBinPrcs( const std::string& a_COD_BIN_PRCS )
        {
                codBinPrcs = a_COD_BIN_PRCS;
        }

        void TBSW2001::SetCodDomCar( const std::string& a_COD_DOM_CAR )
        {
                codDomCar = a_COD_DOM_CAR;
        }

        void TBSW2001::SetCodRgaoEmsr( const std::string& a_COD_RGAO_EMSR )
        {
                codRgaoEmsr = a_COD_RGAO_EMSR;
        }

        void TBSW2001::SetCodPaisEmsr( const std::string& a_COD_PAIS_EMSR )
        {
                codPaisEmsr = a_COD_PAIS_EMSR;
        }

        void TBSW2001::SetIndServCarCmc( const std::string& a_IND_SERV_CAR_CMC )
        {
                indServCarCMC = a_IND_SERV_CAR_CMC;
        }

        void TBSW2001::SetIndTcnl( const std::string& a_IND_TCNL )
        {
                indTcnl = a_IND_TCNL;
        }

        void TBSW2001::SetCodRgaoCar( const std::string& a_COD_RGAO_CAR )
        {
                codRgaoCar = a_COD_RGAO_CAR;
        }

        void TBSW2001::SetCodPaisCar( const std::string& a_COD_PAIS_CAR )
        {
                codPaisCar = a_COD_PAIS_CAR;
        }

        void TBSW2001::SetIndDaNvl2( const std::string& a_IND_DA_NVL_2 )
        {
                indDaNvl2 = a_IND_DA_NVL_2;
        }

	void TBSW2001::SetIndDaNvl3( const std::string& a_IND_DA_NVL_3 )
        {
                indDaNvl3 = a_IND_DA_NVL_3;
        }

        void TBSW2001::SetIndMsgCarCmc( const std::string& a_IND_MSG_CAR_CMC )
        {
                indMsgCarCmc = a_IND_MSG_CAR_CMC;
        }
 
        void TBSW2001::SetIndTxValAgrd( const std::string& a_IND_TX_VAL_AGRD )
        {
                indTxValAgrd = a_IND_TX_VAL_AGRD;
        }

        void TBSW2001::SetIndValOrgl( const std::string& a_IND_VAL_ORGL )
        {
                indValOrgl = a_IND_VAL_ORGL;
        }

        void TBSW2001::SetIndExtnTipProd( const std::string& a_IND_EXTN_TIP_PROD )
        {
                indExtnTipProd = a_IND_EXTN_TIP_PROD;
        }

        void TBSW2001::SetIndTrsfMntr( const std::string& a_IND_TRSF_MNTR )
        {
                indTrsfMntr = a_IND_TRSF_MNTR;
        }

        void TBSW2001::SetIndJogOnln( const std::string& a_IND_JOG_ONLN )
        {
                indJogOnln = a_IND_JOG_ONLN;
        }

        void TBSW2001::SetCodProd( const std::string& a_COD_PROD )
        {
                codProd = a_COD_PROD;
        }

        void TBSW2001::SetTipUsoInt1( const std::string& a_TIP_USO_INT_1 )
        {
                tipUsoInt1 = a_TIP_USO_INT_1;
        }

        void TBSW2001::SetIndAmb( const std::string& a_IND_AMB )
        {
                indAmb = a_IND_AMB;
        }

        void TBSW2001::SetTipUsoInt2( const std::string& a_TIP_USO_INT_2 )
        {
                tipUsoInt2 = a_TIP_USO_INT_2;
        }

        void TBSW2001::SetCodIdMmbrVisa( unsigned long a_COD_ID_MMBR_VISA )
        {
                codIdMmbrVisa = a_COD_ID_MMBR_VISA;
        }

        void TBSW2001::SetDatInclRegVisa( unsigned long a_DAT_INCL_REG_VISA )
        {
                datInclRegVisa = a_DAT_INCL_REG_VISA;
        }

        void TBSW2001::SetTipCarMltp( const std::string& a_TIP_CAR_MLTP )
        {
                tipCarMltp = a_TIP_CAR_MLTP;
        }

        // Getters
        const std::string& TBSW2001::GetCodChavSupr() const
        {
                return codChavSupr;
        }

        const std::string& TBSW2001::GetTipBin() const
        {
                return tipBin;
        }

        const std::string& TBSW2001::GetCodChavInfr() const
        {
                return codChavInfr;
        }

        const std::string& TBSW2001::GetTipIssr() const
        {
                return tipIssr;
        }

        const std::string& TBSW2001::GetCodBinIssr() const
        {
                return codBinIssr;
        }

        const std::string& TBSW2001::GetTipChckDigVrfc() const
        {
                return tipChckDigVrfc;
        }

        const std::string& TBSW2001::GetTamRngCta() const
        {
                return tamRngCta;
        }

        const std::string& TBSW2001::GetTipCar() const
        {
                return tipCar;
        }

        const std::string& TBSW2001::GetTipUso() const
        {
                return tipUso;
        }

        const std::string& TBSW2001::GetCodBinPrcs() const
        {
                return codBinPrcs;
        }

        const std::string& TBSW2001::GetCodDomCar() const
        {
                return codDomCar;
        }

        const std::string& TBSW2001::GetCodRgaoEmsr() const
        {
                return codRgaoEmsr;
        }

        const std::string& TBSW2001::GetCodPaisEmsr() const
        {
                return codPaisEmsr;
        }

        const std::string& TBSW2001::GetIndServCarCmc() const
        {
                return indServCarCMC;
        }

        const std::string& TBSW2001::GetIndTcnl() const
        {
                return indTcnl;
        }

        const std::string& TBSW2001::GetCodRgaoCar() const
        {
                return codRgaoCar;
        }

        const std::string& TBSW2001::GetCodPaisCar() const
        {
                return codPaisCar;
        }

        const std::string& TBSW2001::GetIndDaNvl2() const
        {
                return indDaNvl2;
        }

        const std::string& TBSW2001::GetIndDaNvl3() const
        {
                return indDaNvl3;
        }

        const std::string& TBSW2001::GetIndMsgCarCmc() const
        {
                return indMsgCarCmc;
        }

        const std::string& TBSW2001::GetIndTxValAgrd() const
        {
                return indTxValAgrd;
        }

        const std::string& TBSW2001::GetIndValOrgl() const
        {
                return indValOrgl;
        }

        const std::string& TBSW2001::GetIndExtnTipProd() const
        {
                return indExtnTipProd;
        }

        const std::string& TBSW2001::GetIndTrsfMntr() const
        {
                return indTrsfMntr;
        }

        const std::string& TBSW2001::GetIndJogOnln() const
        {
                return indJogOnln;
        }

        const std::string& TBSW2001::GetCodProd() const
        {
                return codProd;
        }

        const std::string& TBSW2001::GetTipUsoInt1() const
        {
                return tipUsoInt1;
        }

        const std::string& TBSW2001::GetIndAmb() const
        {
                return indAmb;
        }

        const std::string& TBSW2001::GetTipUsoInt2() const
        {
                return tipUsoInt2;
        }

        unsigned long TBSW2001::GetCodIdMmbrVisa() const
        {
                return codIdMmbrVisa;
        }

        unsigned long TBSW2001::GetDatInclRegVisa() const
        {
                return datInclRegVisa;
        }

        const std::string& TBSW2001::GetTipCarMltp() const
        {
                return tipCarMltp;
        }		
				
}//namespace dbaccess_common

