#include "TBSW0155.hpp"

namespace dbaccess_common
{
	TBSW0155::TBSW0155()
	{

		query_fields = "NUM_PDV, DAT_REF, NUM_MDLD_PRCL, QTD_VD_PARC, VAL_VD_PARC";

		table_name = "TBSW0155";

		m_NUM_PDV_pos = 1;
		m_DAT_REF_pos = 2;
		m_NUM_MDLD_PRCL_pos = 3;
		m_QTD_VD_PARC_pos = 4;
		m_VAL_VD_PARC_pos = 5;

		m_NUM_PDV = 0;
		m_DAT_REF = 0;
		m_NUM_MDLD_PRCL = 0;
		m_QTD_VD_PARC = 0;
		dbm_chartodec( &m_VAL_VD_PARC, "0.00", 2 );

		where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0155::TBSW0155( const std::string& whereClause )
	{

		query_fields = "NUM_PDV, DAT_REF, NUM_MDLD_PRCL, QTD_VD_PARC, VAL_VD_PARC";

		table_name = "TBSW0155";

		m_NUM_PDV_pos = 1;
		m_DAT_REF_pos = 2;
		m_NUM_MDLD_PRCL_pos = 3;
		m_QTD_VD_PARC_pos = 4;
		m_VAL_VD_PARC_pos = 5;

		m_NUM_PDV = 0;
		m_DAT_REF = 0;
		m_NUM_MDLD_PRCL = 0;
		m_QTD_VD_PARC = 0;
		dbm_chartodec( &m_VAL_VD_PARC, "0.00", 2 );

		where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0155::~TBSW0155()
	{
	}

	void TBSW0155::bind_columns()
	{
		bind( m_NUM_PDV_pos, m_NUM_PDV );
		bind( m_DAT_REF_pos, &m_DAT_REF );
		bind( m_NUM_MDLD_PRCL_pos, m_NUM_MDLD_PRCL );
		bind( m_QTD_VD_PARC_pos, m_QTD_VD_PARC );
		bind( m_VAL_VD_PARC_pos, m_VAL_VD_PARC );
	}
	void TBSW0155::set_NUM_PDV( unsigned long a_NUM_PDV )
	{
		m_NUM_PDV = a_NUM_PDV;
	}
	void TBSW0155::set_DAT_REF( dbm_datetime_t a_DAT_REF )
	{
		m_DAT_REF = a_DAT_REF;
	}
	void TBSW0155::set_NUM_MDLD_PRCL( unsigned long a_NUM_MDLD_PRCL )
	{
		m_NUM_MDLD_PRCL = a_NUM_MDLD_PRCL;
	}
	void TBSW0155::set_QTD_VD_PARC( unsigned long a_QTD_VD_PARC )
	{
		m_QTD_VD_PARC = a_QTD_VD_PARC;
	}
	void TBSW0155::set_VAL_VD_PARC( oasis_dec_t a_VAL_VD_PARC )
	{
		dbm_deccopy( &m_VAL_VD_PARC, &a_VAL_VD_PARC );
	}
	unsigned long TBSW0155::get_NUM_PDV() const
	{
		return m_NUM_PDV;
	}
	dbm_datetime_t TBSW0155::get_DAT_REF() const
	{
		return m_DAT_REF;
	}
	unsigned long TBSW0155::get_NUM_MDLD_PRCL() const
	{
		return m_NUM_MDLD_PRCL;
	}
	unsigned long TBSW0155::get_QTD_VD_PARC() const
	{
		return m_QTD_VD_PARC;
	}
	oasis_dec_t TBSW0155::get_VAL_VD_PARC() const
	{
		return m_VAL_VD_PARC;
	}

} //namespace dbaccess_common

