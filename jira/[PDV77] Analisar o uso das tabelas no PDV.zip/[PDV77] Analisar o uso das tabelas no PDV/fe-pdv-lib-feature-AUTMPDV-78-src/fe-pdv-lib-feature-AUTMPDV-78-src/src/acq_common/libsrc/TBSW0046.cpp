/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------
/ Sigla: <dbaccess_common::TBSW0046>
/ Descrição: <Arquivo de implementação da classe dbaccess_common::TBSW0046>
/ Conteúdo: <Lista de Módulos definidos>
/ Autor: <694449, Fernando Ramires>
/ Data de Criação: <2017, 09 de Fevereiro>
/ Histórico Mudanças: <Data, Módulo, Autor, Descrição da Mudança>
/ . . .
/ <Data, Módulo, Autor, Descrição da Mudança>
/ ---------------------------------------------------------------------------
*/

#include "TBSW0046.hpp"

namespace dbaccess_common
{
    TBSW0046::TBSW0046()
    {
        query_fields = "NUM_RV, IND_NUM_QBRA, NUM_PRCL, VAL_PRCL, DAT_PRCL, NUM_PDV";

        table_name = "TBSW0046";

        m_NUM_RV_pos = 1;
        m_IND_NUM_QBRA_pos = 2;
        m_IND_NUM_PRCL_pos = 3;
        m_VAL_PRCL_pos = 4;
        m_DAT_PRCL_pos = 5;
        m_NUM_PDV_pos = 6;

        dbm_longtodec( &m_NUM_RV, 0 );
        m_IND_NUM_QBRA = 0;
        m_IND_NUM_PRCL = 0;
        dbm_longtodec( &m_VAL_PRCL, 0);
        m_DAT_PRCL = 0;
        m_NUM_PDV = 0;

        m_VAL_PRCL_ind_null = DBM_NULL_DATA;
   
        where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0046::TBSW0046( const std::string& whereClause )
    {
        query_fields = "NUM_RV, IND_NUM_QBRA, NUM_PRCL, VAL_PRCL, DAT_PRCL, NUM_PDV";

        table_name = "TBSW0046";

        m_NUM_RV_pos = 1;
        m_IND_NUM_QBRA_pos = 2;
        m_IND_NUM_PRCL_pos = 3;
        m_VAL_PRCL_pos = 4;
        m_DAT_PRCL_pos = 5;
        m_NUM_PDV_pos = 6;

        dbm_longtodec( &m_NUM_RV, 0 );
        m_IND_NUM_QBRA = 0;
        m_IND_NUM_PRCL = 0;
        dbm_longtodec( &m_VAL_PRCL, 0);
        m_DAT_PRCL = 0;
        m_NUM_PDV = 0;

        m_VAL_PRCL_ind_null = DBM_NULL_DATA;
   
        where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0046::~TBSW0046()
    {
    }

    void TBSW0046::bind_columns()
    {
        bind( m_NUM_RV_pos, m_NUM_RV );
        bind( m_IND_NUM_QBRA_pos, m_IND_NUM_QBRA );
        bind( m_IND_NUM_PRCL_pos, m_IND_NUM_PRCL );
        bind( m_VAL_PRCL_pos, m_VAL_PRCL, &m_VAL_PRCL_ind_null );
        bind( m_DAT_PRCL_pos, &m_DAT_PRCL );
        bind( m_NUM_PDV_pos, m_NUM_PDV );
    }
    void TBSW0046::set_NUM_RV( oasis_dec_t a_NUM_RV )
    {
        dbm_deccopy( &m_NUM_RV, &a_NUM_RV );
    }
    void TBSW0046::set_IND_NUM_QBRA( unsigned long a_IND_NUM_QBRA )
    {
        m_IND_NUM_QBRA = a_IND_NUM_QBRA;
    }
    void TBSW0046::set_IND_NUM_PRCL( unsigned long a_IND_NUM_PRCL )
    {
        m_IND_NUM_PRCL = a_IND_NUM_PRCL;
    }
    void TBSW0046::set_VAL_PRCL( oasis_dec_t a_VAL_PRCL )
    {
        dbm_deccopy( &m_VAL_PRCL, &a_VAL_PRCL);
		m_VAL_PRCL_ind_null = 0;
    }
    void TBSW0046::set_DAT_PRCL( dbm_datetime_t a_DAT_PRCL )
    {
        m_DAT_PRCL = a_DAT_PRCL;
    }
    void TBSW0046::set_NUM_PDV( unsigned long a_NUM_PDV )
    {
        m_NUM_PDV = a_NUM_PDV;
    }
    
    oasis_dec_t TBSW0046::get_NUM_RV() const
    {
        return m_NUM_RV;
    }
    unsigned long TBSW0046::get_IND_NUM_QBRA() const
    {
        return m_IND_NUM_QBRA;
    }
    unsigned long TBSW0046::get_IND_NUM_PRCL() const
    {
        return m_IND_NUM_PRCL;
    }
    oasis_dec_t TBSW0046::get_VAL_PRCL() const
    {
        return m_VAL_PRCL;
    }
    dbm_datetime_t TBSW0046::get_DAT_PRCL() const
    {
        return m_DAT_PRCL;
    }
    unsigned long TBSW0046::get_NUM_PDV() const
    {
        return m_NUM_PDV;
    }
    
/////////////////////////////////////////
//    void TBSW0046::let_EXEMPLO_as_is() const
//    {
//        m_EXEMPLO_ind_null = is_null(m_EXEMPLO) ? DBM_NULL_DATA : 0;
//    }

        void TBSW0046::let_VAL_PRCL_as_is()
        {
            m_VAL_PRCL_ind_null = is_null(m_VAL_PRCL) ? DBM_NULL_DATA : 0;
        }
} //namespace dbaccess_common

