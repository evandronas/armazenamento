#include "TBSW1042.hpp"

namespace dbaccess_common
{
    TBSW1042::TBSW1042()
    {
        query_fields = "COD_TERM           , \
                        IND_ATCG           , \
                        IND_ATIN           , \
                        DAT_ATCG           , \
                        DAT_ATLZ_REG       , \
                        COD_OPID_ULT_ATLZ";
                        
        table_name = "TBSW1042";

        m_COD_TERM = "";
        m_IND_ATIN = "";
        m_IND_ATCG = "";
        m_DAT_ATCG = 0;
        m_DAT_ATLZ_REG = 0;
        m_COD_OPID_ULT_ATLZ = "";

        where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);

        
    }
    TBSW1042::TBSW1042( const std::string& str )
    {
        query_fields = "COD_TERM           , \
                        IND_ATCG           , \
                        IND_ATIN           , \
                        DAT_ATCG           , \
                        DAT_ATLZ_REG       , \
                        COD_OPID_ULT_ATLZ";

        table_name = "TBSW1042";

        m_COD_TERM = "";
        m_IND_ATIN = "";
        m_IND_ATCG = "";
        m_DAT_ATCG = 0;
        m_DAT_ATLZ_REG = 0;
        m_COD_OPID_ULT_ATLZ = "";

        where_condition = str;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW1042::~TBSW1042()
    {
    }

    const std::string& TBSW1042::get_COD_TERM() const
    {
        return m_COD_TERM;
    }    
    const std::string& TBSW1042::get_IND_ATIN() const
    {
        return m_IND_ATIN;
    }
    const std::string& TBSW1042::get_IND_ATCG() const
    {
        return m_IND_ATCG;
    }    
    const dbm_datetime_t& TBSW1042::get_DAT_ATCG() const
    {
        return m_DAT_ATCG;
    }
    const dbm_datetime_t& TBSW1042::get_DAT_ATLZ_REG() const
    {
        return m_DAT_ATLZ_REG;
    }
    const std::string& TBSW1042::get_COD_OPID_ULT_ATLZ() const
    {
        return m_COD_OPID_ULT_ATLZ;
    }
    
    void TBSW1042::set_COD_TERM( const std::string& a_COD_TERM )
    {
            m_COD_TERM  = a_COD_TERM;
    }
    void TBSW1042::set_IND_ATIN( const std::string& a_IND_ATIN )
    {
            m_IND_ATIN = a_IND_ATIN;
    }
    void TBSW1042::set_IND_ATCG( const std::string& a_IND_ATCG )
    {
            m_IND_ATCG = a_IND_ATCG;
    }
    void TBSW1042::set_DAT_ATCG( dbm_datetime_t a_DAT_ATCG )
    {
            m_DAT_ATCG = a_DAT_ATCG;
    }
    void TBSW1042::set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
    {
            m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    void TBSW1042::set_COD_OPID_ULT_ATLZ( const std::string& a_COD_OPID_ULT_ATLZ )
    {
            m_COD_OPID_ULT_ATLZ = a_COD_OPID_ULT_ATLZ;
    }

    void TBSW1042::bind_columns()
    {
        bind( COD_TERM_POS, m_COD_TERM ); 
        bind( IND_ATCG_POS, m_IND_ATCG );
        bind( IND_ATIN_POS, m_IND_ATIN );
        bind( DAT_ATCG_POS, &m_DAT_ATCG );      
        bind( DAT_ATLZ_REG_POS, &m_DAT_ATLZ_REG );
        bind( COD_OPID_ULT_ATLZ_POS, m_COD_OPID_ULT_ATLZ );           
    }
}
