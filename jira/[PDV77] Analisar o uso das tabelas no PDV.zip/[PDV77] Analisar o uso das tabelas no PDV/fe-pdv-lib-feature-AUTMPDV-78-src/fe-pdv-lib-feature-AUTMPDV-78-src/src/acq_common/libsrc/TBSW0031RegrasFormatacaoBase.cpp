/*----------------------------------------------------------------------------
Nome : TBSW0031RegrasFormatacaoBase.cpp
Descrição: Acerto na gravacao do Campo NUM_SEQ_UNC_RD_AUT
Autor : Renato de Camargo
Data : 07/05/2018
Empresa : REDE
ID : AM223375
----------------------------------------------------------------------------*/

#include <cstring>
#include<TBSW0031RegrasFormatacaoBase.hpp>

TBSW0031RegrasFormatacaoBase::TBSW0031RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0031RegrasFormatacaoBase::~TBSW0031RegrasFormatacaoBase( )
{
}

void TBSW0031RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::NUM_ADM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ADM( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ADM( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::VAL_MN_CAR( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_MN_CAR( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_MN_CAR( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::COD_CRT_ECM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CRT_ECM( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CRT_ECM( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::COD_CTR( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CTR( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CTR( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::QTD_DIA_CRNC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_DIA_CRNC( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_DIA_CRNC( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::NUM_SEQ_UNC_RD_AUT( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC_RD_AUT( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC_RD_AUT( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::IND_TERM_FATR_EXPS( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_TERM_FATR_EXPS( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_TERM_FATR_EXPS( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::COD_PROD_MTC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PROD_MTC( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PROD_MTC( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::COD_RGAO_MTC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_RGAO_MTC( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_RGAO_MTC( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::COD_CTAH_VOCH( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CTAH_VOCH( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CTAH_VOCH( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::NUM_REF_TRAN( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_REF_TRAN( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_REF_TRAN( tbsw0031, params );
    }
}

void TBSW0031RegrasFormatacaoBase::COD_CPCD_TERM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CPCD_TERM( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CPCD_TERM( tbsw0031, params );
    }
}
void TBSW0031RegrasFormatacaoBase::numeroEstabelecimentoPreAutorizacao( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insertNumeroEstabelecimentoPreAutorizacao( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        updateNumeroEstabelecimentoPreAutorizacao( tbsw0031, params );
    }
}
void TBSW0031RegrasFormatacaoBase::codigoTerminalPreAutorizacao( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insertCodigoTerminalPreAutorizacao( tbsw0031, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        updateCodigoTerminalPreAutorizacao( tbsw0031, params );
    }
}

// Metodos utilizados por campos que tem input generico (INSERT/UPDATE)

void TBSW0031RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_NUM_ADM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_VAL_MN_CAR( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_COD_CRT_ECM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_COD_CTR( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_QTD_DIA_CRNC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_NUM_SEQ_UNC_RD_AUT( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_IND_TERM_FATR_EXPS( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_COD_PROD_MTC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_COD_RGAO_MTC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_COD_CTAH_VOCH( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_NUM_REF_TRAN( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::gen_COD_CPCD_TERM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

// Metodos especificos para INSERT

void TBSW0031RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    tbsw0031.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0031RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw0031.set_NUM_SEQ_UNC( l_dect );
}

void TBSW0031RegrasFormatacaoBase::insert_NUM_ADM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    tbsw0031.set_NUM_ADM( 0 );
}

void TBSW0031RegrasFormatacaoBase::insert_VAL_MN_CAR( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, 0 );
    tbsw0031.set_VAL_MN_CAR( l_dect );
}

void TBSW0031RegrasFormatacaoBase::insert_COD_CRT_ECM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::insert_COD_CTR( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::insert_QTD_DIA_CRNC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::insert_NUM_SEQ_UNC_RD_AUT( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::insert_IND_TERM_FATR_EXPS( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if ( params.ind_term_flex.length( ) >= 1 )
    {
        tbsw0031.set_IND_TERM_FATR_EXPS( params.ind_term_flex.substr( 0, 1 ) );
    }
    else
    {
        tbsw0031.set_IND_TERM_FATR_EXPS( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0031RegrasFormatacaoBase::insert_COD_PROD_MTC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if ( params.categoriaMensagem.compare("CONF_PREAUT") == 0 )
    {
        if( params.iss_name == "MASTERCARD" || params.iss_name == "HIPERCARD_CRT" || 
            params.iss_name == "HIPERCARD_CRT_HMV" || params.iss_name == "MASTER_HIPER_CRT" )
        {
            if( params.mc_info_prod_code.size( ) != 0 )
            {
                tbsw0031.set_COD_PROD_MTC( params.mc_info_prod_code );
            }
        }
    }
}

void TBSW0031RegrasFormatacaoBase::insert_COD_RGAO_MTC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if ( params.categoriaMensagem.compare("CONF_PREAUT") == 0 )
    {
        if( params.iss_name == "MASTERCARD" || params.iss_name == "HIPERCARD_CRT"  || 
            params.iss_name == "HIPERCARD_CRT_HMV" || params.iss_name == "MASTER_HIPER_CRT" )
        {
            if( params.mc_info_region.size( ) != 0 )
            {
                tbsw0031.set_COD_RGAO_MTC( params.mc_info_region );
            }
        }
    }
}

void TBSW0031RegrasFormatacaoBase::insert_COD_CTAH_VOCH( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if( params.ctah.length( ) > 0 )
    {
        tbsw0031.set_COD_CTAH_VOCH( params.ctah );
    }
}

void TBSW0031RegrasFormatacaoBase::insert_NUM_REF_TRAN( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if( params.num_ref_tran.empty( ) == false )
    {
        tbsw0031.set_NUM_REF_TRAN( params.num_ref_tran );
    }
    else
    {
        tbsw0031.set_NUM_REF_TRAN( " " );
    }
}

void TBSW0031RegrasFormatacaoBase::insert_COD_CPCD_TERM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if( params.cod_cpcd_term.empty( ) == false )
    {
        tbsw0031.set_COD_CPCD_TERM( params.cod_cpcd_term );
    }
    else
    {
        tbsw0031.set_COD_CPCD_TERM( " " );
    }
}

void TBSW0031RegrasFormatacaoBase::insertNumeroEstabelecimentoPreAutorizacao( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if ( params.categoriaMensagem.compare("CONF_PREAUT") == 0 )
    {
        if( params.numeroEstabelecimentoPreAutorizacao > 0 )
        {
            tbsw0031.SetNumeroEstabelecimentoPreAutorizacao( params.numeroEstabelecimentoPreAutorizacao );
        }
    }
}

void TBSW0031RegrasFormatacaoBase::insertCodigoTerminalPreAutorizacao( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if ( params.categoriaMensagem.compare("CONF_PREAUT") == 0 )
    {
        if( params.codigoTerminalPreAutorizacao.empty( ) == false )
        {
            tbsw0031.SetCodigoTerminalPreAutorizacao( params.codigoTerminalPreAutorizacao );
        }
    }
}

// Metodos especificos para UPDATE

void TBSW0031RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_NUM_ADM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_VAL_MN_CAR( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_COD_CRT_ECM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_COD_CTR( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_QTD_DIA_CRNC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_NUM_SEQ_UNC_RD_AUT( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if( 
		/* Campo gravado para transacao VAN assinaladas abaixo */
		/* Valor devolvido pelo FE-CRT = "T", gerando falha na gravacao deste campo */
		/* params.is_van == "TRUE" &&      */
        ( params.iss_name == "SOROCRED_VAN" || 
          params.iss_name == "HIPERCARD_VAN" || params.iss_name == "COOPERCRED_VAN" ||
          params.iss_name == "REDECOMPRAS_CRT_VAN" || // AUT2-2816 - REDECOMPRAS HUB DE BANDEIRAS
          params.iss_name == "CREDSYSTEM_VAN" ) &&
        params.status != 2 )
    {
        if ( strlen( params.ext_refnum.c_str( ) ) > 0 )
        {
            oasis_dec_t l_dect;
            dbm_chartodec( &l_dect, params.ext_refnum.c_str( ), 0 );
            tbsw0031.set_NUM_SEQ_UNC_RD_AUT( l_dect );
        }
    }
}

void TBSW0031RegrasFormatacaoBase::update_IND_TERM_FATR_EXPS( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_COD_PROD_MTC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if( params.iss_name == "MASTERCARD" || params.iss_name == "HIPERCARD_CRT" || params.iss_name == "HIPERCARD_CRT_HMV" || params.iss_name == "MASTER_HIPER_CRT" )
    {
        if( params.mc_info_prod_code.size( ) != 0 )
        {
            tbsw0031.set_COD_PROD_MTC( params.mc_info_prod_code );
        }
    }
}

void TBSW0031RegrasFormatacaoBase::update_COD_RGAO_MTC( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if( params.iss_name == "MASTERCARD" || params.iss_name == "HIPERCARD_CRT"  || params.iss_name == "HIPERCARD_CRT_HMV" || params.iss_name == "MASTER_HIPER_CRT" )
    {
        if( params.mc_info_region.size( ) != 0 )
        {
            tbsw0031.set_COD_RGAO_MTC( params.mc_info_region );
        }
    }
}

void TBSW0031RegrasFormatacaoBase::update_COD_CTAH_VOCH( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0031RegrasFormatacaoBase::update_NUM_REF_TRAN( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if( params.num_ref_tran.empty( ) == false )
    {
        tbsw0031.set_NUM_REF_TRAN( params.num_ref_tran );
    }
    else
    {
        tbsw0031.set_NUM_REF_TRAN( " " );
    }
}

void TBSW0031RegrasFormatacaoBase::update_COD_CPCD_TERM( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    if( params.cod_cpcd_term.empty( ) == false )
    {
        tbsw0031.set_COD_CPCD_TERM( params.cod_cpcd_term );
    }
    else
    {
        tbsw0031.set_COD_CPCD_TERM( " " );
    }
}

void TBSW0031RegrasFormatacaoBase::updateNumeroEstabelecimentoPreAutorizacao( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION
}

void TBSW0031RegrasFormatacaoBase::updateCodigoTerminalPreAutorizacao( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params )
{
    WARNING_INVALID_FUNCTION
}
