#include <cstring>
#include<TBSW0160RegrasFormatacaoBase.hpp>
#include<AcqUtils.hpp>
#include "msgConv/TextConv.hpp"
#include <iostream>

TBSW0160RegrasFormatacaoBase::TBSW0160RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0160RegrasFormatacaoBase::~TBSW0160RegrasFormatacaoBase( )
{
}

void TBSW0160RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::IND_RD_ORG( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_RD_ORG( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_IND_RD_ORG( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::COD_PGM_AUT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PGM_AUT( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_COD_PGM_AUT( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::TXT_RLCD_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_RLCD_CHIP( TBSW0160, tbsw0160_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_RLCD_CHIP( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_INFO_CMPM_CHIP( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_TXT_INFO_CMPM_CHIP( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_RSTD_ATLZ_CHIP( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_TXT_RSTD_ATLZ_CHIP( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_NVL_SGRA_KMRC( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_IND_NVL_SGRA_KMRC( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_MTDO_VRFC_PORT( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_IND_MTDO_VRFC_PORT( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::IND_PRSC_SNHA( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_PRSC_SNHA( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_IND_PRSC_SNHA( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::DAT_CNFR_PAUZ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_CNFR_PAUZ( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_DAT_CNFR_PAUZ( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::NUM_SEQ_UNC_CNFR( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC_CNFR( TBSW0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC_CNFR( TBSW0160, tbsw0160_params );
    }
}

void TBSW0160RegrasFormatacaoBase::NumeroSequencialCartaoValidacaoChip( dbaccess_common::TBSW0160& tbsw0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertNumeroSequencialCartaoValidacaoChip( tbsw0160, tbsw0160_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        UpdateNumeroSequencialCartaoValidacaoChip( tbsw0160, tbsw0160_params );
    }
}

//#######################################################################
//#######################################################################

void TBSW0160RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    TBSW0160.set_DAT_MOV_TRAN( tbsw0160_params.local_date );
}

void TBSW0160RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    TBSW0160.set_NUM_SEQ_UNC( tbsw0160_params.refnum );
}

void TBSW0160RegrasFormatacaoBase::insert_IND_RD_ORG( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    if ( tbsw0160_params.termid_type.compare( "AVR" ) == 0 || tbsw0160_params.termid_type.compare( "OL" ) == 0 )
    {
        TBSW0160.set_IND_RD_ORG( "1" );
    }
    else if ( tbsw0160_params.termid_type.compare( "KMC" ) == 0 || tbsw0160_params.termid_type.compare( "MPG" ) == 0 )
    {
        TBSW0160.set_IND_RD_ORG( "5" );
    }
    else if ( tbsw0160_params.termid_type.compare( "PDVDIAL" ) == 0 || tbsw0160_params.termid_type.compare( "HY8583" ) == 0 )
    {
        TBSW0160.set_IND_RD_ORG( "3" );
    }
    else if ( tbsw0160_params.termid_type.compare( "ECR" ) == 0 )
    {
        TBSW0160.set_IND_RD_ORG( "2" );
    }
    else
    {
        TBSW0160.set_IND_RD_ORG( " " );
    }
}

void TBSW0160RegrasFormatacaoBase::insert_COD_PGM_AUT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    TBSW0160.set_COD_PGM_AUT( std::string(" ") );
}

void TBSW0160RegrasFormatacaoBase::insert_TXT_RLCD_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    if( tbsw0160_params.iss_name == "AMEX_FULL" &&
        strlen( tbsw0160_params.chip_full_data.c_str( ) ) && tbsw0160_params.chip_full_data_len > 0 )
    {
        std::string de055_esperado = "C1C7D5E20001";
        std::string conteudo_tag   = "";
        std::string chip           = tbsw0160_params.chip_full_data;
        
        std::transform(chip.begin( ), chip.end( ),chip.begin( ), ::toupper);
        if( AcqUtils::findChip( chip, "9F26", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F10", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F37", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F36", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "95", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }

        if( AcqUtils::findChip( chip, "9A", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9C", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F02", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "5F2A", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F1A", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "82", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F03", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "5F34", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }

        if( AcqUtils::findChip( chip, "9F27", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        chip = de055_esperado;
        TBSW0160.set_TXT_RLCD_CHIP( chip );
    }
    else if ( strlen( tbsw0160_params.chip_full_data.c_str( ) ) && tbsw0160_params.chip_full_data_len > 0 )
    {            
        std::string chip = tbsw0160_params.chip_full_data.substr( 0, tbsw0160_params.chip_full_data_len * 2 );        
        TBSW0160.set_TXT_RLCD_CHIP( chip );
    }
    else
    {
        WARNING_EMPTY_STRING;
        TBSW0160.set_TXT_RLCD_CHIP( " " );
    }
}

void TBSW0160RegrasFormatacaoBase::insert_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    gen_TXT_INFO_CMPM_CHIP( TBSW0160, tbsw0160_params );
}

void TBSW0160RegrasFormatacaoBase::insert_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    gen_TXT_RSTD_ATLZ_CHIP( TBSW0160, tbsw0160_params );
}

void TBSW0160RegrasFormatacaoBase::insert_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    TBSW0160.set_IND_NVL_SGRA_KMRC( std::string("0") );
}

void TBSW0160RegrasFormatacaoBase::insert_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    if ( strlen( tbsw0160_params.cvm_code.c_str( ) ) )
    {
        TBSW0160.set_IND_MTDO_VRFC_PORT( tbsw0160_params.cvm_code.substr( 1, 1 ) );
    }
}

void TBSW0160RegrasFormatacaoBase::insert_IND_PRSC_SNHA( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    if ( strlen( tbsw0160_params.pin.c_str( ) ) )
    {
        TBSW0160.set_IND_PRSC_SNHA( "S" );
    }
    else
    {
        TBSW0160.set_IND_PRSC_SNHA( "N" );
    }
}

void TBSW0160RegrasFormatacaoBase::insert_DAT_CNFR_PAUZ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{    
    gen_DAT_CNFR_PAUZ( TBSW0160, tbsw0160_params );
}

void TBSW0160RegrasFormatacaoBase::insert_NUM_SEQ_UNC_CNFR( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::InsertNumeroSequencialCartaoValidacaoChip( dbaccess_common::TBSW0160& tbsw0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    if ( tbsw0160_params.numeroSequenciaCartaoChip.size() != 0 || !tbsw0160_params.numeroSequenciaCartaoChip.empty( ) )//nao veio DE023?
    {
        tbsw0160.SetNumeroSequencialCartaoValidacaoChip( atol( tbsw0160_params.numeroSequenciaCartaoChip.c_str( ) ) );
    }
    else
    {
        if( tbsw0160_params.iss_name == "VISA_CREDITO" )
        {
            tbsw0160.SetNumeroSequencialCartaoValidacaoChip( 0 );
        }
        else
        {
            tbsw0160.SetNumeroSequencialCartaoValidacaoChip( 999 );
        }
    }
}

//#######################################################################
//#######################################################################

void TBSW0160RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::update_IND_RD_ORG( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::update_COD_PGM_AUT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::update_TXT_RLCD_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::update_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    gen_TXT_INFO_CMPM_CHIP( TBSW0160, tbsw0160_params );
}

void TBSW0160RegrasFormatacaoBase::update_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    gen_TXT_RSTD_ATLZ_CHIP( TBSW0160, tbsw0160_params );
}

void TBSW0160RegrasFormatacaoBase::update_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::update_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::update_IND_PRSC_SNHA( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::update_DAT_CNFR_PAUZ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    gen_DAT_CNFR_PAUZ( TBSW0160, tbsw0160_params );
}

void TBSW0160RegrasFormatacaoBase::update_NUM_SEQ_UNC_CNFR( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    if ( tbsw0160_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0160_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        TBSW0160.set_NUM_SEQ_UNC_CNFR( tbsw0160_params.refnum );
    }
}

void TBSW0160RegrasFormatacaoBase::UpdateNumeroSequencialCartaoValidacaoChip( dbaccess_common::TBSW0160& tbsw0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

//#######################################################################
//#######################################################################

void TBSW0160RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_IND_RD_ORG( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_COD_PGM_AUT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_TXT_RLCD_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    if ( strlen( tbsw0160_params.second_gen_ac.c_str( ) ) )
    {
        TBSW0160.set_TXT_INFO_CMPM_CHIP( tbsw0160_params.second_gen_ac.substr( 0, 70 ) );
    }
    else
    {
        WARNING_EMPTY_STRING;
        TBSW0160.set_TXT_INFO_CMPM_CHIP( " " );
    }
}

void TBSW0160RegrasFormatacaoBase::gen_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    if ( strlen( tbsw0160_params.isr.c_str( ) ) )
    {
        TBSW0160.set_TXT_RSTD_ATLZ_CHIP( tbsw0160_params.isr );
    }
    else
    {
        WARNING_EMPTY_STRING;
        TBSW0160.set_TXT_RSTD_ATLZ_CHIP( " " );
    }
}

void TBSW0160RegrasFormatacaoBase::gen_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_IND_PRSC_SNHA( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_DAT_CNFR_PAUZ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::gen_NUM_SEQ_UNC_CNFR( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0160RegrasFormatacaoBase::GenNumeroSequencialCartaoValidacaoChip( dbaccess_common::TBSW0160& tbsw0160, const struct acq_common::tbsw0160_params& tbsw0160_params )
{
    WARNING_INVALID_FUNCTION;
}

//#######################################################################
//#######################################################################

