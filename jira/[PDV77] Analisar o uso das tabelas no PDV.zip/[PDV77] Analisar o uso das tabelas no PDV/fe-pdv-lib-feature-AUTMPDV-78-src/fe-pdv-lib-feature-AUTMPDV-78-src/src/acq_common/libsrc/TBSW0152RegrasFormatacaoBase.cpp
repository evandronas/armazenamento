#include<TBSW0152RegrasFormatacaoBase.hpp>
#include <iostream>

TBSW0152RegrasFormatacaoBase::TBSW0152RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0152RegrasFormatacaoBase::~TBSW0152RegrasFormatacaoBase( )
{
}

void TBSW0152RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::QTD_CICL_CRNC_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_CICL_CRNC_PRMR_PRCL( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_CICL_CRNC_PRMR_PRCL( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::QTD_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_PRCL( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_PRCL( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::DAT_VCTO_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_VCTO_PRMR_PRCL( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_VCTO_PRMR_PRCL( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::VAL_PRCL_ENTR( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_PRCL_ENTR( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_PRCL_ENTR( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::VAL_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_PRCL( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_PRCL( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::PRCN_TX_JURO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_PRCN_TX_JURO( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_PRCN_TX_JURO( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::PRCN_TX_JURO_MES( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_PRCN_TX_JURO_MES( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_PRCN_TX_JURO_MES( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::PRCN_TX_JURO_ANO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_PRCN_TX_JURO_ANO( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_PRCN_TX_JURO_ANO( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::PRCN_TX_JURO_MORA( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_PRCN_TX_JURO_MORA( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_PRCN_TX_JURO_MORA( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::VAL_PRES_BRTO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_PRES_BRTO( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_PRES_BRTO( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::VAL_TX_EFTV( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TX_EFTV( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TX_EFTV( tbsw0152, params );
    }
}

void TBSW0152RegrasFormatacaoBase::VAL_TX_MNSL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TX_MNSL( tbsw0152, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TX_MNSL( tbsw0152, params );
    }
}


void TBSW0152RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_QTD_CICL_CRNC_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_QTD_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_DAT_VCTO_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_VAL_PRCL_ENTR( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_VAL_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_PRCN_TX_JURO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_PRCN_TX_JURO_MES( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_PRCN_TX_JURO_ANO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_PRCN_TX_JURO_MORA( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_VAL_PRES_BRTO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_VAL_TX_EFTV( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::gen_VAL_TX_MNSL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}


void TBSW0152RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    tbsw0152.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0152RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw0152.set_NUM_SEQ_UNC( l_dect );
}

void TBSW0152RegrasFormatacaoBase::insert_QTD_CICL_CRNC_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    tbsw0152.set_QTD_CICL_CRNC_PRMR_PRCL( 0 );
}

void TBSW0152RegrasFormatacaoBase::insert_QTD_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    tbsw0152.set_QTD_PRCL( params.install_num );
}

void TBSW0152RegrasFormatacaoBase::insert_DAT_VCTO_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::insert_VAL_PRCL_ENTR( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::insert_VAL_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::insert_PRCN_TX_JURO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0.00", 2 );
    tbsw0152.set_PRCN_TX_JURO( l_dect );
}

void TBSW0152RegrasFormatacaoBase::insert_PRCN_TX_JURO_MES( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0.00", 2 );
    tbsw0152.set_PRCN_TX_JURO_MES( l_dect );
}

void TBSW0152RegrasFormatacaoBase::insert_PRCN_TX_JURO_ANO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0.00", 2 );
    tbsw0152.set_PRCN_TX_JURO_ANO( l_dect );
}

void TBSW0152RegrasFormatacaoBase::insert_PRCN_TX_JURO_MORA( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0.00", 2 );
    tbsw0152.set_PRCN_TX_JURO_MORA( l_dect );
}

void TBSW0152RegrasFormatacaoBase::insert_VAL_PRES_BRTO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0.00", 2 );
    tbsw0152.set_VAL_PRES_BRTO( l_dect );
}

void TBSW0152RegrasFormatacaoBase::insert_VAL_TX_EFTV( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0.00", 2 );
    tbsw0152.set_VAL_TX_EFTV( l_dect );
}

void TBSW0152RegrasFormatacaoBase::insert_VAL_TX_MNSL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0.00", 2 );
    tbsw0152.set_VAL_TX_MNSL( l_dect );
}


void TBSW0152RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_QTD_CICL_CRNC_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_QTD_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_DAT_VCTO_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_VAL_PRCL_ENTR( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_VAL_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_PRCN_TX_JURO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_PRCN_TX_JURO_MES( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_PRCN_TX_JURO_ANO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_PRCN_TX_JURO_MORA( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_VAL_PRES_BRTO( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0152RegrasFormatacaoBase::update_VAL_TX_EFTV( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    /* Jan2018 Alterado conforme MER
    if ( ( params.msg_name != "VEND_PL" ) && ( params.msg_name != "VEND_PL_ZOLKIN" ) )
    {
        oasis_dec_t l_dect;
        dbm_chartodec( &l_dect, params.applied_fee.c_str( ), 5 );
        tbsw0152.set_VAL_TX_EFTV( l_dect );
    }
    */

    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0.00000", 5 );
    tbsw0152.set_VAL_TX_EFTV( l_dect );
}

void TBSW0152RegrasFormatacaoBase::update_VAL_TX_MNSL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params )
{
    oasis_dec_t l_dect;
 
    if ( params.status == 2 ||
        ( params.msg_name.compare( "VEND_PL" ) == 0 || params.msg_name.compare( "VEND_PL_ZOLKIN" ) == 0 ) ||
        ( params.msg_name.compare( "VEND_CRT_PARC_SJURO" ) == 0        ||
          params.msg_name.compare( "VEND_IATA_PARC_SJURO" ) == 0       ||
          params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0     ||
          params.msg_name.compare( "VEND_CRT_PARC_SJURO_ZOLKIN" ) == 0 ||
          params.msg_name.compare( "CONF_VEND_CRT_PARC_SJURO_ZOLKIN" ) == 0 )
       )
    {
        dbm_chartodec( &l_dect, "0.00", 2 );
    }
    else
    if ( params.msg_name.compare( "VEND_CRT_PARC_CJURO" ) == 0        ||
         params.msg_name.compare( "VEND_IATA_PARC_CJURO" ) == 0       ||
         params.msg_name.compare( "CONF_VEND_CRT_PARC_CJURO" ) == 0   ||
         params.msg_name.compare( "CONF_VEND_IATA_PARC_CJURO" ) == 0  ||
         params.msg_name.compare( "VEND_CRT_PARC_CJURO_ZOLKIN" ) == 0 ||
         params.msg_name.compare( "CONF_VEND_CRT_PARC_CJURO_ZOLKIN" ) == 0 )
    {
        if ( params.iss_name.compare( "UPI" ) == 0 )
            dbm_chartodec( &l_dect, "0.00", 2 );
        else
        {
            double l_dbl_val;
            if ( params.fee.find_first_of( '.' ) != std::string::npos )
            {
                l_dbl_val = atof( params.fee.c_str( ) ) * 100.00;
            }
            else
            {
                l_dbl_val = atof( params.fee.c_str( ) );
            }
            dbm_dbltodec( &l_dect, ( l_dbl_val / 100.00 ) );
        }
    }
    else
    {
        dbm_chartodec( &l_dect, "0.00", 2 );
    }

    tbsw0152.set_VAL_TX_MNSL( l_dect );

}
