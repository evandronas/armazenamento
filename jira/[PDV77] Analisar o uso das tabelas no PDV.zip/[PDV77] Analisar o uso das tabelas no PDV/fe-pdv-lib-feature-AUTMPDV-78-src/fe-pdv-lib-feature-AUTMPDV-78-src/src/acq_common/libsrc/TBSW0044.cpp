#pragma once
#include "TBSW0044.hpp"

namespace dbaccess_common
{
    TBSW0044::TBSW0044()
    {

        query_fields = "NUM_PDV, NUM_BIN_INI, NUM_BIN_FIM, COD_EMSR, COD_STTU_TRAN, DAT_ATLZ_REG, COD_USR_ATLZ_REG, IND_STTU_REG";

        table_name = "TBSW0044";

        m_NUM_PDV_pos = 1;
        m_NUM_BIN_INI_pos = 2;
        m_NUM_BIN_FIM_pos = 3;
        m_COD_EMSR_pos = 4;
        m_COD_STTU_TRAN_pos = 5;
        m_DAT_ATLZ_REG_pos = 6;
        m_COD_USR_ATLZ_REG_pos = 7;
        m_IND_STTU_REG_pos = 8;

        m_NUM_PDV = 0;
        dbm_longtodec( &m_NUM_BIN_INI, 0 );
        dbm_longtodec( &m_NUM_BIN_FIM, 0 );
        m_COD_EMSR = 0;
        m_COD_STTU_TRAN = "";
        m_DAT_ATLZ_REG = 0;
        m_COD_USR_ATLZ_REG = " ";
        m_IND_STTU_REG = " ";

        where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0044::TBSW0044( const std::string& whereClause )
    {

        query_fields = "NUM_PDV, NUM_BIN_INI, NUM_BIN_FIM, COD_EMSR, COD_STTU_TRAN, DAT_ATLZ_REG, COD_USR_ATLZ_REG, IND_STTU_REG";

        table_name = "TBSW0044";

        m_NUM_PDV_pos = 1;
        m_NUM_BIN_INI_pos = 2;
        m_NUM_BIN_FIM_pos = 3;
        m_COD_EMSR_pos = 4;
        m_COD_STTU_TRAN_pos = 5;
        m_DAT_ATLZ_REG_pos = 6;
        m_COD_USR_ATLZ_REG_pos = 7;
        m_IND_STTU_REG_pos = 8;

        m_NUM_PDV = 0;
        dbm_longtodec( &m_NUM_BIN_INI, 0 );
        dbm_longtodec( &m_NUM_BIN_FIM, 0 );
        m_COD_EMSR = 0;
        m_COD_STTU_TRAN = "";
        m_DAT_ATLZ_REG = 0;
        m_COD_USR_ATLZ_REG = " ";
        m_IND_STTU_REG = " ";

        where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0044::~TBSW0044()
    {
    }

    void TBSW0044::bind_columns()
    {
        bind( m_NUM_PDV_pos, m_NUM_PDV );
        bind( m_NUM_BIN_INI_pos, m_NUM_BIN_INI );
        bind( m_NUM_BIN_FIM_pos, m_NUM_BIN_FIM );
        bind( m_COD_EMSR_pos, m_COD_EMSR );
        bind( m_COD_STTU_TRAN_pos, m_COD_STTU_TRAN );
        bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
        bind( m_COD_USR_ATLZ_REG_pos, m_COD_USR_ATLZ_REG );
        bind( m_IND_STTU_REG_pos, m_IND_STTU_REG );
    }
    void TBSW0044::set_NUM_PDV( unsigned long a_NUM_PDV )
    {
        m_NUM_PDV = a_NUM_PDV;
    }
    void TBSW0044::set_NUM_BIN_INI( oasis_dec_t a_NUM_BIN_INI )
    {
        dbm_deccopy( &m_NUM_BIN_INI, &a_NUM_BIN_INI );
    }
    void TBSW0044::set_NUM_BIN_FIM( oasis_dec_t a_NUM_BIN_FIM )
    {
        dbm_deccopy( &m_NUM_BIN_FIM, &a_NUM_BIN_FIM );
    }
    void TBSW0044::set_COD_EMSR( unsigned long a_COD_EMSR )
    {
        m_COD_EMSR = a_COD_EMSR;
    }
    void TBSW0044::set_COD_STTU_TRAN( const std::string& a_COD_STTU_TRAN )
    {
        m_COD_STTU_TRAN = a_COD_STTU_TRAN;
    }
    void TBSW0044::set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG )
    {
        m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    void TBSW0044::set_COD_USR_ATLZ_REG( const std::string& a_COD_USR_ATLZ_REG )
    {
        m_COD_USR_ATLZ_REG = a_COD_USR_ATLZ_REG;
    }
    void TBSW0044::set_IND_STTU_REG( const std::string& a_IND_STTU_REG )
    {
        m_IND_STTU_REG = a_IND_STTU_REG;
    }
    unsigned long TBSW0044::get_NUM_PDV() const
    {
        return m_NUM_PDV;
    }
    oasis_dec_t TBSW0044::get_NUM_BIN_INI() const
    {
        return m_NUM_BIN_INI;
    }
    oasis_dec_t TBSW0044::get_NUM_BIN_FIM() const
    {
        return m_NUM_BIN_FIM;
    }
    unsigned long TBSW0044::get_COD_EMSR() const
    {
        return m_COD_EMSR;
    }
    const std::string& TBSW0044::get_COD_STTU_TRAN() const
    {
        return m_COD_STTU_TRAN;
    }
    dbm_datetime_t TBSW0044::get_DAT_ATLZ_REG() const
    {
        return m_DAT_ATLZ_REG;
    }
    const std::string& TBSW0044::get_COD_USR_ATLZ_REG() const
    {
        return m_COD_USR_ATLZ_REG;
    }
    const std::string& TBSW0044::get_IND_STTU_REG() const
    {
        return m_IND_STTU_REG;
    }

} //namespace dbaccess_common

