/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "TBSW0041.hpp"
#include <iostream>
#include <stdio.h>
#include <string.h>

namespace dbaccess_common
{
	TBSW0041::TBSW0041( )
	{
		query_fields = "NUM_PDV, COD_BNDR, QTD_MXO_PRCL, COD_STTU_REG, DAT_ATLZ_REG, COD_BCO_CMPS, COD_AGE, \
		NUM_CTA_BNCR, DAT_INI_COB_ANT, DAT_INI_COB_ATU, TIP_COB_TRAN_ANT, TIP_COB_TRAN_ATU, VAL_COB_TRAN_ANT, \
		VAL_COB_TRAN_ATU, COD_TRAN, IND_PERM_TRAN_DGTD_EMSR, IND_MODL_CPTR,IND_PART_PROD_FLEX";
		table_name = "TBSW0041";
		where_condition = "";
		m_NUM_PDV_pos = 1;
		m_COD_BNDR_pos = 2;
		m_QTD_MXO_PRCL_pos = 3;
		m_COD_STTU_REG_pos = 4;
		m_DAT_ATLZ_REG_pos = 5;
		m_COD_BCO_CMPS_pos = 6;
		m_COD_AGE_pos = 7;
		m_NUM_CTA_BNCR_pos = 8;
		m_DAT_INI_COB_ANT_pos = 9;
		m_DAT_INI_COB_ATU_pos = 10;
		m_TIP_COB_TRAN_ANT_pos = 11;
		m_TIP_COB_TRAN_ATU_pos = 12;
		m_VAL_COB_TRAN_ANT_pos = 13;
		m_VAL_COB_TRAN_ATU_pos = 14;
		m_COD_TRAN_pos = 15;
		m_IND_PERM_TRAN_DGTD_EMSR_pos = 16;
		m_IND_MODL_CPTR_pos = 17;
		m_IND_PART_PROD_FLEX_pos = 18;
		m_NUM_PDV = 0;
		m_COD_BNDR = 0;
		m_QTD_MXO_PRCL = 0;
		m_COD_STTU_REG = "";
		m_DAT_ATLZ_REG = 0;
		m_COD_BCO_CMPS = 0;
		m_COD_AGE = 0;
		m_NUM_CTA_BNCR = "";
		m_DAT_INI_COB_ANT = 0;
		m_DAT_INI_COB_ATU = 0;
		m_TIP_COB_TRAN_ANT = "";
		m_TIP_COB_TRAN_ATU = "";
		dbm_inttodec( &m_VAL_COB_TRAN_ANT, 0 );
		dbm_inttodec( &m_VAL_COB_TRAN_ATU, 0 );
		m_COD_TRAN = 0;
		m_IND_PERM_TRAN_DGTD_EMSR = "";
		m_IND_MODL_CPTR = "";
		m_IND_PART_PROD_FLEX = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0041::TBSW0041( const std::string &str )
	{
		query_fields = "NUM_PDV, COD_BNDR, QTD_MXO_PRCL, COD_STTU_REG, DAT_ATLZ_REG, COD_BCO_CMPS, COD_AGE, \
		NUM_CTA_BNCR, DAT_INI_COB_ANT, DAT_INI_COB_ATU, TIP_COB_TRAN_ANT, TIP_COB_TRAN_ATU, VAL_COB_TRAN_ANT, \
		VAL_COB_TRAN_ATU, COD_TRAN, IND_PERM_TRAN_DGTD_EMSR, IND_MODL_CPTR, IND_PART_PROD_FLEX";
		table_name = "TBSW0041";
		where_condition = str;
		m_NUM_PDV_pos = 1;
		m_COD_BNDR_pos = 2;
		m_QTD_MXO_PRCL_pos = 3;
		m_COD_STTU_REG_pos = 4;
		m_DAT_ATLZ_REG_pos = 5;
		m_COD_BCO_CMPS_pos = 6;
		m_COD_AGE_pos = 7;
		m_NUM_CTA_BNCR_pos = 8;
		m_DAT_INI_COB_ANT_pos = 9;
		m_DAT_INI_COB_ATU_pos = 10;
		m_TIP_COB_TRAN_ANT_pos = 11;
		m_TIP_COB_TRAN_ATU_pos = 12;
		m_VAL_COB_TRAN_ANT_pos = 13;
		m_VAL_COB_TRAN_ATU_pos = 14;
		m_COD_TRAN_pos = 15;
		m_IND_PERM_TRAN_DGTD_EMSR_pos = 16;
		m_IND_MODL_CPTR_pos = 17;
		m_IND_PART_PROD_FLEX_pos = 18;
		m_NUM_PDV = 0;
		m_COD_BNDR = 0;
		m_QTD_MXO_PRCL = 0;
		m_COD_STTU_REG = "";
		m_DAT_ATLZ_REG = 0;
		m_COD_BCO_CMPS = 0;
		m_COD_AGE = 0;
		m_NUM_CTA_BNCR = "";
		m_DAT_INI_COB_ANT = 0;
		m_DAT_INI_COB_ATU = 0;
		m_TIP_COB_TRAN_ANT = "";
		m_TIP_COB_TRAN_ATU = "";
		dbm_inttodec( &m_VAL_COB_TRAN_ANT, 0 );
		dbm_inttodec( &m_VAL_COB_TRAN_ATU, 0 );
		m_COD_TRAN = 0;
		m_IND_PERM_TRAN_DGTD_EMSR = "";
		m_IND_MODL_CPTR = "";
		m_IND_PART_PROD_FLEX = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0041::~TBSW0041( )
	{
	}
	//////////////////////////////////// GET ////////////////////////////////////
	long TBSW0041::getNUM_PDV( ) const
	{
		return m_NUM_PDV;
	}
	long TBSW0041::getCOD_BNDR( ) const
	{
		return m_COD_BNDR;
	}
	long TBSW0041::getQTD_MXO_PRCL( ) const
	{
		return m_QTD_MXO_PRCL;
	}
	const std::string TBSW0041::getCOD_STTU_REG( ) const
	{
		return m_COD_STTU_REG;
	}
	const dbm_datetime_t TBSW0041::getDAT_ATLZ_REG( ) const
	{
		return m_DAT_ATLZ_REG;
	}
	long TBSW0041::getCOD_BCO_CMPS( ) const
	{
		return m_COD_BCO_CMPS;
	}
	long TBSW0041::getCOD_AGE( ) const
	{
		return m_COD_AGE;
	}
	const std::string TBSW0041::getNUM_CTA_BNCR( ) const
	{
		return m_NUM_CTA_BNCR;
	}
	const dbm_datetime_t TBSW0041::getDAT_INI_COB_ANT( ) const
	{
		return m_DAT_INI_COB_ANT;
	}
	const dbm_datetime_t TBSW0041::getDAT_INI_COB_ATU( ) const
	{
		return m_DAT_INI_COB_ATU;
	}
	const std::string TBSW0041::getTIP_COB_TRAN_ANT( ) const
	{
		return m_TIP_COB_TRAN_ANT;
	}
	const std::string TBSW0041::getTIP_COB_TRAN_ATU( ) const
	{
		return m_TIP_COB_TRAN_ATU;
	}
	const oasis_dec_t TBSW0041::getVAL_COB_TRAN_ANT( ) const
	{
		return m_VAL_COB_TRAN_ANT;
	}
	const oasis_dec_t TBSW0041::getVAL_COB_TRAN_ATU( ) const
	{
		return m_VAL_COB_TRAN_ATU;
	}
	long TBSW0041::getCOD_TRAN( ) const
	{
		return m_COD_TRAN;
	}
	const std::string TBSW0041::getIND_PERM_TRAN_DGTD_EMSR( ) const
	{
		return m_IND_PERM_TRAN_DGTD_EMSR;
	}
	const std::string TBSW0041::getIND_MODL_CPTR( ) const
	{
		return m_IND_MODL_CPTR;
	}
	const std::string TBSW0041::getIND_PART_PROD_FLEX( ) const
	{
		return m_IND_PART_PROD_FLEX;
	}
	//////////////////////////////////// SET ////////////////////////////////////
	void TBSW0041::setNUM_PDV( long a_NUM_PDV )
	{
		m_NUM_PDV = a_NUM_PDV;
	}
	void TBSW0041::setCOD_BNDR( long a_COD_BNDR )
	{
		m_COD_BNDR = a_COD_BNDR;
	}
	void TBSW0041::setQTD_MXO_PRCL( long a_QTD_MXO_PRCL )
	{
		m_QTD_MXO_PRCL = a_QTD_MXO_PRCL;
	}
	void TBSW0041::setCOD_STTU_REG( const std::string& a_COD_STTU_REG )
	{
		m_COD_STTU_REG = a_COD_STTU_REG;
	}
	void TBSW0041::setDAT_ATLZ_REG( const dbm_datetime_t a_DAT_ATLZ_REG )
	{
		m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
	}
	void TBSW0041::setCOD_BCO_CMPS( long a_COD_BCO_CMPS )
	{
		m_COD_BCO_CMPS = a_COD_BCO_CMPS;
	}
	void TBSW0041::setCOD_AGE( long a_COD_AGE )
	{
		m_COD_AGE = a_COD_AGE;
	}
	void TBSW0041::setNUM_CTA_BNCR( const std::string& a_NUM_CTA_BNCR )
	{
		m_NUM_CTA_BNCR = a_NUM_CTA_BNCR;
	}
	void TBSW0041::setDAT_INI_COB_ANT( const dbm_datetime_t a_DAT_INI_COB_ANT )
	{
		m_DAT_INI_COB_ANT = a_DAT_INI_COB_ANT;
	}
	void TBSW0041::setDAT_INI_COB_ATU( const dbm_datetime_t a_DAT_INI_COB_ATU )
	{
		m_DAT_INI_COB_ATU = a_DAT_INI_COB_ATU;
	}
	void TBSW0041::setTIP_COB_TRAN_ANT( const std::string& a_TIP_COB_TRAN_ANT )
	{
		m_TIP_COB_TRAN_ANT = a_TIP_COB_TRAN_ANT;
	}
	void TBSW0041::setTIP_COB_TRAN_ATU( const std::string& a_TIP_COB_TRAN_ATU )
	{
		m_TIP_COB_TRAN_ATU = a_TIP_COB_TRAN_ATU;
	}
	void TBSW0041::setVAL_COB_TRAN_ANT( oasis_dec_t a_VAL_COB_TRAN_ANT )
	{
		dbm_deccopy( &m_VAL_COB_TRAN_ANT, &a_VAL_COB_TRAN_ANT );
	}
	void TBSW0041::setVAL_COB_TRAN_ATU( oasis_dec_t a_VAL_COB_TRAN_ATU )
	{
		dbm_deccopy( &m_VAL_COB_TRAN_ATU, &a_VAL_COB_TRAN_ATU );
	}
	void TBSW0041::setCOD_TRAN( long a_COD_TRAN )
	{
		m_COD_TRAN = a_COD_TRAN;
	}
	void TBSW0041::setIND_PERM_TRAN_DGTD_EMSR( const std::string& a_IND_PERM_TRAN_DGTD_EMSR )
	{
		m_IND_PERM_TRAN_DGTD_EMSR = a_IND_PERM_TRAN_DGTD_EMSR;
	}
	void TBSW0041::setIND_MODL_CPTR( const std::string& a_IND_MODL_CPTR )
	{
		m_IND_MODL_CPTR = a_IND_MODL_CPTR;
	}
	void TBSW0041::setIND_PART_PROD_FLEX( const std::string& a_IND_PART_PROD_FLEX )
	{
		m_IND_PART_PROD_FLEX= a_IND_PART_PROD_FLEX;
	}
	void TBSW0041::bind_columns( )
	{
		bind( m_NUM_PDV_pos, m_NUM_PDV );
		bind( m_COD_BNDR_pos, m_COD_BNDR );
		bind( m_QTD_MXO_PRCL_pos, m_QTD_MXO_PRCL );
		bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
		bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
		bind( m_COD_BCO_CMPS_pos, m_COD_BCO_CMPS );
		bind( m_COD_AGE_pos, m_COD_AGE );
		bind( m_NUM_CTA_BNCR_pos, m_NUM_CTA_BNCR );
		bind( m_DAT_INI_COB_ANT_pos, &m_DAT_INI_COB_ANT );
		bind( m_DAT_INI_COB_ATU_pos, &m_DAT_INI_COB_ATU );
		bind( m_TIP_COB_TRAN_ANT_pos, m_TIP_COB_TRAN_ANT );
		bind( m_TIP_COB_TRAN_ATU_pos, m_TIP_COB_TRAN_ATU );
		bind( m_VAL_COB_TRAN_ANT_pos, m_VAL_COB_TRAN_ANT );
		bind( m_VAL_COB_TRAN_ATU_pos, m_VAL_COB_TRAN_ATU );
		bind( m_COD_TRAN_pos, m_COD_TRAN );
		bind( m_IND_PERM_TRAN_DGTD_EMSR_pos, m_IND_PERM_TRAN_DGTD_EMSR );
		bind( m_IND_MODL_CPTR_pos, m_IND_MODL_CPTR );
		bind( m_IND_PART_PROD_FLEX_pos, m_IND_PART_PROD_FLEX);
	}
}//namespace dbaccess_common

