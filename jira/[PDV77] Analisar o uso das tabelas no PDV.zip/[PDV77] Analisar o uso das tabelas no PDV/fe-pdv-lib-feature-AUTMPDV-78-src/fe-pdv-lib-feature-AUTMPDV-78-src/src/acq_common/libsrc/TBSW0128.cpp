#include "TBSW0128.hpp"

namespace dbaccess_common
{
	TBSW0128::TBSW0128()
	{

		query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, NUM_ESTB, VAL_TRAN, COD_TERM, NUM_CAR, COD_MOT_RSPS_DEST, DTH_INI_TRAN";

		table_name = "TBSW0128";

		m_DAT_MOV_TRAN_pos = 1;
		m_NUM_SEQ_UNC_pos = 2;
		m_NUM_ESTB_pos = 3;
		m_VAL_TRAN_pos = 4;
		m_COD_TERM_pos = 5;
		m_NUM_CAR_pos = 6;
		m_COD_MOT_RSPS_DEST_pos = 7;
		m_DTH_INI_TRAN_pos = 8;

		m_DAT_MOV_TRAN = 0;
		m_NUM_SEQ_UNC = 0;
		m_NUM_ESTB = 0;
		m_VAL_TRAN = 0;
		m_COD_TERM = " ";
		m_NUM_CAR = " ";
		m_COD_MOT_RSPS_DEST = " ";
		m_DTH_INI_TRAN = 0;

		where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0128::TBSW0128( const std::string& whereClause )
	{

		query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, NUM_ESTB, VAL_TRAN, COD_TERM, NUM_CAR, COD_MOT_RSPS_DEST, DTH_INI_TRAN";

		table_name = "TBSW0128";

		m_DAT_MOV_TRAN_pos = 1;
		m_NUM_SEQ_UNC_pos = 2;
		m_NUM_ESTB_pos = 3;
		m_VAL_TRAN_pos = 4;
		m_COD_TERM_pos = 5;
		m_NUM_CAR_pos = 6;
		m_COD_MOT_RSPS_DEST_pos = 7;
		m_DTH_INI_TRAN_pos = 8;

		m_DAT_MOV_TRAN = 0;
		m_NUM_SEQ_UNC = 0;
		m_NUM_ESTB = 0;
		m_VAL_TRAN = 0;
		m_COD_TERM = " ";
		m_NUM_CAR = " ";
		m_COD_MOT_RSPS_DEST = " ";
		m_DTH_INI_TRAN = 0;

		where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0128::~TBSW0128()
	{
	}

	void TBSW0128::bind_columns()
	{
		bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
		bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
		bind( m_NUM_ESTB_pos, m_NUM_ESTB );
		bind( m_VAL_TRAN_pos, m_VAL_TRAN );
		bind( m_COD_TERM_pos, m_COD_TERM );
		bind( m_NUM_CAR_pos, m_NUM_CAR );
		bind( m_COD_MOT_RSPS_DEST_pos, m_COD_MOT_RSPS_DEST );
		bind( m_DTH_INI_TRAN_pos, &m_DTH_INI_TRAN );
	}
	
	void TBSW0128::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
	{
		m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
	}
	void TBSW0128::set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC )
	{
		m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
	}
	void TBSW0128::set_NUM_ESTB( unsigned long a_NUM_ESTB )
	{
		m_NUM_ESTB = a_NUM_ESTB;
	}
	void TBSW0128::set_VAL_TRAN( unsigned long a_VAL_TRAN )
	{
		m_VAL_TRAN = a_VAL_TRAN;
	}
	void TBSW0128::set_COD_TERM( const std::string& a_COD_TERM )
	{
		m_COD_TERM = a_COD_TERM;
	}
	void TBSW0128::set_NUM_CAR( const std::string& a_NUM_CAR )
	{
		m_NUM_CAR = a_NUM_CAR;
	}
	void TBSW0128::set_COD_MOT_RSPS_DEST( const std::string& a_COD_MOT_RSPS_DEST )
	{
		m_COD_MOT_RSPS_DEST = a_COD_MOT_RSPS_DEST;
	}
	void TBSW0128::set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN )
	{
		m_DTH_INI_TRAN = a_DTH_INI_TRAN;
	}
	
	unsigned long TBSW0128::get_DAT_MOV_TRAN() const
	{
		return m_DAT_MOV_TRAN;
	}
	unsigned long TBSW0128::get_NUM_SEQ_UNC() const
	{
		return m_NUM_SEQ_UNC;
	}
	unsigned long TBSW0128::get_NUM_ESTB() const
	{
		return m_NUM_ESTB;
	}
	unsigned long TBSW0128::get_VAL_TRAN() const
	{
		return m_VAL_TRAN;
	}
	const std::string& TBSW0128::get_COD_TERM() const
	{
		return m_COD_TERM;
	}
	const std::string& TBSW0128::get_NUM_CAR() const
	{
		return m_NUM_CAR;
	}
	const std::string& TBSW0128::get_COD_MOT_RSPS_DEST() const
	{
		return m_COD_MOT_RSPS_DEST;
	}
	const dbm_datetime_t TBSW0128::get_DTH_INI_TRAN() const
	{
		return m_DTH_INI_TRAN;
	}

} //namespace dbaccess_common

