#include "TBSW0093.hpp"

namespace dbaccess_common
{
TBSW0093::TBSW0093()
{

	initialize();

	where_condition = "";
    m_log = logger::DebugWriter::getInstance();

    update_database_id(dbaccess::endpoint::DB_CAPTURA);
}

TBSW0093::TBSW0093( const std::string& whereClause )
{

	initialize();

	where_condition = whereClause;

    update_database_id(dbaccess::endpoint::DB_CAPTURA);
}

TBSW0093::~TBSW0093()
{
}

void TBSW0093::initialize()
{
	query_fields = "COD_MOT_RSPS_EXT, COD_OPER_CNFR, COD_OPER_ESTR, COD_ITEM, TIP_MODO_TRAN, TIP_MSG, TIP_VD_SAID, NUM_OPER_ETD, NUM_RD_DEST, COD_MOT_ESTR_DEST, COD_MOT_RSPS_DEST, DAT_MOV_TRAN, NUM_SEQ_UNC";

	table_name = "TBSW0093";

	m_COD_MOT_RSPS_EXT_pos = 1;
	m_COD_OPER_CNFR_pos = 2;
	m_COD_OPER_ESTR_pos = 3;
	m_COD_ITEM_pos = 4;
	m_TIP_MODO_TRAN_pos = 5;
	m_TIP_MSG_pos = 6;
	m_TIP_VD_SAID_pos = 7;
	m_NUM_OPER_ETD_pos = 8;
	m_NUM_RD_DEST_pos = 9;
	m_COD_MOT_ESTR_DEST_pos = 10;
	m_COD_MOT_RSPS_DEST_pos = 11; 
	m_DAT_MOV_TRAN_pos = 12;
	m_NUM_SEQ_UNC_pos = 13;
    
	m_DAT_MOV_TRAN = 0;
	dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
	m_COD_OPER_ESTR = " ";
	m_COD_ITEM = " ";
	m_TIP_MODO_TRAN = " ";
	m_TIP_MSG = " ";
	m_TIP_VD_SAID = " ";
	dbm_longtodec( &m_NUM_OPER_ETD, 0 );
	m_NUM_RD_DEST = 0;
	m_COD_MOT_RSPS_EXT = " ";
	m_COD_OPER_CNFR = " ";
	m_COD_MOT_ESTR_DEST = " ";
	m_COD_MOT_RSPS_DEST = " ";

}
void TBSW0093::bind_columns()
{
	bind( m_DAT_MOV_TRAN_pos,	m_DAT_MOV_TRAN );
	bind( m_NUM_SEQ_UNC_pos,	m_NUM_SEQ_UNC );
	bind( m_COD_OPER_ESTR_pos,	m_COD_OPER_ESTR );
	bind( m_COD_ITEM_pos,		m_COD_ITEM );
	bind( m_TIP_MODO_TRAN_pos,	m_TIP_MODO_TRAN );
	bind( m_TIP_MSG_pos,		m_TIP_MSG );
	bind( m_TIP_VD_SAID_pos,	m_TIP_VD_SAID );
	bind( m_NUM_OPER_ETD_pos,	m_NUM_OPER_ETD );
	bind( m_NUM_RD_DEST_pos,	m_NUM_RD_DEST );
	bind( m_COD_MOT_RSPS_EXT_pos,	m_COD_MOT_RSPS_EXT );
	bind( m_COD_OPER_CNFR_pos,	m_COD_OPER_CNFR );
	bind( m_COD_MOT_ESTR_DEST_pos,	m_COD_MOT_ESTR_DEST );
	bind( m_COD_MOT_RSPS_DEST_pos,	m_COD_MOT_RSPS_DEST );
}
void TBSW0093::set_COD_MOT_RSPS_EXT( const std::string& a_COD_MOT_RSPS_EXT )
{
	m_COD_MOT_RSPS_EXT = a_COD_MOT_RSPS_EXT;
}
void TBSW0093::set_COD_OPER_CNFR( const std::string& a_COD_OPER_CNFR )
{
	m_COD_OPER_CNFR = a_COD_OPER_CNFR;
}
void TBSW0093::set_COD_OPER_ESTR( const std::string& a_COD_OPER_ESTR )
{
	m_COD_OPER_ESTR = a_COD_OPER_ESTR;
}
void TBSW0093::set_COD_ITEM( const std::string& a_COD_ITEM )
{
	m_COD_ITEM = a_COD_ITEM;
}
void TBSW0093::set_TIP_MODO_TRAN( const std::string& a_TIP_MODO_TRAN )
{
	m_TIP_MODO_TRAN = a_TIP_MODO_TRAN;
}
void TBSW0093::set_TIP_MSG( const std::string& a_TIP_MSG )
{
	m_TIP_MSG = a_TIP_MSG;
}
void TBSW0093::set_TIP_VD_SAID( const std::string& a_TIP_VD_SAID )
{
	m_TIP_VD_SAID = a_TIP_VD_SAID;
}
void TBSW0093::set_NUM_OPER_ETD( oasis_dec_t a_NUM_OPER_ETD )
{
	dbm_deccopy( &m_NUM_OPER_ETD, &a_NUM_OPER_ETD );
}
void TBSW0093::set_NUM_RD_DEST( unsigned long a_NUM_RD_DEST )
{
	m_NUM_RD_DEST = a_NUM_RD_DEST;
}
void TBSW0093::set_COD_MOT_ESTR_DEST( const std::string& a_COD_MOT_ESTR_DEST )
{
	m_COD_MOT_ESTR_DEST = a_COD_MOT_ESTR_DEST;
}
void TBSW0093::set_COD_MOT_RSPS_DEST( const std::string& a_COD_MOT_RSPS_DEST )
{
	m_COD_MOT_RSPS_DEST = a_COD_MOT_RSPS_DEST;
}
void TBSW0093::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
{
	m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
}
void TBSW0093::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
{
	dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
}
const std::string& TBSW0093::get_COD_MOT_RSPS_EXT() const
{
	return m_COD_MOT_RSPS_EXT;
}
const std::string& TBSW0093::get_COD_OPER_CNFR() const
{
	return m_COD_OPER_CNFR;
}
const std::string& TBSW0093::get_COD_OPER_ESTR() const
{
	return m_COD_OPER_ESTR;
}
const std::string& TBSW0093::get_COD_ITEM() const
{
	return m_COD_ITEM;
}
const std::string& TBSW0093::get_TIP_MODO_TRAN() const
{
	return m_TIP_MODO_TRAN;
}
const std::string& TBSW0093::get_TIP_MSG() const
{
	return m_TIP_MSG;
}
const std::string& TBSW0093::get_TIP_VD_SAID() const
{
	return m_TIP_VD_SAID;
}
oasis_dec_t TBSW0093::get_NUM_OPER_ETD() const
{
	return m_NUM_OPER_ETD;
}
unsigned long TBSW0093::get_NUM_RD_DEST() const
{
	return m_NUM_RD_DEST;
}
const std::string& TBSW0093::get_COD_MOT_ESTR_DEST() const
{
	return m_COD_MOT_ESTR_DEST;
}
const std::string& TBSW0093::get_COD_MOT_RSPS_DEST() const
{
	return m_COD_MOT_RSPS_DEST;
}
unsigned long TBSW0093::get_DAT_MOV_TRAN() const
{
	return m_DAT_MOV_TRAN;
}
oasis_dec_t TBSW0093::get_NUM_SEQ_UNC() const
{
	return m_NUM_SEQ_UNC;
}

    // Teste de conteudo do registro
void TBSW0093::showxxx( const char *name, unsigned long campo, bool isNull )
{
    char buf[1000] = {0};
    if( isNull == true )
    {
        sprintf(buf, " - %s : [NULL]", name );
    }
    else
    {
        sprintf(buf, " - %s : [%ld]", name, campo );
    }
    m_log->write( logger::LEVEL_DEBUG, buf );
}
void TBSW0093::showxxx( const char *name, dbm_datetime_t campo, bool isNull )
{
    char buf[1000] = {0};
    if( isNull == true )
    {
        sprintf(buf, " - %s : [NULL]", name );
    }
    else
    {
        sprintf(buf, " - %s : [%ld]", name, campo );
    }
    m_log->write( logger::LEVEL_DEBUG, buf );
}
void TBSW0093::showxxx( const char *name, const std::string& campo, bool isNull )
{
    char buf[1000] = {0};
    if( isNull == true )
    {
        sprintf(buf, " - %s : [NULL]", name );
    }
    else
    {
        sprintf(buf, " - %s : [%s]", name, campo.c_str( ) );
    }
    m_log->write( logger::LEVEL_DEBUG, buf );
}
void TBSW0093::showxxx( const char *name, oasis_dec_t campo, bool isNull )
{
    char buf[1000] = {0};
    if( isNull == true )
    {
        sprintf(buf, " - %s : [NULL]", name );
    }
    else
    {
        char buf_aux[1000] = {0};
        dbm_dectochar( &campo, buf_aux);
        sprintf(buf, " - %s : [%s]", name, buf_aux );
    }
    m_log->write( logger::LEVEL_DEBUG, buf );
}
void TBSW0093::showxxx( const char *name, sw_date_t campo, bool isNull )
{
    char buf[1000] = {0};
    if( isNull == true )
    {
        sprintf(buf, " - %s : [NULL]", name );
    }
    else
    {
        sprintf(buf, " - %s : [%ld]", name, campo.date );
    }
    m_log->write( logger::LEVEL_DEBUG, buf );
}
    
    void TBSW0093::show(int nvl)
    {
        char buf[1000];
        sprintf( buf, " --[%s]----------------------------", table_name.c_str() );
        m_log->write( logger::LEVEL_DEBUG, buf );

        //NOT NULL CAMPOS
        showxxx( "COD_MOT_RSPS_EXT" , m_COD_MOT_RSPS_EXT , false);
        showxxx( "COD_OPER_CNFR"    , m_COD_OPER_CNFR    , false);
        showxxx( "COD_OPER_ESTR"    , m_COD_OPER_ESTR    , false);
        showxxx( "COD_ITEM"         , m_COD_ITEM         , false);
        showxxx( "TIP_MODO_TRAN"    , m_TIP_MODO_TRAN    , false);
        showxxx( "TIP_MSG"          , m_TIP_MSG          , false);
        showxxx( "TIP_VD_SAID"      , m_TIP_VD_SAID      , false);
        showxxx( "NUM_OPER_ETD"     , m_NUM_OPER_ETD     , false);
        showxxx( "NUM_RD_DEST"      , m_NUM_RD_DEST      , false);
        showxxx( "COD_MOT_ESTR_DEST", m_COD_MOT_ESTR_DEST, false);
        showxxx( "COD_MOT_RSPS_DEST", m_COD_MOT_RSPS_DEST, false);
        showxxx( "DAT_MOV_TRAN"     , m_DAT_MOV_TRAN     , false);
        showxxx( "NUM_SEQ_UNC"      , m_NUM_SEQ_UNC      , false);

        sprintf( buf, " ------------------------------------------", table_name.c_str() );
        m_log->write( logger::LEVEL_DEBUG, buf );

    }

} //namespace dbaccess_common

