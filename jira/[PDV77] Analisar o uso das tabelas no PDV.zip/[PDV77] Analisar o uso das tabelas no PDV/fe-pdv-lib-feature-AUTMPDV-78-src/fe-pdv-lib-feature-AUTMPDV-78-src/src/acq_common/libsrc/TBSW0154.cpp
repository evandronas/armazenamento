#include "TBSW0154.hpp"

namespace dbaccess_common
{
	TBSW0154::TBSW0154()
	{

		query_fields = "NUM_PDV, DAT_REF, COD_TRAN_PRCL, DAT_PCM, COD_STTU_RSMO_VD, COD_BNDR, NOM_BNDR, QTD_VD_CRE, VAL_TOTL_VD_CRE, QTD_TOTL_VD_PARC, VAL_TOTL_VD_PARC, QTD_CASH_RTTV, VAL_TOTL_CASH_RTTV, QTD_CASH_PARC, VAL_TOTL_CASH_PARC, COD_TERM, DAT_SLC";

		table_name = "TBSW0154";

		m_NUM_PDV_pos = 1;
		m_DAT_REF_pos = 2;
		m_COD_TRAN_PRCL_pos = 3;
		m_DAT_PCM_pos = 4;
		m_COD_STTU_RSMO_VD_pos = 5;
		m_COD_BNDR_pos = 6;
		m_NOM_BNDR_pos = 7;
		m_QTD_VD_CRE_pos = 8;
		m_VAL_TOTL_VD_CRE_pos = 9;
		m_QTD_TOTL_VD_PARC_pos = 10;
		m_VAL_TOTL_VD_PARC_pos = 11;
		m_QTD_CASH_RTTV_pos = 12;
		m_VAL_TOTL_CASH_RTTV_pos = 13;
		m_QTD_CASH_PARC_pos = 14;
		m_VAL_TOTL_CASH_PARC_pos = 15;
		m_COD_TERM_pos = 16;
		m_DAT_SLC_pos = 17;

        m_NUM_PDV = 0;
        m_DAT_REF = 0;
        m_COD_TRAN_PRCL = 0;
        m_DAT_PCM = 0;
        m_COD_STTU_RSMO_VD = 0;
        m_COD_BNDR = 0;
        m_NOM_BNDR = " ";
        dbm_longtodec( &m_QTD_VD_CRE, 0 );
        dbm_chartodec( &m_VAL_TOTL_VD_CRE, "0.00", 2 );
        dbm_longtodec( &m_QTD_TOTL_VD_PARC, 0 );
        dbm_chartodec( &m_VAL_TOTL_VD_PARC, "0.00", 2 );
        dbm_longtodec( &m_QTD_CASH_RTTV, 0 );
        dbm_chartodec( &m_VAL_TOTL_CASH_RTTV, "0.00", 2 );
        dbm_longtodec( &m_QTD_CASH_PARC, 0 );
        dbm_chartodec( &m_VAL_TOTL_CASH_PARC, "0.00", 2 );

        m_DAT_SLC_ind_null = DBM_NULL_DATA;
    
		where_condition = "";

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0154::TBSW0154( const std::string& whereClause )
	{

		query_fields = "NUM_PDV, DAT_REF, COD_TRAN_PRCL, DAT_PCM, COD_STTU_RSMO_VD, COD_BNDR, NOM_BNDR, QTD_VD_CRE, VAL_TOTL_VD_CRE, QTD_TOTL_VD_PARC, VAL_TOTL_VD_PARC, QTD_CASH_RTTV, VAL_TOTL_CASH_RTTV, QTD_CASH_PARC, VAL_TOTL_CASH_PARC, COD_TERM, DAT_SLC";

		table_name = "TBSW0154";

		m_NUM_PDV_pos = 1;
		m_DAT_REF_pos = 2;
		m_COD_TRAN_PRCL_pos = 3;
		m_DAT_PCM_pos = 4;
		m_COD_STTU_RSMO_VD_pos = 5;
		m_COD_BNDR_pos = 6;
		m_NOM_BNDR_pos = 7;
		m_QTD_VD_CRE_pos = 8;
		m_VAL_TOTL_VD_CRE_pos = 9;
		m_QTD_TOTL_VD_PARC_pos = 10;
		m_VAL_TOTL_VD_PARC_pos = 11;
		m_QTD_CASH_RTTV_pos = 12;
		m_VAL_TOTL_CASH_RTTV_pos = 13;
		m_QTD_CASH_PARC_pos = 14;
		m_VAL_TOTL_CASH_PARC_pos = 15;
		m_COD_TERM_pos = 16;
		m_DAT_SLC_pos = 17;

        m_NUM_PDV = 0;
        m_DAT_REF = 0;
        m_COD_TRAN_PRCL = 0;
        m_DAT_PCM = 0;
        m_COD_STTU_RSMO_VD = 0;
        m_COD_BNDR = 0;
        m_NOM_BNDR = " ";
        dbm_longtodec( &m_QTD_VD_CRE, 0 );
        dbm_chartodec( &m_VAL_TOTL_VD_CRE, "0.00", 2 );
        dbm_longtodec( &m_QTD_TOTL_VD_PARC, 0 );
        dbm_chartodec( &m_VAL_TOTL_VD_PARC, "0.00", 2 );
        dbm_longtodec( &m_QTD_CASH_RTTV, 0 );
        dbm_chartodec( &m_VAL_TOTL_CASH_RTTV, "0.00", 2 );
        dbm_longtodec( &m_QTD_CASH_PARC, 0 );
        dbm_chartodec( &m_VAL_TOTL_CASH_PARC, "0.00", 2 );

        m_DAT_SLC_ind_null = DBM_NULL_DATA;
        
		where_condition = whereClause;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}

	TBSW0154::~TBSW0154()
	{
	}

	void TBSW0154::bind_columns()
	{
		bind( m_NUM_PDV_pos, m_NUM_PDV );
		bind( m_DAT_REF_pos, &m_DAT_REF );
		bind( m_COD_TRAN_PRCL_pos, m_COD_TRAN_PRCL );
		bind( m_DAT_PCM_pos, m_DAT_PCM );
		bind( m_COD_STTU_RSMO_VD_pos, m_COD_STTU_RSMO_VD );
		bind( m_COD_BNDR_pos, m_COD_BNDR );
		bind( m_NOM_BNDR_pos, m_NOM_BNDR );
		bind( m_QTD_VD_CRE_pos, m_QTD_VD_CRE );
		bind( m_VAL_TOTL_VD_CRE_pos, m_VAL_TOTL_VD_CRE );
		bind( m_QTD_TOTL_VD_PARC_pos, m_QTD_TOTL_VD_PARC );
		bind( m_VAL_TOTL_VD_PARC_pos, m_VAL_TOTL_VD_PARC );
		bind( m_QTD_CASH_RTTV_pos, m_QTD_CASH_RTTV );
		bind( m_VAL_TOTL_CASH_RTTV_pos, m_VAL_TOTL_CASH_RTTV );
		bind( m_QTD_CASH_PARC_pos, m_QTD_CASH_PARC );
		bind( m_VAL_TOTL_CASH_PARC_pos, m_VAL_TOTL_CASH_PARC );
		bind( m_COD_TERM_pos, m_COD_TERM );
		bind( m_DAT_SLC_pos, &m_DAT_SLC, &m_DAT_SLC_ind_null );
	}
	void TBSW0154::set_NUM_PDV( unsigned long a_NUM_PDV )
	{
		m_NUM_PDV = a_NUM_PDV;
	}
	void TBSW0154::set_DAT_REF( dbm_datetime_t a_DAT_REF )
	{
		m_DAT_REF = a_DAT_REF;
	}
	void TBSW0154::set_COD_TRAN_PRCL( unsigned long a_COD_TRAN_PRCL )
	{
		m_COD_TRAN_PRCL = a_COD_TRAN_PRCL;
	}
	void TBSW0154::set_DAT_PCM( unsigned long a_DAT_PCM )
	{
		m_DAT_PCM = a_DAT_PCM;
	}
	void TBSW0154::set_COD_STTU_RSMO_VD( unsigned long a_COD_STTU_RSMO_VD )
	{
		m_COD_STTU_RSMO_VD = a_COD_STTU_RSMO_VD;
	}
	void TBSW0154::set_COD_BNDR( unsigned long a_COD_BNDR )
	{
		m_COD_BNDR = a_COD_BNDR;
	}
	void TBSW0154::set_NOM_BNDR( const std::string& a_NOM_BNDR )
	{
		m_NOM_BNDR = a_NOM_BNDR;
	}
	void TBSW0154::set_QTD_VD_CRE( oasis_dec_t a_QTD_VD_CRE )
	{
		dbm_deccopy( &m_QTD_VD_CRE, &a_QTD_VD_CRE );
	}
	void TBSW0154::set_VAL_TOTL_VD_CRE( oasis_dec_t a_VAL_TOTL_VD_CRE )
	{
		dbm_deccopy( &m_VAL_TOTL_VD_CRE, &a_VAL_TOTL_VD_CRE );
	}
	void TBSW0154::set_QTD_TOTL_VD_PARC( oasis_dec_t a_QTD_TOTL_VD_PARC )
	{
		dbm_deccopy( &m_QTD_TOTL_VD_PARC, &a_QTD_TOTL_VD_PARC );
	}
	void TBSW0154::set_VAL_TOTL_VD_PARC( oasis_dec_t a_VAL_TOTL_VD_PARC )
	{
		dbm_deccopy( &m_VAL_TOTL_VD_PARC, &a_VAL_TOTL_VD_PARC );
	}
	void TBSW0154::set_QTD_CASH_RTTV( oasis_dec_t a_QTD_CASH_RTTV )
	{
		dbm_deccopy( &m_QTD_CASH_RTTV, &a_QTD_CASH_RTTV );
	}
	void TBSW0154::set_VAL_TOTL_CASH_RTTV( oasis_dec_t a_VAL_TOTL_CASH_RTTV )
	{
		dbm_deccopy( &m_VAL_TOTL_CASH_RTTV, &a_VAL_TOTL_CASH_RTTV );
	}
	void TBSW0154::set_QTD_CASH_PARC( oasis_dec_t a_QTD_CASH_PARC )
	{
		dbm_deccopy( &m_QTD_CASH_PARC, &a_QTD_CASH_PARC );
	}
	void TBSW0154::set_VAL_TOTL_CASH_PARC( oasis_dec_t a_VAL_TOTL_CASH_PARC )
	{
		dbm_deccopy( &m_VAL_TOTL_CASH_PARC, &a_VAL_TOTL_CASH_PARC );
	}
	void TBSW0154::set_COD_TERM( const std::string& a_COD_TERM )
	{
		m_COD_TERM = a_COD_TERM;
	}
	void TBSW0154::set_DAT_SLC( dbm_datetime_t a_DAT_SLC )
	{
		m_DAT_SLC = a_DAT_SLC;
        m_DAT_SLC_ind_null = 0;
	}
	unsigned long TBSW0154::get_NUM_PDV() const
	{
		return m_NUM_PDV;
	}
	dbm_datetime_t TBSW0154::get_DAT_REF() const
	{
		return m_DAT_REF;
	}
	unsigned long TBSW0154::get_COD_TRAN_PRCL() const
	{
		return m_COD_TRAN_PRCL;
	}
	unsigned long TBSW0154::get_DAT_PCM() const
	{
		return m_DAT_PCM;
	}
	unsigned long TBSW0154::get_COD_STTU_RSMO_VD() const
	{
		return m_COD_STTU_RSMO_VD;
	}
	unsigned long TBSW0154::get_COD_BNDR() const
	{
		return m_COD_BNDR;
	}
	const std::string& TBSW0154::get_NOM_BNDR() const
	{
		return m_NOM_BNDR;
	}
	oasis_dec_t TBSW0154::get_QTD_VD_CRE() const
	{
		return m_QTD_VD_CRE;
	}
	oasis_dec_t TBSW0154::get_VAL_TOTL_VD_CRE() const
	{
		return m_VAL_TOTL_VD_CRE;
	}
	oasis_dec_t TBSW0154::get_QTD_TOTL_VD_PARC() const
	{
		return m_QTD_TOTL_VD_PARC;
	}
	oasis_dec_t TBSW0154::get_VAL_TOTL_VD_PARC() const
	{
		return m_VAL_TOTL_VD_PARC;
	}
	oasis_dec_t TBSW0154::get_QTD_CASH_RTTV() const
	{
		return m_QTD_CASH_RTTV;
	}
	oasis_dec_t TBSW0154::get_VAL_TOTL_CASH_RTTV() const
	{
		return m_VAL_TOTL_CASH_RTTV;
	}
	oasis_dec_t TBSW0154::get_QTD_CASH_PARC() const
	{
		return m_QTD_CASH_PARC;
	}
	oasis_dec_t TBSW0154::get_VAL_TOTL_CASH_PARC() const
	{
		return m_VAL_TOTL_CASH_PARC;
	}
	const std::string& TBSW0154::get_COD_TERM() const
	{
		return m_COD_TERM;
	}
	dbm_datetime_t TBSW0154::get_DAT_SLC() const
	{
		return m_DAT_SLC;
	}

    void TBSW0154::let_as_is( )
    {
        m_DAT_SLC_ind_null = is_null(m_DAT_SLC) ? DBM_NULL_DATA : 0;
    }
} //namespace dbaccess_common
