#include <cstring>
#include<TBSW0083RegrasFormatacaoBase.hpp>
#include<AcqUtils.hpp>

TBSW0083RegrasFormatacaoBase::TBSW0083RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0083RegrasFormatacaoBase::~TBSW0083RegrasFormatacaoBase( )
{
}

void TBSW0083RegrasFormatacaoBase::COD_CEP_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CEP_PORT( tbsw0083, tbsw0083_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CEP_PORT( tbsw0083, tbsw0083_params );
    }
}

void TBSW0083RegrasFormatacaoBase::COD_CEP_CMPM_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CEP_CMPM_PORT( tbsw0083, tbsw0083_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CEP_CMPM_PORT( tbsw0083, tbsw0083_params );
    }
}

void TBSW0083RegrasFormatacaoBase::TXT_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_ENDR_PORT( tbsw0083, tbsw0083_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_ENDR_PORT( tbsw0083, tbsw0083_params );
    }
}

void TBSW0083RegrasFormatacaoBase::NUM_CPF_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_CPF_PORT( tbsw0083, tbsw0083_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_CPF_PORT( tbsw0083, tbsw0083_params );
    }
}

void TBSW0083RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0083, tbsw0083_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0083, tbsw0083_params );
    }
}

void TBSW0083RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0083, tbsw0083_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0083, tbsw0083_params );
    }
}

void TBSW0083RegrasFormatacaoBase::COD_RSPS_AVS( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_RSPS_AVS( tbsw0083, tbsw0083_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_RSPS_AVS( tbsw0083, tbsw0083_params );
    }
}

void TBSW0083RegrasFormatacaoBase::TXT_CMPM_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_CMPM_ENDR_PORT( tbsw0083, tbsw0083_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_CMPM_ENDR_PORT( tbsw0083, tbsw0083_params );
    }
}

void TBSW0083RegrasFormatacaoBase::gen_COD_CEP_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::gen_COD_CEP_CMPM_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::gen_TXT_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::gen_NUM_CPF_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::gen_COD_RSPS_AVS( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::gen_TXT_CMPM_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::insert_COD_CEP_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    if ( strlen( tbsw0083_params.avs_cep.c_str( ) ) > 3 )
    {
        std::string l_cep5 = tbsw0083_params.avs_cep.substr( 0, strlen( tbsw0083_params.avs_cep.c_str( ) ) - 3 );
        if ( strlen( l_cep5.c_str( ) ) <= 5 )                
        {
            std::string l_pad( 5 - strlen( l_cep5.c_str( ) ), '0' );
            tbsw0083.set_COD_CEP_PORT( l_pad + l_cep5 );
        }
    }
}

void TBSW0083RegrasFormatacaoBase::insert_COD_CEP_CMPM_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    if ( strlen( tbsw0083_params.avs_cep.c_str( ) ) > 3 )
    {
        std::string l_cep5 = tbsw0083_params.avs_cep.substr( 0, strlen( tbsw0083_params.avs_cep.c_str( ) ) - 3 );
        if ( strlen(l_cep5.c_str()) <= 5 )                
        {
            tbsw0083.set_COD_CEP_CMPM_PORT( tbsw0083_params.avs_cep.substr( strlen( tbsw0083_params.avs_cep.c_str( ) ) - 3, 3 ) );
        }
    }
}

void TBSW0083RegrasFormatacaoBase::insert_TXT_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    std::string l_aux = tbsw0083_params.avs_end_fat + tbsw0083_params.avs_end_num + tbsw0083_params.avs_end_com;
    std::string l_digits_only;
    for ( int i=0, ilen=strlen(l_aux.c_str()); i<ilen; i++ )
    {
        if ( isdigit( l_aux[i] ) )
        {
            l_digits_only += l_aux[i];
        }
    }
    if ( strlen(l_digits_only.c_str()) > 8 ) 
    {
        l_digits_only = l_digits_only.substr(0, 8);
    }              

    if ( strlen(l_digits_only.c_str( )) ) 
    {
        tbsw0083.set_TXT_ENDR_PORT( l_digits_only );
    }
}

void TBSW0083RegrasFormatacaoBase::insert_NUM_CPF_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    if( strlen( tbsw0083_params.avs_cpf.c_str( ) ) ) 
    {
        tbsw0083.set_NUM_CPF_PORT( tbsw0083_params.avs_cpf );
    }
}

void TBSW0083RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    tbsw0083.set_DAT_MOV_TRAN( tbsw0083_params.local_date );
}

void TBSW0083RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    oasis_dec_t aux;
    dbm_chartodec( &aux, tbsw0083_params.refnum.c_str( ), 0 );
    tbsw0083.set_NUM_SEQ_UNC( aux );
}

void TBSW0083RegrasFormatacaoBase::insert_COD_RSPS_AVS( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::insert_TXT_CMPM_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    std::string l_txt_cmpm_endr_port;
    unsigned long l_txt_cmpm_endr_port_len=0;

    l_txt_cmpm_endr_port = tbsw0083_params.avs_end_fat + " " + tbsw0083_params.avs_end_num + " " + tbsw0083_params.avs_end_com;
    l_txt_cmpm_endr_port_len = strlen(l_txt_cmpm_endr_port.c_str());

    if ( l_txt_cmpm_endr_port_len > 70 ) 
    {
        l_txt_cmpm_endr_port_len = 70;
    }

    l_txt_cmpm_endr_port = l_txt_cmpm_endr_port.substr( 0, l_txt_cmpm_endr_port_len );
    tbsw0083.set_TXT_CMPM_ENDR_PORT( l_txt_cmpm_endr_port );
}

void TBSW0083RegrasFormatacaoBase::update_COD_CEP_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::update_COD_CEP_CMPM_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::update_TXT_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::update_NUM_CPF_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0083RegrasFormatacaoBase::update_COD_RSPS_AVS( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    tbsw0083.set_COD_RSPS_AVS( tbsw0083_params.avs_respcode );
}

void TBSW0083RegrasFormatacaoBase::update_TXT_CMPM_ENDR_PORT( dbaccess_common::TBSW0083 &tbsw0083, const struct acq_common::tbsw0083_params &tbsw0083_params )
{
    WARNING_INVALID_FUNCTION;
}
