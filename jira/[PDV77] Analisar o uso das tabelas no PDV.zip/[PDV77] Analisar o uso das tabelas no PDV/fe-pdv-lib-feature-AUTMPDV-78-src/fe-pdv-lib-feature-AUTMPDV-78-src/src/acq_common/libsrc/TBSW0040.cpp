/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descrio:
/ Contedo:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Criao: 2012, 21 de julho
/ Histrico Mudanas: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ 2020, 07 de Outubro, Andre, J10_2020 - Release Bandeiras
/ -------------------------------------------------------------------------------------------------
/ 2021-02-01 Breder - AUT1-2821 - PIX CNPJ Owner +Refactory
*/
#pragma once
#include "TBSW0040.hpp"

using namespace std; // J10_2020 - Release Bandeiras

namespace dbaccess_common
{
    TBSW0040::TBSW0040( )
    {
        setProperties( "" );

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW0040::TBSW0040( const std::string &str )
    {
        setProperties( str );

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW0040::~TBSW0040( )
    {
    }
    void TBSW0040::setProperties( const std::string &str )
    {
        table_name = "TBSW0040";
        where_condition = str;
        query_fields = "";

        int pos = 0;
        m_NUM_PDV_pos               = ++pos; query_fields += "NUM_PDV, ";               /* NUMBER(9)    */ m_NUM_PDV                = 0;
        m_COD_TIP_ESTB_PDV_pos      = ++pos; query_fields += "COD_TIP_ESTB_PDV, ";      /* NUMBER(5)    */ m_COD_TIP_ESTB_PDV       = 0;
        m_COD_CTGR_pos              = ++pos; query_fields += "COD_CTGR, ";              /* CHAR(1)      */ m_COD_CTGR               = "";
        m_NOM_RZAO_SCLA_ESTB_pos    = ++pos; query_fields += "NOM_RZAO_SCLA_ESTB, ";    /* VARCHAR2(27) */ m_NOM_RZAO_SCLA_ESTB     = "";
        m_NOM_FAT_PDV_pos           = ++pos; query_fields += "NOM_FAT_PDV, ";           /* VARCHAR2(23) */ m_NOM_FAT_PDV            = "";
        m_COD_CEP_PDV_pos           = ++pos; query_fields += "COD_CEP_PDV, ";           /* CHAR(5)      */ m_COD_CEP_PDV            = "";
        m_COD_CEP_CPL_PDV_pos       = ++pos; query_fields += "COD_CEP_CPL_PDV, ";       /* CHAR(3)      */ m_COD_CEP_CPL_PDV        = "";
        m_NOM_CID_PDV_pos           = ++pos; query_fields += "NOM_CID_PDV, ";           /* VARCHAR2(25) */ m_NOM_CID_PDV            = "";
        m_NOM_ESTB_PDV_pos          = ++pos; query_fields += "NOM_ESTB_PDV, ";          /* CHAR(2)      */ m_NOM_ESTB_PDV           = "";
        m_COD_PAIS_pos              = ++pos; query_fields += "COD_PAIS, ";              /* CHAR(3)      */ m_COD_PAIS               = "";
        m_COD_RAM_ATVD_pos          = ++pos; query_fields += "COD_RAM_ATVD, ";          /* NUMBER(5)    */ m_COD_RAM_ATVD           = 0;
        m_COD_RAM_ATVD_MTC_pos      = ++pos; query_fields += "COD_RAM_ATVD_MTC, ";      /* NUMBER(5)    */ m_COD_RAM_ATVD_MTC       = 0;
        m_COD_CTGR_TRAN_MTC_pos     = ++pos; query_fields += "COD_CTGR_TRAN_MTC, ";     /* CHAR(1)      */ m_COD_CTGR_TRAN_MTC      = "";
        m_COD_RAM_ATVD_MTC_DNRS_pos = ++pos; query_fields += "COD_RAM_ATVD_MTC_DNRS, "; /* NUMBER(5)    */ m_COD_RAM_ATVD_MTC_DNRS  = 0;
        m_COD_MTZ_ESTB_pos          = ++pos; query_fields += "COD_MTZ_ESTB, ";          /* NUMBER(9)    */ m_COD_MTZ_ESTB           = 0;
        m_COD_GRU_ESTB_pos          = ++pos; query_fields += "COD_GRU_ESTB, ";          /* NUMBER(9)    */ m_COD_GRU_ESTB           = 0;
        m_NUM_CNPJ_pos              = ++pos; query_fields += "NUM_CNPJ, ";              /* NUMBER(14)   */ dbm_inttodec( &m_NUM_CNPJ, 0 );
        m_COD_STTU_REG_pos          = ++pos; query_fields += "COD_STTU_REG, ";          /* CHAR(1)      */ m_COD_STTU_REG           = "";
        m_DAT_ATLZ_REG_pos          = ++pos; query_fields += "DAT_ATLZ_REG, ";          /* DATE         */ m_DAT_ATLZ_REG           = 0;
        m_COD_ID_DSTR_pos           = ++pos; query_fields += "COD_ID_DSTR, ";           /* NUMBER(5)    */ m_COD_ID_DSTR            = 0;
        m_IND_PDV_CART_DGTL_pos     = ++pos; query_fields += "IND_PDV_CART_DGTL, ";     /* CHAR(1)      */ m_IND_PDV_CART_DGTL      = "";
        m_COD_TIP_PES_pos           = ++pos; query_fields += "COD_TIP_PES, ";           /* CHAR(1)      */ m_COD_TIP_PES            = "";
        m_COD_GRU_CLAS_RAM_pos      = ++pos; query_fields += "COD_GRU_CLAS_RAM, ";      /* NUMBER(2)    */ m_COD_GRU_CLAS_RAM       = 0;
        m_COD_TIP_FACR_pos          = ++pos; query_fields += "COD_TIP_FACR, ";          /* NUMBER(5)    */ m_COD_TIP_FACR           = 0;
        m_COD_MVV_pos               = ++pos; query_fields += "COD_MVV, ";               /* CHAR(10)     */ m_COD_MVV                = "";
        m_COD_PRCR_PSP_pos          = ++pos; query_fields += "COD_PRCR_PSP, ";          /* NUMBER(38)   */ m_COD_PRCR_PSP           = 0;
        m_COD_TIP_CHAV_PIX_pos      = ++pos; query_fields += "COD_TIP_CHAV_PIX, ";      /* NUMBER(38)   */ m_COD_TIP_CHAV_PIX       = 0;
        m_COD_CHAV_PIX_pos          = ++pos; query_fields += "COD_CHAV_PIX, ";          /* VARCHAR2(60) */ m_COD_CHAV_PIX           = "";
        m_NUM_CNPJ_PIX_OWN_CHAV_pos = ++pos; query_fields += "NUM_CNPJ_PIX_OWN_CHAV, "; /* NUMBER(14)   */ dbm_inttodec( &m_NUM_CNPJ_PIX_OWN_CHAV, 0 );
        m_NOM_LOGR_PDV_pos          = ++pos; query_fields += "NOM_LOGR_PDV, ";          /* VARCHAR2(60) */ m_NOM_LOGR_PDV           = "";
        m_NUM_LOGR_PDV_pos          = ++pos; query_fields += "NUM_LOGR_PDV, ";          /* CHAR(6)      */ m_NUM_LOGR_PDV           = "";
        m_NOM_BRR_PDV_pos           = ++pos; query_fields += "NOM_BRR_PDV, ";           /* VARCHAR2(20) */ m_NOM_BRR_PDV            = "";
        m_DES_CPL_ENDR_PDV_pos      = ++pos; query_fields += "DES_CPL_ENDR_PDV, ";      /* VARCHAR2(60) */ m_DES_CPL_ENDR_PDV       = "";
        codigoCanalPos              = ++pos; query_fields += "COD_CNL, ";               /* NUMBER(2)    */ codigoCanal              = 0;
        codigoCelulaPos             = ++pos; query_fields += "COD_CEL";                 /* NUMBER(3)    */ codigoCelula             = 0;

    }

    long               TBSW0040::getNUM_PDV                  ( ) const { return m_NUM_PDV;               }
    long               TBSW0040::getCOD_TIP_ESTB_PDV         ( ) const { return m_COD_TIP_ESTB_PDV;      }
    const std::string& TBSW0040::getCOD_CTGR                 ( ) const { return m_COD_CTGR;              }
    const std::string& TBSW0040::getNOM_RZAO_SCLA_ESTB       ( ) const { return m_NOM_RZAO_SCLA_ESTB;    }
    const std::string& TBSW0040::getNOM_FAT_PDV              ( ) const { return m_NOM_FAT_PDV;           }
    const std::string& TBSW0040::getCOD_CEP_PDV              ( ) const { return m_COD_CEP_PDV;           }
    const std::string& TBSW0040::getCOD_CEP_CPL_PDV          ( ) const { return m_COD_CEP_CPL_PDV;       }
    const std::string& TBSW0040::getNOM_CID_PDV              ( ) const { return m_NOM_CID_PDV;           }
    const std::string& TBSW0040::getNOM_ESTB_PDV             ( ) const { return m_NOM_ESTB_PDV;          }
    const std::string& TBSW0040::getCOD_PAIS                 ( ) const { return m_COD_PAIS;              }
    long               TBSW0040::getCOD_RAM_ATVD             ( ) const { return m_COD_RAM_ATVD;          }
    long               TBSW0040::getCOD_RAM_ATVD_MTC         ( ) const { return m_COD_RAM_ATVD_MTC;      }
    const std::string& TBSW0040::getCOD_CTGR_TRAN_MTC        ( ) const { return m_COD_CTGR_TRAN_MTC;     }
    long               TBSW0040::getCOD_RAM_ATVD_MTC_DNRS    ( ) const { return m_COD_RAM_ATVD_MTC_DNRS; }
    long               TBSW0040::getCOD_MTZ_ESTB             ( ) const { return m_COD_MTZ_ESTB;          }
    long               TBSW0040::getCOD_GRU_ESTB             ( ) const { return m_COD_GRU_ESTB;          }
    oasis_dec_t        TBSW0040::getNUM_CNPJ                 ( ) const { return m_NUM_CNPJ;              }
    const std::string& TBSW0040::getCOD_STTU_REG             ( ) const { return m_COD_STTU_REG;          }
    dbm_datetime_t     TBSW0040::getDAT_ATLZ_REG             ( ) const { return m_DAT_ATLZ_REG;          }
    long               TBSW0040::getCOD_ID_DSTR              ( ) const { return m_COD_ID_DSTR;           }
    const std::string& TBSW0040::getIND_PDV_CART_DGTL        ( ) const { return m_IND_PDV_CART_DGTL;     }
    const std::string& TBSW0040::getCOD_TIP_PES              ( ) const { return m_COD_TIP_PES;           }
    long               TBSW0040::getCOD_GRU_CLAS_RAM         ( ) const { return m_COD_GRU_CLAS_RAM;      }
    long               TBSW0040::getCOD_TIP_FACR             ( ) const { return m_COD_TIP_FACR;          }
    const std::string& TBSW0040::getCOD_MVV                  ( ) const { return m_COD_MVV;               } // J10_2020 - Release Outubro
    long               TBSW0040::getCOD_PRCR_PSP             ( ) const { return m_COD_PRCR_PSP;          } // AUT1-2121 - Codigo do Parceiro PSP - PIX
    long               TBSW0040::getCOD_TIP_CHAV_PIX         ( ) const { return m_COD_TIP_CHAV_PIX;      } // AUT1-2121 - Codigo da Chave PIX
    const std::string& TBSW0040::getCOD_CHAV_PIX             ( ) const { return m_COD_CHAV_PIX;          } // AUT1-2320 - Codigo do tipo da Chave PIX
    oasis_dec_t        TBSW0040::getNUM_CNPJ_PIX_OWN_CHAV    ( ) const { return m_NUM_CNPJ_PIX_OWN_CHAV; } // AUT1-2821 - PIX CNPJ Owner
    const std::string& TBSW0040::getNOM_LOGR_PDV             ( ) const { return m_NOM_LOGR_PDV;          } // AUT1-1830 - ELO endereco EC no CV
    const std::string& TBSW0040::getNUM_LOGR_PDV             ( ) const { return m_NUM_LOGR_PDV;          } // AUT1-1830 - ELO endereco EC no CV
    const std::string& TBSW0040::getNOM_BRR_PDV              ( ) const { return m_NOM_BRR_PDV;           } // AUT1-1830 - ELO endereco EC no CV
    const std::string& TBSW0040::getDES_CPL_ENDR_PDV         ( ) const { return m_DES_CPL_ENDR_PDV;      } // AUT1-1830 - ELO endereco EC no CV
    int                TBSW0040::GetCanal                    ( ) const { return codigoCanal;             }
    int                TBSW0040::GetCelula                   ( ) const { return codigoCelula;            }

    void TBSW0040::setNUM_PDV               ( long                 a_NUM_PDV               ) { m_NUM_PDV               = a_NUM_PDV;                                 }
    void TBSW0040::setCOD_TIP_ESTB_PDV      ( long                 a_COD_TIP_ESTB_PDV      ) { m_COD_TIP_ESTB_PDV      = a_COD_TIP_ESTB_PDV;                        }
    void TBSW0040::setCOD_CTGR              ( const std::string&   a_COD_CTGR              ) { m_COD_CTGR              = a_COD_CTGR;                                }
    void TBSW0040::setNOM_RZAO_SCLA_ESTB    ( const std::string&   a_NOM_RZAO_SCLA_ESTB    ) { m_NOM_RZAO_SCLA_ESTB    = a_NOM_RZAO_SCLA_ESTB;                      }
    void TBSW0040::setNOM_FAT_PDV           ( const std::string&   a_NOM_FAT_PDV           ) { m_NOM_FAT_PDV           = a_NOM_FAT_PDV;                             }
    void TBSW0040::setCOD_CEP_PDV           ( const std::string&   a_COD_CEP_PDV           ) { m_COD_CEP_PDV           = a_COD_CEP_PDV;                             }
    void TBSW0040::setCOD_CEP_CPL_PDV       ( const std::string&   a_COD_CEP_CPL_PDV       ) { m_COD_CEP_CPL_PDV       = a_COD_CEP_CPL_PDV;                         }
    void TBSW0040::setNOM_CID_PDV           ( const std::string&   a_NOM_CID_PDV           ) { m_NOM_CID_PDV           = a_NOM_CID_PDV;                             }
    void TBSW0040::setNOM_ESTB_PDV          ( const std::string&   a_NOM_ESTB_PDV          ) { m_NOM_ESTB_PDV          = a_NOM_ESTB_PDV;                            }
    void TBSW0040::setCOD_PAIS              ( const std::string&   a_COD_PAIS              ) { m_COD_PAIS              = a_COD_PAIS;                                }
    void TBSW0040::setCOD_RAM_ATVD          ( long                 a_COD_RAM_ATVD          ) { m_COD_RAM_ATVD          = a_COD_RAM_ATVD;                            }
    void TBSW0040::setCOD_RAM_ATVD_MTC      ( long                 a_COD_RAM_ATVD_MTC      ) { m_COD_RAM_ATVD_MTC      = a_COD_RAM_ATVD_MTC;                        }
    void TBSW0040::setCOD_CTGR_TRAN_MTC     ( const std::string&   a_COD_CTGR_TRAN_MTC     ) { m_COD_CTGR_TRAN_MTC     = a_COD_CTGR_TRAN_MTC;                       }
    void TBSW0040::setCOD_RAM_ATVD_MTC_DNRS ( long                 a_COD_RAM_ATVD_MTC_DNRS ) { m_COD_RAM_ATVD_MTC_DNRS = a_COD_RAM_ATVD_MTC_DNRS;                   }
    void TBSW0040::setCOD_MTZ_ESTB          ( long                 a_COD_MTZ_ESTB          ) { m_COD_MTZ_ESTB          = a_COD_MTZ_ESTB;                            }
    void TBSW0040::setCOD_GRU_ESTB          ( long                 a_COD_GRU_ESTB          ) { m_COD_GRU_ESTB          = a_COD_GRU_ESTB;                            }
    void TBSW0040::setNUM_CNPJ              ( oasis_dec_t          a_NUM_CNPJ              ) { dbm_deccopy( &m_NUM_CNPJ, &a_NUM_CNPJ );                             }
    void TBSW0040::setCOD_STTU_REG          ( const std::string&   a_COD_STTU_REG          ) { m_COD_STTU_REG          = a_COD_STTU_REG;                            }
    void TBSW0040::setDAT_ATLZ_REG          ( dbm_datetime_t       a_DAT_ATLZ_REG          ) { m_DAT_ATLZ_REG          = a_DAT_ATLZ_REG;                            }
    void TBSW0040::setCOD_ID_DSTR           ( long                 a_COD_ID_DSTR           ) { m_COD_ID_DSTR           = a_COD_ID_DSTR;                             }
    void TBSW0040::setIND_PDV_CART_DGTL     ( const std::string&   a_IND_PDV_CART_DGTL     ) { m_IND_PDV_CART_DGTL     = a_IND_PDV_CART_DGTL;                       }
    void TBSW0040::setCOD_TIP_PES           ( const std::string&   a_COD_TIP_PES           ) { m_COD_TIP_PES           = a_COD_TIP_PES;                             }
    void TBSW0040::setCOD_GRU_CLAS_RAM      ( long                 a_COD_GRU_CLAS_RAM      ) { m_COD_GRU_CLAS_RAM      = a_COD_GRU_CLAS_RAM;                        }
    void TBSW0040::setCOD_TIP_FACR          ( long                 a_COD_TIP_FACR          ) { m_COD_TIP_FACR          = a_COD_TIP_FACR;                            }
    void TBSW0040::setCOD_MVV               ( const std::string&   a_COD_MVV               ) { m_COD_MVV               = a_COD_MVV;                                 } // J10_2020 - Release Outubro
    void TBSW0040::setCOD_PRCR_PSP          ( long                 a_COD_PRCR_PSP          ) { m_COD_PRCR_PSP          = a_COD_PRCR_PSP;                            } // AUT1-2121 - Codigo do Parceiro PSP - PIX
    void TBSW0040::setCOD_TIP_CHAV_PIX      ( long                 a_COD_TIP_CHAV_PIX      ) { m_COD_TIP_CHAV_PIX      = a_COD_TIP_CHAV_PIX;                        } // AUT1-2121 - Codigo da Chave PIX
    void TBSW0040::setCOD_CHAV_PIX          ( const std::string&   a_COD_CHAV_PIX          ) { m_COD_CHAV_PIX          = a_COD_CHAV_PIX;                            } // AUT1-2320 - Codigo do tipo da Chave PIX
    void TBSW0040::setNUM_CNPJ_PIX_OWN_CHAV ( oasis_dec_t          a_NUM_CNPJ_PIX_OWN_CHAV ) { dbm_deccopy( &m_NUM_CNPJ_PIX_OWN_CHAV, &a_NUM_CNPJ_PIX_OWN_CHAV );   } // AUT1-2821 - PIX CNPJ Owner
    void TBSW0040::setNOM_LOGR_PDV          ( const std::string&   a_NOM_LOGR_PDV          ) { m_NOM_LOGR_PDV          = a_NOM_LOGR_PDV;                            } // AUT1-1830 - ELO endereco EC no CV
    void TBSW0040::setNUM_LOGR_PDV          ( const std::string&   a_NUM_LOGR_PDV          ) { m_NUM_LOGR_PDV          = a_NUM_LOGR_PDV;                            } // AUT1-1830 - ELO endereco EC no CV
    void TBSW0040::setNOM_BRR_PDV           ( const std::string&   a_NOM_BRR_PDV           ) { m_NOM_BRR_PDV           = a_NOM_BRR_PDV;                             } // AUT1-1830 - ELO endereco EC no CV
    void TBSW0040::setDES_CPL_ENDR_PDV      ( const std::string&   a_DES_CPL_ENDR_PDV      ) { m_DES_CPL_ENDR_PDV      = a_DES_CPL_ENDR_PDV;                        } // AUT1-1830 - ELO endereco EC no CV
    void TBSW0040::setCanal                 ( int                  canal                   ) { codigoCanal             = canal;                                     }
    void TBSW0040::setCelula                ( int                  celula                  ) { codigoCelula            = celula;                                    }

    void TBSW0040::bind_columns( )
    {
        bind( m_NUM_PDV_pos,                m_NUM_PDV );
        bind( m_COD_TIP_ESTB_PDV_pos,       m_COD_TIP_ESTB_PDV );
        bind( m_COD_CTGR_pos,               m_COD_CTGR );
        bind( m_NOM_RZAO_SCLA_ESTB_pos,     m_NOM_RZAO_SCLA_ESTB );
        bind( m_NOM_FAT_PDV_pos,            m_NOM_FAT_PDV );
        bind( m_COD_CEP_PDV_pos,            m_COD_CEP_PDV );
        bind( m_COD_CEP_CPL_PDV_pos,        m_COD_CEP_CPL_PDV );
        bind( m_NOM_CID_PDV_pos,            m_NOM_CID_PDV );
        bind( m_NOM_ESTB_PDV_pos,           m_NOM_ESTB_PDV );
        bind( m_COD_PAIS_pos,               m_COD_PAIS );
        bind( m_COD_RAM_ATVD_pos,           m_COD_RAM_ATVD );
        bind( m_COD_RAM_ATVD_MTC_pos,       m_COD_RAM_ATVD_MTC );
        bind( m_COD_CTGR_TRAN_MTC_pos,      m_COD_CTGR_TRAN_MTC );
        bind( m_COD_RAM_ATVD_MTC_DNRS_pos,  m_COD_RAM_ATVD_MTC_DNRS );
        bind( m_COD_MTZ_ESTB_pos,           m_COD_MTZ_ESTB );
        bind( m_COD_GRU_ESTB_pos,           m_COD_GRU_ESTB );
        bind( m_NUM_CNPJ_pos,               m_NUM_CNPJ );
        bind( m_COD_STTU_REG_pos,           m_COD_STTU_REG );
        bind( m_DAT_ATLZ_REG_pos,          &m_DAT_ATLZ_REG );
        bind( m_COD_ID_DSTR_pos,            m_COD_ID_DSTR );
        bind( m_IND_PDV_CART_DGTL_pos,      m_IND_PDV_CART_DGTL );
        bind( m_COD_TIP_PES_pos,            m_COD_TIP_PES );
        bind( m_COD_GRU_CLAS_RAM_pos,       m_COD_GRU_CLAS_RAM );
        bind( m_COD_TIP_FACR_pos,           m_COD_TIP_FACR );
        bind( m_COD_MVV_pos,                m_COD_MVV );               // J10_2020 - Release Outubro
        bind( m_COD_PRCR_PSP_pos,           m_COD_PRCR_PSP );          // AUT1-2121 - Codigo do Parceiro PSP - PIX
        bind( m_COD_TIP_CHAV_PIX_pos,       m_COD_TIP_CHAV_PIX );      // AUT1-2121 - Codigo da Chave PIX
        bind( m_COD_CHAV_PIX_pos,           m_COD_CHAV_PIX );          // AUT1-2320 - Codigo do tipo da Chave PIX
        bind( m_NUM_CNPJ_PIX_OWN_CHAV_pos,  m_NUM_CNPJ_PIX_OWN_CHAV ); // AUT1-2821 - PIX CNPJ Owner
        bind( m_NOM_LOGR_PDV_pos,           m_NOM_LOGR_PDV );          // AUT1-1830 - ELO endereco EC no CV
        bind( m_NUM_LOGR_PDV_pos,           m_NUM_LOGR_PDV );          // AUT1-1830 - ELO endereco EC no CV
        bind( m_NOM_BRR_PDV_pos,            m_NOM_BRR_PDV );           // AUT1-1830 - ELO endereco EC no CV
        bind( m_DES_CPL_ENDR_PDV_pos,       m_DES_CPL_ENDR_PDV );      // AUT1-1830 - ELO endereco EC no CV
        bind( codigoCanalPos,               codigoCanal );
        bind( codigoCelulaPos,              codigoCelula );
    }
}//namespace dbaccess_common
