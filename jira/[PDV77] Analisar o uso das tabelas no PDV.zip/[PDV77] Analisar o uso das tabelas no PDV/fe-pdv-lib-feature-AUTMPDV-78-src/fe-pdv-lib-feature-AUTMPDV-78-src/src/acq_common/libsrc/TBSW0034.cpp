#include "TBSW0034.hpp"

namespace dbaccess_common
{
    TBSW0034::TBSW0034( )
    {
        initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
        m_log = logger::DebugWriter::getInstance();
    }
    TBSW0034::TBSW0034( const std::string& whereClause )
    {
        initialize();
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
        m_log = logger::DebugWriter::getInstance();
    }

    TBSW0034::~TBSW0034( )
    {
    }
    
    void TBSW0034::initialize()
    {
        query_fields = "TXT_RLCD_CHIP, TXT_INFO_CMPM_CHIP, TXT_RSTD_ATLZ_CHIP, IND_NVL_SGRA_KMRC, DAT_MOV_TRAN, NUM_SEQ_UNC, DAT_VD_CHIP, COD_PGM_AUT, IND_MTDO_VRFC_PORT, IND_PRSC_SNHA, NUM_SEQ_CAR_VLDC_CHIP, NOM_PORT_CAR";

        table_name = "TBSW0034";

        m_TXT_RLCD_CHIP_pos = 1;
        m_TXT_INFO_CMPM_CHIP_pos = 2;
        m_TXT_RSTD_ATLZ_CHIP_pos = 3;
        m_IND_NVL_SGRA_KMRC_pos = 4;
        m_DAT_MOV_TRAN_pos = 5;
        m_NUM_SEQ_UNC_pos = 6;
        m_DAT_VD_CHIP_pos = 7;
        m_COD_PGM_AUT_pos = 8;
        m_IND_MTDO_VRFC_PORT_pos = 9;
        m_IND_PRSC_SNHA_pos = 10;
        m_NUM_SEQ_CAR_VLDC_CHIP_pos = 11;
        m_NOM_PORT_CAR_pos = 12;

        m_TXT_RLCD_CHIP = " ";      // NOT NULL 
        m_TXT_INFO_CMPM_CHIP = " "; // NOT NULL 
        m_TXT_RSTD_ATLZ_CHIP = " "; // NOT NULL 
        m_IND_NVL_SGRA_KMRC = "0";  // NOT NULL 
        m_DAT_MOV_TRAN = 0;         // NOT NULL         
        m_NUM_SEQ_UNC = 0;          // NOT NULL
        m_DAT_VD_CHIP = 0;          // NOT NULL 
        m_COD_PGM_AUT = "";
        m_IND_MTDO_VRFC_PORT = "";
        m_IND_PRSC_SNHA = "";
        m_NUM_SEQ_CAR_VLDC_CHIP = 0;
        m_NOM_PORT_CAR = "";

        m_NUM_SEQ_CAR_VLDC_CHIP_ind_null = DBM_NULL_DATA;
    
    }
    void TBSW0034::setWhereClause( const std::string& whereClause )
    {
        where_condition = whereClause;
    }

    void TBSW0034::bind_columns( )
    {
        bind( m_TXT_RLCD_CHIP_pos, m_TXT_RLCD_CHIP );
        bind( m_TXT_INFO_CMPM_CHIP_pos, m_TXT_INFO_CMPM_CHIP );
        bind( m_TXT_RSTD_ATLZ_CHIP_pos, m_TXT_RSTD_ATLZ_CHIP );
        bind( m_IND_NVL_SGRA_KMRC_pos, m_IND_NVL_SGRA_KMRC );
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_DAT_VD_CHIP_pos, &m_DAT_VD_CHIP );
        bind( m_COD_PGM_AUT_pos, m_COD_PGM_AUT );
        bind( m_IND_MTDO_VRFC_PORT_pos, m_IND_MTDO_VRFC_PORT );
        bind( m_IND_PRSC_SNHA_pos, m_IND_PRSC_SNHA );
        bind( m_NUM_SEQ_CAR_VLDC_CHIP_pos, m_NUM_SEQ_CAR_VLDC_CHIP, &m_NUM_SEQ_CAR_VLDC_CHIP_ind_null );
        bind( m_NOM_PORT_CAR_pos, m_NOM_PORT_CAR );
    }

    void TBSW0034::let_as_is( )
    {
        m_NUM_SEQ_CAR_VLDC_CHIP_ind_null = is_null( m_NUM_SEQ_CAR_VLDC_CHIP ) ? DBM_NULL_DATA : 0;
    }

    void TBSW0034::set_TXT_RLCD_CHIP( const std::string& a_TXT_RLCD_CHIP )
    {
        m_TXT_RLCD_CHIP = a_TXT_RLCD_CHIP;
    }
    void TBSW0034::set_TXT_INFO_CMPM_CHIP( const std::string& a_TXT_INFO_CMPM_CHIP )
    {
        m_TXT_INFO_CMPM_CHIP = a_TXT_INFO_CMPM_CHIP;
    }
    void TBSW0034::set_TXT_RSTD_ATLZ_CHIP( const std::string& a_TXT_RSTD_ATLZ_CHIP )
    {
        m_TXT_RSTD_ATLZ_CHIP = a_TXT_RSTD_ATLZ_CHIP;
    }
    void TBSW0034::set_IND_NVL_SGRA_KMRC( const std::string& a_IND_NVL_SGRA_KMRC )
    {
        m_IND_NVL_SGRA_KMRC = a_IND_NVL_SGRA_KMRC;
    }
    void TBSW0034::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0034::set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }
    void TBSW0034::set_DAT_VD_CHIP( dbm_datetime_t a_DAT_VD_CHIP )
    {
        m_DAT_VD_CHIP = a_DAT_VD_CHIP;
    }
    void TBSW0034::set_COD_PGM_AUT( const std::string& a_COD_PGM_AUT )
    {
        m_COD_PGM_AUT = a_COD_PGM_AUT;
    }
    void TBSW0034::set_IND_MTDO_VRFC_PORT( const std::string& a_IND_MTDO_VRFC_PORT )
    {
        m_IND_MTDO_VRFC_PORT = a_IND_MTDO_VRFC_PORT;
    }
    void TBSW0034::set_IND_PRSC_SNHA( const std::string& a_IND_PRSC_SNHA )
    {
        m_IND_PRSC_SNHA = a_IND_PRSC_SNHA;
    }
    void TBSW0034::set_NUM_SEQ_CAR_VLDC_CHIP( unsigned long a_NUM_SEQ_CAR_VLDC_CHIP )
    {
        m_NUM_SEQ_CAR_VLDC_CHIP = a_NUM_SEQ_CAR_VLDC_CHIP;
        m_NUM_SEQ_CAR_VLDC_CHIP_ind_null = 0;
    }
    void TBSW0034::set_NOM_PORT_CAR( const std::string& a_NOM_PORT_CAR )
    {
        m_NOM_PORT_CAR = a_NOM_PORT_CAR;
    }

    const std::string& TBSW0034::get_TXT_RLCD_CHIP( ) const
    {
        return( m_TXT_RLCD_CHIP );
    }
    const std::string& TBSW0034::get_TXT_INFO_CMPM_CHIP( ) const
    {
        return( m_TXT_INFO_CMPM_CHIP );
    }
    const std::string& TBSW0034::get_TXT_RSTD_ATLZ_CHIP( ) const
    {
        return( m_TXT_RSTD_ATLZ_CHIP );
    }
    const std::string& TBSW0034::get_IND_NVL_SGRA_KMRC( ) const
    {
        return( m_IND_NVL_SGRA_KMRC );
    }
    unsigned long TBSW0034::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    unsigned long TBSW0034::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }
    dbm_datetime_t TBSW0034::get_DAT_VD_CHIP( ) const
    {
        return( m_DAT_VD_CHIP );
    }
    const std::string& TBSW0034::get_COD_PGM_AUT( ) const
    {
        return( m_COD_PGM_AUT );
    }
    const std::string& TBSW0034::get_IND_MTDO_VRFC_PORT( ) const
    {
        return( m_IND_MTDO_VRFC_PORT );
    }
    const std::string& TBSW0034::get_IND_PRSC_SNHA( ) const
    {
        return( m_IND_PRSC_SNHA );
    }
    unsigned long TBSW0034::get_NUM_SEQ_CAR_VLDC_CHIP( ) const
    {
        return( m_NUM_SEQ_CAR_VLDC_CHIP );
    }
    const std::string& TBSW0034::get_NOM_PORT_CAR() const
    {
        return( m_NOM_PORT_CAR );
    }
    

    // Teste de conteudo do registro
    void TBSW0034::showxxx( const char *name, unsigned long campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%ld]", name, campo );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0034::showxxx( const char *name, dbm_datetime_t campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%ld]", name, campo );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0034::showxxx( const char *name, const std::string& campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%s]", name, campo.c_str( ) );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0034::showxxx( const char *name, oasis_dec_t campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            char buf_aux[1000] = {0};
            dbm_dectochar( &campo, buf_aux);
            sprintf(buf, " - %s : [%s]", name, buf_aux );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }
    void TBSW0034::showxxx( const char *name, sw_date_t campo, bool isNull )
    {
        char buf[1000] = {0};
        if( isNull == true )
        {
            sprintf(buf, " - %s : [NULL]", name );
        }
        else
        {
            sprintf(buf, " - %s : [%ld]", name, campo.date );
        }
        m_log->write( logger::LEVEL_DEBUG, buf );
    }    
    
    void TBSW0034::show(int nvl)
    {
        char buf[1000];
        sprintf( buf, " --[%s]----------------------------", table_name.c_str() );
        m_log->write( logger::LEVEL_DEBUG, buf );

        //NOT NULL CAMPOS
        showxxx( "TXT_RLCD_CHIP",m_TXT_RLCD_CHIP, false);
        showxxx( "TXT_INFO_CMPM_CHIP",m_TXT_INFO_CMPM_CHIP, false);
        showxxx( "TXT_RSTD_ATLZ_CHIP",m_TXT_RSTD_ATLZ_CHIP, false);
        showxxx( "IND_NVL_SGRA_KMRC",m_IND_NVL_SGRA_KMRC, false);
        showxxx( "DAT_MOV_TRAN",m_DAT_MOV_TRAN, false);
        showxxx( "DAT_VD_CHIP",m_DAT_VD_CHIP, false);
        showxxx( "NUM_SEQ_UNC",m_NUM_SEQ_UNC, false);

        //NULL CAMPOS
        showxxx("COD_PGM_AUT",m_COD_PGM_AUT, m_COD_PGM_AUT.empty( ) );
        showxxx("IND_MTDO_VRFC_PORT",m_IND_MTDO_VRFC_PORT, m_IND_MTDO_VRFC_PORT.empty( ) );
        showxxx("IND_PRSC_SNHA",m_IND_PRSC_SNHA, m_IND_PRSC_SNHA.empty( ) );
        showxxx("NUM_SEQ_CAR_VLDC_CHIP",m_NUM_SEQ_CAR_VLDC_CHIP, m_NUM_SEQ_CAR_VLDC_CHIP == DBM_NULL_DATA );
        showxxx("NOM_PORT_CAR",m_NOM_PORT_CAR, m_NOM_PORT_CAR.empty( ) );        

        sprintf( buf, " ------------------------------------------", table_name.c_str() );
        m_log->write( logger::LEVEL_DEBUG, buf );

    }    
} //namespace dbaccess_common


