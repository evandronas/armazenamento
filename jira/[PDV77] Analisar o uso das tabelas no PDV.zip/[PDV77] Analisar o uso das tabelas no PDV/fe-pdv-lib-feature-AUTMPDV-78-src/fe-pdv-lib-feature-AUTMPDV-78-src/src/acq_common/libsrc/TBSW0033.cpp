#include "TBSW0033.hpp"

namespace dbaccess_common
{
    TBSW0033::TBSW0033()
    {
        initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0033::TBSW0033( const std::string& whereClause )
    {
        initialize();
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0033::~TBSW0033()
    {
    }

    void TBSW0033::initialize()
    {
        query_fields = "NUM_BCO_DEB, NUM_CGC_CPF, NUM_CHQ, TXT_MSG_1, TXT_MSG_2, NUM_RSMO_VD, DAT_RSMO_VD, NUM_TEL, TIP_DOC, DTH_CON_TRAN, DAT_MOV_TRAN, NUM_SEQ_UNC";

        table_name = "TBSW0033";

        m_NUM_BCO_DEB_pos = 1;
        m_NUM_CGC_CPF_pos = 2;
        m_NUM_CHQ_pos = 3;
        m_TXT_MSG_1_pos = 4;
        m_TXT_MSG_2_pos = 5;
        m_NUM_RSMO_VD_pos = 6;
        m_DAT_RSMO_VD_pos = 7;
        m_NUM_TEL_pos = 8;
        m_TIP_DOC_pos = 9;
        m_DTH_CON_TRAN_pos = 10;
        m_DAT_MOV_TRAN_pos = 11;
        m_NUM_SEQ_UNC_pos = 12;
		m_TIP_DOC = "";
        m_NUM_BCO_DEB = 0;
        dbm_longtodec( &m_NUM_CGC_CPF, 0 );
        m_NUM_CHQ = "";
        m_TXT_MSG_1 = "";
        m_TXT_MSG_2 = "";
        dbm_longtodec( &m_NUM_RSMO_VD, 0 );
        m_DAT_RSMO_VD = 0;
        dbm_longtodec( &m_NUM_TEL, 0 );
        m_DTH_CON_TRAN = 0;
        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        
        m_TXT_MSG_1_ind_null = DBM_NULL_DATA;
        m_TXT_MSG_2_ind_null = DBM_NULL_DATA;
        m_TIP_DOC_ind_null = DBM_NULL_DATA;       
        m_NUM_BCO_DEB_ind_null = DBM_NULL_DATA;
        m_NUM_CGC_CPF_ind_null = DBM_NULL_DATA;
        m_NUM_RSMO_VD_ind_null = DBM_NULL_DATA;
        m_DAT_RSMO_VD_ind_null = DBM_NULL_DATA;
        m_NUM_TEL_ind_null = DBM_NULL_DATA;
        m_DTH_CON_TRAN_ind_null = DBM_NULL_DATA;        
        
    }

    void TBSW0033::let_as_is( )
    {
        m_DAT_RSMO_VD_ind_null  = ( is_null(m_DAT_RSMO_VD) )  ? ( DBM_NULL_DATA  ) : ( 0 );
        m_DTH_CON_TRAN_ind_null = ( is_null(m_DTH_CON_TRAN) ) ? ( DBM_NULL_DATA  ) : ( 0 );
        m_NUM_BCO_DEB_ind_null  = ( is_null(m_NUM_BCO_DEB) )  ? ( DBM_NULL_DATA  ) : ( 0 );
        m_NUM_CGC_CPF_ind_null  = ( is_null(m_NUM_CGC_CPF) )  ? ( DBM_NULL_DATA  ) : ( 0 );
        m_NUM_RSMO_VD_ind_null  = ( is_null(m_NUM_RSMO_VD) )  ? ( DBM_NULL_DATA  ) : ( 0 );
        m_NUM_TEL_ind_null      = ( is_null(m_NUM_TEL) )      ? ( DBM_NULL_DATA  ) : ( 0 );
    }

    void TBSW0033::bind_columns()
    {
        bind( m_NUM_CHQ_pos, m_NUM_CHQ );
        bind( m_NUM_BCO_DEB_pos, m_NUM_BCO_DEB, &m_NUM_BCO_DEB_ind_null);
        bind( m_NUM_CGC_CPF_pos, m_NUM_CGC_CPF, &m_NUM_CGC_CPF_ind_null);
        bind( m_TXT_MSG_1_pos, m_TXT_MSG_1 );
        bind( m_TXT_MSG_2_pos, m_TXT_MSG_2 );
        bind( m_NUM_RSMO_VD_pos, m_NUM_RSMO_VD, &m_NUM_RSMO_VD_ind_null);
        bind( m_DAT_RSMO_VD_pos, &m_DAT_RSMO_VD , &m_DAT_RSMO_VD_ind_null);
        bind( m_NUM_TEL_pos, m_NUM_TEL, &m_NUM_TEL_ind_null);
        bind( m_TIP_DOC_pos, m_TIP_DOC);
        bind( m_DTH_CON_TRAN_pos, &m_DTH_CON_TRAN, &m_DTH_CON_TRAN_ind_null);
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
    }
    void TBSW0033::set_NUM_BCO_DEB( unsigned long a_NUM_BCO_DEB )
    {
        m_NUM_BCO_DEB = a_NUM_BCO_DEB;
        m_NUM_BCO_DEB_ind_null = 0;
    }
    void TBSW0033::set_NUM_CGC_CPF( oasis_dec_t a_NUM_CGC_CPF )
    {
        dbm_deccopy( &m_NUM_CGC_CPF, &a_NUM_CGC_CPF );
        m_NUM_CGC_CPF_ind_null = 0;
    }
    void TBSW0033::set_NUM_CHQ( const std::string& a_NUM_CHQ )
    {
        m_NUM_CHQ = a_NUM_CHQ;
    }
    void TBSW0033::set_TXT_MSG_1( const std::string& a_TXT_MSG_1 )
    {
        m_TXT_MSG_1 = a_TXT_MSG_1;
    }
    void TBSW0033::set_TXT_MSG_2( const std::string& a_TXT_MSG_2 )
    {
        m_TXT_MSG_2 = a_TXT_MSG_2;
    }
    void TBSW0033::set_NUM_RSMO_VD( oasis_dec_t a_NUM_RSMO_VD )
    {
        dbm_deccopy( &m_NUM_RSMO_VD, &a_NUM_RSMO_VD );
        m_NUM_RSMO_VD_ind_null = 0;
    }
    void TBSW0033::set_DAT_RSMO_VD( dbm_datetime_t a_DAT_RSMO_VD )
    {
        m_DAT_RSMO_VD = a_DAT_RSMO_VD;
        m_DAT_RSMO_VD_ind_null = 0;
    }
    void TBSW0033::set_NUM_TEL( oasis_dec_t a_NUM_TEL )
    {
        dbm_deccopy( &m_NUM_TEL, &a_NUM_TEL );
        m_NUM_TEL_ind_null = 0;
    }
    void TBSW0033::set_TIP_DOC( const std::string& a_TIP_DOC )
    {
        m_TIP_DOC = a_TIP_DOC;
    }
    void TBSW0033::set_DTH_CON_TRAN( dbm_datetime_t a_DTH_CON_TRAN )
    {
        m_DTH_CON_TRAN = a_DTH_CON_TRAN;
        m_DTH_CON_TRAN_ind_null = 0;
    }
    void TBSW0033::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0033::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    unsigned long TBSW0033::get_NUM_BCO_DEB() const
    {
        return m_NUM_BCO_DEB;
    }
    oasis_dec_t TBSW0033::get_NUM_CGC_CPF() const
    {
        return m_NUM_CGC_CPF;
    }
    const std::string& TBSW0033::get_NUM_CHQ() const
    {
        return m_NUM_CHQ;
    }
    const std::string& TBSW0033::get_TXT_MSG_1() const
    {
        return m_TXT_MSG_1;
    }
    const std::string& TBSW0033::get_TXT_MSG_2() const
    {
        return m_TXT_MSG_2;
    }
    oasis_dec_t TBSW0033::get_NUM_RSMO_VD() const
    {
        return m_NUM_RSMO_VD;
    }
    dbm_datetime_t TBSW0033::get_DAT_RSMO_VD() const
    {
        return m_DAT_RSMO_VD;
    }
    oasis_dec_t TBSW0033::get_NUM_TEL() const
    {
        return m_NUM_TEL;
    }
    const std::string& TBSW0033::get_TIP_DOC() const
    {
        return m_TIP_DOC;
    }
    dbm_datetime_t TBSW0033::get_DTH_CON_TRAN() const
    {
        return m_DTH_CON_TRAN;
    }
    unsigned long TBSW0033::get_DAT_MOV_TRAN() const
    {
        return m_DAT_MOV_TRAN;
    }
    oasis_dec_t TBSW0033::get_NUM_SEQ_UNC() const
    {
        return m_NUM_SEQ_UNC;
    }

} //namespace dbaccess_common

