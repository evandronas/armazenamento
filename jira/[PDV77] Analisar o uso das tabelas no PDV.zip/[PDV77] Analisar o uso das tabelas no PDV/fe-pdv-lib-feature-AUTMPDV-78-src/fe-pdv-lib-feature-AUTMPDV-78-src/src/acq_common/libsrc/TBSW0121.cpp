#include "TBSW0121.hpp"

namespace dbaccess_common
{
    TBSW0121::TBSW0121( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0121::TBSW0121( const std::string& whereClause )
    {
        initialize( );
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0121::~TBSW0121( )
    {
    }

    void TBSW0121::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, COD_VERS_SRVD_PDV, COD_VERS_CHCK_PDV, COD_VERS_BBLT_PNPD, COD_VERS_SFTW, COD_VERS_SIS, NUM_SRE_PNPD, COD_CHCK_PDV, COD_MODL_PNPD";

        table_name = "TBSW0121";

        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_COD_VERS_SRVD_PDV_pos = 3;
        m_COD_VERS_CHCK_PDV_pos = 4;
        m_COD_VERS_BBLT_PNPD_pos = 5;
        m_COD_VERS_SFTW_pos = 6;
        m_COD_VERS_SIS_pos = 7;
        m_NUM_SRE_PNPD_pos = 8;
        m_COD_CHCK_PDV_pos = 9;
        m_COD_MODL_PNPD_pos = 10;

        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_COD_VERS_SRVD_PDV = " ";
        m_COD_VERS_CHCK_PDV = " ";
        m_COD_VERS_BBLT_PNPD = " ";
        m_COD_VERS_SFTW = " ";
        m_COD_VERS_SIS = " ";
        m_NUM_SRE_PNPD = " ";
        m_COD_CHCK_PDV = " ";
        m_COD_MODL_PNPD = " ";
    }

    void TBSW0121::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_COD_VERS_SRVD_PDV_pos, m_COD_VERS_SRVD_PDV );
        bind( m_COD_VERS_CHCK_PDV_pos, m_COD_VERS_CHCK_PDV );
        bind( m_COD_VERS_BBLT_PNPD_pos, m_COD_VERS_BBLT_PNPD );
        bind( m_COD_VERS_SFTW_pos, m_COD_VERS_SFTW );
        bind( m_COD_VERS_SIS_pos, m_COD_VERS_SIS );
        bind( m_NUM_SRE_PNPD_pos, m_NUM_SRE_PNPD );
        bind( m_COD_CHCK_PDV_pos, m_COD_CHCK_PDV );
        bind( m_COD_MODL_PNPD_pos, m_COD_MODL_PNPD );
    }

    void TBSW0121::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0121::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    void TBSW0121::set_COD_VERS_SRVD_PDV( const std::string& a_COD_VERS_SRVD_PDV )
    {
        m_COD_VERS_SRVD_PDV = a_COD_VERS_SRVD_PDV;
    }
    void TBSW0121::set_COD_VERS_CHCK_PDV( const std::string& a_COD_VERS_CHCK_PDV )
    {
        m_COD_VERS_CHCK_PDV = a_COD_VERS_CHCK_PDV;
    }
    void TBSW0121::set_COD_VERS_BBLT_PNPD( const std::string& a_COD_VERS_BBLT_PNPD )
    {
        m_COD_VERS_BBLT_PNPD = a_COD_VERS_BBLT_PNPD;
    }
    void TBSW0121::set_COD_VERS_SFTW( const std::string& a_COD_VERS_SFTW )
    {
        m_COD_VERS_SFTW = a_COD_VERS_SFTW;
    }
    void TBSW0121::set_COD_VERS_SIS( const std::string& a_COD_VERS_SIS )
    {
        m_COD_VERS_SIS = a_COD_VERS_SIS;
    }
    void TBSW0121::set_NUM_SRE_PNPD( const std::string& a_NUM_SRE_PNPD )
    {
        m_NUM_SRE_PNPD = a_NUM_SRE_PNPD;
    }
    void TBSW0121::set_COD_CHCK_PDV( const std::string& a_COD_CHCK_PDV )
    {
        m_COD_CHCK_PDV = a_COD_CHCK_PDV;
    }
    void TBSW0121::set_COD_MODL_PNPD( const std::string& a_COD_MODL_PNPD )
    {
        m_COD_MODL_PNPD = a_COD_MODL_PNPD;
    }

    unsigned long TBSW0121::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    oasis_dec_t TBSW0121::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }
    const std::string& TBSW0121::get_COD_VERS_SRVD_PDV( ) const
    {
        return( m_COD_VERS_SRVD_PDV );
    }
    const std::string& TBSW0121::get_COD_VERS_CHCK_PDV( ) const
    {
        return( m_COD_VERS_CHCK_PDV );
    }
    const std::string& TBSW0121::get_COD_VERS_BBLT_PNPD( ) const
    {
        return( m_COD_VERS_BBLT_PNPD );
    }
    const std::string& TBSW0121::get_COD_VERS_SIS( ) const
    {
        return( m_COD_VERS_SIS );
    }
    const std::string& TBSW0121::get_NUM_SRE_PNPD( ) const
    {
        return( m_NUM_SRE_PNPD );
    }
    const std::string& TBSW0121::get_COD_CHCK_PDV( ) const
    {
        return( m_COD_CHCK_PDV );
    }
    const std::string& TBSW0121::get_COD_MODL_PNPD( ) const
    {
        return( m_COD_MODL_PNPD );
    }
    const std::string& TBSW0121::get_COD_VERS_SFTW( ) const
    {
        return( m_COD_VERS_SFTW );
    }

} // namespace dbaccess_common
