#include <cstring>
#include<TBSW0084RegrasFormatacaoBase.hpp>

TBSW0084RegrasFormatacaoBase::TBSW0084RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0084RegrasFormatacaoBase::~TBSW0084RegrasFormatacaoBase( )
{
}

void TBSW0084RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::COD_TERM( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TERM( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TERM( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::NUM_STAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_STAN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_STAN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::DTH_INI_TRAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_INI_TRAN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_INI_TRAN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::NUM_ESTB( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ESTB( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ESTB( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::COD_PNPD_PDV( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PNPD_PDV( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PNPD_PDV( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::NOM_FBRC_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FBRC_PNPD( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FBRC_PNPD( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::NUM_SRE_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SRE_PNPD( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SRE_PNPD( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::COD_VERS_HDW_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_HDW_PNPD( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_HDW_PNPD( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::COD_VERS_FRWR_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_FRWR_PNPD( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_FRWR_PNPD( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::NOM_FBRC_TEF( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FBRC_TEF( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FBRC_TEF( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::COD_VERS_SFTW_TEF( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_SFTW_TEF( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_SFTW_TEF( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::NOM_FBRC_ATMC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FBRC_ATMC( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FBRC_ATMC( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::COD_VERS_SFTW_ATMC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_SFTW_ATMC( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_SFTW_ATMC( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_LEIT_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_LEIT_MAGN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_LEIT_MAGN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_ERR_LEIT_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_ERR_LEIT_MAGN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_ERR_LEIT_MAGN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_SNHA_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_SNHA_MAGN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_SNHA_MAGN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_ERR_SNHA_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_ERR_SNHA_MAGN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_ERR_SNHA_MAGN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_SNHA_CHIP_ONLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_SNHA_CHIP_ONLN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_SNHA_CHIP_ONLN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_ERR_SNHA_CHIP_ONLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_ERR_SNHA_CHIP_ONLN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_ERR_SNHA_CHIP_ONLN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_SNHA_CHIP_OFLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_SNHA_CHIP_OFLN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_SNHA_CHIP_OFLN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_ERR_SNHA_CHIP_OFLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_ERR_SNHA_CHIP_OFLN( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_ERR_SNHA_CHIP_OFLN( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_BLQD_CHIP( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_BLQD_CHIP( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_BLQD_CHIP( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_LEIT_CHIP( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_LEIT_CHIP( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_LEIT_CHIP( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_FALLBACK_CRE( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_FALLBACK_CRE( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_FALLBACK_CRE( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::QTD_FALLBACK_DEB( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_FALLBACK_DEB( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_FALLBACK_DEB( tbsw0084, params );
    }
}

void TBSW0084RegrasFormatacaoBase::COD_VERS_SFTW_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VERS_SFTW_PNPD( tbsw0084, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VERS_SFTW_PNPD( tbsw0084, params );
    }
}

// Metodos utilizados por campos que tem input generico (INSERT/UPDATE)

void TBSW0084RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    tbsw0084.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0084RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw0084.set_NUM_SEQ_UNC( l_dect );
}

void TBSW0084RegrasFormatacaoBase::gen_COD_TERM( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.terminal_pdv.c_str( ) ) > 0 )
    {
        tbsw0084.set_COD_TERM( params.terminal_pdv );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_NUM_STAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.trace );
    tbsw0084.set_NUM_STAN( l_dect );
}

void TBSW0084RegrasFormatacaoBase::gen_DTH_INI_TRAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    tbsw0084.set_DTH_INI_TRAN( AcqUtils::dateTime( params.local_date, params.local_time ) );
}

void TBSW0084RegrasFormatacaoBase::gen_NUM_ESTB( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    tbsw0084.set_NUM_ESTB( params.termloc );
}

void TBSW0084RegrasFormatacaoBase::gen_COD_PNPD_PDV( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    tbsw0084.set_COD_PNPD_PDV( params.id_pinpad );
}

void TBSW0084RegrasFormatacaoBase::gen_NOM_FBRC_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_NOM_FBRC_PNPD( params.statistics.substr( 0, 20 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_NUM_SRE_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_NUM_SRE_PNPD( params.statistics.substr( 20, 20 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_COD_VERS_HDW_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_COD_VERS_HDW_PNPD( params.statistics.substr( 40, 20 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_COD_VERS_FRWR_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_COD_VERS_FRWR_PNPD( params.statistics.substr( 60, 20 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_NOM_FBRC_TEF( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_NOM_FBRC_TEF( params.statistics.substr( 100, 20 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_COD_VERS_SFTW_TEF( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_COD_VERS_SFTW_TEF( params.statistics.substr( 120, 20 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_NOM_FBRC_ATMC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_NOM_FBRC_ATMC( params.statistics.substr( 140, 20 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_COD_VERS_SFTW_ATMC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_COD_VERS_SFTW_ATMC( params.statistics.substr( 160, 20 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_LEIT_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_LEIT_MAGN( strtol( params.statistics.substr( 180, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_ERR_LEIT_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_ERR_LEIT_MAGN( strtol( params.statistics.substr( 183, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_SNHA_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_SNHA_MAGN( strtol( params.statistics.substr( 186, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_ERR_SNHA_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_ERR_SNHA_MAGN( strtol( params.statistics.substr( 189, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_SNHA_CHIP_ONLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_SNHA_CHIP_ONLN( strtol( params.statistics.substr( 192, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_ERR_SNHA_CHIP_ONLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_ERR_SNHA_CHIP_ONLN( strtol( params.statistics.substr( 195, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_SNHA_CHIP_OFLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_SNHA_CHIP_OFLN( strtol( params.statistics.substr( 198, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_ERR_SNHA_CHIP_OFLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_ERR_SNHA_CHIP_OFLN( strtol( params.statistics.substr( 201, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_BLQD_CHIP( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_BLQD_CHIP( strtol( params.statistics.substr( 204, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_LEIT_CHIP( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_LEIT_CHIP( strtol( params.statistics.substr( 207, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_FALLBACK_CRE( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_FALLBACK_CRE( strtol( params.statistics.substr( 210, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_QTD_FALLBACK_DEB( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_QTD_FALLBACK_DEB( strtol( params.statistics.substr( 213, 3 ).c_str( ), NULL, 10 ) );
    }
}

void TBSW0084RegrasFormatacaoBase::gen_COD_VERS_SFTW_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    if ( strlen( params.statistics.c_str( ) ) == 246 )
    {
        tbsw0084.set_COD_VERS_SFTW_PNPD( params.statistics.substr( 80, 20 ) );
    }
}

// Metodos especificos para INSERT

void TBSW0084RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_DAT_MOV_TRAN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NUM_SEQ_UNC( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_COD_TERM( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_TERM( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_NUM_STAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NUM_STAN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_DTH_INI_TRAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_DTH_INI_TRAN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_NUM_ESTB( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NUM_ESTB( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_COD_PNPD_PDV( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_PNPD_PDV( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_NOM_FBRC_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NOM_FBRC_PNPD( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_NUM_SRE_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NUM_SRE_PNPD( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_COD_VERS_HDW_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_HDW_PNPD( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_COD_VERS_FRWR_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_FRWR_PNPD( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_NOM_FBRC_TEF( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NOM_FBRC_TEF( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_COD_VERS_SFTW_TEF( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_SFTW_TEF( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_NOM_FBRC_ATMC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NOM_FBRC_ATMC( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_COD_VERS_SFTW_ATMC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_SFTW_ATMC( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_LEIT_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_LEIT_MAGN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_ERR_LEIT_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_ERR_LEIT_MAGN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_SNHA_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_SNHA_MAGN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_ERR_SNHA_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_ERR_SNHA_MAGN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_SNHA_CHIP_ONLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_SNHA_CHIP_ONLN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_ERR_SNHA_CHIP_ONLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_ERR_SNHA_CHIP_ONLN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_SNHA_CHIP_OFLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_SNHA_CHIP_OFLN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_ERR_SNHA_CHIP_OFLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_ERR_SNHA_CHIP_OFLN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_BLQD_CHIP( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_BLQD_CHIP( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_LEIT_CHIP( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_LEIT_CHIP( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_FALLBACK_CRE( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_FALLBACK_CRE( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_QTD_FALLBACK_DEB( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_FALLBACK_DEB( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::insert_COD_VERS_SFTW_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_SFTW_PNPD( tbsw0084, params );
}

// Metodos especificos para UPDATE

void TBSW0084RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_DAT_MOV_TRAN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NUM_SEQ_UNC( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_COD_TERM( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_TERM( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_NUM_STAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NUM_STAN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_DTH_INI_TRAN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_DTH_INI_TRAN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_NUM_ESTB( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NUM_ESTB( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_COD_PNPD_PDV( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_PNPD_PDV( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_NOM_FBRC_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NOM_FBRC_PNPD( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_NUM_SRE_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NUM_SRE_PNPD( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_COD_VERS_HDW_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_HDW_PNPD( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_COD_VERS_FRWR_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_FRWR_PNPD( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_NOM_FBRC_TEF( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NOM_FBRC_TEF( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_COD_VERS_SFTW_TEF( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_SFTW_TEF( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_NOM_FBRC_ATMC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_NOM_FBRC_ATMC( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_COD_VERS_SFTW_ATMC( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_SFTW_ATMC( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_LEIT_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_LEIT_MAGN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_ERR_LEIT_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_ERR_LEIT_MAGN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_SNHA_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_SNHA_MAGN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_ERR_SNHA_MAGN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_ERR_SNHA_MAGN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_SNHA_CHIP_ONLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_SNHA_CHIP_ONLN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_ERR_SNHA_CHIP_ONLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_ERR_SNHA_CHIP_ONLN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_SNHA_CHIP_OFLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_SNHA_CHIP_OFLN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_ERR_SNHA_CHIP_OFLN( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_ERR_SNHA_CHIP_OFLN( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_BLQD_CHIP( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_BLQD_CHIP( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_LEIT_CHIP( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_LEIT_CHIP( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_FALLBACK_CRE( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_FALLBACK_CRE( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_QTD_FALLBACK_DEB( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_QTD_FALLBACK_DEB( tbsw0084, params );
}

void TBSW0084RegrasFormatacaoBase::update_COD_VERS_SFTW_PNPD( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params )
{
    gen_COD_VERS_SFTW_PNPD( tbsw0084, params );
}
