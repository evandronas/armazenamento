#pragma once
#include <cstring>
#include "CodUcafFormaterVisa.hpp"

CodUcafFormaterVisa::CodUcafFormaterVisa( const std::string &cavv ) : CodUcafFormater( cavv )
{
}

CodUcafFormaterVisa::~CodUcafFormaterVisa()
{
}

/// formatVisa
/// Retorna CAVV no formato recebido pelo SW (Hex)
std::string CodUcafFormaterVisa::format()
{
    if ( m_cavv.length() )
    {
        char cavvChar[50] = {0};
        std::memset( cavvChar, 0, sizeof(cavvChar) );
        int cavvCharSize;

        // Para Visa, o tamanho maximo do CAVV e' 20
        if( m_cavv.size() > 20 )
        {
            cavvCharSize = 40;
        }
        else
        {
            cavvCharSize = m_cavv.size()*2;
        }

        BinaryToChar( cavvChar, (char *) m_cavv.c_str(), cavvCharSize );

        // Verificar se cavv contem apenas zeros
        if (std::strncmp("0000000000000000000000000000000000000000", cavvChar, cavvCharSize) != 0)
        {
            return std::string( cavvChar );
        }
    }

    return std::string(" ");
}