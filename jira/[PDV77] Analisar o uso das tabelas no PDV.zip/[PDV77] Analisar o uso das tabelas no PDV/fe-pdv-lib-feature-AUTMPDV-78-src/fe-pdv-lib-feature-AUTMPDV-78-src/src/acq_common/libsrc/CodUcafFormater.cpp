#pragma once
#include "CodUcafFormater.hpp"

CodUcafFormater::CodUcafFormater( const std::string &cavv )
{
    m_cavv = cavv;
}

CodUcafFormater::~CodUcafFormater()
{
}

/// BinaryToChar
/// Converte o dado binario em string
/// EF/ET: ET1
/// Historico: [Data] - ET - Descricao
/// 08/03/2019 - ET1 - Criacao da versao inicial
/// outputData: Dado de saida
/// inputData: Dado de entrada
/// lenghtData: Tamanho do dado a ser convertido
void CodUcafFormater::BinaryToChar( char* outputData, char* inputData, int lenghtData )
{
    int index = 0;
    char* inputChar = NULL;
    char* outputChar = NULL;

    // Converte do formato binario para um hex imprimivel
    for ( index = 0, outputChar = outputData, inputChar = inputData;
                    ( index * 2 ) < lenghtData; index++, outputChar += 2, inputChar++ )
    {
        sprintf( outputChar, "%02x", *inputChar & 0xFF );
    }
    if ( lenghtData % 2 )
    {
        *( outputData + lenghtData ) = '\0';
    }
}