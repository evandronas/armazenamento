#include "TBSW0160.hpp"

namespace dbaccess_common
{
    TBSW0160::TBSW0160( )
    {
        initialize();
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_BASEUNICA);
    }
    
    TBSW0160::TBSW0160( const std::string& whereClause )
    {
        initialize();
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_BASEUNICA);
    }

    TBSW0160::~TBSW0160( )
    {
    }
    
    void TBSW0160::initialize()
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, IND_RD_ORG, COD_PGM_AUT, TXT_RLCD_CHIP, TXT_INFO_CMPM_CHIP, TXT_RSTD_ATLZ_CHIP, IND_NVL_SGRA_KMRC, IND_MTDO_VRFC_PORT, IND_PRSC_SNHA, DAT_CNFR_PAUZ, NUM_SEQ_UNC_CNFR, NUM_SEQ_CAR_VLDC_CHIP";

        table_name = "TBSW0160";

        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_IND_RD_ORG_pos = 3;
        m_COD_PGM_AUT_pos = 4;
        m_TXT_RLCD_CHIP_pos = 5;
        m_TXT_INFO_CMPM_CHIP_pos = 6;
        m_TXT_RSTD_ATLZ_CHIP_pos = 7;
        m_IND_NVL_SGRA_KMRC_pos = 8;
        m_IND_MTDO_VRFC_PORT_pos = 9;
        m_IND_PRSC_SNHA_pos = 10;
        m_DAT_CNFR_PAUZ_pos = 11;
        m_NUM_SEQ_UNC_CNFR_pos = 12;
        posNumeroSequencialCartaoValidacaoChip = 13;

        m_DAT_MOV_TRAN = 0;
        m_NUM_SEQ_UNC =  0;
        m_IND_RD_ORG = "";
        m_COD_PGM_AUT = "";
        m_TXT_RLCD_CHIP = "";
        m_TXT_INFO_CMPM_CHIP = "";
        m_TXT_RSTD_ATLZ_CHIP = "";
        m_IND_NVL_SGRA_KMRC = "";
        m_IND_MTDO_VRFC_PORT = "";
        m_IND_PRSC_SNHA = "";
        m_DAT_CNFR_PAUZ = 0;
        m_NUM_SEQ_UNC_CNFR = 0;
        numeroSequencialCartaoValidacaoChip = 0;
        
        m_DAT_CNFR_PAUZ_ind_null = DBM_NULL_DATA;
        m_NUM_SEQ_UNC_CNFR_ind_null = DBM_NULL_DATA;
        indNullNumeroSequencialCartaoValidacaoChip = DBM_NULL_DATA;
    }
    
    void TBSW0160::setWhereClause( const std::string& whereClause )
    {
        where_condition = whereClause;
    }

    void TBSW0160::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_IND_RD_ORG_pos, m_IND_RD_ORG );
        bind( m_COD_PGM_AUT_pos, m_COD_PGM_AUT );
        bind( m_TXT_RLCD_CHIP_pos, m_TXT_RLCD_CHIP );
        bind( m_TXT_INFO_CMPM_CHIP_pos, m_TXT_INFO_CMPM_CHIP  );
        bind( m_TXT_RSTD_ATLZ_CHIP_pos, m_TXT_RSTD_ATLZ_CHIP  );
        bind( m_IND_NVL_SGRA_KMRC_pos, m_IND_NVL_SGRA_KMRC );
        bind( m_IND_MTDO_VRFC_PORT_pos, m_IND_MTDO_VRFC_PORT );
        bind( m_IND_PRSC_SNHA_pos, m_IND_PRSC_SNHA );
        bind( m_DAT_CNFR_PAUZ_pos, &m_DAT_CNFR_PAUZ, &m_DAT_CNFR_PAUZ_ind_null );
        bind( m_NUM_SEQ_UNC_CNFR_pos, m_NUM_SEQ_UNC_CNFR, &m_NUM_SEQ_UNC_CNFR_ind_null );
        
        bind( posNumeroSequencialCartaoValidacaoChip, numeroSequencialCartaoValidacaoChip, &indNullNumeroSequencialCartaoValidacaoChip );
    }
    
	void TBSW0160::let_as_is( )
	{
        m_DAT_CNFR_PAUZ_ind_null = is_null( &m_DAT_CNFR_PAUZ ) ? DBM_NULL_DATA : 0;
        m_NUM_SEQ_UNC_CNFR_ind_null = is_null( m_NUM_SEQ_UNC_CNFR ) ? DBM_NULL_DATA : 0;

        indNullNumeroSequencialCartaoValidacaoChip = is_null( numeroSequencialCartaoValidacaoChip ) ? DBM_NULL_DATA : 0;
	}

    void TBSW0160::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }

    void TBSW0160::set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }

    void TBSW0160::set_IND_RD_ORG( const std::string& a_IND_RD_ORG )
    {
        m_IND_RD_ORG = a_IND_RD_ORG;
    }

    void TBSW0160::set_COD_PGM_AUT( const std::string& a_COD_PGM_AUT )
    {
        m_COD_PGM_AUT = a_COD_PGM_AUT;
    }

    void TBSW0160::set_TXT_RLCD_CHIP( const std::string& a_TXT_RLCD_CHIP )
    {
        m_TXT_RLCD_CHIP = a_TXT_RLCD_CHIP;
    }

    void TBSW0160::set_TXT_INFO_CMPM_CHIP( const std::string& a_TXT_INFO_CMPM_CHIP )
    {
        m_TXT_INFO_CMPM_CHIP = a_TXT_INFO_CMPM_CHIP;
    }

    void TBSW0160::set_TXT_RSTD_ATLZ_CHIP( const std::string& a_TXT_RSTD_ATLZ_CHIP )
    {
        m_TXT_RSTD_ATLZ_CHIP = a_TXT_RSTD_ATLZ_CHIP;
    }

    void TBSW0160::set_IND_NVL_SGRA_KMRC( const std::string& a_IND_NVL_SGRA_KMRC )
    {
        m_IND_NVL_SGRA_KMRC = a_IND_NVL_SGRA_KMRC;
    }

    void TBSW0160::set_IND_MTDO_VRFC_PORT( const std::string& a_IND_MTDO_VRFC_PORT )
    {
        m_IND_MTDO_VRFC_PORT = a_IND_MTDO_VRFC_PORT;
    }

    void TBSW0160::set_IND_PRSC_SNHA( const std::string& a_IND_PRSC_SNHA )
    {
        m_IND_PRSC_SNHA = a_IND_PRSC_SNHA;
    }

    void TBSW0160::set_DAT_CNFR_PAUZ( dbm_datetime_t a_DAT_CNFR_PAUZ )
    {
        m_DAT_CNFR_PAUZ = a_DAT_CNFR_PAUZ;
        m_DAT_CNFR_PAUZ_ind_null = 0;
    }

    void TBSW0160::set_NUM_SEQ_UNC_CNFR( unsigned long a_NUM_SEQ_UNC_CNFR )
    {
        m_NUM_SEQ_UNC_CNFR = a_NUM_SEQ_UNC_CNFR;
        m_NUM_SEQ_UNC_CNFR_ind_null = 0;
    }

    void TBSW0160::SetNumeroSequencialCartaoValidacaoChip( unsigned long paramNumeroSequencialCartaoValidacaoChip )
    {
        numeroSequencialCartaoValidacaoChip = paramNumeroSequencialCartaoValidacaoChip;
        indNullNumeroSequencialCartaoValidacaoChip = 0;
    }

    unsigned long TBSW0160::get_DAT_MOV_TRAN( ) const
    {
        return m_DAT_MOV_TRAN;
    }

    unsigned long TBSW0160::get_NUM_SEQ_UNC( ) const
    {
        return m_NUM_SEQ_UNC;
    }

    const std::string& TBSW0160::get_IND_RD_ORG( ) const
    {
        return m_IND_RD_ORG;
    }

    const std::string& TBSW0160::get_COD_PGM_AUT( ) const
    {
        return m_COD_PGM_AUT;
    }

    const std::string& TBSW0160::get_TXT_RLCD_CHIP( ) const
    {
        return m_TXT_RLCD_CHIP;
    }

    const std::string& TBSW0160::get_TXT_INFO_CMPM_CHIP( ) const
    {
        return m_TXT_INFO_CMPM_CHIP;
    }

    const std::string& TBSW0160::get_TXT_RSTD_ATLZ_CHIP( ) const
    {
        return m_TXT_RSTD_ATLZ_CHIP;
    }

    const std::string& TBSW0160::get_IND_NVL_SGRA_KMRC( ) const
    {
        return m_IND_NVL_SGRA_KMRC;
    }

    const std::string& TBSW0160::get_IND_MTDO_VRFC_PORT( ) const
    {
        return m_IND_MTDO_VRFC_PORT;
    }

    const std::string& TBSW0160::get_IND_PRSC_SNHA( ) const
    {
        return m_IND_PRSC_SNHA;
    }

    dbm_datetime_t TBSW0160::get_DAT_CNFR_PAUZ( ) const
    {
        return m_DAT_CNFR_PAUZ;
    }

    unsigned long TBSW0160::get_NUM_SEQ_UNC_CNFR( ) const
    {
        return m_NUM_SEQ_UNC_CNFR;
    }

    unsigned long TBSW0160::GetNumeroSequencialCartaoValidacaoChip( ) const
    {
        return numeroSequencialCartaoValidacaoChip;
    }

} //namespace dbaccess_common
