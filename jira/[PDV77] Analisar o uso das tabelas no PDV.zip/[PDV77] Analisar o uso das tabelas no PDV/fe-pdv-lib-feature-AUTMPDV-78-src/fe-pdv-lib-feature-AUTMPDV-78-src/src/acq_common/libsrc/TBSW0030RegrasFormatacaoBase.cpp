    /*
Copyright 2018 Rede S.A.
********************** MODIFICACOES ************************
Autor    : Celso Sata
Data     : 03/08/2018
Empresa  : FIS
Descricao: Impressao do saldo no slip de cartao de debito e credito PDV 
           Alteracao do texto SALDOVOUCHER para SALDODISP em transacoes Voucher PDV 
           Armazenar o campo "Origem de resposta da autorizacao" em transacoes PDV Elo Debito 
           Correcoes do FE-PDV 
ID       : AM 230.883
************************************************************
Autor    : Renato de Camargo
Data     : 08/03/2019
Empresa  : REDE
Descricao: EAK-1435 - Correcao de Status da Pre-Autorizacao
ID       : BIP 244842 
************************************************************
Autor    : Eduardo De Souza
Data     : 09/05/2019
Empresa  : REDE
Descricao: EAK-1517 - Correcao erro cartao Diners 19 digitos
ID       : AM 248.141
************************************************************
Autor    : Daniel Nava
Data     : 16/12/2019
Empresa  : REDE
Descricao: EAK-1899 - Inclusao da regra do IND_TRK para resumo de vendas
ID       : AM 248.141
************************************************************
Autor    : Daniel Nava
Data     : 27/12/2019
Empresa  : Leega
Descricao: EAK-1994 - Campos de autorizacao nulos para advice de transacao negada localmente
ID       : AM 248.141
************************************************************
*/

#include <cstring>
#include<TBSW0030RegrasFormatacaoBase.hpp>
#include <sstream>
#include <AcqUtils.hpp>
#include <string>
#include <shcdef.h>

TBSW0030RegrasFormatacaoBase::TBSW0030RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0030RegrasFormatacaoBase::~TBSW0030RegrasFormatacaoBase( )
{
}

void TBSW0030RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DTH_GMT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_GMT( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_GMT( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DTH_INI_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_INI_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_INI_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DAT_CTB_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_CTB_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_CTB_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_MSG_ISO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MSG_ISO( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MSG_ISO( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_PCM_ISO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PCM_ISO( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PCM_ISO( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_DTLH_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_DTLH_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_DTLH_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_VD( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_VD( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_PLN_PGMN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_PLN_PGMN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_PLN_PGMN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_CTGR_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CTGR_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CTGR_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_CMPM_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CMPM_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CMPM_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_RD_ORG( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_RD_ORG( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_RD_ORG( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_ESTB( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ESTB( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ESTB( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_TERM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TERM( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TERM( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_STAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_STAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_STAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_TCNL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_TCNL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_TCNL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_TERM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_TERM( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_TERM( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_RAM_ATVD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_RAM_ATVD( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_RAM_ATVD( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_POS_ENTR_MODO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_POS_ENTR_MODO( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_POS_ENTR_MODO( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_BNDR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_BNDR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_BNDR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_ID_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ID_CAR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ID_CAR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_PAIS_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PAIS_CAR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PAIS_CAR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_CAR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_CAR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DAT_VLD_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_VLD_CAR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_VLD_CAR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_TRK( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_TRK( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_TRK( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_CPTR_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_CPTR_CVC_2( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_CPTR_CVC_2( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_CVC_2( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_CVC_2( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_TRK_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TRK_CAR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TRK_CAR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_SERV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_SERV( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_SERV( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_SERV_SNHA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_SERV_SNHA( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_SERV_SNHA( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_ID_PREV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_ID_PREV( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_ID_PREV( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::VAL_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::VAL_TOTL_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TOTL_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TOTL_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_MOED( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MOED( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MOED( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_CV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_CV( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_CV( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_AUT( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_AUT( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_MOT_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MOT_AUT( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MOT_AUT( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_MOT_RSPS( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_MOT_RSPS( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_MOT_RSPS( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_MOT_RSPS_EXT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MOT_RSPS_EXT( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MOT_RSPS_EXT( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_MOT_SW( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MOT_SW( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MOT_SW( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_STTU_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_STTU_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DTH_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_STTU_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_STTU_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_PROD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PROD( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PROD( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_RSMO_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_RSMO_VD( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_RSMO_VD( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DAT_RSMO_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_RSMO_VD( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_RSMO_VD( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_LOC_ESTB( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_LOC_ESTB( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_LOC_ESTB( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_TERM_RLCD_CHIP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_TERM_RLCD_CHIP( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_TERM_RLCD_CHIP( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_DFZM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_DFZM( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_DFZM( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_ESTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_ESTR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_ESTR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_CPTRDO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_CPTRDO( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_CPTRDO( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_AGND_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_AGND_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_AGND_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_IMPR_CPOM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_IMPR_CPOM( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_IMPR_CPOM( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_EMSR_MTC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_EMSR_MTC( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_EMSR_MTC( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_DA_RLCD_CHIP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_DA_RLCD_CHIP( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_DA_RLCD_CHIP( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_DA_RLCD_IATA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_DA_RLCD_IATA( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_DA_RLCD_IATA( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_TRAN_REFD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_TRAN_REFD( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_TRAN_REFD( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_TRAN_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_TRAN_ORGL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_TRAN_ORGL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DAT_EXPC_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_EXPC_TRAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_EXPC_TRAN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::VAL_TRAN_DLR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TRAN_DLR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TRAN_DLR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::VAL_COT_DLR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_COT_DLR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_COT_DLR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_CTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CTR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CTR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::VAL_TX( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TX( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TX( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_REF_RESTANTE( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_REF_RESTANTE( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_REF_RESTANTE( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_CNDC_CPTR_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CNDC_CPTR_PAUZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CNDC_CPTR_PAUZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_ENT_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_ENT_PAUZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_ENT_PAUZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_OPER_CNFR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_OPER_CNFR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_OPER_CNFR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::PRCN_TX_RISC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_PRCN_TX_RISC( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_PRCN_TX_RISC( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::VAL_TX_RISC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TX_RISC( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TX_RISC( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_CNDC_CPTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CNDC_CPTR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CNDC_CPTR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ACQR_ORGL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ACQR_ORGL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ACQR_ORGL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ACQR_ORGL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ACQR_ORGL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ACQR_ORGL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_SITE_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ISSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ISSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_HOST_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ISSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ISSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_FE_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ISSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ISSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ACQR_ATLZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ACQR_ATLZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ACQR_ATLZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ACQR_ATLZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ACQR_ATLZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ACQR_ATLZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TXT_DA_ADIC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_DA_ADIC_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_DA_ADIC_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::TIP_MODL_CPTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_MODL_CPTR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_MODL_CPTR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DTH_TRAN_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_TRAN_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_TRAN_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DAT_LQDC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_LQDC_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_LQDC_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_ISTT_ACQR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_ISTT_ACQR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_ISTT_ACQR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_ISTT_FRWD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_ISTT_FRWD( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_ISTT_FRWD( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_RSPS_DTLH_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_RSPS_DTLH_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_RSPS_DTLH_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_RSTD_NUM_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_RSTD_NUM_CVC_2( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_RSTD_NUM_CVC_2( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_SERV_TRK_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_SERV_TRK_CAR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_SERV_TRK_CAR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_VLDC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VLDC_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VLDC_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_AUT( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_AUT( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_DA_RLCD_KMRC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_DA_RLCD_KMRC( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_DA_RLCD_KMRC( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_TRAN_SEM_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_TRAN_SEM_ORGL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_TRAN_SEM_ORGL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::DAT_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_PAUZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_PAUZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_SEQ_UNC_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC_PAUZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC_PAUZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_TRAN_CAD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TRAN_CAD( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TRAN_CAD( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_AUT_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_AUT_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_AUT_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_NTWK_ID_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_NTWK_ID_ACQR_ATLZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_NTWK_ID_ACQR_ATLZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_NTWK_ID_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_NTWK_ID_ACQR_ORGL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_NTWK_ID_ACQR_ORGL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_NTWK_ID_ROUT_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_NTWK_ID_ROUT_ATLZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_NTWK_ID_ROUT_ATLZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_NTWK_ID_ROUT_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_NTWK_ID_ROUT_ORGL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_NTWK_ID_ROUT_ORGL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_NTWK_ID_ISSR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_NTWK_ID_ISSR_ATLZ( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_NTWK_ID_ISSR_ATLZ( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_NTWK_ID_ISSR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_NTWK_ID_ISSR_ORGL( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_NTWK_ID_ISSR_ORGL( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_RAM_MCC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_RAM_MCC( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_RAM_MCC( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_CNDC_CPTR_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CNDC_CPTR_EMSR( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CNDC_CPTR_EMSR( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_PROD_CDST( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PROD_CDST( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PROD_CDST( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_SERV_CORP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_SERV_CORP( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_SERV_CORP( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_EMP_ADQT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_EMP_ADQT( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_EMP_ADQT( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_PDV_EXT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_PDV_EXT( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_PDV_EXT( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::NUM_PDV_VAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_PDV_VAN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_PDV_VAN( tbsw0030, tbsw0030_params );
    }
}
void TBSW0030RegrasFormatacaoBase::COD_DSPO_NFC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_DSPO_NFC( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_DSPO_NFC( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_GRU_CLAS_RAM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_GRU_CLAS_RAM( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_GRU_CLAS_RAM( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::IND_TRAN_TKN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_TRAN_TKN( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_TRAN_TKN( tbsw0030, tbsw0030_params );
    }
}

void TBSW0030RegrasFormatacaoBase::COD_ORG_APRV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_ORG_APRV( tbsw0030, tbsw0030_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_ORG_APRV( tbsw0030, tbsw0030_params );
    }
}


//=========================================
//              UPDATE
//=========================================

void TBSW0030RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_DTH_GMT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_DTH_INI_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_DAT_CTB_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( ( tbsw0030_params.settlement_date > 1 ) && // zerado significa que nao veio do emissor, quando da timeout o shc do FE Emissor coloca 1
        ( tbsw0030_params.msg_name.compare("VEND_DBT_PREDAT") != 0           &&
          tbsw0030_params.msg_name.compare("EST_VEND_DBT_PREDAT") != 0       &&  tbsw0030_params.msg_name.compare("DESF_VEND_DBT_PREDAT") != 0  &&
          tbsw0030_params.msg_name.compare("VEND_DBT_DIST_PREDAT") != 0      &&
          tbsw0030_params.msg_name.compare("EST_VEND_DBT_DIST_PREDAT") != 0  &&  tbsw0030_params.msg_name.compare("DESF_VEND_DBT_DIST_PREDAT") != 0 &&
          tbsw0030_params.msg_category.compare("CONF_PREAUT") != 0           &&
          tbsw0030_params.msg_name.compare("ADV_VEND_DIST_PREDAT_NEG") != 0  &&  tbsw0030_params.msg_name.compare("ADV_VEND_DBT_PREDAT_NEG") != 0 ) )
    {
        tbsw0030.set_DAT_CTB_TRAN( AcqUtils::dateTime( tbsw0030_params.settlement_date, 0 ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_MSG_ISO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_PCM_ISO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_TIP_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_TIP_DTLH_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_TIP_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_TIP_PLN_PGMN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_CTGR_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_CMPM_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    // J01_2020 - Novo Debito da Mastercard - INICIO
    if ( ( tbsw0030_params.iss_name.compare( "MAESTRO" ) == 0 )
        && ( tbsw0030_params.subtranscode == 7 || tbsw0030_params.subtranscode == 8 )
        )
    {
        tbsw0030.set_COD_CMPM_TRAN( tbsw0030_params.subtranscode );
    }
    // J01_2020 - Novo Debito da Mastercard - FIM
}

void TBSW0030RegrasFormatacaoBase::update_NUM_RD_ORG( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_ESTB( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_TERM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_STAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_TIP_TCNL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_TIP_TERM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_RAM_ATVD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_POS_ENTR_MODO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_BNDR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_ID_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( ( tbsw0030_params.iss_name.compare( "MASTERCARD" ) == 0 ||
           tbsw0030_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 ||
           tbsw0030_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
           tbsw0030_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 )
         && tbsw0030_params.mc_info_ica.size( ) > 0
         && tbsw0030_params.is_desfaz_estorno.compare( "TRUE" ) != 0
         && tbsw0030_params.msg_category.compare( "CONF_PREAUT" ) != 0
         && tbsw0030_params.settlement_date != 0            // zerado significa que nao veio do emissor
         && tbsw0030_params.respcode.compare( "8" ) != 0  ) // Quando timeout
    {
        oasis_dec_t l_dect;
        dbm_chartodec( &l_dect, tbsw0030_params.mc_info_ica.c_str( ), 0 );
        tbsw0030.set_NUM_ID_CAR( l_dect );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_PAIS_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.iss_name.compare( "DINERS_NACIONAL" ) == 0 )
    {
        tbsw0030.set_COD_PAIS_CAR( "BRA" );
    }
    else if( tbsw0030_params.mc_info_country.length( ) > 0 )
    {
        tbsw0030.set_COD_PAIS_CAR( tbsw0030_params.mc_info_country );
    }
    else
    {
        tbsw0030.set_COD_PAIS_CAR( "000" );
    }
}

void TBSW0030RegrasFormatacaoBase::update_NUM_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_DAT_VLD_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_TRK( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_CPTR_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO E USADO ATUALMENTE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_TRK_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_SERV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_SERV_SNHA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.has_pin.compare( "TRUE" ) == 0 )
    {
        if( tbsw0030_params.iss_name.compare( "VISA_CREDITO" ) == 0 )
        {
            if( tbsw0030_params.addresponse.length( ) >= 2 )
            {
                tbsw0030.set_COD_SERV_SNHA( tbsw0030_params.addresponse.substr( 0, 2 ).c_str( ) );
            }
        }
        else if ( tbsw0030_params.status.compare( "2" ) == 0 && 
                  tbsw0030_params.quem_negou.compare( "ISS" ) != 0 )
        {
            tbsw0030.set_COD_SERV_SNHA( "RW" );
        }
    }
}

void TBSW0030RegrasFormatacaoBase::update_IND_ID_PREV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_VAL_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_VAL_TOTL_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_MOED( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_CV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_category.compare( "ADV_NEGADO" ) == 0 && !strcmp(getenv( "NOM_FE_ACQR" ), "FEPDV" ) )
    {
        tbsw0030.set_NUM_AUT( NULL );
    }
    else if ( tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0030.set_NUM_AUT( tbsw0030_params.authnum );
    }
    else if( tbsw0030_params.authnum.empty( ) == false &&
             tbsw0030_params.de38IssOff.compare( "FALSE" ) == 0
           )
    {
        std::string authnum("");
        authnum = AcqUtils::converteAuthnum( tbsw0030_params.authnum );
        if ( authnum.size( ) == 6 )
        {
            authnum.erase( 0, 1 ); //sao gravados apenas os 5 ultimos digitos do de 38 convertido...
            tbsw0030.set_NUM_AUT( authnum );
        }
        else
        {
            std::string str;
            str.clear();
            str.append("Erro na funcao AcqUtils::converteAuthnum, authnum com tamanho menor que 6...");
            m_log->write( logger::LEVEL_DEBUG, str.c_str() );
        }
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_MOT_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_MOT_RSPS( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    gen_NUM_MOT_RSPS( tbsw0030, tbsw0030_params );
}

void TBSW0030RegrasFormatacaoBase::update_COD_MOT_RSPS_EXT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    char l_buffer[ 3 + 1 ] = { 0 };

    if ( ( tbsw0030_params.iss_name.compare( "ELO_CRT_FULL"   ) == 0 ||
         tbsw0030_params.iss_name.compare( "ELO_DBT_FULL" ) == 0 ) &&
         tbsw0030_params.alphaResponseCode.size( ) > 0 )
    {
        if ( tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) != 0 )
        {
            tbsw0030.set_COD_MOT_RSPS_EXT( tbsw0030_params.alphaResponseCode );
            return;
        }
    }
    
    sprintf( l_buffer, "%0.3d", tbsw0030_params.ext_network_code );
    tbsw0030.set_COD_MOT_RSPS_EXT( std::string( l_buffer ) );
}

void TBSW0030RegrasFormatacaoBase::update_COD_MOT_SW( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.cod_mtv_sw.length( ) > 0 && tbsw0030_params.cod_mtv_sw.length( ) <= 3 )
    {
        tbsw0030.set_COD_MOT_SW( tbsw0030_params.cod_mtv_sw );
    }
    else
    {
        tbsw0030.set_COD_MOT_SW( "000" );
    }
}

void TBSW0030RegrasFormatacaoBase::update_IND_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    // TODO: Verificar porque eh necessario vrf. az_reason_code ao inves de somente assumir o conteudo da var. status.
    if ( tbsw0030_params.az_reason_code > 0 && tbsw0030_params.pb_reason_code != 87 //pb_reason_code=87 - trn. aprovada por Saldo Disponivel Voucher
        && (tbsw0030_params.msg_category.compare( "PAGAMENTO" ) != 0) && (tbsw0030_params.msg_name.compare( "SONDA" ) != 0)
        )
    {
        tbsw0030.set_IND_STTU_TRAN( "2" );
    }
    else
    {
       tbsw0030.set_IND_STTU_TRAN( tbsw0030_params.status );
    }
}

void TBSW0030RegrasFormatacaoBase::update_DTH_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    gen_DTH_STTU_TRAN( tbsw0030, tbsw0030_params );
}

void TBSW0030RegrasFormatacaoBase::update_COD_PROD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_RSMO_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_DAT_RSMO_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NOM_LOC_ESTB( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_TERM_RLCD_CHIP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_DFZM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_ESTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_CPTRDO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    gen_IND_CPTRDO( tbsw0030, tbsw0030_params );
}

void TBSW0030RegrasFormatacaoBase::update_IND_AGND_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_IMPR_CPOM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.trn_tem_cupom.compare( "S" ) == 0 )
    {
        tbsw0030.set_IND_IMPR_CPOM( std::string( "S" ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_IND_EMSR_MTC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_DA_RLCD_CHIP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_DA_RLCD_IATA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_TRAN_REFD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    gen_IND_TRAN_REFD( tbsw0030, tbsw0030_params );
}

void TBSW0030RegrasFormatacaoBase::update_TIP_TRAN_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_DAT_EXPC_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_VAL_TRAN_DLR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_VAL_COT_DLR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_CTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_VAL_TX( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_REF_RESTANTE( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_CNDC_CPTR_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_TIP_ENT_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_OPER_CNFR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if (std::string(getenv( "NOM_FE_ACQR" )) == "FEPDV" && tbsw0030_params.msg_name.compare("SONDA") == 0 &&
        (tbsw0030_params.status.compare( "1" ) == 0 || tbsw0030_params.status.compare( "3" ) == 0 || tbsw0030_params.status.compare( "4" ) == 0)
       )
    {
        tbsw0030.set_COD_OPER_CNFR( std::string( "SONDA" ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_PRCN_TX_RISC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_VAL_TX_RISC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_CNDC_CPTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NOM_SITE_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( atoi( tbsw0030_params.respcode.c_str( ) ) == 0 || (atoi( tbsw0030_params.respcode.c_str( ) ) != 0 && tbsw0030_params.quem_negou.compare( "ISS" ) == 0))
    {
        if ( tbsw0030_params.nom_site_issr != "" )
        {
            tbsw0030.set_NOM_SITE_ISSR( tbsw0030_params.nom_site_issr );
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
}

void TBSW0030RegrasFormatacaoBase::update_NOM_HOST_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( atoi( tbsw0030_params.respcode.c_str( ) ) == 0 || (atoi( tbsw0030_params.respcode.c_str( ) ) != 0 && tbsw0030_params.quem_negou.compare( "ISS" ) == 0))
    {
        if ( tbsw0030_params.nom_host_issr != "" )
        {
            tbsw0030.set_NOM_HOST_ISSR( tbsw0030_params.nom_host_issr );
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
}

void TBSW0030RegrasFormatacaoBase::update_NOM_FE_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( atoi( tbsw0030_params.respcode.c_str( ) ) == 0 || (atoi( tbsw0030_params.respcode.c_str( ) ) != 0 && tbsw0030_params.quem_negou.compare( "ISS" ) == 0))
    {
        if ( tbsw0030_params.nom_fe_issr != "" )
        {
            tbsw0030.set_NOM_FE_ISSR( tbsw0030_params.nom_fe_issr );
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
}

void TBSW0030RegrasFormatacaoBase::update_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare("ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_EST_ADV_VEND_VCH") != 0 &&
        !( tbsw0030_params.msg_name.compare("DESF_EST_VEND_VCH_GEN") == 0 && tbsw0030_params.orig_transcode == 12 ) &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_CJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_SJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_PREDAT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH_NEG") != 0 )
    {
        tbsw0030.set_NOM_SITE_ACQR_ATLZ( std::string( getenv( "NOM_SITE_ACQR" ) ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare("ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_EST_ADV_VEND_VCH") != 0 &&
        !( tbsw0030_params.msg_name.compare("DESF_EST_VEND_VCH_GEN") == 0 && tbsw0030_params.orig_transcode == 12 ) &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_CJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_SJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_PREDAT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH_NEG") != 0 )
    {
        tbsw0030.set_NOM_HOST_ACQR_ATLZ( std::string( getenv( "NOM_HOST_ACQR" ) ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare("ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_EST_ADV_VEND_VCH") != 0 &&
        !( tbsw0030_params.msg_name.compare("DESF_EST_VEND_VCH_GEN") == 0 && tbsw0030_params.orig_transcode == 12 ) &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_CJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_SJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_PREDAT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH_NEG") != 0 )
    {
        tbsw0030.set_NOM_FE_ACQR_ATLZ( std::string( getenv( "NOM_FE_ACQR" ) ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_TXT_DA_ADIC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    std::string l_string;

    if ( ( tbsw0030_params.iss_name.compare( "VISA_CREDITO" ) == 0 )    || ( tbsw0030_params.iss_name.compare( "VISA_ELECTRON" ) == 0 ) )
    {
        l_string =  tbsw0030_params.de_adc_ete;
    }
    else if ( ( tbsw0030_params.iss_name.compare( "MASTERCARD" ) == 0 )      || ( tbsw0030_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 )  ||
              ( tbsw0030_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 )   || ( tbsw0030_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ) ||
              ( tbsw0030_params.iss_name.compare( "CALCARD" ) == 0 )         || ( tbsw0030_params.iss_name.compare( "SOROCRED_FULL" ) == 0 )     ||
              ( tbsw0030_params.iss_name.compare( "CREDSYSTEM_FULL" ) == 0 ) || ( tbsw0030_params.iss_name.compare( "CABAL_CRT" ) == 0 )         ||
              ( tbsw0030_params.iss_name.compare( "CREDZ" ) == 0 )           || ( tbsw0030_params.iss_name.compare( "BANESCARD_CRT_FULL" ) == 0 ) ||
              ( tbsw0030_params.iss_name.compare( "BANESCARD_CRT_VAN" ) == 0 ) ||
              ( tbsw0030_params.iss_name.compare( "MAESTRO" ) == 0 )         || ( tbsw0030_params.iss_name.compare( "MASTER_HIPER_DBT" ) == 0 )  ||
              ( tbsw0030_params.iss_name.compare( "HIPERCARD_DBT" ) == 0 )   || ( tbsw0030_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ) ||
              ( tbsw0030_params.iss_name.compare( "CABAL_DBT" ) == 0 )       || ( tbsw0030_params.iss_name.compare( "BANESCARD_DBT_FULL" ) == 0 ) ||
              ( tbsw0030_params.iss_name.compare( "BANESCARD_DBT_VAN" ) == 0 ) )
    {
        if ( tbsw0030_params.de_adc_ete.length( ) > 0 )
            l_string =  tbsw0030_params.de_adc_ete;
        else
            l_string =  " ";
    }
    else if ( ( tbsw0030_params.iss_name.compare( "ELO_CRT" ) == 0 ) || ( tbsw0030_params.iss_name.compare( "ELO_DBT" ) == 0 ) ||
                ( tbsw0030_params.iss_name.compare( "ALELO" ) == 0 ) )
    {
        l_string =  tbsw0030_params.numero_cv_ad;
    }
    else if ( ( tbsw0030_params.iss_name.compare( "AMEX" ) == 0 )            || ( tbsw0030_params.iss_name.compare( "AMEX_FULL" ) == 0 )       ||
              ( tbsw0030_params.iss_name.compare( "ELO_CRT_FULL" ) == 0 )    || ( tbsw0030_params.iss_name.compare( "ELO_DBT_FULL" ) == 0 )    ||
              ( tbsw0030_params.iss_name.compare( "DINERS_NACIONAL" ) == 0 ) || ( tbsw0030_params.iss_name.compare( "DINERS_INTERNAC" ) == 0 ) ||
              ( tbsw0030_params.iss_name.compare( "JCB_CRT" ) == 0 )         ||
              ( tbsw0030_params.iss_name.compare( "HIPERCARD_VAN" ) == 0 )   || ( tbsw0030_params.iss_name.compare( "CREDSYSTEM_VAN" ) == 0 )  ||
              ( tbsw0030_params.iss_name.compare( "COOPERCRED_VAN" ) == 0 )  || ( tbsw0030_params.iss_name.compare( "SOROCRED_VAN" ) == 0 )    ||
              ( tbsw0030_params.iss_name.compare( "PL_FININVEST" ) == 0 )    || ( tbsw0030_params.iss_name.compare( "PL_BRADESCO" ) == 0 )     ||
              ( tbsw0030_params.iss_name.compare( "PL_BANCOBRASIL" ) == 0 )  || ( tbsw0030_params.iss_name.compare( "PL_CREDSYSTEM" ) == 0 )   ||
              ( tbsw0030_params.iss_name.compare( "PL_PORTOSEGURO" ) == 0 )  ||
              ( tbsw0030_params.iss_name.compare( "BNB_CLUBE" ) == 0 )       || ( tbsw0030_params.iss_name.compare( "PLANVALE" ) == 0 )        ||
              ( tbsw0030_params.iss_name.compare( "GREEN_CARD" ) == 0 )      || ( tbsw0030_params.iss_name.compare( "TOP_PREMIUM" ) == 0 )     ||
              ( tbsw0030_params.iss_name.compare( "SODEXO" ) == 0 )          || ( tbsw0030_params.iss_name.compare( "SMARTNET" ) == 0 )        ||
              ( tbsw0030_params.iss_name.compare( "NUTRICASH" ) == 0 )       || ( tbsw0030_params.iss_name.compare( "CABAL" ) == 0 )           ||
              ( tbsw0030_params.iss_name.compare( "VEROCHEQUE" ) == 0 )      || ( tbsw0030_params.iss_name.compare( "VCH_SOROCRED" ) == 0 )    ||
              ( tbsw0030_params.iss_name.compare( "COOPER_CRED" ) == 0 )     || ( tbsw0030_params.iss_name.compare( "TICKET" ) == 0 )          ||
              ( tbsw0030_params.iss_name.compare( "TICKET_CHIP" ) == 0 )     || ( tbsw0030_params.iss_name.compare( "VCH_VR" ) == 0 ) )
    {
        l_string =  " ";
    }
    else if ( tbsw0030_params.iss_name.compare( "UPI" ) == 0 )
    {
        l_string =  tbsw0030_params.txt_adic_pos;
    }
    else  // others, if any
    {
        l_string =  tbsw0030_params.de_adc_ete;
    }

    if ( tbsw0030_params.az_reason_code == 0 && strlen( l_string.c_str() ) > 0 &&
         ( tbsw0030_params.sender_mbname.compare( "SharedCash" ) == 0  ||
           tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 ) )
                                                                        // Assume the request had been sent to the issuer and
    {                                                                  // the response is coming from SHC. Otherwise, NULL.
        tbsw0030.set_TXT_DA_ADIC_EMSR( l_string );
    }
}

void TBSW0030RegrasFormatacaoBase::update_TIP_MODL_CPTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( ((tbsw0030_params.msg_category.compare( "VENDA" ) == 0 ||
            tbsw0030_params.msg_category.compare( "CONF_PREAUT" ) == 0) &&
        (tbsw0030_params.quem_negou.compare( "ISS" ) == 0 || tbsw0030_params.quem_negou.empty( ) == true)) ||
        (tbsw0030_params.msg_category.compare( "ADV_APROVADO" ) == 0 ||
            tbsw0030_params.msg_category.compare( "ADV_NEGADO" ) == 0) )
    {
        tbsw0030.set_TIP_MODL_CPTR( tbsw0030_params.ind_modl_cptr );
    }
}

void TBSW0030RegrasFormatacaoBase::update_DTH_TRAN_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.iss_name.compare( "UPI" ) == 0 && tbsw0030_params.dat_mov_tran_emsr != 0 )
    {
        tbsw0030.set_DTH_TRAN_EMSR( AcqUtils::dateTime( tbsw0030_params.dat_mov_tran_emsr, tbsw0030_params.hor_tran_emsr ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_DAT_LQDC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.iss_name.compare( "UPI" ) == 0 && tbsw0030_params.settlement_date != 0 && tbsw0030_params.settlement_date != 1 )
    {
        tbsw0030.set_DAT_LQDC_EMSR( AcqUtils::dateTime( tbsw0030_params.settlement_date, 0 ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_ISTT_ACQR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.iss_name.compare( "UPI" ) == 0 && tbsw0030_params.cod_istt_acqr.empty( ) != true &&
        ( tbsw0030_params.quem_negou.empty( ) == true || tbsw0030_params.quem_negou.compare( "ISS" ) == 0 ) )
    {
        tbsw0030.set_COD_ISTT_ACQR( 27480076 );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_ISTT_FRWD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.iss_name.compare( "UPI" ) == 0 && tbsw0030_params.cod_istt_frwd.empty( ) != true &&
        ( tbsw0030_params.quem_negou.empty( ) == true || tbsw0030_params.quem_negou.compare( "ISS" ) == 0 ) )
    {
        tbsw0030.set_COD_ISTT_FRWD( 27480076 );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_RSPS_DTLH_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.iss_name.compare( "UPI" ) == 0 && tbsw0030_params.respcode.compare( "8" ) != 0 &&
        tbsw0030_params.is_desfaz_estorno.compare( "TRUE" ) != 0 && tbsw0030_params.msg_category.compare( "CONF_PREAUT" ) != 0 &&
        tbsw0030_params.msg_name.compare( "DESF_CONF_PREAUT_GEN" ) != 0 )
    {
        tbsw0030.set_COD_RSPS_DTLH_EMSR( tbsw0030_params.cod_rsps_dtlh_emsr );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_RSTD_NUM_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( ( tbsw0030_params.iss_name.compare( "VISA_CREDITO" ) == 0 || tbsw0030_params.iss_name.compare( "VISA_ELECTRON" ) == 0 ) &&
         tbsw0030_params.addresponse.length( ) >= 11 )
    {
        tbsw0030.set_COD_RSTD_NUM_CVC_2( tbsw0030_params.addresponse.substr( 10, 1 ).c_str( ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_SERV_TRK_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_VLDC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( ( tbsw0030_params.iss_name.compare( "VISA_CREDITO" ) == 0 || tbsw0030_params.iss_name.compare( "VISA_ELECTRON" ) == 0 ) &&
         tbsw0030_params.ext_refnum.length( ) >= 6 )
    {
        tbsw0030.set_COD_VLDC_EMSR( tbsw0030_params.ext_refnum.substr( 2, 4 ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_IND_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( ( tbsw0030_params.iss_name.compare( "VISA_CREDITO" ) == 0 || 
          tbsw0030_params.iss_name.compare( "VISA_ELECTRON" ) == 0 ||
          tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 ||
          tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 ) &&
        tbsw0030_params.addresponse.length( ) >= 1 && tbsw0030_params.respcode.compare( "8" ) != 0 )
    {
        tbsw0030.set_IND_AUT( tbsw0030_params.addresponse.substr( 0, 1 ) );
    }
    else
    {
        tbsw0030.set_IND_AUT( " " );
    }
}

void TBSW0030RegrasFormatacaoBase::update_IND_DA_RLCD_KMRC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_TRAN_SEM_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_DAT_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_SEQ_UNC_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_TRAN_CAD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_AUT_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_category.compare( "ADV_NEGADO" ) == 0 && !strcmp(getenv( "NOM_FE_ACQR" ), "FEPDV" ) )
    {
        tbsw0030.set_COD_AUT_EMSR( NULL );
    }
    else if( tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0030.set_COD_AUT_EMSR( tbsw0030_params.orig_authnum );
    }
    //TODO: PARA VOUCHER IMPLEMENTAR PROXIMO CICLO....
    else if( tbsw0030_params.de38IssOff.compare( "FALSE" ) == 0 )
    {
        if( tbsw0030_params.iss_name.compare( "AMEX_FULL" ) == 0 &&
            ( tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 || tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 )
          )
        {
            // Nao deve vir DE038 do emissor - Faz nada, manter NULL
        }
        else
        if( tbsw0030_params.iss_name.compare( "GREEN_CARD" ) == 0 &&
            ( tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 || tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 )
          )
        {
            // Nao deve vir DE038 e gncd8583 desconsidera memso se vem DE127 para 0410 0430 - Faz nada, manter NULL
        }
        else
        if( tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 && tbsw0030_params.status.compare( "2" ) == 0 &&
            ( tbsw0030_params.iss_name.compare( "UPI" )             == 0  ||
              tbsw0030_params.iss_name.compare( "TICKET_CHIP" )     == 0  ||
              tbsw0030_params.iss_name.compare( "DINERS_INTERNAC" ) == 0
            )
          )
        {
            // Faz nada, manter NULL
        }
        else
        {
            tbsw0030.set_COD_AUT_EMSR( tbsw0030_params.authnum );
        }
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_NTWK_ID_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare("ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_EST_ADV_VEND_VCH") != 0 &&
        !( tbsw0030_params.msg_name.compare("DESF_EST_VEND_VCH_GEN") == 0 && tbsw0030_params.orig_transcode == 12 ) &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_CJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_SJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_PREDAT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH_NEG") != 0 )
    {
        tbsw0030.set_COD_NTWK_ID_ACQR_ATLZ( std::string( getenv( "NETWORKID" ) ) );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_NTWK_ID_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_NTWK_ID_ROUT_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare("ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_EST_ADV_VEND_VCH") != 0 &&
        !( tbsw0030_params.msg_name.compare("DESF_EST_VEND_VCH_GEN") == 0 && tbsw0030_params.orig_transcode == 12 ) &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_CJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_SJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_PREDAT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH_NEG") != 0 )
    {
        tbsw0030.set_COD_NTWK_ID_ROUT_ATLZ( tbsw0030_params.receive_inst_id );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_NTWK_ID_ROUT_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_NTWK_ID_ISSR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare("ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_CRT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_DBT") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("EST_ADV_VEND_VCH") != 0 &&
        tbsw0030_params.msg_name.compare("DESF_EST_ADV_VEND_VCH") != 0 &&
        !( tbsw0030_params.msg_name.compare("DESF_EST_VEND_VCH_GEN") == 0 && tbsw0030_params.orig_transcode == 12 ) &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_CJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_CRT_PARC_SJUROS_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_DBT_PREDAT_NEG") != 0 &&
        tbsw0030_params.msg_name.compare("ADV_VEND_VCH_NEG") != 0 )
    {
        tbsw0030.set_COD_NTWK_ID_ISSR_ATLZ( tbsw0030_params.issuer );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_NTWK_ID_ISSR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_RAM_MCC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_CNDC_CPTR_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.iss_name.compare( "VISA_ELECTRON" ) == 0 )
    {
        tbsw0030.set_COD_CNDC_CPTR_EMSR( tbsw0030_params.extrac_out_de60 );
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_PROD_CDST( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_SERV_CORP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_EMP_ADQT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_PDV_EXT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_NUM_PDV_VAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_DSPO_NFC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_COD_GRU_CLAS_RAM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::update_IND_TRAN_TKN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.iss_name.compare( "MASTERCARD" )        == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_CRT" )     == 0 ||
        tbsw0030_params.iss_name.compare( "MASTER_HIPER_CRT" )  == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
        tbsw0030_params.iss_name.compare( "MAESTRO" )           == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_DBT" )     == 0 ||
        tbsw0030_params.iss_name.compare( "MASTER_HIPER_DBT" )  == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ||
        tbsw0030_params.iss_name.compare( "VISA_CREDITO" )      == 0 ||
        tbsw0030_params.iss_name.compare( "VISA_ELECTRON" )     == 0
      )
    {
        if( tbsw0030_params.quem_negou.empty( ) == true && tbsw0030_params.tokenIdentifier.empty( ) == false )
        {
            tbsw0030.set_IND_TRAN_TKN( tbsw0030_params.tokenIdentifier );
        }
        else
        if( tbsw0030_params.quem_negou.compare( "ACQ" ) == 0      ||
           (tbsw0030_params.quem_negou.compare( "SWCORE" ) == 0 &&
            tbsw0030_params.tokenIdentifier.empty( ) == true )
          )
        {
            tbsw0030.set_IND_TRAN_TKN( " " );
        }
        if( ( tbsw0030_params.quem_negou.compare( "ISS" )        == 0 ||
              tbsw0030_params.quem_negou.compare( "SWCALLBACK" ) == 0 ||
              tbsw0030_params.quem_negou.compare( "SWCORE" )     == 0 ) &&
            tbsw0030_params.tokenIdentifier.empty( ) == false
          )
        {
            tbsw0030.set_IND_TRAN_TKN( tbsw0030_params.tokenIdentifier );
        }
    }
}

void TBSW0030RegrasFormatacaoBase::update_COD_ORG_APRV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.codigoOrigemRespostaAutorizacao.empty( ) == false && tbsw0030_params.msg_category.compare( "ESTORNO" ) != 0 &&  tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) != 0)
    {
        tbsw0030.SetCodOrgAprv( tbsw0030_params.codigoOrigemRespostaAutorizacao );
    }
}


//=========================================
//              INSERT
//=========================================

void TBSW0030RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_DAT_MOV_TRAN( tbsw0030_params.local_date );
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_NUM_SEQ_UNC( tbsw0030_params.refnum );
}

void TBSW0030RegrasFormatacaoBase::insert_DTH_GMT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.trandate > 0 )
    {
        dbm_datetime_t l_dth_gmt_unix = AcqUtils::dateTime( tbsw0030_params.trandate, tbsw0030_params.trantime );
        tbsw0030.set_DTH_GMT( l_dth_gmt_unix );
    }
    else
    {
        dbm_datetime_t l_dth_gmt_local = AcqUtils::dateTimeGMT( tbsw0030_params.local_date, tbsw0030_params.local_time );
        tbsw0030.set_DTH_GMT( l_dth_gmt_local );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_DTH_INI_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_DTH_INI_TRAN( AcqUtils::dateTime( tbsw0030_params.local_date, tbsw0030_params.local_time ) );
}

void TBSW0030RegrasFormatacaoBase::insert_DAT_CTB_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_DAT_CTB_TRAN( AcqUtils::dateTime( tbsw0030_params.local_date, 0 ) );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_MSG_ISO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_MSG_ISO( tbsw0030_params.msgtype );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_PCM_ISO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_PCM_ISO( tbsw0030_params.pcode );
}

void TBSW0030RegrasFormatacaoBase::insert_TIP_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_TIP_TRAN( tbsw0030_params.transcode );
}

void TBSW0030RegrasFormatacaoBase::insert_TIP_DTLH_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.tip_dtlh_tran.empty( ) == true )
    {
        WARNING_EMPTY_STRING;
        tbsw0030.set_TIP_DTLH_TRAN(" ");
    }
    else
    {
        tbsw0030.set_TIP_DTLH_TRAN( tbsw0030_params.tip_dtlh_tran );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_TIP_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    std::string l_tip_vd("0");

    if ( tbsw0030_params.msg_name.compare( "VEND_CRT" ) == 0 ||
         tbsw0030_params.msg_name.compare( "VEND_IATA_AVISTA" ) == 0 ||
         tbsw0030_params.msg_name.compare( "CONF_VEND_IATA" ) == 0 ||
         tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 ||
         tbsw0030_params.msg_name.compare( "CONF_PREAUT_3PERNA" ) == 0 ||
         tbsw0030_params.msg_name.compare( "CREDIARIO_SIMUL" ) == 0 || /* FBA - Crediario - Txn Simulacao */
         tbsw0030_params.msg_name.compare( "CREDIARIO_VENDA" ) == 0 ) /* FBA - Crediario - Txn Contratacao */
    {
        l_tip_vd = "1";
    }
    else if ( tbsw0030_params.msg_name.compare( "VEND_CRT_PARC_CJURO" ) == 0 ||
              tbsw0030_params.msg_name.compare( "CONF_VEND_CRT_PARC_CJURO" ) == 0 ||
              tbsw0030_params.msg_name.compare( "VEND_IATA_PARC_CJURO" ) == 0 ||
              tbsw0030_params.msg_name.compare( "CONF_VEND_IATA_PARC_CJURO" ) == 0 ||
              tbsw0030_params.msg_name.compare( "SIMU_CREDIARIO" ) == 0 ||
              tbsw0030_params.msg_name.compare( "CONTRA_CRED"  ) == 0 )
    {
        l_tip_vd = "2";
    }
    else if ( tbsw0030_params.msg_name.compare( "VEND_IATA_PARC_SJURO" ) == 0 ||
              tbsw0030_params.msg_name.compare( "VEND_CRT_PARC_SJURO" ) == 0 ||
              tbsw0030_params.msg_name.compare( "CONF_VEND_CRT" ) == 0 ||
              tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        l_tip_vd = "3";
    }

    tbsw0030.set_TIP_VD( l_tip_vd );
}

void TBSW0030RegrasFormatacaoBase::insert_TIP_PLN_PGMN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.acq_name.compare( "PL" ) == 0 &&
      ( tbsw0030_params.msg_category.compare( "VENDA" ) == 0 || tbsw0030_params.msg_category.compare( "CONSULTA" ) == 0 ) )
    {
        tbsw0030.set_TIP_PLN_PGMN( atol( tbsw0030_params.plano_pagamento.c_str( ) ) );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_CTGR_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.cd_ctg_trx.empty( ) == true )
    {
        WARNING_EMPTY_STRING;
        tbsw0030.set_COD_CTGR_TRAN(" ");
    }
    else
    {
        if ( ( tbsw0030_params.iss_name.compare( "MASTERCARD" ) == 0 ||
              tbsw0030_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 || tbsw0030_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
              tbsw0030_params.iss_name.compare( "HIPERCARD_DBT" ) == 0 || tbsw0030_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ||
               tbsw0030_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 || tbsw0030_params.iss_name.compare( "MASTER_HIPER_DBT" ) == 0 ||
               tbsw0030_params.iss_name.compare( "MAESTRO" ) == 0) &&
               tbsw0030_params.cd_ctg_trx.length( ) > 0 )
        {
            tbsw0030.set_COD_CTGR_TRAN( tbsw0030_params.cd_ctg_trx.substr( 0, 1 ) );
        }
        else
        {
            tbsw0030.set_COD_CTGR_TRAN(" ");
        }
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_CMPM_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_CMPM_TRAN( tbsw0030_params.subtranscode );
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_RD_ORG( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO DIFERENTE POS E PDV
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_ESTB( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_NUM_ESTB( tbsw0030_params.termloc );
    if (tbsw0030.get_NUM_ESTB() > 999999999)
        tbsw0030.set_NUM_ESTB( 0 );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_TERM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if(tbsw0030_params.termid.empty())
    {
        WARNING_EMPTY_STRING;
        tbsw0030.set_COD_TERM(" ");
    }
    else
    {
        tbsw0030.set_COD_TERM( tbsw0030_params.termid );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_STAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_NUM_STAN( tbsw0030_params.trace );
}

void TBSW0030RegrasFormatacaoBase::insert_TIP_TCNL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
     if(tbsw0030_params.in_tpo_tcn.empty())
    {
        WARNING_EMPTY_STRING;
        tbsw0030.set_TIP_TCNL(" ");
    }
    else
    {
        char l_tmpStrTipTcnl[ 4 + 1 ];
        sprintf( l_tmpStrTipTcnl, "%04d", atoi( tbsw0030_params.in_tpo_tcn.c_str( ) ) );
        std::string l_string = std::string( l_tmpStrTipTcnl );
        tbsw0030.set_TIP_TCNL( l_string.substr( 0, 4 ) );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_TIP_TERM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
     if(tbsw0030_params.cd_tpo_trm.empty())
    {
        WARNING_EMPTY_STRING;
        tbsw0030.set_TIP_TERM(" ");
    }
    else
    {
        tbsw0030.set_TIP_TERM( tbsw0030_params.cd_tpo_trm );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_RAM_ATVD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_RAM_ATVD( atol( tbsw0030_params.mer_cat_code.c_str( ) ) );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_POS_ENTR_MODO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.pos_entry_code != 0 )
    {
        char l_tmpPosEntryCode[ 3 + 1 ] = { 0 };
        sprintf( l_tmpPosEntryCode, "%0.3d", tbsw0030_params.pos_entry_code );
        std::string pos_entry_code = std::string( l_tmpPosEntryCode );
        tbsw0030.set_COD_POS_ENTR_MODO( pos_entry_code );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_BNDR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_BNDR( tbsw0030_params.cod_bndr );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_EMSR( tbsw0030_params.cd_ems );
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.acq_name.compare( "ADM" ) != 0 )
    {
        if ( tbsw0030_params.iss_name.compare( "MAESTRO" ) == 0 || tbsw0030_params.iss_name.compare( "HIPERCARD_DBT" ) == 0 ||
             tbsw0030_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 || tbsw0030_params.iss_name.compare( "MASTER_HIPER_DBT" ) == 0)
        {
            //tbsw0030.set_NUM_EMSR( tbsw0030_params.cd_ems );
            tbsw0030.set_NUM_EMSR( 18 );
        }
        else
        {
            if ( tbsw0030_params.bin.length( ) > 0 )
            {
                tbsw0030.set_NUM_EMSR( atoi( tbsw0030_params.bin.substr( 0, 2 ).c_str( ) ) );
            }
        }
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_ID_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    oasis_dec_t l_dect;

    if( tbsw0030_params.iss_name.compare( "MASTERCARD" ) == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
        tbsw0030_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 )
    {
        //fica null
        return;
    }
    else if( tbsw0030_params.iss_name.compare( "HIPERCARD_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990001" ).c_str( ), 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "SOROCRED_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990002" ).c_str( ), 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "CABAL_CRT" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990003" ).c_str( ), 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "COOPERCRED_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990004" ).c_str( ), 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "UPI" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990006" ).c_str( ), 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "CREDSYSTEM_FULL" ) == 0 || tbsw0030_params.iss_name.compare( "CREDSYSTEM_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990010" ).c_str( ), 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "DINERS_INTERNAC" ) == 0 )
    {
        dbm_chartodec( &l_dect, "0", 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "DINERS_NACIONAL" ) == 0 )
    {
        dbm_chartodec( &l_dect, "0", 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "BANESCARD_CRT_FULL" ) == 0 || tbsw0030_params.iss_name.compare( "BANESCARD_CRT_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990011" ).c_str( ), 0 );
    }
    else if( tbsw0030_params.iss_name.compare( "CREDZ" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990014" ).c_str( ), 0 );
    }
    else
    {
        if( tbsw0030_params.bin.empty( ) == false )
        {
            dbm_chartodec( &l_dect, tbsw0030_params.bin.c_str( ), 0 );
        }
        else
            return;
    }
    tbsw0030.set_NUM_ID_CAR( l_dect );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_PAIS_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    std::string orig_pan = tbsw0030_params.orig_pan;

    //TRANSACOES QUE POSSUEM NUMERO DO CARTAO DA ORIGINAL
    if( tbsw0030_params.num_car.length( ) > 0 )
    {
        tbsw0030.set_NUM_CAR( tbsw0030_params.num_car );
    }
    else if( orig_pan.length( ) )
    {
        //limpa o pan caso precise
        size_t l_pos = orig_pan.find_first_of("=DF^");
        if( l_pos != std::string::npos )
        {
            orig_pan.erase( l_pos, std::string::npos );
        }   

        if ( tbsw0030_params.iss_name.compare( "DINERS_INTERNAC" ) == 0 )
        {
            if (orig_pan.length( ) == 18) //EAK-1517 - se o pan for igual a 18 precisamos liberar 1 digito
            {
                orig_pan = orig_pan.substr( 0, strlen( orig_pan.c_str( ) ) - 1 );
                orig_pan = tbsw0030_params.countryDiners + orig_pan; //countryDiners+orig_pan nao podem ultrapassar 19 digitos
            }
            else if(orig_pan.length( ) == 19) //EAK-1517 - se o pan for igual a 18 precisamos liberar 2 digitos
            {
                orig_pan = orig_pan.substr( 0, strlen( orig_pan.c_str( ) ) - 2 );
                orig_pan = tbsw0030_params.countryDiners + orig_pan; //countryDiners+orig_pan nao podem ultrapassar 19 digitos
            }
            else
                orig_pan = tbsw0030_params.countryDiners + orig_pan;
        }
        else if( *orig_pan.rbegin( ) == 'F' ) // o pan pode vir com um digito em hexa por problemas de conversao
        {
            orig_pan = orig_pan.substr( 0, strlen( orig_pan.c_str( ) ) - 1 );
        }

        tbsw0030.set_NUM_CAR( orig_pan );
    }else
    {
        tbsw0030.set_NUM_CAR( "" );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_DAT_VLD_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.expiry_date > 0 )
    {
        sw_date_t e_date;
        int mod_expiry_date = 0;
        int expiry_date_signature = 1212;

        mod_expiry_date = tbsw0030_params.expiry_date % 100;
        /* BIP233274 - evitando data de validade invalida */
        /* caso seja invalido, colocamos a assinatura 6912 */
        if (mod_expiry_date < 1 || mod_expiry_date > 12)
            e_date.date = (( tbsw0030_params.local_date / 1000000 ) * 1000000) + ( expiry_date_signature * 100 + 1);
        else
        e_date.date = (( tbsw0030_params.local_date / 1000000 ) * 1000000) + ( tbsw0030_params.expiry_date * 100 + 1);
        tbsw0030.set_DAT_VLD_CAR( e_date );
    }
}

/// insert_IND_TRK
/// Prepara IND_TRK para insercao
/// EF/ET: EAK-1899
/// Historico: [Data] - ET - Descricao
/// 16/12/2019 - EAK1899 - Inclusao da verificacao de resumo de vendas
/// [Data] - ET - Descricao
/// tbsw0030: Dados da tabela tbsw0030
/// tbsw0030_params: Parametros recebidos da tbsw0030
void TBSW0030RegrasFormatacaoBase::insert_IND_TRK( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( ( tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 || tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 ) &&
        ( tbsw0030_params.ind_trk.empty( ) == false ) )
    {
        tbsw0030.set_IND_TRK( tbsw0030_params.ind_trk );
    }
    else if( tbsw0030_params.msg_category.compare( "ADMINISTRATIVA" ) == 0 && tbsw0030_params.msg_name.compare( "RES_VEND" ) == 0 )
    {
        tbsw0030.set_IND_TRK( std::string("0") );
    }
    else if( tbsw0030_params.track2.empty( ) == false && tbsw0030_params.track2.compare("                                        ") != 0 )
    {
        tbsw0030.set_IND_TRK( std::string("2") );
    }
    else if( tbsw0030_params.indicadorTrilha3Len.compare("0") != 0 )
    {
        tbsw0030.set_IND_TRK( std::string("1") );
    }
    else
    {
        tbsw0030.set_IND_TRK( std::string("0") );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_IND_CPTR_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    std::string cvv2 = tbsw0030_params.cvv2;
    std::string ind = "N";

    cvv2 = AcqUtils::trim( cvv2, " ", true, true );
    if ( cvv2[ 0 ] != '\0'        && cvv2.compare( "" ) != 0 &&
         cvv2.compare( "1" ) != 0 && cvv2.compare( "2" ) != 0 &&
         cvv2.compare( "INX" ) != 0 && cvv2.compare( "ILG" ) != 0 )
    {
        ind = "S";
    }

    tbsw0030.set_IND_CPTR_CVC_2( ind );
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO E USADO ATUALMENTE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_TRK_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 || tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 )
    {
        if( tbsw0030_params.cod_trk_car.empty( ) == false )
        {
            tbsw0030.set_COD_TRK_CAR( tbsw0030_params.cod_trk_car );
        }
    }
    else if( tbsw0030_params.acq_name.compare( "VCH" ) == 0 || tbsw0030_params.msg_name.compare( "VEND_DBT_PREDAT" ) == 0 || tbsw0030_params.msg_name.compare( "VEND_DBT_DIST_PREDAT" ) == 0 || tbsw0030_params.msg_name.compare( "VEND_DBT_PREDAT_ZOLKIN" ) == 0 )
    {
        if( tbsw0030_params.track2.empty( ) == false )
        {
            tbsw0030.set_COD_TRK_CAR( tbsw0030_params.track2.substr( 0, 40 ) );
        }
        else if( tbsw0030_params.track3.empty( ) == false )
        {
            tbsw0030.set_COD_TRK_CAR( tbsw0030_params.track3.substr( 0, 40 ) );
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
    //MARCARA CARACTERES APOS O SEPARADOR
    else if( ( ( tbsw0030_params.msg_category.compare( "VENDA" ) == 0 ||
                 tbsw0030_params.msg_category.compare( "ADV_APROVADO" ) == 0 ||
                 tbsw0030_params.msg_category.compare( "ADV_NEGADO" ) == 0 ) &&
             ( tbsw0030_params.acq_name.compare( "PL" ) == 0 || tbsw0030_params.acq_name.compare( "CRT" ) == 0 ) ) ||
             ( tbsw0030_params.msg_category.compare( "CONSULTA" ) == 0 && tbsw0030_params.acq_name.compare( "CRT" ) == 0 ) ||
             ( tbsw0030_params.msg_category.compare( "CONSULTA" ) == 0 && tbsw0030_params.acq_name.compare( "PL" ) == 0 ) ||
             tbsw0030_params.msg_category.compare( "CONF_PREAUT" ) == 0 )
    {
        if( tbsw0030_params.track2.empty( ) == false )
        {
            std::string local_track2 = tbsw0030_params.track2;
            int   pos = local_track2.find_first_of("=DF");
            if( pos != std::string::npos )
            {
                int tam = local_track2.length( ) - pos;
                local_track2.replace( pos + 1, tam - 1, tam - 1, 'X');
                tbsw0030.set_COD_TRK_CAR( local_track2.substr( 0, 40 ) );
            }
            else
            {
                WARNING_FLOW_ERROR;
            }
        }
        else if( tbsw0030_params.track3.empty( ) == false )
        {
            std::string local_track3 = tbsw0030_params.track3;
            int pos = local_track3.find( '^' );
            if( pos != std::string::npos )
            {
                pos = local_track3.find( '^', pos + 1 );
                if( pos == std::string::npos )
                {
                    WARNING_FLOW_ERROR;
                }

                int tam = local_track3.length( ) - pos;
                local_track3.replace( pos + 1, tam - 1, tam - 1, 'X');
                tbsw0030.set_COD_TRK_CAR( local_track3.substr( 0, 40 ) );
            }
            else
            {
                WARNING_FLOW_ERROR;
            }
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
    //MARCARA CARACTERES APOS A DATA DE VALIDADE
    else if( tbsw0030_params.msg_category.compare( "VENDA" ) == 0 && tbsw0030_params.acq_name.compare( "DBT" ) == 0 )
    {
        if( tbsw0030_params.track2.empty( ) == false )
        {
            std::string local_track2;
            std::size_t pos = tbsw0030_params.track2.find_first_of("=D^F");
            if( pos == std::string::npos )
            {
                WARNING_FLOW_ERROR;
            }
            else
            {
                local_track2.append( pos, 'X' );
                local_track2.append( tbsw0030_params.track2.substr( pos, 5 ) );
                local_track2.append( tbsw0030_params.track2.length( ) - local_track2.length( ), 'X' );
                if( local_track2.length( ) > 40 )
                {
                    local_track2 = local_track2.substr( 0, 40 );
                }
                else if( local_track2.length( ) < 40 )
                {
                    local_track2.append( 40 - local_track2.length( ), ' ' );
                }
                tbsw0030.set_COD_TRK_CAR( local_track2 );
            }
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
    // J3_2019 - Mensageria de pagamento ITI - INICIO
    else if( tbsw0030_params.msg_category.compare( "PAGAMENTO" ) == 0 )
    {
        // nenhuma acao a ser executada
    }
    // J3_2019 - Mensageria de pagamento ITI - FIM
    else
    {
        WARNING_FLOW_ERROR;
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_SERV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    std::string l_string = AcqUtils::getServiceCode( tbsw0030_params.track2, tbsw0030_params.track3 );

    if(l_string.substr( 0, 1 ) != " " )
    {
        if ( l_string.substr( 0, 1 ) != "X" )
        { /* O "X" ocorrera quando a trilha mascarada for recuperada de transacao original, entao o campo deve ficar nulo */
            tbsw0030.set_COD_SERV( l_string.substr( 0, 1 ) );
        }
    }
    else if( tbsw0030_params.local_cod_serv.empty( ) == false )
    {
        tbsw0030.set_COD_SERV( tbsw0030_params.local_cod_serv );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_SERV_SNHA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.has_pin.compare( "TRUE" ) == 0 )
    {
        if( tbsw0030_params.iss_name.compare( "MASTERCARD" ) == 0 || tbsw0030_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 ||
            tbsw0030_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 || tbsw0030_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 )
        {
            tbsw0030.set_COD_SERV_SNHA( "PX" );
        }
        else if( tbsw0030_params.status.compare( "2" ) == 0 )
        {
            tbsw0030.set_COD_SERV_SNHA( "RW" );
        } 
        else
        {
            if( tbsw0030_params.iss_name.compare( "VISA_CREDITO" ) == 0 )
            {
                tbsw0030.set_COD_SERV_SNHA( "  " );
            }
            else
            {
                tbsw0030.set_COD_SERV_SNHA( "00" );
            }
        }
    }
    else
    {
        tbsw0030.set_COD_SERV_SNHA( "  " );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_IND_ID_PREV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_ID_PREV( 0 );
}

void TBSW0030RegrasFormatacaoBase::insert_VAL_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, tbsw0030_params.amount.c_str( ), 0 );
    if( dbm_cmpzero( &l_dect ) > 0 )
    {
        tbsw0030.set_VAL_TRAN( l_dect );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_VAL_TOTL_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0", 0 );
    tbsw0030.set_VAL_TOTL_TRAN( l_dect );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_MOED( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    int l_segDig = atoi( tbsw0030_params.mer_cat_code.c_str( ) )/1000;
    l_segDig = l_segDig % 10;
    std::string moeda = "986";
    if( tbsw0030_params.mer_cat_code.compare( "61300" ) == 0 || l_segDig == 8 )
    {
        moeda = "840";
    }

    tbsw0030.set_COD_MOED( moeda );
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_CV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    // Usando cd_ems ao inves de iss_name porque trata-se de 'qualquer emissor VOUCHER'. O nome 'VOUCHER' nao pode ser utilizado em iss_name
    // porque ele eh subdividido em varios emissores ( ver 'MappingIssName.xml' )
    if( tbsw0030_params.cd_ems == 24 )
    {
        if( tbsw0030_params.msg_category.compare( "VENDA" ) == 0        ||
            tbsw0030_params.msg_category.compare( "ADV_APROVADO" ) == 0 ||
            tbsw0030_params.msg_category.compare( "ADV_NEGADO" ) == 0 )
        {
            if( tbsw0030_params.trace > 0 )
                tbsw0030.set_NUM_CV( tbsw0030_params.trace );
        }
        else
        if( tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 || tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 )
        {
            if( tbsw0030_params.origtrace > 0 )
                tbsw0030.set_NUM_CV( tbsw0030_params.origtrace );
        }
    }
    else
    if( tbsw0030_params.iss_name.compare( "MAESTRO" ) == 0           || tbsw0030_params.iss_name.compare( "HIPERCARD_DBT" ) == 0    ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 || tbsw0030_params.iss_name.compare( "MASTER_HIPER_DBT" ) == 0 )
    {
        // Para MAESTRO HIPERCARD_DBT HIPERCARD_DBT_HMV MASTER_HIPER_DBT o NUM_CV eh o DE011 enviado ao emissor conforme a regra substr(NSU(REDE),6,6)
        if( tbsw0030_params.msg_category.compare( "VENDA" ) == 0        ||
            tbsw0030_params.msg_category.compare( "ADV_APROVADO" ) == 0 ||
            tbsw0030_params.msg_category.compare( "ADV_NEGADO" ) == 0 )
        {
            if( tbsw0030_params.refnum > 0 )
                tbsw0030.set_NUM_CV( ( tbsw0030_params.refnum % 1000000 ) ) ;
        }
        else
        if( tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 || tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 )
        {
            if( tbsw0030_params.origrefnum > 0 )
                tbsw0030.set_NUM_CV( ( tbsw0030_params.origrefnum % 1000000 ) );
        }
    }
    else
    {
        if( tbsw0030_params.msg_category.compare( "VENDA" ) == 0        ||
            tbsw0030_params.msg_category.compare( "CONF_PREAUT" ) == 0  ||
            tbsw0030_params.msg_category.compare( "CONSULTA" ) == 0 ||
            tbsw0030_params.msg_category.compare( "ADV_APROVADO" ) == 0 ||
            tbsw0030_params.msg_category.compare( "ADV_NEGADO" ) == 0 )
        {
            tbsw0030.set_NUM_CV( tbsw0030_params.refnum );
        }
        else if( tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 || tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 )
        {
            if( tbsw0030_params.origrefnum > 0 )
                tbsw0030.set_NUM_CV( tbsw0030_params.origrefnum );
        }
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_MOT_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0030.set_COD_MOT_AUT( tbsw0030_params.cod_mot_aut_pauz );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_MOT_RSPS( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    gen_NUM_MOT_RSPS( tbsw0030, tbsw0030_params );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_MOT_RSPS_EXT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_MOT_RSPS_EXT( "000" );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_MOT_SW( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.cod_mtv_sw.length( ) > 0 )
    {
        tbsw0030.set_COD_MOT_SW( tbsw0030_params.cod_mtv_sw );
    }
    else
    {
        tbsw0030.set_COD_MOT_SW( "000" );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_IND_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{

    if ( tbsw0030_params.msgtype == 800 && atoi( tbsw0030_params.status.c_str( ) ) <= 0 )
    {
        tbsw0030.set_IND_STTU_TRAN( "1" );
    }
    else
    {
        if(tbsw0030_params.status.empty())
        {
            WARNING_EMPTY_STRING;
            tbsw0030.set_IND_STTU_TRAN(" ");
        }
        else
        {
            tbsw0030.set_IND_STTU_TRAN( tbsw0030_params.status );
        }
    }
}

void TBSW0030RegrasFormatacaoBase::insert_DTH_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    gen_DTH_STTU_TRAN( tbsw0030, tbsw0030_params );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_PROD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_PROD( " " );
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_RSMO_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_DAT_RSMO_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.msg_name.compare( "RES_VEND" ) == 0 && tbsw0030_params.dt_rv > 0 )
    {
        dbm_datetime_t l_datetime;
        l_datetime = tbsw0030_params.dt_rv;
        tbsw0030.set_DAT_RSMO_VD( l_datetime );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_LOC_ESTB( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
        std::string l_nom_loc_estb;
        std::string l_mer_name;
        std::string l_mer_city;
        std::size_t l_pos;

          l_mer_name = tbsw0030_params.merchant_mer_name;
          l_mer_city = tbsw0030_params.merchant_mer_city;
        //grava 22 primeiras posicoes do nome do estabelecimento completados com branco a direita
        if ( 22 < strlen( l_mer_name.c_str( ) ) )
        {
            l_nom_loc_estb = l_mer_name.substr( 0, 22 );
        }
        else
        {
            l_nom_loc_estb = l_mer_name;
            l_nom_loc_estb.append( 22 - strlen( l_mer_name.c_str( ) ), ' ' );
        }
        //inclui branco na 23 posicao
        l_nom_loc_estb.append( " " );
        //grava 13 primeiras posicoes do nome da cidade completados com branco a direita
        if ( 13 < strlen( l_mer_city.c_str( ) ) )
        {
            l_nom_loc_estb.append( l_mer_city.substr( 0, 13 ) );
        }
        else
        {
            l_nom_loc_estb.append( l_mer_city );
            l_nom_loc_estb.append( 13 - strlen( l_mer_city.c_str( ) ), ' ' );
        }
        //inclui branco na 37 posicao seguido de ""BRA""
        l_nom_loc_estb.append( " BRA" );

        tbsw0030.set_NOM_LOC_ESTB(l_nom_loc_estb);

}

void TBSW0030RegrasFormatacaoBase::insert_IND_TERM_RLCD_CHIP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
        if(tbsw0030_params.ind_term_ltro_chip.empty())
        {
            WARNING_EMPTY_STRING;
            tbsw0030.set_IND_TERM_RLCD_CHIP(" ");
        }
        else
        {
            tbsw0030.set_IND_TERM_RLCD_CHIP( tbsw0030_params.ind_term_ltro_chip );
        }
}

void TBSW0030RegrasFormatacaoBase::insert_IND_DFZM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_DFZM( std::string( "N" ) );

    if( tbsw0030_params.isReversal.compare( "TRUE" ) == 0 )
    {
        tbsw0030.set_IND_DFZM( std::string( "S" ) );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_IND_ESTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_ESTR( std::string( "N" ) );

    if( tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 )
    {
        tbsw0030.set_IND_ESTR( std::string( "S" ) ) ;
    }
}

void TBSW0030RegrasFormatacaoBase::insert_IND_CPTRDO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    gen_IND_CPTRDO( tbsw0030, tbsw0030_params );
}

void TBSW0030RegrasFormatacaoBase::insert_IND_AGND_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_AGND_TRAN( std::string( "N" ) );
}

void TBSW0030RegrasFormatacaoBase::insert_IND_IMPR_CPOM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_IMPR_CPOM( std::string( "N" ) );
}

void TBSW0030RegrasFormatacaoBase::insert_IND_EMSR_MTC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_EMSR_MTC( std::string( "N" ) );

    if ( tbsw0030_params.iss_name.compare( "MASTERCARD" ) == 0 ||
         tbsw0030_params.iss_name.compare( "MAESTRO" ) == 0 ||
         tbsw0030_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 ||
         tbsw0030_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
         tbsw0030_params.iss_name.compare( "HIPERCARD_DBT" ) == 0 ||
         tbsw0030_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ||
         tbsw0030_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 ||
         tbsw0030_params.iss_name.compare( "MASTER_HIPER_DBT" ) == 0)
    {
        tbsw0030.set_IND_EMSR_MTC( std::string( "S" ) );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_IND_DA_RLCD_CHIP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_DA_RLCD_CHIP( std::string( "N" ) );

    if ( tbsw0030_params.is_pre_auth.compare( "FALSE" ) == 0 )
    {
        if( ( tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 ||
              tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 ) &&
            tbsw0030_params.orig_ind_da_rlcd_chip.empty(  ) == false)
        {
            tbsw0030.set_IND_DA_RLCD_CHIP( tbsw0030_params.orig_ind_da_rlcd_chip );
        }
        else
        {
            if ( tbsw0030_params.chip_full_data_len > 0 && tbsw0030_params.ind_term_ltro_chip == "S" )
            {
                tbsw0030.set_IND_DA_RLCD_CHIP( std::string( "S" ) );
            }
        }
    }
}

void TBSW0030RegrasFormatacaoBase::insert_IND_DA_RLCD_IATA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO DIFERENTE POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_IND_TRAN_REFD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    gen_IND_TRAN_REFD( tbsw0030, tbsw0030_params );
}

void TBSW0030RegrasFormatacaoBase::insert_TIP_TRAN_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO DIFERENTE POS E PDV
}

void TBSW0030RegrasFormatacaoBase::insert_DAT_EXPC_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_VAL_TRAN_DLR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_VAL_COT_DLR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_CTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.acq_name.compare( "PL" ) == 0 &&
        ( tbsw0030_params.msg_category.compare( "CONSULTA" ) == 0 || tbsw0030_params.msg_category.compare( "VENDA" ) == 0  ) )
    {
        tbsw0030.set_COD_CTR( tbsw0030_params.pl_cod_item );
    }
    else
    {
        tbsw0030.set_COD_CTR( std::string( "0" ) );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_VAL_TX( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO DIFERENTE POS E PDV
}

void TBSW0030RegrasFormatacaoBase::insert_COD_REF_RESTANTE( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_REF_RESTANTE( " " );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_CNDC_CPTR_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare( "DESF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "EST_PREAUT" ) == 0 ||
        tbsw0030_params.msg_name.compare( "DESF_PREAUT_PARC_SJURO" ) == 0 || tbsw0030_params.msg_name.compare( "EST_PREAUT_PARC_SJURO" ) == 0 ||
        tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0030.set_COD_CNDC_CPTR_PAUZ( tbsw0030_params.cod_cndc_cptr_pauz );
    }
    else
    {
        tbsw0030.set_COD_CNDC_CPTR_PAUZ(" ");
    }

}

void TBSW0030RegrasFormatacaoBase::insert_TIP_ENT_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare( "DESF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "EST_PREAUT" ) == 0 ||
        tbsw0030_params.msg_name.compare( "DESF_PREAUT_PARC_SJURO" ) == 0 || tbsw0030_params.msg_name.compare( "EST_PREAUT_PARC_SJURO" ) == 0 ||
        tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0030.set_TIP_ENT_PAUZ( tbsw0030_params.tip_ent_pauz );
    }
    else
    {
        tbsw0030.set_TIP_ENT_PAUZ(" ");
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_OPER_CNFR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_OPER_CNFR( std::string( "SISTSW" ) );
}

void TBSW0030RegrasFormatacaoBase::insert_PRCN_TX_RISC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0", 0 );
    tbsw0030.set_PRCN_TX_RISC( l_dect );

    if ( tbsw0030_params.common_vl_pca_ent.empty( ) == false &&
         ( tbsw0030_params.msg_name.compare("VEND_DBT_DIST_AVISTA") == 0 ||
           tbsw0030_params.msg_name.compare("DESF_VEND_DBT_DIST") == 0 ||
           tbsw0030_params.msg_name.compare("EST_VEND_DBT_DIST") == 0 ||
           tbsw0030_params.msg_name.compare("DESF_EST_VEND_DBT_DIST") == 0 ||
           tbsw0030_params.msg_name.compare("VEND_DBT_DIST_PREDAT") == 0 ||
           tbsw0030_params.msg_name.compare("DESF_VEND_DBT_DIST_PREDAT") == 0 ||
           tbsw0030_params.msg_name.compare("EST_VEND_DBT_DIST_PREDAT") == 0 ||
           tbsw0030_params.msg_name.compare("DESF_EST_VEND_DBT_DIST_PREDAT") == 0 ||
           tbsw0030_params.msg_name.compare("ADV_VEND_DIST_NEG") == 0 ||
           tbsw0030_params.msg_name.compare("ADV_VEND_DIST_PREDAT_NEG") == 0 ) )
    {
        dbm_chartodec( &l_dect, tbsw0030_params.common_vl_pca_ent.c_str( ), 0 );
        tbsw0030.set_PRCN_TX_RISC( l_dect );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_VAL_TX_RISC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    oasis_dec_t l_dect;
    dbm_chartodec( &l_dect, "0", 0 );
    tbsw0030.set_VAL_TX_RISC( l_dect );

    if ( tbsw0030_params.common_vl_txa.empty( ) == false &&
         ( tbsw0030_params.msg_name.compare("VEND_DBT_DIST_AVISTA") == 0 ||
           tbsw0030_params.msg_name.compare("DESF_VEND_DBT_DIST") == 0 ||
           tbsw0030_params.msg_name.compare("EST_VEND_DBT_DIST") == 0 ||
           tbsw0030_params.msg_name.compare("DESF_EST_VEND_DBT_DIST") == 0 ||
           tbsw0030_params.msg_name.compare("VEND_DBT_DIST_PREDAT") == 0 ||
           tbsw0030_params.msg_name.compare("DESF_VEND_DBT_DIST_PREDAT") == 0 ||
           tbsw0030_params.msg_name.compare("EST_VEND_DBT_DIST_PREDAT") == 0 ||
           tbsw0030_params.msg_name.compare("DESF_EST_VEND_DBT_DIST_PREDAT") == 0 ||
           tbsw0030_params.msg_name.compare("ADV_VEND_DIST_NEG") == 0 ||
           tbsw0030_params.msg_name.compare("ADV_VEND_DIST_PREDAT_NEG") == 0 ) )
    {
        dbm_chartodec( &l_dect, tbsw0030_params.common_vl_txa.c_str( ), 0 );
        tbsw0030.set_VAL_TX_RISC( l_dect );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_CNDC_CPTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    std::string fe_acq( getenv( "NOM_FE_ACQR" ) );
    std::string conteudo_de061 = tbsw0030_params.cod_cndc_cptr;
    std::stringstream s_modo_entrada; // modo de entrada pode conter ate 3 digitos
    std::string cod_cndc_cptr;
    int digt_modo_entrada;

    if( conteudo_de061.empty( ) == true )
    {
        tbsw0030.set_COD_CNDC_CPTR( "00000000000" );
        return;
    }
    s_modo_entrada << tbsw0030_params.pos_entry_code;
    digt_modo_entrada = atoi( s_modo_entrada.str( ).substr( 0, 1 ).c_str( ) );
    if( ( (digt_modo_entrada == 7) || (digt_modo_entrada == 8) ) && ( s_modo_entrada.str( ).length( ) > 1))
    {
        digt_modo_entrada = atoi( s_modo_entrada.str( ).substr( 0, 2 ).c_str( ) );
    }
    if( conteudo_de061.length( ) <= 8 && fe_acq == "FEPDV" )
    {
        if( digt_modo_entrada == 5 )
        {
            conteudo_de061 = "00000000008";
        }
        else
        {
            conteudo_de061 = "00000000007";
        }
    }

    //posicao 1
    if( conteudo_de061.substr( 0, 1 ) == "1" )
    {
        cod_cndc_cptr = conteudo_de061.substr( 0, 1 );
    }
    else
    {
        cod_cndc_cptr = "0";
    }

    //posicao 2
    if ( std::string( getenv( "NOM_FE_ACQR" ) ) == "FEPDV" && ( tbsw0030_params.iss_name.compare( "MASTERCARD" ) == 0 ) )
    {
        if( tbsw0030_params.posCapCode & SH_POS_CAP_NOTERM )
        {
            cod_cndc_cptr.append( "0" );
        }
        else if ( tbsw0030_params.posCapCode & SH_POS_CAP_CARDCAPTURE_UNKNOWN )
            cod_cndc_cptr.append( "9" );
        else
            cod_cndc_cptr.append( "1" );
    }
    else if( conteudo_de061.substr( 1, 1 ) == "0" || conteudo_de061.substr( 1, 1 ) == "9" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 1, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }

    //posicao 3
    if( conteudo_de061.substr( 2, 1 ) == "0" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 2, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }

    //posicao 4
    if( conteudo_de061.substr( 3, 1 ) == "0" &&
        !( digt_modo_entrada == 1 || digt_modo_entrada == 79 || digt_modo_entrada == 81 ) )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 3, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }

    //posicao 5
    if( conteudo_de061.substr( 4, 1 ) == "0" &&
        !( digt_modo_entrada == 1 || digt_modo_entrada == 79 || digt_modo_entrada == 81 ) )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 4, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }

    //posicao 6
    if( conteudo_de061.substr( 5, 1 ) == "1" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 5, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }

    //posicao 7
    if( conteudo_de061.substr( 6, 1 ) == "4" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 6, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }

    //posicao 8
    if( conteudo_de061.substr( 7, 1 ) == "1" || conteudo_de061.substr( 7, 1 ) == "2" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 7, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }

    //posicao 9
    if( fe_acq == "FEPOS" )
    {
        cod_cndc_cptr.append( "0" );
    }
    else
    {
        if( conteudo_de061.substr( 8, 1 ) == "1" || conteudo_de061.substr( 8, 1 ) == "2" )
        {
            cod_cndc_cptr.append( conteudo_de061.substr( 8, 1 ) );
        }
        else
        {
            cod_cndc_cptr.append( "0" );
        }
    }

    //posicao 10
    if ( fe_acq == "FEPOS" )
    {
        if  ( ( ( tbsw0030_params.iss_name.compare( "MASTERCARD" ) == 0 ) ||
                ( tbsw0030_params.iss_name.compare( "MAESTRO" ) == 0 ) ||
                ( tbsw0030_params.iss_name.compare( "DINERS_INTERNAC" ) == 0 ) ||
                ( tbsw0030_params.iss_name.compare( "DINERS_NACIONAL" ) == 0 ) ||
                ( tbsw0030_params.iss_name.compare( "VISA_CREDITO" ) == 0 ) ||
                ( tbsw0030_params.iss_name.compare( "VISA_ELECTRON" ) == 0 ) ||
                ( tbsw0030_params.iss_name.compare( "UPI" ) == 0 ) ) &&
            ( ( tbsw0030_params.ecr_sftw_verid.compare( 0, 2, "MP") == 0 ) ||
                ( tbsw0030_params.ecr_sftw_verid.compare( 0, 2, "MD") == 0 ) ||
                ( tbsw0030_params.in_tpo_tcn.compare( 0, 3, "154" ) == 0 ) ) )
        {
            cod_cndc_cptr.append( "9" );
        }
        else
        {
            cod_cndc_cptr.append( "0" );
        }
    }
	// AUT1-2555/3047 - VISA MASTERCARD CAT 7-9 - INICIO
	else if ( fe_acq.compare( "FEPDV" ) == 0)
	{
		cod_cndc_cptr.append( conteudo_de061.substr( 9, 1 ) );
	}
	// AUT1-2555/3047 - VISA MASTERCARD CAT 7-9 - FIM
    else
    {
        cod_cndc_cptr.append( "0" );
    }

    //posicao 11
    if( ( fe_acq == "FEPOS" ) && ( conteudo_de061.length( ) < 11 ))
    {
            cod_cndc_cptr.append( "0" );
    }
    else
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 10, 1 ) );
    }

    tbsw0030.set_COD_CNDC_CPTR( cod_cndc_cptr );
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if(strlen(getenv( "NOM_SITE_ACQR" ))==0)
    {
        WARNING_EMPTY_STRING;
        tbsw0030.set_NOM_SITE_ACQR_ORGL(" ");
    }
    else
    {
        tbsw0030.set_NOM_SITE_ACQR_ORGL( getenv( "NOM_SITE_ACQR" ) );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if(strlen(getenv( "NOM_HOST_ACQR" ))==0)
    {
        WARNING_EMPTY_STRING;
        tbsw0030.set_NOM_HOST_ACQR_ORGL(" ");
    }
    else
    {
        tbsw0030.set_NOM_HOST_ACQR_ORGL( getenv( "NOM_HOST_ACQR" ) );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if(strlen(getenv( "NOM_FE_ACQR" ))==0)
    {
        WARNING_EMPTY_STRING;
        tbsw0030.set_NOM_FE_ACQR_ORGL(" ");
    }
    else
    {
        tbsw0030.set_NOM_FE_ACQR_ORGL( getenv( "NOM_FE_ACQR" ) );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_SITE_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_HOST_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_FE_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_TXT_DA_ADIC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_TIP_MODL_CPTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_DTH_TRAN_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_DAT_LQDC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_ISTT_ACQR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_ISTT_FRWD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_RSPS_DTLH_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_RSTD_NUM_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_RSTD_NUM_CVC_2( std::string( " " ) );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_SERV_TRK_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.acq_name.compare( "DBT" ) == 0 )
    {
        if ( tbsw0030_params.track2.empty( ) == false || tbsw0030_params.track3.empty( ) == false )
        {
            tbsw0030.set_COD_SERV_TRK_CAR( atol( AcqUtils::getServiceCode( tbsw0030_params.track2, tbsw0030_params.track3 ).c_str( ) ) );
        }
        else
        {
            if( tbsw0030_params.value_cod_serv_trk_car.empty( ) == false &&
              ( tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 || tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 ) )
            {
                tbsw0030.set_COD_SERV_TRK_CAR ( atol( tbsw0030_params.value_cod_serv_trk_car.c_str( ) ) );
            }
        }
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_VLDC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_VLDC_EMSR( std::string( " " ) );
}

void TBSW0030RegrasFormatacaoBase::insert_IND_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_AUT( std::string( " " ) );
}

void TBSW0030RegrasFormatacaoBase::insert_IND_DA_RLCD_KMRC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_IND_DA_RLCD_KMRC( "N" );
}

void TBSW0030RegrasFormatacaoBase::insert_IND_TRAN_SEM_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.trn_tem_original.compare( "FALSE" )  == 0 &&
        (tbsw0030_params.msg_category.compare("DESFAZIMENTO") == 0 ||
         tbsw0030_params.msg_category.compare("ESTORNO")      == 0 ||
         tbsw0030_params.msg_category.compare("CONF_PREAUT")  == 0 ||
         tbsw0030_params.msg_category.compare("CONFIRMACAO")  == 0) )
    {
        tbsw0030.set_IND_TRAN_SEM_ORGL( "S" );
    }
    else
    {
        tbsw0030.set_IND_TRAN_SEM_ORGL( "N" );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_DAT_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare( "DESF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "EST_PREAUT" ) == 0 ||
        tbsw0030_params.msg_name.compare( "DESF_PREAUT_PARC_SJURO" ) == 0 || tbsw0030_params.msg_name.compare( "EST_PREAUT_PARC_SJURO" ) == 0 ||
        tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0030.set_DAT_PAUZ( tbsw0030_params.date_pauz );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_SEQ_UNC_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.msg_name.compare( "DESF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "EST_PREAUT" ) == 0 ||
        tbsw0030_params.msg_name.compare( "DESF_PREAUT_PARC_SJURO" ) == 0 || tbsw0030_params.msg_name.compare( "EST_PREAUT_PARC_SJURO" ) == 0 ||
        tbsw0030_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0030_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        if( tbsw0030_params.origrefnum > 0 )
        {
            tbsw0030.set_NUM_SEQ_UNC_PAUZ( tbsw0030_params.origrefnum );
        }
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_TRAN_CAD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_TRAN_CAD( tbsw0030_params.cod_tran_cad );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_AUT_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_NTWK_ID_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_NTWK_ID_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_NTWK_ID_ACQR_ORGL( std::string( getenv( "NETWORKID" ) ) );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_NTWK_ID_ROUT_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_NTWK_ID_ROUT_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_NTWK_ID_ROUT_ORGL( tbsw0030_params.receive_inst_id );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_NTWK_ID_ISSR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_NTWK_ID_ISSR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_NTWK_ID_ISSR_ORGL( tbsw0030_params.issuer );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_RAM_MCC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.merchantCategoryCodeSubLojista.length( ) > 0 && atoi(tbsw0030_params.merchantCategoryCodeSubLojista.c_str( )) > 0 )
    {
        tbsw0030.set_COD_RAM_MCC( tbsw0030_params.merchantCategoryCodeSubLojista );
    }
    else if ( tbsw0030_params.merchant_type.length( ) > 0 )
    {
        tbsw0030.set_COD_RAM_MCC( tbsw0030_params.merchant_type );
    }
}

void TBSW0030RegrasFormatacaoBase::insert_COD_CNDC_CPTR_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_PROD_CDST( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_COD_PROD_CDST( tbsw0030_params.cod_prod_cdst );
}

void TBSW0030RegrasFormatacaoBase::insert_COD_SERV_CORP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_EMP_ADQT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_PDV_EXT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_NUM_PDV_VAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_DSPO_NFC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::insert_COD_GRU_CLAS_RAM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.acq_name.compare( "VCH" ) != 0 && tbsw0030_params.isVan.compare( "TRUE" ) != 0 )
        tbsw0030.set_COD_GRU_CLAS_RAM( tbsw0030_params.cod_gru_clas_ram );
    else
        tbsw0030.set_COD_GRU_CLAS_RAM( 0 );
}

void TBSW0030RegrasFormatacaoBase::insert_IND_TRAN_TKN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if( tbsw0030_params.iss_name.compare( "MASTERCARD" )        == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_CRT" )     == 0 ||
        tbsw0030_params.iss_name.compare( "MASTER_HIPER_CRT" )  == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
        tbsw0030_params.iss_name.compare( "MAESTRO" )           == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_DBT" )     == 0 ||
        tbsw0030_params.iss_name.compare( "MASTER_HIPER_DBT" )  == 0 ||
        tbsw0030_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ||
        tbsw0030_params.iss_name.compare( "VISA_CREDITO" )      == 0 ||
        tbsw0030_params.iss_name.compare( "VISA_ELECTRON" )     == 0
       )
    {
        tbsw0030.set_IND_TRAN_TKN( " " );   // Start with this
    }
    else
    {
        tbsw0030.set_IND_TRAN_TKN( "N" );  // Other issuers
    }

}

void TBSW0030RegrasFormatacaoBase::insert_COD_ORG_APRV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.msg_category.compare( "CONF_PREAUT" ) == 0 && tbsw0030_params.codigoOrigemRespostaAutorizacao.empty( ) == false )
    {
        tbsw0030.SetCodOrgAprv( tbsw0030_params.codigoOrigemRespostaAutorizacao );
    }
    else
    {
        tbsw0030.SetCodOrgAprv( " " );
    }
}


//=========================================
//              GEN
//=========================================

void TBSW0030RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DTH_GMT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DTH_INI_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DAT_CTB_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTES
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_MSG_ISO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_PCM_ISO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_DTLH_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_PLN_PGMN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_CTGR_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_CMPM_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_RD_ORG( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT DIFERENTE POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_ESTB( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_TERM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_STAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_TCNL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTES
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_TERM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_RAM_ATVD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_POS_ENTR_MODO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_BNDR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_ID_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTES
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_PAIS_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DAT_VLD_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_TRK( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_CPTR_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO E USADO ATUALMENTE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_TRK_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_SERV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_SERV_SNHA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //UPDATE E INSERT DIFERENTE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_ID_PREV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_VAL_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_VAL_TOTL_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_MOED( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_CV( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_MOT_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_MOT_RSPS( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_NUM_MOT_RSPS( tbsw0030_params.pb_reason_code );
}

void TBSW0030RegrasFormatacaoBase::gen_COD_MOT_RSPS_EXT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_MOT_SW( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DTH_STTU_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    tbsw0030.set_DTH_STTU_TRAN( AcqUtils::dateTime( tbsw0030_params.local_date, tbsw0030_params.local_time ) );
}

void TBSW0030RegrasFormatacaoBase::gen_COD_PROD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_RSMO_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DAT_RSMO_VD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_LOC_ESTB( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_TERM_RLCD_CHIP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_DFZM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_ESTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_CPTRDO( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{

    if( tbsw0030_params.acq_name.compare( "ADM" ) == 0 ) // IMPORTANTE: ADM inclui transacoes SERASA
    {
        if (!strcmp(getenv( "NOM_FE_ACQR" ), "FEPDV") && (
            tbsw0030_params.status.compare( "1" ) == 0 || 
            tbsw0030_params.status.compare( "3" ) == 0 || 
            tbsw0030_params.status.compare( "4" ) == 0 ) ) {

            tbsw0030.set_IND_CPTRDO( "S" ); 

        } else {   
            tbsw0030.set_IND_CPTRDO( "N" );
        }
    }
    else if( tbsw0030_params.msg_category.compare( "CONF_PREAUT" ) == 0 )
    {
        tbsw0030.set_IND_CPTRDO( "N" );
    }
    else
    {
        if( ( tbsw0030_params.msg_category.compare( "VENDA" ) == 0 ||
              tbsw0030_params.msg_category.compare( "CONSULTA" ) == 0 ||
              tbsw0030_params.msg_category.compare( "CONFIRMACAO" ) == 0 ||
              tbsw0030_params.msg_category.compare( "ADV_APROVADO" ) == 0 ||
              // J3_2019 - Mensageria de pagamento ITI - INICIO
              tbsw0030_params.msg_category.compare( "PAGAMENTO" ) == 0 ||
              // J3_2019 - Mensageria de pagamento ITI - FIM
              tbsw0030_params.msg_category.compare( "ADV_NEGADO" ) == 0 ) &&
            ( tbsw0030_params.status.compare( "1" ) == 0 ||
              tbsw0030_params.status.compare( "2" ) == 0 ||
              tbsw0030_params.status.compare( "3" ) == 0 ||
              tbsw0030_params.status.compare( "4" ) == 0 ||
              tbsw0030_params.status.compare( "5" ) == 0 ) )
        {
            tbsw0030.set_IND_CPTRDO( "S" );
        }
        else if( tbsw0030_params.msg_category.compare( "ESTORNO" ) == 0 &&
                 tbsw0030_params.status.compare( "2" ) == 0 )
        {
            tbsw0030.set_IND_CPTRDO( "S" );
        }
        else if( tbsw0030_params.is_desfaz_estorno.compare( "TRUE" ) == 0 )
        {
            tbsw0030.set_IND_CPTRDO( "S" );
        }
        else if( tbsw0030_params.msg_category.compare( "DESFAZIMENTO" ) == 0 &&
                 tbsw0030_params.trn_tem_original.compare( "FALSE" ) == 0 && tbsw0030_params.status.compare( "2" ) != 0 ) //Resposta 57 da planilha do GAPS-2016
        {
            tbsw0030.set_IND_CPTRDO( "S" );
        }
        else
        {
            tbsw0030.set_IND_CPTRDO( "N" );
        }
    }
}

void TBSW0030RegrasFormatacaoBase::gen_IND_AGND_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_IMPR_CPOM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_EMSR_MTC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_DA_RLCD_CHIP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_DA_RLCD_IATA( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_TRAN_REFD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    if ( tbsw0030_params.local_ind_tran_refd.length( ) > 0 )
    {
        tbsw0030.set_IND_TRAN_REFD( tbsw0030_params.local_ind_tran_refd );
    }
    else
    {
        tbsw0030.set_IND_TRAN_REFD( "0" );
    }
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_TRAN_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO DIFERENTE POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DAT_EXPC_TRAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_VAL_TRAN_DLR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_VAL_COT_DLR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //NAO TRATADO PELO POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_CTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_VAL_TX( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO DIFERENTE POS E PDV
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_REF_RESTANTE( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_CNDC_CPTR_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_ENT_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_OPER_CNFR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_PRCN_TX_RISC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_VAL_TX_RISC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_CNDC_CPTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_SITE_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_HOST_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_FE_ISSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TXT_DA_ADIC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_TIP_MODL_CPTR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DTH_TRAN_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DAT_LQDC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_ISTT_ACQR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    // CAMPO SO USADO NO UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_ISTT_FRWD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    // CAMPO SO USADO NO UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_RSPS_DTLH_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    // CAMPO SO USADO NO UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_RSTD_NUM_CVC_2( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTES
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_SERV_TRK_CAR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_VLDC_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTES
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_AUT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //INSERT E UPDATE DIFERENTES
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_DA_RLCD_KMRC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_IND_TRAN_SEM_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_DAT_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_SEQ_UNC_PAUZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_TRAN_CAD( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_AUT_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_NTWK_ID_ACQR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_NTWK_ID_ACQR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_NTWK_ID_ROUT_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_NTWK_ID_ROUT_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_NTWK_ID_ISSR_ATLZ( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_NTWK_ID_ISSR_ORGL( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_RAM_MCC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_CNDC_CPTR_EMSR( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_PROD_CDST( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_SERV_CORP( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_EMP_ADQT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_PDV_EXT( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_NUM_PDV_VAN( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_DSPO_NFC( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}

void TBSW0030RegrasFormatacaoBase::gen_COD_GRU_CLAS_RAM( dbaccess_common::TBSW0030 &tbsw0030, const struct acq_common::tbsw0030_params &tbsw0030_params )
{
    //CAMPO SOMENTE PARA UPDATE
    WARNING_INVALID_FUNCTION;
}


// J4_2019 - Release Bandeiras Abril 2019 - INICIO
/// IndicadorPresencaPortador
/// Grava o indicador de presenca do portador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0030RegrasFormatacaoBase::IndicadorPresencaPortador( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertIndicadorPresencaPortador( dadosTabela, dadosParams );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateIndicadorPresencaPortador( dadosTabela, dadosParams );
    }
}

/// InsertIndicadorPresencaPortador
/// Insere o indicador de presenca do portador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::InsertIndicadorPresencaPortador( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( dadosParams.indicadorPresencaPortador.empty( ) == false )
    {
        dadosTabela.SetIndicadorPresencaPortador( dadosParams.indicadorPresencaPortador );
    }
    else
    {
        dadosTabela.SetIndicadorPresencaPortador( " " );
    }
}

/// UpdateIndicadorPresencaPortador
/// Atualiza o indicador de presenca do portador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::UpdateIndicadorPresencaPortador( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if( dadosParams.indicadorPresencaPortador.empty( ) == false 
        && dadosParams.msg_category.compare( "ESTORNO" ) != 0 
        &&  dadosParams.msg_category.compare( "DESFAZIMENTO" ) != 0 )
    {
        dadosTabela.SetIndicadorPresencaPortador( dadosParams.indicadorPresencaPortador );
    }
}

/// IndicadorTecnologiaTerminal
/// Grava o indicador de tecnologia do terminal
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0030RegrasFormatacaoBase::IndicadorTecnologiaTerminal( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertIndicadorTecnologiaTerminal( dadosTabela, dadosParams );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateIndicadorTecnologiaTerminal( dadosTabela, dadosParams );
    }
}

/// InsertIndicadorTecnologiaTerminal
/// Insere o indicador de tecnologia do terminal
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::InsertIndicadorTecnologiaTerminal( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( dadosParams.indicadorTecnologiaTerminal.empty( ) == false )
    {
        dadosTabela.SetIndicadorTecnologiaTerminal( dadosParams.indicadorTecnologiaTerminal );
    }
    else
    {
        dadosTabela.SetIndicadorTecnologiaTerminal( " " );
    }
}

/// UpdateIndicadorTecnologiaTerminal
/// Atualiza o indicador de tecnologia do terminal
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::UpdateIndicadorTecnologiaTerminal( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if( dadosParams.indicadorTecnologiaTerminal.empty( ) == false 
        && dadosParams.msg_category.compare( "ESTORNO" ) != 0 
        &&  dadosParams.msg_category.compare( "DESFAZIMENTO" ) != 0 )
    {
        dadosTabela.SetIndicadorTecnologiaTerminal( dadosParams.indicadorTecnologiaTerminal );
    }
}
// J4_2019 - Release Bandeiras Abril 2019 - FIM


// J2_2020 - WQ3 QRCODE - INICIO
/// TipoFormatadorHeader
/// Grava o tipo do formatador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0030RegrasFormatacaoBase::TipoFormatadorHeader( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertTipoFormatadorHeader( dadosTabela, dadosParams );
    }
    // nao precisa atualizar campo. gravado no INSERT
    //else if( operacao == acq_common::UPDATE )
    //{
    //    UpdateTipoFormatadorHeader( dadosTabela, dadosParams );
    //}
}

/// InsertTipoFormatadorHeader
/// Insere o tipo do formatador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::InsertTipoFormatadorHeader( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( dadosParams.tipoFormatadorHeader.empty( ) == false )
    {
        dadosTabela.SetTipoFormatadorHeader( dadosParams.tipoFormatadorHeader );
    }
    else
    {
        dadosTabela.SetTipoFormatadorHeader( " " );
    }
}

/// UpdateTipoFormatadorHeader
/// Atualiza o tipo do formatador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::UpdateTipoFormatadorHeader( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if( dadosParams.tipoFormatadorHeader.empty( ) == false 
        && dadosParams.msg_category.compare( "ESTORNO" ) != 0 
        &&  dadosParams.msg_category.compare( "DESFAZIMENTO" ) != 0 )
    {
        dadosTabela.SetTipoFormatadorHeader( dadosParams.tipoFormatadorHeader );
    }
}

/// IndicacaoQrcode
/// Grava o indicador de QRCODE
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0030RegrasFormatacaoBase::IndicacaoQrcode( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertIndicacaoQrcode( dadosTabela, dadosParams );
    }
    // nao precisa atualizar campo. gravado no INSERT
    //else if( operacao == acq_common::UPDATE )
    //{
    //    UpdateIndicacaoQrcode( dadosTabela, dadosParams );
    //}
}

/// InsertIndicacaoQrcode
/// Insere o indicador de QRCODE
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::InsertIndicacaoQrcode( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( dadosParams.indicacaoQrcode.empty( ) == false )
    {
        if( dadosParams.tipoFormatadorHeader.compare( "WQ3" ) == 0 &&
                 dadosParams.indicacaoQrcode.compare( "03" ) == 0 )
        {
            // se instancia_formatador = wq3 e DE048 tag 0x4c = 03
            dadosTabela.SetIndicacaoQrcode( "S" );
        }
        else
        {
            dadosTabela.SetIndicacaoQrcode( "N" );
        }
    }
    else
    {
        dadosTabela.SetIndicacaoQrcode( "N" );
    }
}

/// UpdateIndicacaoQrcode
/// Atualiza o indicador de QRCODE
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::UpdateIndicacaoQrcode( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if( dadosParams.indicacaoQrcode.empty( ) == false 
        && dadosParams.msg_category.compare( "ESTORNO" ) != 0 
        &&  dadosParams.msg_category.compare( "DESFAZIMENTO" ) != 0 )
    {
        dadosTabela.SetIndicacaoQrcode( dadosParams.indicacaoQrcode );
    }
}

/// CodigoParceiro
/// Grava o codigo parceiro da carteira digital
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0030RegrasFormatacaoBase::CodigoParceiro( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertCodigoParceiro( dadosTabela, dadosParams );
    }
    // nao precisa atualizar campo. gravado no INSERT
    //else if( operacao == acq_common::UPDATE )
    //{
    //    UpdatecodigoParceiro( dadosTabela, dadosParams );
    //}
}

/// InsertCodigoParceiro
/// Insere o codigo parceiro da carteira digital
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::InsertCodigoParceiro( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( dadosParams.codigoParceiro > 0 )
    {
        dadosTabela.SetCodigoParceiro( dadosParams.codigoParceiro );
    }
    else
    {
        dadosTabela.SetCodigoParceiro( 0 );
    }
}

/// UpdateCodigoParceiro
/// Atualiza o codigo parceiro da carteira digital
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::UpdateCodigoParceiro( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if( dadosParams.codigoParceiro > 0  
        && dadosParams.msg_category.compare( "ESTORNO" ) != 0 
        &&  dadosParams.msg_category.compare( "DESFAZIMENTO" ) != 0 )
    {
        dadosTabela.SetCodigoParceiro( dadosParams.codigoParceiro );
    }
}
// J2_2020 - WQ3 QRCODE - FIM

/// CodigoRoteamentoTransacao
/// Grava o codigo de roteamento da transacao
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 22/05/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0030RegrasFormatacaoBase::CodigoRoteamentoTransacao( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertCodigoRoteamentoTransacao( dadosTabela, dadosParams );
    }
}

/// InsertCodigoRoteamentoTransacao
/// Insere o codigo de roteamento da transacao
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 22/05/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::InsertCodigoRoteamentoTransacao( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( std::string( getenv( "NOM_FE_ACQR" ) ) == "FEPDV" )
    {
        dadosTabela.SetCodigoRoteamentoTransacao( dadosParams.codigoRoteamentoTransacao );
    }
    else
    {
        dadosTabela.SetCodigoRoteamentoTransacao( "" );
    }
}

// AUT1-2168 - PIX - INICIO
/// RequestIdPix
/// Grava o request id do PIX
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 13/10/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0030RegrasFormatacaoBase::RequestIdPix( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertRequestIdPix( dadosTabela, dadosParams );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateRequestIdPix( dadosTabela, dadosParams );
    }
}

/// InsertRequestIdPix
/// Insere o request id do PIX
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 13/10/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::InsertRequestIdPix( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( dadosParams.requestIdPix.empty( ) == false )
    {
        dadosTabela.SetRequestIdPix( dadosParams.requestIdPix );
    }
}

/// UpdateRequestIdPix
/// Atualiza o tipo do formatador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 09/02/2020 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0030RegrasFormatacaoBase::UpdateRequestIdPix( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if( dadosParams.requestIdPix.empty( ) == false )
    {
        dadosTabela.SetRequestIdPix( dadosParams.requestIdPix );
    }
}
// AUT1-2168 - PIX - FIM

void TBSW0030RegrasFormatacaoBase::CodigoProcessoEmissor( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::UPDATE )
    {
        dadosTabela.SetCodigoProcessoEmissor( dadosParams.codigoProcessoEmissor );
    }
}

void TBSW0030RegrasFormatacaoBase::IdentificadorReferenciaBandeira( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        dadosTabela.SetIdentificadorReferenciaBandeira( "" );
    }
    else if( operacao == acq_common::UPDATE )
    {
        dadosTabela.SetIdentificadorReferenciaBandeira( dadosParams.identificadorReferenciaBandeira );
    }
}

void TBSW0030RegrasFormatacaoBase::CodigoParceiroAdquirente( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertCodigoParceiroAdquirente( dadosTabela, dadosParams );
    }
    // nao precisa atualizar campo. gravado no INSERT
    //else if( operacao == acq_common::UPDATE )
    //{
    //    UpdatecodigoParceiroAdquirente( dadosTabela, dadosParams );
    //}
}

void TBSW0030RegrasFormatacaoBase::InsertCodigoParceiroAdquirente( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( dadosParams.codigoParceiroAdquirente > 0 )
    {
        dadosTabela.SetCodigoParceiroAdquirente( dadosParams.codigoParceiroAdquirente );
    }
    else
    {
        dadosTabela.SetCodigoParceiroAdquirente( 0 );
    }
}

void TBSW0030RegrasFormatacaoBase::UpdateCodigoParceiroAdquirente( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    return;
}

void TBSW0030RegrasFormatacaoBase::SituacaoOferta( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertSituacaoOferta( dadosTabela, dadosParams );
    }
    // nao precisa atualizar campo. gravado no INSERT
    //else if( operacao == acq_common::UPDATE )
    //{
    //    UpdateSituacaoOferta( dadosTabela, dadosParams );
    //}
}

void TBSW0030RegrasFormatacaoBase::InsertSituacaoOferta( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    if ( dadosParams.situacaoOferta > 0 && dadosParams.situacaoOferta < 5 )
    {
        dadosTabela.SetSituacaoOferta( dadosParams.situacaoOferta );
    }
    else
    {
        dadosTabela.SetSituacaoOferta( 0 );
    }
}

void TBSW0030RegrasFormatacaoBase::UpdateSituacaoOferta( dbaccess_common::TBSW0030 &dadosTabela, const struct acq_common::tbsw0030_params &dadosParams )
{
    return;
}