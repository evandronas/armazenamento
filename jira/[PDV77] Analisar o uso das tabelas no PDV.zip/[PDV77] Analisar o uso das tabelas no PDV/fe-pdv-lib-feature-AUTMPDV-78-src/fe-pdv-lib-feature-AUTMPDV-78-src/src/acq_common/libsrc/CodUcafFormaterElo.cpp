#pragma once
#include <cstring>
#include "CodUcafFormaterElo.hpp"

CodUcafFormaterElo::CodUcafFormaterElo( const std::string &cavv, const std::string &programProtocol, unsigned long codigoTransacao ) : CodUcafFormater( cavv )
{
    m_programProtocol = programProtocol;
    m_codigoTransacao = codigoTransacao;
}

CodUcafFormaterElo::CodUcafFormaterElo( const std::string &cavv ) : CodUcafFormater( cavv )
{
    m_programProtocol = "";
    m_codigoTransacao = 0;
}

CodUcafFormaterElo::~CodUcafFormaterElo()
{
}

CodUcafFormaterElo CodUcafFormaterElo::setCodigoTransacao( unsigned long codigoTransacao ){
    m_codigoTransacao = codigoTransacao;
    return *this;
}

/// formatElo
/// Retorna CAVV no formato especifico Elo
std::string CodUcafFormaterElo::format()
{
    // converte o cavv para ascii
    if ( m_cavv.length() )
    {
        char codigoVerificacaoAutenticacaoConvertido[50] = {0};
        std::memset(codigoVerificacaoAutenticacaoConvertido, 0, sizeof(codigoVerificacaoAutenticacaoConvertido));
        int codigoVerificacaoAutenticacaoConvertidoSize = m_cavv.size()*2;

        if (m_codigoTransacao == 68 || m_codigoTransacao == 69 || m_codigoTransacao == 80 || m_codigoTransacao == 81) // confirmacao de pre autorizacao
        {
            if (codigoVerificacaoAutenticacaoConvertidoSize > 42)
            {
                codigoVerificacaoAutenticacaoConvertidoSize = 42;
            }
            BinaryToChar( codigoVerificacaoAutenticacaoConvertido, (char *) m_cavv.c_str(), codigoVerificacaoAutenticacaoConvertidoSize );

            if (std::strncmp("000000000000000000000000000000000000000000", codigoVerificacaoAutenticacaoConvertido, codigoVerificacaoAutenticacaoConvertidoSize) != 0)
            {
                return std::string(codigoVerificacaoAutenticacaoConvertido);
            }
        }
        else
        {
            if (codigoVerificacaoAutenticacaoConvertidoSize > 40)
            {
                codigoVerificacaoAutenticacaoConvertidoSize = 40;
            }
            BinaryToChar( codigoVerificacaoAutenticacaoConvertido, (char *) m_cavv.c_str(), codigoVerificacaoAutenticacaoConvertidoSize );

            if (std::strncmp("0000000000000000000000000000000000000000", codigoVerificacaoAutenticacaoConvertido, codigoVerificacaoAutenticacaoConvertidoSize) != 0)
            {
                char codigoVerificacaoAutenticacaoFinal[50] = {0};
                std::memset(codigoVerificacaoAutenticacaoFinal, 0, sizeof(codigoVerificacaoAutenticacaoFinal));

                if (m_programProtocol == "2") // DE48.66.1
                {
                    // 02 - Programa 3D-Secure Elo
                    std::strncpy(codigoVerificacaoAutenticacaoFinal, "02", 2);
                }
                else
                {
                    // 03 - Autenticacao In-App
                    std::strncpy(codigoVerificacaoAutenticacaoFinal, "03", 2);
                }
                std::strncat(codigoVerificacaoAutenticacaoFinal, codigoVerificacaoAutenticacaoConvertido, codigoVerificacaoAutenticacaoConvertidoSize);

                return std::string(codigoVerificacaoAutenticacaoFinal);
            }
        }
    }
    return std::string(" ");
}