#include <cstring>
#include<TBSW0058RegrasFormatacaoBase.hpp>
#include<AcqUtils.hpp>
#include <sstream>
#include <iomanip>  
//#include <iostream>

TBSW0058RegrasFormatacaoBase::TBSW0058RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0058RegrasFormatacaoBase::~TBSW0058RegrasFormatacaoBase( )
{
}

void TBSW0058RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_TIP_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_TIP_TRAN(tbsw0058_params.transcode);
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_MOT_RSPS( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NUM_MOT_RSPS( tbsw0058_params.pb_reason_code );
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_TERM( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_RD_ORG( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_POS_ENTR_MODO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_VAL_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_RAM_ATVD( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::string orig_panAux = tbsw0058_params.orig_pan;
    if ( strlen( orig_panAux.c_str( ) ) )
    {
        // t689066@FIS_BEGIN - Data: 30/12/2013 - BT53125: cartoes menores que 16 estavam gravando NUM_CAR com separador.
        size_t l_pos = orig_panAux.find_first_of("=DF^");
        if( l_pos != std::string::npos )
        {
            orig_panAux.erase( l_pos, std::string::npos );
        }
        // t689066@FIS_END - Data: 30/12/2013 - BT53125: cartoes menores que 16 estavam gravando NUM_CAR com separador.
       tbsw0058.set_NUM_CAR( orig_panAux );
    }
    else
    {
        tbsw0058.set_NUM_CAR( " " );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_VAL_COT_DLR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_DAT_VLD_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_TRK_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_MOED( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_PAIS_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_SERV_SNHA( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_IND_RD_ORG( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_MOT_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_DAT_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_DAT_PAUZ( AcqUtils::dateTime( tbsw0058_params.local_date, tbsw0058_params.local_time ) );
}

void TBSW0058RegrasFormatacaoBase::gen_COD_GRU_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_MTZ_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_DTH_INI_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_DTH_STTU_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    dbm_datetime_t l_dth_ini_tran_unix = AcqUtils::dateTime( tbsw0058_params.local_date, tbsw0058_params.local_time );
    tbsw0058.set_DTH_STTU_TRAN(l_dth_ini_tran_unix);
}

void TBSW0058RegrasFormatacaoBase::gen_DTH_GMT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_STAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_VAL_EFTV_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_QTD_PRCL_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_IND_RD_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}
    
void TBSW0058RegrasFormatacaoBase::gen_COD_CNDC_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::string fe_acq( getenv( "NOM_FE_ACQR" ) );
    std::string conteudo_de061 = tbsw0058_params.cod_cndc_cptr;
    std::stringstream s_modo_entrada; // modo de entrada pode conter ate 3 digitos
    std::string cod_cndc_cptr;
    int digt_modo_entrada;
    
    if( conteudo_de061.empty( ) == true )
    {
        return tbsw0058.set_COD_CNDC_CPTR( "00000000000" );
    }
	s_modo_entrada << tbsw0058_params.pos_entry_code;
    digt_modo_entrada = atoi( s_modo_entrada.str( ).substr( 0, 1 ).c_str( ) );
    if( ( (digt_modo_entrada == 7) || (digt_modo_entrada == 8) ) && ( s_modo_entrada.str( ).length( ) > 1))
    {
        digt_modo_entrada = atoi( s_modo_entrada.str( ).substr( 0, 2 ).c_str( ) );
    }
    if( conteudo_de061.length( ) <= 8 && fe_acq == "FEPDV" )
    {
        if( digt_modo_entrada == 5 )
        {
            conteudo_de061 = "00000000008";
        }
        else
        {
            conteudo_de061 = "00000000007";
        }
    }
    
    //posicao 1
    if( conteudo_de061.substr( 0, 1 ) == "1" )
    {
        cod_cndc_cptr = conteudo_de061.substr( 0, 1 );
    }
    else
    {
        cod_cndc_cptr = "0";
    }
    
    //posicao 2
    if( conteudo_de061.substr( 1, 1 ) == "0" || conteudo_de061.substr( 1, 1 ) == "9" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 1, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }

    //posicao 3
    if( conteudo_de061.substr( 2, 1 ) == "0" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 2, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }
    
    //posicao 4
    if( conteudo_de061.substr( 3, 1 ) == "0" && 
        !( digt_modo_entrada == 1 || digt_modo_entrada == 79 || digt_modo_entrada == 81 ) )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 3, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }
    
    //posicao 5
    if( conteudo_de061.substr( 4, 1 ) == "0" && 
        !( digt_modo_entrada == 1 || digt_modo_entrada == 79 || digt_modo_entrada == 81 ) )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 4, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "1" );
    }
    
    //posicao 6
    if( conteudo_de061.substr( 5, 1 ) == "1" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 5, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }
    
    //posicao 7
    if( conteudo_de061.substr( 6, 1 ) == "4" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 6, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }
    
    //posicao 8
    if( conteudo_de061.substr( 7, 1 ) == "1" || conteudo_de061.substr( 7, 1 ) == "2" )
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 7, 1 ) );
    }
    else
    {
        cod_cndc_cptr.append( "0" );
    }
    
    //posicao 9
    if( fe_acq == "FEPOS" )
    {
        cod_cndc_cptr.append( "0" );
    }
    else
    {
        if( conteudo_de061.substr( 8, 1 ) == "1" || conteudo_de061.substr( 8, 1 ) == "2" )
        {
            cod_cndc_cptr.append( conteudo_de061.substr( 8, 1 ) );
        }
        else
        {
            cod_cndc_cptr.append( "0" );
        }    
    }
    
    //posicao 10
	// AUT1-2555/3047 - VISA MASTERCARD CAT 7-9 - INICIO
	if ( fe_acq.compare( "FEPDV" ) == 0)
	{
		cod_cndc_cptr.append( conteudo_de061.substr( 9, 1 ) );
	}
	// AUT1-2555/3047 - VISA MASTERCARD CAT 7-9 - FIM
	else
	{
		cod_cndc_cptr.append( "0" );
	}
    
    //posicao 11
    if( ( fe_acq == "FEPOS" ) && ( conteudo_de061.length( ) < 11 ))
    {
            cod_cndc_cptr.append( "0" );
    }
    else
    {
        cod_cndc_cptr.append( conteudo_de061.substr( 10, 1 ) );
    }
    
    tbsw0058.set_COD_CNDC_CPTR( cod_cndc_cptr );
}

void TBSW0058RegrasFormatacaoBase::gen_DAT_CNFR_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_VAL_TRAN_DLR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_DAT_CAN_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_DAT_VLD_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.dt_vdd_pre_auz )
    {            
        char l_DataFormatada[ 16 ];
        int l_ano;
        int l_mes;
        int l_dia;
        l_ano = tbsw0058_params.dt_vdd_pre_auz % 10000;
        l_mes = ( tbsw0058_params.dt_vdd_pre_auz / 10000) % 100;
        l_dia = tbsw0058_params.dt_vdd_pre_auz / 1000000;
        sprintf( l_DataFormatada, "%04d%02d%02d", l_ano, l_mes, l_dia );
        tbsw0058.set_DAT_VLD_PAUZ( AcqUtils::dateTime( atol( l_DataFormatada ), 0 ) );
    }
    else
    {
        tbsw0058.set_DAT_VLD_PAUZ( AcqUtils::dateTime( tbsw0058_params.local_date, tbsw0058_params.local_time ) );
    }
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_PORT_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_MSG_ISO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_COD_MSG_ISO( tbsw0058_params.msgtype );
}

void TBSW0058RegrasFormatacaoBase::gen_COD_PCM_ISO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_COD_PCM_ISO( tbsw0058_params.pcode );
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_SITE_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_HOST_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_FE_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{    
//Deve ser gravado o Nome do Site do Acquirer da mensagem que est� gerando a atualiza��o  
//(confirma��o, estorno, desfazimento ou sonda) na mensagem que esta sendo atualizada (venda ou consulta). 
//Gravado na solicita��o (da rede de captura). O registro da mensagem em quest�o grava "NULL", e na mensagem atualizada deve conter o valor do mesmo campo ORGL [CTO/CAS/SW7.1] 
//
//Este campo deve ser preenchido quando o campo IND_STTU_TRAN for atualizado.
//No momento da venda, o registro correspondente deve gravar "NULL".
//Registro de Venda confirmada: Registro de venda *ATLZ = Valor correspondente ao ocorrido na confirma��o.
//Estorno aprovado: Registro de venda *ATLZ= *ORGL do estorno, Registro de Estorno *ATLZ= NULL 
//Estorno negado: Registro de venda *ATLZ n�o alterado, Registro de Estorno *ATLZ=NULL 
//Desfazimento de venda aprovado: Registro de venda *ATLZ= *ORGL do desfazimento, Registro de Desfazimento *ATLZ= NULL 
//Desfazimento de estorno aprovado: Registro de venda *ATLZ n�o alterado, estorno *ATLZ= *ORGL do desfazimento, Registro de Desfazimento *ATLZ= NULL
	if( tbsw0058_params.msg_name.compare("ADV_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_PARC_NEG") != 0 )
	{	
		tbsw0058.set_NOM_SITE_ACQR_ATLZ( std::string( getenv( "NOM_SITE_ACQR" ) ) );  
	}
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
 	if( tbsw0058_params.msg_name.compare("ADV_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_PARC_NEG") != 0 )
	{	
		tbsw0058.set_NOM_HOST_ACQR_ATLZ( std::string( getenv( "NOM_HOST_ACQR" ) ) );
   }
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
	if( tbsw0058_params.msg_name.compare("ADV_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_PARC_NEG") != 0 )
	{	
		tbsw0058.set_NOM_FE_ACQR_ATLZ( std::string( getenv( "NOM_FE_ACQR" ) ) );
	}
}

void TBSW0058RegrasFormatacaoBase::gen_COD_MOT_ISO_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_TERM_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_DAT_MOV_TRAN_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_DTH_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_IND_RD_ORG_ESTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_IND_STTU_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{   
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_ESTB_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_ESTB_ESTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_ID_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_SEQ_UNC_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_STAN_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_BNDR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_IND_EMSR_MTC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_AVSO_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_TXT_DA_ADIC_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NOM_FNTS_PDV( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //Utilizado apenas pelo FE-WEB
    //tbsw0058.set_NOM_FNTS_PDV(local_date);
}

void TBSW0058RegrasFormatacaoBase::gen_COD_PGM_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //Utilizado apenas pelo FE-WEB
    //tbsw0058.set_COD_PGM_AUT(local_date);
}

void TBSW0058RegrasFormatacaoBase::gen_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //Utilizado apenas pelo FE-WEB
    //tbsw0058.set_IND_NVL_SGRA_KMRC(local_date);
}

void TBSW0058RegrasFormatacaoBase::gen_COD_UCAF( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //Utilizado apenas pelo FE-WEB
    //tbsw0058.set_COD_UCAF(local_date);
}

void TBSW0058RegrasFormatacaoBase::gen_COD_AUT_EMSR_CNVT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_AUT_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NTWK_ID_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NTWK_ID_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NTWK_ID_ACQR_ORGL( std::string( getenv( "NETWORKID" ) ) );
}

void TBSW0058RegrasFormatacaoBase::gen_NTWK_ID_ROUTE_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{ 
	if( tbsw0058_params.msg_name.compare("ADV_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_PARC_NEG") != 0 )
	{	
		tbsw0058.set_NTWK_ID_ROUTE_ATLZ( tbsw0058_params.acquirer );
	}
}

void TBSW0058RegrasFormatacaoBase::gen_NTWK_ID_ROUTE_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NTWK_ID_ROUTE_ORGL( tbsw0058_params.receive_inst_id );
}

void TBSW0058RegrasFormatacaoBase::gen_NTWK_ID_ISSR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
	if( tbsw0058_params.msg_name.compare("ADV_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_PARC_NEG") != 0 )
	{	
		tbsw0058.set_NTWK_ID_ISSR_ATLZ( tbsw0058_params.issuer );
	}
}

void TBSW0058RegrasFormatacaoBase::gen_NTWK_ID_ISSR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NTWK_ID_ISSR_ORGL( tbsw0058_params.issuer );
}

void TBSW0058RegrasFormatacaoBase::gen_IND_CPTRDO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //tbsw0058.set_IND_CPTRDO(local_date);
}

void TBSW0058RegrasFormatacaoBase::gen_COD_CTAH_VOCH( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_TIP_PROD_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_PDV_EXT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_PDV_VAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_GRU_CLAS_RAM( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_NUM_REF_TRAN( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::gen_COD_CPCD_TERM( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

/// COD_PROD_MTC
void TBSW0058RegrasFormatacaoBase::GenCodigoProdutoMastercard( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

/// COD_RGAO_MTC
void TBSW0058RegrasFormatacaoBase::GenCodigoRegiaoMastercard( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

//###################################################################################################################################
//###################################################################################################################################
//###################################################################################################################################
//###################################################################################################################################
//###################################################################################################################################

void TBSW0058RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_DAT_MOV_TRAN(tbsw0058_params.local_date);
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NUM_SEQ_UNC( atol( tbsw0058_params.refnum.c_str( ) ) );
}

void TBSW0058RegrasFormatacaoBase::insert_TIP_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_TIP_TRAN( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_MOT_RSPS( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NUM_MOT_RSPS( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NUM_ESTB( tbsw0058_params.termloc );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_TERM( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{   
    if( !tbsw0058_params.termid.empty( ) )
    {
        tbsw0058.set_COD_TERM( tbsw0058_params.termid );
    }
    else
    {
        tbsw0058.set_COD_TERM( " " );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_RD_ORG( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NUM_RD_ORG(0);
}

void TBSW0058RegrasFormatacaoBase::insert_COD_POS_ENTR_MODO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::ostringstream str_pos_entry_code;
    str_pos_entry_code << tbsw0058_params.pos_entry_code;
    std::string aux = str_pos_entry_code.str();
        
    if ( aux.size( ) > 0 && aux.size( ) <= 3 )
    {
        std::string leftPaddedPosEntryCode = std::string( 3 - aux.length(), '0') + aux;
        tbsw0058.set_COD_POS_ENTR_MODO( leftPaddedPosEntryCode );
    }
    else
    {
        tbsw0058.set_COD_POS_ENTR_MODO( " " );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0058RegrasFormatacaoBase::insert_COD_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_COD_EMSR( tbsw0058_params.cd_ems );
}

void TBSW0058RegrasFormatacaoBase::insert_VAL_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.acq_currency_code != 840 )
    {
        oasis_dec_t l_dec_amount;
        dbm_chartodec( &l_dec_amount, tbsw0058_params.amount.c_str( ), 0 );
        tbsw0058.set_VAL_TRAN( l_dec_amount );
    }
    else
    {
        std::string l_zero( "0.0" );
        oasis_dec_t l_dec_zero;
        dbm_chartodec( &l_dec_zero, l_zero.c_str( ), 0 );
        tbsw0058.set_VAL_TRAN( l_dec_zero );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_COD_RAM_ATVD( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( tbsw0058_params.mer_cat_code.length( ) )
    {    
        tbsw0058.set_COD_RAM_ATVD( atoi (tbsw0058_params.mer_cat_code.c_str( ) ) );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NUM_CAR( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_VAL_COT_DLR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_DAT_VLD_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //DAT_VLD_CAR     shc_data.expiry_date( vem YYMM )
    //OBS: sw_date_t encapsua data no formato YYYYMMDD para enviar ao banco.
    sw_date_t expiry_dateAux;
	int mod_expiry_date = 0;
	int expiry_date_signature = 1212;

	mod_expiry_date = tbsw0058_params.expiry_date % 100;
	if (mod_expiry_date < 1 || mod_expiry_date > 12)
		expiry_dateAux.date = ( ( ( tbsw0058.get_DAT_MOV_TRAN() / 1000000 ) * 1000000 ) + ( expiry_date_signature * 100 + 1 ) );
	else
		expiry_dateAux.date = ( ( ( tbsw0058.get_DAT_MOV_TRAN() / 1000000 ) * 1000000 ) + ( tbsw0058_params.expiry_date * 100 + 1 ) );
    tbsw0058.set_DAT_VLD_CAR( expiry_dateAux );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_TRK_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{  
    if( tbsw0058_params.msg_category.compare( "DESFAZIMENTO" ) == 0 || tbsw0058_params.msg_category.compare( "ESTORNO" ) == 0 )
    {
        if( tbsw0058_params.cod_trk_car.empty( ) == false )
        {
            tbsw0058.set_COD_TRK_CAR( tbsw0058_params.cod_trk_car );
        }
    }
    else if( tbsw0058_params.acq_name.compare( "VCH" ) == 0 || tbsw0058_params.msg_name.compare( "VEND_DBT_PREDAT" ) == 0 || tbsw0058_params.msg_name.compare( "VEND_DBT_PREDAT_ZOLKIN" ) == 0 ) 
    {
        if( tbsw0058_params.track2.empty( ) == false )
        {
            tbsw0058.set_COD_TRK_CAR( tbsw0058_params.track2.substr( 0, 40 ) );
        }
        else if( tbsw0058_params.track3.empty( ) == false )
        {
            tbsw0058.set_COD_TRK_CAR( tbsw0058_params.track3.substr( 0, 40 ) );
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
    //MARCARA CARACTERES APOS O SEPARADOR
    else if( tbsw0058_params.msg_category.compare( "PRE_AUTORIZACAO" ) == 0 )
    {
        if( tbsw0058_params.track2.empty( ) == false )
        {
            std::string local_track2 = tbsw0058_params.track2;
            int   pos = local_track2.find_first_of("=DF");
            if( pos != std::string::npos )
            {
                int tam = local_track2.length( ) - pos;
                local_track2.replace( pos + 1, tam - 1, tam - 1, 'X');
                tbsw0058.set_COD_TRK_CAR( local_track2.substr( 0, 40 ) );
            }
            else
            {
                WARNING_FLOW_ERROR;
            }
        }
        else if( tbsw0058_params.track3.empty( ) == false )
        {
            std::string local_track3 = tbsw0058_params.track3;
            int pos = local_track3.find( '^' );
            if( pos != std::string::npos )
            {
                pos = local_track3.find( '^', pos + 1 );
                if( pos == std::string::npos )
                {
                    WARNING_FLOW_ERROR;
                }
            
                int tam = local_track3.length( ) - pos;
                local_track3.replace( pos + 1, tam - 1, tam - 1, 'X');
                tbsw0058.set_COD_TRK_CAR( local_track3.substr( 0, 40 ) );
            }
            else
            {
                WARNING_FLOW_ERROR;
            }
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
    //MARCARA CARACTERES APOS A DATA DE VALIDADE
    else if( tbsw0058_params.msg_category.compare( "VENDA" ) == 0 && tbsw0058_params.acq_name.compare( "DBT" ) == 0 )
    {
        if( tbsw0058_params.track2.empty( ) == false )
        {
            std::string local_track2;
			std::size_t pos = tbsw0058_params.track2.find_first_of("=D^F");
			if( pos == std::string::npos )
			{
				WARNING_FLOW_ERROR;
			}
			else
			{
				local_track2.append( pos, 'X' );
				local_track2.append( tbsw0058_params.track2.substr( pos, 5 ) );
				local_track2.append( tbsw0058_params.track2.length( ) - local_track2.length( ), 'X' );
				if( local_track2.length( ) > 40 )
				{
					local_track2 = local_track2.substr( 0, 40 );
				}
				else if( local_track2.length( ) < 40 )
				{
					local_track2.append( 40 - local_track2.length( ), ' ' );
				}
				tbsw0058.set_COD_TRK_CAR( local_track2 );
			}
        }
        else
        {
            WARNING_FLOW_ERROR;
        }
    }
    else
    {
        WARNING_FLOW_ERROR;
    }
}

void TBSW0058RegrasFormatacaoBase::insert_COD_MOED( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    unsigned long l_ulong = 0;
    if( tbsw0058_params.mer_cat_code.length( ) )
    {
        l_ulong = atoi( tbsw0058_params.mer_cat_code.substr( 1, 1 ).c_str() );
    }
    
    std::string cod_moed;
    if( l_ulong == 8 || tbsw0058_params.mer_cat_code == "61300" )
    {
        cod_moed = "840";
    }
    else
    {
        cod_moed = "986";
    }
    
    tbsw0058.set_COD_MOED( cod_moed );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_PAIS_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_COD_PAIS_CAR( std::string( "000" ) );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_SERV_SNHA( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( tbsw0058_params.has_pin.compare( "TRUE" ) == 0 )
    {
        if( tbsw0058_params.status.compare( "2" ) == 0 )
        {
            tbsw0058.set_COD_SERV_SNHA( "RW" );
        }
        else if( tbsw0058_params.iss_name.compare( "MASTERCARD" ) == 0 || tbsw0058_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 ||
                 tbsw0058_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 || tbsw0058_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 )
        {
            tbsw0058.set_COD_SERV_SNHA( "PX" );
        }
        else
        {
            if( tbsw0058_params.iss_name.compare( "VISA_CREDITO" ) == 0 )
            {
                tbsw0058.set_COD_SERV_SNHA( "  " );
            }
            else
            {
                tbsw0058.set_COD_SERV_SNHA( "00" );
            }
        }
    }
    else
    {
        tbsw0058.set_COD_SERV_SNHA( "  " );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_IND_RD_ORG( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.termid_type.compare( "AVR" ) == 0 || tbsw0058_params.termid_type.compare( "OL" ) == 0 )
    {
        tbsw0058.set_IND_RD_ORG( "1" );
    }
    else if ( tbsw0058_params.termid_type.compare( "KMC" ) == 0 || tbsw0058_params.termid_type.compare( "MPG" ) == 0 )
    {
        tbsw0058.set_IND_RD_ORG( "5" );
    }
    else if ( tbsw0058_params.termid_type.compare( "PDVDIAL" ) == 0 || tbsw0058_params.termid_type.compare( "HY8583" ) == 0 )
    {
        tbsw0058.set_IND_RD_ORG( "3" );
    }
    else if ( tbsw0058_params.termid_type.compare( "ECR" ) == 0 )
    {
        tbsw0058.set_IND_RD_ORG( "2" );
    }
    else
    {
        tbsw0058.set_IND_RD_ORG( " " );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_COD_MOT_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_COD_MOT_AUT( std::string( " " ) );    
}

void TBSW0058RegrasFormatacaoBase::insert_DAT_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DAT_PAUZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_GRU_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.cod_gru_estb.size( ) > 0 )
    {
        tbsw0058.set_COD_GRU_ESTB( atol ( tbsw0058_params.cod_gru_estb.c_str( ) ) );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_COD_MTZ_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
// insert com status 2 possivel apenas com Transacao negada pelo SW...
    if ( tbsw0058_params.status.compare( "2" ) == 0 )
    {
        tbsw0058.set_COD_MTZ_ESTB( 0 );
    }
    else
    {
        if ( tbsw0058_params.cod_mtz_estb.size( ) > 0 )
        {
            tbsw0058.set_COD_MTZ_ESTB( atol ( tbsw0058_params.cod_mtz_estb.c_str( ) ) );
        }
        else
        {
            tbsw0058.set_COD_MTZ_ESTB( 0 );
            WARNING_EMPTY_STRING;
        }
    }
}

void TBSW0058RegrasFormatacaoBase::insert_DTH_INI_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    dbm_datetime_t l_dth_ini_tran_unix = AcqUtils::dateTime( tbsw0058_params.local_date, tbsw0058_params.local_time );
    tbsw0058.set_DTH_INI_TRAN(l_dth_ini_tran_unix);
}

void TBSW0058RegrasFormatacaoBase::insert_DTH_STTU_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DTH_STTU_TRAN( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_DTH_GMT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    dbm_datetime_t datetime_t;
    if ( tbsw0058_params.trandate > 0 )
    {
        datetime_t = AcqUtils::dateTime( tbsw0058_params.trandate, tbsw0058_params.trantime );
        tbsw0058.set_DTH_GMT( datetime_t );
    } 
    else 
    {
        datetime_t = AcqUtils::dateTimeGMT( tbsw0058_params.local_date, tbsw0058_params.local_time );
        tbsw0058.set_DTH_GMT( datetime_t );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_STAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NUM_STAN( atol( tbsw0058_params.trace.c_str( ) ) );
}

void TBSW0058RegrasFormatacaoBase::insert_VAL_EFTV_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_QTD_PRCL_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( tbsw0058_params.install_num  > 0 )
    {
        tbsw0058.set_QTD_PRCL_CNFR( tbsw0058_params.install_num );
    }
    else
    {
        tbsw0058.set_QTD_PRCL_CNFR( 0 );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_IND_RD_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_COD_CNDC_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_CNDC_CPTR( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_DAT_CNFR_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DAT_CNFR_PAUZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_VAL_TRAN_DLR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.acq_currency_code == 840 )
    {
        oasis_dec_t l_dec_amount;
        dbm_chartodec( &l_dec_amount, tbsw0058_params.amount.c_str( ), 0 );
        tbsw0058.set_VAL_TRAN_DLR( l_dec_amount );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_DAT_CAN_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DAT_CAN_PAUZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_DAT_VLD_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DAT_VLD_PAUZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_PORT_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_PORT_CAR( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_MSG_ISO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_MSG_ISO( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_PCM_ISO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_PCM_ISO( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::string nom_site_acqr = getenv( "NOM_SITE_ACQR" );
    if( !nom_site_acqr.empty( ) )
    {
        tbsw0058.set_NOM_SITE_ACQR_ORGL( nom_site_acqr );
    }
    else
    {
        tbsw0058.set_NOM_SITE_ACQR_ORGL( " " );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::string nom_host_acqr = getenv( "NOM_HOST_ACQR" );
    if( !nom_host_acqr.empty( ) )
    {
        tbsw0058.set_NOM_HOST_ACQR_ORGL( nom_host_acqr );
    }
    else
    {
        tbsw0058.set_NOM_HOST_ACQR_ORGL( " " );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::string nom_fe_acqr = getenv( "NOM_FE_ACQR" );
    if( !nom_fe_acqr.empty( ) )
    {
        tbsw0058.set_NOM_FE_ACQR_ORGL( nom_fe_acqr );
    }
    else
    {
        tbsw0058.set_NOM_FE_ACQR_ORGL( " " );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_SITE_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_HOST_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_FE_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_SITE_ACQR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_HOST_ACQR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_FE_ACQR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_MOT_ISO_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_COD_TERM_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_DAT_MOV_TRAN_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_DTH_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_IND_RD_ORG_ESTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{  
    WARNING_INVALID_FUNCTION;  
}

void TBSW0058RegrasFormatacaoBase::insert_IND_STTU_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.status.empty( ) )
        tbsw0058.set_IND_STTU_TRAN( " " );
    else
        tbsw0058.set_IND_STTU_TRAN( tbsw0058_params.status );
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( tbsw0058_params.acq_name.compare( "ADM" ) != 0 )
    {
        if ( tbsw0058_params.iss_name.compare( "MAESTRO" ) == 0 || tbsw0058_params.iss_name.compare( "HIPERCARD_DBT" ) == 0 ||
             tbsw0058_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 || tbsw0058_params.iss_name.compare( "MASTER_HIPER_DBT" ) == 0)
        {
            //tbsw0058.set_NUM_EMSR( tbsw0058_params.cd_ems );
            tbsw0058.set_NUM_EMSR( 18 );
        }
        else
        {
            if ( tbsw0058_params.bin > 10000 )
            {
                long l_bin = tbsw0058_params.bin / 10000;
                tbsw0058.set_NUM_EMSR( l_bin );
            }
        }
    }
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_ESTB_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_ESTB_ESTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_ID_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    oasis_dec_t l_dect;

    if( tbsw0058_params.iss_name.compare( "MASTERCARD" ) == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
        tbsw0058_params.iss_name.compare( "MASTERCARD" ) == 0 ||
        tbsw0058_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 )
    {
        //fica null
        return;
    }
    else if( tbsw0058_params.iss_name.compare( "HIPERCARD_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990001" ).c_str( ), 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "SOROCRED_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990002" ).c_str( ), 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "CABAL_CRT" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990003" ).c_str( ), 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "COOPERCRED_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990004" ).c_str( ), 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "UPI" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990006" ).c_str( ), 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "CREDSYSTEM_FULL" ) == 0 || tbsw0058_params.iss_name.compare( "CREDSYSTEM_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990010" ).c_str( ), 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "DINERS_INTERNAC" ) == 0 )
    {
        dbm_chartodec( &l_dect, "0", 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "DINERS_NACIONAL" ) == 0 )
    {
        dbm_chartodec( &l_dect, "0", 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "BANESCARD_CRT_FULL" ) == 0 || tbsw0058_params.iss_name.compare( "BANESCARD_CRT_VAN" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990011" ).c_str( ), 0 );
    }
    else if( tbsw0058_params.iss_name.compare( "CREDZ" ) == 0 )
    {
        dbm_chartodec( &l_dect, std::string( "99999990014" ).c_str( ), 0 );
    }
    else
    {
        if( tbsw0058_params.bin > 0  )
        {
            dbm_longtodec( &l_dect, tbsw0058_params.bin );
        }
        else
            return;
    }
    tbsw0058.set_NUM_ID_CAR( l_dect );
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_SEQ_UNC_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_STAN_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_COD_BNDR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.cod_bndr > 0 )
    {
        tbsw0058.set_COD_BNDR( tbsw0058_params.cod_bndr ); 
    }
}

void TBSW0058RegrasFormatacaoBase::insert_IND_EMSR_MTC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_IND_EMSR_MTC( std::string( "N" ) );

    if ( tbsw0058_params.iss_name.compare( "MASTERCARD" ) == 0 ||
         tbsw0058_params.iss_name.compare( "MAESTRO" ) == 0 ||
         tbsw0058_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 ||
         tbsw0058_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
         tbsw0058_params.iss_name.compare( "HIPERCARD_DBT" ) == 0 ||
         tbsw0058_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ||
         tbsw0058_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 ||
         tbsw0058_params.iss_name.compare( "MASTER_HIPER_DBT" ) == 0)
    {
        tbsw0058.set_IND_EMSR_MTC( std::string( "S" ) );
    }
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_AVSO_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
        tbsw0058.set_NUM_AVSO_AUT(" ");
}

void TBSW0058RegrasFormatacaoBase::insert_TXT_DA_ADIC_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_NOM_FNTS_PDV( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_FNTS_PDV( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_PGM_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_PGM_AUT( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_IND_NVL_SGRA_KMRC( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_UCAF( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_UCAF( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_AUT_EMSR_CNVT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_COD_AUT_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_NTWK_ID_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ACQR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NTWK_ID_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ACQR_ORGL( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NTWK_ID_ROUTE_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ROUTE_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NTWK_ID_ROUTE_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ROUTE_ORGL( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NTWK_ID_ISSR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ISSR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_NTWK_ID_ISSR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ISSR_ORGL( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_IND_CPTRDO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_IND_CPTRDO( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_CTAH_VOCH( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_COD_CTAH_VOCH( tbsw0058_params.cod_ctah_voch );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_TIP_PROD_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_COD_TIP_PROD_CAR( " " );
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_PDV_EXT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    tbsw0058.set_NUM_PDV_EXT( tbsw0058_params.cod_pv_externo );
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_PDV_VAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::insert_COD_GRU_CLAS_RAM( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.acq_name.compare( "VCH" ) != 0 && tbsw0058_params.isVan.compare( "TRUE" ) != 0 )
        tbsw0058.set_COD_GRU_CLAS_RAM( tbsw0058_params.cod_gru_clas_ram );
    else
        tbsw0058.set_COD_GRU_CLAS_RAM( 0 );
}

void TBSW0058RegrasFormatacaoBase::insert_NUM_REF_TRAN( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    tbsw0058.set_NUM_REF_TRAN( " " );
}

void TBSW0058RegrasFormatacaoBase::insert_COD_CPCD_TERM( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    tbsw0058.set_COD_CPCD_TERM( " " );
}

void TBSW0058RegrasFormatacaoBase::insert_IND_TRAN_TKN( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{

    if( tbsw0058_params.iss_name.compare( "MASTERCARD" )        == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_CRT" )     == 0 ||
        tbsw0058_params.iss_name.compare( "MASTER_HIPER_CRT" )  == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
        tbsw0058_params.iss_name.compare( "MAESTRO" )           == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_DBT" )     == 0 ||
        tbsw0058_params.iss_name.compare( "MASTER_HIPER_DBT" )  == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ||
        tbsw0058_params.iss_name.compare( "VISA_CREDITO" )      == 0 ||
        tbsw0058_params.iss_name.compare( "VISA_ELECTRON" )     == 0 )
	{
        tbsw0058.set_IND_TRAN_TKN( " " );   // Start with this
	}
    else
	{
        tbsw0058.set_IND_TRAN_TKN( "N" );  // Other issuers
	}

}

void TBSW0058RegrasFormatacaoBase::insert_COD_ORG_APRV( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    tbsw0058.SetCodOrgAprv( " " );
}

/// COD_PROD_MTC
void TBSW0058RegrasFormatacaoBase::InsertCodigoProdutoMastercard( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &params )
{
    WARNING_INVALID_FUNCTION;
}

/// COD_RGAO_MTC
void TBSW0058RegrasFormatacaoBase::InsertCodigoRegiaoMastercard( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &params )
{
    WARNING_INVALID_FUNCTION;
}

//###################################################################################################################################
//###################################################################################################################################
//###################################################################################################################################
//###################################################################################################################################

void TBSW0058RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_TIP_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_TIP_TRAN( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NUM_MOT_RSPS( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NUM_MOT_RSPS( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NUM_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_TERM( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NUM_RD_ORG( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_POS_ENTR_MODO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_VAL_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_RAM_ATVD( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NUM_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NUM_CAR( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NUM_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0058.set_NUM_AUT( tbsw0058_params.orig_authnum );
    }
    else if( tbsw0058_params.authnum.empty( ) == false )
    {
        std::string authnum("");
        authnum = AcqUtils::converteAuthnum( tbsw0058_params.authnum );
        if ( authnum.size( ) == 6 )
        {
            authnum.erase( 0, 1 ); //sao gravados apenas os 5 ultimos digitos do de 38 convertido...
            tbsw0058.set_NUM_AUT( authnum );
        }
        else
        {
            std::string str;
            str.clear();
            str.append("Erro na funcao AcqUtils::converteAuthnum, authnum com tamanho menor que 6...");
            m_log->write( logger::LEVEL_INFO, str.c_str() );
        }
    }
}

void TBSW0058RegrasFormatacaoBase::update_VAL_COT_DLR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{    // fixo null segundo BDCaptura

}

void TBSW0058RegrasFormatacaoBase::update_DAT_VLD_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_TRK_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_MOED( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_PAIS_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{    
    if( tbsw0058_params.iss_name.compare( "DINERS_NACIONAL" ) == 0 )
    {
        tbsw0058.set_COD_PAIS_CAR( "BRA" );
    }
    else
    {
        if( tbsw0058_params.mc_info_country.length( ) > 0 )
        {
            tbsw0058.set_COD_PAIS_CAR( tbsw0058_params.mc_info_country );
        }
        else
        {
            tbsw0058.set_COD_PAIS_CAR( " " );
            WARNING_EMPTY_STRING;            
        }
    }
}

void TBSW0058RegrasFormatacaoBase::update_COD_SERV_SNHA( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( tbsw0058_params.has_pin.compare( "TRUE" ) == 0 )
    {
        if( tbsw0058_params.iss_name.compare( "VISA_CREDITO" ) == 0 )
        {
            if( tbsw0058_params.addresponse.length( ) >= 2 )
            {
                tbsw0058.set_COD_SERV_SNHA( tbsw0058_params.addresponse.substr( 0, 2 ).c_str( ) );
            }
        }
    }
}

void TBSW0058RegrasFormatacaoBase::update_IND_RD_ORG( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_MOT_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //if( tbsw0058_params.cd_ems == 6 || tbsw0058_params.cd_ems == 8 ) //Diners
    if( tbsw0058_params.iss_name == "DINERS_INTERNAC" || 
        tbsw0058_params.iss_name == "DINERS_NACIONAL" )
    {
        if ( tbsw0058_params.az_reason_code.size( ) > 0 )
        {
            tbsw0058.set_COD_MOT_AUT( tbsw0058_params.az_reason_code.substr( 0, 3 ).c_str(  ) );
        }
        else        
        {
            tbsw0058.set_COD_MOT_AUT( " " );        
        }
    }
    else        
    {
        tbsw0058.set_COD_MOT_AUT( " " );        
    }
}

void TBSW0058RegrasFormatacaoBase::update_DAT_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DAT_PAUZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_COD_GRU_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_MTZ_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_DTH_INI_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_DTH_STTU_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DTH_STTU_TRAN( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_DTH_GMT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NUM_STAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_VAL_EFTV_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        oasis_dec_t l_dec_amount;
        dbm_chartodec( &l_dec_amount, tbsw0058_params.amount.c_str( ), 0 );
        tbsw0058.set_VAL_EFTV_CPTR( l_dec_amount );
    }
}

void TBSW0058RegrasFormatacaoBase::update_QTD_PRCL_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{    
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        if( tbsw0058_params.install_num  > 0 )
        {
            tbsw0058.set_QTD_PRCL_CNFR( tbsw0058_params.install_num );
        }
    }
}

void TBSW0058RegrasFormatacaoBase::update_IND_RD_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_CNDC_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_CNDC_CPTR( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_DAT_CNFR_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DAT_CNFR_PAUZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_VAL_TRAN_DLR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_DAT_CAN_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DAT_CAN_PAUZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_DAT_VLD_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_DAT_VLD_PAUZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NOM_PORT_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_PORT_CAR( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_COD_MSG_ISO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_MSG_ISO( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_COD_PCM_ISO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_PCM_ISO( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NOM_SITE_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{    
    if ( strlen( tbsw0058_params.nom_site_issr.c_str( ) ) )
    {
        tbsw0058.set_NOM_SITE_ISSR( tbsw0058_params.nom_site_issr );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NOM_HOST_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( strlen( tbsw0058_params.nom_host_issr.c_str( ) ) )
    {
        tbsw0058.set_NOM_HOST_ISSR( tbsw0058_params.nom_host_issr );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NOM_FE_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( strlen( tbsw0058_params.nom_fe_issr.c_str( ) ) )
    {
        tbsw0058.set_NOM_FE_ISSR( tbsw0058_params.nom_fe_issr );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_SITE_ACQR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_HOST_ACQR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_FE_ACQR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_COD_MOT_ISO_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::ostringstream str_ext_network_code;
    str_ext_network_code << tbsw0058_params.ext_network_code;
    int tam_ext_network_code = str_ext_network_code.str( ).size( );

    if ( tam_ext_network_code > 0 )
    {
        std::string aux =  std::string( 3 - tam_ext_network_code, '0') + str_ext_network_code.str( );
        tbsw0058.set_COD_MOT_ISO_EMSR( aux );
    }
}

void TBSW0058RegrasFormatacaoBase::update_COD_TERM_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0058.set_COD_TERM_CNFR( tbsw0058_params.termid );
    }
}

void TBSW0058RegrasFormatacaoBase::update_DAT_MOV_TRAN_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0058.set_DAT_MOV_TRAN_CNFR( tbsw0058_params.local_date );
    }
}

void TBSW0058RegrasFormatacaoBase::update_DTH_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0058.set_DTH_CNFR( AcqUtils::dateTime( tbsw0058_params.local_date, tbsw0058_params.local_time ) );
    }
}

void TBSW0058RegrasFormatacaoBase::update_IND_RD_ORG_ESTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //IND_RD_ORG_ESTR  1 -> AVR     2 -> PDV        3 -> POS
    
    if( tbsw0058_params.orig_status == "4" )//somente estorno de preaut
    {
        if ( tbsw0058_params.termid_type.compare( "AVR" ) == 0 || tbsw0058_params.termid_type.compare( "OL" ) == 0 )
        {
            tbsw0058.set_IND_RD_ORG_ESTR( "1" );
        }
        else if ( tbsw0058_params.termid_type.compare( "KMC" ) == 0 || tbsw0058_params.termid_type.compare( "MPG" ) == 0 )
        {
            tbsw0058.set_IND_RD_ORG_ESTR( "5" );
        }
        else if ( tbsw0058_params.termid_type.compare( "PDVDIAL" ) == 0 || tbsw0058_params.termid_type.compare( "HY8583" ) == 0 )
        {
            tbsw0058.set_IND_RD_ORG_ESTR( "3" );
        }
        else if ( tbsw0058_params.termid_type.compare( "ECR" ) == 0 )
        {
            tbsw0058.set_IND_RD_ORG_ESTR( "2" );
        }
        else
        {
            tbsw0058.set_IND_RD_ORG_ESTR( " " );
        }
    }
    else
    {
            tbsw0058.set_IND_RD_ORG_ESTR( " " );
    }
}

void TBSW0058RegrasFormatacaoBase::update_IND_STTU_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.status.size( ) > 0 )
    {
        tbsw0058.set_IND_STTU_TRAN( tbsw0058_params.status.substr( 0, 1 ).c_str( ) );
    }
    else
    {
        tbsw0058.set_IND_STTU_TRAN( " " );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0058RegrasFormatacaoBase::update_NUM_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NUM_ESTB_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0058.set_NUM_ESTB_CNFR( tbsw0058_params.termloc );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NUM_ESTB_ESTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( tbsw0058_params.orig_status == "4" )
    {
        tbsw0058.set_NUM_ESTB_ESTR( tbsw0058_params.termloc );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NUM_ID_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( ( tbsw0058_params.iss_name.compare( "MASTERCARD" ) == 0 ||
         tbsw0058_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 ||
         tbsw0058_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
         tbsw0058_params.iss_name.compare( "MASTERCARD" ) == 0 ||
         tbsw0058_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 )
		&& tbsw0058_params.mc_info_ica.size( ) > 0 )
    {
        oasis_dec_t l_dect;
        dbm_chartodec( &l_dect, tbsw0058_params.mc_info_ica.c_str( ), 0 );
        tbsw0058.set_NUM_ID_CAR( l_dect );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NUM_SEQ_UNC_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0058.set_NUM_SEQ_UNC_CNFR( atol ( tbsw0058_params.refnum.c_str( ) ) );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NUM_STAN_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( tbsw0058_params.msg_category.compare( "DESFAZIMENTO" ) == 0 || tbsw0058_params.msg_category.compare( "ESTORNO" ) == 0 )
    {
        tbsw0058.set_NUM_STAN_ORGL( atol ( tbsw0058_params.refnum.c_str( ) ) );
    }
}

void TBSW0058RegrasFormatacaoBase::update_COD_BNDR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_IND_EMSR_MTC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NUM_AVSO_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.status.compare( "1" ) == 0 && ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 ) )
    {
        tbsw0058.set_NUM_AVSO_AUT( "888888888888888" );   
    }
    else
    {
        tbsw0058.set_NUM_AVSO_AUT(" ");
    }
}

void TBSW0058RegrasFormatacaoBase::update_TXT_DA_ADIC_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::string l_string;

    if ( ( tbsw0058_params.iss_name.compare( "VISA_CREDITO" ) == 0 )    || ( tbsw0058_params.iss_name.compare( "VISA_ELECTRON" ) == 0 ) )
    {
        l_string =  tbsw0058_params.de_adc_ete;
    }
    else if ( ( tbsw0058_params.iss_name.compare( "MASTERCARD" ) == 0 )      || ( tbsw0058_params.iss_name.compare( "MASTER_HIPER_CRT" ) == 0 )  ||
              ( tbsw0058_params.iss_name.compare( "HIPERCARD_CRT" ) == 0 )   || ( tbsw0058_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ) ||
              ( tbsw0058_params.iss_name.compare( "CALCARD" ) == 0 )         || ( tbsw0058_params.iss_name.compare( "SOROCRED_FULL" ) == 0 )     ||
              ( tbsw0058_params.iss_name.compare( "CREDSYSTEM_FULL" ) == 0 ) || ( tbsw0058_params.iss_name.compare( "CABAL_CRT" ) == 0 )         ||
              ( tbsw0058_params.iss_name.compare( "CREDZ" ) == 0 )           || ( tbsw0058_params.iss_name.compare( "BANESCARD_CRT_FULL" ) == 0 ) ||
              ( tbsw0058_params.iss_name.compare( "BANESCARD_CRT_VAN" ) == 0 ) ||
              ( tbsw0058_params.iss_name.compare( "MAESTRO" ) == 0 )         || ( tbsw0058_params.iss_name.compare( "MASTER_HIPER_DBT" ) == 0 )  ||
              ( tbsw0058_params.iss_name.compare( "HIPERCARD_DBT" ) == 0 )   || ( tbsw0058_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ) ||
              ( tbsw0058_params.iss_name.compare( "CABAL_DBT" ) == 0 )       || ( tbsw0058_params.iss_name.compare( "BANESCARD_DBT_FULL" ) == 0 ) ||
              ( tbsw0058_params.iss_name.compare( "BANESCARD_DBT_VAN" ) == 0 ) )
    {
        if ( tbsw0058_params.de_adc_ete.length( ) > 0 )
            l_string =  tbsw0058_params.de_adc_ete;
        else
            l_string =  " ";
    }
    else if ( ( tbsw0058_params.iss_name.compare( "ELO_CRT" ) == 0 ) || ( tbsw0058_params.iss_name.compare( "ELO_DBT" ) == 0 ) ||
                ( tbsw0058_params.iss_name.compare( "ALELO" ) == 0 ) )
    {
        l_string =  tbsw0058_params.numero_cv_ad;
    }
    else if ( ( tbsw0058_params.iss_name.compare( "AMEX" ) == 0 )            || ( tbsw0058_params.iss_name.compare( "AMEX_FULL" ) == 0 )       ||
              ( tbsw0058_params.iss_name.compare( "ELO_CRT_FULL" ) == 0 )    || ( tbsw0058_params.iss_name.compare( "ELO_DBT_FULL" ) == 0 )    ||
              ( tbsw0058_params.iss_name.compare( "DINERS_NACIONAL" ) == 0 ) || ( tbsw0058_params.iss_name.compare( "DINERS_INTERNAC" ) == 0 ) ||
              ( tbsw0058_params.iss_name.compare( "JCB_CRT" ) == 0 )         ||
              ( tbsw0058_params.iss_name.compare( "HIPERCARD_VAN" ) == 0 )   || ( tbsw0058_params.iss_name.compare( "CREDSYSTEM_VAN" ) == 0 )  ||
              ( tbsw0058_params.iss_name.compare( "COOPERCRED_VAN" ) == 0 )  || ( tbsw0058_params.iss_name.compare( "SOROCRED_VAN" ) == 0 )    ||
              ( tbsw0058_params.iss_name.compare( "PL_FININVEST" ) == 0 )    || ( tbsw0058_params.iss_name.compare( "PL_BRADESCO" ) == 0 )     ||
              ( tbsw0058_params.iss_name.compare( "PL_BANCOBRASIL" ) == 0 )  || ( tbsw0058_params.iss_name.compare( "PL_CREDSYSTEM" ) == 0 )   ||
              ( tbsw0058_params.iss_name.compare( "PL_PORTOSEGURO" ) == 0 )  ||
              ( tbsw0058_params.iss_name.compare( "BNB_CLUBE" ) == 0 )       || ( tbsw0058_params.iss_name.compare( "PLANVALE" ) == 0 )        ||
              ( tbsw0058_params.iss_name.compare( "GREEN_CARD" ) == 0 )      || ( tbsw0058_params.iss_name.compare( "TOP_PREMIUM" ) == 0 )     ||
              ( tbsw0058_params.iss_name.compare( "SODEXO" ) == 0 )          || ( tbsw0058_params.iss_name.compare( "SMARTNET" ) == 0 )        ||
              ( tbsw0058_params.iss_name.compare( "NUTRICASH" ) == 0 )       || ( tbsw0058_params.iss_name.compare( "CABAL" ) == 0 )           ||
              ( tbsw0058_params.iss_name.compare( "VEROCHEQUE" ) == 0 )      || ( tbsw0058_params.iss_name.compare( "VCH_SOROCRED" ) == 0 )    ||
              ( tbsw0058_params.iss_name.compare( "COOPER_CRED" ) == 0 )     || ( tbsw0058_params.iss_name.compare( "TICKET" ) == 0 )          ||
              ( tbsw0058_params.iss_name.compare( "TICKET_CHIP" ) == 0 )     || ( tbsw0058_params.iss_name.compare( "VCH_VR" ) == 0 ) )
    {
        l_string =  " ";
    }
    else if ( tbsw0058_params.iss_name.compare( "UPI" ) == 0 )
    {
        l_string =  tbsw0058_params.txt_adic_pos;
    }
    else  // others, if any
    {
        l_string =  tbsw0058_params.de_adc_ete;
    }

    if ( atoi( tbsw0058_params.az_reason_code.c_str( ) ) == 0 && strlen( l_string.c_str() ) > 0 &&
         tbsw0058_params.sender_mbname.compare( "SharedCash" ) == 0 )  // Assume the request had been sent to the issuer and
    {                                                                  // the response is coming from SHC. Otherwise, NULL.
        tbsw0058.set_TXT_DA_ADIC_EMSR( l_string );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NOM_FNTS_PDV( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NOM_FNTS_PDV( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_COD_PGM_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_PGM_AUT( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_IND_NVL_SGRA_KMRC( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_COD_UCAF( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_COD_UCAF( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_COD_AUT_EMSR_CNVT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    std::string l_string = tbsw0058_params.authnum;
    
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || 
         tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        std::string l_string = tbsw0058_params.orig_authnum;
        l_string = AcqUtils::converteAuthnum( l_string );
        tbsw0058.set_COD_AUT_EMSR_CNVT( l_string );
    }
    else if(l_string.size() > 0)
    {
        l_string = AcqUtils::converteAuthnum( l_string );
        tbsw0058.set_COD_AUT_EMSR_CNVT( l_string );
    }
}

void TBSW0058RegrasFormatacaoBase::update_COD_AUT_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if ( tbsw0058_params.msg_name.compare( "CONF_PREAUT" ) == 0 || 
         tbsw0058_params.msg_name.compare( "CONF_PREAUT_PARC_SJURO" ) == 0 )
    {
        tbsw0058.set_COD_AUT_EMSR( tbsw0058_params.orig_authnum );
    }
    else if( tbsw0058_params.authnum.size( ) > 0 )
    {
        tbsw0058.set_COD_AUT_EMSR( tbsw0058_params.authnum );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NTWK_ID_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{    
	if( tbsw0058_params.msg_name.compare("ADV_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_NEG") != 0 &&
		tbsw0058_params.msg_name.compare("ADV_CONF_PREAUT_PARC_NEG") != 0 )
	{	
		tbsw0058.set_NTWK_ID_ACQR_ATLZ( std::string( getenv( "NETWORKID" ) ) );
	}
}

void TBSW0058RegrasFormatacaoBase::update_NTWK_ID_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ACQR_ORGL( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NTWK_ID_ROUTE_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ROUTE_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NTWK_ID_ROUTE_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ROUTE_ORGL( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NTWK_ID_ISSR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ISSR_ATLZ( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_NTWK_ID_ISSR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_NTWK_ID_ISSR_ORGL( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_IND_CPTRDO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    gen_IND_CPTRDO( tbsw0058, tbsw0058_params );
}

void TBSW0058RegrasFormatacaoBase::update_COD_CTAH_VOCH( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_TIP_PROD_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    if( tbsw0058_params.iss_name.compare( "MASTERCARD" ) == 0 && tbsw0058_params.mc_info_prod_code.empty( ) == false ) 
    {
        tbsw0058.set_COD_TIP_PROD_CAR( tbsw0058_params.mc_info_prod_code );
    }
}

void TBSW0058RegrasFormatacaoBase::update_NUM_PDV_EXT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NUM_PDV_VAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_COD_GRU_CLAS_RAM( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params )
{
    //CAMPO SOMENTE PARA INSERT
    WARNING_INVALID_FUNCTION;
}

void TBSW0058RegrasFormatacaoBase::update_NUM_REF_TRAN( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    if( tbsw0058_params.num_ref_tran.empty( ) == false )
    {
        tbsw0058.set_NUM_REF_TRAN( tbsw0058_params.num_ref_tran );
    }
    else
    {
        tbsw0058.set_NUM_REF_TRAN( " " );
    }
}

void TBSW0058RegrasFormatacaoBase::update_COD_CPCD_TERM( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    if( tbsw0058_params.cod_cpcd_term.empty( ) == false )
    {
        tbsw0058.set_COD_CPCD_TERM( tbsw0058_params.cod_cpcd_term );
    }
    else
    {
        tbsw0058.set_COD_CPCD_TERM( " " );
    }
}

void TBSW0058RegrasFormatacaoBase::update_IND_TRAN_TKN( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    if( tbsw0058_params.iss_name.compare( "MASTERCARD" )        == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_CRT" )     == 0 ||
        tbsw0058_params.iss_name.compare( "MASTER_HIPER_CRT" )  == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_CRT_HMV" ) == 0 ||
        tbsw0058_params.iss_name.compare( "MAESTRO" )           == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_DBT" )     == 0 ||
        tbsw0058_params.iss_name.compare( "MASTER_HIPER_DBT" )  == 0 ||
        tbsw0058_params.iss_name.compare( "HIPERCARD_DBT_HMV" ) == 0 ||
        tbsw0058_params.iss_name.compare( "VISA_CREDITO" )      == 0 ||
        tbsw0058_params.iss_name.compare( "VISA_ELECTRON" )     == 0
      )
    {
        if( tbsw0058_params.quem_negou.empty( ) == true && tbsw0058_params.tokenIdentifier.empty( ) == false )
        {
            tbsw0058.set_IND_TRAN_TKN( tbsw0058_params.tokenIdentifier );
        }
        else
        if( tbsw0058_params.quem_negou.compare( "ACQ" ) == 0       ||
           (tbsw0058_params.quem_negou.compare( "SWCORE" ) == 0 &&
            tbsw0058_params.tokenIdentifier.empty( ) == true )
          )
        {
            tbsw0058.set_IND_TRAN_TKN( " " );
        }
        else
        if( ( tbsw0058_params.quem_negou.compare( "ISS" )        == 0 ||
              tbsw0058_params.quem_negou.compare( "SWCALLBACK" ) == 0 ||
              tbsw0058_params.quem_negou.compare( "SWCORE" )     == 0 ) &&
            tbsw0058_params.tokenIdentifier.empty( ) == false )
        {
            tbsw0058.set_IND_TRAN_TKN( tbsw0058_params.tokenIdentifier );
        }
    }
}

void TBSW0058RegrasFormatacaoBase::update_COD_ORG_APRV( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params )
{
    if( tbsw0058_params.codigoOrigemRespostaAutorizacao.empty( ) == false )
    {
        tbsw0058.SetCodOrgAprv( tbsw0058_params.codigoOrigemRespostaAutorizacao );
    }
}

/// COD_PROD_MTC
void TBSW0058RegrasFormatacaoBase::UpdateCodigoProdutoMastercard( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &params )
{
    if( params.iss_name == "MASTERCARD" || params.iss_name == "HIPERCARD_CRT" || params.iss_name == "HIPERCARD_CRT_HMV" || params.iss_name == "MASTER_HIPER_CRT" )
    {
        if( params.codigoProdutoMastercard.size( ) != 0 )
        {
            tbsw0058.SetCodigoProdutoMastercard( params.codigoProdutoMastercard );
        }
    }
}

/// COD_RGAO_MTC
void TBSW0058RegrasFormatacaoBase::UpdateCodigoRegiaoMastercard( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &params )
{
    if( params.iss_name == "MASTERCARD" || params.iss_name == "HIPERCARD_CRT"  || params.iss_name == "HIPERCARD_CRT_HMV" || params.iss_name == "MASTER_HIPER_CRT" )
    {
        if( params.codigoRegiaoMastercard.size( ) != 0 )
        {
            tbsw0058.SetCodigoRegiaoMastercard( params.codigoRegiaoMastercard );
        }
    }
}


//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################

void TBSW0058RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::TIP_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_TRAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_TRAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_MOT_RSPS( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_MOT_RSPS( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_MOT_RSPS( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ESTB( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ESTB( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_TERM( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TERM( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TERM( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_RD_ORG( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_RD_ORG( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_RD_ORG( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_POS_ENTR_MODO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_POS_ENTR_MODO( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_POS_ENTR_MODO( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_EMSR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_EMSR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::VAL_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TRAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TRAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_RAM_ATVD( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_RAM_ATVD( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_RAM_ATVD( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_CAR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_CAR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_AUT( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_AUT( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::VAL_COT_DLR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_COT_DLR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_COT_DLR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DAT_VLD_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_VLD_CAR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_VLD_CAR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_TRK_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TRK_CAR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TRK_CAR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_MOED( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MOED( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MOED( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_PAIS_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PAIS_CAR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PAIS_CAR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_SERV_SNHA( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_SERV_SNHA( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_SERV_SNHA( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::IND_RD_ORG( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_RD_ORG( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_RD_ORG( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_MOT_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MOT_AUT( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MOT_AUT( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DAT_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_PAUZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_PAUZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_GRU_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_GRU_ESTB( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_GRU_ESTB( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_MTZ_ESTB( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MTZ_ESTB( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MTZ_ESTB( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DTH_INI_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_INI_TRAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_INI_TRAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DTH_STTU_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_STTU_TRAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_STTU_TRAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DTH_GMT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_GMT( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_GMT( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_STAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_STAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_STAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::VAL_EFTV_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_EFTV_CPTR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_EFTV_CPTR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::QTD_PRCL_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_QTD_PRCL_CNFR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_QTD_PRCL_CNFR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::IND_RD_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_RD_CPTR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_RD_CPTR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_CNDC_CPTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CNDC_CPTR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CNDC_CPTR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DAT_CNFR_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_CNFR_PAUZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_CNFR_PAUZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::VAL_TRAN_DLR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TRAN_DLR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TRAN_DLR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DAT_CAN_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_CAN_PAUZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_CAN_PAUZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DAT_VLD_PAUZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_VLD_PAUZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_VLD_PAUZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_PORT_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_PORT_CAR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_PORT_CAR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_MSG_ISO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MSG_ISO( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MSG_ISO( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_PCM_ISO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PCM_ISO( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PCM_ISO( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ACQR_ORGL( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ACQR_ORGL( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ACQR_ORGL( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ACQR_ORGL( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ACQR_ORGL( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ACQR_ORGL( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_SITE_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ISSR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ISSR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_HOST_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ISSR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ISSR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_FE_ISSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ISSR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ISSR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_SITE_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ACQR_ATLZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ACQR_ATLZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_HOST_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ACQR_ATLZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ACQR_ATLZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_FE_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ACQR_ATLZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ACQR_ATLZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_MOT_ISO_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_MOT_ISO_EMSR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_MOT_ISO_EMSR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_TERM_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TERM_CNFR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TERM_CNFR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DAT_MOV_TRAN_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN_CNFR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN_CNFR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::DTH_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_CNFR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_CNFR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::IND_RD_ORG_ESTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_RD_ORG_ESTR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_RD_ORG_ESTR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::IND_STTU_TRAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_STTU_TRAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_STTU_TRAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_EMSR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_EMSR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_ESTB_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ESTB_CNFR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ESTB_CNFR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_ESTB_ESTR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ESTB_ESTR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ESTB_ESTR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_ID_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ID_CAR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ID_CAR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_SEQ_UNC_CNFR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC_CNFR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC_CNFR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_STAN_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_STAN_ORGL( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_STAN_ORGL( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_BNDR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_BNDR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_BNDR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::IND_EMSR_MTC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_EMSR_MTC( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_EMSR_MTC( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_AVSO_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_AVSO_AUT( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_AVSO_AUT( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::TXT_DA_ADIC_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_DA_ADIC_EMSR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_DA_ADIC_EMSR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NOM_FNTS_PDV( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FNTS_PDV( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FNTS_PDV( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_PGM_AUT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PGM_AUT( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_PGM_AUT( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_NVL_SGRA_KMRC( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_NVL_SGRA_KMRC( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_UCAF( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_UCAF( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_UCAF( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_AUT_EMSR_CNVT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_AUT_EMSR_CNVT( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_AUT_EMSR_CNVT( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_AUT_EMSR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_AUT_EMSR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_AUT_EMSR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NTWK_ID_ACQR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NTWK_ID_ACQR_ATLZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NTWK_ID_ACQR_ATLZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NTWK_ID_ACQR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NTWK_ID_ACQR_ORGL( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NTWK_ID_ACQR_ORGL( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NTWK_ID_ROUTE_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NTWK_ID_ROUTE_ATLZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NTWK_ID_ROUTE_ATLZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NTWK_ID_ROUTE_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NTWK_ID_ROUTE_ORGL( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NTWK_ID_ROUTE_ORGL( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NTWK_ID_ISSR_ATLZ( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NTWK_ID_ISSR_ATLZ( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NTWK_ID_ISSR_ATLZ( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NTWK_ID_ISSR_ORGL( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NTWK_ID_ISSR_ORGL( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NTWK_ID_ISSR_ORGL( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::IND_CPTRDO( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_CPTRDO( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_CPTRDO( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_CTAH_VOCH( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CTAH_VOCH( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CTAH_VOCH( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_TIP_PROD_CAR( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TIP_PROD_CAR( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TIP_PROD_CAR( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_PDV_EXT( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_PDV_EXT( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_PDV_EXT( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_PDV_VAN( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_PDV_VAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_PDV_VAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_GRU_CLAS_RAM( dbaccess_common::TBSW0058& tbsw0058, const struct acq_common::tbsw0058_params& tbsw0058_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_GRU_CLAS_RAM( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_GRU_CLAS_RAM( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::NUM_REF_TRAN( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_REF_TRAN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_REF_TRAN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_CPCD_TERM( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_CPCD_TERM( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_CPCD_TERM( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::IND_TRAN_TKN( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_TRAN_TKN( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_TRAN_TKN( tbsw0058, tbsw0058_params );
    }
}

void TBSW0058RegrasFormatacaoBase::COD_ORG_APRV( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &tbsw0058_params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_ORG_APRV( tbsw0058, tbsw0058_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_ORG_APRV( tbsw0058, tbsw0058_params );
    }
}

/// COD_PROD_MTC
void TBSW0058RegrasFormatacaoBase::CodigoProdutoMastercard( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertCodigoProdutoMastercard( tbsw0058, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateCodigoProdutoMastercard( tbsw0058, params );
    }
}

/// COD_RGAO_MTC
void TBSW0058RegrasFormatacaoBase::CodigoRegiaoMastercard( dbaccess_common::TBSW0058 &tbsw0058, const struct acq_common::tbsw0058_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertCodigoRegiaoMastercard( tbsw0058, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateCodigoRegiaoMastercard( tbsw0058, params );
    }
}


// J4_2019 - Release Bandeiras Abril 2019 - INICIO
/// IndicadorPresencaPortador
/// Grava o indicador de presenca do portador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0058RegrasFormatacaoBase::IndicadorPresencaPortador( dbaccess_common::TBSW0058 &dadosTabela, const struct acq_common::tbsw0058_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertIndicadorPresencaPortador( dadosTabela, dadosParams );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateIndicadorPresencaPortador( dadosTabela, dadosParams );
    }
}

/// InsertIndicadorPresencaPortador
/// Insere o indicador de presenca do portador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0058RegrasFormatacaoBase::InsertIndicadorPresencaPortador( dbaccess_common::TBSW0058 &dadosTabela, const struct acq_common::tbsw0058_params &dadosParams )
{
    if ( dadosParams.indicadorPresencaPortador.empty( ) == false )
    {
        dadosTabela.SetIndicadorPresencaPortador( dadosParams.indicadorPresencaPortador );
    }
    else
    {
        dadosTabela.SetIndicadorPresencaPortador( " " );
    }
}

/// UpdateIndicadorPresencaPortador
/// Atualiza o indicador de presenca do portador
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0058RegrasFormatacaoBase::UpdateIndicadorPresencaPortador( dbaccess_common::TBSW0058 &dadosTabela, const struct acq_common::tbsw0058_params &dadosParams )
{
    if( dadosParams.indicadorPresencaPortador.empty( ) == false 
        && dadosParams.msg_category.compare( "ESTORNO" ) != 0 
        &&  dadosParams.msg_category.compare( "DESFAZIMENTO" ) != 0 )
    {
        dadosTabela.SetIndicadorPresencaPortador( dadosParams.indicadorPresencaPortador );
    }
}

/// IndicadorTecnologiaTerminal
/// Grava o indicador de tecnologia do terminal
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
/// operacao: tipo da operacao
void TBSW0058RegrasFormatacaoBase::IndicadorTecnologiaTerminal( dbaccess_common::TBSW0058 &dadosTabela, const struct acq_common::tbsw0058_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        InsertIndicadorTecnologiaTerminal( dadosTabela, dadosParams );
    }
    else if( operacao == acq_common::UPDATE )
    {
        UpdateIndicadorTecnologiaTerminal( dadosTabela, dadosParams );
    }
}

/// InsertIndicadorTecnologiaTerminal
/// Insere o indicador de tecnologia do terminal
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0058RegrasFormatacaoBase::InsertIndicadorTecnologiaTerminal( dbaccess_common::TBSW0058 &dadosTabela, const struct acq_common::tbsw0058_params &dadosParams )
{
    if ( dadosParams.indicadorTecnologiaTerminal.empty( ) == false )
    {
        dadosTabela.SetIndicadorTecnologiaTerminal( dadosParams.indicadorTecnologiaTerminal );
    }
    else
    {
        dadosTabela.SetIndicadorTecnologiaTerminal( " " );
    }
}

/// UpdateIndicadorTecnologiaTerminal
/// Atualiza o indicador de tecnologia do terminal
/// EF/ET : ET1
/// Historico: [Data] - ET - Descricao
/// 12/03/2019 - ET1 - Criacao da versao inicial
/// dadosTabela: instancia da tabela
/// dadosParams: instancia da transacao
void TBSW0058RegrasFormatacaoBase::UpdateIndicadorTecnologiaTerminal( dbaccess_common::TBSW0058 &dadosTabela, const struct acq_common::tbsw0058_params &dadosParams )
{
    if( dadosParams.indicadorTecnologiaTerminal.empty( ) == false 
        && dadosParams.msg_category.compare( "ESTORNO" ) != 0 
        &&  dadosParams.msg_category.compare( "DESFAZIMENTO" ) != 0 )
    {
        dadosTabela.SetIndicadorTecnologiaTerminal( dadosParams.indicadorTecnologiaTerminal );
    }
}
// J4_2019 - Release Bandeiras Abril 2019 - FIM

void TBSW0058RegrasFormatacaoBase::CodigoProcessoEmissor( dbaccess_common::TBSW0058 &dadosTabela, const struct acq_common::tbsw0058_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::UPDATE )
    {
        dadosTabela.SetCodigoProcessoEmissor( dadosParams.codigoProcessoEmissor );
    }
}

void TBSW0058RegrasFormatacaoBase::IdentificadorReferenciaBandeira( dbaccess_common::TBSW0058 &dadosTabela, const struct acq_common::tbsw0058_params &dadosParams, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::UPDATE )
    {
        dadosTabela.SetIdentificadorReferenciaBandeira( dadosParams.identificadorReferenciaBandeira );
    }
}
