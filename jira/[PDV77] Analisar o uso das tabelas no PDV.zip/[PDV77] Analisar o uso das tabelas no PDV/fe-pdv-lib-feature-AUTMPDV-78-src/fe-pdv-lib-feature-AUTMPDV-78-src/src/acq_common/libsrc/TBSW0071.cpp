/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "TBSW0071.hpp"

namespace dbaccess_common
{
	TBSW0071::TBSW0071( )
	{
		query_fields = "NUM_PDV, COD_STTU_REG, DAT_ATLZ_REG, COD_SERV, NUM_PDV_BCO_ARCD, \
		TIP_MDLD_PGMN, COD_BLTO_BCO_ARCD, VAL_MN_VD, VAL_MX_SQUE";
		table_name = "TBSW0071";
		where_condition = "";
		m_NUM_PDV_pos = 1;
		m_COD_STTU_REG_pos = 2;
		m_DAT_ATLZ_REG_pos = 3;
		m_COD_SERV_pos = 4;
		m_NUM_PDV_BCO_ARCD_pos = 5;
		m_TIP_MDLD_PGMN_pos = 6;
		m_COD_BLTO_BCO_ARCD_pos = 7;
		m_VAL_MN_VD_pos = 8;
		m_VAL_MX_SQUE_pos = 9;
		m_NUM_PDV = 0;
		m_COD_STTU_REG = "";
		m_DAT_ATLZ_REG = 0;
		m_COD_SERV = 0;
		m_NUM_PDV_BCO_ARCD = 0;
		m_TIP_MDLD_PGMN = "";
		m_COD_BLTO_BCO_ARCD = "";
		dbm_inttodec( &m_VAL_MN_VD, 0 );
		dbm_inttodec( &m_VAL_MX_SQUE, 0 );

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0071::TBSW0071( const std::string& str )
	{
		query_fields = "NUM_PDV, COD_STTU_REG, DAT_ATLZ_REG, COD_SERV, NUM_PDV_BCO_ARCD, \
		TIP_MDLD_PGMN, COD_BLTO_BCO_ARCD, VAL_MN_VD, VAL_MX_SQUE";
		table_name = "TBSW0071";
		where_condition = str;
		m_NUM_PDV_pos = 1;
		m_COD_STTU_REG_pos = 2;
		m_DAT_ATLZ_REG_pos = 3;
		m_COD_SERV_pos = 4;
		m_NUM_PDV_BCO_ARCD_pos = 5;
		m_TIP_MDLD_PGMN_pos = 6;
		m_COD_BLTO_BCO_ARCD_pos = 7;
		m_VAL_MN_VD_pos = 8;
		m_VAL_MX_SQUE_pos = 9;
		m_NUM_PDV = 0;
		m_COD_STTU_REG = "";
		m_DAT_ATLZ_REG = 0;
		m_COD_SERV = 0;
		m_NUM_PDV_BCO_ARCD = 0;
		m_TIP_MDLD_PGMN = "";
		m_COD_BLTO_BCO_ARCD = "";
		dbm_inttodec( &m_VAL_MN_VD, 0 );
		dbm_inttodec( &m_VAL_MX_SQUE, 0 );

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0071::~TBSW0071( )
	{
	}
	long TBSW0071::getNUM_PDV( ) const
	{
		return m_NUM_PDV;
	}
	const std::string& TBSW0071::getCOD_STTU_REG( ) const
	{
		return m_COD_STTU_REG;
	}
	dbm_datetime_t TBSW0071::getDAT_ATLZ_REG( ) const
	{
		return m_DAT_ATLZ_REG;
	}
	long TBSW0071::getCOD_SERV( ) const
	{
		return m_COD_SERV;
	}
	long TBSW0071::getNUM_PDV_BCO_ARCD( ) const
	{
		return m_NUM_PDV_BCO_ARCD;
	}
	const std::string& TBSW0071::getTIP_MDLD_PGMN( ) const
	{
		return m_TIP_MDLD_PGMN;
	}
	const std::string& TBSW0071::getCOD_BLTO_BCO_ARCD( ) const
	{
		return m_COD_BLTO_BCO_ARCD;
	}
	oasis_dec_t TBSW0071::getVAL_MN_VD( ) const
	{
		return m_VAL_MN_VD;
	}
	oasis_dec_t TBSW0071::getVAL_MX_SQUE( ) const
	{
		return m_VAL_MX_SQUE;
	}
	void TBSW0071::bind_columns( )
	{
		bind( m_NUM_PDV_pos, m_NUM_PDV );
		bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
		bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
		bind( m_COD_SERV_pos, m_COD_SERV );
		bind( m_NUM_PDV_BCO_ARCD_pos, m_NUM_PDV_BCO_ARCD );
		bind( m_TIP_MDLD_PGMN_pos, m_TIP_MDLD_PGMN );
		bind( m_COD_BLTO_BCO_ARCD_pos, m_COD_BLTO_BCO_ARCD );
		bind( m_VAL_MN_VD_pos, m_VAL_MN_VD );
		bind( m_VAL_MX_SQUE_pos, m_VAL_MX_SQUE );
	}
}//namespace dbaccess_common

