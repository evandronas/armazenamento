#include <cstring>
#include<TBSW0033RegrasFormatacaoBase.hpp>
#include<AcqUtils.hpp>

/*
Copyright 2018 Rede S.A.
********************** MODIFICACOES ************************
Autor    : Daniel Nava
Data     : 16/12/2019
Empresa  : REDE
Descricao: EAK-1899 - Correcao da validacao da data do resumo vazia
ID       : AM 248.141
************************************************************
*/

TBSW0033RegrasFormatacaoBase::TBSW0033RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0033RegrasFormatacaoBase::~TBSW0033RegrasFormatacaoBase( )
{
}

void TBSW0033RegrasFormatacaoBase::NUM_BCO_DEB( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_BCO_DEB( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_BCO_DEB( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::NUM_CGC_CPF( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_CGC_CPF( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_CGC_CPF( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::NUM_CHQ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_CHQ( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_CHQ( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::TXT_MSG_1( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_MSG_1( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_MSG_1( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::TXT_MSG_2( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_MSG_2( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_MSG_2( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::NUM_RSMO_VD( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_RSMO_VD( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_RSMO_VD( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::DAT_RSMO_VD( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_RSMO_VD( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_RSMO_VD( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::NUM_TEL( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_TEL( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_TEL( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::TIP_DOC( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TIP_DOC( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TIP_DOC( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::DTH_CON_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_CON_TRAN( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_CON_TRAN( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0033, tbsw0033_params );
    }
}

void TBSW0033RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0033, tbsw0033_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0033, tbsw0033_params );
    }
}

//#########################################################################
//#########################################################################

void TBSW0033RegrasFormatacaoBase::insert_NUM_BCO_DEB( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    tbsw0033.set_NUM_BCO_DEB( 999 );
}

void TBSW0033RegrasFormatacaoBase::insert_NUM_CGC_CPF( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    if ( tbsw0033_params.cpf_cnpj.size() > 1 )
    {
        oasis_dec_t l_dect;
        dbm_chartodec( &l_dect, tbsw0033_params.cpf_cnpj.substr( 2, ( strlen( tbsw0033_params.cpf_cnpj.c_str( ) ) - 2 ) ).c_str( ), 0 );
        tbsw0033.set_NUM_CGC_CPF( l_dect );
    }
}

void TBSW0033RegrasFormatacaoBase::insert_NUM_CHQ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    if ( tbsw0033_params.msg_name.compare("CONS_SERASA") == 0 )
    {
        tbsw0033.set_NUM_CHQ( tbsw0033_params.num_cheque );
    }
}

void TBSW0033RegrasFormatacaoBase::insert_TXT_MSG_1( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    gen_TXT_MSG_1( tbsw0033, tbsw0033_params );
}

void TBSW0033RegrasFormatacaoBase::insert_TXT_MSG_2( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    gen_TXT_MSG_2( tbsw0033, tbsw0033_params );
}

void TBSW0033RegrasFormatacaoBase::insert_NUM_RSMO_VD( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::insert_DAT_RSMO_VD( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::insert_NUM_TEL( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, 0 );
    tbsw0033.set_NUM_TEL( l_dect );
}

void TBSW0033RegrasFormatacaoBase::insert_TIP_DOC( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    if ( tbsw0033_params.msg_name.compare("CONS_SERASA") == 0 )
    {
        if ( tbsw0033_params.cpf_cnpj.size( ) > 1 )
        {    
            if ( tbsw0033_params.cpf_cnpj.substr( 1, 1 ) == "1" )
            {
                tbsw0033.set_TIP_DOC( "2" );
            }
            if ( tbsw0033_params.cpf_cnpj.substr( 1, 1 ) == "2"  )
            {
                tbsw0033.set_TIP_DOC( "1" );
            }
        }
    }
}

void TBSW0033RegrasFormatacaoBase::insert_DTH_CON_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{ 
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    tbsw0033.set_DAT_MOV_TRAN( tbsw0033_params.local_date );
}

void TBSW0033RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    oasis_dec_t aux;
    dbm_chartodec( &aux, tbsw0033_params.refnum.c_str( ), 0 );
    tbsw0033.set_NUM_SEQ_UNC( aux );
}


//#########################################################################
//#########################################################################

void TBSW0033RegrasFormatacaoBase::update_NUM_BCO_DEB( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::update_NUM_CGC_CPF( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::update_NUM_CHQ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::update_TXT_MSG_1( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    gen_TXT_MSG_1( tbsw0033, tbsw0033_params );
}

void TBSW0033RegrasFormatacaoBase::update_TXT_MSG_2( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    gen_TXT_MSG_2( tbsw0033, tbsw0033_params );
}

void TBSW0033RegrasFormatacaoBase::update_NUM_RSMO_VD( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    if ( tbsw0033_params.msg_name.compare("RES_VEND") == 0 )
    {
        oasis_dec_t l_dect;
        if ( !tbsw0033_params.nu_rv.empty( ) ) 
        {
            dbm_chartodec( &l_dect, tbsw0033_params.nu_rv.c_str( ), 0 );
            tbsw0033.set_NUM_RSMO_VD( l_dect );
        }
        else
        {
            dbm_longtodec( &l_dect, 0 );
            tbsw0033.set_NUM_RSMO_VD( l_dect );
        }
    }
}

/// update_DAT_RSMO_VD
/// Prepara DAT_RSMO_VD para update
/// EF/ET: EAK-1899
/// Histórico: [Data] - ET - Descrição
/// 16/12/2019 - EAK1899 - Correcao da validacao da data de resumo vazia
/// [Data] - ET - Descrição
/// tbsw0033: Dados da tabela tbsw0033
/// tbsw0033_params: Parametros recebidos da tbsw0033
void TBSW0033RegrasFormatacaoBase::update_DAT_RSMO_VD( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    if ( tbsw0033_params.msg_name.compare("RES_VEND") == 0 )
    {
        if ( tbsw0033_params.dt_rv.empty( ) ) 
        {
            tbsw0033.set_DAT_RSMO_VD( AcqUtils::dateTime( tbsw0033_params.local_date, tbsw0033_params.local_time ) );
        }
        else
        {
            tbsw0033.set_DAT_RSMO_VD( atol ( tbsw0033_params.dt_rv.c_str( ) ) );        
        }
    }
}

void TBSW0033RegrasFormatacaoBase::update_NUM_TEL( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::update_TIP_DOC( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::update_DTH_CON_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}


//#########################################################################
//#########################################################################

void TBSW0033RegrasFormatacaoBase::gen_NUM_BCO_DEB( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_NUM_CGC_CPF( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_NUM_CHQ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_TXT_MSG_1( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{    
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_TXT_MSG_2( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_NUM_RSMO_VD( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{ 
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_DAT_RSMO_VD( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_NUM_TEL( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_TIP_DOC( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{  
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_DTH_CON_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{ 
    WARNING_INVALID_FUNCTION;  
}

void TBSW0033RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0033RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params )
{
    WARNING_INVALID_FUNCTION;
}


