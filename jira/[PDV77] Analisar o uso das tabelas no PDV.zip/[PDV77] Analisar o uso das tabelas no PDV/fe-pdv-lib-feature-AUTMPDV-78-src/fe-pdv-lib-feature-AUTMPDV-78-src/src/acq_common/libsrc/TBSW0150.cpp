#include "TBSW0150.hpp"

namespace dbaccess_common
{
    TBSW0150::TBSW0150( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0150::TBSW0150( const std::string& whereClause )
    {
        initialize( );
        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    
    TBSW0150::~TBSW0150( )
    {
    }
    
    void TBSW0150::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, COD_IATA_ETD, TXT_DOC_PSSR_1, NOM_PSSR_1, TXT_DOC_PSSR_2, NOM_PSSR_2, TXT_DOC_PSSR_3, NOM_PSSR_3, TXT_DOC_PSSR_4, NOM_PSSR_4, TXT_DOC_PSSR_5, NOM_PSSR_5, VAL_TX_EMBQ";

        table_name = "TBSW0150";

        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_COD_IATA_ETD_pos = 3;
        m_TXT_DOC_PSSR_1_pos = 4;
        m_NOM_PSSR_1_pos = 5;
        m_TXT_DOC_PSSR_2_pos = 6;
        m_NOM_PSSR_2_pos = 7;
        m_TXT_DOC_PSSR_3_pos = 8;
        m_NOM_PSSR_3_pos = 9;
        m_TXT_DOC_PSSR_4_pos = 10;
        m_NOM_PSSR_4_pos = 11;
        m_TXT_DOC_PSSR_5_pos = 12;
        m_NOM_PSSR_5_pos = 13;
        m_VAL_TX_EMBQ_pos = 14;

        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_COD_IATA_ETD = 0;
        m_TXT_DOC_PSSR_1 = " ";
        m_NOM_PSSR_1 = " ";
        m_TXT_DOC_PSSR_2 = "";
        m_NOM_PSSR_2 = "";
        m_TXT_DOC_PSSR_3 = "";
        m_NOM_PSSR_3 = "";
        m_TXT_DOC_PSSR_4 = "";
        m_NOM_PSSR_4 = "";
        m_TXT_DOC_PSSR_5 = "";
        m_NOM_PSSR_5 = "";
        dbm_chartodec( &m_VAL_TX_EMBQ, "0.00000", 5 );
    }

    void TBSW0150::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_COD_IATA_ETD_pos, m_COD_IATA_ETD );
        bind( m_TXT_DOC_PSSR_1_pos, m_TXT_DOC_PSSR_1 );
        bind( m_NOM_PSSR_1_pos, m_NOM_PSSR_1 );
        bind( m_TXT_DOC_PSSR_2_pos, m_TXT_DOC_PSSR_2 );
        bind( m_NOM_PSSR_2_pos, m_NOM_PSSR_2 );
        bind( m_TXT_DOC_PSSR_3_pos, m_TXT_DOC_PSSR_3 );
        bind( m_NOM_PSSR_3_pos, m_NOM_PSSR_3 );
        bind( m_TXT_DOC_PSSR_4_pos, m_TXT_DOC_PSSR_4 );
        bind( m_NOM_PSSR_4_pos, m_NOM_PSSR_4 );
        bind( m_TXT_DOC_PSSR_5_pos, m_TXT_DOC_PSSR_5 );
        bind( m_NOM_PSSR_5_pos, m_NOM_PSSR_5 );
        bind( m_VAL_TX_EMBQ_pos, m_VAL_TX_EMBQ );
    }
    void TBSW0150::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0150::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    void TBSW0150::set_COD_IATA_ETD( unsigned long a_COD_IATA_ETD )
    {
        m_COD_IATA_ETD = a_COD_IATA_ETD;
    }
    void TBSW0150::set_TXT_DOC_PSSR_1( const std::string& a_TXT_DOC_PSSR_1 )
    {
        m_TXT_DOC_PSSR_1 = a_TXT_DOC_PSSR_1;
    }
    void TBSW0150::set_NOM_PSSR_1( const std::string& a_NOM_PSSR_1 )
    {
        m_NOM_PSSR_1 = a_NOM_PSSR_1;
    }
    void TBSW0150::set_TXT_DOC_PSSR_2( const std::string& a_TXT_DOC_PSSR_2 )
    {
        m_TXT_DOC_PSSR_2 = a_TXT_DOC_PSSR_2;
    }
    void TBSW0150::set_NOM_PSSR_2( const std::string& a_NOM_PSSR_2 )
    {
        m_NOM_PSSR_2 = a_NOM_PSSR_2;
    }
    void TBSW0150::set_TXT_DOC_PSSR_3( const std::string& a_TXT_DOC_PSSR_3 )
    {
        m_TXT_DOC_PSSR_3 = a_TXT_DOC_PSSR_3;
    }
    void TBSW0150::set_NOM_PSSR_3( const std::string& a_NOM_PSSR_3 )
    {
        m_NOM_PSSR_3 = a_NOM_PSSR_3;
    }
    void TBSW0150::set_TXT_DOC_PSSR_4( const std::string& a_TXT_DOC_PSSR_4 )
    {
        m_TXT_DOC_PSSR_4 = a_TXT_DOC_PSSR_4;
    }
    void TBSW0150::set_NOM_PSSR_4( const std::string& a_NOM_PSSR_4 )
    {
        m_NOM_PSSR_4 = a_NOM_PSSR_4;
    }
    void TBSW0150::set_TXT_DOC_PSSR_5( const std::string& a_TXT_DOC_PSSR_5 )
    {
        m_TXT_DOC_PSSR_5 = a_TXT_DOC_PSSR_5;
    }
    void TBSW0150::set_NOM_PSSR_5( const std::string& a_NOM_PSSR_5 )
    {
        m_NOM_PSSR_5 = a_NOM_PSSR_5;
    }
    void TBSW0150::set_VAL_TX_EMBQ( oasis_dec_t a_VAL_TX_EMBQ )
    {
        dbm_deccopy( &m_VAL_TX_EMBQ, &a_VAL_TX_EMBQ );
    }
    unsigned long TBSW0150::get_DAT_MOV_TRAN( ) const
    {
        return m_DAT_MOV_TRAN;
    }
    oasis_dec_t TBSW0150::get_NUM_SEQ_UNC( ) const
    {
        return m_NUM_SEQ_UNC;
    }
    unsigned long TBSW0150::get_COD_IATA_ETD( ) const
    {
        return m_COD_IATA_ETD;
    }
    const std::string& TBSW0150::get_TXT_DOC_PSSR_1( ) const
    {
        return m_TXT_DOC_PSSR_1;
    }
    const std::string& TBSW0150::get_NOM_PSSR_1( ) const
    {
        return m_NOM_PSSR_1;
    }
    const std::string& TBSW0150::get_TXT_DOC_PSSR_2( ) const
    {
        return m_TXT_DOC_PSSR_2;
    }
    const std::string& TBSW0150::get_NOM_PSSR_2( ) const
    {
        return m_NOM_PSSR_2;
    }
    const std::string& TBSW0150::get_TXT_DOC_PSSR_3( ) const
    {
        return m_TXT_DOC_PSSR_3;
    }
    const std::string& TBSW0150::get_NOM_PSSR_3( ) const
    {
        return m_NOM_PSSR_3;
    }
    const std::string& TBSW0150::get_TXT_DOC_PSSR_4( ) const
    {
        return m_TXT_DOC_PSSR_4;
    }
    const std::string& TBSW0150::get_NOM_PSSR_4( ) const
    {
        return m_NOM_PSSR_4;
    }
    const std::string& TBSW0150::get_TXT_DOC_PSSR_5( ) const
    {
        return m_TXT_DOC_PSSR_5;
    }
    const std::string& TBSW0150::get_NOM_PSSR_5( ) const
    {
        return m_NOM_PSSR_5;
    }
    oasis_dec_t TBSW0150::get_VAL_TX_EMBQ( ) const
    {
        return m_VAL_TX_EMBQ;
    }

} //namespace dbaccess_common
