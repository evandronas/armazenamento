#pragma once
#include "TBSW1039.hpp"

namespace dbaccess_common
{
    TBSW1039::TBSW1039( )
    {
        initialize( );
        where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW1039::TBSW1039( const std::string& a_whereCondition )
    {
        initialize( );
        where_condition = a_whereCondition;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW1039::~TBSW1039( )
    {
    }

    void TBSW1039::initialize( )
    {
        query_fields = "DAT_MOV_TRAN, NUM_SEQ_UNC, COD_MSG_ISO_ORGL, DTH_STTU_TRAN_ORGL, NUM_STAN_ORGL, COD_ISTT_ACQR_ORGL";

        table_name = "TBSW1039";

        m_DAT_MOV_TRAN_pos = 1;
        m_NUM_SEQ_UNC_pos = 2;
        m_COD_MSG_ISO_ORGL_pos = 3;
        m_DTH_STTU_TRAN_ORGL_pos = 4;
        m_NUM_STAN_ORGL_pos = 5;
        m_COD_ISTT_ACQR_ORGL_pos = 6;

        m_DAT_MOV_TRAN = 0;
        dbm_longtodec( &m_NUM_SEQ_UNC, 0 );
        m_COD_MSG_ISO_ORGL = 0;
        m_DTH_STTU_TRAN_ORGL = 0;
        dbm_longtodec( &m_NUM_STAN_ORGL, 0 );
        dbm_longtodec( &m_COD_ISTT_ACQR_ORGL, 0 );

        m_DTH_STTU_TRAN_ORGL_ind_null = DBM_NULL_DATA;
        m_NUM_STAN_ORGL_ind_null = DBM_NULL_DATA;
        m_COD_ISTT_ACQR_ORGL_ind_null = DBM_NULL_DATA;
    }

    void TBSW1039::bind_columns( )
    {
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_COD_MSG_ISO_ORGL_pos, m_COD_MSG_ISO_ORGL );
        bind( m_DTH_STTU_TRAN_ORGL_pos, &m_DTH_STTU_TRAN_ORGL, &m_DTH_STTU_TRAN_ORGL_ind_null );
        bind( m_NUM_STAN_ORGL_pos, m_NUM_STAN_ORGL, &m_NUM_STAN_ORGL_ind_null );
        bind( m_COD_ISTT_ACQR_ORGL_pos, m_COD_ISTT_ACQR_ORGL, &m_COD_ISTT_ACQR_ORGL_ind_null );

        m_DTH_STTU_TRAN_ORGL_ind_null = is_null( &m_DTH_STTU_TRAN_ORGL ) ? DBM_NULL_DATA : 0;
        m_NUM_STAN_ORGL_ind_null = is_null( m_NUM_STAN_ORGL ) ? DBM_NULL_DATA : 0;
        m_COD_ISTT_ACQR_ORGL_ind_null = is_null( m_COD_ISTT_ACQR_ORGL ) ? DBM_NULL_DATA : 0;
    }

    //SET 
    void  TBSW1039::set_DAT_MOV_TRAN( const unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void  TBSW1039::set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC )
    {
        dbm_deccopy( &m_NUM_SEQ_UNC, &a_NUM_SEQ_UNC );
    }
    void  TBSW1039::set_COD_MSG_ISO_ORGL( const unsigned long a_COD_MSG_ISO_ORGL )
    {
        m_COD_MSG_ISO_ORGL = a_COD_MSG_ISO_ORGL;
    }
    void  TBSW1039::set_DTH_STTU_TRAN_ORGL( const dbm_datetime_t a_DTH_STTU_TRAN_ORGL )
    {
        m_DTH_STTU_TRAN_ORGL = a_DTH_STTU_TRAN_ORGL;
        m_DTH_STTU_TRAN_ORGL_ind_null = 0;
    }
    void  TBSW1039::set_NUM_STAN_ORGL( const oasis_dec_t& a_NUM_STAN_ORGL )
    {
        m_NUM_STAN_ORGL = a_NUM_STAN_ORGL;
        m_NUM_STAN_ORGL_ind_null = 0;
    }
    void  TBSW1039::set_COD_ISTT_ACQR_ORGL( const oasis_dec_t& a_COD_ISTT_ACQR_ORGL )
    {
        m_COD_ISTT_ACQR_ORGL = a_COD_ISTT_ACQR_ORGL;
        m_COD_ISTT_ACQR_ORGL_ind_null = 0;
    }

    //GET 
    unsigned long TBSW1039::get_DAT_MOV_TRAN( ) const
    {
        return( m_DAT_MOV_TRAN );
    }
    oasis_dec_t TBSW1039::get_NUM_SEQ_UNC( ) const
    {
        return( m_NUM_SEQ_UNC );
    }
    unsigned long TBSW1039::get_COD_MSG_ISO_ORGL( ) const
    {
        return( m_COD_MSG_ISO_ORGL );
    }
    const dbm_datetime_t TBSW1039::get_DTH_STTU_TRAN_ORGL( ) const
    {
        return( m_DTH_STTU_TRAN_ORGL );
    }
    const oasis_dec_t& TBSW1039::get_NUM_STAN_ORGL( ) const
    {
        return( m_NUM_STAN_ORGL );
    }
    const oasis_dec_t& TBSW1039::get_COD_ISTT_ACQR_ORGL( ) const
    {
        return( m_COD_ISTT_ACQR_ORGL );
    }

    void TBSW1039::setWhereClause( const std::string& a_whereClause )
    {
        where_condition = a_whereClause;
    }

}//namespace dbaccess_common
