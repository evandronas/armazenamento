#include<TBSW0150RegrasFormatacaoBase.hpp>

TBSW0150RegrasFormatacaoBase::TBSW0150RegrasFormatacaoBase( )
{
}

TBSW0150RegrasFormatacaoBase::~TBSW0150RegrasFormatacaoBase( )
{
}

void TBSW0150RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::COD_IATA_ETD( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_IATA_ETD( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_IATA_ETD( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::TXT_DOC_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_DOC_PSSR_1( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_DOC_PSSR_1( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::NOM_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_PSSR_1( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_PSSR_1( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::TXT_DOC_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_DOC_PSSR_2( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_DOC_PSSR_2( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::NOM_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_PSSR_2( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_PSSR_2( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::TXT_DOC_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_DOC_PSSR_3( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_DOC_PSSR_3( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::NOM_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_PSSR_3( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_PSSR_3( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::TXT_DOC_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_DOC_PSSR_4( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_DOC_PSSR_4( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::NOM_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_PSSR_4( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_PSSR_4( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::TXT_DOC_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_DOC_PSSR_5( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_DOC_PSSR_5( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::NOM_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_PSSR_5( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_PSSR_5( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::VAL_TX_EMBQ( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_VAL_TX_EMBQ( tbsw0150, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_VAL_TX_EMBQ( tbsw0150, params );
    }
}

void TBSW0150RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_COD_IATA_ETD( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_TXT_DOC_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_NOM_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_TXT_DOC_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_NOM_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_TXT_DOC_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_NOM_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_TXT_DOC_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_NOM_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_TXT_DOC_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_NOM_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::gen_VAL_TX_EMBQ( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    tbsw0150.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0150RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw0150.set_NUM_SEQ_UNC( l_dect );
}

void TBSW0150RegrasFormatacaoBase::insert_COD_IATA_ETD( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_TXT_DOC_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_NOM_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_TXT_DOC_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_NOM_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_TXT_DOC_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_NOM_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_TXT_DOC_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_NOM_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_TXT_DOC_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_NOM_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::insert_VAL_TX_EMBQ( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_COD_IATA_ETD( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_TXT_DOC_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_NOM_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_TXT_DOC_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_NOM_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_TXT_DOC_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_NOM_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_TXT_DOC_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_NOM_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_TXT_DOC_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_NOM_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0150RegrasFormatacaoBase::update_VAL_TX_EMBQ( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params )
{
    WARNING_INVALID_FUNCTION;
}
