/*
-------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-POS
/ Descricao: EAK-1847 - [PacoteEstabilidade] Desativação do uso do "FOR UPDATE"
/ Autor: Renato de Camargo
/ Data de Criacao: 03/10/2019
-------------------------------------------------------------------------------------------------
*/
#pragma once
#include "base/GenException.hpp"
#include "TBSW2020.hpp"
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <unistd.h> 

namespace dbaccess_common
{
    TBSW2020::TBSW2020( )
    {
		query_fields = "SGL_SITE, DAT_RESET, VAL_RESET_NUM_SEQ_UNC, VAL_ATU_NUM_SEQ_UNC, VAL_RNG_NUM_SEQ_UNC, NOM_HOST, COD_PR_EXEC, DTH_ULT_ATLZ";
        table_name = "TBSW2020";
        where_condition = "";
        SGL_SITE_pos = 1;
        VAL_RESET_NUM_SEQ_UNC_pos = 3;
        VAL_RNG_NUM_SEQ_UNC_pos = 5;
        VAL_ATU_NUM_SEQ_UNC_pos = 4;
        DAT_RESET_pos = 2;
        dbm_inttodec( &m_nsu, 0 );
        dbm_inttodec( &m_rangeLimite, 0 );
        m_range = 0;
        m_resetDate = 0;
		// Inicializacao campos Novos
		nomHost = "";
		processoId = 0;
		dataUltimaAtualizacao = 0;	
		// Posicao campos Novos		
		posNomHost = 6;
		posProcessoId = 7;
		posDataUltimaAtualizacao = 8;
        set_where_condition( "" );

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW2020::TBSW2020( std::string a_table )
    {
        query_fields = "SGL_SITE, DAT_RESET, VAL_RESET_NUM_SEQ_UNC, VAL_ATU_NUM_SEQ_UNC, VAL_RNG_NUM_SEQ_UNC, NOM_HOST, COD_PR_EXEC, DTH_ULT_ATLZ";
        table_name = a_table;
        where_condition = "";
        SGL_SITE_pos = 1;
        VAL_RESET_NUM_SEQ_UNC_pos = 3;
        VAL_RNG_NUM_SEQ_UNC_pos = 5;
        VAL_ATU_NUM_SEQ_UNC_pos = 4;
        DAT_RESET_pos = 2;
        dbm_inttodec( &m_nsu, 0 );
        dbm_inttodec( &m_rangeLimite, 0 );
        m_range = 0;
        m_resetDate = 0;
		// Inicializacao campos Novos
		nomHost = "";
		processoId = 0;
		dataUltimaAtualizacao = 0;	
		// Posicao campos Novos		
		posNomHost = 6;
		posProcessoId = 7;
		posDataUltimaAtualizacao = 8;
        set_where_condition( "" );

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW2020::~TBSW2020( )
    {
    }
    void TBSW2020::set_VAL_RESET_NUM_SEQ_UNC( oasis_dec_t a_value )
    {
        VAL_RESET_NUM_SEQ_UNC = a_value;
    }
    void TBSW2020::set_VAL_ATU_NUM_SEQ_UNC( oasis_dec_t a_value )
    {
        VAL_ATU_NUM_SEQ_UNC = a_value;
    }
    void TBSW2020::set_VAL_RNG_NUM_SEQ_UNC( int a_value )
    {
        VAL_RNG_NUM_SEQ_UNC = a_value;
    }
    void TBSW2020::set_SGL_SITE( const std::string& a_value )
    {
        SGL_SITE = a_value;
    }
    void TBSW2020::set_DAT_RESET( const dbm_datetime_t& a_value )
    {
        DAT_RESET = a_value;
    }
    oasis_dec_t TBSW2020::get_VAL_RESET_NUM_SEQ_UNC( )
    {
        return VAL_RESET_NUM_SEQ_UNC;
    }
    oasis_dec_t TBSW2020::get_VAL_ATU_NUM_SEQ_UNC( )
    {
        return VAL_ATU_NUM_SEQ_UNC;
    }
    int TBSW2020::get_VAL_RNG_NUM_SEQ_UNC( )
    {
        return VAL_RNG_NUM_SEQ_UNC;
    }
    const std::string& TBSW2020::get_SGL_SITE( )
    {
        return SGL_SITE;
    }
    const dbm_datetime_t& TBSW2020::get_DAT_RESET( )
    {
        return DAT_RESET;
    }
    bool TBSW2020::VAL_RESET_NUM_SEQ_UNC_is_null( )
    {
        return is_null( VAL_RESET_NUM_SEQ_UNC_pos );
    }
    bool TBSW2020::VAL_ATU_NUM_SEQ_UNC_is_null( )
    {
        return is_null( VAL_ATU_NUM_SEQ_UNC_pos );
    }
    bool TBSW2020::VAL_RNG_NUM_SEQ_UNC_is_null( )
    {
        return is_null( VAL_RNG_NUM_SEQ_UNC_pos );
    }
    bool TBSW2020::SGL_SITE_is_null( )
    {
        return is_null( SGL_SITE_pos );
    }
    bool TBSW2020::DAT_RESET_is_null( )
    {
        return is_null( DAT_RESET_pos );
    }
	// Campos Novos
	/// SetNomeHost
	/// Descrição : Set para Campo Nome Host
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial
	void TBSW2020::SetNomeHost( const std::string value ) 
	{
		nomHost = value;
	}
	/// SetProcessoId
	/// Descrição : Set Campo Nome ProcessoId
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial	
	void TBSW2020::SetProcessoId( int pid )
	{
		processoId = pid;
	}
	/// SetDataUltimaAtualizacao
	/// Descrição : Set Campo Data Ultima Atualizacao
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial	
	void TBSW2020::SetDataUltimaAtualizacao( const dbm_datetime_t& value )
	{
		dataUltimaAtualizacao = value;
	}
	/// GetNomeHost
	/// Descrição : Get PID
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial		
	const std::string& TBSW2020::GetNomeHost()
	{
		return nomHost;
	}
	/// GetProcessoId
	/// Descrição : Get PID
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial		
	int  TBSW2020::GetProcessoId()
	{
		return processoId;
	}	
	/// GetDataUltimaAtualizacao
	/// Descrição : Get DataUltimaAtualizacao
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial		
	const dbm_datetime_t& TBSW2020::GetDataUltimaAtualizacao()
	{
		return dataUltimaAtualizacao;
	}
	/// NomeHostIsNull
	/// Descrição : Verifica se Nome eh NULL
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial	
	bool TBSW2020::NomeHostIsNull()
	{
		return is_null( nomHost );
	}
	/// ProcessoIdIsNull
	/// Descrição : Verifica se Processo eh NULL
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial	
	bool TBSW2020::ProcessoIdIsNull()
	{
		return is_null( processoId );
	}
	/// DataUltimaAtualizacaoIsNull
	/// Descrição : Verifica se Data Ultima Atualizacao eh NULL
	/// EF/ET: AM 260.465
	/// 23.12.19 - Versao Inicial	
	bool TBSW2020::DataUltimaAtualizacaoIsNull()
	{
		return is_null( dataUltimaAtualizacao );		
	}
    void TBSW2020::bind_columns( )
    {
        bind( VAL_RESET_NUM_SEQ_UNC_pos, VAL_RESET_NUM_SEQ_UNC );
        bind( VAL_ATU_NUM_SEQ_UNC_pos, VAL_ATU_NUM_SEQ_UNC );
        bind( VAL_RNG_NUM_SEQ_UNC_pos, VAL_RNG_NUM_SEQ_UNC );
        bind( SGL_SITE_pos, SGL_SITE );
        bind( DAT_RESET_pos, &DAT_RESET );
		// Bind Novos Campos
		bind( posProcessoId, processoId );
		bind( posNomHost, nomHost  );
		bind( posDataUltimaAtualizacao, &dataUltimaAtualizacao);
    }
    void TBSW2020::set_table_name( const std::string& a_table )
    {
        table_name = a_table;
    }
    void TBSW2020::set_where_condition( const std::string& a_where )
    {
        where_condition = a_where;
    }
    void TBSW2020::set_query_fields( const std::string& a_fields )
    {
        query_fields = a_fields;
    }
    oasis_dec_t TBSW2020::currentNsu( )
    {
        m_now = time( NULL );
        oasis_dec_t l_nsu;
        dbm_inttodec( &l_nsu, 0 );
		
        std::string l_whereClause;
        std::string l_sgl_site( std::string( getenv( "NOM_SITE_ACQR" ) ) );
		std::string nomHostAcqr( std::string( getenv( "NOM_HOST_ACQR" ) ) );
		
		l_whereClause = "SGL_SITE in ( LOWER('" + l_sgl_site  + "') , UPPER('" + l_sgl_site + "') ) and NOM_HOST = '" + nomHostAcqr  + "'";
		set_where_condition(l_whereClause);
		prepare();
		execute();
		if( !fetch() ) 
		{
			l_whereClause = "SGL_SITE in ( LOWER('" + l_sgl_site  + "') , UPPER('" + l_sgl_site + "') ) and NOM_HOST = '*'";
			set_where_condition(l_whereClause);
		}
        
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, " ========= Clausula Where TBSW2020 ==========" );
        logger::DebugWriter::getInstance()->write( logger::LEVEL_DEBUG, l_whereClause.c_str( ) );

        if ( dbm_cmpzero( &m_nsu ) <= 0 )
        {
            prepare_for_update( );
            execute( );
            fetch( );
            // Bug-32856: Gravando NSU zerado.
            m_nsu = get_VAL_ATU_NUM_SEQ_UNC( );
            if ( dbm_cmpzero( &m_nsu ) == 0 )
            {
                // Inicio do sistema, com o tab.VAL_ATU_NUM_SEQ_UNC zerado
                m_nsu = get_VAL_RESET_NUM_SEQ_UNC( );
            }
            m_range = get_VAL_RNG_NUM_SEQ_UNC( );
            dbm_decnadd( &m_nsu, ( double ) m_range, &m_rangeLimite );
            m_resetDate = get_DAT_RESET( );
            set_VAL_ATU_NUM_SEQ_UNC( m_rangeLimite );
			//SetNomeHost( nomHostAcqr );
			SetProcessoId( getpid() );
			SetDataUltimaAtualizacao( m_now );
            update();
            commit( );
        }
        if ( m_now > m_resetDate )
        {
            prepare_for_update(  );
            execute( );
            fetch( );
            
            if( m_now > get_DAT_RESET( ) )
            {
                dbm_datetime_t l_nextResetDate = time( NULL );
                int l_year = 0;
                int l_month = 0;
                int l_day = 0;
                
                dbm_unmake_datetime(l_nextResetDate, &l_year, &l_month, &l_day, NULL, NULL, NULL);
                dbm_make_datetime(&l_nextResetDate, l_year, l_month, l_day, 23, 59, 59);
                
                m_nsu = get_VAL_RESET_NUM_SEQ_UNC( );
                m_range = get_VAL_RNG_NUM_SEQ_UNC( );
                dbm_decnadd( &m_nsu, ( double ) m_range, &m_rangeLimite );

                m_resetDate = l_nextResetDate;
                
                set_VAL_ATU_NUM_SEQ_UNC( m_rangeLimite );
                set_DAT_RESET( m_resetDate );
            }
            else
            {
                m_nsu = get_VAL_ATU_NUM_SEQ_UNC( );
                m_range = get_VAL_RNG_NUM_SEQ_UNC( );
                dbm_decnadd( &m_nsu, ( double ) m_range, &m_rangeLimite );
                m_resetDate = get_DAT_RESET( );
                set_VAL_ATU_NUM_SEQ_UNC( m_rangeLimite );
            }
			//SetNomeHost( nomHostAcqr );
			SetProcessoId( getpid() );
			SetDataUltimaAtualizacao( m_now );
            update();
            commit( );
        }
        else
        {
            if ( ( ( m_range > 0 ) && ( dbm_deccmp( &m_nsu, &m_rangeLimite ) >= 0 ) ) || 
                 ( ( m_range < 0 ) && ( dbm_deccmp( &m_nsu, &m_rangeLimite ) <= 0 ) ) )
            {
                prepare_for_update(  );
                execute( );
                fetch( );
                m_nsu = get_VAL_ATU_NUM_SEQ_UNC( );
                m_range = get_VAL_RNG_NUM_SEQ_UNC( );
                dbm_decnadd( &m_nsu, ( double ) m_range, &m_rangeLimite );
                set_VAL_ATU_NUM_SEQ_UNC( m_rangeLimite );
				//SetNomeHost( nomHostAcqr );
				SetProcessoId( getpid() );
				SetDataUltimaAtualizacao( m_now );
                update(  );
                commit( );
            }
        }
        dbm_deccopy( &l_nsu, &m_nsu );
        if ( m_range > 0 )
        {
            dbm_decnadd( &m_nsu, ( double ) 2, &m_nsu );
        }
        else
        {
            dbm_decnsub( &m_nsu, ( double ) 2, &m_nsu );
        }
        return l_nsu;   
  
  }//currentNsu
}//namespace dbaccess_common
