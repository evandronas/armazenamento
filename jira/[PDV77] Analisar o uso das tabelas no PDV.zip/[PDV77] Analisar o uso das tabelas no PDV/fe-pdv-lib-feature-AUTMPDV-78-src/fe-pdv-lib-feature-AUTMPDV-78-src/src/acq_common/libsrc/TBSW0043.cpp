/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pos::TBSW0043>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pos::TBSW0043Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>
/ Data de Cria��o: <Thu Nov 01 09:26:32 2012>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/
#include "TBSW0043.hpp"

namespace dbaccess_common
{
    TBSW0043::TBSW0043( )
    {
        query_fields = "COD_TERM, COD_STTU_REG, DAT_ATLZ_REG, COD_FUN"; 
		table_name = "TBSW0043";
		where_condition = "";
		m_COD_TERM_pos = 1;
        m_COD_STTU_REG_pos = 2;
        m_DAT_ATLZ_REG_pos = 3;
        m_COD_FUN_pos = 4;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }
    TBSW0043::TBSW0043( const std::string& str )
    {
        query_fields = "COD_TERM, COD_STTU_REG, DAT_ATLZ_REG, COD_FUN";

        table_name = "TBSW0043";
		where_condition = str;
        m_COD_TERM_pos = 1;
        m_COD_STTU_REG_pos = 2;
        m_DAT_ATLZ_REG_pos = 3;
        m_COD_FUN_pos = 4;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
    }

    TBSW0043::~TBSW0043( )
    {
    }
    const std::string& TBSW0043::get_COD_TERM( ) const
    {
        return m_COD_TERM;
    }
    const std::string& TBSW0043::get_COD_STTU_REG( ) const
    {
        return m_COD_STTU_REG;
    }
    const dbm_datetime_t& TBSW0043::get_DAT_ATLZ_REG( ) const
    {
        return m_DAT_ATLZ_REG;
    }
    long TBSW0043::get_COD_FUN( ) const
    {
        return m_COD_FUN;
    }


    void  TBSW0043::set_COD_TERM( const std::string& a_COD_TERM )
    {
        m_COD_TERM = a_COD_TERM;
    }
    void  TBSW0043::set_COD_STTU_REG( const std::string& a_COD_STTU_REG )
    {
        m_COD_STTU_REG = a_COD_STTU_REG;
    }
    void  TBSW0043::set_DAT_ATLZ_REG( const dbm_datetime_t& a_DAT_ATLZ_REG )
    {
        m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
    }
    void  TBSW0043::set_COD_FUN( long a_COD_FUN )
    {
        m_COD_FUN = a_COD_FUN;
    }


    void TBSW0043::bind_columns( )
    {
        bind( m_COD_TERM_pos, m_COD_TERM );
        bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
        bind( m_DAT_ATLZ_REG_pos, &m_DAT_ATLZ_REG );
        bind( m_COD_FUN_pos, m_COD_FUN );
    }

}//namespace dbaccess_common

