/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "TBSW0073.hpp"

namespace dbaccess_common
{
	TBSW0073::TBSW0073( )
	{
		query_fields = "COD_RAM_ATVD, COD_STTU_REG, QTD_DIA_PRZO_PRE_AUT";
		table_name = "TBSW0073";
		where_condition = "";
		m_COD_RAM_ATVD_pos         = 1;
		m_COD_STTU_REG_pos         = 2;
		m_QTD_DIA_PRZO_PRE_AUT_pos = 3;
		m_COD_RAM_ATVD = 0;
		m_COD_STTU_REG = "";
		m_QTD_DIA_PRZO_PRE_AUT = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0073::TBSW0073( const std::string& str )
	{
		query_fields = "COD_RAM_ATVD, COD_STTU_REG, QTD_DIA_PRZO_PRE_AUT";
		table_name = "TBSW0073";
		where_condition = str;
		m_COD_RAM_ATVD_pos         = 1;
		m_COD_STTU_REG_pos         = 2;
		m_QTD_DIA_PRZO_PRE_AUT_pos = 3;
		m_COD_RAM_ATVD = 0;
		m_COD_STTU_REG = "";
		m_QTD_DIA_PRZO_PRE_AUT = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0073::~TBSW0073( )
	{
	}
	//////////////////////////////////// GET ////////////////////////////////////
	long TBSW0073::getCOD_RAM_ATVD( ) const
	{
		return m_COD_RAM_ATVD;
	}
	const std::string& TBSW0073::getCOD_STTU_REG( ) const
	{
		return m_COD_STTU_REG;
	}
	long TBSW0073::getQTD_DIA_PRZO_PRE_AUT( ) const
	{
		return m_QTD_DIA_PRZO_PRE_AUT;
	}
	void TBSW0073::bind_columns( )
	{
		bind( m_COD_RAM_ATVD_pos, m_COD_RAM_ATVD );
		bind( m_COD_STTU_REG_pos, m_COD_STTU_REG );
		bind( m_QTD_DIA_PRZO_PRE_AUT_pos, m_QTD_DIA_PRZO_PRE_AUT );
	}
}//namespace dbaccess_common

