#include <cstring>
#include<TBSW0034RegrasFormatacaoBase.hpp>
#include<AcqUtils.hpp>
#include "msgConv/TextConv.hpp"

TBSW0034RegrasFormatacaoBase::TBSW0034RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0034RegrasFormatacaoBase::~TBSW0034RegrasFormatacaoBase( )
{
}

void TBSW0034RegrasFormatacaoBase::TXT_RLCD_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_RLCD_CHIP( tbsw0034, tbsw0034_params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_TXT_RLCD_CHIP( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_INFO_CMPM_CHIP( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_TXT_INFO_CMPM_CHIP( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_TXT_RSTD_ATLZ_CHIP( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_TXT_RSTD_ATLZ_CHIP( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_NVL_SGRA_KMRC( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_IND_NVL_SGRA_KMRC( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::DAT_VD_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_VD_CHIP( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_DAT_VD_CHIP( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::COD_PGM_AUT( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_PGM_AUT( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_COD_PGM_AUT( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_MTDO_VRFC_PORT( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_IND_MTDO_VRFC_PORT( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::IND_PRSC_SNHA( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_PRSC_SNHA( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_IND_PRSC_SNHA( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::NUM_SEQ_CAR_VLDC_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_CAR_VLDC_CHIP( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_CAR_VLDC_CHIP( tbsw0034, tbsw0034_params );
    }
}

void TBSW0034RegrasFormatacaoBase::NOM_PORT_CAR( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params, const acq_common::OPERACAO& operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_PORT_CAR( tbsw0034, tbsw0034_params );
    }
    if( operacao == acq_common::UPDATE )
    {
        update_NOM_PORT_CAR( tbsw0034, tbsw0034_params );
    }
}

//#######################################################################
//#######################################################################

void TBSW0034RegrasFormatacaoBase::insert_TXT_RLCD_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    if( tbsw0034_params.iss_name == "AMEX_FULL" &&
        strlen( tbsw0034_params.chip_full_data.c_str( ) ) && tbsw0034_params.chip_full_data_len > 0 )
    {
        std::string de055_esperado = "C1C7D5E20001";
        std::string conteudo_tag   = "";
        std::string chip           = tbsw0034_params.chip_full_data;
        
        std::transform(chip.begin( ), chip.end( ),chip.begin( ), ::toupper);
        
        if( AcqUtils::findChip( chip, "9F26", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F10", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F37", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F36", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "95", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }

        if( AcqUtils::findChip( chip, "9A", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9C", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F02", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "5F2A", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F1A", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "82", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "9F03", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        if( AcqUtils::findChip( chip, "5F34", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }

        if( AcqUtils::findChip( chip, "9F27", conteudo_tag ) == true )
        {
            if( conteudo_tag.empty( ) == false )
            {
                de055_esperado.append( conteudo_tag );
                conteudo_tag = "";
            }
        }
        
        chip = de055_esperado;
        
        tbsw0034.set_TXT_RLCD_CHIP( chip );
    }
    //t694449@FIS@BT57923@11.03.2014
    else if ( strlen( tbsw0034_params.chip_full_data.c_str( ) ) && tbsw0034_params.chip_full_data_len > 0 )
    {			
        // t719927 chip_full_data_len contem o numero equivalente de bytes dos dados do chip, metade do numero de caracteres a serem gravados no BD
        std::string chip = tbsw0034_params.chip_full_data.substr( 0, tbsw0034_params.chip_full_data_len * 2 );        
        tbsw0034.set_TXT_RLCD_CHIP( chip );
    }
    else
    {
        WARNING_EMPTY_STRING;
        tbsw0034.set_TXT_RLCD_CHIP( " " );
    }
}

void TBSW0034RegrasFormatacaoBase::insert_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    gen_TXT_INFO_CMPM_CHIP( tbsw0034, tbsw0034_params );
}

void TBSW0034RegrasFormatacaoBase::insert_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    gen_TXT_RSTD_ATLZ_CHIP( tbsw0034, tbsw0034_params );
}

void TBSW0034RegrasFormatacaoBase::insert_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    tbsw0034.set_IND_NVL_SGRA_KMRC( std::string("0") );
}

void TBSW0034RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    tbsw0034.set_DAT_MOV_TRAN( tbsw0034_params.local_date );
}

void TBSW0034RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{    
    tbsw0034.set_NUM_SEQ_UNC( atol(tbsw0034_params.refnum.c_str()) );
}

void TBSW0034RegrasFormatacaoBase::insert_DAT_VD_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{    
    tbsw0034.set_DAT_VD_CHIP( AcqUtils::dateTime( tbsw0034_params.local_date, tbsw0034_params.local_time ) );
}

void TBSW0034RegrasFormatacaoBase::insert_COD_PGM_AUT( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    tbsw0034.set_COD_PGM_AUT( std::string(" ") );
}

void TBSW0034RegrasFormatacaoBase::insert_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    if ( strlen( tbsw0034_params.cvm_code.c_str( ) ) )
    {
        tbsw0034.set_IND_MTDO_VRFC_PORT( tbsw0034_params.cvm_code.substr( 1, 1 ) );
    }
}

void TBSW0034RegrasFormatacaoBase::insert_IND_PRSC_SNHA( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    if ( strlen( tbsw0034_params.pin.c_str( ) ) )
    {
        tbsw0034.set_IND_PRSC_SNHA( "S" );
    }
    else
    {
        tbsw0034.set_IND_PRSC_SNHA( "N" );
    }
}

void TBSW0034RegrasFormatacaoBase::insert_NUM_SEQ_CAR_VLDC_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    if ( tbsw0034_params.card_seqno.size() != 0 && !tbsw0034_params.card_seqno.empty( ) )//nao veio DE023?
    {
        tbsw0034.set_NUM_SEQ_CAR_VLDC_CHIP( atol( tbsw0034_params.card_seqno.c_str( ) ) );
    }
    else
    {
        if( tbsw0034_params.iss_name == "VISA_CREDITO" )
        {
            tbsw0034.set_NUM_SEQ_CAR_VLDC_CHIP( 0 );
        }
        else
        {
            tbsw0034.set_NUM_SEQ_CAR_VLDC_CHIP( 999 );
        }
    }
}

void TBSW0034RegrasFormatacaoBase::insert_NOM_PORT_CAR( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    if ( !tbsw0034_params.cardholder_name_extended.empty( ) )
    {
        tbsw0034.set_NOM_PORT_CAR( tbsw0034_params.cardholder_name_extended );
    }
}

//#######################################################################
//#######################################################################

void TBSW0034RegrasFormatacaoBase::update_TXT_RLCD_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    gen_TXT_INFO_CMPM_CHIP( tbsw0034, tbsw0034_params );
}

void TBSW0034RegrasFormatacaoBase::update_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    gen_TXT_RSTD_ATLZ_CHIP( tbsw0034, tbsw0034_params );
}

void TBSW0034RegrasFormatacaoBase::update_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_DAT_VD_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_COD_PGM_AUT( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_IND_PRSC_SNHA( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_NUM_SEQ_CAR_VLDC_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::update_NOM_PORT_CAR( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

//#######################################################################
//#######################################################################

void TBSW0034RegrasFormatacaoBase::gen_TXT_RLCD_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    if ( strlen( tbsw0034_params.second_gen_ac.c_str( ) ) )
    {
        // .. Ajustado pois no banco esta com tamanho limitado a 128 ..
        tbsw0034.set_TXT_INFO_CMPM_CHIP( tbsw0034_params.second_gen_ac.substr( 0, 128 ) );
    }
    else
    {
        WARNING_EMPTY_STRING;
        tbsw0034.set_TXT_INFO_CMPM_CHIP( " " );
    }
}

void TBSW0034RegrasFormatacaoBase::gen_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    if ( strlen( tbsw0034_params.isr.c_str( ) ) )
    {
        tbsw0034.set_TXT_RSTD_ATLZ_CHIP( tbsw0034_params.isr );
    }
    else
    {
        WARNING_EMPTY_STRING;
        tbsw0034.set_TXT_RSTD_ATLZ_CHIP( " " );
    }
}

void TBSW0034RegrasFormatacaoBase::gen_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_DAT_VD_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_COD_PGM_AUT( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_IND_PRSC_SNHA( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_NUM_SEQ_CAR_VLDC_CHIP( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0034RegrasFormatacaoBase::gen_NOM_PORT_CAR( dbaccess_common::TBSW0034& tbsw0034, const struct acq_common::tbsw0034_params& tbsw0034_params )
{
    WARNING_INVALID_FUNCTION;
}

//#######################################################################
//#######################################################################

