#include<TBSW0052RegrasFormatacaoBase.hpp>

TBSW0052RegrasFormatacaoBase::TBSW0052RegrasFormatacaoBase( )
{
}

TBSW0052RegrasFormatacaoBase::~TBSW0052RegrasFormatacaoBase( )
{
}
