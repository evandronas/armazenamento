#include<TBSW0055RegrasFormatacaoBase.hpp>
#include "CodUcafFormaterElo.hpp"

TBSW0055RegrasFormatacaoBase::TBSW0055RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance();
}

TBSW0055RegrasFormatacaoBase::~TBSW0055RegrasFormatacaoBase( )
{
}

void TBSW0055RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0055, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0055, params );
    }
}

void TBSW0055RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0055, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0055, params );
    }
}

void TBSW0055RegrasFormatacaoBase::COD_UCAF( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_UCAF( tbsw0055, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_UCAF( tbsw0055, params );
    }
}

void TBSW0055RegrasFormatacaoBase::IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_IND_NVL_SGRA_KMRC( tbsw0055, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_IND_NVL_SGRA_KMRC( tbsw0055, params );
    }
}

void TBSW0055RegrasFormatacaoBase::COD_VLDC_ATTC_PRTO_SGRA( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_VLDC_ATTC_PRTO_SGRA( tbsw0055, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_VLDC_ATTC_PRTO_SGRA( tbsw0055, params );
    }
}

// Metodos especificos para INSERT

void TBSW0055RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    tbsw0055.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0055RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    tbsw0055.set_NUM_SEQ_UNC( params.refnum );
}

void TBSW0055RegrasFormatacaoBase::insert_COD_UCAF( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    std::string codUcaf = formata_COD_UCAF(params);
    std::string log_msg = "TBSW0055RegrasFormatacaoBase::insert_COD_UCAF [" + codUcaf + "]";
    m_log->write( logger::LEVEL_DEBUG, log_msg.c_str() );

    tbsw0055.set_COD_UCAF( codUcaf );
}

void TBSW0055RegrasFormatacaoBase::insert_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    tbsw0055.set_IND_NVL_SGRA_KMRC( params.eci );
}

void TBSW0055RegrasFormatacaoBase::insert_COD_VLDC_ATTC_PRTO_SGRA( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    WARNING_INVALID_FUNCTION
}

// Metodos especificos para UPDATE

void TBSW0055RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0055RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0055RegrasFormatacaoBase::update_COD_UCAF( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0055RegrasFormatacaoBase::update_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0055RegrasFormatacaoBase::update_COD_VLDC_ATTC_PRTO_SGRA( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params )
{
        tbsw0055.SetProtocolValidationResult( params.protocol_validation_result );
}


/*
    Funcoes Auxiliares
*/

std::string TBSW0055RegrasFormatacaoBase::formata_COD_UCAF( const struct acq_common::tbsw0055_params &params )
{
    // Formata apenas para Elo
    CodUcafFormaterElo codUcafFormaterElo = CodUcafFormaterElo(params.cavv).setCodigoTransacao(params.transcode);
    return codUcafFormaterElo.format();
}
