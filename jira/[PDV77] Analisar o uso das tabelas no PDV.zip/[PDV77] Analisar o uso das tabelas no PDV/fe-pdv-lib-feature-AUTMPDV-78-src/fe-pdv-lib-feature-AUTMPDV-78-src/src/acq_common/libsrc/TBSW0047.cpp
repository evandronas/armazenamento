/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include "TBSW0047.hpp"
namespace dbaccess_common
{
	TBSW0047::TBSW0047( )
	{
		query_fields = "COD_BCO_CMPS, COD_INT_BCO, COD_MODO_OPE_BCO, COD_MODO_PLTO, IND_OPE_CDC, DAT_VIG_CDC, \
		IND_OPE_PRCI, DAT_VIG_PRCI, DAT_VIG_PDA, IND_OPE_GRNT_CHQ, IND_SIT_BCO, \
		IND_SIT_BCO_ESTB, NOM_BCO_CMPL, TMS_INCL, COD_STTU_REG, IND_OPE_PDA, DAT_VIG_GRNT_CHQ";
		table_name = "TBSW0047";
		where_condition = "";
		COD_BCO_CMPS_pos = 1;
		COD_INT_BCO_pos = 2;
		COD_MODO_OPE_BCO_pos = 3;
		COD_MODO_PLTO_pos = 4;
		IND_OPE_CDC_pos = 5;
		DAT_VIG_CDC_pos = 6;
		IND_OPE_PRCI_pos = 7;
		DAT_VIG_PRCI_pos = 8;
		DAT_VIG_PDA_pos = 9;
		IND_OPE_GRNT_CHQ_pos = 10;
		IND_SIT_BCO_pos = 11;
		IND_SIT_BCO_ESTB_pos = 12;
		NOM_BCO_CMPL_pos = 13;
		TMS_INCL_pos = 14;
		COD_STTU_REG_pos = 15;
		IND_OPE_PDA_pos = 16;
		DAT_VIG_GRNT_CHQ_pos = 17;
		m_COD_BCO_CMPS = 0;
		m_COD_INT_BCO = 0;
		m_COD_MODO_OPE_BCO = "";
		m_COD_MODO_PLTO = "";
		m_IND_OPE_CDC = "";
		m_DAT_VIG_CDC = 0;
		m_IND_OPE_PRCI = "";
		m_DAT_VIG_PRCI = 0;
		m_DAT_VIG_PDA = 0;
		m_IND_OPE_GRNT_CHQ = "";
		m_IND_SIT_BCO = "";
		m_IND_SIT_BCO_ESTB = "";
		m_NOM_BCO_CMPL = "";
		m_TMS_INCL = 0;
		m_COD_STTU_REG = "";
		m_IND_OPE_PDA = "";
		m_DAT_VIG_GRNT_CHQ = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0047::TBSW0047( const std::string &str )
	{
		query_fields = "COD_BCO_CMPS, COD_INT_BCO, COD_MODO_OPE_BCO, COD_MODO_PLTO, IND_OPE_CDC, DAT_VIG_CDC, \
		IND_OPE_PRCI, DAT_VIG_PRCI, DAT_VIG_PDA, IND_OPE_GRNT_CHQ, IND_SIT_BCO, \
		IND_SIT_BCO_ESTB, NOM_BCO_CMPL, TMS_INCL, COD_STTU_REG, IND_OPE_PDA, DAT_VIG_GRNT_CHQ";
		table_name = "TBSW0047";
		where_condition = str;
		COD_BCO_CMPS_pos = 1;
		COD_INT_BCO_pos = 2;
		COD_MODO_OPE_BCO_pos = 3;
		COD_MODO_PLTO_pos = 4;
		IND_OPE_CDC_pos = 5;
		DAT_VIG_CDC_pos = 6;
		IND_OPE_PRCI_pos = 7;
		DAT_VIG_PRCI_pos = 8;
		DAT_VIG_PDA_pos = 9;
		IND_OPE_GRNT_CHQ_pos = 10;
		IND_SIT_BCO_pos = 11;
		IND_SIT_BCO_ESTB_pos = 12;
		NOM_BCO_CMPL_pos = 13;
		TMS_INCL_pos = 14;
		COD_STTU_REG_pos = 15;
		IND_OPE_PDA_pos = 16;
		DAT_VIG_GRNT_CHQ_pos = 17;
		m_COD_BCO_CMPS = 0;
		m_COD_INT_BCO = 0;
		m_COD_MODO_OPE_BCO = "";
		m_COD_MODO_PLTO = "";
		m_IND_OPE_CDC = "";
		m_DAT_VIG_CDC = 0;
		m_IND_OPE_PRCI = "";
		m_DAT_VIG_PRCI = 0;
		m_DAT_VIG_PDA = 0;
		m_IND_OPE_GRNT_CHQ = "";
		m_IND_SIT_BCO = "";
		m_IND_SIT_BCO_ESTB = "";
		m_NOM_BCO_CMPL = "";
		m_TMS_INCL = 0;
		m_COD_STTU_REG = "";
		m_IND_OPE_PDA = "";
		m_DAT_VIG_GRNT_CHQ = 0;

        update_database_id(dbaccess::endpoint::DB_CAPTURA);
	}
	TBSW0047::~TBSW0047( )
	{
	}
	long TBSW0047::getCOD_BCO_CMPS( ) const
	{
		return m_COD_BCO_CMPS;
	}
	long TBSW0047::getCOD_INT_BCO( ) const
	{
		return m_COD_INT_BCO;
	}
	const std::string& TBSW0047::getCOD_MODO_OPE_BCO( ) const
	{
		return m_COD_MODO_OPE_BCO;
	}
	const std::string& TBSW0047::getCOD_MODO_PLTO( ) const
	{
		return m_COD_MODO_PLTO;
	}
	const std::string& TBSW0047::getIND_OPE_CDC( ) const
	{
		return m_IND_OPE_CDC;
	}
	dbm_datetime_t TBSW0047::getDAT_VIG_CDC( ) const
	{
		return m_DAT_VIG_CDC;
	}
	const std::string& TBSW0047::getIND_OPE_PRCI( ) const
	{
		return m_IND_OPE_PRCI;
	}
	dbm_datetime_t TBSW0047::getDAT_VIG_PRCI( ) const
	{
		return m_DAT_VIG_PRCI;
	}
	dbm_datetime_t TBSW0047::getDAT_VIG_PDA( ) const
	{
		return m_DAT_VIG_PDA;
	}
	const std::string& TBSW0047::getIND_OPE_GRNT_CHQ( ) const
	{
		return m_IND_OPE_GRNT_CHQ;
	}
	const std::string& TBSW0047::getIND_SIT_BCO( ) const
	{
		return m_IND_SIT_BCO;
	}
	const std::string& TBSW0047::getIND_SIT_BCO_ESTB( ) const
	{
		return m_IND_SIT_BCO_ESTB;
	}
	const std::string& TBSW0047::getNOM_BCO_CMPL( ) const
	{
		return m_NOM_BCO_CMPL;
	}
	dbm_datetime_t TBSW0047::getTMS_INCL( ) const
	{
		return m_TMS_INCL;
	}
	const std::string& TBSW0047::getCOD_STTU_REG( ) const
	{
		return m_COD_STTU_REG;
	}
	const std::string& TBSW0047::getIND_OPE_PDA( ) const
	{
		return m_IND_OPE_PDA;
	}
	dbm_datetime_t TBSW0047::getDAT_VIG_GRNT_CHQ( ) const
	{
		return m_DAT_VIG_GRNT_CHQ;
	}
	void TBSW0047::setCOD_BCO_CMPS( long a_COD_BCO_CMPS )
	{
		m_COD_BCO_CMPS = a_COD_BCO_CMPS;
	}
	void TBSW0047::setCOD_INT_BCO( long a_COD_INT_BCO )
	{
		m_COD_INT_BCO = a_COD_INT_BCO;
	}
	void TBSW0047::setCOD_MODO_OPE_BCO( const std::string& a_COD_MODO_OPE_BCO )
	{
		m_COD_MODO_OPE_BCO = a_COD_MODO_OPE_BCO;
	}
	void TBSW0047::setCOD_MODO_PLTO( const std::string& a_COD_MODO_PLTO )
	{
		m_COD_MODO_PLTO = a_COD_MODO_PLTO;
	}
	void TBSW0047::setIND_OPE_CDC( const std::string& a_IND_OPE_CDC )
	{
		m_IND_OPE_CDC = a_IND_OPE_CDC;
	}
	void TBSW0047::setDAT_VIG_CDC( dbm_datetime_t a_DAT_VIG_CDC )
	{
		m_DAT_VIG_CDC = a_DAT_VIG_CDC;
	}
	void TBSW0047::setIND_OPE_PRCI( const std::string& a_IND_OPE_PRCI )
	{
		m_IND_OPE_PRCI = a_IND_OPE_PRCI;
	}
	void TBSW0047::setDAT_VIG_PRCI( dbm_datetime_t a_DAT_VIG_PRCI )
	{
		m_DAT_VIG_PRCI = a_DAT_VIG_PRCI;
	}
	void TBSW0047::setDAT_VIG_PDA( dbm_datetime_t a_DAT_VIG_PDA )
	{
		m_DAT_VIG_PDA = a_DAT_VIG_PDA;
	}
	void TBSW0047::setIND_OPE_GRNT_CHQ( const std::string& a_IND_OPE_GRNT_CHQ )
	{
		m_IND_OPE_GRNT_CHQ = a_IND_OPE_GRNT_CHQ;
	}
	void TBSW0047::setIND_SIT_BCO( const std::string& a_IND_SIT_BCO )
	{
		m_IND_SIT_BCO = a_IND_SIT_BCO;
	}
	void TBSW0047::setIND_SIT_BCO_ESTB( const std::string& a_IND_SIT_BCO_ESTB )
	{
		m_IND_SIT_BCO_ESTB = a_IND_SIT_BCO_ESTB;
	}
	void TBSW0047::setNOM_BCO_CMPL( const std::string& a_NOM_BCO_CMPL )
	{
		m_NOM_BCO_CMPL = a_NOM_BCO_CMPL;
	}
	void TBSW0047::setTMS_INCL( dbm_datetime_t a_TMS_INCL )
	{
		m_TMS_INCL = a_TMS_INCL;
	}
	void TBSW0047::setCOD_STTU_REG( const std::string& a_COD_STTU_REG )
	{
		m_COD_STTU_REG = a_COD_STTU_REG;
	}
	void TBSW0047::setIND_OPE_PDA( const std::string& a_NOM_BCO_CMPL )
	{
		m_NOM_BCO_CMPL = a_NOM_BCO_CMPL;
	}
	void TBSW0047::setDAT_VIG_GRNT_CHQ( dbm_datetime_t a_TMS_INCL )
	{
		m_TMS_INCL = a_TMS_INCL;
	}
	void TBSW0047::bind_columns( )
	{
		bind( COD_BCO_CMPS_pos, m_COD_BCO_CMPS );
		bind( COD_INT_BCO_pos, m_COD_INT_BCO );
		bind( COD_MODO_OPE_BCO_pos, m_COD_MODO_OPE_BCO );
		bind( COD_MODO_PLTO_pos, m_COD_MODO_PLTO );
		bind( IND_OPE_CDC_pos, m_IND_OPE_CDC );
		bind( DAT_VIG_CDC_pos, &m_DAT_VIG_CDC );
		bind( IND_OPE_PRCI_pos, m_IND_OPE_PRCI );
		bind( DAT_VIG_PRCI_pos, &m_DAT_VIG_PRCI );
		bind( DAT_VIG_PDA_pos, &m_DAT_VIG_PDA );
		bind( IND_OPE_GRNT_CHQ_pos, m_IND_OPE_GRNT_CHQ );
		bind( IND_SIT_BCO_pos, m_IND_SIT_BCO );
		bind( IND_SIT_BCO_ESTB_pos, m_IND_SIT_BCO_ESTB );
		bind( NOM_BCO_CMPL_pos, m_NOM_BCO_CMPL );
		bind( TMS_INCL_pos, &m_TMS_INCL );
		bind( COD_STTU_REG_pos, m_COD_STTU_REG );
		bind( IND_OPE_PDA_pos, m_IND_OPE_PDA );
		bind( DAT_VIG_GRNT_CHQ_pos, &m_DAT_VIG_GRNT_CHQ );
	}
}//namespace dbaccess_common

