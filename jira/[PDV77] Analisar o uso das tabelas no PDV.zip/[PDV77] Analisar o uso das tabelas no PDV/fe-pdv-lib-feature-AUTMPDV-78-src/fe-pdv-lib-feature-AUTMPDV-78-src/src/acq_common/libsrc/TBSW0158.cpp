#include "TBSW0158.hpp"

namespace dbaccess_pos
{

TBSW0158::TBSW0158()
{
	initialize();

	where_condition = "";
        update_database_id(dbaccess::endpoint::DB_CAPTURA);

	// Teste de conteudo do registro
	m_log = logger::DebugWriter::getInstance();
}

TBSW0158::TBSW0158( const std::string& whereClause )
{
        initialize();

        where_condition = whereClause;
        update_database_id(dbaccess::endpoint::DB_CAPTURA);

        // Teste de conteudo do registro
        m_log = logger::DebugWriter::getInstance();
}

TBSW0158::~TBSW0158()
{
}


void TBSW0158::bind_columns()
{
	bind( m_COD_EMP_ADQT_pos,	m_COD_EMP_ADQT );
        bind( m_NUM_PDV_pos,		m_NUM_PDV );
        bind( m_NUM_PDV_EXT_pos,	m_NUM_PDV_EXT );
        bind( m_NUM_PDV_VAN_pos,	m_NUM_PDV_VAN );
        bind( m_COD_SIT_PDV_EXT_pos,	m_COD_SIT_PDV_EXT );
        bind( m_DAT_ATLZ_REG_pos,	&m_DAT_ATLZ_REG );

}

void TBSW0158::initialize()
{
	query_fields = "COD_EMP_ADQT, NUM_PDV, NUM_PDV_EXT, NUM_PDV_VAN, COD_SIT_PDV_EXT, DAT_ATLZ_REG";

        table_name = "TBSW0158";

        m_COD_EMP_ADQT_pos	= 1;
        m_NUM_PDV_pos		= 2;
        m_NUM_PDV_EXT_pos	= 3;
        m_NUM_PDV_VAN_pos	= 4;
        m_COD_SIT_PDV_EXT_pos	= 5;
        m_DAT_ATLZ_REG_pos	= 6;

        m_COD_EMP_ADQT		= 0;
        m_NUM_PDV		= 0;
        m_NUM_PDV_EXT		= " ";
        m_NUM_PDV_VAN		= " ";
        m_COD_SIT_PDV_EXT	= " ";
        m_DAT_ATLZ_REG		= 0;

}


void TBSW0158::set_COD_EMP_ADQT( unsigned long a_COD_EMP_ADQT )
{
	m_COD_EMP_ADQT = a_COD_EMP_ADQT;
}

void TBSW0158::set_NUM_PDV( unsigned long a_NUM_PDV )
{
	m_NUM_PDV = a_NUM_PDV;
}

void TBSW0158::set_NUM_PDV_EXT( const std::string& a_NUM_PDV_EXT )
{
	m_NUM_PDV_EXT = a_NUM_PDV_EXT;
}

void TBSW0158::set_NUM_PDV_VAN( const std::string& a_NUM_PDV_VAN )
{
	m_NUM_PDV_VAN = a_NUM_PDV_VAN;
}

void TBSW0158::set_COD_SIT_PDV_EXT( const std::string& a_COD_SIT_PDV_EXT )
{
	m_COD_SIT_PDV_EXT = a_COD_SIT_PDV_EXT;
}

void TBSW0158::set_DAT_ATLZ_REG( dbm_datetime_t  a_DAT_ATLZ_REG )
{
	m_DAT_ATLZ_REG = a_DAT_ATLZ_REG;
}


unsigned long TBSW0158::get_COD_EMP_ADQT() const
{
	return m_COD_EMP_ADQT;
}

unsigned long TBSW0158::get_NUM_PDV() const
{
	return m_NUM_PDV;
}

const std::string TBSW0158::get_NUM_PDV_EXT() const
{
	return m_NUM_PDV_EXT;
}

const std::string TBSW0158::get_NUM_PDV_VAN() const
{
	return m_NUM_PDV_VAN;
}

const std::string TBSW0158::get_COD_SIT_PDV_EXT() const
{
	return m_COD_SIT_PDV_EXT;
}

dbm_datetime_t TBSW0158::get_DAT_ATLZ_REG() const
{
	return m_DAT_ATLZ_REG;
}

} //namespace dbaccess_pos

