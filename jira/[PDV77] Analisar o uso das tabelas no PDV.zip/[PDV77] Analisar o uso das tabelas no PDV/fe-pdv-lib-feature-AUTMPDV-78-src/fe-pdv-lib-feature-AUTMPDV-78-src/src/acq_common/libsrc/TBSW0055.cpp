#include "TBSW0055.hpp"

namespace dbaccess_common
{
    TBSW0055::TBSW0055()
    {
        query_fields = init_query_fields().c_str();

        table_name = "TBSW0055";

        init_var();

        update_database_id(dbaccess::endpoint::DB_CAPTURA);

        where_condition = "";
    }

    TBSW0055::TBSW0055( const std::string& whereClause )
    {
        query_fields = init_query_fields().c_str();

        table_name = "TBSW0055";

        init_var();

        update_database_id(dbaccess::endpoint::DB_CAPTURA);

        where_condition = whereClause;
    }

    TBSW0055::~TBSW0055()
    {
    }

    void TBSW0055::init_var( )
    {
        m_COD_UCAF = " ";
        dbm_longtodec( &m_NUM_DSTR_CMC_ELET, 0 );
        m_NOM_PORT_CAR = "";
        m_DAT_MOV_TRAN = 0;
        m_NUM_SEQ_UNC = 0;
        m_COD_USR_CMC_ELET = " ";
        m_NUM_PDDO_CMC_ELET = " ";
        m_TXT_CMPM_ENDR_PORT = "";
        m_NOM_FNTS_PDV = " ";
        m_COD_ID_DTCH = " ";
        m_IND_PGMN_RECRRN = 0;
        m_VAL_SCO_FRUD = 0;
        m_COD_PGM_AUT = " ";
        m_IND_NVL_SGRA_KMRC = " ";
        /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
        tipoOrigemWeb = 1;
        // ID_184816 - AMEX FULL - R2_2017 - CAPTURA
        indicadorCompraEletronica = " ";

        // ID204705 - Release de bandeiras Outubro-2017 - INICIO
        codigoNivelSeguranca = " ";
        codigoNivelSegurancaOriginal = " ";
        indicadorCredencialArmazenado = "0";
        // ID204705 - Release de bandeiras Outubro-2017 - FIM
        // R10_2018 - Release Outubro - INICIO
        programProtocol = "";
        directoryServer = "";
        protocolValidationResult = "";
        // R10_2018 - Release Outubro - FIM
        // AUT1-2517 - 2021/J01 - INICIO
        walletID = "";
        // AUT1-2517 - 2021/J01 - FIM
    }

    std::string TBSW0055::init_query_fields()
    {
        std::string query_fields = "COD_UCAF, NUM_DSTR_CMC_ELET, NOM_PORT_CAR, DAT_MOV_TRAN, NUM_SEQ_UNC, COD_USR_CMC_ELET, NUM_PDDO_CMC_ELET, TXT_CMPM_ENDR_PORT, NOM_FNTS_PDV, COD_ID_DTCH, IND_PGMN_RECRRN, VAL_SCO_FRUD, COD_PGM_AUT, IND_NVL_SGRA_KMRC";
        /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
        query_fields += ",COD_TIP_ORG_TRAN_WEB, TIP_ATTC_CMC_ELET";
        
        // ID204705 - Release de bandeiras Outubro-2017 - INICIO
        query_fields += ", COD_NVL_SGRA, COD_NVL_SGRA_ORGL, IND_DA_TIT_CAR_AMZT";
        // ID204705 - Release de bandeiras Outubro-2017 - FIM
        
        // R10_2018 - Release Outubro - INICIO 
        query_fields += ", ID_VERS_PRTO_SGRA, COD_HASH_PRTO_SGRA, COD_VLDC_ATTC_PRTO_SGRA";
        // R10_2018 - Release Outubro - FIM

        // AUT1-2517 - 2021/J01 - INICIO
        query_fields += ", COD_ID_CART_DGTL";
        // AUT1-2517 - 2021/J01 - FIM
        return query_fields;
    }

    void TBSW0055::bind_columns()
    {
        bind( m_COD_UCAF_pos, m_COD_UCAF );
        bind( m_NUM_DSTR_CMC_ELET_pos, m_NUM_DSTR_CMC_ELET );
        bind( m_NOM_PORT_CAR_pos, m_NOM_PORT_CAR );
        bind( m_DAT_MOV_TRAN_pos, m_DAT_MOV_TRAN );
        bind( m_NUM_SEQ_UNC_pos, m_NUM_SEQ_UNC );
        bind( m_COD_USR_CMC_ELET_pos, m_COD_USR_CMC_ELET );
        bind( m_NUM_PDDO_CMC_ELET_pos, m_NUM_PDDO_CMC_ELET );
        bind( m_TXT_CMPM_ENDR_PORT_pos, m_TXT_CMPM_ENDR_PORT );
        bind( m_NOM_FNTS_PDV_pos, m_NOM_FNTS_PDV );
        bind( m_COD_ID_DTCH_pos, m_COD_ID_DTCH );
        bind( m_IND_PGMN_RECRRN_pos, m_IND_PGMN_RECRRN );
        bind( m_VAL_SCO_FRUD_pos, m_VAL_SCO_FRUD );
        bind( m_COD_PGM_AUT_pos, m_COD_PGM_AUT );
        bind( m_IND_NVL_SGRA_KMRC_pos, m_IND_NVL_SGRA_KMRC );
        /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
        bind( tipoOrigemWebPos, tipoOrigemWeb );
        // ID_184816 - AMEX FULL - R2_2017 - CAPTURA
        bind( indicadorCompraEletronicaPos, indicadorCompraEletronica );
        // ID204705 - Release de bandeiras Outubro-2017 - INICIO
        bind( codigoNivelSegurancaPosicao, codigoNivelSeguranca );
        bind( codigoNivelSegurancaOriginalPosicao, codigoNivelSegurancaOriginal );
        bind( indicadorCredencialArmazenadoPosicao, indicadorCredencialArmazenado );
        // ID204705 - Release de bandeiras Outubro-2017 - FIM
        // R10_2018 - Release Outubro - INICIO 
        bind( programProtocolPosicao, programProtocol );
        bind( directoryServerPosicao, directoryServer );
        bind( protocolValidationResultPosicao, protocolValidationResult );
        // R10_2018 - Release Outubro - FIM
        // AUT1-2517 - 2021/J01 - INICIO
        bind( walletIDPosicao, walletID);
        // AUT1-2517 - 2021/J01 - FIM
    }
    
    //sets
    void TBSW0055::set_COD_UCAF( const std::string& a_COD_UCAF )
    {
        m_COD_UCAF = a_COD_UCAF;
    }
    void TBSW0055::set_NUM_DSTR_CMC_ELET( oasis_dec_t a_NUM_DSTR_CMC_ELET )
    {
        dbm_deccopy( &m_NUM_DSTR_CMC_ELET, &a_NUM_DSTR_CMC_ELET );
    }
    void TBSW0055::set_NOM_PORT_CAR( const std::string& a_NOM_PORT_CAR )
    {
        m_NOM_PORT_CAR = a_NOM_PORT_CAR;
    }
    void TBSW0055::set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN )
    {
        m_DAT_MOV_TRAN = a_DAT_MOV_TRAN;
    }
    void TBSW0055::set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC )
    {
        m_NUM_SEQ_UNC = a_NUM_SEQ_UNC;
    }
    void TBSW0055::set_COD_USR_CMC_ELET( const std::string& a_COD_USR_CMC_ELET )
    {
        m_COD_USR_CMC_ELET = a_COD_USR_CMC_ELET;
    }
    void TBSW0055::set_NUM_PDDO_CMC_ELET( const std::string& a_NUM_PDDO_CMC_ELET )
    {
        m_NUM_PDDO_CMC_ELET = a_NUM_PDDO_CMC_ELET;
    }
    void TBSW0055::set_TXT_CMPM_ENDR_PORT( const std::string& a_TXT_CMPM_ENDR_PORT )
    {
        m_TXT_CMPM_ENDR_PORT = a_TXT_CMPM_ENDR_PORT;
    }
    void TBSW0055::set_NOM_FNTS_PDV( const std::string& a_NOM_FNTS_PDV )
    {
        m_NOM_FNTS_PDV = a_NOM_FNTS_PDV;
    }
    void TBSW0055::set_COD_ID_DTCH( const std::string& a_COD_ID_DTCH )
    {
        m_COD_ID_DTCH = a_COD_ID_DTCH;
    }
    void TBSW0055::set_IND_PGMN_RECRRN( unsigned long a_IND_PGMN_RECRRN )
    {
        m_IND_PGMN_RECRRN = a_IND_PGMN_RECRRN;
    }
    void TBSW0055::set_VAL_SCO_FRUD( int a_VAL_SCO_FRUD )
    {
        m_VAL_SCO_FRUD = a_VAL_SCO_FRUD;
    }
    void TBSW0055::set_COD_PGM_AUT( const std::string& a_COD_PGM_AUT )
    {
        m_COD_PGM_AUT = a_COD_PGM_AUT;
    }
    void TBSW0055::set_IND_NVL_SGRA_KMRC( const std::string& a_IND_NVL_SGRA_KMRC )
    {
        m_IND_NVL_SGRA_KMRC = a_IND_NVL_SGRA_KMRC;
    }
    
    /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
    /// SetTipoOrigemWeb
    /// Atribui novo valor ao campo COD_TIP_ORG_TRAN_WEB
    /// EF/ET : ET8
    /// Historico: [Data] - ET - Descricao
    /// 20/10/2014 - ET8 - Criacao da versao inicial
    /// parameterValue: Valor a ser atribuido ao campo COD_TIP_ORG_TRAN_WEB
    void TBSW0055::SetTipoOrigemWeb( int parameterValue )
    {
        tipoOrigemWeb = parameterValue;
    }
    
    
    // ID204705 - Release de bandeiras Outubro-2017 - INICIO
    /// SetCodigoNivelSeguranca
    /// Atribui valor ao atributo da classe
    /// EF/ET: 204705
    /// Historico: [Data] - ET - Descriзгo
    /// 10/08/2017 - 204705 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void TBSW0055::SetCodigoNivelSeguranca( const std::string& value )
    {
        codigoNivelSeguranca = value;
    }
    // ID204705 - Release de bandeiras Outubro-2017 - FIM

    // ID204705 - Release de bandeiras Outubro-2017 - INICIO
    /// SetCodigoNivelSegurancaOriginal
    /// Atribui valor ao atributo da classe
    /// EF/ET: 204705
    /// Historico: [Data] - ET - Descriзгo
    /// 10/08/2017 - 204705 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void TBSW0055::SetCodigoNivelSegurancaOriginal( const std::string& value )
    {
        codigoNivelSegurancaOriginal = value;
    }
    // ID204705 - Release de bandeiras Outubro-2017 - FIM

    // ID204705 - Release de bandeiras Outubro-2017 - INICIO
    /// SetIndicadorCredencialArmazenado
    /// Atribui valor ao atributo da classe
    /// EF/ET: 204705
    /// Historico: [Data] - ET - Descriзгo
    /// 10/08/2017 - 204705 - Criacao da versao inicial
    /// value: Valor a ser atribuido
    void TBSW0055::SetIndicadorCredencialArmazenado( const std::string& value )
    {
        indicadorCredencialArmazenado = value;
    }
    // ID204705 - Release de bandeiras Outubro-2017 - FIM

    // R10_2018 - Release Outubro - INICIO 
    /// SetProgramProtocol
    /// Atribui novo valor ao campo ID_VERS_PRTO_SGRA
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 22/08/2018 - ET1 - Release Outubro 2018
    /// value: Valor a ser atribuido ao campo ID_VERS_PRTO_SGRA
    void TBSW0055::SetProgramProtocol(const std::string& value)
    {
        programProtocol = value;
    }
    // R10_2018 - Release Outubro - FIM

    // R10_2018 - Release Outubro - INICIO 
    /// SetDirectoryServer
    /// Atribui novo valor ao campo COD_HASH_PRTO_SGRA
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 22/08/2018 - ET1 - Release Outubro 2018
    /// value: Valor a ser atribuido ao campo COD_HASH_PRTO_SGRA
    void TBSW0055::SetDirectoryServer(const std::string& value)
    {
        directoryServer = value;
    }
    // R10_2018 - Release Outubro - FIM
    
    // R10_2018 - Release Outubro - INICIO 
    /// SetProtocolValidationResult
    /// Atribui novo valor ao campo COD_VLDC_ATTC_PRTO_SGRA
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 22/08/2018 - ET1 - Release Outubro 2018
    /// value: Valor a ser atribuido ao campo COD_VLDC_ATTC_PRTO_SGRA
    void TBSW0055::SetProtocolValidationResult(const std::string& value)
    {
        protocolValidationResult = value;
    }
    // R10_2018 - Release Outubro - FIM

    // AUT1-2517 - 2021/J01 - INICIO
    /// SetWalletID
    /// Atribui novo valor do campo COD_ID_CART_DGTL
    void TBSW0055::SetWalletID(const std::string& value)
    {
        walletID = value;
    }
    // AUT1-2517 - 2021/J01 - FIM

    //gets
    const std::string& TBSW0055::get_COD_UCAF() const
    {
        return m_COD_UCAF;
    }
    oasis_dec_t TBSW0055::get_NUM_DSTR_CMC_ELET() const
    {
        return m_NUM_DSTR_CMC_ELET;
    }
    const std::string& TBSW0055::get_NOM_PORT_CAR() const
    {
        return m_NOM_PORT_CAR;
    }
    unsigned long TBSW0055::get_DAT_MOV_TRAN() const
    {
        return m_DAT_MOV_TRAN;
    }
    unsigned long TBSW0055::get_NUM_SEQ_UNC() const
    {
        return m_NUM_SEQ_UNC;
    }
    const std::string& TBSW0055::get_COD_USR_CMC_ELET() const
    {
        return m_COD_USR_CMC_ELET;
    }
    const std::string& TBSW0055::get_NUM_PDDO_CMC_ELET() const
    {
        return m_NUM_PDDO_CMC_ELET;
    }
    const std::string& TBSW0055::get_TXT_CMPM_ENDR_PORT() const
    {
        return m_TXT_CMPM_ENDR_PORT;
    }
    const std::string& TBSW0055::get_NOM_FNTS_PDV() const
    {
        return m_NOM_FNTS_PDV;
    }
    const std::string& TBSW0055::get_COD_ID_DTCH() const
    {
        return m_COD_ID_DTCH;
    }
    unsigned long TBSW0055::get_IND_PGMN_RECRRN() const
    {
        return m_IND_PGMN_RECRRN;
    }
    int TBSW0055::get_VAL_SCO_FRUD() const
    {
        return m_VAL_SCO_FRUD;
    }
    const std::string& TBSW0055::get_COD_PGM_AUT() const
    {
        return m_COD_PGM_AUT;
    }
    const std::string& TBSW0055::get_IND_NVL_SGRA_KMRC() const
    {
        return m_IND_NVL_SGRA_KMRC;
    }
    
    /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
    /// GetTipoOrigemWeb
    /// Retorna valor do campo COD_TIP_ORG_TRAN_WEB
    /// EF/ET : ET8
    /// Historico: [Data] - ET - Descricao
    /// 20/10/2014 - ET8 - Criacao da versao inicial
    int TBSW0055::GetTipoOrigemWeb() const
    {
        return tipoOrigemWeb;
    }
    
    // ID204705 - Release de bandeiras Outubro-2017 - INICIO
    /// GetCodigoNivelSeguranca
    /// Obtem valor ao atributo da classe
    /// EF/ET: 204705
    /// Historico: [Data] - ET - Descriзгo
    /// 10/08/2017 - 204705 - Criacao da versao inicial
    const std::string& TBSW0055::GetCodigoNivelSeguranca() const
    {
        return codigoNivelSeguranca;
    }
    // ID204705 - Release de bandeiras Outubro-2017 - FIM

    // ID204705 - Release de bandeiras Outubro-2017 - INICIO
    /// GetCodigoNivelSegurancaOriginal
    /// Obtem valor ao atributo da classe
    /// EF/ET: 204705
    /// Historico: [Data] - ET - Descriзгo
    /// 10/08/2017 - 204705 - Criacao da versao inicial
    const std::string& TBSW0055::GetCodigoNivelSegurancaOriginal() const
    {
        return codigoNivelSegurancaOriginal;
    }
    // ID204705 - Release de bandeiras Outubro-2017 - FIM

    // ID204705 - Release de bandeiras Outubro-2017 - INICIO
    /// GetIndicadorCredencialArmazenado
    /// Obtem valor ao atributo da classe
    /// EF/ET: 204705
    /// Historico: [Data] - ET - Descriзгo
    /// 10/08/2017 - 204705 - Criacao da versao inicial
    /// 24/09/2018 - Andre Morishita - ET2 - R10_2018 - Release Outubro
    const std::string& TBSW0055::GetIndicadorCredencialArmazenado() const
    {
        return indicadorCredencialArmazenado;
    }
    // ID204705 - Release de bandeiras Outubro-2017 - FIM
    

    // ID_184816 - AMEX FULL - R2_2017 - CAPTURA - INICIO
    /// SetIndicadorCompraEletronica
    /// Atribui novo valor ao campo TIP_ATTC_CMC_ELET
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 18/01/2017 - ET - AMEX FULL
    /// value: Valor a ser atribuido ao campo TIP_ATTC_CMC_ELET
    void TBSW0055::SetIndicadorCompraEletronica( const std::string& value )
    {
        indicadorCompraEletronica = value;
    }
    /// GetIndicadorCompraEletronica
    /// Atribui novo valor ao campo TIP_ATTC_CMC_ELET
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 18/01/2017 - ET - AMEX FULL
    const std::string& TBSW0055::GetIndicadorCompraEletronica() const
    {
        return indicadorCompraEletronica;
    }
    // ID_184816 - AMEX FULL - R2_2017 - CAPTURA - FIM
    
    // R10_2018 - Release Outubro - INICIO 
    /// GetProgramProtocol
    /// Obtem valor do campo ID_VERS_PRTO_SGRA
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 22/08/2018 - ET1 - Release Outubro 2018
    const std::string& TBSW0055::GetProgramProtocol() const
    {
        return programProtocol;
    }
    // R10_2018 - Release Outubro - FIM

    // R10_2018 - Release Outubro - INICIO 
    /// GetDirectoryServer
    /// Obtem valor do campo COD_HASH_PRTO_SGRA
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 22/08/2018 - ET1 - Release Outubro 2018
    const std::string& TBSW0055::GetDirectoryServer() const
    {
        return directoryServer;
    }
    // R10_2018 - Release Outubro - FIM
    
    // R10_2018 - Release Outubro - INICIO 
    /// GetProtocolValidationResult
    /// Obtem valor do campo COD_VLDC_ATTC_PRTO_SGRA
    /// EF/ET : ET1
    /// Historico: [Data] - ET - Descricao
    /// 22/08/2018 - ET1 - Release Outubro 2018
    const std::string& TBSW0055::GetProtocolValidationResult() const
    {
        return protocolValidationResult;
    }
    // R10_2018 - Release Outubro - FIM

    // AUT1-2517 - 2021/J01 - INICIO
    /// GetWalletID
    /// Obtem valor do campo COD_ID_CART_DGTL
    const std::string& TBSW0055::GetWalletID() const
    {
        return walletID;
    }
    // AUT1-2517 - 2021/J01 - FIM

} //namespace dbaccess_common
