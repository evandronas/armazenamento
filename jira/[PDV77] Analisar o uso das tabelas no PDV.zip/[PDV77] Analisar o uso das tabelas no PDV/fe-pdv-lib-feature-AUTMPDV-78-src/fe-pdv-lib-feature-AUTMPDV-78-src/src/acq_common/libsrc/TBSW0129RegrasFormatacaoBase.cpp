#include<TBSW0129RegrasFormatacaoBase.hpp>

TBSW0129RegrasFormatacaoBase::TBSW0129RegrasFormatacaoBase( )
{
    m_log = logger::DebugWriter::getInstance( );
}

TBSW0129RegrasFormatacaoBase::~TBSW0129RegrasFormatacaoBase( )
{
}

void TBSW0129RegrasFormatacaoBase::DAT_MOV_TRAN( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DAT_MOV_TRAN( tbsw0129, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DAT_MOV_TRAN( tbsw0129, params );
    }
}

void TBSW0129RegrasFormatacaoBase::NUM_SEQ_UNC( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_SEQ_UNC( tbsw0129, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_SEQ_UNC( tbsw0129, params );
    }
}

void TBSW0129RegrasFormatacaoBase::DTH_INI_TRAN( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_DTH_INI_TRAN( tbsw0129, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_DTH_INI_TRAN( tbsw0129, params );
    }
}

void TBSW0129RegrasFormatacaoBase::COD_TERM( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_COD_TERM( tbsw0129, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_COD_TERM( tbsw0129, params );
    }
}

void TBSW0129RegrasFormatacaoBase::NUM_ESTB( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NUM_ESTB( tbsw0129, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NUM_ESTB( tbsw0129, params );
    }
}

void TBSW0129RegrasFormatacaoBase::NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_SITE_ACQR_ORGL( tbsw0129, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_SITE_ACQR_ORGL( tbsw0129, params );
    }
}

void TBSW0129RegrasFormatacaoBase::NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_HOST_ACQR_ORGL( tbsw0129, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_HOST_ACQR_ORGL( tbsw0129, params );
    }
}

void TBSW0129RegrasFormatacaoBase::NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao )
{
    if( operacao == acq_common::INSERT )
    {
        insert_NOM_FE_ACQR_ORGL( tbsw0129, params );
    }
    else if( operacao == acq_common::UPDATE )
    {
        update_NOM_FE_ACQR_ORGL( tbsw0129, params );
    }
}

// Metodos utilizados por campos que tem input generico (INSERT/UPDATE)

void TBSW0129RegrasFormatacaoBase::gen_DAT_MOV_TRAN( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::gen_NUM_SEQ_UNC( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::gen_DTH_INI_TRAN( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::gen_COD_TERM( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::gen_NUM_ESTB( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::gen_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::gen_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::gen_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

// Metodos especificos para INSERT

void TBSW0129RegrasFormatacaoBase::insert_DAT_MOV_TRAN( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    tbsw0129.set_DAT_MOV_TRAN( params.local_date );
}

void TBSW0129RegrasFormatacaoBase::insert_NUM_SEQ_UNC( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    oasis_dec_t l_dect;
    dbm_longtodec( &l_dect, params.refnum );
    tbsw0129.set_NUM_SEQ_UNC( l_dect );
}

void TBSW0129RegrasFormatacaoBase::insert_DTH_INI_TRAN( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    tbsw0129.set_DTH_INI_TRAN( AcqUtils::dateTime( params.local_date, params.local_time ) );
}

void TBSW0129RegrasFormatacaoBase::insert_COD_TERM( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    if( params.termid.size( ) != 0 )
    {
        tbsw0129.set_COD_TERM( params.termid );
    }
    else
    {
        tbsw0129.set_COD_TERM( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0129RegrasFormatacaoBase::insert_NUM_ESTB( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    tbsw0129.set_NUM_ESTB( params.termloc );
}

void TBSW0129RegrasFormatacaoBase::insert_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    if( params.nom_site_acqr.size() != 0 )
    {
        tbsw0129.set_NOM_SITE_ACQR_ORGL( params.nom_site_acqr );
    }
    else
    {
        tbsw0129.set_NOM_SITE_ACQR_ORGL( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0129RegrasFormatacaoBase::insert_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    if( params.nom_host_acqr.size() != 0 )
    {
        tbsw0129.set_NOM_HOST_ACQR_ORGL( params.nom_host_acqr );
    }
    else
    {
        tbsw0129.set_NOM_HOST_ACQR_ORGL( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

void TBSW0129RegrasFormatacaoBase::insert_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    if( params.nom_fe_acqr.size() != 0 )
    {
        tbsw0129.set_NOM_FE_ACQR_ORGL( params.nom_fe_acqr );
    }
    else
    {
        tbsw0129.set_NOM_FE_ACQR_ORGL( std::string( " " ) );
        WARNING_EMPTY_STRING;
    }
}

// Metodos especificos para UPDATE

void TBSW0129RegrasFormatacaoBase::update_DAT_MOV_TRAN( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::update_NUM_SEQ_UNC( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::update_DTH_INI_TRAN( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::update_COD_TERM( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::update_NUM_ESTB( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::update_NOM_SITE_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::update_NOM_HOST_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}

void TBSW0129RegrasFormatacaoBase::update_NOM_FE_ACQR_ORGL( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params )
{
    WARNING_INVALID_FUNCTION;
}
