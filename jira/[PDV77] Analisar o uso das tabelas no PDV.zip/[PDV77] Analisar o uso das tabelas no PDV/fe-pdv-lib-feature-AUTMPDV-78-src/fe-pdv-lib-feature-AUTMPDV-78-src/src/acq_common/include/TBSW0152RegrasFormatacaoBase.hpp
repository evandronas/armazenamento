#pragma once

#include <string>
#include <DBM3.h> //oasis_dec_t
#include "TBSW0152.hpp"
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <AcqUtils.hpp>

class TBSW0152RegrasFormatacaoBase
{
    public:
        TBSW0152RegrasFormatacaoBase( );
        ~TBSW0152RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN           ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_CICL_CRNC_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_PRCL               ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void DAT_VCTO_PRMR_PRCL     ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_PRCL_ENTR          ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_PRCL               ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void PRCN_TX_JURO           ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void PRCN_TX_JURO_MES       ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void PRCN_TX_JURO_ANO       ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void PRCN_TX_JURO_MORA      ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_PRES_BRTO          ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_TX_EFTV            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_TX_MNSL            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params, const acq_common::OPERACAO &operacao );

        virtual void gen_DAT_MOV_TRAN           ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_NUM_SEQ_UNC            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_QTD_CICL_CRNC_PRMR_PRCL( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_QTD_PRCL               ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_DAT_VCTO_PRMR_PRCL     ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_VAL_PRCL_ENTR          ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_VAL_PRCL               ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_PRCN_TX_JURO           ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_PRCN_TX_JURO_MES       ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_PRCN_TX_JURO_ANO       ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_PRCN_TX_JURO_MORA      ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_VAL_PRES_BRTO          ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_VAL_TX_EFTV            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void gen_VAL_TX_MNSL            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );

        virtual void insert_DAT_MOV_TRAN            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_NUM_SEQ_UNC             ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_QTD_CICL_CRNC_PRMR_PRCL ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_QTD_PRCL                ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_DAT_VCTO_PRMR_PRCL      ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_VAL_PRCL_ENTR           ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_VAL_PRCL                ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_PRCN_TX_JURO            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_PRCN_TX_JURO_MES        ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_PRCN_TX_JURO_ANO        ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_PRCN_TX_JURO_MORA       ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_VAL_PRES_BRTO           ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_VAL_TX_EFTV             ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void insert_VAL_TX_MNSL             ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );

        virtual void update_DAT_MOV_TRAN            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_NUM_SEQ_UNC             ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_QTD_CICL_CRNC_PRMR_PRCL ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_QTD_PRCL                ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_DAT_VCTO_PRMR_PRCL      ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_VAL_PRCL_ENTR           ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_VAL_PRCL                ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_PRCN_TX_JURO            ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_PRCN_TX_JURO_MES        ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_PRCN_TX_JURO_ANO        ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_PRCN_TX_JURO_MORA       ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_VAL_PRES_BRTO           ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_VAL_TX_EFTV             ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );
        virtual void update_VAL_TX_MNSL             ( dbaccess_common::TBSW0152 &tbsw0152, const struct acq_common::tbsw0152_params &params );

        logger::DebugWriter *m_log;

};
