#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0150 : public dbaccess::table
    {
        public:
            TBSW0150( );
            TBSW0150( const std::string& whereClause );
            ~TBSW0150( );

            void initialize( );
            void bind_columns( );

            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            void set_COD_IATA_ETD( unsigned long a_COD_IATA_ETD );
            void set_TXT_DOC_PSSR_1( const std::string& a_TXT_DOC_PSSR_1 );
            void set_NOM_PSSR_1( const std::string& a_NOM_PSSR_1 );
            void set_TXT_DOC_PSSR_2( const std::string& a_TXT_DOC_PSSR_2 );
            void set_NOM_PSSR_2( const std::string& a_NOM_PSSR_2 );
            void set_TXT_DOC_PSSR_3( const std::string& a_TXT_DOC_PSSR_3 );
            void set_NOM_PSSR_3( const std::string& a_NOM_PSSR_3 );
            void set_TXT_DOC_PSSR_4( const std::string& a_TXT_DOC_PSSR_4 );
            void set_NOM_PSSR_4( const std::string& a_NOM_PSSR_4 );
            void set_TXT_DOC_PSSR_5( const std::string& a_TXT_DOC_PSSR_5 );
            void set_NOM_PSSR_5( const std::string& a_NOM_PSSR_5 );
            void set_VAL_TX_EMBQ( oasis_dec_t a_VAL_TX_EMBQ );

            unsigned long get_DAT_MOV_TRAN( ) const;
            oasis_dec_t get_NUM_SEQ_UNC( ) const;
            unsigned long get_COD_IATA_ETD( ) const;
            const std::string& get_TXT_DOC_PSSR_1( ) const;
            const std::string& get_NOM_PSSR_1( ) const;
            const std::string& get_TXT_DOC_PSSR_2( ) const;
            const std::string& get_NOM_PSSR_2( ) const;
            const std::string& get_TXT_DOC_PSSR_3( ) const;
            const std::string& get_NOM_PSSR_3( ) const;
            const std::string& get_TXT_DOC_PSSR_4( ) const;
            const std::string& get_NOM_PSSR_4( ) const;
            const std::string& get_TXT_DOC_PSSR_5( ) const;
            const std::string& get_NOM_PSSR_5( ) const;
            oasis_dec_t get_VAL_TX_EMBQ( ) const;

        private:
            unsigned long   m_DAT_MOV_TRAN;
            oasis_dec_t     m_NUM_SEQ_UNC;
            unsigned long   m_COD_IATA_ETD;
            std::string     m_TXT_DOC_PSSR_1;
            std::string     m_NOM_PSSR_1;
            std::string     m_TXT_DOC_PSSR_2;
            std::string     m_NOM_PSSR_2;
            std::string     m_TXT_DOC_PSSR_3;
            std::string     m_NOM_PSSR_3;
            std::string     m_TXT_DOC_PSSR_4;
            std::string     m_NOM_PSSR_4;
            std::string     m_TXT_DOC_PSSR_5;
            std::string     m_NOM_PSSR_5;
            oasis_dec_t     m_VAL_TX_EMBQ;

            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_COD_IATA_ETD_pos;
            int m_TXT_DOC_PSSR_1_pos;
            int m_NOM_PSSR_1_pos;
            int m_TXT_DOC_PSSR_2_pos;
            int m_NOM_PSSR_2_pos;
            int m_TXT_DOC_PSSR_3_pos;
            int m_NOM_PSSR_3_pos;
            int m_TXT_DOC_PSSR_4_pos;
            int m_NOM_PSSR_4_pos;
            int m_TXT_DOC_PSSR_5_pos;
            int m_NOM_PSSR_5_pos;
            int m_VAL_TX_EMBQ_pos;

    }; //class TBSW0150

} //namespace dbaccess_common
