#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0161 : public dbaccess::table
    {
        public:

            TBSW0161( );
            TBSW0161( const std::string& whereClause );            
            ~TBSW0161( );

            void setWhereClause( const std::string& whereClause );    
            void bind_columns( );

            void set_NUM_PDV( unsigned long a_NUM_PDV );
            void set_COD_BNDR_CORP( unsigned long a_COD_BNDR_CORP );
            void set_NUM_PDV_BNDR( const std::string& a_NUM_PDV_BNDR );
            void set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG );

            unsigned long get_NUM_PDV( ) const;
            unsigned long get_COD_BNDR_CORP( ) const;
            const std::string& get_NUM_PDV_BNDR( ) const;
            dbm_datetime_t get_DAT_ATLZ_REG( ) const;
            
        private:
            unsigned long m_NUM_PDV;
            unsigned long m_COD_BNDR_CORP;
            std::string m_NUM_PDV_BNDR;
            dbm_datetime_t m_DAT_ATLZ_REG;
            
            int m_NUM_PDV_pos;
            int m_COD_BNDR_CORP_pos;
            int m_NUM_PDV_BNDR_pos;
            int m_DAT_ATLZ_REG_pos;
            
            void initialize();
    };
} //namespace dbaccess_pdv


