#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0032 : public dbaccess::table
    {
        public:

            TBSW0032( );
            TBSW0032( const std::string& whereClause );
            ~TBSW0032( );
            
            void initialize( );
            void bind_columns( );
            void let_as_is( );
			
            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            void set_NUM_BCO_ESTB( unsigned long a_NUM_BCO_ESTB );
            void set_NUM_BCO_DEB( unsigned long a_NUM_BCO_DEB );
            void set_NUM_EMSR( unsigned long a_NUM_EMSR );
            void set_NUM_AGE_ESTB( oasis_dec_t a_NUM_AGE_ESTB );
            void set_COD_CTA_ESTB( const std::string& a_COD_CTA_ESTB );
            void set_COD_VD_BCO( const std::string& a_COD_VD_BCO );
            void set_VAL_SQUE( oasis_dec_t a_VAL_SQUE );
            void set_IND_CNFR_PSTV( const std::string& a_IND_CNFR_PSTV );
            void set_IND_IMPR_CPOM( const std::string& a_IND_IMPR_CPOM );
            void set_QTD_DIA_CRNC( unsigned long a_QTD_DIA_CRNC );
            void set_IND_CAR_MLTP( const std::string& a_IND_CAR_MLTP );        
            void set_VAL_LQDC( oasis_dec_t a_VAL_LQDC );
            void set_VAL_RPSS( oasis_dec_t a_VAL_RPSS );
            void set_TIP_RPSS_VAL( const std::string& a_TIP_RPSS_VAL );
            void set_VAL_RCD( oasis_dec_t a_VAL_RCD );
            void set_COD_RVDA_PROD_MTC( const std::string& a_COD_RVDA_PROD_MTC );
            
            unsigned long get_DAT_MOV_TRAN( ) const;
            oasis_dec_t get_NUM_SEQ_UNC( ) const;
            unsigned long get_NUM_BCO_ESTB( ) const;
            unsigned long get_NUM_BCO_DEB( ) const;
            unsigned long get_NUM_EMSR( ) const;
            oasis_dec_t get_NUM_AGE_ESTB( ) const;
            const std::string& get_COD_CTA_ESTB( ) const;
            const std::string& get_COD_VD_BCO( ) const;
            oasis_dec_t get_VAL_SQUE( ) const;
            const std::string& get_IND_CNFR_PSTV( ) const;
            const std::string& get_IND_IMPR_CPOM( ) const;
            unsigned long get_QTD_DIA_CRNC( ) const;
            const std::string& get_IND_CAR_MLTP( ) const;
            oasis_dec_t get_VAL_LQDC( ) const;
            oasis_dec_t get_VAL_RPSS( ) const;
            const std::string& get_TIP_RPSS_VAL( ) const;
            oasis_dec_t get_VAL_RCD( ) const;
            const std::string& get_COD_RVDA_PROD_MTC( ) const;

        private:
            
            unsigned long    m_DAT_MOV_TRAN;
            oasis_dec_t      m_NUM_SEQ_UNC;
            unsigned long    m_NUM_BCO_ESTB;
            unsigned long    m_NUM_BCO_DEB;
            unsigned long    m_NUM_EMSR;
            oasis_dec_t      m_NUM_AGE_ESTB;
            std::string      m_COD_CTA_ESTB;
            std::string      m_COD_VD_BCO;
            oasis_dec_t      m_VAL_SQUE;
            std::string      m_IND_CNFR_PSTV;
            std::string      m_IND_IMPR_CPOM;
            unsigned long    m_QTD_DIA_CRNC;
            std::string      m_IND_CAR_MLTP;
            oasis_dec_t      m_VAL_LQDC;
            oasis_dec_t      m_VAL_RPSS;
            std::string      m_TIP_RPSS_VAL;
            oasis_dec_t      m_VAL_RCD;
            std::string      m_COD_RVDA_PROD_MTC;
            
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_NUM_BCO_ESTB_pos;
            int m_NUM_BCO_DEB_pos;
            int m_NUM_EMSR_pos;
            int m_NUM_AGE_ESTB_pos;
            int m_COD_CTA_ESTB_pos;
            int m_COD_VD_BCO_pos;
            int m_VAL_SQUE_pos;
            int m_IND_CNFR_PSTV_pos;
            int m_IND_IMPR_CPOM_pos;
            int m_QTD_DIA_CRNC_pos;
            int m_IND_CAR_MLTP_pos;
            int m_VAL_LQDC_pos;
            int m_VAL_RPSS_pos;
            int m_TIP_RPSS_VAL_pos;
            int m_VAL_RCD_pos;
            int m_COD_RVDA_PROD_MTC_pos;
            
            int m_QTD_DIA_CRNC_ind_null;
            int m_VAL_LQDC_ind_null;
            int m_VAL_RCD_ind_null;
            int m_VAL_RPSS_ind_null;
    };
} //namespace dbaccess_common


