#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0033 : public dbaccess::table
    {
    public:
        TBSW0033();
        TBSW0033( const std::string& whereClause );
        ~TBSW0033();

        void bind_columns();
        void let_as_is( );
        
        void set_NUM_BCO_DEB( unsigned long a_NUM_BCO_DEB );
        void set_NUM_CGC_CPF( oasis_dec_t a_NUM_CGC_CPF );
        void set_NUM_CHQ( const std::string& a_NUM_CHQ );
        void set_TXT_MSG_1( const std::string& a_TXT_MSG_1 );
        void set_TXT_MSG_2( const std::string& a_TXT_MSG_2 );
        void set_NUM_RSMO_VD( oasis_dec_t a_NUM_RSMO_VD );
        void set_DAT_RSMO_VD( dbm_datetime_t a_DAT_RSMO_VD );
        void set_NUM_TEL( oasis_dec_t a_NUM_TEL );
        void set_TIP_DOC( const std::string& a_TIP_DOC );
        void set_DTH_CON_TRAN( dbm_datetime_t a_DTH_CON_TRAN );
        void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
        void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );

        unsigned long get_NUM_BCO_DEB() const;
        oasis_dec_t get_NUM_CGC_CPF() const;
        const std::string& get_NUM_CHQ() const;
        const std::string& get_TXT_MSG_1() const;
        const std::string& get_TXT_MSG_2() const;
        oasis_dec_t get_NUM_RSMO_VD() const;
        dbm_datetime_t get_DAT_RSMO_VD() const;
        oasis_dec_t get_NUM_TEL() const;
        const std::string& get_TIP_DOC() const;
        dbm_datetime_t get_DTH_CON_TRAN() const;
        unsigned long get_DAT_MOV_TRAN() const;
        oasis_dec_t get_NUM_SEQ_UNC() const;

    private:
        void initialize();
        unsigned long  m_NUM_BCO_DEB;
        oasis_dec_t    m_NUM_CGC_CPF;
        std::string    m_NUM_CHQ;
        std::string    m_TXT_MSG_1;
        std::string    m_TXT_MSG_2;
        oasis_dec_t  m_NUM_RSMO_VD;
        dbm_datetime_t m_DAT_RSMO_VD;
        oasis_dec_t  m_NUM_TEL;
        std::string    m_TIP_DOC;
        dbm_datetime_t m_DTH_CON_TRAN;
        unsigned long  m_DAT_MOV_TRAN;
        oasis_dec_t  m_NUM_SEQ_UNC;

        int m_NUM_BCO_DEB_pos;
        int m_NUM_CGC_CPF_pos;
        int m_NUM_CHQ_pos;
        int m_TXT_MSG_1_pos;
        int m_TXT_MSG_2_pos;
        int m_NUM_RSMO_VD_pos;
        int m_DAT_RSMO_VD_pos;
        int m_NUM_TEL_pos;
        int m_TIP_DOC_pos;
        int m_DTH_CON_TRAN_pos;
        int m_DAT_MOV_TRAN_pos;
        int m_NUM_SEQ_UNC_pos;

        int m_TXT_MSG_1_ind_null;
        int m_TXT_MSG_2_ind_null;
        int m_TIP_DOC_ind_null;
        int m_DAT_RSMO_VD_ind_null;
        int m_DTH_CON_TRAN_ind_null;
        int m_NUM_BCO_DEB_ind_null;
        int m_NUM_CGC_CPF_ind_null;
        int m_NUM_RSMO_VD_ind_null;
        int m_NUM_TEL_ind_null;
        
    };
} //namespace dbaccess_common

