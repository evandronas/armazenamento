#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0121 : public dbaccess::table
    {
        public:
            TBSW0121( );
            TBSW0121( const std::string& whereClause );
            ~TBSW0121( );

            void initialize( );
            void bind_columns( );

            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            void set_COD_VERS_SRVD_PDV( const std::string& a_COD_VERS_SRVD_PDV );
            void set_COD_VERS_CHCK_PDV( const std::string& a_COD_VERS_CHCK_PDV );
            void set_COD_VERS_BBLT_PNPD( const std::string& a_COD_VERS_BBLT_PNPD ); 
            void set_COD_VERS_SFTW( const std::string& a_COD_VERS_SFTW );
            void set_COD_VERS_SIS( const std::string& a_COD_VERS_SIS );
            void set_NUM_SRE_PNPD( const std::string& a_NUM_SRE_PNPD );
            void set_COD_CHCK_PDV( const std::string& a_COD_CHCK_PDV );
            void set_COD_MODL_PNPD( const std::string& a_COD_MODL_PNPD );

            unsigned long get_DAT_MOV_TRAN( ) const;
            oasis_dec_t get_NUM_SEQ_UNC( ) const;
            const std::string& get_COD_VERS_SRVD_PDV( ) const;
            const std::string& get_COD_VERS_CHCK_PDV( ) const;
            const std::string& get_COD_VERS_BBLT_PNPD( ) const;
            const std::string& get_COD_VERS_SFTW( ) const;
            const std::string& get_COD_VERS_SIS( ) const;
            const std::string& get_NUM_SRE_PNPD( ) const;
            const std::string& get_COD_CHCK_PDV( ) const;
            const std::string& get_COD_MODL_PNPD( ) const;

        private:
            unsigned long   m_DAT_MOV_TRAN;
            oasis_dec_t     m_NUM_SEQ_UNC;
            std::string     m_COD_VERS_SRVD_PDV;
            std::string     m_COD_VERS_CHCK_PDV;
            std::string     m_COD_VERS_BBLT_PNPD; 
            std::string     m_COD_VERS_SFTW;
            std::string     m_COD_VERS_SIS;
            std::string     m_NUM_SRE_PNPD;
            std::string     m_COD_CHCK_PDV;
            std::string     m_COD_MODL_PNPD;

            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_COD_VERS_SRVD_PDV_pos;
            int m_COD_VERS_CHCK_PDV_pos;
            int m_COD_VERS_BBLT_PNPD_pos;        
            int m_COD_VERS_SFTW_pos;
            int m_COD_VERS_SIS_pos;
            int m_NUM_SRE_PNPD_pos;
            int m_COD_CHCK_PDV_pos;
            int m_COD_MODL_PNPD_pos;

    }; // class TBSW0121

} // namespace dbaccess_common
