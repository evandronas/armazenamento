#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0055 : public dbaccess::table
    {
    public:
        TBSW0055();
        TBSW0055( const std::string& whereClause );
        ~TBSW0055();

        void bind_columns();

        void set_COD_UCAF( const std::string& a_COD_UCAF );
        void set_NUM_DSTR_CMC_ELET( oasis_dec_t a_NUM_DSTR_CMC_ELET );
        void set_NOM_PORT_CAR( const std::string& a_NOM_PORT_CAR );
        void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
        void set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC );
        void set_COD_USR_CMC_ELET( const std::string& a_COD_USR_CMC_ELET );
        void set_NUM_PDDO_CMC_ELET( const std::string& a_NUM_PDDO_CMC_ELET );
        void set_TXT_CMPM_ENDR_PORT( const std::string& a_TXT_CMPM_ENDR_PORT );
        void set_NOM_FNTS_PDV( const std::string& a_NOM_FNTS_PDV );
        void set_COD_ID_DTCH( const std::string& a_COD_ID_DTCH );
        void set_IND_PGMN_RECRRN( unsigned long a_IND_PGMN_RECRRN );
        void set_VAL_SCO_FRUD( int a_VAL_SCO_FRUD );
        void set_COD_PGM_AUT( const std::string& a_COD_PGM_AUT );
        void set_IND_NVL_SGRA_KMRC( const std::string& a_IND_NVL_SGRA_KMRC );
        /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
        void SetTipoOrigemWeb( int parameterValue );
        // ID_184816 - AMEX FULL - R2_2017 - CAPTURA
        void SetCodigoGrupoRamo( unsigned long value );
        void SetNumeroTransacaoEmissor( const std::string& value );
        void SetCodigoCapacidadeTerminalEmissor( const std::string& value );
        void SetIndicadorCompraEletronica( const std::string& value );
        // ID204705 - Release de bandeiras Outubro-2017 - INICIO
        void SetCodigoNivelSeguranca( const std::string& value );
        void SetCodigoNivelSegurancaOriginal( const std::string& value );
        void SetIndicadorCredencialArmazenado( const std::string& value );
        // ID204705 - Release de bandeiras Outubro-2017 - FIM
        // R10_2018 - Release Outubro - INICIO 
        void SetProgramProtocol(const std::string& value);
        void SetDirectoryServer(const std::string& value);
        void SetProtocolValidationResult(const std::string& value);
        // R10_2018 - Release Outubro - FIM
        // AUT1-2517 - 2021/J01 - INICIO
        void SetWalletID(const std::string& value);
        // AUT1-2517 - 2021/J01 - FIM

        const std::string& get_COD_UCAF() const;
        oasis_dec_t get_NUM_DSTR_CMC_ELET() const;
        const std::string& get_NOM_PORT_CAR() const;
        unsigned long get_DAT_MOV_TRAN() const;
        unsigned long get_NUM_SEQ_UNC() const;
        const std::string& get_COD_USR_CMC_ELET() const;
        const std::string& get_NUM_PDDO_CMC_ELET() const;
        const std::string& get_TXT_CMPM_ENDR_PORT() const;
        const std::string& get_NOM_FNTS_PDV() const;
        const std::string& get_COD_ID_DTCH() const;
        unsigned long get_IND_PGMN_RECRRN() const;
        int get_VAL_SCO_FRUD() const;
        const std::string& get_COD_PGM_AUT() const;
        const std::string& get_IND_NVL_SGRA_KMRC() const;
        /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
        int GetTipoOrigemWeb() const;
        // ID_184816 - AMEX FULL - R2_2017 - CAPTURA
        unsigned long GetCodigoGrupoRamo() const;
        const std::string& GetNumeroTransacaoEmissor() const;
        const std::string& GetCodigoCapacidadeTerminalEmissor() const;
        const std::string& GetIndicadorCompraEletronica() const;
        // ID204705 - Release de bandeiras Outubro-2017 - INICIO
        const std::string& GetCodigoNivelSeguranca() const;
        const std::string& GetCodigoNivelSegurancaOriginal() const;
        const std::string& GetIndicadorCredencialArmazenado() const;
        // ID204705 - Release de bandeiras Outubro-2017 - FIM
        // R10_2018 - Release Outubro - INICIO 
        const std::string& GetProgramProtocol() const;
        const std::string& GetDirectoryServer() const;
        const std::string& GetProtocolValidationResult() const;
        // R10_2018 - Release Outubro - FIM
        // AUT1-2517 - 2021/J01 - INICIO
        const std::string& GetWalletID() const;
        // AUT1-2517 - 2021/J01 - FIM

    private:
        std::string				m_COD_UCAF;
        oasis_dec_t				m_NUM_DSTR_CMC_ELET;
        std::string				m_NOM_PORT_CAR;
        unsigned long				m_DAT_MOV_TRAN;
        unsigned long				m_NUM_SEQ_UNC;
        std::string				m_COD_USR_CMC_ELET;
        std::string				m_NUM_PDDO_CMC_ELET;
        std::string				m_TXT_CMPM_ENDR_PORT;
        std::string				m_NOM_FNTS_PDV;
        std::string				m_COD_ID_DTCH;
        unsigned long				m_IND_PGMN_RECRRN;
        int				m_VAL_SCO_FRUD;
        std::string				m_COD_PGM_AUT;
        std::string				m_IND_NVL_SGRA_KMRC;
        /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
        int						tipoOrigemWeb;
        // ID_184816 - AMEX FULL - R2_2017 - CAPTURA
        unsigned long   codigoGrupoRamo;
        std::string     numeroTransacaoEmissor;
        std::string     codigoCapacidadeTerminalEmissor;
        std::string     indicadorCompraEletronica;
        // ID204705 - Release de bandeiras Outubro-2017 - INICIO
        std::string     codigoNivelSeguranca;
        std::string     codigoNivelSegurancaOriginal;
        std::string     indicadorCredencialArmazenado;
        // ID204705 - Release de bandeiras Outubro-2017 - FIM
        // R10_2018 - Release Outubro - INICIO 
        std::string     programProtocol;
        std::string     directoryServer;
        std::string     protocolValidationResult;
        // R10_2018 - Release Outubro - FIM
        // AUT1-2517 - 2021/J01 - INICIO
        std::string     walletID;
        // AUT1-2517 - 2021/J01 - FIM

        enum field_position {
            m_COD_UCAF_pos = 1,
            m_NUM_DSTR_CMC_ELET_pos,
            m_NOM_PORT_CAR_pos,
            m_DAT_MOV_TRAN_pos,
            m_NUM_SEQ_UNC_pos,
            m_COD_USR_CMC_ELET_pos,
            m_NUM_PDDO_CMC_ELET_pos,
            m_TXT_CMPM_ENDR_PORT_pos,
            m_NOM_FNTS_PDV_pos,
            m_COD_ID_DTCH_pos,
            m_IND_PGMN_RECRRN_pos,
            m_VAL_SCO_FRUD_pos,
            m_COD_PGM_AUT_pos,
            m_IND_NVL_SGRA_KMRC_pos,
            /* ID_28352 - PRODUTO ADQUIRENCIA - R1_2015 - CAPTURA CAMPO COD_TIP_ORG_TRAN_WEB */
            tipoOrigemWebPos,
            // ID_184816 - AMEX FULL - R2_2017 - CAPTURA
            indicadorCompraEletronicaPos,
            // ID204705 - Release de bandeiras Outubro-2017 - INICIO
            codigoNivelSegurancaPosicao,
            codigoNivelSegurancaOriginalPosicao,
            indicadorCredencialArmazenadoPosicao,
            // ID204705 - Release de bandeiras Outubro-2017 - FIM
            // R10_2018 - Release Outubro - INICIO 
            programProtocolPosicao,
            directoryServerPosicao,
            protocolValidationResultPosicao,
            // R10_2018 - Release Outubro - FIM
            // AUT1-2517 - 2021/J01 - INICIO
            walletIDPosicao,
            // AUT1-2517 - 2021/J01 - FIM
        };

        void init_var();
        std::string init_query_fields();
    };
} //namespace dbaccess_common
