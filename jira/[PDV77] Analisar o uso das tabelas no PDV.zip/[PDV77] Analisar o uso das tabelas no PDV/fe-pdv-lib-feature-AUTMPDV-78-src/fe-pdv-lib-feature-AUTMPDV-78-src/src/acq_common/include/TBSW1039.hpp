#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW1039 : public dbaccess::table
    {
        public:
            TBSW1039( );
            TBSW1039( const std::string & str );
            virtual ~TBSW1039( );

            void initialize( );
            void bind_columns( );
            void setWhereClause( const std::string& a_whereClause );

            //GET
            unsigned long get_DAT_MOV_TRAN( ) const;
            oasis_dec_t get_NUM_SEQ_UNC( ) const;
            unsigned long get_COD_MSG_ISO_ORGL( ) const;
            const oasis_dec_t& get_NUM_STAN_ORGL( ) const;
            const dbm_datetime_t get_DTH_STTU_TRAN_ORGL( ) const;
            const oasis_dec_t& get_COD_ISTT_ACQR_ORGL( ) const;

            //SET
            void set_DAT_MOV_TRAN( const unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            void set_COD_MSG_ISO_ORGL( const unsigned long a_COD_MSG_ISO_ORGL );
            void set_NUM_STAN_ORGL( const oasis_dec_t& a_NUM_STAN_ORGL );
            void set_DTH_STTU_TRAN_ORGL( const dbm_datetime_t a_DTH_STTU_TRAN_ORGL );
            void set_COD_ISTT_ACQR_ORGL( const oasis_dec_t& a_COD_ISTT_ACQR_ORGL );

        private:
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_COD_MSG_ISO_ORGL_pos;
            int m_NUM_STAN_ORGL_pos;
            int m_DTH_STTU_TRAN_ORGL_pos;
            int m_COD_ISTT_ACQR_ORGL_pos;

            unsigned long m_DAT_MOV_TRAN;
            oasis_dec_t m_NUM_SEQ_UNC;
            unsigned long m_COD_MSG_ISO_ORGL;
            oasis_dec_t m_NUM_STAN_ORGL;
            dbm_datetime_t m_DTH_STTU_TRAN_ORGL;
            oasis_dec_t m_COD_ISTT_ACQR_ORGL;

            int m_NUM_STAN_ORGL_ind_null;
            int m_DTH_STTU_TRAN_ORGL_ind_null;
            int m_COD_ISTT_ACQR_ORGL_ind_null;

    }; // class TBSW1039

} // namespace dbaccess_common
