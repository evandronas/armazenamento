#pragma once

#include "TBSW0084.hpp"
#include<string>
#include<DBM3.h> //oasis_dec_t
#include <AcqUtils.hpp>
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

class TBSW0084RegrasFormatacaoBase
{
    public:
        TBSW0084RegrasFormatacaoBase( );
        ~TBSW0084RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_TERM               ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_STAN               ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void DTH_INI_TRAN           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_ESTB               ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_PNPD_PDV           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_FBRC_PNPD          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SRE_PNPD           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_HDW_PNPD      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_FRWR_PNPD     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_FBRC_TEF           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_SFTW_TEF      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_FBRC_ATMC          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_SFTW_ATMC     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_LEIT_MAGN          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_ERR_LEIT_MAGN      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_SNHA_MAGN          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_ERR_SNHA_MAGN      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_SNHA_CHIP_ONLN     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_ERR_SNHA_CHIP_ONLN ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_SNHA_CHIP_OFLN     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_ERR_SNHA_CHIP_OFLN ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_BLQD_CHIP         ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_LEIT_CHIP          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_FALLBACK_CRE       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_FALLBACK_DEB       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_SFTW_PNPD     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params, const acq_common::OPERACAO &operacao );

        // Metodos utilizados por campos que tem input generico (INSERT/UPDATE)
        virtual void gen_DAT_MOV_TRAN           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_NUM_SEQ_UNC            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_COD_TERM               ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_NUM_STAN               ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_DTH_INI_TRAN           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_NUM_ESTB               ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_COD_PNPD_PDV           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_NOM_FBRC_PNPD          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_NUM_SRE_PNPD           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_COD_VERS_HDW_PNPD      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_COD_VERS_FRWR_PNPD     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_NOM_FBRC_TEF           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_COD_VERS_SFTW_TEF      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_NOM_FBRC_ATMC          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_COD_VERS_SFTW_ATMC     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_LEIT_MAGN          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_ERR_LEIT_MAGN      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_SNHA_MAGN          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_ERR_SNHA_MAGN      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_SNHA_CHIP_ONLN     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_ERR_SNHA_CHIP_ONLN ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_SNHA_CHIP_OFLN     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_ERR_SNHA_CHIP_OFLN ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_BLQD_CHIP         ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_LEIT_CHIP          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_FALLBACK_CRE       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_QTD_FALLBACK_DEB       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void gen_COD_VERS_SFTW_PNPD     ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );

        // Metodos especificos para INSERT
        virtual void insert_DAT_MOV_TRAN            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_NUM_SEQ_UNC             ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_COD_TERM                ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_NUM_STAN                ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_DTH_INI_TRAN            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_NUM_ESTB                ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_COD_PNPD_PDV            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_NOM_FBRC_PNPD           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_NUM_SRE_PNPD            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_COD_VERS_HDW_PNPD       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_COD_VERS_FRWR_PNPD      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_NOM_FBRC_TEF            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_COD_VERS_SFTW_TEF       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_NOM_FBRC_ATMC           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_COD_VERS_SFTW_ATMC      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_LEIT_MAGN           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_ERR_LEIT_MAGN       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_SNHA_MAGN           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_ERR_SNHA_MAGN       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_SNHA_CHIP_ONLN      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_ERR_SNHA_CHIP_ONLN  ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_SNHA_CHIP_OFLN      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_ERR_SNHA_CHIP_OFLN  ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_BLQD_CHIP          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_LEIT_CHIP           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_FALLBACK_CRE        ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_QTD_FALLBACK_DEB        ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void insert_COD_VERS_SFTW_PNPD      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );

        // Metodos especificos para UPDATE
        virtual void update_DAT_MOV_TRAN            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_NUM_SEQ_UNC             ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_COD_TERM                ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_NUM_STAN                ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_DTH_INI_TRAN            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_NUM_ESTB                ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_COD_PNPD_PDV            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_NOM_FBRC_PNPD           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_NUM_SRE_PNPD            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_COD_VERS_HDW_PNPD       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_COD_VERS_FRWR_PNPD      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_NOM_FBRC_TEF            ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_COD_VERS_SFTW_TEF       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_NOM_FBRC_ATMC           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_COD_VERS_SFTW_ATMC      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_LEIT_MAGN           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_ERR_LEIT_MAGN       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_SNHA_MAGN           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_ERR_SNHA_MAGN       ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_SNHA_CHIP_ONLN      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_ERR_SNHA_CHIP_ONLN  ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_SNHA_CHIP_OFLN      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_ERR_SNHA_CHIP_OFLN  ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_BLQD_CHIP          ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_LEIT_CHIP           ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_FALLBACK_CRE        ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_QTD_FALLBACK_DEB        ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );
        virtual void update_COD_VERS_SFTW_PNPD      ( dbaccess_common::TBSW0084 &tbsw0084, const struct acq_common::tbsw0084_params &params );

        logger::DebugWriter *m_log;

};
