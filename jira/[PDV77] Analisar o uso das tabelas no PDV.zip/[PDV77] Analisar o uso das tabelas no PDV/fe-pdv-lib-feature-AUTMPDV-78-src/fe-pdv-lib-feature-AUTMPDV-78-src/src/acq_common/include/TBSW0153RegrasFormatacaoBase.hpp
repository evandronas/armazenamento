#pragma once

#include "TBSW0153.hpp"
#include<string>
#include<DBM3.h> //oasis_dec_t
#include <AcqUtils.hpp>
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

class TBSW0153RegrasFormatacaoBase
{
    public:
        TBSW0153RegrasFormatacaoBase( );
        ~TBSW0153RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN           ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC            ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao );
        virtual void IND_VAL_APR_SLDO_DSPL  ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_EMSR               ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_EFTV_APRV          ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_RTDR_TRK           ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao );
        virtual void DTH_VD_TERM            ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_MOT_APRV_OFLN      ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params, const acq_common::OPERACAO &operacao );

        // Metodos utilizados por campos que tem input generico (INSERT/UPDATE)
        virtual void gen_DAT_MOV_TRAN           ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void gen_NUM_SEQ_UNC            ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void gen_IND_VAL_APR_SLDO_DSPL  ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void gen_NUM_EMSR               ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void gen_VAL_EFTV_APRV          ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void gen_NUM_RTDR_TRK           ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void gen_DTH_VD_TERM            ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void gen_COD_MOT_APRV_OFLN      ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );

        // Metodos especificos para INSERT
        virtual void insert_DAT_MOV_TRAN            ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void insert_NUM_SEQ_UNC             ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void insert_IND_VAL_APR_SLDO_DSPL   ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void insert_NUM_EMSR                ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void insert_VAL_EFTV_APRV           ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void insert_NUM_RTDR_TRK            ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void insert_DTH_VD_TERM             ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void insert_COD_MOT_APRV_OFLN       ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );

        // Metodos especificos para UPDATE
        virtual void update_DAT_MOV_TRAN            ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void update_NUM_SEQ_UNC             ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void update_IND_VAL_APR_SLDO_DSPL   ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void update_NUM_EMSR                ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void update_VAL_EFTV_APRV           ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void update_NUM_RTDR_TRK            ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void update_DTH_VD_TERM             ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        virtual void update_COD_MOT_APRV_OFLN       ( dbaccess_common::TBSW0153 &tbsw0153, const struct acq_common::tbsw0153_params &params );
        
        logger::DebugWriter *m_log;

}; // class TBSW0153RegrasFormatacaoBase
