#pragma once

#include "TBSW0150.hpp"
#include <string>
#include <DBM3.h> //oasis_dec_t
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <AcqUtils.hpp>

class TBSW0150RegrasFormatacaoBase
{
    public:
        TBSW0150RegrasFormatacaoBase( );
        ~TBSW0150RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_IATA_ETD( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void TXT_DOC_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void TXT_DOC_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void TXT_DOC_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void TXT_DOC_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void TXT_DOC_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_TX_EMBQ( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params, const acq_common::OPERACAO &operacao );

        virtual void gen_DAT_MOV_TRAN( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_NUM_SEQ_UNC( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_COD_IATA_ETD( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_TXT_DOC_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_NOM_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_TXT_DOC_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_NOM_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_TXT_DOC_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_NOM_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_TXT_DOC_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_NOM_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_TXT_DOC_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_NOM_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void gen_VAL_TX_EMBQ( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );

        virtual void insert_DAT_MOV_TRAN( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_NUM_SEQ_UNC( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_COD_IATA_ETD( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_TXT_DOC_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_NOM_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_TXT_DOC_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_NOM_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_TXT_DOC_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_NOM_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_TXT_DOC_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_NOM_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_TXT_DOC_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_NOM_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void insert_VAL_TX_EMBQ( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );

        virtual void update_DAT_MOV_TRAN( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_NUM_SEQ_UNC( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_COD_IATA_ETD( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_TXT_DOC_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_NOM_PSSR_1( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_TXT_DOC_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_NOM_PSSR_2( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_TXT_DOC_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_NOM_PSSR_3( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_TXT_DOC_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_NOM_PSSR_4( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_TXT_DOC_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_NOM_PSSR_5( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );
        virtual void update_VAL_TX_EMBQ( dbaccess_common::TBSW0150 &tbsw0150, const struct acq_common::tbsw0150_params &params );

        logger::DebugWriter *m_log;
};