#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
	class TBSW0157 : public dbaccess::table
	{
	public:
		TBSW0157();
		TBSW0157( const std::string& whereClause );
		void initialize();
		~TBSW0157();

		void bind_columns();

        void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
        void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
        void set_COD_SERV_TRAN( unsigned long a_COD_SERV_TRAN );
        void set_NUM_PDV_ORG_TRAN( unsigned long a_NUM_PDV_ORG_TRAN );
        void set_COD_TERM_ORG_TRAN( const std::string& a_COD_TERM_ORG_TRAN );
        void set_NUM_DDD_RCRG( unsigned long a_NUM_DDD_RCRG );
        void set_NUM_TEL_RCRG( oasis_dec_t a_NUM_TEL_RCRG );
        void set_NUM_SEQ_UNC_OPER( unsigned long a_NUM_SEQ_UNC_OPER );

        unsigned long get_DAT_MOV_TRAN() const;
        oasis_dec_t get_NUM_SEQ_UNC() const;
        unsigned long get_COD_SERV_TRAN() const;
        unsigned long get_NUM_PDV_ORG_TRAN() const;
        const std::string& get_COD_TERM_ORG_TRAN() const;
        unsigned long get_NUM_DDD_RCRG() const;
        oasis_dec_t get_NUM_TEL_RCRG() const;
        unsigned long get_NUM_SEQ_UNC_OPER() const;


	private:
        int m_DAT_MOV_TRAN_pos;
        int m_NUM_SEQ_UNC_pos;
        int m_COD_SERV_TRAN_pos;
        int m_NUM_PDV_ORG_TRAN_pos;
        int m_COD_TERM_ORG_TRAN_pos;
        int m_NUM_DDD_RCRG_pos;
        int m_NUM_TEL_RCRG_pos;
        int m_NUM_SEQ_UNC_OPER_pos;

		unsigned long m_DAT_MOV_TRAN;
		oasis_dec_t  m_NUM_SEQ_UNC;
		unsigned long m_COD_SERV_TRAN;
		unsigned long m_NUM_PDV_ORG_TRAN;
		std::string m_COD_TERM_ORG_TRAN;
        unsigned long m_NUM_DDD_RCRG;
        oasis_dec_t m_NUM_TEL_RCRG;
        unsigned long m_NUM_SEQ_UNC_OPER;

		
	};
} //namespace dbaccess_common

