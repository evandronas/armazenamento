#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0044 : public dbaccess::table
    {
        public:
            TBSW0044();
            TBSW0044( const std::string& whereClause );
            ~TBSW0044();

            void bind_columns();

            void set_NUM_PDV( unsigned long a_NUM_PDV );
            void set_NUM_BIN_INI( oasis_dec_t a_NUM_BIN_INI );
            void set_NUM_BIN_FIM( oasis_dec_t a_NUM_BIN_FIM );
            void set_COD_EMSR( unsigned long a_COD_EMSR );
            void set_COD_STTU_TRAN( const std::string& a_COD_STTU_TRAN );
            void set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG );
            void set_COD_USR_ATLZ_REG( const std::string& a_COD_USR_ATLZ_REG );
            void set_IND_STTU_REG( const std::string& a_IND_STTU_REG );

            unsigned long get_NUM_PDV() const;
            oasis_dec_t get_NUM_BIN_INI() const;
            oasis_dec_t get_NUM_BIN_FIM() const;
            unsigned long get_COD_EMSR() const;
            const std::string& get_COD_STTU_TRAN() const;
            dbm_datetime_t get_DAT_ATLZ_REG() const;
            const std::string& get_COD_USR_ATLZ_REG() const;
            const std::string& get_IND_STTU_REG() const;

        private:
            unsigned long   m_NUM_PDV;
            oasis_dec_t     m_NUM_BIN_INI;
            oasis_dec_t     m_NUM_BIN_FIM;
            unsigned long   m_COD_EMSR;
            std::string     m_COD_STTU_TRAN;
            dbm_datetime_t  m_DAT_ATLZ_REG;
            std::string     m_COD_USR_ATLZ_REG;
            std::string     m_IND_STTU_REG;

            int m_NUM_PDV_pos;
            int m_NUM_BIN_INI_pos;
            int m_NUM_BIN_FIM_pos;
            int m_COD_EMSR_pos;
            int m_COD_STTU_TRAN_pos;
            int m_DAT_ATLZ_REG_pos;
            int m_COD_USR_ATLZ_REG_pos;
            int m_IND_STTU_REG_pos;
    };
} //namespace dbaccess_common

