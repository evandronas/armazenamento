/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t689066, Alexandre Costa Duarte
/ Data de Cria��o: 2017, 11 de Setembro
/ Hist�rico Mudan�as:
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <dbm.h>
#include "dbaccess/table.hpp"
namespace dbaccess_common
{
    class TBSW0140 : public dbaccess::table
    {
    public:
        TBSW0140( );
        TBSW0140( const std::string &str );
        virtual ~TBSW0140( );
        void bind_columns( );
        long getCOD_RAM_ATVD( ) const;
        long getCOD_BNDR( ) const;
        long getCOD_BNDR_CORP( ) const;
        long getCOD_MCC( ) const;
        dbm_datetime_t getDAT_ATLZ_REG( )  const;
        
        void setCOD_RAM_ATVD( long a_COD_RAM_ATVD );
        void setCOD_BNDR( long a_COD_BNDR );
        void setCOD_BNDR_CORP( long a_COD_BNDR_CORP );
        void setCOD_MCC( long a_COD_MCC );
        void setDAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG );
        
    private:
        int m_COD_RAM_ATVD_pos;
        int m_COD_BNDR_pos;
        int m_COD_BNDR_CORP_pos;
        int m_COD_MCC_pos;
        int m_DAT_ATLZ_REG_pos;
        
        int m_COD_RAM_ATVD;
        int m_COD_BNDR;
        int m_COD_BNDR_CORP;
        int m_COD_MCC;
        dbm_datetime_t m_DAT_ATLZ_REG;
    };
}

