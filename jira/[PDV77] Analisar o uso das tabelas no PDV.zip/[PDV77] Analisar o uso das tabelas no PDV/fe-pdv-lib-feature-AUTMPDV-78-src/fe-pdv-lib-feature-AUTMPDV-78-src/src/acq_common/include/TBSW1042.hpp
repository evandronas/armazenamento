#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

enum table_pos 
{
    COD_TERM_POS = 1,  
    IND_ATCG_POS = 2,
    IND_ATIN_POS = 3,
    DAT_ATCG_POS = 4,
    DAT_ATLZ_REG_POS = 5,
    COD_OPID_ULT_ATLZ_POS = 6
    
};

namespace dbaccess_common
{
    class TBSW1042 : public dbaccess::table
    {
    public:
        TBSW1042();
        TBSW1042( const std::string & str );
        virtual ~TBSW1042();
        void bind_columns();
        const std::string& get_COD_TERM() const;
        const std::string& get_IND_ATIN() const;
        const std::string& get_IND_ATCG() const;
        const dbm_datetime_t& get_DAT_ATCG() const;
        const dbm_datetime_t& get_DAT_ATLZ_REG() const;        
        const std::string& get_COD_OPID_ULT_ATLZ() const;
                
        void set_COD_TERM( const std::string& a_COD_TERM );
        void set_IND_ATIN( const std::string& a_IND_ATIN );
        void set_IND_ATCG( const std::string& a_IND_ATCG );
        void set_DAT_ATCG( dbm_datetime_t a_DAT_ATCG );
        void set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG );
        void set_COD_OPID_ULT_ATLZ( const std::string& a_COD_OPID_ULT_ATLZ );

    private:
        std::string m_COD_TERM;
        std::string m_IND_ATIN;
        std::string m_IND_ATCG;        
        dbm_datetime_t m_DAT_ATCG;
        dbm_datetime_t m_DAT_ATLZ_REG;
        std::string m_COD_OPID_ULT_ATLZ;
    };
}
