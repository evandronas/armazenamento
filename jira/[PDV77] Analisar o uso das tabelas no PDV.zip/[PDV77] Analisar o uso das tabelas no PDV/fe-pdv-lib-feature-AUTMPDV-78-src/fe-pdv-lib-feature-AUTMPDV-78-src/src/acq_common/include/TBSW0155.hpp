#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
	class TBSW0155 : public dbaccess::table
	{
	public:
		TBSW0155();
		TBSW0155( const std::string& whereClause );
		~TBSW0155();

		void bind_columns();

		void set_NUM_PDV( unsigned long a_NUM_PDV );
		void set_DAT_REF( dbm_datetime_t a_DAT_REF );
		void set_NUM_MDLD_PRCL( unsigned long a_NUM_MDLD_PRCL );
		void set_QTD_VD_PARC( unsigned long a_QTD_VD_PARC );
		void set_VAL_VD_PARC( oasis_dec_t a_VAL_VD_PARC );

		unsigned long get_NUM_PDV() const;
		dbm_datetime_t get_DAT_REF() const;
		unsigned long get_NUM_MDLD_PRCL() const;
		unsigned long get_QTD_VD_PARC() const;
		oasis_dec_t get_VAL_VD_PARC() const;



	private:
		unsigned long				m_NUM_PDV;
		dbm_datetime_t				m_DAT_REF;
		unsigned long				m_NUM_MDLD_PRCL;
		unsigned long				m_QTD_VD_PARC;
		oasis_dec_t				m_VAL_VD_PARC;

		int m_NUM_PDV_pos;
		int m_DAT_REF_pos;
		int m_NUM_MDLD_PRCL_pos;
		int m_QTD_VD_PARC_pos;
		int m_VAL_VD_PARC_pos;
	};
} //namespace dbaccess_common

