/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#ifndef __TBSW2018_H__
#define __TBSW2018_H__

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW2018 : public dbaccess::table
    {
        public:
            // Declaracao dos Contrutores
            TBSW2018();
            TBSW2018(const std::string& where);

            // Declaracao dos Destrutores
            virtual ~TBSW2018();

            // Getters
            const std::string& GetEnderecoControleDispositivo() const;
            const std::string& GetCodigoSituacaoRegistro() const;
            const std::string& GetDescricaoBloqueio() const;
            const std::string& GetCodigoUsuarioUltimaAlteracao() const;
            const dbm_datetime_t& GetDataUltimaAlteracaoRegistro() const;
            
			
            // Setters
            void SetEnderecoControleDispositivo(const std::string& value);
            void SetCodigoSituacaoRegistro(const std::string& value);
            void SetDescricaoBloqueio(const std::string& value);
            void SetCodigoUsuarioUltimaAlteracao(const std::string& value);
            void SetDataUltimaAlteracaoRegistro(const dbm_datetime_t& value);
            
        protected:
            // Metodo herdado da classe base(db_object)
            void bind_columns();

        private:
            // Indices dos campos na tabela
            int enderecoControleDispositivoPosicao;
            int codigoSituacaoRegistroPosicao;
            int descricaoBloqueioPosicao;
            int codigoUsuarioUltimaAlteracaoPosicao;
            int dataUltimaAlteracaoRegistroPosicao;

            // Atributos confrome campos da tabela TBSW2018
            std::string enderecoControleDispositivo;
            std::string codigoSituacaoRegistro;
            std::string descricaoBloqueio;
            std::string codigoUsuarioUltimaAlteracao;
            dbm_datetime_t dataAlteracaoRegistro;
            
    };
}
#endif  // __TBSW2018_H__
