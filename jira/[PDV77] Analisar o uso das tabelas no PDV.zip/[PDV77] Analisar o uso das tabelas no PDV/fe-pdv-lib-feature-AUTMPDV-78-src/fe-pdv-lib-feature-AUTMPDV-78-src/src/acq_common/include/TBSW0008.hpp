/* Copyright 2019 Rede S.A.
Autor  : Joao Paulo F. Costa
Empresa: Rede
*/

#ifndef __TBSW0008_H__
#define __TBSW0008_H__

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0008 : public dbaccess::table
    {
        public:
            // Declaracao dos Contrutores
            TBSW0008();
            TBSW0008(const std::string& where);

            // Declaracao dos Destrutores
            virtual ~TBSW0008();

            // Getters
            const std::string& GetCodigoBinInferior() const;
            const std::string& GetCodigoBinSuperior() const;
            const oasis_dec_t& GetCodigoIca() const;
            const std::string& GetCodigoRegiao() const;
            const std::string& GetCodigoPais() const;
            const std::string& GetCodigoProduto() const;
            const dbm_datetime_t& GetDataInclusaoRegistro() const;
            const std::string& GetCodigoSituacaoRegistro() const;
            const std::string& GetIndicadorToken() const;

            // Setters
            void SetCodigoBinInferior(const std::string& value);
            void SetCodigoBinSuperior(const std::string& value);
            void SetCodigoIca(const oasis_dec_t& value);
            void SetCodigoRegiao(const std::string& value);
            void SetCodigoPais(const std::string& value);
            void SetCodigoProduto(const std::string& value);
            void SetDataInclusaoRegistro(const dbm_datetime_t& value);
            void SetCodigoSituacaoRegistro(const std::string& value);
            void SetIndicadorToken(const std::string& value);

        protected:
            // Metodo herdado da classe base(db_object)
            void bind_columns();

        private:
            // Indices dos campos na tabela
            int codigoBinInferiorPosicao;
            int codigoBinSuperiorPosicao;
            int codigoIcaPosicao;
            int codigoRegiaoPosicao;
            int codigoPaisPosicao;
            int codigoProdutoPosicao;
            int dataInclusaoRegistroPosicao;
            int codigoSituacaoRegistroPosicao;
            int indicadorTokenPosicao;

            // Atributos confrome campos da tabela TBSW0008
            std::string codigoBinInferior;
            std::string codigoBinSuperior;
            oasis_dec_t codigoIca;
            std::string codigoRegiao;
            std::string codigoPais;
            std::string codigoProduto;
            dbm_datetime_t dataInclusaoRegistro;
            std::string codigoSituacaoRegistro;
            std::string indicadorToken;;
    };
}
#endif  // __TBSW0008_H__
