#pragma once

#include <string>
#include <DBM3.h> //oasis_dec_t
#include "TBSW0033.hpp"
#include <defines.hpp>

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

class TBSW0033RegrasFormatacaoBase
{
public:
	TBSW0033RegrasFormatacaoBase( );
	~TBSW0033RegrasFormatacaoBase( );
    
    virtual void gen_NUM_BCO_DEB ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_NUM_CGC_CPF ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_NUM_CHQ     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_TXT_MSG_1   ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_TXT_MSG_2   ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_NUM_RSMO_VD ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_DAT_RSMO_VD ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_NUM_TEL     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_TIP_DOC     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_DTH_CON_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_DAT_MOV_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void gen_NUM_SEQ_UNC ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    
    virtual void insert_NUM_BCO_DEB ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_NUM_CGC_CPF ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_NUM_CHQ     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_TXT_MSG_1   ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_TXT_MSG_2   ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_NUM_RSMO_VD ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_DAT_RSMO_VD ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_NUM_TEL     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_TIP_DOC     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_DTH_CON_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_DAT_MOV_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void insert_NUM_SEQ_UNC ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    
    virtual void update_NUM_BCO_DEB ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_NUM_CGC_CPF ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_NUM_CHQ     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_TXT_MSG_1   ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_TXT_MSG_2   ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_NUM_RSMO_VD ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_DAT_RSMO_VD ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_NUM_TEL     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_TIP_DOC     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_DTH_CON_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_DAT_MOV_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    virtual void update_NUM_SEQ_UNC ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params );
    
    virtual void NUM_BCO_DEB ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void NUM_CGC_CPF ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void NUM_CHQ     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void TXT_MSG_1   ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void TXT_MSG_2   ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void NUM_RSMO_VD ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void DAT_RSMO_VD ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void NUM_TEL     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void TIP_DOC     ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void DTH_CON_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void DAT_MOV_TRAN( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    virtual void NUM_SEQ_UNC ( dbaccess_common::TBSW0033& tbsw0033, const struct acq_common::tbsw0033_params& tbsw0033_params, const acq_common::OPERACAO& operacao );
    
private:    
    logger::DebugWriter *m_log;

};