/* Copyright 2021 Rede S.A.
Autor  : Igor
Empresa: Rede
*/

#ifndef __TBSW0036_H__
#define __TBSW0036_H__

#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_common
{
    class TBSW0036 : public dbaccess::table
    {
        public:
            // Declaracao dos Contrutores
            TBSW0036();
            TBSW0036(const std::string& where);

            // Declaracao dos Destrutores
            virtual ~TBSW0036();

            void initialize();
            void bind_columns();

            void setWhereClause( const std::string& whereClause );

            void showxxx( const char *name, unsigned long campo, bool isNull );
            void showxxx( const char *name, long campo, bool isNull );
            void showxxx( const char *name, const std::string& campo, bool isNull );
            void showxxx( const char *name, oasis_dec_t campo, bool isNull );
            void show( int nvl );

            void let_as_is( );

            // Getters
            unsigned long GetDataMovimentoTransacao() const;
            unsigned long GetNumeroSequencialUnico() const;
            oasis_dec_t GetValorMoedaEstrangeira() const;
            const std::string& GetCodigoMoedaEstrangeira() const;
            long GetPercentualTaxaMarkup() const;
            unsigned long GetValorTaxaConversaoMoeda() const;
            unsigned long GetDataMovimentoTransacaoConsulta() const;
            unsigned long GetNumeroSequencialUnicoConsulta() const;

            // Setters
            void SetDataMovimentoTransacao(unsigned long value);
            void SetNumeroSequencialUnico(unsigned long value);
            void SetValorMoedaEstrangeira(oasis_dec_t value);
            void SetCodigoMoedaEstrangeira(const std::string& value);
            void SetPercentualTaxaMarkup(long value);
            void SetValorTaxaConversaoMoeda(unsigned long value);
            void SetDataMovimentoTransacaoConsulta(unsigned long value);
            void SetNumeroSequencialUnicoConsulta(unsigned long value);

        private:
            // Indices dos campos na tabela
            int dataMovimentoTransacaoPosicao;
            int numeroSequencialUnicoPosicao;
            int valorMoedaEstrangeiraPosicao;
            int codigoMoedaEstrangeiraPosicao;
            int percentualTaxaMarkupPosicao;
            int valorTaxaConversaoMoedaPosicao;
            int dataMovimentoTransacaoConsultaPosicao;
            int numeroSequencialUnicoConsultaPosicao;

            // Nullables
            int valorMoedaEstrangeiraIndNull;
            int codigoMoedaEstrangeiraIndNull;
            int percentualTaxaMarkupIndNull;
            int valorTaxaConversaoMoedaIndNull;
            int dataMovimentoTransacaoConsultaIndNull;
            int numeroSequencialUnicoConsultaIndNull;

            // Atributos confrome campos da tabela TBSW0036
            unsigned long dataMovimentoTransacao;
            unsigned long numeroSequencialUnico;
            oasis_dec_t valorMoedaEstrangeira;
            std::string codigoMoedaEstrangeira;
            long percentualTaxaMarkup;
            unsigned long valorTaxaConversaoMoeda;
            unsigned long dataMovimentoTransacaoConsulta;
            unsigned long numeroSequencialUnicoConsulta;

            logger::DebugWriter *log;
            bool isDual;
    };
}
#endif  // __TBSW0036_H__
