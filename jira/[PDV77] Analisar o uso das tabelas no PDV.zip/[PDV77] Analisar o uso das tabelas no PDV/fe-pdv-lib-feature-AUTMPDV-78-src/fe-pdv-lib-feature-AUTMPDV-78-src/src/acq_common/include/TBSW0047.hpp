/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_common
{
	class TBSW0047 : public dbaccess::table
	{
	public:
		TBSW0047( );
		TBSW0047( const std::string &str );
		virtual ~TBSW0047( );
		void bind_columns( );
		long getCOD_BCO_CMPS( ) const;
		long getCOD_INT_BCO( ) const;
		const std::string& getCOD_MODO_OPE_BCO( ) const;
		const std::string& getCOD_MODO_PLTO( ) const;
		const std::string& getIND_OPE_CDC( ) const;
		dbm_datetime_t getDAT_VIG_CDC( ) const;
		const std::string& getIND_OPE_PRCI( ) const;
		dbm_datetime_t getDAT_VIG_PRCI( ) const;
		dbm_datetime_t getDAT_VIG_PDA( ) const;
		const std::string& getIND_OPE_GRNT_CHQ( ) const;
		const std::string& getIND_SIT_BCO( ) const;
		const std::string& getIND_SIT_BCO_ESTB( ) const;
		const std::string& getNOM_BCO_CMPL( ) const;
		dbm_datetime_t getTMS_INCL( ) const;
		const std::string& getCOD_STTU_REG( ) const;
		const std::string& getIND_OPE_PDA( ) const;
		dbm_datetime_t getDAT_VIG_GRNT_CHQ( ) const;
		void setCOD_BCO_CMPS( long a_COD_BCO_CMPS );
		void setCOD_INT_BCO( long a_COD_INT_BCO );
		void setCOD_MODO_OPE_BCO( const std::string& a_COD_MODO_OPE_BCO );
		void setCOD_MODO_PLTO( const std::string& a_COD_MODO_PLTO );
		void setIND_OPE_CDC( const std::string& a_IND_OPE_CDC );
		void setDAT_VIG_CDC( dbm_datetime_t a_DAT_VIG_CDC );
		void setIND_OPE_PRCI( const std::string& a_IND_OPER_PRCI );
		void setDAT_VIG_PRCI( dbm_datetime_t a_DAT_VIG_PRCI );
		void setDAT_VIG_PDA( dbm_datetime_t a_DAT_VIG_PDA );
		void setIND_OPE_GRNT_CHQ( const std::string& a_IND_OPER_GRNT_CHQ );
		void setIND_SIT_BCO( const std::string& a_IND_SIT_BCO );
		void setIND_SIT_BCO_ESTB( const std::string& a_IND_SIT_BCO_ESTB );
		void setNOM_BCO_CMPL( const std::string& a_NOM_BCO_CMPL );
		void setTMS_INCL( dbm_datetime_t a_TMS_INCL );
		void setCOD_STTU_REG( const std::string& a_COD_STTU_REG );
		void setIND_OPE_PDA( const std::string& a_NOM_BCO_CMPL );
		void setDAT_VIG_GRNT_CHQ( dbm_datetime_t a_TMS_INCL );
	private:
		int COD_BCO_CMPS_pos;
		int COD_INT_BCO_pos;
		int COD_MODO_OPE_BCO_pos;
		int COD_MODO_PLTO_pos;
		int IND_OPE_CDC_pos;
		int DAT_VIG_CDC_pos;
		int IND_OPE_PRCI_pos;
		int DAT_VIG_PRCI_pos;
		int DAT_VIG_PDA_pos;
		int IND_OPE_GRNT_CHQ_pos;
		int IND_SIT_BCO_pos;
		int IND_SIT_BCO_ESTB_pos;
		int NOM_BCO_CMPL_pos;
		int TMS_INCL_pos;
		int COD_STTU_REG_pos;
		int IND_OPE_PDA_pos;
		int DAT_VIG_GRNT_CHQ_pos;
		long m_COD_BCO_CMPS;
		long m_COD_INT_BCO;
		std::string m_COD_MODO_OPE_BCO;
		std::string m_COD_MODO_PLTO;
		std::string m_IND_OPE_CDC;
		dbm_datetime_t m_DAT_VIG_CDC;
		std::string m_IND_OPE_PRCI;
		dbm_datetime_t m_DAT_VIG_PRCI;
		dbm_datetime_t m_DAT_VIG_PDA;
		std::string m_IND_OPE_GRNT_CHQ;
		std::string m_IND_SIT_BCO;
		std::string m_IND_SIT_BCO_ESTB;
		std::string m_NOM_BCO_CMPL;
		dbm_datetime_t m_TMS_INCL;
		std::string m_COD_STTU_REG;
		std::string m_IND_OPE_PDA;
		dbm_datetime_t m_DAT_VIG_GRNT_CHQ;
	};
}

