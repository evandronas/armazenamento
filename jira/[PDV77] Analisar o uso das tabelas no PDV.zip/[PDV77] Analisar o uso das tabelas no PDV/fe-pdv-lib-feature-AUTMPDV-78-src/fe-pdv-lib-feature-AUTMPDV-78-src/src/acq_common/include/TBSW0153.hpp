#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0153 : public dbaccess::table
    {
        public:

            TBSW0153( );
            TBSW0153( const std::string& whereClause );
            ~TBSW0153( );

            void initialize( );
            void bind_columns( );
			void let_as_is( );
			
            void set_NUM_EMSR( unsigned long a_NUM_EMSR );
            void set_NUM_SEQ_UNC( oasis_dec_t a_NUM_SEQ_UNC );
            void set_DTH_VD_TERM( dbm_datetime_t m_DTH_VD_TERM );
            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_VAL_EFTV_APRV( oasis_dec_t a_VAL_EFTV_APRV );
            void set_NUM_RTDR_TRK( unsigned long a_NUM_RTDR_TRK );
            void set_COD_MOT_APRV_OFLN( const std::string& a_COD_MOT_APRV_OFLN );
            void set_IND_VAL_APR_SLDO_DSPL( const std::string& a_IND_VAL_APR_SLDO_DSPL );

            oasis_dec_t get_VAL_EFTV_APRV( ) const;
            dbm_datetime_t get_DTH_VD_TERM( ) const;
            unsigned long get_NUM_EMSR( ) const;
            oasis_dec_t get_NUM_SEQ_UNC( ) const;
            unsigned long get_DAT_MOV_TRAN( ) const;
            unsigned long get_NUM_RTDR_TRK( ) const;
            const std::string& get_COD_MOT_APRV_OFLN() const;
            const std::string& get_IND_VAL_APR_SLDO_DSPL( ) const;

        private:

            unsigned long   m_NUM_EMSR;
            oasis_dec_t     m_NUM_SEQ_UNC;
            unsigned long   m_NUM_RTDR_TRK;
            unsigned long   m_DAT_MOV_TRAN;
            dbm_datetime_t  m_DTH_VD_TERM;
            oasis_dec_t     m_VAL_EFTV_APRV;
            std::string     m_COD_MOT_APRV_OFLN;
            std::string     m_IND_VAL_APR_SLDO_DSPL;

            int m_NUM_EMSR_pos;
            int m_DTH_VD_TERM_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_RTDR_TRK_pos;
            int m_VAL_EFTV_APRV_pos;
            int m_COD_MOT_APRV_OFLN_pos;
            int m_IND_VAL_APR_SLDO_DSPL_pos;

            int m_VAL_EFTV_APRV_ind_null;

    }; // class TBSW0153

} // namespace dbaccess_common


