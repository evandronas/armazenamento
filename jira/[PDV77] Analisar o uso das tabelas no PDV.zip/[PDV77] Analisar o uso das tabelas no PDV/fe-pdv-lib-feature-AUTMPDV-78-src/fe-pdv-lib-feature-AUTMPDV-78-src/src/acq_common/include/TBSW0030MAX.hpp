#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0030MAX : public dbaccess::table
    {
    public:
        TBSW0030MAX();
        TBSW0030MAX( const std::string& whereClause );
        ~TBSW0030MAX();
        
        void initialize( );
        void bind_columns();

        void set_NUM_SEQ_UNC(unsigned long a_NUM_SEQ_UNC );
        void set_IND_STTU_TRAN(const std::string& a_IND_STTU_TRAN);
        void set_DAT_MOV_TRAN(unsigned long a_DAT_MOV_TRAN);
        unsigned long get_NUM_SEQ_UNC() const;
        const std::string& get_IND_STTU_TRAN() const;
        unsigned long get_DAT_MOV_TRAN() const;
        
    private:
        unsigned long m_NUM_SEQ_UNC;
        std::string m_IND_STTU_TRAN;
        unsigned long m_DAT_MOV_TRAN;
        
        int m_NUM_SEQ_UNC_pos;
        int m_IND_STTU_TRAN_pos;
        int m_DAT_MOV_TRAN_pos;
    };
} //namespace dbaccess_common

