/*
Copyright 2018 REDE
*********************** MODIFICACOES ************************
Autor    : Eduardo de Souza
Data     : 20/09/2018
Empresa  : Rede
Descricao: Correcao para gravar o campo valor efetivo aprovado
ID       : BIP 234.996
*************************************************************
*/
#pragma once
#include <dbm.h>
#include <string>

namespace acq_common
{
    enum OPERACAO{
        INSERT = 0,
        UPDATE
    };

    struct tbsw0030_params{
        unsigned long local_date; // shc_msg.local_date
        unsigned long refnum; // shc_msg.refnum
        unsigned long origrefnum; // segments.common.origrefnum 
        unsigned long trandate; // shc_msg.trandate
        unsigned long trantime; // shc_msg.trantime
        unsigned long local_time; // shc_msg.local_time 
        std::string dbt_tipo_transacao; // segments.debt.tipo_transacao
        unsigned long settlement_date; // shc_msg.settlement_date 
        unsigned long msgtype; // shc_msg.msgtype 
        unsigned long pcode; // shc_msg.pcode 
        unsigned long transcode; // segments.common.transcode 
        std::string tip_dtlh_tran; // LOCAL.tip_dtlh_tran 
        std::string plano_pagamento; // segments.private_label.plano_pagamento
        std::string cd_ctg_trx; // segments.common.cd_ctg_trx 
        unsigned long subtranscode; // segments.common.subtranscode 
        unsigned long termloc; // shc_msg.termloc 
        std::string termid; // shc_msg.termid 
        unsigned long trace; // shc_msg.trace 
        std::string cd_tpo_trm; // segments.merchant.cd_tpo_trm 
        std::string mer_cat_code; // segments.merchant.mer_cat_code 
        unsigned long pos_entry_code; // shc_msg.pos_entry_code 
        unsigned long cod_bndr; // segments.common.cod_bndr 
        std::string bin; // segments.common.bin 
        std::string mc_info_ica; // segments.credit.mc_info_ica 
        std::string num_car; // LOCAL.L_NUM_CAR 
        std::string orig_pan; // segments.common.orig_pan 
        std::string countryDiners; // LOCAL.countryDiners 
        unsigned long expiry_date; // shc_data.expiry_date 
        std::string cod_trk_car; // LOCAL.L_COD_TRK_CAR 
        std::string ind_trk; // LOCAL.L_IND_TRK
        unsigned long orig_transcode; // segments.common.orig_transcode 
        std::string track2; // shc_msg.track2 
        std::string track3; // shc_msg.track3 
        std::string mc_info_country; // segments.credit.mc_info_country 
        std::string isVan; // LOCAL.isVAN 
        std::string cvv2; // shc_msg.cvv2 
        std::string local_cod_serv; // LOCAL.L_COD_SERV 
        std::string status; // segments.common.status 
        std::string pin; // shc_msg.pin
        std::string amount; // shc_msg.amount 
        std::string cod_mot_aut_pauz; // LOCAL.cod_mot_aut_pauz 
        std::string orig_authnum; // segments.common.orig_authnum 
        std::string authnum; // shc_msg.authnum 
        unsigned long pb_reason_code; // segments.common.pb_reason_code 
        std::string acceptorname; // shc_msg.acceptorname 
        std::string ind_term_ltro_chip; // LOCAL.IND_TERM_LTRO_CHIP 
        std::string isReversal; // segments.common.is_reversal 
        std::string isVoid; // segments.common.is_void 
        unsigned long chip_full_data_len; // segments.chip.chip_full_data_len 
        std::string local_ind_tran_refd; // LOCAL.IND_TRAN_REFD
        std::string cod_cndc_cptr_pauz; // LOCAL.cod_cndc_cptr_pauz
        std::string tip_ent_pauz; // LOCAL.tip_ent_pauz
        std::string transactionID; // segments.common.transactionId
        std::string common_vl_pca_ent; // segments.common.vl_pca_ent
        std::string common_vl_txa; // segments.common.vl_txa
        std::string cod_cndc_cptr; // segments.common.cod_cndc_cptr
        std::string ecr_sftw_verid; // segments.common.ecr_sftw_verid
        unsigned long az_reason_code; // segments.common.az_reason_code
        std::string de_adc_ete; // segments.common.de_adc_ete
        std::string ind_modl_cptr; // LOCAL.ind_modl_cptr
        unsigned long hor_tran_emsr; // segments.credit.hor_tran_emsr
        unsigned long dat_mov_tran_emsr; // segments.credit.dat_mov_tran_emsr
        std::string cod_istt_acqr; // segments.credit.cod_istt_acqr
        unsigned long cod_rsps_dtlh_emsr; // segments.cod_rsps_dtlh_emsr
        std::string addresponse; // shc_msg.addresponse
        std::string is_cod_serv_trk_car; // LOCAL.IS_COD_SERV_TRK_CAR
        std::string value_cod_serv_trk_car; // LOCAL.VALUE_COD_SERV_TRK_CAR
        std::string ext_refnum; // segments.common.ext_refnum
        std::string termid_type; // segments.common.termid_type
        std::string trn_tem_original; // LOCAL.trn_tem_original
        unsigned long date_pauz; // LOCAL.dat_pauz
        unsigned long cod_tran_cad; // segments.acq_common.COD_TRAN_CAD
        std::string receive_inst_id; // shc_msg.receive_inst_id
        std::string issuer; // shc_msg.issuer
        std::string merchant_type; // shc_msg.merchant_type
        std::string extrac_out_de60; // segments.debt.extrac_out_de60
        std::string respcode; // shc_msg.respcode
        unsigned long ext_network_code; // segments.common.ext_network_code
        unsigned long dt_rv; // segments.common.dt_rv
        unsigned long cd_ems; // segments.common.cd_ems
        std::string cod_istt_frwd; // segments.credit.cod_istt_frwd
        std::string iss_name; // segments.common.iss_name 
        std::string msg_category; // segments.common.msg_cateogry 
        std::string acq_name; // segments.common.msg_sub_cateogry 
        unsigned long origtrace; // shc_msg.origtrace 
        std::string msg_name; // segments.common.msg_name 
        std::string in_tpo_tcn; // segments.merchant.in_tpo_tcn 
        std::string is_pre_auth; // segments.common.is_pre_auth
        std::string pl_cod_item; // segments.private_label.cod_item 
        std::string netcodex; // segments.common.netcodex
        std::string cod_mtv_sw; // segments.common.cod_mtv_sw 
        std::string has_pin; // segments.common.has_pin
        std::string nom_site_issr; // segments.common.nom_site_issr
        std::string nom_host_issr; //segments.common.nom_host_issr
        std::string nom_fe_issr; // segments.common.nom_fe_issr
        std::string quem_negou; // segments.common.quem_negou
        std::string trn_tem_cupom; // segments.common.trn_tem_cupom
        unsigned long ind_pagt_fatura; // segments.debt.idPagFatura
        unsigned long cod_serv_corp; // LOCAL.cod_serv_corp
        unsigned long cod_emp_adqt; // segments.common.cod_emp_adqt
        std::string num_pdv_ext; // segments.merchant.cod_pv_externo
        std::string num_pdv_van; // segments.merchant.cod_pv_van
        std::string chip_full_data; // LOCAL.L_CHIP_FULL_DATA
        std::string txt_adic_pos; // segments.credit.txt_adic_pos
        std::string numero_cv_ad; // segments.common.numero_cv_ad
        std::string msg_entrymode; // segments.common.msg_entrymode
        std::string merchant_mer_name; // PPAYPORT-703
        std::string merchant_mer_city; // PPAYPORT-703
        std::string segments_credit_fee; // segments.credit.fee  PPAYPORT-702
        std::string form_factor; // segments.chip.form_factor  PPAYPORT-909
        std::string term_fisico; // segments.service.term_fisico
        std::string is_nfc; // segments.common.is_nfc
        std::string cod_mot_rsps_ext; // tbsw0030.cod_mot_rsps_ext
        std::string is_desfaz_estorno;
        std::string sender_mbname; // LOCAL.mailboxName
        std::string de38IssOff; // segments.common.de38IssOff
        std::string orig_ind_da_rlcd_chip;
        long cod_gru_clas_ram;
        std::string tokenIdentifier; // segments.common.tokenIdentifier
        std::string ind_da_rlcd_iata; // LOCAL.ind_da_rlcd_iata
        unsigned long cod_prod_cdst; // segments.acq_common.COD_TRAN_CAD
        std::string codigoOrigemRespostaAutorizacao; // segments.common.codigoOrigemRespostaAutorizacao
        std::string alphaResponseCode; // shc_msg.alpha_response_code
        std::string nomePortadorDoCartao; // segments.common.nome_portador_cartao
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        std::string indicadorPresencaPortador; // segments.common.indicadorPresencaPortador
        std::string indicadorTecnologiaTerminal; // segments.common.indicadorTecnologiaTerminal
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        // BRUM - EAK-1657 - 27/08/2019 - MCC Dinamico - Inicio
        std::string merchantCategoryCodeSubLojista; // segments.sublojista.merchantCategoryCode
        // BRUM - EAK-1657 - Fim
        std::string indicadorTrilha3Len;
        // J2_2020 - WQ3 QRCODE - INICIO
        std::string     tipoFormatadorHeader;   // segments.common.fmt_env_source
        std::string     indicacaoQrcode;        // segments.common.indicacao_qrcode
        long            codigoParceiro;         // segments.common.codigo_parceiro
        // J2_2020 - WQ3 QRCODE - FIM
        std::string     codigoRoteamentoTransacao;        // shc_msg.netcode
        short       posCapCode;
        // AUT1-2168 - PIX - INICIO
        std::string     requestIdPix;                  // segments.pix.requestIdPix
        // AUT1-2168 - PIX - INICIO

        // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
        int codigoProcessoEmissor;                      // segments.common.codigoProcessoEmissor
        // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM
        std::string identificadorReferenciaBandeira;

        long codigoParceiroAdquirente;

        unsigned long situacaoOferta;

    };
    
    struct tbsw0031_params{
        //shcmsg
        unsigned long   local_date;
        unsigned long   refnum;
        //segmento common
        std::string     ext_refnum;
        std::string     iss_name;
        std::string     is_van;
        unsigned long   status;
        //segmento merchant
        std::string     ind_term_flex;
        //segmento credit
        std::string     mc_info_prod_code;
        std::string     mc_info_region;
        //segmento voucher
        std::string     ctah;
        std::string     num_ref_tran;
        std::string     cod_cpcd_term;
        std::string     categoriaMensagem; // segments.common.msg_cateogry 
        // R10_2018 - Release Outubro - INICIO
        std::string     printedCardSecurityCode; // segments.credit.printedCardSecurityCode
        // R10_2018 - Release Outubro - FIM
        unsigned long   numeroEstabelecimentoPreAutorizacao;
        std::string     codigoTerminalPreAutorizacao;
    };

    struct tbsw0032_params{
        unsigned long   local_date;
        unsigned long   refnum;
        unsigned long   nu_bco_etb;
        std::string     iss_name;
        std::string     bin;
        unsigned long   nu_age_etb;
        std::string     cd_cta_etb;
        std::string     cash_back;
        std::string     amount;
        std::string     cap_positive_conf;
        std::string     cap_data_positive_conf;
        std::string     tip_cob_tran_mtc;
        std::string     mc_info_cod_rvda_prod;
        std::string     trxTaxa;
        std::string     vlTrfTxaMtc;
        std::string     mc_info_prod_code;
        std::string     ind_car_mltp;
        std::string     val_cob_tran;
        int             respcode;
        double          amount2;
        std::string     msg_category; // segments.common.msg_cateogry 
        int             status; //segments.common.status
    };

    struct tbsw0033_params
    {
        unsigned long local_time;
        unsigned long local_date;
        std::string refnum;
        std::string cpf_cnpj;
        std::string num_cheque;
        std::string nu_rv;
        std::string msg_category; //segments.common.msg_category
        std::string dt_rv;
        std::string bit63;
        unsigned long pos_entry_code;
        std::string bit48;
        std::string pay_code;
        std::string msg_name; // segments.common.msg_name
        char load_init;
        char load_program;
        char indUtlzPnpd;
        unsigned long nu_age_etb;
        std::string cd_tpo_trm;
        std::string in_tpo_tcn;
        std::string cd_cta_etb;
        unsigned long trace;
        unsigned long origmsg;
        unsigned long origtrace;
        std::string origdate;
        unsigned long origtime;
        std::string dataLocalOriginal;
        std::string horaLocalOriginal;
        std::string nomeEmissor;
        std::string cartao;
        std::string codigoMembroBandeira;
        std::string enderecoFantasia;
        std::string cpf;
        std::string respcode;
    };

    struct tbsw0034_params
    {
        unsigned long local_time;
        unsigned long local_date;
        std::string refnum;
        std::string second_gen_ac;
        std::string chip_full_data;
        int chip_full_data_len;
        std::string isr;
        std::string cvm_code;
        std::string pin;
        std::string card_seqno;
        unsigned long transcode;
        std::string cardholder_name_extended;
        std::string cd_ems;
        std::string iss_name;

        struct commonStruct
        {
            std::string cvm_code;
            unsigned long   transcode;
            std::string card_seqno;
            std::string cd_ems;
            std::string cardholder_name_extended;
        }common;

    };

    struct tbsw0035_params{
        //shcmsg
        unsigned long   local_date;
        unsigned long   refnum;
        unsigned long   termloc;
        std::string     termid;
        //segmento merchant
        std::string     merchant_in_tpo_tcn;
        std::string     merchant_mer_name;
        std::string     merchant_cod_vers_sftw;
        //segmento adm
        std::string     adm_num_bxa_tec;
        std::string     adm_num_sre_term;
        std::string     adm_num_sre_pnpd_ext;
        std::string     adm_cod_id_pnpd;
        std::string     adm_cod_aplv_pnpd;
        std::string     adm_cod_vers_krn;
        std::string     adm_nom_modl_chip;
        std::string     adm_num_sre_smcrd;
        std::string     adm_nom_oper;
        std::string     adm_cod_ip_prmi;
        unsigned long   adm_num_prta_prmi;
        std::string     adm_cod_ip_secd;
        unsigned long   adm_num_prta_secd;
        std::string     adm_nom_url_cnfr;
        unsigned long   adm_qtd_tran_gprs_prmi;
        unsigned long   adm_qtd_tran_gsm_prmi;
        unsigned long   adm_qtd_tran_gprs_secd;
        unsigned long   adm_qtd_tran_gsm_secd;
        unsigned long   adm_qtd_tnta_prmi;
        unsigned long   adm_qtd_tnta_secd;
        std::string     local_num_tel_adic_estb;
        // t689049
        std::string     bit63;
    };

    struct tbsw0055_params
    {
        unsigned long   local_date;     // DAT_MOV_TRAN
        unsigned long   refnum;         // NUM_SEQ_UNC
        std::string     cavv;           // COD_UCAF
        std::string     eci;            // IND_NVL_SGRA_KMRC
        unsigned long   transcode;      // Auxiliar para formatar cavv (COD_UCAF)
        std::string     protocol_validation_result;    // COD_VLDC_ATTC_PRTO_SGRA
    };

    struct tbsw0058_params{    
        unsigned long   local_time;
        unsigned long   local_date;
        std::string   refnum;
        unsigned long   termloc;
        std::string     termid;
        unsigned long msgtype;
        unsigned long ulCd_ems;
        std::string amount;
        unsigned long acq_currency_code; 
        std::string mer_cat_code;
        std::string orig_pan;
        unsigned long bin;        
        unsigned long pcode;
        unsigned long transcode;
        unsigned long pb_reason_code;
        unsigned long expiry_date;
        unsigned long trandate;    
        unsigned long trantime;     
        std::string trace;     
        unsigned long dt_vdd_pre_auz;
        unsigned long cod_bndr;       
        std::string pos_entry_code;
        std::string authnum;
        std::string track2;
        std::string cod_gru_estb;
        std::string cod_mtz_estb ; 
        std::string status;  
        std::string mc_info_ica ;
        std::string acquirer_data;
        std::string receive_inst_id; 
        std::string issuer;
        std::string cod_ctah_voch; 
        std::string acq_conv_rate; 
        unsigned long cd_ems;
        unsigned long ext_network_code;
        unsigned long install_num;
        unsigned char pin[ 20 ];
        std::string cod_serv_snha;
        std::string is_van;
        std::string az_reason_code;
        std::string nom_site_issr;
        std::string nom_host_issr;
        std::string nom_fe_issr;
        std::string quem_negou; // segments.common.quem_negou
        std::string termid_type;
        std::string is_void;
        std::string is_reversal;
        std::string de_adc_ete;
        std::string acquirer;
        std::string mc_info_country;
        std::string ind_rd_org;
        std::string ind_rd_org_estr;
        std::string ind_rd_cptr;
        std::string iss_name;
        std::string has_pin; // segments.common.has_pin
        std::string addresponse; // shc_msg.addresponse
        std::string cod_cndc_cptr; // segments.common.cod_cndc_cptr
        std::string msg_category; // segments.common.msg_cateogry 
        std::string isVan; // LOCAL.isVAN 
        std::string msg_name; // segments.common.msg_name 
        std::string orig_authnum; // segments.common.orig_authnum 
        std::string is_pre_auth; // segments.common.is_pre_auth
        std::string acq_name; // segments.common.msg_sub_cateogry 
        std::string mc_info_prod_code; //segments.credit.mc_info_prod_code
        std::string cod_pv_externo; //segments.merchant.cod_pv_externo
        std::string cod_pv_van; //segments.merchant.cod_pv_van
        std::string cod_trk_car;
        std::string track3;
        std::string txt_adic_pos; // segments.credit.txt_adic_pos
        std::string numero_cv_ad; // segments.common.numero_cv_ad
        std::string sender_mbname;  // LOCAL.mailboxName
        std::string num_pdv_van; // segments.merchant.cod_pv_van
        std::string orig_status;
        long cod_gru_clas_ram;
        std::string num_ref_tran;
        std::string cod_cpcd_term;
        std::string tokenIdentifier; // segments.common.tokenIdentifier
        std::string codigoOrigemRespostaAutorizacao; // segments.common.codigoOrigemRespostaAutorizacao
        std::string codigoProdutoMastercard;
        std::string codigoRegiaoMastercard;
        // R10_2018 - Release Outubro - INICIO
        std::string printedCardSecurityCode; // segments.credit.printedCardSecurityCode
        // R10_2018 - Release Outubro - FIM
        // J4_2019 - Release Bandeiras Abril 2019 - INICIO
        std::string indicadorPresencaPortador; // segments.common.indicadorPresencaPortador
        std::string indicadorTecnologiaTerminal; // segments.common.indicadorTecnologiaTerminal
        // J4_2019 - Release Bandeiras Abril 2019 - FIM
        // J04_2021 - Retencao do codigo do processo do pcode Elo - INICIO
        int codigoProcessoEmissor;                      // segments.common.codigoProcessoEmissor
        // J04_2021 - Retencao do codigo do processo do pcode Elo - FIM
        std::string identificadorReferenciaBandeira;
    };

    struct tbsw0083_params{
        std::string avs_cep;
        std::string avs_end_fat;
        std::string avs_end_num;
        std::string avs_end_com;
        std::string avs_cpf;
        unsigned long local_date;
        std::string refnum;
        std::string avs_respcode;
        
        struct commonStruct
        {
            std::string cvm_code;
            unsigned long transcode;
            std::string card_seqno;
            std::string cd_ems;
            std::string cardholder_name_extended;
        }common;
    };
    
    struct tbsw0084_params{
        //shcmsg
        unsigned long   local_date;
        unsigned long   trace;
        unsigned long   termloc;
        unsigned long   local_time;
        unsigned long   refnum;
        //segmento adm
        std::string     statistics;
        std::string     id_pinpad;
        //segmento common
        std::string     terminal_pdv;
    };

    struct tbsw0093_params{
    //shcmsg
    unsigned long local_date;
    std::string refnum;
    std::string   pcode;
    std::string   pos_entry_code;
    std::string   origdate;
    //segment common
    std::string  common_cd_ems;
    std::string  common_pay_code;
    std::string  common_cod_trans;
    std::string  common_transcode;
    std::string  common_origrefnum;
    std::string  common_az_reason_code;
    std::string  common_pb_reason_code;
    std::string  common_ext_network_code;
    std::string  msg_name;
    //segment private label
    std::string private_label_cod_item;
    std::string tbsw0030_tip_vd;
    };

    struct tbsw0121_params{
        //shcmsg
        unsigned long   local_date;
        unsigned long   refnum;
        std::string     termid;
        //segmento common
        std::string     codver;
        std::string     ecr_sftw_verid;
        //segmento acq_common
        std::string     de47_tag3_dial;
        //segmento merchant
        std::string     cod_vers_sftw;
    };

    struct tbsw0129_params{
        //shcmsg
        unsigned long   local_date;
        unsigned long   refnum;
        unsigned long   local_time;
        std::string     termid;
        unsigned long   termloc;
        //outros
        std::string     nom_site_acqr;
        std::string     nom_host_acqr;
        std::string     nom_fe_acqr;
    };

    struct tbsw0139_params{
        //shcmsg
        unsigned long   local_date;
        std::string     termid;
        unsigned long   termloc;
        //segmento merchant
        std::string     indCripto;
        std::string     cod_vers_sftw;
        std::string     num_vers_clit;
        std::string     num_vers_aplv_rcd;
        std::string     versSotfwBiblCompartPinpad;
        std::string     versEspecBiblCompartPinpad;
        //segmento common
        std::string     nom_site_issr;
        std::string     nom_host_issr;
        std::string     nom_fe_issr;
        std::string     termid_type;
        std::string     codver;
        std::string     ecr_fabr_id;
        std::string     ecr_sftw_verid;
        //outros
        std::string     nom_site_acqr;
        std::string     nom_host_acqr;
        std::string     nom_fe_acqr;
        std::string     nom_site_acqr_atlz;
        std::string     nom_host_acqr_atlz;
        std::string     nom_fe_acqr_atlz;
    };

    struct tbsw0150_params{
        unsigned long   local_date;
        unsigned long   refnum;
    };

    struct tbsw0152_params{
        //shcmsg
        unsigned long   local_date;
        unsigned long   refnum;
        //segmento common
        unsigned long   install_num;
        unsigned long   status;
        std::string     msg_name;
        std::string     iss_name;
        //segmento credit
        std::string     install_amt;
        std::string     fee;
        std::string     applied_fee;
        std::string     vl_pca_ent;
        std::string     amount;
    };

    struct tbsw0153_params{
        //shcmsg
        unsigned long   local_date;
        unsigned long   refnum;
        std::string     track2;
        unsigned long   local_time;
        std::string     aval_balance;
        //segmento common
        unsigned long   cd_ems;             //TO DO: remover (descontinuado)
        unsigned long   bin;                //TO DO: remover (descontinuado)
        unsigned long   pb_reason_code;
        std::string     iss_name;           //TO DO: remover (descontinuado)
        std::string     tentativa_offline;
        unsigned long   cod_emsr;
        //segmento voucher
        std::string     ind_mot_aprov_chip;
        //LOCAL
        unsigned long   num_rtdr;
        std::string     msg_entrymode;
        std::string     respcode;
        std::string     valEftvAprv; // shc_msg.amount
    };

    struct tbsw0157_params{
        //shc_msg
        unsigned long   local_date;
        oasis_dec_t     refnum;
        //segmento service
        unsigned long   cod_service;
        unsigned long   pv_fisico;
        std::string     term_fisico;
        unsigned long   ddd_celular;
        oasis_dec_t     num_celular;
        unsigned long   nsu_operadora;
    };

    struct tbsw1039_params{
        //shcmsg
        unsigned long   local_date;
        unsigned long   refnum;
        unsigned long   origpcode;
        unsigned long   origmsg;
        std::string     origtrace;
        unsigned long   origdate;
        unsigned long   origtime;
        //segmento common
        std::string     ecr_acqinst_id;
    };

    struct tbsw0160_params{
        unsigned long local_date;
        unsigned long refnum;
        int chip_full_data_len;
        std::string   termid_type;
        std::string   cod_pgm_aut;
        std::string   chip_full_data;
        std::string   second_gen_ac;
        std::string   isr;
        std::string   ind_nvl_sgra_kmrc;
        std::string   cvm_code;
        std::string   pin;
        std::string   msg_name;
        std::string   iss_name;
        std::string   numeroSequenciaCartaoChip; /// card_seqno
    };

    struct tbsw0101_params{
        unsigned long   local_date;
        unsigned long   refnum;
        std::string     tokenAssuranceLevel;
        std::string     paymentAccountReference;
    };

    struct tbsw0102_params{
        unsigned long   local_date;
        unsigned long   refnum;
        std::string     tokenAssuranceLevel;
        std::string     paymentAccountReference;
    };
    // Estrutura para armazenar as variaveis necessarias para formatacao de um registro da TBSW0162
    struct Tbsw0162Parametros{
        unsigned long dataLocal;                    // shc_msg.local_date
        unsigned long numeroSequencial;             // shc_msg.refnum
        std::string   identificacaoTerminal;        // shc_msg.termid 
        unsigned long identificacaoEstabelecimento; // shc_msg.termloc 
        std::string   numeroSerieTerminal;          // segments.adm.num_sre_term
    };

}
