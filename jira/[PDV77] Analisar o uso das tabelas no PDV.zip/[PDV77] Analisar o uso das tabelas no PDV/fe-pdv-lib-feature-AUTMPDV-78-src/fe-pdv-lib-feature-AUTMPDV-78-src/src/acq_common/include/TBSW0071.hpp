/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_common
{
	class TBSW0071 : public dbaccess::table
	{
	public:
		TBSW0071( );
		TBSW0071( const std::string & str );
		virtual ~TBSW0071( );
		void bind_columns( );
		long getNUM_PDV( ) const;
		const std::string& getCOD_STTU_REG( ) const;
		dbm_datetime_t getDAT_ATLZ_REG( ) const;
		long getCOD_SERV( ) const;
		long getNUM_PDV_BCO_ARCD( ) const;
		const std::string& getTIP_MDLD_PGMN( ) const;
		const std::string& getCOD_BLTO_BCO_ARCD( ) const;
		oasis_dec_t getVAL_MN_VD( ) const;
		oasis_dec_t getVAL_MX_SQUE( ) const;
	private:
		int m_NUM_PDV_pos;
		int m_COD_STTU_REG_pos;
		int m_DAT_ATLZ_REG_pos;
		int m_COD_SERV_pos;
		int m_NUM_PDV_BCO_ARCD_pos;
		int m_TIP_MDLD_PGMN_pos;
		int m_COD_BLTO_BCO_ARCD_pos;
		int m_VAL_MN_VD_pos;
		int m_VAL_MX_SQUE_pos;
		long m_NUM_PDV;
		std::string m_COD_STTU_REG;
		dbm_datetime_t m_DAT_ATLZ_REG;
		long m_COD_SERV;
		long m_NUM_PDV_BCO_ARCD;
		std::string m_TIP_MDLD_PGMN;
		std::string m_COD_BLTO_BCO_ARCD;
		oasis_dec_t m_VAL_MN_VD;
		oasis_dec_t m_VAL_MX_SQUE;
	};
}//namespace dbaccess_common

