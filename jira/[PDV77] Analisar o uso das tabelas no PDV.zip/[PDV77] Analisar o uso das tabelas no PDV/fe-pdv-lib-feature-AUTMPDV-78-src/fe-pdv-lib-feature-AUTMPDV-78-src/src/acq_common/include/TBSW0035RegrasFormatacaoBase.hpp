#pragma once

#include "TBSW0035.hpp"
#include<string>
#include <AcqUtils.hpp>
#include <defines.hpp>
#include<DBM3.h> //oasis_dec_t

class TBSW0035RegrasFormatacaoBase
{
    public:
        TBSW0035RegrasFormatacaoBase( );
        ~TBSW0035RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void DTH_BXA_TEC        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_BXA_TEC        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void TIP_TCNL           ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_ORDM_SERV      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_OCOR           ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_ESTB           ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_FNTS_PT_DE_VD  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_TEL_ESTB       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void TXT_ENDR_ESTB      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_TERM           ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SRE_TERM       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SRE_PNPD_EXT   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_ID_PNPD        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_APLV_PNPD      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_SFTW      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VERS_KRN       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_MODL_CHIP      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SRE_SMCRD      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_OPER           ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_ID_TEC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_EPS            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_IP_PRMI        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_PRTA_PRMI      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_IP_SECD        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_PRTA_SECD      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_URL_CNFR       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_TRAN_GPRS_PRMI ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_TRAN_GSM_PRMI  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_TRAN_GPRS_SECD ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_TRAN_GSM_SECD  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_STTU_RPLC      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_TNTA_PRMI      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_TNTA_SECD      ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_TEL_ADIC_ESTB  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params, const acq_common::OPERACAO &operacao );

        // Metodos utilizados por campos que tem input generico (INSERT/UPDATE)
        virtual void gen_DAT_MOV_TRAN        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_SEQ_UNC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_DTH_BXA_TEC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_BXA_TEC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_TIP_TCNL            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_ORDM_SERV       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_OCOR            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_ESTB            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NOM_FNTS_PT_DE_VD   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_TEL_ESTB        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_TXT_ENDR_ESTB       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_TERM            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_SRE_TERM        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_SRE_PNPD_EXT    ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_ID_PNPD         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_APLV_PNPD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_VERS_SFTW       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_VERS_KRN        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NOM_MODL_CHIP       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_SRE_SMCRD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NOM_OPER            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_ID_TEC          ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_EPS             ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_IP_PRMI         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_PRTA_PRMI       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_IP_SECD         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_PRTA_SECD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NOM_URL_CNFR        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_QTD_TRAN_GPRS_PRMI  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_QTD_TRAN_GSM_PRMI   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_QTD_TRAN_GPRS_SECD  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_QTD_TRAN_GSM_SECD   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_COD_STTU_RPLC       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_QTD_TNTA_PRMI       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_QTD_TNTA_SECD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void gen_NUM_TEL_ADIC_ESTB   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );

        // Metodos especificos para INSERT
        virtual void insert_DAT_MOV_TRAN        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_SEQ_UNC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_DTH_BXA_TEC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_BXA_TEC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_TIP_TCNL            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_ORDM_SERV       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_OCOR            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_ESTB            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NOM_FNTS_PT_DE_VD   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_TEL_ESTB        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_TXT_ENDR_ESTB       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_TERM            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_SRE_TERM        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_SRE_PNPD_EXT    ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_ID_PNPD         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_APLV_PNPD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_VERS_SFTW       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_VERS_KRN        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NOM_MODL_CHIP       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_SRE_SMCRD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NOM_OPER            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_ID_TEC          ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_EPS             ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_IP_PRMI         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_PRTA_PRMI       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_IP_SECD         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_PRTA_SECD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NOM_URL_CNFR        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_QTD_TRAN_GPRS_PRMI  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_QTD_TRAN_GSM_PRMI   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_QTD_TRAN_GPRS_SECD  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_QTD_TRAN_GSM_SECD   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_COD_STTU_RPLC       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_QTD_TNTA_PRMI       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_QTD_TNTA_SECD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void insert_NUM_TEL_ADIC_ESTB   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );

        // Metodos especificos para UPDATE
        virtual void update_DAT_MOV_TRAN        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_SEQ_UNC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_DTH_BXA_TEC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_BXA_TEC         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_TIP_TCNL            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_ORDM_SERV       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_OCOR            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_ESTB            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NOM_FNTS_PT_DE_VD   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_TEL_ESTB        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_TXT_ENDR_ESTB       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_TERM            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_SRE_TERM        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_SRE_PNPD_EXT    ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_ID_PNPD         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_APLV_PNPD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_VERS_SFTW       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_VERS_KRN        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NOM_MODL_CHIP       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_SRE_SMCRD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NOM_OPER            ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_ID_TEC          ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_EPS             ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_IP_PRMI         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_PRTA_PRMI       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_IP_SECD         ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_PRTA_SECD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NOM_URL_CNFR        ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_QTD_TRAN_GPRS_PRMI  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_QTD_TRAN_GSM_PRMI   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_QTD_TRAN_GPRS_SECD  ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_QTD_TRAN_GSM_SECD   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_COD_STTU_RPLC       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_QTD_TNTA_PRMI       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_QTD_TNTA_SECD       ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );
        virtual void update_NUM_TEL_ADIC_ESTB   ( dbaccess_common::TBSW0035 &tbsw0035, const struct acq_common::tbsw0035_params &params );

}; // class TBSW0035RegrasFormatacaoBase