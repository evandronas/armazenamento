#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0113 : public dbaccess::table
    {
        public:
            TBSW0113( );
            TBSW0113( const std::string& whereClause );
            ~TBSW0113( );

            void initialize( );
            void bind_columns( );

            void set_COD_STTU_REG( const std::string& a_COD_STTU_REG );
            void set_NUM_RTDR( unsigned long a_NUM_RTDR );
            void set_COD_SBPD( unsigned long a_COD_SBPD );
            void set_COD_EMSR( unsigned long a_COD_EMSR );
            void set_NOM_EMSR( const std::string& a_NOM_EMSR );
            void set_COD_TRAN_GE( unsigned long a_COD_TRAN_GE );
            void set_NOM_PROD_CPOM( const std::string& a_NOM_PROD_CPOM );
            void set_TXT_RDPE_CPOM( const std::string& a_TXT_RDPE_CPOM );
            void set_COD_USR_ATLZ_REG( const std::string& a_COD_USR_ATLZ_REG );
            void set_DAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG );
            void set_DAT_ATVC_VOCH( dbm_datetime_t a_DAT_ATVC_VOCH );
            void set_NTWKID( const std::string& a_NTWKID );
            void set_NUM_BIN( unsigned long a_NUM_BIN );

            const std::string& get_COD_STTU_REG( ) const;
            unsigned long get_NUM_RTDR( ) const;
            unsigned long get_COD_SBPD( ) const;
            unsigned long get_COD_EMSR( ) const;
            const std::string& get_NOM_EMSR( ) const;
            unsigned long get_COD_TRAN_GE( ) const;
            const std::string& get_NOM_PROD_CPOM( ) const;
            const std::string& get_TXT_RDPE_CPOM( ) const;
            const std::string& get_COD_USR_ATLZ_REG( ) const;
            dbm_datetime_t get_DAT_ATLZ_REG( ) const;
            dbm_datetime_t get_DAT_ATVC_VOCH( ) const;
            const std::string& get_NTWKID( ) const;
            unsigned long get_NUM_BIN( ) const;

        private:
            std::string     m_COD_STTU_REG;
            unsigned long   m_NUM_RTDR;
            unsigned long   m_COD_SBPD;
            unsigned long   m_COD_EMSR;
            std::string     m_NOM_EMSR;
            unsigned long   m_COD_TRAN_GE;
            std::string     m_NOM_PROD_CPOM;
            std::string     m_TXT_RDPE_CPOM;
            std::string     m_COD_USR_ATLZ_REG;
            dbm_datetime_t  m_DAT_ATLZ_REG;
            dbm_datetime_t  m_DAT_ATVC_VOCH;
            std::string     m_NTWKID;
            unsigned long   m_NUM_BIN;

            int m_COD_STTU_REG_pos;
            int m_NUM_RTDR_pos;
            int m_COD_SBPD_pos;
            int m_COD_EMSR_pos;
            int m_NOM_EMSR_pos;
            int m_COD_TRAN_GE_pos;
            int m_NOM_PROD_CPOM_pos;
            int m_TXT_RDPE_CPOM_pos;
            int m_COD_USR_ATLZ_REG_pos;
            int m_DAT_ATLZ_REG_pos;
            int m_DAT_ATVC_VOCH_pos;
            int m_NTWKID_pos;
            int m_NUM_BIN_pos;
    };
} //namespace dbaccess_common
