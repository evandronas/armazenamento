#pragma once

#include "TBSW0031.hpp"
#include<string>
#include<DBM3.h> //oasis_dec_t
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <AcqUtils.hpp>

class TBSW0031RegrasFormatacaoBase
{
    public:
        TBSW0031RegrasFormatacaoBase( );
        ~TBSW0031RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_ADM            ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_MN_CAR         ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_CRT_ECM        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_CTR            ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_DIA_CRNC       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC_RD_AUT ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void IND_TERM_FATR_EXPS ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_PROD_MTC       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_RGAO_MTC       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_CTAH_VOCH      ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_REF_TRAN       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_CPCD_TERM      ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void numeroEstabelecimentoPreAutorizacao    ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );
        virtual void codigoTerminalPreAutorizacao           ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params, const acq_common::OPERACAO &operacao );

        // Metodos utilizados por campos que tem input generico (INSERT/UPDATE)
        virtual void gen_DAT_MOV_TRAN       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_NUM_SEQ_UNC        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_NUM_ADM            ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_VAL_MN_CAR         ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_COD_CRT_ECM        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_COD_CTR            ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_QTD_DIA_CRNC       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_NUM_SEQ_UNC_RD_AUT ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_IND_TERM_FATR_EXPS ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_COD_PROD_MTC       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_COD_RGAO_MTC       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_COD_CTAH_VOCH      ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_NUM_REF_TRAN       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void gen_COD_CPCD_TERM      ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );

        // Metodos especificos para INSERT
        virtual void insert_DAT_MOV_TRAN        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_NUM_SEQ_UNC         ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_NUM_ADM             ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_VAL_MN_CAR          ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_COD_CRT_ECM         ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_COD_CTR             ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_QTD_DIA_CRNC        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_NUM_SEQ_UNC_RD_AUT  ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_IND_TERM_FATR_EXPS  ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_COD_PROD_MTC        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_COD_RGAO_MTC        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_COD_CTAH_VOCH       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_NUM_REF_TRAN        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insert_COD_CPCD_TERM       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insertNumeroEstabelecimentoPreAutorizacao  ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void insertCodigoTerminalPreAutorizacao         ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );

        // Metodos especificos para UPDATE
        virtual void update_DAT_MOV_TRAN        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_NUM_SEQ_UNC         ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_NUM_ADM             ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_VAL_MN_CAR          ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_COD_CRT_ECM         ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_COD_CTR             ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_QTD_DIA_CRNC        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_NUM_SEQ_UNC_RD_AUT  ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_IND_TERM_FATR_EXPS  ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_COD_PROD_MTC        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_COD_RGAO_MTC        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_COD_CTAH_VOCH       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_NUM_REF_TRAN        ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void update_COD_CPCD_TERM       ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void updateNumeroEstabelecimentoPreAutorizacao  ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );
        virtual void updateCodigoTerminalPreAutorizacao         ( dbaccess_common::TBSW0031 &tbsw0031, const struct acq_common::tbsw0031_params &params );

        logger::DebugWriter *m_log;

}; // class TBSW0031RegrasFormatacaoBase
