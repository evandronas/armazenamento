#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0160 : public dbaccess::table
    {
        public:

            TBSW0160( );
            TBSW0160( const std::string& whereClause );            
            ~TBSW0160( );

            void setWhereClause( const std::string& whereClause );    
            void bind_columns( );
			void let_as_is( );

            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC );
            void set_IND_RD_ORG( const std::string& a_IND_RD_ORG );
            void set_COD_PGM_AUT( const std::string& a_COD_PGM_AUT );
            void set_TXT_RLCD_CHIP( const std::string& a_TXT_RLCD_CHIP );
            void set_TXT_INFO_CMPM_CHIP( const std::string& a_TXT_INFO_CMPM_CHIP );
            void set_TXT_RSTD_ATLZ_CHIP( const std::string& a_TXT_RSTD_ATLZ_CHIP );
            void set_IND_NVL_SGRA_KMRC( const std::string& a_IND_NVL_SGRA_KMRC );
            void set_IND_MTDO_VRFC_PORT( const std::string& a_IND_MTDO_VRFC_PORT );
            void set_IND_PRSC_SNHA( const std::string& a_IND_PRSC_SNHA );
            void set_DAT_CNFR_PAUZ( dbm_datetime_t a_DAT_CNFR_PAUZ );
            void set_NUM_SEQ_UNC_CNFR( unsigned long a_NUM_SEQ_UNC_CNFR );

            unsigned long get_DAT_MOV_TRAN( ) const;
            unsigned long get_NUM_SEQ_UNC( ) const;
            const std::string& get_IND_RD_ORG( ) const;
            const std::string& get_COD_PGM_AUT( ) const;
            const std::string& get_TXT_RLCD_CHIP( ) const;
            const std::string& get_TXT_INFO_CMPM_CHIP( ) const;
            const std::string& get_TXT_RSTD_ATLZ_CHIP( ) const;
            const std::string& get_IND_NVL_SGRA_KMRC( ) const;
            const std::string& get_IND_MTDO_VRFC_PORT( ) const;
            const std::string& get_IND_PRSC_SNHA( ) const;
            dbm_datetime_t get_DAT_CNFR_PAUZ( ) const;
            unsigned long get_NUM_SEQ_UNC_CNFR( ) const;

            void SetNumeroSequencialCartaoValidacaoChip( unsigned long paramNumeroSequencialCartaoValidacaoChip );
            unsigned long GetNumeroSequencialCartaoValidacaoChip( ) const;

        private:
            unsigned long m_DAT_MOV_TRAN;
            unsigned long m_NUM_SEQ_UNC;
            std::string m_IND_RD_ORG;
            std::string m_COD_PGM_AUT;
            std::string m_TXT_RLCD_CHIP;
            std::string m_TXT_INFO_CMPM_CHIP;
            std::string m_TXT_RSTD_ATLZ_CHIP;
            std::string m_IND_NVL_SGRA_KMRC;
            std::string m_IND_MTDO_VRFC_PORT;
            std::string m_IND_PRSC_SNHA;
            dbm_datetime_t m_DAT_CNFR_PAUZ;
            unsigned long m_NUM_SEQ_UNC_CNFR;
            
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_IND_RD_ORG_pos;
            int m_COD_PGM_AUT_pos;
            int m_TXT_RLCD_CHIP_pos;
            int m_TXT_INFO_CMPM_CHIP_pos;
            int m_TXT_RSTD_ATLZ_CHIP_pos;
            int m_IND_NVL_SGRA_KMRC_pos;
            int m_IND_MTDO_VRFC_PORT_pos;
            int m_IND_PRSC_SNHA_pos;
            int m_DAT_CNFR_PAUZ_pos;
            int m_NUM_SEQ_UNC_CNFR_pos;
            int m_DAT_CNFR_PAUZ_ind_null;
            int m_NUM_SEQ_UNC_CNFR_ind_null;
            
            unsigned long numeroSequencialCartaoValidacaoChip;
            int posNumeroSequencialCartaoValidacaoChip;
            int indNullNumeroSequencialCartaoValidacaoChip;

            void initialize();
    };
} //namespace dbaccess_pdv


