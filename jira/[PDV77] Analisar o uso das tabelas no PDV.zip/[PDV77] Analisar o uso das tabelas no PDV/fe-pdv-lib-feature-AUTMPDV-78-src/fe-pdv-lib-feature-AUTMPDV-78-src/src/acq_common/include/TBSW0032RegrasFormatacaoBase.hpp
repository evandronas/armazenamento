#pragma once

#include <string>
#include <DBM3.h> //oasis_dec_t
#include "TBSW0032.hpp"
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <AcqUtils.hpp>

class TBSW0032RegrasFormatacaoBase
{
    public:
        TBSW0032RegrasFormatacaoBase( );
        ~TBSW0032RegrasFormatacaoBase( );
        
        virtual void DAT_MOV_TRAN( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_BCO_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_BCO_DEB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_EMSR( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_AGE_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_CTA_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_VD_BCO( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void IND_CNFR_PSTV( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void IND_IMPR_CPOM( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void QTD_DIA_CRNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void IND_CAR_MLTP( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_LQDC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_RPSS( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void TIP_RPSS_VAL( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void VAL_RCD( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_RVDA_PROD_MTC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params, const acq_common::OPERACAO &operacao );

        virtual void gen_DAT_MOV_TRAN( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_NUM_SEQ_UNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_NUM_BCO_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_NUM_BCO_DEB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_NUM_EMSR( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_NUM_AGE_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_COD_CTA_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_COD_VD_BCO( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_IND_CNFR_PSTV( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_IND_IMPR_CPOM( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_QTD_DIA_CRNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_IND_CAR_MLTP( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_VAL_LQDC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_VAL_RPSS( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_TIP_RPSS_VAL( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_VAL_RCD( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void gen_COD_RVDA_PROD_MTC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );

        virtual void insert_DAT_MOV_TRAN( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_NUM_SEQ_UNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_NUM_BCO_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_NUM_BCO_DEB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_NUM_EMSR( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_NUM_AGE_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_COD_CTA_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_COD_VD_BCO( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_IND_CNFR_PSTV( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_IND_IMPR_CPOM( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_QTD_DIA_CRNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_IND_CAR_MLTP( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_VAL_LQDC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_VAL_RPSS( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_TIP_RPSS_VAL( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_VAL_RCD( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void insert_COD_RVDA_PROD_MTC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );

        virtual void update_DAT_MOV_TRAN( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_NUM_SEQ_UNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_NUM_BCO_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_NUM_BCO_DEB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_NUM_EMSR( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_NUM_AGE_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_COD_CTA_ESTB( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_COD_VD_BCO( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_VAL_SQUE( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_IND_CNFR_PSTV( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_IND_IMPR_CPOM( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_QTD_DIA_CRNC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_IND_CAR_MLTP( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_VAL_LQDC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_VAL_RPSS( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_TIP_RPSS_VAL( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_VAL_RCD( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );
        virtual void update_COD_RVDA_PROD_MTC( dbaccess_common::TBSW0032 &tbsw0032, const struct acq_common::tbsw0032_params &params );

        logger::DebugWriter *m_log;

}; // class TBSW0032RegrasFormatacaoBase
