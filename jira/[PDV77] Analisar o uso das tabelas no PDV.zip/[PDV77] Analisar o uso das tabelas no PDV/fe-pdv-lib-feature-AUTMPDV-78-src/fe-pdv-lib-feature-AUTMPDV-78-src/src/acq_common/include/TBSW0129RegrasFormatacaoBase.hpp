#pragma once

#include "TBSW0129.hpp"
#include<string>
#include <AcqUtils.hpp>
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

class TBSW0129RegrasFormatacaoBase
{
    public:
        TBSW0129RegrasFormatacaoBase( );
        ~TBSW0129RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN       ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC        ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao );
        virtual void DTH_INI_TRAN       ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_TERM           ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_ESTB           ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_SITE_ACQR_ORGL ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_HOST_ACQR_ORGL ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao );
        virtual void NOM_FE_ACQR_ORGL   ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params, const acq_common::OPERACAO &operacao );

        // Metodos utilizados por campos que tem input generico (INSERT/UPDATE)
        virtual void gen_DAT_MOV_TRAN       ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void gen_NUM_SEQ_UNC        ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void gen_DTH_INI_TRAN       ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void gen_COD_TERM           ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void gen_NUM_ESTB           ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void gen_NOM_SITE_ACQR_ORGL ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void gen_NOM_HOST_ACQR_ORGL ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void gen_NOM_FE_ACQR_ORGL   ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );

        // Metodos especificos para INSERT
        virtual void insert_DAT_MOV_TRAN        ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void insert_NUM_SEQ_UNC         ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void insert_DTH_INI_TRAN        ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void insert_COD_TERM            ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void insert_NUM_ESTB            ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void insert_NOM_SITE_ACQR_ORGL  ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void insert_NOM_HOST_ACQR_ORGL  ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void insert_NOM_FE_ACQR_ORGL    ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );

        // Metodos especificos para UPDATE
        virtual void update_DAT_MOV_TRAN        ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void update_NUM_SEQ_UNC         ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void update_DTH_INI_TRAN        ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void update_COD_TERM            ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void update_NUM_ESTB            ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void update_NOM_SITE_ACQR_ORGL  ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void update_NOM_HOST_ACQR_ORGL  ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );
        virtual void update_NOM_FE_ACQR_ORGL    ( dbaccess_common::TBSW0129 &tbsw0129, const struct acq_common::tbsw0129_params &params );

        logger::DebugWriter *m_log;

}; // class TBSW0129RegrasFormatacaoBase
