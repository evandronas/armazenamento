#pragma once

#include <string>
#include <algorithm>

#include <DBM3.h> //oasis_dec_t
#include "TBSW0160.hpp"
#include <defines.hpp>

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

class TBSW0160RegrasFormatacaoBase
{
public:
	TBSW0160RegrasFormatacaoBase( );
	~TBSW0160RegrasFormatacaoBase( );
    
    virtual void gen_DAT_MOV_TRAN      ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_NUM_SEQ_UNC       ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_IND_RD_ORG        ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_COD_PGM_AUT       ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_TXT_RLCD_CHIP     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_IND_NVL_SGRA_KMRC ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_IND_PRSC_SNHA     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_DAT_CNFR_PAUZ     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void gen_NUM_SEQ_UNC_CNFR  ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void GenNumeroSequencialCartaoValidacaoChip  ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    
    virtual void insert_DAT_MOV_TRAN      ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_NUM_SEQ_UNC       ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_IND_RD_ORG        ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_COD_PGM_AUT       ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_TXT_RLCD_CHIP     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_IND_NVL_SGRA_KMRC ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_IND_PRSC_SNHA     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_DAT_CNFR_PAUZ     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void insert_NUM_SEQ_UNC_CNFR  ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void InsertNumeroSequencialCartaoValidacaoChip( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    
    virtual void update_DAT_MOV_TRAN      ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_NUM_SEQ_UNC       ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_IND_RD_ORG        ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_COD_PGM_AUT       ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_TXT_RLCD_CHIP     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_IND_NVL_SGRA_KMRC ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_IND_PRSC_SNHA     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_DAT_CNFR_PAUZ     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void update_NUM_SEQ_UNC_CNFR  ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    virtual void UpdateNumeroSequencialCartaoValidacaoChip( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params );
    
    virtual void DAT_MOV_TRAN      ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void NUM_SEQ_UNC       ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void IND_RD_ORG        ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void COD_PGM_AUT       ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void TXT_RLCD_CHIP     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void TXT_INFO_CMPM_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void TXT_RSTD_ATLZ_CHIP( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void IND_NVL_SGRA_KMRC ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void IND_MTDO_VRFC_PORT( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void IND_PRSC_SNHA     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void DAT_CNFR_PAUZ     ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void NUM_SEQ_UNC_CNFR  ( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    virtual void NumeroSequencialCartaoValidacaoChip( dbaccess_common::TBSW0160& TBSW0160, const struct acq_common::tbsw0160_params& tbsw0160_params, const acq_common::OPERACAO& operacao );
    
private:    
    logger::DebugWriter *m_log;

};