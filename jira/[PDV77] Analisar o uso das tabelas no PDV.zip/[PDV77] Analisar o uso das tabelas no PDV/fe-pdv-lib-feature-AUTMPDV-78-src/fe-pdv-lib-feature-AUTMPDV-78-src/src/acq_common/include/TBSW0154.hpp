#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
	class TBSW0154 : public dbaccess::table
	{
	public:
		TBSW0154();
		TBSW0154( const std::string& whereClause );
		~TBSW0154();

		void bind_columns();

		void set_NUM_PDV( unsigned long a_NUM_PDV );
		void set_DAT_REF( dbm_datetime_t a_DAT_REF );
		void set_COD_TRAN_PRCL( unsigned long a_COD_TRAN_PRCL );
		void set_DAT_PCM( unsigned long a_DAT_PCM );
		void set_COD_STTU_RSMO_VD( unsigned long a_COD_STTU_RSMO_VD );
		void set_COD_BNDR( unsigned long a_COD_BNDR );
		void set_NOM_BNDR( const std::string& a_NOM_BNDR );
		void set_QTD_VD_CRE( oasis_dec_t a_QTD_VD_CRE );
		void set_VAL_TOTL_VD_CRE( oasis_dec_t a_VAL_TOTL_VD_CRE );
		void set_QTD_TOTL_VD_PARC( oasis_dec_t a_QTD_TOTL_VD_PARC );
		void set_VAL_TOTL_VD_PARC( oasis_dec_t a_VAL_TOTL_VD_PARC );
		void set_QTD_CASH_RTTV( oasis_dec_t a_QTD_CASH_RTTV );
		void set_VAL_TOTL_CASH_RTTV( oasis_dec_t a_VAL_TOTL_CASH_RTTV );
		void set_QTD_CASH_PARC( oasis_dec_t a_QTD_CASH_PARC );
		void set_VAL_TOTL_CASH_PARC( oasis_dec_t a_VAL_TOTL_CASH_PARC );
		void set_COD_TERM( const std::string& a_COD_TERM );
		void set_DAT_SLC( dbm_datetime_t a_DAT_SLC );

		unsigned long get_NUM_PDV() const;
		dbm_datetime_t get_DAT_REF() const;
		unsigned long get_COD_TRAN_PRCL() const;
		unsigned long get_DAT_PCM() const;
		unsigned long get_COD_STTU_RSMO_VD() const;
		unsigned long get_COD_BNDR() const;
		const std::string& get_NOM_BNDR() const;
		oasis_dec_t get_QTD_VD_CRE() const;
		oasis_dec_t get_VAL_TOTL_VD_CRE() const;
		oasis_dec_t get_QTD_TOTL_VD_PARC() const;
		oasis_dec_t get_VAL_TOTL_VD_PARC() const;
		oasis_dec_t get_QTD_CASH_RTTV() const;
		oasis_dec_t get_VAL_TOTL_CASH_RTTV() const;
		oasis_dec_t get_QTD_CASH_PARC() const;
		oasis_dec_t get_VAL_TOTL_CASH_PARC() const;
		const std::string& get_COD_TERM() const;
		dbm_datetime_t get_DAT_SLC() const;

		void let_as_is( );

	private:
		unsigned long			m_NUM_PDV;
		dbm_datetime_t			m_DAT_REF;
		unsigned long			m_COD_TRAN_PRCL;
		unsigned long			m_DAT_PCM;
		unsigned long			m_COD_STTU_RSMO_VD;
		unsigned long			m_COD_BNDR;
		std::string				m_NOM_BNDR;
		oasis_dec_t				m_QTD_VD_CRE;
		oasis_dec_t				m_VAL_TOTL_VD_CRE;
		oasis_dec_t				m_QTD_TOTL_VD_PARC;
		oasis_dec_t				m_VAL_TOTL_VD_PARC;
		oasis_dec_t				m_QTD_CASH_RTTV;
		oasis_dec_t				m_VAL_TOTL_CASH_RTTV;
		oasis_dec_t				m_QTD_CASH_PARC;
		oasis_dec_t				m_VAL_TOTL_CASH_PARC;
		std::string				m_COD_TERM;
		dbm_datetime_t		    m_DAT_SLC;

		int m_NUM_PDV_pos;
		int m_DAT_REF_pos;
		int m_COD_TRAN_PRCL_pos;
		int m_DAT_PCM_pos;
		int m_COD_STTU_RSMO_VD_pos;
		int m_COD_BNDR_pos;
		int m_NOM_BNDR_pos;
		int m_QTD_VD_CRE_pos;
		int m_VAL_TOTL_VD_CRE_pos;
		int m_QTD_TOTL_VD_PARC_pos;
		int m_VAL_TOTL_VD_PARC_pos;
		int m_QTD_CASH_RTTV_pos;
		int m_VAL_TOTL_CASH_RTTV_pos;
		int m_QTD_CASH_PARC_pos;
		int m_VAL_TOTL_CASH_PARC_pos;
		int m_COD_TERM_pos;
		int m_DAT_SLC_pos;

        int m_DAT_SLC_ind_null;
	};
} //namespace dbaccess_common

