#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
	class TBSW0051 : public dbaccess::table
	{
	public:
		TBSW0051();
		TBSW0051( const std::string& whereClause );
		~TBSW0051();

		void bind_columns();

		void set_NUM_PDV( unsigned long a_NUM_PDV );
		void set_COD_STTU_REG( const std::string& a_COD_STTU_REG );

		unsigned long get_NUM_PDV() const;
		const std::string& get_COD_STTU_REG() const;



	private:
		unsigned long				m_NUM_PDV;
		std::string				m_COD_STTU_REG;

		int m_NUM_PDV_pos;
		int m_COD_STTU_REG_pos;
	};
} //namespace dbaccess_common

