#pragma once

#include <string>
#include <DBM3.h> 
#include "TBSW0093.hpp"
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"


class TBSW0093RegrasFormatacaoBase
{
public:
	TBSW0093RegrasFormatacaoBase( );
	~TBSW0093RegrasFormatacaoBase( );

	virtual void DAT_MOV_TRAN	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void NUM_SEQ_UNC	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void COD_OPER_ESTR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void COD_ITEM		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void TIP_MODO_TRAN	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void TIP_MSG		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void TIP_VD_SAID	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void NUM_OPER_ETD	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void NUM_RD_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void COD_MOT_RSPS_EXT	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void COD_OPER_CNFR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void COD_MOT_ESTR_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );
	virtual void COD_MOT_RSPS_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params, const acq_common::OPERACAO &operacao );

        // INSERT'
	virtual void insert_DAT_MOV_TRAN	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_NUM_SEQ_UNC		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_COD_OPER_ESTR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_COD_ITEM		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_TIP_MODO_TRAN	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_TIP_MSG		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_TIP_VD_SAID		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_NUM_OPER_ETD	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_NUM_RD_DEST		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_COD_MOT_RSPS_EXT	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_COD_OPER_CNFR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_COD_MOT_ESTR_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void insert_COD_MOT_RSPS_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );

        // UPDATE
	virtual void update_DAT_MOV_TRAN	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_NUM_SEQ_UNC		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_COD_OPER_ESTR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_COD_ITEM		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_TIP_MODO_TRAN	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_TIP_MSG		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_TIP_VD_SAID		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_NUM_OPER_ETD	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_NUM_RD_DEST		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_COD_MOT_RSPS_EXT	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_COD_OPER_CNFR	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_COD_MOT_ESTR_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void update_COD_MOT_RSPS_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );

        // GEN
	virtual void gen_DAT_MOV_TRAN		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_NUM_SEQ_UNC		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_COD_OPER_ESTR		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_COD_ITEM		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_TIP_MODO_TRAN		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_TIP_MSG		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_TIP_VD_SAID		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_NUM_OPER_ETD		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_NUM_RD_DEST		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_COD_MOT_RSPS_EXT	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_COD_OPER_CNFR		( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_COD_MOT_ESTR_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );
	virtual void gen_COD_MOT_RSPS_DEST	( dbaccess_common::TBSW0093 &tbsw0093, const struct acq_common::tbsw0093_params &tbsw0093_params );

private:    
    logger::DebugWriter *m_log;

};


