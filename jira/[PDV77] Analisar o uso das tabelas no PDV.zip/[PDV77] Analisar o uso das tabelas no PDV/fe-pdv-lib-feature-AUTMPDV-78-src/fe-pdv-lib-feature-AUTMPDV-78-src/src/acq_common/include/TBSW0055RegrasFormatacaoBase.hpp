#pragma once
#include "TBSW0055.hpp"
#include "logger/DebugWriter.hpp"
#include <AcqUtils.hpp>
#include <defines.hpp>

class TBSW0055RegrasFormatacaoBase
{
public:
    TBSW0055RegrasFormatacaoBase();
    ~TBSW0055RegrasFormatacaoBase();

    virtual void DAT_MOV_TRAN( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao );
    virtual void NUM_SEQ_UNC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao );
    virtual void COD_UCAF( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao );
    virtual void IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao );
    virtual void COD_VLDC_ATTC_PRTO_SGRA( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params, const acq_common::OPERACAO &operacao );

    // Metodos especificos para INSERT
    virtual void insert_DAT_MOV_TRAN( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );
    virtual void insert_NUM_SEQ_UNC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );
    virtual void insert_COD_UCAF( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );
    virtual void insert_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );
    virtual void insert_COD_VLDC_ATTC_PRTO_SGRA( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );

    // Metodos especificos para UPDATE
    virtual void update_DAT_MOV_TRAN( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );
    virtual void update_NUM_SEQ_UNC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );
    virtual void update_COD_UCAF( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );
    virtual void update_IND_NVL_SGRA_KMRC( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );
    virtual void update_COD_VLDC_ATTC_PRTO_SGRA( dbaccess_common::TBSW0055 &tbsw0055, const struct acq_common::tbsw0055_params &params );

protected:
    virtual std::string formata_COD_UCAF( const struct acq_common::tbsw0055_params &params );
    logger::DebugWriter *m_log;
};