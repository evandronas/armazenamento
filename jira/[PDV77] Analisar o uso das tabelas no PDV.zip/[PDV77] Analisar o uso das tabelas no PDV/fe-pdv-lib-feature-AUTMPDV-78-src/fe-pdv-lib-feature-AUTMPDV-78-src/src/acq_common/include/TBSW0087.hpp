/*
*******************************************************************
* (c) Copyright 2012 Fidelity National Information Services       *
*                                                                 *
* FIS Confidential                                                *
*******************************************************************
*/

/*
/ -------------------------------------------------------------------------------------------------
/ Sigla: SW - FE-GEN
/ Descri��o:
/ Conte�do:
/ Autor: t694037, Fernando Luiz do Amaral Junior
/ Data de Cria��o: 2012, 21 de julho
/ Hist�rico Mudan�as: 2012, 21 de julho, t694037, Fernando Luiz do Amaral Junior, Versao Inicial
/ -------------------------------------------------------------------------------------------------
*/
#pragma once
#include <dbm.h>
#include "dbaccess/table.hpp"

namespace dbaccess_common
{
	class TBSW0087 : public dbaccess::table
	{
	public:
		TBSW0087( );
		TBSW0087( const std::string &str );
		virtual ~TBSW0087( );
		void bind_columns( );
		const std::string& getNUM_PRFX_CAR( ) const;
		const std::string& getCOD_SGL_PAI( ) const;
		const std::string& getCOD_STTU_REG( ) const;
		dbm_datetime_t getDAT_ATLZ_REG( ) const;
		void setNUM_PRFX_CAR( const std::string& a_NUM_PRFX_CAR );
		void setCOD_SGL_PAI( const std::string&	a_COD_SGL_PAI );
		void setCOD_STTU_REG( const std::string& a_COD_STTU_REG );
		void setDAT_ATLZ_REG( dbm_datetime_t a_DAT_ATLZ_REG );
	private:
		int m_NUM_PRFX_CAR_pos;
		int m_COD_SGL_PAI_pos;
		int m_COD_STTU_REG_pos;
		int m_DAT_ATLZ_REG_pos;
		std::string m_NUM_PRFX_CAR;
		std::string m_COD_SGL_PAI;
		std::string m_COD_STTU_REG;
		dbm_datetime_t m_DAT_ATLZ_REG;
	};
}

