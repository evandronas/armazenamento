#pragma once

#include <string>
#include <DBM3.h> //oasis_dec_t
#include "TBSW1039.hpp"
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"
#include <AcqUtils.hpp>

class TBSW1039RegrasFormatacaoBase
{
    public:
        TBSW1039RegrasFormatacaoBase( );
        ~TBSW1039RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN       ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC        ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_MSG_ISO_ORGL   ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_STAN_ORGL      ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao );
        virtual void DTH_STTU_TRAN_ORGL ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_ISTT_ACQR_ORGL ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params, const acq_common::OPERACAO &operacao );

        // GEN
        virtual void gen_DAT_MOV_TRAN       ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void gen_NUM_SEQ_UNC        ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void gen_COD_MSG_ISO_ORGL   ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void gen_NUM_STAN_ORGL      ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void gen_DTH_STTU_TRAN_ORGL ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void gen_COD_ISTT_ACQR_ORGL ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );

        // INSERT
        virtual void insert_DAT_MOV_TRAN        ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void insert_NUM_SEQ_UNC         ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void insert_COD_MSG_ISO_ORGL    ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void insert_NUM_STAN_ORGL       ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void insert_DTH_STTU_TRAN_ORGL  ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void insert_COD_ISTT_ACQR_ORGL  ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );

        // UPDATE
        virtual void update_DAT_MOV_TRAN        ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void update_NUM_SEQ_UNC         ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void update_COD_MSG_ISO_ORGL    ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void update_NUM_STAN_ORGL       ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void update_DTH_STTU_TRAN_ORGL  ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );
        virtual void update_COD_ISTT_ACQR_ORGL  ( dbaccess_common::TBSW1039 &tbsw1039, const struct acq_common::tbsw1039_params &params );

        logger::DebugWriter *m_log;

};
