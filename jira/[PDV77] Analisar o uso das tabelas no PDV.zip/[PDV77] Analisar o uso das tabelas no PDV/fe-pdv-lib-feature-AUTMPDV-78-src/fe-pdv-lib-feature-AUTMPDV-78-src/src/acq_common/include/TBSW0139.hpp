#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0139 : public dbaccess::table
    {
        public:
            TBSW0139();
            TBSW0139( const std::string & str );
            virtual ~TBSW0139();

            void initialize();
            void bind_columns();

            void set_COD_TERM( const std::string& a_COD_TERM );
            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_COD_PNPD_PDV( const std::string& a_COD_PNPD_PDV );
            void set_TIP_CIP( const std::string& a_TIP_CIP );
            void set_NUM_PDV( unsigned long a_NUM_PDV );
            void set_NUM_VERS_SRVD_PDV( const std::string& a_NUM_VERS_SRVD_PDV );
            void set_NUM_VERS_CLIT( const std::string& a_NUM_VERS_CLIT );
            void set_NUM_VERS_APLV_RCD( const std::string& a_NUM_VERS_APLV_RCD );
            void set_NUM_VERS_SFTW_BBLT_PNPD( const std::string& a_NUM_VERS_SFTW_BBLT_PNPD );
            void set_NUM_VERS_ESPF_BBLT_PNPD( const std::string& a_NUM_VERS_ESPF_BBLT_PNPD );
            void set_COD_FBRC_PDV( const std::string& a_COD_FBRC_PDV );
            void set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL );
            void set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL );
            void set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL );
            void set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR );
            void set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR );
            void set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR );
            void set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ );
            void set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ );
            void set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ );
            void set_TIP_GRU_TERM( const std::string& a_TIP_GRU_TERM );

            const std::string& get_COD_TERM() const;
            unsigned long get_DAT_MOV_TRAN() const;
            const std::string& get_COD_PNPD_PDV() const;
            const std::string& get_TIP_CIP() const;
            unsigned long get_NUM_PDV() const;
            const std::string& get_NUM_VERS_SRVD_PDV() const;
            const std::string& get_NUM_VERS_CLIT() const;
            const std::string& get_NUM_VERS_APLV_RCD() const;
            const std::string& get_NUM_VERS_SFTW_BBLT_PNPD() const;
            const std::string& get_NUM_VERS_ESPF_BBLT_PNPD() const;
            const std::string& get_COD_FBRC_PDV() const;
            const std::string& get_NOM_SITE_ACQR_ORGL() const;
            const std::string& get_NOM_HOST_ACQR_ORGL() const;
            const std::string& get_NOM_FE_ACQR_ORGL() const;
            const std::string& get_NOM_SITE_ISSR() const;
            const std::string& get_NOM_HOST_ISSR() const;
            const std::string& get_NOM_FE_ISSR() const;
            const std::string& get_NOM_SITE_ACQR_ATLZ() const;
            const std::string& get_NOM_HOST_ACQR_ATLZ() const;
            const std::string& get_NOM_FE_ACQR_ATLZ() const;
            const std::string& get_TIP_GRU_TERM() const;
            
        private:
            std::string     m_COD_TERM;
            unsigned long   m_DAT_MOV_TRAN;
            std::string     m_COD_PNPD_PDV;
            std::string     m_TIP_CIP;
            unsigned long   m_NUM_PDV;
            std::string     m_NUM_VERS_SRVD_PDV;
            std::string     m_NUM_VERS_CLIT;
            std::string     m_NUM_VERS_APLV_RCD;
            std::string     m_NUM_VERS_SFTW_BBLT_PNPD;
            std::string     m_NUM_VERS_ESPF_BBLT_PNPD;
            std::string     m_COD_FBRC_PDV;
            std::string     m_NOM_SITE_ACQR_ORGL;
            std::string     m_NOM_HOST_ACQR_ORGL;
            std::string     m_NOM_FE_ACQR_ORGL;
            std::string     m_NOM_SITE_ISSR;
            std::string     m_NOM_HOST_ISSR;
            std::string     m_NOM_FE_ISSR;
            std::string     m_NOM_SITE_ACQR_ATLZ;
            std::string     m_NOM_HOST_ACQR_ATLZ;
            std::string     m_NOM_FE_ACQR_ATLZ;
            std::string     m_TIP_GRU_TERM;

            int m_COD_TERM_pos;
            int m_DAT_MOV_TRAN_pos;
            int m_COD_PNPD_PDV_pos;
            int m_TIP_CIP_pos;
            int m_NUM_PDV_pos;
            int m_NUM_VERS_SRVD_PDV_pos;
            int m_NUM_VERS_CLIT_pos;
            int m_NUM_VERS_APLV_RCD_pos;
            int m_NUM_VERS_SFTW_BBLT_PNPD_pos;
            int m_NUM_VERS_ESPF_BBLT_PNPD_pos;
            int m_COD_FBRC_PDV_pos;
            int m_NOM_SITE_ACQR_ORGL_pos;
            int m_NOM_HOST_ACQR_ORGL_pos;
            int m_NOM_FE_ACQR_ORGL_pos;
            int m_NOM_SITE_ISSR_pos;
            int m_NOM_HOST_ISSR_pos;
            int m_NOM_FE_ISSR_pos;
            int m_NOM_SITE_ACQR_ATLZ_pos;
            int m_NOM_HOST_ACQR_ATLZ_pos;
            int m_NOM_FE_ACQR_ATLZ_pos;
            int m_TIP_GRU_TERM_pos;

            int m_NUM_PDV_ind_null;

    };

}//namespace dbaccess_common



