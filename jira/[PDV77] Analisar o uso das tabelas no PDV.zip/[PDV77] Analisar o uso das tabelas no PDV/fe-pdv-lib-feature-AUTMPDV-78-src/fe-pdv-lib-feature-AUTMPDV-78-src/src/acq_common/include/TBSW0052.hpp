#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0052 : public dbaccess::table
    {
        public:
            
            TBSW0052( );
            TBSW0052( const std::string& whereClause );
            ~TBSW0052( );
            
            void bind_columns( );
            
            void set_DAT_MOV_TRAN( unsigned long a_DAT_MOV_TRAN );
            void set_NUM_SEQ_UNC( unsigned long a_NUM_SEQ_UNC );
            void set_DTH_GMT( dbm_datetime_t a_DTH_GMT );
            void set_DTH_INI_TRAN( dbm_datetime_t a_DTH_INI_TRAN );
            void set_COD_MSG_ISO( unsigned long a_COD_MSG_ISO );
            void set_COD_PCM_ISO( unsigned long a_COD_PCM_ISO );
            void set_TIP_TRAN( unsigned long a_TIP_TRAN );
            void set_IND_RD_ORG( const std::string& a_IND_RD_ORG );
            void set_NUM_ESTB( unsigned long a_NUM_ESTB );
            void set_COD_DDD_ESTB( const std::string& a_COD_DDD_ESTB );
            void set_NUM_TEL_ESTB( oasis_dec_t a_NUM_TEL_ESTB );
            void set_COD_TERM( const std::string& a_COD_TERM );
            void set_NUM_TRAN_RD( oasis_dec_t a_NUM_TRAN_RD );
            void set_COD_RAM_ATVD( unsigned long a_COD_RAM_ATVD );
            void set_COD_POS_ENTR_MODO( const std::string& a_COD_POS_ENTR_MODO );
            void set_COD_BNDR( unsigned long a_COD_BNDR );
            void set_COD_EMSR( unsigned long a_COD_EMSR );
            void set_NUM_ID_CAR( unsigned long a_NUM_ID_CAR );
            void set_NUM_CAR( const std::string& a_NUM_CAR );
            void set_COD_PAIS_CAR( const std::string& a_COD_PAIS_CAR );
            void set_IND_VLDC_CVC( const std::string& a_IND_VLDC_CVC );
            void set_COD_OPER_TRAN( const std::string& a_COD_OPER_TRAN );
            void set_COD_MOED( const std::string& a_COD_MOED );
            void set_VAL_TRAN( oasis_dec_t a_VAL_TRAN );
            void set_VAL_TRAN_DLR( oasis_dec_t a_VAL_TRAN_DLR );
            void set_VAL_COT_DLR( oasis_dec_t a_VAL_COT_DLR );
            void set_QTD_PRCL( unsigned long a_QTD_PRCL );
            void set_VAL_PRCL( oasis_dec_t a_VAL_PRCL );
            void set_NUM_AUT( const std::string& a_NUM_AUT );
            void set_COD_MOT_AUT( const std::string& a_COD_MOT_AUT );
            void set_NUM_MOT_RSPS( unsigned long a_NUM_MOT_RSPS );
            void set_COD_MOT_SW( const std::string& a_COD_MOT_SW );
            void set_COD_MOT_ISO_EMSR( const std::string& a_COD_MOT_ISO_EMSR );
            void set_TXT_MSG_RSPS( const std::string& a_TXT_MSG_RSPS );
            void set_IND_STTU_TRAN( const std::string& a_IND_STTU_TRAN );
            void set_DTH_STTU_TRAN( dbm_datetime_t a_DTH_STTU_TRAN );
            void set_COD_CNDC_CNFR( const std::string& a_COD_CNDC_CNFR );
            void set_DTH_CPTR( dbm_datetime_t a_DTH_CPTR );
            void set_COD_OPER_ESTR( const std::string& a_COD_OPER_ESTR );
            void set_COD_TERM_ESTR( const std::string& a_COD_TERM_ESTR );
            void set_TIP_PES( const std::string& a_TIP_PES );
            void set_VAL_TX( oasis_dec_t a_VAL_TX );
            void set_DTH_DFZM_TRAN( dbm_datetime_t a_DTH_DFZM_TRAN );
            void set_DTH_ESTR_TRAN( dbm_datetime_t a_DTH_ESTR_TRAN );
            void set_NOM_SITE_ACQR_ORGL( const std::string& a_NOM_SITE_ACQR_ORGL );
            void set_NOM_HOST_ACQR_ORGL( const std::string& a_NOM_HOST_ACQR_ORGL );
            void set_NOM_FE_ACQR_ORGL( const std::string& a_NOM_FE_ACQR_ORGL );
            void set_NOM_SITE_ISSR( const std::string& a_NOM_SITE_ISSR );
            void set_NOM_HOST_ISSR( const std::string& a_NOM_HOST_ISSR );
            void set_NOM_FE_ISSR( const std::string& a_NOM_FE_ISSR );
            void set_NOM_SITE_ACQR_ATLZ( const std::string& a_NOM_SITE_ACQR_ATLZ );
            void set_NOM_HOST_ACQR_ATLZ( const std::string& a_NOM_HOST_ACQR_ATLZ );
            void set_NOM_FE_ACQR_ATLZ( const std::string& a_NOM_FE_ACQR_ATLZ );
            void set_NUM_AVSO_AUT( const std::string& a_NUM_AVSO_AUT );
            void set_COD_AUT_ICH( const std::string& a_COD_AUT_ICH );
            void set_DTH_TRAN_OFLN( dbm_datetime_t a_DTH_TRAN_OFLN );
            void set_DTH_TRAN_EMSR( dbm_datetime_t a_DTH_TRAN_EMSR );

            void set_NTWK_ID_ACQR_ATLZ( const std::string& a_NTWK_ID_ACQR_ATLZ );
            void set_NTWK_ID_ACQR_ORGL( const std::string& a_NTWK_ID_ACQR_ORGL );
            void set_NTWK_ID_ROUTE_ATLZ( const std::string& a_NTWK_ID_ROUTE_ATLZ );
            void set_NTWK_ID_ROUTE_ORGL( const std::string& a_NTWK_ID_ROUTE_ORGL );
            void set_NTWK_ID_ISSR_ATLZ( const std::string& a_NTWK_ID_ISSR_ATLZ );
            void set_m_NTWK_ID_ISSR_ORGL( const std::string& a_NTWK_ID_ISSR_ORGL );

            
            void set_NTWK_ID_ACQR_ATLZ_ind_null(const std::string& a_NTWK_ID_ACQR_ATLZ);
            void set_NTWK_ID_ACQR_ORGL_ind_null(const std::string& a_NTWK_ID_ACQR_ORGL);
            void set_NTWK_ID_ROUTE_ATLZ_ind_null(const std::string& a_NTWK_ID_ROUTE_ATLZ);
            void set_NTWK_ID_ROUTE_ORGL_ind_null(const std::string& a_NTWK_ID_ROUTE_ORGL);
            void set_NTWK_ID_ISSR_ATLZ_ind_null(const std::string& a_NTWK_ID_ISSR_ATLZ);
            void set_NTWK_ID_ISSR_ORGL_ind_null(const std::string& a_NTWK_ID_ISSR_ORGL);              
            
            
            
            unsigned long get_DAT_MOV_TRAN( ) const;
            unsigned long get_NUM_SEQ_UNC( ) const;
            dbm_datetime_t get_DTH_GMT( ) const;
            dbm_datetime_t get_DTH_INI_TRAN( ) const;
            unsigned long get_COD_MSG_ISO( ) const;
            unsigned long get_COD_PCM_ISO( ) const;
            unsigned long get_TIP_TRAN( ) const;
            const std::string& get_IND_RD_ORG( ) const;
            unsigned long get_NUM_ESTB( ) const;
            const std::string& get_COD_DDD_ESTB( ) const;
            oasis_dec_t get_NUM_TEL_ESTB( ) const;
            const std::string& get_COD_TERM( ) const;
            oasis_dec_t get_NUM_TRAN_RD( ) const;
            unsigned long get_COD_RAM_ATVD( ) const;
            const std::string& get_COD_POS_ENTR_MODO( ) const;
            unsigned long get_COD_BNDR( ) const;
            unsigned long get_COD_EMSR( ) const;
            unsigned long get_NUM_ID_CAR( ) const;
            const std::string& get_NUM_CAR( ) const;
            const std::string& get_COD_PAIS_CAR( ) const;
            const std::string& get_IND_VLDC_CVC( ) const;
            const std::string& get_COD_OPER_TRAN( ) const;
            const std::string& get_COD_MOED( ) const;
            oasis_dec_t get_VAL_TRAN( ) const;
            oasis_dec_t get_VAL_TRAN_DLR( ) const;
            oasis_dec_t get_VAL_COT_DLR( ) const;
            unsigned long get_QTD_PRCL( ) const;
            oasis_dec_t get_VAL_PRCL( ) const;
            const std::string& get_NUM_AUT( ) const;
            const std::string& get_COD_MOT_AUT( ) const;
            unsigned long get_NUM_MOT_RSPS( ) const;
            const std::string& get_COD_MOT_SW( ) const;
            const std::string& get_COD_MOT_ISO_EMSR( ) const;
            const std::string& get_TXT_MSG_RSPS( ) const;
            const std::string& get_IND_STTU_TRAN( ) const;
            dbm_datetime_t get_DTH_STTU_TRAN( ) const;
            const std::string& get_COD_CNDC_CNFR( ) const;
            dbm_datetime_t get_DTH_CPTR( ) const;
            const std::string& get_COD_OPER_ESTR( ) const;
            const std::string& get_COD_TERM_ESTR( ) const;
            const std::string& get_TIP_PES( ) const;
            oasis_dec_t get_VAL_TX( ) const;
            dbm_datetime_t get_DTH_DFZM_TRAN( ) const;
            dbm_datetime_t get_DTH_ESTR_TRAN( ) const;
            const std::string& get_NOM_SITE_ACQR_ORGL( ) const;
            const std::string& get_NOM_HOST_ACQR_ORGL( ) const;
            const std::string& get_NOM_FE_ACQR_ORGL( ) const;
            const std::string& get_NOM_SITE_ISSR( ) const;
            const std::string& get_NOM_HOST_ISSR( ) const;
            const std::string& get_NOM_FE_ISSR( ) const;
            const std::string& get_NOM_SITE_ACQR_ATLZ( ) const;
            const std::string& get_NOM_HOST_ACQR_ATLZ( ) const;
            const std::string& get_NOM_FE_ACQR_ATLZ( ) const;
            const std::string& get_NUM_AVSO_AUT( ) const;
            const std::string& get_COD_AUT_ICH( ) const;
            dbm_datetime_t get_DTH_TRAN_OFLN( ) const;
            dbm_datetime_t get_DTH_TRAN_EMSR( ) const;
            
            const std::string& get_NTWK_ID_ACQR_ATLZ( ) const;
            const std::string& get_NTWK_ID_ACQR_ORGL(  ) const;
            const std::string& get_NTWK_ID_ROUTE_ATLZ(  ) const;
            const std::string& get_NTWK_ID_ROUTE_ORGL(  ) const;
            const std::string& get_NTWK_ID_ISSR_ATLZ( ) const;
            const std::string& get_m_NTWK_ID_ISSR_ORGL(  ) const;

            const std::string&  get_NTWK_ID_ACQR_ATLZ_ind_null() const;
            const std::string&  get_NTWK_ID_ACQR_ORGL_ind_null() const;
            const std::string&  get_NTWK_ID_ROUTE_ATLZ_ind_null() const;
            const std::string&  get_NTWK_ID_ROUTE_ORGL_ind_null() const;
            const std::string&  get_NTWK_ID_ISSR_ATLZ_ind_null() const;
            const std::string&  get_NTWK_ID_ISSR_ORGL_ind_null() const;
                        
            void let_DTH_DFZM_TRAN_as_is( );
            void let_DTH_ESTR_TRAN_as_is( );
            void let_DTH_TRAN_EMSR_as_is( );
            void let_DTH_CPTR_as_is( );
            void let_DTH_TRAN_OFLN_as_is( );
	    //void let_m_DTH_DFZM_TRAN_as_is( );
	    //void let_m_DTH_ESTR_TRAN_as_is( );
            //void let_m_DTH_TRAN_EMSR_as_is( );
            //void let_m_DTH_CPTR_as_is( );
            //void let_m_DTH_TRAN_OFLN_as_is( );
            
            void let_NUM_ID_CAR_as_is( );
            void let_NUM_MOT_RSPS_as_is( );
            void let_VAL_TRAN_as_is( );
            void let_VAL_TRAN_DLR_as_is( );
            void let_VAL_TX_as_is( );
            void let_VAL_PRCL_as_is( );
            void let_VAL_COT_DLR_as_is( );
            void let_NUM_TEL_ESTB_as_is( );
            
            void let_NTWK_ID_ACQR_ATLZ_ind_null();
            void let_NTWK_ID_ACQR_ORGL_ind_null();
            void let_NTWK_ID_ROUTE_ATLZ_ind_null();
            void let_NTWK_ID_ROUTE_ORGL_ind_null();
            void let_NTWK_ID_ISSR_ATLZ_ind_null();
            void let_NTWK_ID_ISSR_ORGL_ind_null();              
            
        private:
            
            unsigned long    m_DAT_MOV_TRAN;
            unsigned long    m_NUM_SEQ_UNC;
            dbm_datetime_t   m_DTH_GMT;
            dbm_datetime_t   m_DTH_INI_TRAN;
            unsigned long    m_COD_MSG_ISO;
            unsigned long    m_COD_PCM_ISO;
            unsigned long    m_TIP_TRAN;
            std::string      m_IND_RD_ORG;
            unsigned long    m_NUM_ESTB;
            std::string      m_COD_DDD_ESTB;
            oasis_dec_t      m_NUM_TEL_ESTB;
            std::string      m_COD_TERM;
            oasis_dec_t      m_NUM_TRAN_RD;
            unsigned long    m_COD_RAM_ATVD;
            std::string      m_COD_POS_ENTR_MODO;
            unsigned long    m_COD_BNDR;
            unsigned long    m_COD_EMSR;
            unsigned long    m_NUM_ID_CAR;
            std::string      m_NUM_CAR;
            std::string      m_COD_PAIS_CAR;
            std::string      m_IND_VLDC_CVC;
            std::string      m_COD_OPER_TRAN;
            std::string      m_COD_MOED;
            oasis_dec_t      m_VAL_TRAN;
            oasis_dec_t      m_VAL_TRAN_DLR;
            oasis_dec_t      m_VAL_COT_DLR;
            unsigned long    m_QTD_PRCL;
            oasis_dec_t      m_VAL_PRCL;
            std::string      m_NUM_AUT;
            std::string      m_COD_MOT_AUT;
            unsigned long    m_NUM_MOT_RSPS;
            std::string      m_COD_MOT_SW;
            std::string      m_COD_MOT_ISO_EMSR;
            std::string      m_TXT_MSG_RSPS;
            std::string      m_IND_STTU_TRAN;
            dbm_datetime_t   m_DTH_STTU_TRAN;
            std::string      m_COD_CNDC_CNFR;
            dbm_datetime_t   m_DTH_CPTR;
            std::string      m_COD_OPER_ESTR;
            std::string      m_COD_TERM_ESTR;
            std::string      m_TIP_PES;
            oasis_dec_t      m_VAL_TX;
            dbm_datetime_t   m_DTH_DFZM_TRAN;
            dbm_datetime_t   m_DTH_ESTR_TRAN;
            std::string      m_NOM_SITE_ACQR_ORGL;
            std::string      m_NOM_HOST_ACQR_ORGL;
            std::string      m_NOM_FE_ACQR_ORGL;
            std::string      m_NOM_SITE_ISSR;
            std::string      m_NOM_HOST_ISSR;
            std::string      m_NOM_FE_ISSR;
            std::string      m_NOM_SITE_ACQR_ATLZ;
            std::string      m_NOM_HOST_ACQR_ATLZ;
            std::string      m_NOM_FE_ACQR_ATLZ;
            std::string      m_NUM_AVSO_AUT;
            std::string      m_COD_AUT_ICH;
            dbm_datetime_t   m_DTH_TRAN_OFLN;
            dbm_datetime_t   m_DTH_TRAN_EMSR;
            
            
            std::string      m_NTWK_ID_ACQR_ATLZ;
            std::string      m_NTWK_ID_ACQR_ORGL;
            std::string      m_NTWK_ID_ROUTE_ATLZ;
            std::string      m_NTWK_ID_ROUTE_ORGL;
            std::string      m_NTWK_ID_ISSR_ATLZ;
            std::string      m_NTWK_ID_ISSR_ORGL;
                        
            int m_DAT_MOV_TRAN_pos;
            int m_NUM_SEQ_UNC_pos;
            int m_DTH_GMT_pos;
            int m_DTH_INI_TRAN_pos;
            int m_COD_MSG_ISO_pos;
            int m_COD_PCM_ISO_pos;
            int m_TIP_TRAN_pos;
            int m_IND_RD_ORG_pos;
            int m_NUM_ESTB_pos;
            int m_COD_DDD_ESTB_pos;
            int m_NUM_TEL_ESTB_pos;
            int m_COD_TERM_pos;
            int m_NUM_TRAN_RD_pos;
            int m_COD_RAM_ATVD_pos;
            int m_COD_POS_ENTR_MODO_pos;
            int m_COD_BNDR_pos;
            int m_COD_EMSR_pos;
            int m_NUM_ID_CAR_pos;
            int m_NUM_CAR_pos;
            int m_COD_PAIS_CAR_pos;
            int m_IND_VLDC_CVC_pos;
            int m_COD_OPER_TRAN_pos;
            int m_COD_MOED_pos;
            int m_VAL_TRAN_pos;
            int m_VAL_TRAN_DLR_pos;
            int m_VAL_COT_DLR_pos;
            int m_QTD_PRCL_pos;
            int m_VAL_PRCL_pos;
            int m_NUM_AUT_pos;
            int m_COD_MOT_AUT_pos;
            int m_NUM_MOT_RSPS_pos;
            int m_COD_MOT_SW_pos;
            int m_COD_MOT_ISO_EMSR_pos;
            int m_TXT_MSG_RSPS_pos;
            int m_IND_STTU_TRAN_pos;
            int m_DTH_STTU_TRAN_pos;
            int m_COD_CNDC_CNFR_pos;
            int m_DTH_CPTR_pos;
            int m_COD_OPER_ESTR_pos;
            int m_COD_TERM_ESTR_pos;
            int m_TIP_PES_pos;
            int m_VAL_TX_pos;
            int m_DTH_DFZM_TRAN_pos;
            int m_DTH_ESTR_TRAN_pos;
            int m_NOM_SITE_ACQR_ORGL_pos;
            int m_NOM_HOST_ACQR_ORGL_pos;
            int m_NOM_FE_ACQR_ORGL_pos;
            int m_NOM_SITE_ISSR_pos;
            int m_NOM_HOST_ISSR_pos;
            int m_NOM_FE_ISSR_pos;
            int m_NOM_SITE_ACQR_ATLZ_pos;
            int m_NOM_HOST_ACQR_ATLZ_pos;
            int m_NOM_FE_ACQR_ATLZ_pos;
            int m_NUM_AVSO_AUT_pos;
            int m_COD_AUT_ICH_pos;
            int m_DTH_TRAN_OFLN_pos;
            int m_DTH_TRAN_EMSR_pos;
            
            int m_NTWK_ID_ACQR_ATLZ_pos;
            int m_NTWK_ID_ACQR_ORGL_pos;
            int m_NTWK_ID_ROUTE_ATLZ_pos;
            int m_NTWK_ID_ROUTE_ORGL_pos;
            int m_NTWK_ID_ISSR_ATLZ_pos;
            int m_NTWK_ID_ISSR_ORGL_pos;
                        
            int m_VAL_TRAN_ind_null_DLR;
            int m_DTH_DFZM_TRAN_ind_null;
            int m_DTH_ESTR_TRAN_ind_null;
            int m_DTH_TRAN_EMSR_ind_null;
            int m_DTH_CPTR_ind_null;
            int m_DTH_TRAN_OFLN_ind_null;
            int m_NUM_ID_CAR_ind_null;
            int m_NUM_MOT_RSPS_ind_null;
            int m_VAL_TRAN_ind_null;
            int m_VAL_TRAN_DLR_ind_null;
            int m_VAL_TX_ind_null;
            int m_VAL_PRCL_ind_null;
            int m_VAL_COT_DLR_ind_null;
            int m_NUM_TEL_ESTB_ind_null;
            
            int m_NTWK_ID_ACQR_ATLZ_ind_null;
            int m_NTWK_ID_ACQR_ORGL_ind_null;
            int m_NTWK_ID_ROUTE_ATLZ_ind_null;
            int m_NTWK_ID_ROUTE_ORGL_ind_null;
            int m_NTWK_ID_ISSR_ATLZ_ind_null;
            int m_NTWK_ID_ISSR_ORGL_ind_null;

            int m_DAT_CNFR_PAUZ_ind_null;
            int m_DTH_CNFR_ind_null;
            int m_NUM_ESTB_CNFR_ind_null;
            int m_QTD_PRCL_CNFR_ind_null;
            int m_NUM_SEQ_UNC_CNFR_ind_null;
            int m_DAT_MOV_TRAN_CNFR_ind_null;
            int m_DAT_CAN_PAUZ_ind_null;
            int m_VAL_EFTV_CPTR_ind_null;
    };
} //namespace dbaccess_common


