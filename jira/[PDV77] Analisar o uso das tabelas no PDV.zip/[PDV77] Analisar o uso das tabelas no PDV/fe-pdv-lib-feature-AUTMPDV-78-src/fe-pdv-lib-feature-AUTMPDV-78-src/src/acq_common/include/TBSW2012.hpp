#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
	class TBSW2012 : public dbaccess::table
	{
	public:
		TBSW2012();
		TBSW2012( const std::string& whereClause );
		~TBSW2012();

		void bind_columns();

		void set_COD_ROTA_ADMN( unsigned long a_COD_ROTA_ADMN );
		void set_COD_MSG_ISO( unsigned long a_COD_MSG_ISO );
		void set_COD_PCM_ISO( unsigned long a_COD_PCM_ISO );
		void set_NETWORK_ID( const std::string& a_NETWORK_ID );
		void set_NOM_HOST_ACQR( const std::string& a_NOM_HOST_ACQR );
		void set_NOM_FE_ACQR( const std::string& a_NOM_FE_ACQR );
		void set_COD_ISSR_SW( unsigned long a_COD_ISSR_SW );

		unsigned long get_COD_ROTA_ADMN() const;
		unsigned long get_COD_MSG_ISO() const;
		unsigned long get_COD_PCM_ISO() const;
		const std::string& get_NETWORK_ID() const;
		const std::string& get_NOM_HOST_ACQR() const;
		const std::string& get_NOM_FE_ACQR() const;
		unsigned long get_COD_ISSR_SW() const;



	private:
		unsigned long				m_COD_ROTA_ADMN;
		unsigned long				m_COD_MSG_ISO;
		unsigned long				m_COD_PCM_ISO;
		std::string				m_NETWORK_ID;
		std::string				m_NOM_HOST_ACQR;
		std::string				m_NOM_FE_ACQR;
		unsigned long				m_COD_ISSR_SW;

		int m_COD_ROTA_ADMN_pos;
		int m_COD_MSG_ISO_pos;
		int m_COD_PCM_ISO_pos;
		int m_NETWORK_ID_pos;
		int m_NOM_HOST_ACQR_pos;
		int m_NOM_FE_ACQR_pos;
		int m_COD_ISSR_SW_pos;
	};
} //namespace dbaccess_common

