#pragma once

#include "TBSW0101.hpp"
#include<string>
#include <AcqUtils.hpp>
#include <defines.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

class TBSW0101RegrasFormatacaoBase
{
    public:
        TBSW0101RegrasFormatacaoBase( );
        ~TBSW0101RegrasFormatacaoBase( );

        virtual void DAT_MOV_TRAN       ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params, const acq_common::OPERACAO &operacao );
        virtual void NUM_SEQ_UNC        ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_NVL_SGRA_TKN   ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params, const acq_common::OPERACAO &operacao );
        virtual void COD_REF_CTA_PGMN   ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params, const acq_common::OPERACAO &operacao );

        // Metodos utilizados por campos que tem input generico (INSERT/UPDATE)
        virtual void gen_DAT_MOV_TRAN       ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void gen_NUM_SEQ_UNC        ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void gen_COD_NVL_SGRA_TKN   ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void gen_COD_REF_CTA_PGMN   ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );

        // Metodos especificos para INSERT
        virtual void insert_DAT_MOV_TRAN        ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void insert_NUM_SEQ_UNC         ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void insert_COD_NVL_SGRA_TKN    ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void insert_COD_REF_CTA_PGMN    ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );

        // Metodos especificos para UPDATE
        virtual void update_DAT_MOV_TRAN        ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void update_NUM_SEQ_UNC         ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void update_COD_NVL_SGRA_TKN    ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );
        virtual void update_COD_REF_CTA_PGMN    ( dbaccess_common::TBSW0101 &tbsw0101, const struct acq_common::tbsw0101_params &params );

        logger::DebugWriter *m_log;

}; // class TBSW0101RegrasFormatacaoBase
