/* Copyright 2018 Rede S.A.
Autor : Danilo Oliveira
Empresa : FIS
*/

#pragma once

#include <string>
#include <DBM3.h> //oasis_dec_t
#include "Tbsw0162.hpp"
#include <defines.hpp>

#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

/// Tbsw0162RegrasFormatacaoBase
/// Classe que contem os metodos de formatacao dos campos da tabela TBSW0162
/// EF/ET: 000
/// Historico: 04/05/2018 - Danilo Oliveira - 000 - Implementacao inicial
class Tbsw0162RegrasFormatacaoBase
{
public:
    // Declaracao de construtores/destrutores
    Tbsw0162RegrasFormatacaoBase( );
    ~Tbsw0162RegrasFormatacaoBase( );

    // Assinatura dos metodos de interface com o Plugin
    virtual void DataMovimentoTransacao( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao );
    virtual void NumeroSequencialUnico( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao );
    virtual void CodigoTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao );
    virtual void NumeroEstabelecimento( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao );
    virtual void NumeroSerieTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162, const acq_common::OPERACAO &operacao );
    // Assinatura dos metodos genericos (utilizados quando a formatacao da insercao e do update sao iguais)
    virtual void GenDataMovimentoTransacao( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void GenNumeroSequencialUnico( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void GenCodigoTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void GenNumeroEstabelecimento( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void GenNumeroSerieTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    // Assinatura dos metodos de formatacao para operacao de insert
    virtual void InsertDataMovimentoTransacao( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void InsertNumeroSequencialUnico( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void InsertCodigoTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void InsertNumeroEstabelecimento( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void InsertNumeroSerieTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    // Assinatura dos metodos de formatacao para operacao de update
    virtual void UpdateDataMovimentoTransacao( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void UpdateNumeroSequencialUnico( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void UpdateCodigoTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void UpdateNumeroEstabelecimento( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );
    virtual void UpdateNumeroSerieTerminal( dbaccess_common::Tbsw0162 &tbsw0162, const struct acq_common::Tbsw0162Parametros &paramsTbsw0162 );

    // Declaracao de atributos
    logger::DebugWriter *m_log;
};
