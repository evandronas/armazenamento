#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_common
{
	class TBSW0093 : public dbaccess::table
	{
	public:
		TBSW0093();
		TBSW0093( const std::string& whereClause );
		~TBSW0093();

		void initialize();
		void bind_columns();

		void set_DAT_MOV_TRAN	  ( unsigned long a_DAT_MOV_TRAN );
		void set_NUM_SEQ_UNC	  ( oasis_dec_t a_NUM_SEQ_UNC );
		void set_COD_OPER_ESTR	  ( const std::string& a_COD_OPER_ESTR );
		void set_COD_ITEM	  ( const std::string& a_COD_ITEM );
		void set_TIP_MODO_TRAN	  ( const std::string& a_TIP_MODO_TRAN );
		void set_TIP_MSG	  ( const std::string& a_TIP_MSG );
		void set_TIP_VD_SAID	  ( const std::string& a_TIP_VD_SAID );
		void set_NUM_OPER_ETD	  ( oasis_dec_t a_NUM_OPER_ETD );
		void set_NUM_RD_DEST	  ( unsigned long a_NUM_RD_DEST );
		void set_COD_MOT_RSPS_EXT ( const std::string& a_COD_MOT_RSPS_EXT );
		void set_COD_OPER_CNFR	  ( const std::string& a_COD_OPER_CNFR );
		void set_COD_MOT_ESTR_DEST( const std::string& a_COD_MOT_ESTR_DEST );
		void set_COD_MOT_RSPS_DEST( const std::string& a_COD_MOT_RSPS_DEST );

        
		unsigned long		get_DAT_MOV_TRAN() const;
		oasis_dec_t   		get_NUM_SEQ_UNC() const;
		const std::string& 	get_COD_OPER_ESTR() const;
		const std::string& 	get_COD_ITEM() const;
		const std::string& 	get_TIP_MODO_TRAN() const;
		const std::string& 	get_TIP_MSG() const;
		const std::string& 	get_TIP_VD_SAID() const;
		oasis_dec_t 		get_NUM_OPER_ETD() const;
		unsigned long 		get_NUM_RD_DEST() const;
		const std::string& 	get_COD_MOT_RSPS_EXT() const;
		const std::string& 	get_COD_OPER_CNFR() const;
		const std::string& 	get_COD_MOT_ESTR_DEST() const;
		const std::string& 	get_COD_MOT_RSPS_DEST() const;
        void show( int nvl );



	private:
		unsigned long		m_DAT_MOV_TRAN;
		oasis_dec_t		m_NUM_SEQ_UNC;

		std::string		m_COD_OPER_ESTR;
		std::string		m_COD_ITEM;
		std::string		m_TIP_MODO_TRAN;
		std::string		m_TIP_MSG;
		std::string		m_TIP_VD_SAID;
		oasis_dec_t		m_NUM_OPER_ETD;
		unsigned long		m_NUM_RD_DEST;
		std::string		m_COD_MOT_RSPS_EXT;
		std::string		m_COD_OPER_CNFR;
		std::string		m_COD_MOT_ESTR_DEST;
		std::string		m_COD_MOT_RSPS_DEST;


		int m_DAT_MOV_TRAN_pos;
		int m_NUM_SEQ_UNC_pos;
		int m_COD_OPER_ESTR_pos;
		int m_COD_ITEM_pos;
		int m_TIP_MODO_TRAN_pos;
		int m_TIP_MSG_pos;
		int m_TIP_VD_SAID_pos;
		int m_NUM_OPER_ETD_pos;
		int m_NUM_RD_DEST_pos;
		int m_COD_MOT_RSPS_EXT_pos;
		int m_COD_OPER_CNFR_pos;
		int m_COD_MOT_ESTR_DEST_pos;
		int m_COD_MOT_RSPS_DEST_pos;
        
        
        void showxxx( const char *name, unsigned long campo, bool isNull );
        void showxxx( const char *name, dbm_datetime_t campo, bool isNull );
        void showxxx( const char *name, const std::string& campo, bool isNull );
        void showxxx( const char *name, oasis_dec_t campo, bool isNull );
        void showxxx( const char *name, sw_date_t campo, bool isNull );
        
        logger::DebugWriter *m_log;

	};
} //namespace dbaccess_common

