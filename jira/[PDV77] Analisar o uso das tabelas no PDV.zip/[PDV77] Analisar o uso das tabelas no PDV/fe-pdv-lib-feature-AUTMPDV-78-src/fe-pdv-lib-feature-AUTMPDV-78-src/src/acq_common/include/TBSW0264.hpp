#pragma once

#include <dbm.h>
#include <dbaccess/table.hpp>
#include "logger/DebugWriter.hpp"
#include "logger/Level.hpp"

namespace dbaccess_pos
{
class TBSW0264 : public dbaccess::table
{
public:
	TBSW0264();
	TBSW0264( const std::string& whereClause );
	~TBSW0264();

	void bind_columns();
	void initialize();

	void set_COD_EMP( unsigned long a_COD_EMP );
	void set_COD_RAM_ATVD( unsigned long a_COD_RAM_ATVD );
	void set_COD_RAM_ATVD_EMP( unsigned long a_COD_RAM_ATVD_EMP );
	void set_IND_PRE_AUT( const std::string& a_IND_PRE_AUT );
	void set_DTH_ATLZ_REG( dbm_datetime_t  a_DTH_ATLZ_REG );

	unsigned long		get_COD_EMP() const;
	unsigned long		get_COD_RAM_ATVD() const;
	unsigned long		get_COD_RAM_ATVD_EMP() const;
	const std::string	get_IND_PRE_AUT() const;
	dbm_datetime_t		get_DTH_ATLZ_REG() const;

	void let_DTH_ATLZ_REG_as_is();

private:

	int m_COD_EMP_pos;
	int m_COD_RAM_ATVD_pos;
	int m_COD_RAM_ATVD_EMP_pos;
	int m_IND_PRE_AUT_pos;
	int m_DTH_ATLZ_REG_pos;

	unsigned long m_COD_EMP;
	unsigned long m_COD_RAM_ATVD;
	unsigned long m_COD_RAM_ATVD_EMP;
	std::string m_IND_PRE_AUT;
	dbm_datetime_t	m_DTH_ATLZ_REG;
	
	// Teste de conteudo do registro
	logger::DebugWriter *m_log;

};
} //namespace dbaccess_pos

