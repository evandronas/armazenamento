/*
/ -------------------------------------------------------------------------
/ Sigla: <plugins_pos::TBSW0043>
/ Descri��o: <Arquivo de implementa��o da classe plugins_pos::TBSW0043Loader>
/ Conte�do: <Lista de M�dulos definidos>
/ Autor: <689687, Felipe Bezerra>
/ Data de Cria��o: <Thu Nov 01 09:26:32 2012>
/ Hist�rico Mudan�as: <Data, M�dulo, Autor, Descri��o da Mudan�a>
/ ---------------------------------------------------------------------------
*/

#pragma once
#include <dbm.h>
#include <dbaccess/table.hpp>

namespace dbaccess_common
{
    class TBSW0043 : public dbaccess::table
    {
    public:
        TBSW0043( );
        TBSW0043( const std::string & str );
        virtual ~TBSW0043( );

        void bind_columns( );

        const std::string& get_COD_TERM( ) const;
        const std::string& get_COD_STTU_REG( ) const;
        const dbm_datetime_t& get_DAT_ATLZ_REG( ) const;
        long get_COD_FUN( ) const;

        void set_COD_TERM( const std::string& a_COD_TERM );
        void set_COD_STTU_REG( const std::string& a_COD_STTU_REG );
        void set_DAT_ATLZ_REG( const dbm_datetime_t& a_DAT_ATLZ_REG );
        void set_COD_FUN( long a_COD_FUN );


    private:
        int m_COD_TERM_pos;
        int m_COD_STTU_REG_pos;
        int m_DAT_ATLZ_REG_pos;
        int m_COD_FUN_pos;

        std::string m_COD_TERM;
        std::string m_COD_STTU_REG;
        dbm_datetime_t m_DAT_ATLZ_REG;
        long m_COD_FUN;

    };
}//namespace dbaccess_common



