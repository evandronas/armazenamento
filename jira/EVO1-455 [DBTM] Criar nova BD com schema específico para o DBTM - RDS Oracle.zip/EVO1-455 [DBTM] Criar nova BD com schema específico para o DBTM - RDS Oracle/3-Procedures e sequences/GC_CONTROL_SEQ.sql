--------------------------------------------------------
--  Arquivo criado - Quinta-feira-Outubro-28-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence GG_CONTROL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "SW_DBTM"."GG_CONTROL_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
