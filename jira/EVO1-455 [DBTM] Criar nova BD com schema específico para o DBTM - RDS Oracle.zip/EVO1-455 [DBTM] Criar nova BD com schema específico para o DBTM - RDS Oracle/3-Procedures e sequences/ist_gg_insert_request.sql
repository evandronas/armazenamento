create or replace procedure ist_gg_insert_request(p_cmd in varchar2, p_group_id in varchar2, p_when_requested out date, p_req_id out number) as
pragma autonomous_transaction;
ts date;
w_req_id number;
begin
	ts := sysdate;
	w_req_id := gg_control_seq.nextval;
	insert into gg_control (cmd, group_id, created_on, req_id) values (p_cmd, p_group_id, ts, w_req_id);
	p_req_id := w_req_id;
	p_when_requested := ts;
	commit;
end;