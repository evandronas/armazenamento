create or replace procedure ist_gg_query_request(p_req_id in number, p_processed_on out date, p_status out varchar2, p_extra_info out varchar2) as
begin
    select processed_on, status, extra_info into p_processed_on, p_status, p_extra_info from gg_control where req_id = p_req_id and
processed_on is not null;
exception
    when NO_DATA_FOUND then
        p_processed_on := null;
        p_status := null;
        p_extra_info := null;
end;