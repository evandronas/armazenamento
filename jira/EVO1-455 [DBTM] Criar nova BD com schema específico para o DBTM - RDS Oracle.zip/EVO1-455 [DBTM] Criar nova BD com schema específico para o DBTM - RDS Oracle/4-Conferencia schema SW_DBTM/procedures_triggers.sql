SET LINESIZE 100;
SET PAGESIZE 1000;

select * from DBA_PROCEDURES 
--where OWNER = 'SW_OWN'
where OWNER = 'SW_DBTM'
;
