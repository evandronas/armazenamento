SET LINESIZE 100;
SET PAGESIZE 1000;

select * from all_objects 
where object_type = 'SEQUENCE'
--AND OWNER = 'SW_OWN'
AND OWNER = 'SW_DBTM'
;
