SET LINESIZE 100;
SET PAGESIZE 1000;

SELECT table_name, column_name, DATA_TYPE, DATA_LENGTH, NULLABLE, owner
  FROM all_tab_cols
-- WHERE owner = 'SW_OWN'
 WHERE owner = 'SW_DBTM'
 ORDER BY TABLE_NAME, COLUMN_NAME;
