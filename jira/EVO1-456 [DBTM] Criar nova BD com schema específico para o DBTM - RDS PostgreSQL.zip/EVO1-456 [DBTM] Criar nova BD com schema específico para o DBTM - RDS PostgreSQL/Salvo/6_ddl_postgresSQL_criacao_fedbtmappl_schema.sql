-- DROP SCHEMA fedbtmappl;

CREATE SCHEMA fedbtmappl AUTHORIZATION fedbtm;
