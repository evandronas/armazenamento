CREATE TABLE dbarede.TBSW0008(
     COD_BIN_INFR char(19),
     COD_BIN_SUPR char(19),
     COD_ID_MMBR numeric(11),
     COD_PAIS char(3),
     COD_PROD char(3),
     COD_RGAO char(1),
     COD_STTU_REG char(1),
     DAT_INCL_REG date,
     IND_BIN_TKN char(1),
     IND_ROTA_BIN char(1),
     TIP_BIN char(1)
);

CREATE TABLE dbarede.TBSW0131(
     DAT_MOV_TRAN date,
     NUM_SEQ_UNC_CCR numeric(9),
     TXT_ADIC_RD_EXT char(20),
     TXT_ADIC_SNHA char(1)
);

CREATE TABLE dbarede.TBSW0264(
     COD_EMP numeric(3),
     COD_RAM_ATVD numeric(5),
     COD_RAM_ATVD_EMP numeric(5),
     DTH_ATLZ_REG date,
     IND_PRE_AUT char(1)
);

CREATE TABLE dbarede.TBSW0265(
     COD_BNDR numeric(5),
     DTH_ATLZ_REG date,
     NUM_BIN_FIM char(6),
     NUM_BIN_INI char(6),
     TIP_TRAN numeric(5)
);

CREATE TABLE dbarede.TBSW1002(
     COD_PAIS_MSTO char(3),
     COD_PRFX_MSTO char(11),
     DAT_INCL_REG_MSTO numeric(8),
     IND_CDC numeric(1),
     IND_CNFR_PSTV numeric(1),
     IND_CSHB numeric(1),
     IND_MSTO numeric(1),
     IND_PARCELE_MAIS numeric(1),
     IND_PRE_DATADO numeric(1),
     NUM_ID_BIN_DEB numeric(11)
);

CREATE TABLE dbarede.TBSW1004(
     COD_RSPS_TRAN char(4),
     COD_TIP_MSG char(4),
     DAT_LQDC_EFTV numeric(8),
     DAT_MOV_TRAN numeric(8),
     DAT_STTU_TRAN numeric(8),
     HOR_ULT_TRCA_CHAV numeric(6),
     IND_STTU_TRAN char(1),
     NUM_HIST_TRAN_LQDC numeric(38),
     NUM_SEQ_UNC numeric(9)
);

CREATE TABLE dbarede.TBSW1005(
     COD_EMSR numeric(4),
     COD_PCM char(6),
     COD_STTU_ENVO char(1),
     COD_TERM char(8),
     COD_TRK_CAR char(40),
     DAT_CTB_RD date,
     DAT_MOV_TRAN numeric(8),
     DES_CPL_MOT_RD_EXT char(25),
     HOR_INI_TRAN date,
     IND_ACAO char(1),
     NUM_AUT_EMSR char(6),
     NUM_CAR char(19),
     NUM_ESTB numeric(10),
     NUM_SEQ_UNC numeric(9),
     TIP_TRAN numeric(4),
     VAL_TRAN numeric(19,4)
);

CREATE TABLE dbarede.TBSW1007(
     COD_AUT_MTC char(9),
     COD_BNDR numeric(3),
     COD_CV numeric(12),
     COD_ELE_ADIC char(20),
     COD_MODO_ENTR_POS char(3),
     COD_MOED char(3),
     COD_MOT_RD_EXT char(3),
     COD_RAM_ATVD_MTC numeric(4),
     COD_TERM char(8),
     DAT_MOV_TRAN numeric(8),
     DAT_PCM_AJST_TRAN numeric(8),
     DAT_STTU_TRAN numeric(8),
     DES_CPL_MOT_RD_EXT char(25),
     HOR_AJST_TRAN numeric(6),
     HOR_INI_TRAN numeric(6),
     IND_STTU_TRAN char(1),
     IND_TIP_AJST numeric(38),
     NOM_LOCL_ESTB char(40),
     NUM_CAR char(19),
     NUM_ESTB numeric(9),
     NUM_SEQ_UNC numeric(9),
     VAL_LQDC numeric(19,2),
     VAL_RISC numeric(19,2),
     VAL_SLDO_PARC numeric(19,2),
     VAL_TRAN numeric(19,2)
);

CREATE TABLE dbarede.TBSW1008(
     COD_AUT_MTC char(9),
     COD_BNDR numeric(3),
     COD_CLI numeric(5),
     COD_CV numeric(12),
     COD_ELE_ADIC char(20),
     COD_MODO_ENTR_POS char(3),
     COD_MOED char(3),
     COD_MOT_NGTV_RD_EXT char(3),
     COD_RAM_ATVD_MTC numeric(4),
     COD_REF_EMSR char(15),
     COD_TERM char(8),
     COD_TRK_CAR varchar(40),
     DAT_LQDC_EFTV numeric(8),
     DAT_MOV_TRAN numeric(8),
     DAT_PRDT numeric(8),
     DAT_STTU_TRAN numeric(8),
     DES_CPL_MOT_RD_EXT char(25),
     HOR_INI_TRAN numeric(6),
     HOR_LQDC_TRAN numeric(6),
     IND_DSTR numeric(5),
     IND_PRRD_TRAN numeric(5),
     IND_STTU_TRAN char(1),
     NOM_LOCL_ESTB char(40),
     NUM_CAR char(19),
     NUM_ESTB numeric(9),
     NUM_SEQ_UNC numeric(9),
     TIP_LQDC numeric(5),
     VAL_LQDC numeric(19,2),
     VAL_RISC numeric(19,2),
     VAL_TRAN numeric(19,2)
);

CREATE TABLE dbarede.TBSW1009(
     DAT_ULT_TRCA_CHAV numeric(8),
     HOR_ULT_TRCA_CHAV numeric(6),
     NUM_ID_TRCA_CHAV_MSTO numeric(38)
);

CREATE TABLE dbarede.TBSW1012(
     DAT_CRTE_MSTO date,
     HOR_CRTE_MSTO date,
     IND_PAIS_CRTE char(1)
);

CREATE TABLE dbarede.TBSW2001(
     COD_BIN_ISSR char(6),
     COD_BIN_PRCS char(6),
     COD_CHAV_INFR char(9),
     COD_CHAV_SUPR char(9),
     COD_DOM_CAR char(1),
     COD_ID_MMBR_VISA numeric(11),
     COD_PAIS_CAR char(2),
     COD_PAIS_EMSR char(2),
     COD_PROD char(2),
     COD_RGAO_CAR char(1),
     COD_RGAO_EMSR char(1),
     DAT_INCL_REG_VISA numeric(8),
     IND_AMB char(1),
     IND_BIN_TKN char(1),
     IND_DA_NVL_2 char(1),
     IND_DA_NVL_3 char(1),
     IND_EXTN_TIP_PROD char(1),
     IND_JOG_ONLN char(1),
     IND_MSG_CAR_CMC char(1),
     IND_SERV_CAR_CMC char(1),
     IND_TCNL char(1),
     IND_TRSF_MNTR char(1),
     IND_TX_VAL_AGRD char(1),
     IND_VAL_ORGL char(1),
     TAM_RNG_CTA char(2),
     TIP_BIN char(3),
     TIP_CAR char(1),
     TIP_CAR_MLTP char(1),
     TIP_CHCK_DIG_VRFC char(1),
     TIP_ISSR char(3),
     TIP_USO char(1),
     TIP_USO_INT_1 varchar(18),
     TIP_USO_INT_2 char(1)
);

CREATE TABLE dbarede.TBSW2002(
     COD_OPID_ULT_ATLZ char(8),
     DES_TIP_TRAN char(40),
     DTH_ULT_ATLZ date,
     TIP_TRAN char(2)
);

CREATE TABLE dbarede.TBSW2003(
     COD_BNDR numeric(2),
     COD_EST char(2),
     COD_PAIS char(3),
     COD_RGAO numeric(2),
     DAT_EFTV numeric(8),
     NUM_BIN char(19),
     NUM_MMBR_ID char(11),
     QTD_MXO_PRCL numeric(2),
     TAM_BIN numeric(2),
     TAM_PAN numeric(2),
     TIP_BIN numeric(1),
     TIP_EFTV char(1)
);

CREATE TABLE dbarede.TBSW2004(
     COD_RET_EXEC numeric(3),
     COD_SCRP_CMDR char(8),
     COD_STTU_EXEC numeric(1),
     DTH_FIM_EXEC date,
     DTH_INI_EXEC date,
     NOM_HOST_EXEC varchar(16),
     NUM_ARQ_PCD numeric(9),
     NUM_PR_BTC numeric(5),
     NUM_PR_SIS_OPRC numeric(12)
);

CREATE TABLE dbarede.TBSW2005(
     COD_OPID_ULT_ATLZ char(8),
     COD_SCRP_CMDR char(8),
     DES_SCRP_CMDR varchar(256),
     DTH_ULT_ATLZ date
);

CREATE TABLE dbarede.TBSW2006(
     COD_OPID_ULT_ATLZ char(8),
     DES_PR_BTC varchar(256),
     DTH_ULT_ATLZ date,
     NOM_PR_BTC varchar(64),
     NUM_PR_BTC numeric(5)
);

CREATE TABLE dbarede.TBSW2007(
     COD_OPID_ULT_ATLZ char(8),
     COD_RET_EXEC numeric(3),
     DES_COD_RET_EXEC varchar(256),
     DTH_ULT_ATLZ date
);

CREATE TABLE dbarede.TBSW2008(
     COD_STTU_ARQ_PCD numeric(1),
     NOM_ARQ_PCD varchar(256),
     NUM_ARQ_PCD numeric(9),
     QTD_REG_PCD numeric(9),
     QTD_REG_PCD_ERR numeric(9),
     QTD_REG_PCD_SCSO numeric(9),
     TIP_OPE_ARQ_PCD char(1),
     TXT_LST_FE_MOV_ARQ_PCD varchar(256),
     TXT_LST_HOST_MOV_ARQ_PCD varchar(256),
     TXT_LST_SITE_MOV_ARQ_PCD varchar(256)
);

CREATE TABLE dbarede.TBSW2010(
     COD_ISSR_SW numeric(10),
     COD_ROTA numeric(10),
     COD_TIP_TRAN char(1),
     IND_PRRD numeric(5),
     NETWORK_ID varchar(10),
     NETWORK_ID_VAN varchar(10),
     NOM_FE_ACQR varchar(16),
     NOM_HOST_ACQR varchar(16),
     NUM_BIN_CAR_FIM varchar(10),
     NUM_BIN_CAR_INI varchar(10)
);

CREATE TABLE dbarede.TBSW2011(
     COD_BNDR numeric(5),
     COD_EMSR_SW numeric(10),
     COD_FE_EMSR varchar(16),
     COD_ISSR_SW numeric(10),
     NOM_EMSR_SW varchar(30)
);

CREATE TABLE dbarede.TBSW2013(
     COD_ISSR_SW numeric(10),
     COD_ROTA_PRVT_LBEL numeric(10),
     NETWORK_ID varchar(10),
     NOM_FE_ACQR varchar(16),
     NOM_HOST_ACQR varchar(16)
);

CREATE TABLE dbarede.TBSW2014(
     COD_ID_MMBR numeric(11),
     COD_PAIS char(3),
     COD_PRFX_MSTO char(11),
     DAT_INCL_REG date,
     IND_BIN_TKN char(1),
     IND_CASH_BACK numeric(1),
     IND_CDC numeric(1),
     IND_CNFR_PSTV numeric(1),
     IND_DEB_MTC numeric(1),
     IND_MSTO numeric(1),
     IND_VD_PRDT numeric(1),
     TAM_PRFX_MSTO numeric(2)
);

CREATE TABLE dbarede.TBSW2020(
     COD_PR_EXEC numeric(10),
     DAT_RESET date,
     DTH_ULT_ATLZ date,
     NOM_HOST varchar(16),
     SGL_SITE char(3),
     VAL_ATU_NUM_SEQ_UNC numeric(12),
     VAL_RESET_NUM_SEQ_UNC numeric(12),
     VAL_RNG_NUM_SEQ_UNC numeric(5)
);

