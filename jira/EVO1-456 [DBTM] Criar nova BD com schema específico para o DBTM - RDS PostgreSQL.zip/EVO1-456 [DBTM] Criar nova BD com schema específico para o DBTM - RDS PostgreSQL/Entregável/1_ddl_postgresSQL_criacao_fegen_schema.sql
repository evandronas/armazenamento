-- CREATE USER fegen;
CREATE ROLE fegen NOSUPERUSER CREATEDB CREATEROLE INHERIT LOGIN PASSWORD 'switch77';

-- DROP SCHEMA fegen;

CREATE SCHEMA fegen AUTHORIZATION dbarede;
-- fegen.tbsw0008 definition

-- Drop table

-- DROP TABLE fegen.tbsw0008;

CREATE TABLE fegen.tbsw0008 (
	cod_bin_infr bpchar(19) NOT NULL,
	cod_bin_supr bpchar(19) NOT NULL,
	cod_id_mmbr numeric(11) NULL,
	cod_pais bpchar(3) NULL,
	cod_prod bpchar(3) NULL,
	cod_rgao bpchar(1) NULL,
	cod_sttu_reg bpchar(1) NULL,
	dat_incl_reg date NULL,
	ind_bin_tkn bpchar(1) NULL,
	ind_rota_bin bpchar(1) NULL,
	tip_bin bpchar(1) NULL,
	CONSTRAINT cc01sw0008_1 CHECK ((ind_bin_tkn = ANY (ARRAY['S'::bpchar, 'N'::bpchar]))),
	CONSTRAINT cc02sw0008_1 CHECK (((ind_rota_bin IS NULL) OR (ind_rota_bin = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))),
	CONSTRAINT sw0008u0_1 PRIMARY KEY (cod_bin_infr, cod_bin_supr),
	CONSTRAINT sys_c00212628_1 CHECK ((cod_bin_infr IS NOT NULL)),
	CONSTRAINT sys_c00212629_1 CHECK ((cod_bin_supr IS NOT NULL)),
	CONSTRAINT sys_c00212630_1 CHECK ((cod_id_mmbr IS NOT NULL)),
	CONSTRAINT sys_c00212631_1 CHECK ((cod_rgao IS NOT NULL)),
	CONSTRAINT sys_c00212632_1 CHECK ((cod_pais IS NOT NULL)),
	CONSTRAINT sys_c00212633_1 CHECK ((cod_prod IS NOT NULL)),
	CONSTRAINT sys_c00212634_1 CHECK ((dat_incl_reg IS NOT NULL)),
	CONSTRAINT sys_c00212635_1 CHECK ((cod_sttu_reg IS NOT NULL)),
	CONSTRAINT sys_c00212636_1 CHECK ((tip_bin IS NOT NULL))
);


-- fegen.tbsw0131 definition

-- Drop table

-- DROP TABLE fegen.tbsw0131;

CREATE TABLE fegen.tbsw0131 (
	dat_mov_tran date NOT NULL,
	num_seq_unc_ccr numeric(9) NOT NULL,
	txt_adic_rd_ext bpchar(20) NULL,
	txt_adic_snha bpchar(1) NULL,
	CONSTRAINT cc01sw0131 CHECK ((txt_adic_snha = ANY (ARRAY['S'::bpchar, 'P'::bpchar]))),
	CONSTRAINT sw0131n1 PRIMARY KEY (num_seq_unc_ccr, dat_mov_tran),
	CONSTRAINT sys_c00212637 CHECK ((num_seq_unc_ccr IS NOT NULL)),
	CONSTRAINT sys_c00212638 CHECK ((dat_mov_tran IS NOT NULL))
);


-- fegen.tbsw0264 definition

-- Drop table

-- DROP TABLE fegen.tbsw0264;

CREATE TABLE fegen.tbsw0264 (
	cod_emp numeric(3) NOT NULL,
	cod_ram_atvd numeric(5) NOT NULL,
	cod_ram_atvd_emp numeric(5) NULL,
	dth_atlz_reg date NULL,
	ind_pre_aut bpchar(1) NULL,
	CONSTRAINT sw0264u0 PRIMARY KEY (cod_emp, cod_ram_atvd),
	CONSTRAINT sys_c00213677 CHECK ((cod_emp IS NOT NULL)),
	CONSTRAINT sys_c00213678 CHECK ((cod_ram_atvd IS NOT NULL)),
	CONSTRAINT sys_c00213679 CHECK ((cod_ram_atvd_emp IS NOT NULL)),
	CONSTRAINT sys_c00213680 CHECK ((ind_pre_aut IS NOT NULL))
);


-- fegen.tbsw0265 definition

-- Drop table

-- DROP TABLE fegen.tbsw0265;

CREATE TABLE fegen.tbsw0265 (
	cod_bndr numeric(5) NOT NULL,
	dth_atlz_reg date NULL,
	num_bin_fim bpchar(6) NOT NULL,
	num_bin_ini bpchar(6) NOT NULL,
	tip_tran numeric(5) NOT NULL,
	CONSTRAINT sw0265u0 PRIMARY KEY (num_bin_ini, num_bin_fim, cod_bndr, tip_tran),
	CONSTRAINT sys_c00212162 CHECK ((num_bin_ini IS NOT NULL)),
	CONSTRAINT sys_c00212163 CHECK ((num_bin_fim IS NOT NULL)),
	CONSTRAINT sys_c00212164 CHECK ((cod_bndr IS NOT NULL)),
	CONSTRAINT sys_c00212165 CHECK ((tip_tran IS NOT NULL))
);


-- fegen.tbsw2001 definition

-- Drop table

-- DROP TABLE fegen.tbsw2001;

CREATE TABLE fegen.tbsw2001 (
	cod_bin_issr bpchar(6) NULL,
	cod_bin_prcs bpchar(6) NULL,
	cod_chav_infr bpchar(9) NOT NULL,
	cod_chav_supr bpchar(9) NOT NULL,
	cod_dom_car bpchar(1) NULL,
	cod_id_mmbr_visa numeric(11) NULL,
	cod_pais_car bpchar(2) NULL,
	cod_pais_emsr bpchar(2) NULL,
	cod_prod bpchar(2) NULL,
	cod_rgao_car bpchar(1) NULL,
	cod_rgao_emsr bpchar(1) NULL,
	dat_incl_reg_visa numeric(8) NULL,
	ind_amb bpchar(1) NULL,
	ind_bin_tkn bpchar(1) NULL,
	ind_da_nvl_2 bpchar(1) NULL,
	ind_da_nvl_3 bpchar(1) NULL,
	ind_extn_tip_prod bpchar(1) NULL,
	ind_jog_onln bpchar(1) NULL,
	ind_msg_car_cmc bpchar(1) NULL,
	ind_serv_car_cmc bpchar(1) NULL,
	ind_tcnl bpchar(1) NULL,
	ind_trsf_mntr bpchar(1) NULL,
	ind_tx_val_agrd bpchar(1) NULL,
	ind_val_orgl bpchar(1) NULL,
	tam_rng_cta bpchar(2) NULL,
	tip_bin bpchar(3) NOT NULL,
	tip_car bpchar(1) NULL,
	tip_car_mltp bpchar(1) NULL,
	tip_chck_dig_vrfc bpchar(1) NULL,
	tip_issr bpchar(3) NOT NULL,
	tip_uso bpchar(1) NULL,
	tip_uso_int_1 varchar(18) NULL,
	tip_uso_int_2 bpchar(1) NULL,
	CONSTRAINT cc01sw2001 CHECK ((ind_bin_tkn = ANY (ARRAY['S'::bpchar, 'N'::bpchar]))),
	CONSTRAINT sw2001u0 PRIMARY KEY (cod_chav_supr, tip_bin, cod_chav_infr, tip_issr),
	CONSTRAINT sys_c00214141 CHECK ((cod_chav_supr IS NOT NULL)),
	CONSTRAINT sys_c00214142 CHECK ((tip_bin IS NOT NULL)),
	CONSTRAINT sys_c00214143 CHECK ((cod_chav_infr IS NOT NULL)),
	CONSTRAINT sys_c00214144 CHECK ((tip_issr IS NOT NULL)),
	CONSTRAINT sys_c00214145 CHECK ((cod_bin_issr IS NOT NULL)),
	CONSTRAINT sys_c00214146 CHECK ((tip_chck_dig_vrfc IS NOT NULL)),
	CONSTRAINT sys_c00214147 CHECK ((tam_rng_cta IS NOT NULL)),
	CONSTRAINT sys_c00214148 CHECK ((tip_car IS NOT NULL)),
	CONSTRAINT sys_c00214149 CHECK ((tip_uso IS NOT NULL)),
	CONSTRAINT sys_c00214150 CHECK ((cod_bin_prcs IS NOT NULL)),
	CONSTRAINT sys_c00214151 CHECK ((cod_dom_car IS NOT NULL)),
	CONSTRAINT sys_c00214152 CHECK ((cod_rgao_emsr IS NOT NULL)),
	CONSTRAINT sys_c00214153 CHECK ((cod_pais_emsr IS NOT NULL)),
	CONSTRAINT sys_c00214154 CHECK ((ind_serv_car_cmc IS NOT NULL)),
	CONSTRAINT sys_c00214155 CHECK ((ind_tcnl IS NOT NULL)),
	CONSTRAINT sys_c00214156 CHECK ((cod_rgao_car IS NOT NULL)),
	CONSTRAINT sys_c00214157 CHECK ((cod_pais_car IS NOT NULL)),
	CONSTRAINT sys_c00214158 CHECK ((ind_da_nvl_2 IS NOT NULL)),
	CONSTRAINT sys_c00214159 CHECK ((ind_da_nvl_3 IS NOT NULL)),
	CONSTRAINT sys_c00214160 CHECK ((ind_msg_car_cmc IS NOT NULL)),
	CONSTRAINT sys_c00214161 CHECK ((ind_tx_val_agrd IS NOT NULL)),
	CONSTRAINT sys_c00214162 CHECK ((ind_val_orgl IS NOT NULL)),
	CONSTRAINT sys_c00214163 CHECK ((ind_extn_tip_prod IS NOT NULL)),
	CONSTRAINT sys_c00214164 CHECK ((ind_trsf_mntr IS NOT NULL)),
	CONSTRAINT sys_c00214165 CHECK ((ind_jog_onln IS NOT NULL)),
	CONSTRAINT sys_c00214166 CHECK ((cod_prod IS NOT NULL)),
	CONSTRAINT sys_c00214167 CHECK ((tip_uso_int_1 IS NOT NULL)),
	CONSTRAINT sys_c00214168 CHECK ((ind_amb IS NOT NULL)),
	CONSTRAINT sys_c00214169 CHECK ((tip_uso_int_2 IS NOT NULL)),
	CONSTRAINT sys_c00214170 CHECK ((cod_id_mmbr_visa IS NOT NULL)),
	CONSTRAINT sys_c00214171 CHECK ((dat_incl_reg_visa IS NOT NULL)),
	CONSTRAINT sys_c00214172 CHECK ((tip_car_mltp IS NOT NULL))
);
CREATE INDEX sw2001n1 ON fegen.tbsw2001 USING btree (cod_chav_supr, cod_chav_infr);


-- fegen.tbsw2002 definition

-- Drop table

-- DROP TABLE fegen.tbsw2002;

CREATE TABLE fegen.tbsw2002 (
	cod_opid_ult_atlz bpchar(8) NULL,
	des_tip_tran bpchar(40) NULL,
	dth_ult_atlz date NULL,
	tip_tran bpchar(2) NOT NULL,
	CONSTRAINT sw2002u0 PRIMARY KEY (tip_tran),
	CONSTRAINT sys_c00212166 CHECK ((tip_tran IS NOT NULL)),
	CONSTRAINT sys_c00212167 CHECK ((des_tip_tran IS NOT NULL)),
	CONSTRAINT sys_c00212168 CHECK ((cod_opid_ult_atlz IS NOT NULL)),
	CONSTRAINT sys_c00212169 CHECK ((dth_ult_atlz IS NOT NULL))
);


-- fegen.tbsw2003 definition

-- Drop table

-- DROP TABLE fegen.tbsw2003;

CREATE TABLE fegen.tbsw2003 (
	cod_bndr numeric(2) NOT NULL,
	cod_est bpchar(2) NULL,
	cod_pais bpchar(3) NULL,
	cod_rgao numeric(2) NULL,
	dat_eftv numeric(8) NULL,
	num_bin bpchar(19) NOT NULL,
	num_mmbr_id bpchar(11) NULL,
	qtd_mxo_prcl numeric(2) NULL,
	tam_bin numeric(2) NULL,
	tam_pan numeric(2) NULL,
	tip_bin numeric(1) NULL,
	tip_eftv bpchar(1) NULL,
	CONSTRAINT sw2003u0_1 PRIMARY KEY (num_bin, cod_bndr),
	CONSTRAINT sys_c00214821_1 CHECK ((num_bin IS NOT NULL)),
	CONSTRAINT sys_c00214822_1 CHECK ((cod_bndr IS NOT NULL)),
	CONSTRAINT sys_c00214823_1 CHECK ((tip_bin IS NOT NULL)),
	CONSTRAINT sys_c00214824_1 CHECK ((tam_bin IS NOT NULL)),
	CONSTRAINT sys_c00214825_1 CHECK ((tam_pan IS NOT NULL)),
	CONSTRAINT sys_c00214826_1 CHECK ((cod_pais IS NOT NULL)),
	CONSTRAINT sys_c00214827_1 CHECK ((cod_rgao IS NOT NULL)),
	CONSTRAINT sys_c00214828_1 CHECK ((dat_eftv IS NOT NULL)),
	CONSTRAINT sys_c00214829_1 CHECK ((tip_eftv IS NOT NULL)),
	CONSTRAINT sys_c00214830_1 CHECK ((cod_est IS NOT NULL)),
	CONSTRAINT sys_c00214831_1 CHECK ((num_mmbr_id IS NOT NULL)),
	CONSTRAINT sys_c00214832_1 CHECK ((qtd_mxo_prcl IS NOT NULL))
);
CREATE INDEX sw2003n1_1 ON fegen.tbsw2003 USING btree (num_bin, cod_bndr, tip_bin);


-- fegen.tbsw2005 definition

-- Drop table

-- DROP TABLE fegen.tbsw2005;

CREATE TABLE fegen.tbsw2005 (
	cod_opid_ult_atlz bpchar(8) NULL,
	cod_scrp_cmdr bpchar(8) NOT NULL,
	des_scrp_cmdr varchar(256) NULL,
	dth_ult_atlz date NULL,
	CONSTRAINT sw2005u0_1 PRIMARY KEY (cod_scrp_cmdr),
	CONSTRAINT sys_c00214550_1 CHECK ((cod_scrp_cmdr IS NOT NULL)),
	CONSTRAINT sys_c00214551_1 CHECK ((des_scrp_cmdr IS NOT NULL)),
	CONSTRAINT sys_c00214552_1 CHECK ((dth_ult_atlz IS NOT NULL))
);


-- fegen.tbsw2006 definition

-- Drop table

-- DROP TABLE fegen.tbsw2006;

CREATE TABLE fegen.tbsw2006 (
	cod_opid_ult_atlz bpchar(8) NULL,
	des_pr_btc varchar(256) NULL,
	dth_ult_atlz date NULL,
	nom_pr_btc varchar(64) NULL,
	num_pr_btc numeric(5) NOT NULL,
	CONSTRAINT sw2006u0_1 PRIMARY KEY (num_pr_btc),
	CONSTRAINT sys_c00213311_1 CHECK ((num_pr_btc IS NOT NULL)),
	CONSTRAINT sys_c00213312_1 CHECK ((nom_pr_btc IS NOT NULL)),
	CONSTRAINT sys_c00213313_1 CHECK ((des_pr_btc IS NOT NULL)),
	CONSTRAINT sys_c00213314_1 CHECK ((dth_ult_atlz IS NOT NULL))
);


-- fegen.tbsw2007 definition

-- Drop table

-- DROP TABLE fegen.tbsw2007;

CREATE TABLE fegen.tbsw2007 (
	cod_opid_ult_atlz bpchar(8) NULL,
	cod_ret_exec numeric(3) NOT NULL,
	des_cod_ret_exec varchar(256) NULL,
	dth_ult_atlz date NULL,
	CONSTRAINT sw2007u0_1 PRIMARY KEY (cod_ret_exec),
	CONSTRAINT sys_c00214818_1 CHECK ((cod_ret_exec IS NOT NULL)),
	CONSTRAINT sys_c00214819_1 CHECK ((des_cod_ret_exec IS NOT NULL)),
	CONSTRAINT sys_c00214820_1 CHECK ((dth_ult_atlz IS NOT NULL))
);


-- fegen.tbsw2008 definition

-- Drop table

-- DROP TABLE fegen.tbsw2008;

CREATE TABLE fegen.tbsw2008 (
	cod_sttu_arq_pcd numeric(1) NULL,
	nom_arq_pcd varchar(256) NULL,
	num_arq_pcd numeric(9) NOT NULL,
	qtd_reg_pcd numeric(9) NULL,
	qtd_reg_pcd_err numeric(9) NULL,
	qtd_reg_pcd_scso numeric(9) NULL,
	tip_ope_arq_pcd bpchar(1) NULL,
	txt_lst_fe_mov_arq_pcd varchar(256) NULL,
	txt_lst_host_mov_arq_pcd varchar(256) NULL,
	txt_lst_site_mov_arq_pcd varchar(256) NULL,
	CONSTRAINT cc01sw2008_1 CHECK ((tip_ope_arq_pcd = ANY (ARRAY['I'::bpchar, 'E'::bpchar]))),
	CONSTRAINT sw2008u0_1 PRIMARY KEY (num_arq_pcd),
	CONSTRAINT sys_c00214138_1 CHECK ((num_arq_pcd IS NOT NULL)),
	CONSTRAINT sys_c00214139_1 CHECK ((nom_arq_pcd IS NOT NULL)),
	CONSTRAINT sys_c00214140_1 CHECK ((tip_ope_arq_pcd IS NOT NULL))
);


-- fegen.tbsw2011 definition

-- Drop table

-- DROP TABLE fegen.tbsw2011;

CREATE TABLE fegen.tbsw2011 (
	cod_bndr numeric(5) NULL,
	cod_emsr_sw numeric(10) NULL,
	cod_fe_emsr varchar(16) NULL,
	cod_issr_sw numeric(10) NOT NULL,
	nom_emsr_sw varchar(30) NULL,
	CONSTRAINT sw2011u0_1 PRIMARY KEY (cod_issr_sw),
	CONSTRAINT sys_c00213309_1 CHECK ((cod_issr_sw IS NOT NULL)),
	CONSTRAINT sys_c00213310_1 CHECK ((cod_bndr IS NOT NULL))
);


-- fegen.tbsw2014 definition

-- Drop table

-- DROP TABLE fegen.tbsw2014;

CREATE TABLE fegen.tbsw2014 (
	cod_id_mmbr numeric(11) NULL,
	cod_pais bpchar(3) NULL,
	cod_prfx_msto bpchar(11) NOT NULL,
	dat_incl_reg date NULL,
	ind_bin_tkn bpchar(1) NULL,
	ind_cash_back numeric(1) NULL,
	ind_cdc numeric(1) NULL,
	ind_cnfr_pstv numeric(1) NULL,
	ind_deb_mtc numeric(1) NULL,
	ind_msto numeric(1) NULL,
	ind_vd_prdt numeric(1) NULL,
	tam_prfx_msto numeric(2) NULL,
	CONSTRAINT cc01sw2014_1 CHECK ((ind_msto = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT cc02sw2014_1 CHECK ((ind_cdc = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT cc03sw2014_1 CHECK ((ind_vd_prdt = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT cc04sw2014_1 CHECK ((ind_cnfr_pstv = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT cc05sw2014_1 CHECK (((ind_bin_tkn IS NULL) OR (ind_bin_tkn = ANY (ARRAY['S'::bpchar, 'N'::bpchar])))),
	CONSTRAINT cc06sw2014_1 CHECK (((ind_cash_back IS NULL) OR (ind_cash_back = ANY (ARRAY[(0)::numeric, (1)::numeric, (2)::numeric])))),
	CONSTRAINT cc07sw2014_1 CHECK ((ind_deb_mtc = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT sw2014u0_1 PRIMARY KEY (cod_prfx_msto),
	CONSTRAINT sys_c00214127_1 CHECK ((cod_prfx_msto IS NOT NULL)),
	CONSTRAINT sys_c00214128_1 CHECK ((cod_pais IS NOT NULL)),
	CONSTRAINT sys_c00214129_1 CHECK ((ind_msto IS NOT NULL)),
	CONSTRAINT sys_c00214130_1 CHECK ((ind_cdc IS NOT NULL)),
	CONSTRAINT sys_c00214131_1 CHECK ((ind_vd_prdt IS NOT NULL)),
	CONSTRAINT sys_c00214132_1 CHECK ((ind_cnfr_pstv IS NOT NULL)),
	CONSTRAINT sys_c00214133_1 CHECK ((dat_incl_reg IS NOT NULL)),
	CONSTRAINT sys_c00226872_1 CHECK ((ind_deb_mtc IS NOT NULL))
);


-- fegen.tbsw2020 definition

-- Drop table

-- DROP TABLE fegen.tbsw2020;

CREATE TABLE fegen.tbsw2020 (
	cod_pr_exec numeric(10) NULL,
	dat_reset date NULL,
	dth_ult_atlz date NULL,
	nom_host varchar(16) NOT NULL,
	sgl_site bpchar(3) NOT NULL,
	val_atu_num_seq_unc numeric(12) NULL,
	val_reset_num_seq_unc numeric(12) NULL,
	val_rng_num_seq_unc numeric(5) NULL,
	CONSTRAINT sw2020u0_1 PRIMARY KEY (sgl_site, nom_host),
	CONSTRAINT sys_c00214544_1 CHECK ((sgl_site IS NOT NULL)),
	CONSTRAINT sys_c00214545_1 CHECK ((dat_reset IS NOT NULL))
);


-- fegen.tbsw2004 definition

-- Drop table

-- DROP TABLE fegen.tbsw2004;

CREATE TABLE fegen.tbsw2004 (
	cod_ret_exec numeric(3) NULL,
	cod_scrp_cmdr bpchar(8) NULL,
	cod_sttu_exec numeric(1) NULL,
	dth_fim_exec date NULL,
	dth_ini_exec date NOT NULL,
	nom_host_exec varchar(16) NOT NULL,
	num_arq_pcd numeric(9) NULL,
	num_pr_btc numeric(5) NULL,
	num_pr_sis_oprc numeric(12) NOT NULL,
	CONSTRAINT cc01sw2004_1 CHECK ((cod_sttu_exec = ANY (ARRAY[(0)::numeric, (1)::numeric, (2)::numeric]))),
	CONSTRAINT sw2004u0_1 PRIMARY KEY (nom_host_exec, num_pr_sis_oprc, dth_ini_exec),
	CONSTRAINT sys_c00214553_1 CHECK ((nom_host_exec IS NOT NULL)),
	CONSTRAINT sys_c00214554_1 CHECK ((num_pr_sis_oprc IS NOT NULL)),
	CONSTRAINT sys_c00214555_1 CHECK ((dth_ini_exec IS NOT NULL)),
	CONSTRAINT sys_c00214556_1 CHECK ((cod_sttu_exec IS NOT NULL)),
	CONSTRAINT ci01sw2004 FOREIGN KEY (cod_scrp_cmdr) REFERENCES fegen.tbsw2005(cod_scrp_cmdr),
	CONSTRAINT ci02sw2004 FOREIGN KEY (num_pr_btc) REFERENCES fegen.tbsw2006(num_pr_btc),
	CONSTRAINT ci03sw2004 FOREIGN KEY (cod_ret_exec) REFERENCES fegen.tbsw2007(cod_ret_exec),
	CONSTRAINT ci04sw2004 FOREIGN KEY (num_arq_pcd) REFERENCES fegen.tbsw2008(num_arq_pcd)
);


-- fegen.tbsw2010 definition

-- Drop table

-- DROP TABLE fegen.tbsw2010;

CREATE TABLE fegen.tbsw2010 (
	cod_issr_sw numeric(10) NULL,
	cod_rota numeric(10) NOT NULL,
	cod_tip_tran bpchar(1) NULL,
	ind_prrd numeric(5) NULL,
	network_id varchar(10) NULL,
	network_id_van varchar(10) NULL,
	nom_fe_acqr varchar(16) NULL,
	nom_host_acqr varchar(16) NULL,
	num_bin_car_fim varchar(10) NULL,
	num_bin_car_ini varchar(10) NULL,
	CONSTRAINT sw2010u0_1 PRIMARY KEY (cod_rota),
	CONSTRAINT sys_c00214546_1 CHECK ((cod_rota IS NOT NULL)),
	CONSTRAINT sys_c00214547_1 CHECK ((cod_issr_sw IS NOT NULL)),
	CONSTRAINT sys_c00214548_1 CHECK ((nom_fe_acqr IS NOT NULL)),
	CONSTRAINT sys_c00214549_1 CHECK ((nom_host_acqr IS NOT NULL)),
	CONSTRAINT ci01sw2010 FOREIGN KEY (cod_issr_sw) REFERENCES fegen.tbsw2011(cod_issr_sw)
);


-- fegen.tbsw2013 definition

-- Drop table

-- DROP TABLE fegen.tbsw2013;

CREATE TABLE fegen.tbsw2013 (
	cod_issr_sw numeric(10) NULL,
	cod_rota_prvt_lbel numeric(10) NOT NULL,
	network_id varchar(10) NULL,
	nom_fe_acqr varchar(16) NULL,
	nom_host_acqr varchar(16) NULL,
	CONSTRAINT sw2013u0_1 PRIMARY KEY (cod_rota_prvt_lbel),
	CONSTRAINT sys_c00214134_1 CHECK ((cod_rota_prvt_lbel IS NOT NULL)),
	CONSTRAINT sys_c00214135_1 CHECK ((cod_issr_sw IS NOT NULL)),
	CONSTRAINT sys_c00214136_1 CHECK ((nom_fe_acqr IS NOT NULL)),
	CONSTRAINT sys_c00214137_1 CHECK ((nom_host_acqr IS NOT NULL)),
	CONSTRAINT ci01sw2013 FOREIGN KEY (cod_issr_sw) REFERENCES fegen.tbsw2011(cod_issr_sw)
);
