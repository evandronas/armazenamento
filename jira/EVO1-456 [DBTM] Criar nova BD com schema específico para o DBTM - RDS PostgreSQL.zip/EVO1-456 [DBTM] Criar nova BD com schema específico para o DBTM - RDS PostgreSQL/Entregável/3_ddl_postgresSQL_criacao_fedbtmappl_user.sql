-- CREATE USER fedbtmappl;
CREATE ROLE fedbtmappl NOSUPERUSER CREATEDB CREATEROLE INHERIT LOGIN PASSWORD 'switch77';

ALTER ROLE fedbtmappl SET search_path TO "$user",public,fedbtm,fegen;

-- GRANT SCHEMAS e TABLES;

--fedbtm
GRANT USAGE ON SCHEMA fedbtm TO fedbtmappl;
--tbsw1012
GRANT SELECT ON TABLE fedbtm.tbsw1012 TO fedbtmappl;
GRANT INSERT ON TABLE fedbtm.tbsw1012 TO fedbtmappl;
GRANT UPDATE ON TABLE fedbtm.tbsw1012 TO fedbtmappl;
GRANT DELETE ON TABLE fedbtm.tbsw1012 TO fedbtmappl;
--tbsw1002
GRANT SELECT ON TABLE fedbtm.tbsw1002 TO fedbtmappl;
GRANT INSERT ON TABLE fedbtm.tbsw1002 TO fedbtmappl;
GRANT UPDATE ON TABLE fedbtm.tbsw1002 TO fedbtmappl;
GRANT DELETE ON TABLE fedbtm.tbsw1002 TO fedbtmappl;
--tbsw1008
GRANT SELECT ON TABLE fedbtm.tbsw1008 TO fedbtmappl;
GRANT INSERT ON TABLE fedbtm.tbsw1008 TO fedbtmappl;
GRANT UPDATE ON TABLE fedbtm.tbsw1008 TO fedbtmappl;
GRANT DELETE ON TABLE fedbtm.tbsw1008 TO fedbtmappl;
--tbsw1004
GRANT SELECT ON TABLE fedbtm.tbsw1004 TO fedbtmappl;
GRANT INSERT ON TABLE fedbtm.tbsw1004 TO fedbtmappl;
GRANT UPDATE ON TABLE fedbtm.tbsw1004 TO fedbtmappl;
GRANT DELETE ON TABLE fedbtm.tbsw1004 TO fedbtmappl;
--tbsw1007
GRANT SELECT ON TABLE fedbtm.tbsw1007 TO fedbtmappl;
GRANT INSERT ON TABLE fedbtm.tbsw1007 TO fedbtmappl;
GRANT UPDATE ON TABLE fedbtm.tbsw1007 TO fedbtmappl;
GRANT DELETE ON TABLE fedbtm.tbsw1007 TO fedbtmappl;
--tbsw1009
GRANT SELECT ON TABLE fedbtm.tbsw1009 TO fedbtmappl;
GRANT INSERT ON TABLE fedbtm.tbsw1009 TO fedbtmappl;
GRANT UPDATE ON TABLE fedbtm.tbsw1009 TO fedbtmappl;
GRANT DELETE ON TABLE fedbtm.tbsw1009 TO fedbtmappl;
--tbsw1005
GRANT SELECT ON TABLE fedbtm.tbsw1005 TO fedbtmappl;
GRANT INSERT ON TABLE fedbtm.tbsw1005 TO fedbtmappl;
GRANT UPDATE ON TABLE fedbtm.tbsw1005 TO fedbtmappl;
GRANT DELETE ON TABLE fedbtm.tbsw1005 TO fedbtmappl;

--fegen
GRANT USAGE ON SCHEMA fegen TO fedbtmappl;

--tbsw2014
GRANT SELECT ON TABLE fegen.tbsw2014 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2014 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2014 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2014 TO fedbtmappl;

--tbsw2013
GRANT SELECT ON TABLE fegen.tbsw2013 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2013 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2013 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2013 TO fedbtmappl;

--tbsw2008
GRANT SELECT ON TABLE fegen.tbsw2008 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2008 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2008 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2008 TO fedbtmappl;

--tbsw2001
GRANT SELECT ON TABLE fegen.tbsw2001 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2001 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2001 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2001 TO fedbtmappl;

--tbsw2020
GRANT SELECT ON TABLE fegen.tbsw2020 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2020 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2020 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2020 TO fedbtmappl;

--tbsw2010
GRANT SELECT ON TABLE fegen.tbsw2010 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2010 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2010 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2010 TO fedbtmappl;

--tbsw2005
GRANT SELECT ON TABLE fegen.tbsw2005 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2005 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2005 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2005 TO fedbtmappl;

--tbsw2004
GRANT SELECT ON TABLE fegen.tbsw2004 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2004 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2004 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2004 TO fedbtmappl;

--tbsw2007
GRANT SELECT ON TABLE fegen.tbsw2007 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2007 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2007 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2007 TO fedbtmappl;

--tbsw0264
GRANT SELECT ON TABLE fegen.tbsw0264 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw0264 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw0264 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw0264 TO fedbtmappl;

--tbsw2006
GRANT SELECT ON TABLE fegen.tbsw2006 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2006 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2006 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2006 TO fedbtmappl;

--tbsw2011
GRANT SELECT ON TABLE fegen.tbsw2011 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2011 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2011 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2011 TO fedbtmappl;

--tbsw0131
GRANT SELECT ON TABLE fegen.tbsw0131 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw0131 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw0131 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw0131 TO fedbtmappl;

--tbsw0008
GRANT SELECT ON TABLE fegen.tbsw0008 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw0008 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw0008 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw0008 TO fedbtmappl;

--tbsw2003
GRANT SELECT ON TABLE fegen.tbsw2003 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2003 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2003 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2003 TO fedbtmappl;

--tbsw0265
GRANT SELECT ON TABLE fegen.tbsw0265 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw0265 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw0265 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw0265 TO fedbtmappl;

--tbsw2002
GRANT SELECT ON TABLE fegen.tbsw2002 TO fedbtmappl;
GRANT INSERT ON TABLE fegen.tbsw2002 TO fedbtmappl;
GRANT UPDATE ON TABLE fegen.tbsw2002 TO fedbtmappl;
GRANT DELETE ON TABLE fegen.tbsw2002 TO fedbtmappl;
