-- CREATE USER fedbtm;
CREATE ROLE fedbtm NOSUPERUSER CREATEDB CREATEROLE INHERIT LOGIN PASSWORD 'switch77';

-- DROP SCHEMA fedbtm;

CREATE SCHEMA fedbtm AUTHORIZATION dbarede;
-- fedbtm.tbsw1002 definition

-- Drop table

-- DROP TABLE fedbtm.tbsw1002;

CREATE TABLE fedbtm.tbsw1002 (
	cod_pais_msto bpchar(3) NULL,
	cod_prfx_msto bpchar(11) NULL,
	dat_incl_reg_msto numeric(8) NULL,
	ind_cdc numeric(1) NULL,
	ind_cnfr_pstv numeric(1) NULL,
	ind_cshb numeric(1) NULL,
	ind_msto numeric(1) NULL,
	ind_parcele_mais numeric(1) NULL,
	ind_pre_datado numeric(1) NULL,
	num_id_bin_deb numeric(11) NOT NULL,
	CONSTRAINT cc01tbsw1002_672613250 CHECK ((ind_cnfr_pstv = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT cc02tbsw1002_456536077 CHECK ((ind_msto = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT cc03tbsw1002 CHECK ((ind_cdc = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT cc04tbsw1002_708795233 CHECK ((ind_pre_datado = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT cc05tbsw1002_624311319 CHECK ((ind_cshb = ANY (ARRAY[(0)::numeric, (1)::numeric]))),
	CONSTRAINT sw1002u0 PRIMARY KEY (num_id_bin_deb),
	CONSTRAINT sys_c00213773 CHECK ((num_id_bin_deb IS NOT NULL)),
	CONSTRAINT sys_c00213774 CHECK ((dat_incl_reg_msto IS NOT NULL)),
	CONSTRAINT sys_c00213775 CHECK ((cod_prfx_msto IS NOT NULL)),
	CONSTRAINT sys_c00213776 CHECK ((cod_pais_msto IS NOT NULL)),
	CONSTRAINT sys_c00213777 CHECK ((ind_cnfr_pstv IS NOT NULL)),
	CONSTRAINT sys_c00213778 CHECK ((ind_msto IS NOT NULL)),
	CONSTRAINT sys_c00213779 CHECK ((ind_cdc IS NOT NULL)),
	CONSTRAINT sys_c00213780 CHECK ((ind_pre_datado IS NOT NULL)),
	CONSTRAINT sys_c00213781 CHECK ((ind_cshb IS NOT NULL)),
	CONSTRAINT sys_c00213782 CHECK ((ind_parcele_mais IS NOT NULL))
);


-- fedbtm.tbsw1005 definition

-- Drop table

-- DROP TABLE fedbtm.tbsw1005;

CREATE TABLE fedbtm.tbsw1005 (
	cod_emsr numeric(4) NULL,
	cod_pcm bpchar(6) NULL,
	cod_sttu_envo bpchar(1) NULL,
	cod_term bpchar(8) NULL,
	cod_trk_car bpchar(40) NULL,
	dat_ctb_rd date NULL,
	dat_mov_tran numeric(8) NOT NULL,
	des_cpl_mot_rd_ext bpchar(25) NULL,
	hor_ini_tran date NULL,
	ind_acao bpchar(1) NULL,
	num_aut_emsr bpchar(6) NULL,
	num_car bpchar(19) NULL,
	num_estb numeric(10) NULL,
	num_seq_unc numeric(9) NOT NULL,
	tip_tran numeric(4) NULL,
	val_tran numeric(19, 4) NULL,
	CONSTRAINT sw1005n1 PRIMARY KEY (num_seq_unc, dat_mov_tran),
	CONSTRAINT sys_c00214238 CHECK ((num_seq_unc IS NOT NULL)),
	CONSTRAINT sys_c00214239 CHECK ((dat_mov_tran IS NOT NULL)),
	CONSTRAINT sys_c00214240 CHECK ((num_car IS NOT NULL)),
	CONSTRAINT sys_c00214241 CHECK ((val_tran IS NOT NULL)),
	CONSTRAINT sys_c00214242 CHECK ((hor_ini_tran IS NOT NULL)),
	CONSTRAINT sys_c00214243 CHECK ((ind_acao IS NOT NULL)),
	CONSTRAINT sys_c00214244 CHECK ((cod_pcm IS NOT NULL)),
	CONSTRAINT sys_c00214245 CHECK ((dat_ctb_rd IS NOT NULL)),
	CONSTRAINT sys_c00214246 CHECK ((num_aut_emsr IS NOT NULL)),
	CONSTRAINT sys_c00214247 CHECK ((cod_term IS NOT NULL)),
	CONSTRAINT sys_c00214248 CHECK ((num_estb IS NOT NULL)),
	CONSTRAINT sys_c00214249 CHECK ((des_cpl_mot_rd_ext IS NOT NULL)),
	CONSTRAINT sys_c00214250 CHECK ((cod_emsr IS NOT NULL)),
	CONSTRAINT sys_c00214251 CHECK ((cod_trk_car IS NOT NULL)),
	CONSTRAINT sys_c00214252 CHECK ((tip_tran IS NOT NULL)),
	CONSTRAINT sys_c00214253 CHECK ((cod_sttu_envo IS NOT NULL))
);


-- fedbtm.tbsw1007 definition

-- Drop table

-- DROP TABLE fedbtm.tbsw1007;

CREATE TABLE fedbtm.tbsw1007 (
	cod_aut_mtc bpchar(9) NULL,
	cod_bndr numeric(3) NULL,
	cod_cv numeric(12) NULL,
	cod_ele_adic bpchar(20) NULL,
	cod_modo_entr_pos bpchar(3) NULL,
	cod_moed bpchar(3) NULL,
	cod_mot_rd_ext bpchar(3) NULL,
	cod_ram_atvd_mtc numeric(4) NULL,
	cod_term bpchar(8) NULL,
	dat_mov_tran numeric(8) NOT NULL,
	dat_pcm_ajst_tran numeric(8) NOT NULL,
	dat_sttu_tran numeric(8) NULL,
	des_cpl_mot_rd_ext bpchar(25) NULL,
	hor_ajst_tran numeric(6) NULL,
	hor_ini_tran numeric(6) NULL,
	ind_sttu_tran bpchar(1) NULL,
	ind_tip_ajst numeric NULL,
	nom_locl_estb bpchar(40) NULL,
	num_car bpchar(19) NULL,
	num_estb numeric(9) NULL,
	num_seq_unc numeric(9) NOT NULL,
	val_lqdc numeric(19, 2) NULL,
	val_risc numeric(19, 2) NULL,
	val_sldo_parc numeric(19, 2) NULL,
	val_tran numeric(19, 2) NULL,
	CONSTRAINT sw1007u0 PRIMARY KEY (dat_pcm_ajst_tran, dat_mov_tran, num_seq_unc),
	CONSTRAINT sys_c00212777 CHECK ((dat_pcm_ajst_tran IS NOT NULL)),
	CONSTRAINT sys_c00212778 CHECK ((dat_mov_tran IS NOT NULL)),
	CONSTRAINT sys_c00212779 CHECK ((num_seq_unc IS NOT NULL)),
	CONSTRAINT sys_c00212780 CHECK ((cod_modo_entr_pos IS NOT NULL)),
	CONSTRAINT sys_c00212781 CHECK ((cod_cv IS NOT NULL)),
	CONSTRAINT sys_c00212782 CHECK ((cod_aut_mtc IS NOT NULL)),
	CONSTRAINT sys_c00212783 CHECK ((num_car IS NOT NULL)),
	CONSTRAINT sys_c00212784 CHECK ((val_tran IS NOT NULL)),
	CONSTRAINT sys_c00212785 CHECK ((val_lqdc IS NOT NULL)),
	CONSTRAINT sys_c00212786 CHECK ((cod_term IS NOT NULL)),
	CONSTRAINT sys_c00212787 CHECK ((val_risc IS NOT NULL)),
	CONSTRAINT sys_c00212788 CHECK ((nom_locl_estb IS NOT NULL)),
	CONSTRAINT sys_c00212789 CHECK ((cod_ram_atvd_mtc IS NOT NULL)),
	CONSTRAINT sys_c00212790 CHECK ((cod_moed IS NOT NULL)),
	CONSTRAINT sys_c00212791 CHECK ((cod_ele_adic IS NOT NULL)),
	CONSTRAINT sys_c00212792 CHECK ((num_estb IS NOT NULL)),
	CONSTRAINT sys_c00212793 CHECK ((ind_tip_ajst IS NOT NULL)),
	CONSTRAINT sys_c00212794 CHECK ((des_cpl_mot_rd_ext IS NOT NULL)),
	CONSTRAINT sys_c00212795 CHECK ((cod_mot_rd_ext IS NOT NULL)),
	CONSTRAINT sys_c00212796 CHECK ((dat_sttu_tran IS NOT NULL)),
	CONSTRAINT sys_c00212797 CHECK ((val_sldo_parc IS NOT NULL)),
	CONSTRAINT sys_c00212798 CHECK ((ind_sttu_tran IS NOT NULL)),
	CONSTRAINT sys_c00212799 CHECK ((hor_ajst_tran IS NOT NULL)),
	CONSTRAINT sys_c00212800 CHECK ((hor_ini_tran IS NOT NULL))
);


-- fedbtm.tbsw1008 definition

-- Drop table

-- DROP TABLE fedbtm.tbsw1008;

CREATE TABLE fedbtm.tbsw1008 (
	cod_aut_mtc bpchar(9) NULL,
	cod_bndr numeric(3) NULL,
	cod_cli numeric(5) NULL,
	cod_cv numeric(12) NULL,
	cod_ele_adic bpchar(20) NULL,
	cod_modo_entr_pos bpchar(3) NULL,
	cod_moed bpchar(3) NULL,
	cod_mot_ngtv_rd_ext bpchar(3) NULL,
	cod_ram_atvd_mtc numeric(4) NULL,
	cod_ref_emsr bpchar(15) NULL,
	cod_term bpchar(8) NULL,
	cod_trk_car varchar(40) NULL,
	dat_lqdc_eftv numeric(8) NOT NULL,
	dat_mov_tran numeric(8) NOT NULL,
	dat_prdt numeric(8) NULL,
	dat_sttu_tran numeric(8) NULL,
	des_cpl_mot_rd_ext bpchar(25) NULL,
	hor_ini_tran numeric(6) NULL,
	hor_lqdc_tran numeric(6) NULL,
	ind_dstr numeric(5) NULL,
	ind_prrd_tran numeric(5) NULL,
	ind_sttu_tran bpchar(1) NULL,
	nom_locl_estb bpchar(40) NULL,
	num_car bpchar(19) NULL,
	num_estb numeric(9) NULL,
	num_seq_unc numeric(9) NOT NULL,
	tip_lqdc numeric(5) NULL,
	val_lqdc numeric(19, 2) NULL,
	val_risc numeric(19, 2) NULL,
	val_tran numeric(19, 2) NULL,
	CONSTRAINT sw1008u0 PRIMARY KEY (dat_lqdc_eftv, dat_mov_tran, num_seq_unc),
	CONSTRAINT sys_c00213744 CHECK ((cod_modo_entr_pos IS NOT NULL)),
	CONSTRAINT sys_c00213745 CHECK ((dat_mov_tran IS NOT NULL)),
	CONSTRAINT sys_c00213746 CHECK ((cod_moed IS NOT NULL)),
	CONSTRAINT sys_c00213747 CHECK ((num_seq_unc IS NOT NULL)),
	CONSTRAINT sys_c00213748 CHECK ((hor_lqdc_tran IS NOT NULL)),
	CONSTRAINT sys_c00213749 CHECK ((hor_ini_tran IS NOT NULL)),
	CONSTRAINT sys_c00213750 CHECK ((val_lqdc IS NOT NULL)),
	CONSTRAINT sys_c00213751 CHECK ((val_risc IS NOT NULL)),
	CONSTRAINT sys_c00213752 CHECK ((dat_prdt IS NOT NULL)),
	CONSTRAINT sys_c00213753 CHECK ((cod_term IS NOT NULL)),
	CONSTRAINT sys_c00213754 CHECK ((num_car IS NOT NULL)),
	CONSTRAINT sys_c00213755 CHECK ((cod_trk_car IS NOT NULL)),
	CONSTRAINT sys_c00213756 CHECK ((val_tran IS NOT NULL)),
	CONSTRAINT sys_c00213757 CHECK ((cod_cv IS NOT NULL)),
	CONSTRAINT sys_c00213758 CHECK ((des_cpl_mot_rd_ext IS NOT NULL)),
	CONSTRAINT sys_c00213759 CHECK ((num_estb IS NOT NULL)),
	CONSTRAINT sys_c00213760 CHECK ((cod_ram_atvd_mtc IS NOT NULL)),
	CONSTRAINT sys_c00213761 CHECK ((cod_mot_ngtv_rd_ext IS NOT NULL)),
	CONSTRAINT sys_c00213762 CHECK ((dat_lqdc_eftv IS NOT NULL)),
	CONSTRAINT sys_c00213763 CHECK ((nom_locl_estb IS NOT NULL)),
	CONSTRAINT sys_c00213764 CHECK ((tip_lqdc IS NOT NULL)),
	CONSTRAINT sys_c00213765 CHECK ((ind_prrd_tran IS NOT NULL)),
	CONSTRAINT sys_c00213766 CHECK ((ind_dstr IS NOT NULL)),
	CONSTRAINT sys_c00213767 CHECK ((cod_ref_emsr IS NOT NULL)),
	CONSTRAINT sys_c00213768 CHECK ((ind_sttu_tran IS NOT NULL)),
	CONSTRAINT sys_c00213769 CHECK ((cod_aut_mtc IS NOT NULL)),
	CONSTRAINT sys_c00213770 CHECK ((dat_sttu_tran IS NOT NULL)),
	CONSTRAINT sys_c00213771 CHECK ((cod_ele_adic IS NOT NULL)),
	CONSTRAINT sys_c00213772 CHECK ((cod_cli IS NOT NULL))
);
CREATE INDEX sw1008n1 ON fedbtm.tbsw1008 USING btree (ind_sttu_tran);


-- fedbtm.tbsw1009 definition

-- Drop table

-- DROP TABLE fedbtm.tbsw1009;

CREATE TABLE fedbtm.tbsw1009 (
	dat_ult_trca_chav numeric(8) NULL,
	hor_ult_trca_chav numeric(6) NULL,
	num_id_trca_chav_msto numeric(38) NOT NULL,
	CONSTRAINT sw1009n1 PRIMARY KEY (num_id_trca_chav_msto),
	CONSTRAINT sys_c00214257 CHECK ((num_id_trca_chav_msto IS NOT NULL)),
	CONSTRAINT sys_c00214258 CHECK ((dat_ult_trca_chav IS NOT NULL)),
	CONSTRAINT sys_c00214259 CHECK ((hor_ult_trca_chav IS NOT NULL))
);


-- fedbtm.tbsw1012 definition

-- Drop table

-- DROP TABLE fedbtm.tbsw1012;

CREATE TABLE fedbtm.tbsw1012 (
	dat_crte_msto date NOT NULL,
	hor_crte_msto date NULL,
	ind_pais_crte bpchar(1) NOT NULL,
	CONSTRAINT sw1012n1 PRIMARY KEY (dat_crte_msto, ind_pais_crte),
	CONSTRAINT sys_c00214235 CHECK ((dat_crte_msto IS NOT NULL)),
	CONSTRAINT sys_c00214236 CHECK ((ind_pais_crte IS NOT NULL)),
	CONSTRAINT sys_c00214237 CHECK ((hor_crte_msto IS NOT NULL))
);


-- fedbtm.tbsw1004 definition

-- Drop table

-- DROP TABLE fedbtm.tbsw1004;

CREATE TABLE fedbtm.tbsw1004 (
	cod_rsps_tran bpchar(4) NULL,
	cod_tip_msg bpchar(4) NULL,
	dat_lqdc_eftv numeric(8) NOT NULL,
	dat_mov_tran numeric(8) NOT NULL,
	dat_sttu_tran numeric(8) NULL,
	hor_ult_trca_chav numeric(6) NULL,
	ind_sttu_tran bpchar(1) NULL,
	num_hist_tran_lqdc numeric(38) NOT NULL,
	num_seq_unc numeric(9) NOT NULL,
	CONSTRAINT sw1004u0 PRIMARY KEY (num_hist_tran_lqdc, dat_lqdc_eftv, dat_mov_tran, num_seq_unc),
	CONSTRAINT sys_c00212317 CHECK ((num_hist_tran_lqdc IS NOT NULL)),
	CONSTRAINT sys_c00212318 CHECK ((dat_lqdc_eftv IS NOT NULL)),
	CONSTRAINT sys_c00212319 CHECK ((dat_sttu_tran IS NOT NULL)),
	CONSTRAINT sys_c00212320 CHECK ((dat_mov_tran IS NOT NULL)),
	CONSTRAINT sys_c00212321 CHECK ((hor_ult_trca_chav IS NOT NULL)),
	CONSTRAINT sys_c00212322 CHECK ((num_seq_unc IS NOT NULL)),
	CONSTRAINT sys_c00212323 CHECK ((ind_sttu_tran IS NOT NULL)),
	CONSTRAINT sys_c00212324 CHECK ((cod_tip_msg IS NOT NULL)),
	CONSTRAINT sys_c00212325 CHECK ((cod_rsps_tran IS NOT NULL)),
	CONSTRAINT ci01sw1004 FOREIGN KEY (dat_lqdc_eftv,dat_mov_tran,num_seq_unc) REFERENCES fedbtm.tbsw1008(dat_lqdc_eftv,dat_mov_tran,num_seq_unc)
);
