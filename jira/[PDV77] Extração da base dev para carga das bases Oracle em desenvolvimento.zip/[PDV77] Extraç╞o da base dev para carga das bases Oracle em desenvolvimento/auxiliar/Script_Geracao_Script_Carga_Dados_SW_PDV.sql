--exec dbms_stats.gather_schema_stats('DBAREDE', cascade=>TRUE);
--exec dbms_stats.gather_schema_stats('SW_PDV', cascade=>TRUE);

SET SERVEROUTPUT ON
--exec dbms_stats.gather_schema_stats('DBAREDE');
--INSERT INTO sw_pdv.ENT_AUDIT (ENT_AUDIT_DATE, ENT_AUDIT_MSG, ENT_LEVEL, ENT_OBJECT_ID, ENT_SESSION_ID, ENT_TERMINAL_ID, ENT_USER_ID, SITE_ID) SELECT ENT_AUDIT_DATE, ENT_AUDIT_MSG, ENT_LEVEL, ENT_OBJECT_ID, ENT_SESSION_ID, ENT_TERMINAL_ID, ENT_USER_ID, 1 AS SITE_ID FROM dbarede.ENT_AUDIT;
--INSERT INTO sw_pdv.INST_PROFILE (EXTERNALID, EXT_ID_DESC, F_ID, INST_ID, ISS_ENTITY_ID, MEMBER_ID, MSGTYPE, TXNDEST, TXNSRC, USERBIN_ID, ID) SELECT EXTERNALID, EXT_ID_DESC, F_ID, INST_ID, ISS_ENTITY_ID, MEMBER_ID, MSGTYPE, TXNDEST, TXNSRC, USERBIN_ID, ROWNUM AS ID FROM (SELECT DISTINCT EXTERNALID, EXT_ID_DESC, F_ID, INST_ID, ISS_ENTITY_ID, MEMBER_ID, MSGTYPE, TXNDEST, TXNSRC, USERBIN_ID FROM dbarede.INST_PROFILE);

DECLARE v_tabela varchar(30);
v_coluna varchar(30);
v_datatype varchar(30);
v_datalength number;
v_dataprecision number;
v_datascale number;
sql_stmt VARCHAR2(32767);
v_colunas VARCHAR2(32767);
v_valores VARCHAR2(32767);
v_str varchar(32767);
CURSOR cur_tabelas
IS SELECT TABLE_NAME FROM ALL_TABLES
	WHERE OWNER = 'DBAREDE'
		AND NUM_ROWS > 0
    AND TABLE_NAME IN (SELECT TABLE_NAME FROM ALL_TABLES
      WHERE OWNER = 'SW_PDV')
	ORDER BY TABLE_NAME;
CURSOR cur_colunas
IS SELECT table_name,column_name,DATA_TYPE,DATA_LENGTH,DATA_PRECISION,DATA_SCALE FROM all_tab_cols
	WHERE OWNER = 'DBAREDE'
		AND TABLE_NAME IN (SELECT TABLE_NAME FROM ALL_TABLES WHERE OWNER = 'DBAREDE'
		AND NUM_ROWS > 0) AND TABLE_NAME = v_tabela
    AND table_name||column_name IN
    (SELECT table_name||column_name FROM all_tab_cols
    	WHERE OWNER = 'SW_PDV'
		AND TABLE_NAME IN (SELECT TABLE_NAME FROM ALL_TABLES WHERE OWNER = 'SW_PDV'
		) AND TABLE_NAME = v_tabela)
	ORDER BY TABLE_NAME, COLUMN_NAME;
BEGIN
	OPEN cur_tabelas;
	LOOP
		FETCH cur_tabelas INTO v_tabela;
		EXIT WHEN cur_tabelas%NOTFOUND;
		v_colunas := '';
		v_valores := '';
		OPEN cur_colunas;
		LOOP
			FETCH cur_colunas INTO v_tabela, v_coluna, v_datatype, v_datalength, v_dataprecision, v_datascale;
			EXIT WHEN cur_colunas%NOTFOUND;
			v_colunas := v_colunas || v_coluna || ', ';
			IF (v_datatype != 'DATE') THEN
				IF (v_datatype != 'NUMBER') THEN
					IF (v_datatype != 'ROW') THEN --Char, Varchar ...
						v_str := v_coluna;
					ELSE --ROW
						v_str := v_coluna;
					END IF;
				ELSE --NUMBER
					v_str := v_coluna;
				END IF;
			ELSE --DATE
				v_str := v_coluna;
			END IF; --Não será necessário conversão
			v_valores := v_valores || v_str || ', ';
		END LOOP;
		v_colunas := substr(v_colunas, 1, length(v_colunas)-2) ;
		v_valores := substr(v_valores, 1, length(v_valores)-2) ;
		IF (v_tabela = 'ENT_AUDIT' OR v_tabela = 'OAS_COUNTER') THEN
			v_colunas := v_colunas || ', SITE_ID';
			v_valores := v_valores || ', 1 AS SITE_ID';
		END IF;
		IF (v_tabela = 'INST_PROFILE') THEN
			sql_stmt := 'INSERT INTO ' || 'sw_pdv.' || v_tabela || ' (' || v_colunas || ', ID) ' || 'SELECT ' || v_valores || ', ROWNUM AS ID FROM (SELECT DISTINCT ' || v_valores || ' FROM ' || 'dbarede.' || v_tabela || ');';
		ELSE
			sql_stmt := 'INSERT INTO ' || 'sw_pdv.' || v_tabela || ' (' || v_colunas || ') SELECT DISTINCT ' || v_valores || ' FROM ' || 'dbarede.' || v_tabela || ';';
		END IF;
		dbms_output.put_line('TRUNCATE TABLE ' || 'sw_pdv.' || v_tabela || ';');
		dbms_output.put_line(sql_stmt);
		dbms_output.put_line('COMMIT;');
		CLOSE cur_colunas;
	END LOOP;
	CLOSE cur_tabelas;
END;
/
