REM INSERTING into SECLOC
SET DEFINE OFF;
Insert into SECLOC (LID,STATUS,ENABLE,BRANCH,REGION,DEPT,O_ROWID) values ('3','V','E','1','A','audit               ','0');
Insert into SECLOC (LID,STATUS,ENABLE,BRANCH,REGION,DEPT,O_ROWID) values ('66','V','E','1','1','tellers             ','0');
Insert into SECLOC (LID,STATUS,ENABLE,BRANCH,REGION,DEPT,O_ROWID) values ('211','V','E','1','1','systems1            ','0');
Insert into SECLOC (LID,STATUS,ENABLE,BRANCH,REGION,DEPT,O_ROWID) values ('234','V','E','1','1','phones              ','0');
commit;
