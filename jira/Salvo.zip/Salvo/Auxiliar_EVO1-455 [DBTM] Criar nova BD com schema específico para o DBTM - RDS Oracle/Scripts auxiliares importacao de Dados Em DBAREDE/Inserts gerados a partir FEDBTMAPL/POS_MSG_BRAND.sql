REM INSERTING into POS_MSG_BRAND
SET DEFINE OFF;
Insert into POS_MSG_BRAND (POS_MSG_BRAND,MSG_BRAND,MSG_VERSION) values ('7','hypercom','3.32');
Insert into POS_MSG_BRAND (POS_MSG_BRAND,MSG_BRAND,MSG_VERSION) values ('5','visa 2nd','6.1');
Insert into POS_MSG_BRAND (POS_MSG_BRAND,MSG_BRAND,MSG_VERSION) values ('101','SPAN POS (APACS 6)','6.0');
Insert into POS_MSG_BRAND (POS_MSG_BRAND,MSG_BRAND,MSG_VERSION) values ('7','hypercom','3.32');
Insert into POS_MSG_BRAND (POS_MSG_BRAND,MSG_BRAND,MSG_VERSION) values ('5','visa 2nd','6.1');
commit;
