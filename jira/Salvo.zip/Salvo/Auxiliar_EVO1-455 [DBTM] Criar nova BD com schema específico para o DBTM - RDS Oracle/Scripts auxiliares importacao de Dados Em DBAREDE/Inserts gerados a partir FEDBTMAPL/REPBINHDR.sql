REM INSERTING into REPBINHDR
SET DEFINE OFF;
Insert into REPBINHDR (BIN,HEADING1,HEADING2,O_ROWID) values ('0000000004','VISA INTERNATIONAL                      ',null,'0');
Insert into REPBINHDR (BIN,HEADING1,HEADING2,O_ROWID) values ('FFFFFFFFFF','OTHER NETWORKS                          ',null,'0');
Insert into REPBINHDR (BIN,HEADING1,HEADING2,O_ROWID) values ('GLOBAL HDR','    OASIS                               ','TECHNOLOGY LTD                          ','0');
Insert into REPBINHDR (BIN,HEADING1,HEADING2,O_ROWID) values ('1010101010','IST/SHARE MAIN BIN                      ',null,'0');
commit;
