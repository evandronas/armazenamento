REM INSERTING into GUI_SUBSYSTEM
SET DEFINE OFF;
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('atmmon','com.oasis.atmmon.client.AtmMonApplet','http://172.10.130.51:8083/atmmon.html');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('BackOffice','com.oasis.backoffice.client.BOApplet','//localhost:8100/oasis-technology/startBO.html');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('cfgsvc','com.oasis.cfgsvc.client.CfgSvcApplet','none');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('ent','com.oasis.ent.client.ENTApplet','Anything');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('istcms','com.efunds.istcms.client.CmsApplet','none');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('istmon','com.oasis.istmon.client.IstMonApplet','http://172.10.130.51:8083/istmon.html');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('istreport','com.oasis.istreport.client.IstReportApplet','http://172.10.130.51:8083/istreport.html');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('pos','com.oasis.pos.client.POSApplet','http://172.10.130.51:8083/pos.html');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('swgui','com.oasis.SwGui.client.SwGuiApplet','None');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('VisaAdmin','com.oasis.visaadmin.client.AdminApplet','//localhost:8100/oasis-technology/visaadmin.html');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('visafrs','com.oasis.visafrs.client.VisaFrsApplet','http://172.10.130.51:8083/visafrs.html');
Insert into GUI_SUBSYSTEM (SUB_SYSTEM_NAME,CLASS_NAME,URL) values ('voice','com.oasis.voice.client.VoiceApplet','//localhost:8000/oasis-technology/iplanet4doc/voice.html');
commit;
