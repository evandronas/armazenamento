REM INSERTING into SECOBJ
SET DEFINE OFF;
Insert into SECOBJ (ONAME,OID,SECCLASS,ENABLE,STATUS,SECLEVEL,DESCR,O_ROWID) values ('secadmin                      ','2','C','E','V','9','Security Administration       ','0');
Insert into SECOBJ (ONAME,OID,SECCLASS,ENABLE,STATUS,SECLEVEL,DESCR,O_ROWID) values ('istparam                      ','106','N','E','V','1','CONFIG MGR                    ','0');
Insert into SECOBJ (ONAME,OID,SECCLASS,ENABLE,STATUS,SECLEVEL,DESCR,O_ROWID) values ('xmserver                      ','108','N','E','V','1','XMSERVER FOR CONFIG MGR       ','0');
Insert into SECOBJ (ONAME,OID,SECCLASS,ENABLE,STATUS,SECLEVEL,DESCR,O_ROWID) values ('istmenu                       ','236','N','E','V','1','IST MAIN MENU                 ','0');
commit;
