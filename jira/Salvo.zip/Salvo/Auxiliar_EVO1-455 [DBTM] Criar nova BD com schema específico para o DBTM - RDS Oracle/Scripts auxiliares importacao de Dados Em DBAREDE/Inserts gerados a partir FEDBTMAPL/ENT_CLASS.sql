REM INSERTING into ENT_CLASS
SET DEFINE OFF;
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('1','Users');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('2','Ent Tables');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('6','GUI Profiles');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('11','Fields');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('31','SubField');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('32','SubButton');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('33','Form Button');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('65','institution');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('72','Switch Institutions');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('75','merchant');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('3','Forms');
Insert into ENT_CLASS (ENT_CLASS_ID,ENT_CLASS_NAME) values ('10','Sub-system');
commit;
