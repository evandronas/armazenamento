REM INSERTING into ENT_GROUP
SET DEFINE OFF;
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('Admin_Group','System Admins.    ','O','1');
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('Administradores','Administradores   ','O','1');
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('Fabrica BSI','Fabrica BSI       ','O','1');
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('Fabrica Resource Outsourcing','Fab Reso Outsourc ','O','1');
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('Fabrica Resource Sustentacao','Fab Resource Suste','O','1');
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('Fabrica Stefanini','Fabrica Stefanini ','O','1');
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('Redecard Evolucao Sist. Missao Critica','RC Evol Sis Mis Cr','O','1');
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('Sustentacao','Sustentacao       ','O','1');
Insert into ENT_GROUP (ENT_GROUP_ID,ENT_GROUP_DESC,ENT_GROUP_TYPE,ENT_CLASS_ID) values ('swcons','Grupo de consulta ','O','1');
commit;
