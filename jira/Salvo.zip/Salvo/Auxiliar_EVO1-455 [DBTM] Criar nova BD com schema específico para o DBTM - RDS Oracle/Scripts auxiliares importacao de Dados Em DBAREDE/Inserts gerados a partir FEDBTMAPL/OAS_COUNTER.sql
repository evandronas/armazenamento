REM INSERTING into OAS_COUNTER
SET DEFINE OFF;
Insert into OAS_COUNTER (CLIENT_ID) values ('22');
commit;
