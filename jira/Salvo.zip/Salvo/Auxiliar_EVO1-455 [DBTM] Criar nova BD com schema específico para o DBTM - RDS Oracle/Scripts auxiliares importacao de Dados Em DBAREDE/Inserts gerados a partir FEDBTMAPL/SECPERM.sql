REM INSERTING into SECPERM
SET DEFINE OFF;
Insert into SECPERM (ONAME,OID,NAME,O_UID,GNAME,GID,PRM,STATUS,O_ROWID) values ('secadmin                      ','2','none      ','0','control   ','22','VIDUR               ','V','0');
Insert into SECPERM (ONAME,OID,NAME,O_UID,GNAME,GID,PRM,STATUS,O_ROWID) values ('istparam                      ','106','none      ','0','tellers   ','64','RWVID               ','V','0');
Insert into SECPERM (ONAME,OID,NAME,O_UID,GNAME,GID,PRM,STATUS,O_ROWID) values ('xmserver                      ','108','none      ','0','tellers   ','64','VIDUR               ','V','0');
Insert into SECPERM (ONAME,OID,NAME,O_UID,GNAME,GID,PRM,STATUS,O_ROWID) values ('istmenu                       ','236','none      ','0','tellers   ','64','VIDUR               ','V','0');
commit;
