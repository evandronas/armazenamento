REM INSERTING into SECUSRGRP
SET DEFINE OFF;
Insert into SECUSRGRP (NAME,O_UID,GNAME,GID,STATUS,O_ROWID) values ('qa1       ','4','control   ','22','V','0');
Insert into SECUSRGRP (NAME,O_UID,GNAME,GID,STATUS,O_ROWID) values ('qa2       ','5','control   ','22','V','0');
Insert into SECUSRGRP (NAME,O_UID,GNAME,GID,STATUS,O_ROWID) values ('qa3       ','6','control   ','22','V','0');
Insert into SECUSRGRP (NAME,O_UID,GNAME,GID,STATUS,O_ROWID) values ('qa4       ','7','control   ','22','V','0');
Insert into SECUSRGRP (NAME,O_UID,GNAME,GID,STATUS,O_ROWID) values ('paradmin  ','68','tellers   ','64','V','0');
Insert into SECUSRGRP (NAME,O_UID,GNAME,GID,STATUS,O_ROWID) values ('ctrl1     ','212','control   ','22','V','0');
commit;
