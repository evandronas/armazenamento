--
-- Este script foi criado com objetivo criar um script de criação das tabelas no schema DBAREDE, e portanto deve ser executado
-- no schema FEDBTMAPPL da versão 7.5 do IST
--
SET SERVEROUTPUT ON

DECLARE
  CURSOR cur_tabela
  IS
    SELECT table_name, column_name, DATA_TYPE, DATA_LENGTH,  DATA_PRECISION, DATA_SCALE
      FROM all_tab_cols WHERE OWNER = 'FEDBTM'
          AND TABLE_NAME IN (SELECT TABLE_NAME
              FROM ALL_TABLES WHERE OWNER = 'FEDBTM'
                  AND TABLE_NAME IN (SELECT TABLE_NAME FROM all_synonyms WHERE OWNER = 'FEDBTMAPPL')
                  AND NUM_ROWS > 0) ORDER BY TABLE_NAME, COLUMN_NAME;
  v_tabela varchar(100) := 'dummy';
  v_virgula boolean := true;
  v_newline boolean := false;
  v_onetime boolean := true;
  v_ncol number;
BEGIN
  FOR v_cur_tabela IN cur_tabela
  LOOP
    IF (v_tabela != v_cur_tabela.TABLE_NAME) THEN
        IF (v_tabela != 'dummy') THEN
            dbms_output.put_line('');
            dbms_output.put_line(');');
            v_virgula := false;
        END IF;
        dbms_output.put_line('');
        dbms_output.put_line('CREATE TABLE ' || v_cur_tabela.TABLE_NAME || '(');
        v_tabela := v_cur_tabela.TABLE_NAME;
        v_ncol := 0;
    ELSE
        v_virgula := true;
    END IF;
    IF (v_newline) THEN
        IF (v_virgula) THEN
            dbms_output.put_line(',');
        END IF;
        v_newline := false;
    ELSE
        IF (v_onetime) THEN
            v_onetime := false;
        ELSE
            IF (v_ncol > 0) THEN
                dbms_output.put_line(',');
            END IF;
        END IF;
    END IF;
    dbms_output.put('     ' || v_cur_tabela.COLUMN_NAME || ' ' || v_cur_tabela.DATA_TYPE);
    IF (v_cur_tabela.DATA_TYPE != 'DATE') THEN
        IF (v_cur_tabela.DATA_TYPE != 'NUMBER') THEN
            IF (v_cur_tabela.DATA_LENGTH > 0) THEN
                dbms_output.put('(' || v_cur_tabela.DATA_LENGTH || ')');
            END IF;
        ELSE
            IF (v_cur_tabela.DATA_PRECISION > 0) THEN
                dbms_output.put('(' || v_cur_tabela.DATA_PRECISION);
                IF ( v_cur_tabela.DATA_SCALE > 0) THEN
                    dbms_output.put(',' || v_cur_tabela.DATA_SCALE);
                END IF;
                dbms_output.put(')');
			ELSE
				IF (v_cur_tabela.DATA_LENGTH > 0) THEN
            dbms_output.put('(');
            IF (v_cur_tabela.DATA_LENGTH != 22) THEN
                dbms_output.put(v_cur_tabela.DATA_LENGTH);
            ELSE
                dbms_output.put(38);
            END IF;
            dbms_output.put(')');
				END IF;
            END IF;
        END IF;
    END IF;
    IF (v_virgula) THEN
        v_newline := true;
    END IF;
    v_ncol := v_ncol + 1;
  END LOOP;
  dbms_output.put_line('');
  dbms_output.put_line(');');
END;
/
