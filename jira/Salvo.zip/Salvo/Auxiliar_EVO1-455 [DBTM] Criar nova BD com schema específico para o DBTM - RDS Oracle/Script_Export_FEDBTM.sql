SET SERVEROUTPUT ON
DECLARE v_tabela varchar(30);
v_coluna varchar(30);
v_datatype varchar(30);
v_datalength number;
v_dataprecision number;
v_datascale number;
sql_stmt VARCHAR2(32767);
v_colunas VARCHAR2(32767);
v_valores VARCHAR2(32767);
v_n number;
v_str varchar(32767);
CURSOR cur_tabelas
IS SELECT TABLE_NAME FROM ALL_TABLES
	WHERE OWNER = 'FEDBTM'
		AND TABLE_NAME IN (SELECT TABLE_NAME FROM all_synonyms WHERE OWNER = 'FEDBTMAPPL')
		AND NUM_ROWS > 0
	ORDER BY TABLE_NAME;
CURSOR cur_colunas
IS SELECT table_name, column_name, DATA_TYPE, DATA_LENGTH,  DATA_PRECISION, DATA_SCALE FROM all_tab_cols
	WHERE OWNER = 'FEDBTM'
		AND TABLE_NAME IN (SELECT TABLE_NAME FROM ALL_TABLES WHERE OWNER = 'FEDBTM'
		AND TABLE_NAME IN (SELECT TABLE_NAME FROM all_synonyms WHERE OWNER = 'FEDBTMAPPL')
		AND NUM_ROWS > 0) AND TABLE_NAME = v_tabela
	ORDER BY TABLE_NAME, COLUMN_NAME;
BEGIN
	OPEN cur_tabelas;
	LOOP
		FETCH cur_tabelas INTO v_tabela;
		EXIT WHEN cur_tabelas%NOTFOUND;
		v_colunas := '';
		v_valores := '';
		v_n := 0;
		OPEN cur_colunas;
		LOOP
			FETCH cur_colunas INTO v_tabela, v_coluna, v_datatype, v_datalength, v_dataprecision, v_datascale;
			EXIT WHEN cur_colunas%NOTFOUND;
			v_colunas := v_colunas || v_coluna || ', ';
			v_n := v_n + 1;
			IF (v_datatype != 'DATE') THEN
				IF (v_datatype != 'NUMBER') THEN
					IF (v_datatype != 'ROW') THEN
						v_str := ':' || v_n;
					ELSE
						v_str := 'TO_ROW(:' || v_n || ')';
					END IF;
				ELSE
					v_str := 'TO_NUMBER(:' || v_n;
					IF (v_dataprecision > 0) THEN
						v_str := v_str || ', ' || v_dataprecision;
						IF ( v_datascale > 0) THEN
							v_str := v_str || ', ' || v_datascale;
						END IF;
					ELSE
						IF (v_datalength > 0) THEN
							v_str := v_str || ', ' || v_datalength;
						END IF;
					END IF;
					v_str := v_str || ')';
				END IF;
			ELSE
				v_str := 'TO_DATE(:' || v_n || ')';
			END IF;
			v_valores := v_valores || v_str || ', ';
			--dbms_output.put_line(v_coluna || ' ' || v_datatype || ' ' || v_datalength || ' ' || v_dataprecision || ' ' || v_datascale);
		END LOOP;
		v_colunas := substr(v_colunas, 1, length(v_colunas)-2) ;
		v_valores := substr(v_valores, 1, length(v_valores)-2) ;
		sql_stmt := 'INSERT INTO ' || v_tabela || ' (' || v_colunas || ') VALUES (' || v_valores || ');';
		dbms_output.put_line(sql_stmt);
		CLOSE cur_colunas;
	END LOOP;
	CLOSE cur_tabelas;
END;
/