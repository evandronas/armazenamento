--
-- Este script foi criado com objetivo criar um script de criação das constraints das constraints TBSW* no schema DBAREDE, 
-- e portanto deve ser executado no schema FEDBTMAPPL da versão 7.5 do IST, 
-- e irá extrair as estruturas das indices 'TBSW*' existentes
--
-- ALTER TABLE ... ADD CONSTRAINT ... CHECK (...);
-- ALTER TABLE ... ADD CONSTRAINT ... PRIMARY KEY (...);
-- ALTER TABLE ... ADD FOREIGN KEY (...) REFERENCES Persons(...);

SET SERVEROUTPUT ON

DECLARE

  v_indice varchar(100) := 'dummy';
  v_constraint varchar(100) := 'dummy';
  v_reference varchar(100) := 'dummy';
  v_virgula boolean := true;
  v_newline boolean := false;
  v_onetime boolean := true;
  v_ncol number;

  CURSOR cur_constraint_c
  IS 
	SELECT *
		FROM all_constraints
		WHERE substr(table_name,1,4) = 'TBSW' AND CONSTRAINT_TYPE = 'C'
		ORDER BY OWNER, TABLE_NAME, CONSTRAINT_TYPE, CONSTRAINT_NAME;
  CURSOR cur_constraint_p
  IS 
	SELECT * FROM	
		(SELECT all_constraints.TABLE_NAME AS TABLE_NAME, all_constraints.CONSTRAINT_NAME AS CONSTRAINT_NAME, all_constraints.INDEX_NAME FROM all_constraints WHERE substr(table_name,1,4) = 'TBSW' AND CONSTRAINT_TYPE = 'P' ORDER BY OWNER, 
               TABLE_NAME, CONSTRAINT_TYPE, CONSTRAINT_NAME) constraints,
		(SELECT ALL_IND_COLUMNS.COLUMN_NAME AS COLUMN_NAME, ALL_IND_COLUMNS.COLUMN_POSITION AS COLUMN_POSITION, ALL_IND_COLUMNS.TABLE_NAME AS TABLE_NAME_1, ALL_IND_COLUMNS.INDEX_NAME AS INDEX_NAME_1 FROM ALL_IND_COLUMNS ORDER BY INDEX_OWNER, TABLE_NAME, COLUMN_POSITION) colunas
				WHERE constraints.TABLE_NAME = colunas.TABLE_NAME_1 AND constraints.INDEX_NAME = colunas.INDEX_NAME_1
				ORDER BY TABLE_NAME, INDEX_NAME, COLUMN_POSITION;
  CURSOR cur_constraint_r
  IS 
	SELECT a.table_name AS TABLE_NAME, a.column_name AS COLUMN_NAME, a.constraint_name AS CONSTRAINT_NAME, c.owner AS OWNER, 
       c.r_owner AS R_OWNER, c_pk.table_name AS R_TABLE_NAME, c_pk.constraint_name AS R_PK
  FROM all_cons_columns a
  JOIN all_constraints c ON a.owner = c.owner
                        AND a.constraint_name = c.constraint_name
  JOIN all_constraints c_pk ON c.r_owner = c_pk.owner
                           AND c.r_constraint_name = c_pk.constraint_name
 WHERE c.constraint_type = 'R'
   AND a.table_name IN (SELECT DISTINCT TABLE_NAME
		FROM all_constraints WHERE substr(table_name,1,4) = 'TBSW'
    AND CONSTRAINT_TYPE = 'R');
BEGIN
  FOR v_cur_constraint_c IN cur_constraint_c
  LOOP
        dbms_output.put_line('ALTER ' || 'TABLE dbarede.' || v_cur_constraint_c.TABLE_NAME || ' ADD CONSTRAINT ' || v_cur_constraint_c.CONSTRAINT_NAME || ' CHECK (' || v_cur_constraint_c.SEARCH_CONDITION || ');');
  END LOOP;
  FOR v_cur_constraint_p IN cur_constraint_p
  LOOP
    IF (v_indice != v_cur_constraint_p.INDEX_NAME) THEN
        IF (v_indice != 'dummy') THEN
            dbms_output.put_line('');
            dbms_output.put_line(');');
            v_virgula := false;
        END IF;
        dbms_output.put_line('');
        dbms_output.put_line('ALTER ' || 'TABLE dbarede.' || v_cur_constraint_p.TABLE_NAME || ' ADD CONSTRAINT ' || v_cur_constraint_p.CONSTRAINT_NAME || ' PRIMARY KEY (');
        v_indice := v_cur_constraint_p.INDEX_NAME;
        v_ncol := 0;
    ELSE
        v_virgula := true;
    END IF;
    IF (v_newline) THEN
        IF (v_virgula) THEN
            dbms_output.put_line(',');
        END IF;
        v_newline := false;
    ELSE
        IF (v_onetime) THEN
            v_onetime := false;
        ELSE
            IF (v_ncol > 0) THEN
                dbms_output.put_line(',');
            END IF;
        END IF;
    END IF;
    dbms_output.put(' ' || v_cur_constraint_p.COLUMN_NAME || ' ');
    IF (v_virgula) THEN
        v_newline := true;
    END IF;
    v_ncol := v_ncol + 1;
  END LOOP;
  dbms_output.put_line('');
  dbms_output.put_line(');');
  v_virgula := true;
  v_newline := false;
  v_onetime := true;
  FOR v_cur_constraint_r IN cur_constraint_r
  LOOP
    IF (v_constraint != v_cur_constraint_r.CONSTRAINT_NAME) THEN
        IF (v_constraint != 'dummy') THEN
            dbms_output.put_line('');
            dbms_output.put_line(')'||v_reference||');');
            v_virgula := false;
        END IF;
        dbms_output.put_line('');
        dbms_output.put_line('ALTER ' || 'TABLE dbarede.' || v_cur_constraint_r.TABLE_NAME || ' ADD CONSTRAINT ' || v_cur_constraint_r.CONSTRAINT_NAME || ' FOREIGN KEY (');
        v_constraint := v_cur_constraint_r.CONSTRAINT_NAME;
        v_reference := ' REFERENCES ' || v_cur_constraint_r.R_TABLE_NAME || '(';
        v_ncol := 0;
    ELSE
        v_virgula := true;
    END IF;
    IF (v_newline) THEN
        IF (v_virgula) THEN
            dbms_output.put_line(',');
            v_reference := v_reference || ',';
        END IF;
        v_newline := false;
    ELSE
        IF (v_onetime) THEN
            v_onetime := false;
        ELSE
            IF (v_ncol > 0) THEN
                dbms_output.put_line(',');
                v_reference := v_reference || ',';
            END IF;
        END IF;
    END IF;
    dbms_output.put(' ' || v_cur_constraint_r.COLUMN_NAME || ' ');
    v_reference := v_reference || ' ' || v_cur_constraint_r.COLUMN_NAME || ' ';
    IF (v_virgula) THEN
        v_newline := true;
    END IF;
    v_ncol := v_ncol + 1;
  END LOOP;
  dbms_output.put_line('');
  dbms_output.put_line(')'||v_reference||');');
END;
/
