--
-- Este script foi criado com objetivo criar um script de criação dos indices das tabelas TBSW* no schema DBAREDE, 
-- e portanto deve ser executado no schema FEDBTMAPPL da versão 7.5 do IST, 
-- e irá extrair as estruturas das indices 'TBSW*' existentes e por fim com um script final a ser executado no
-- schema DBARED no AWS
-- Exemplo: CREATE UNIQUE INDEX dbarede.SW2020U0 ON dbarede.TBSW2020 (SGL_SITE, NOM_HOST);
--
SET SERVEROUTPUT ON

DECLARE
  CURSOR cur_indice
  IS 
	SELECT NDX.OWNER AS OWNER, NDX.INDEX_NAME AS INDEX_NAME, NDX.INDEX_TYPE AS INDEX_TYPE, NDX.TABLE_OWNER AS TABLE_OWNER, 
         NDX.TABLE_NAME AS TABLE_NAME, NDX.TABLE_TYPE AS TABLE_TYPE, NDX.UNIQUENESS AS UNIQUENESS, NDX.COMPRESSION AS COMPRESSION, 
         COLUNAS.COLUMN_NAME AS COLUMN_NAME, COLUNAS.COLUMN_POSITION AS COLUMN_POSITION, COLUNAS.DESCEND AS DESCEND 
         FROM (SELECT * FROM ALL_INDEXES WHERE SUBSTR(TABLE_NAME,1,4) = 'TBSW') NDX, (SELECT * FROM ALL_IND_COLUMNS WHERE 
         SUBSTR(TABLE_NAME,1,4) = 'TBSW') COLUNAS WHERE NDX.INDEX_NAME = COLUNAS.INDEX_NAME ORDER BY NDX.OWNER, NDX.INDEX_NAME, 
         NDX.TABLE_OWNER, NDX.TABLE_NAME, COLUNAS.COLUMN_POSITION;
  v_table varchar(100) := 'dummy';
  v_indice varchar(100) := 'dummy';
  v_unique varchar(100) := 'dummy';
  v_virgula boolean := true;
  v_newline boolean := false;
  v_onetime boolean := true;
  v_ncol number;
BEGIN
  FOR v_cur_indice IN cur_indice
  LOOP
    IF (v_indice != v_cur_indice.INDEX_NAME) THEN
        IF (v_indice != 'dummy') THEN
            dbms_output.put_line('');
            dbms_output.put_line(');');
            v_virgula := false;
        END IF;
        v_unique := v_cur_indice.UNIQUENESS;
        v_table := v_cur_indice.TABLE_NAME;
        IF (v_unique = 'NONUNIQUE') THEN
          v_unique := '';
        END IF;
        dbms_output.put_line('');
        dbms_output.put_line('CREATE ' || v_unique || ' INDEX dbarede.' || v_cur_indice.INDEX_NAME || ' ON dbarede.' || v_cur_indice.TABLE_NAME || '(');
        v_indice := v_cur_indice.INDEX_NAME;
        v_ncol := 0;
    ELSE
        v_virgula := true;
    END IF;
    IF (v_newline) THEN
        IF (v_virgula) THEN
            dbms_output.put_line(',');
        END IF;
        v_newline := false;
    ELSE
        IF (v_onetime) THEN
            v_onetime := false;
        ELSE
            IF (v_ncol > 0) THEN
                dbms_output.put_line(',');
            END IF;
        END IF;
    END IF;
    dbms_output.put(v_cur_indice.COLUMN_NAME || ' ');
   IF (v_virgula) THEN
        v_newline := true;
    END IF;
    v_ncol := v_ncol + 1;
  END LOOP;
  dbms_output.put_line('');
  dbms_output.put_line(');');
END;
/
