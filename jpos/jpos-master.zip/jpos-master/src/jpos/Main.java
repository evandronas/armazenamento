package jpos;

/**
 *
 * @author Renato de Camargo
 * @project jPOS
 *
 **/
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import isofw.*;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

public class Main extends Thread {
    /**
     * @param args the command line arguments
     */
    private static LogFile mErrlog;
    private static String mIP = "";
    private static int mPort = 0;
    private static String mCFGfile = "";
    private static String mMsgfile = "";
    private static String mBatchfile = "";
    private static String mAssincFile = "";
    private static String mDirectory = ".";
    private static int mqtdMsg = 1;
    private static int mmsgRate = 1000;
    private static int mdelay = 0;
    private static int mTO = ISO8583.getInstance().getTxnTimeout();
    private static int mTPS = 1;
    public static boolean _debug = false;
    private static ISO8583 iso8583 = ISO8583.getInstance();
    private static InterfacePreProcessor intPreProc = InterfacePreProcessor.getInstance();
    private static final String jPOSversion = "jPOSfw v3.1.5 - 01/01/2015 - @%d - Copyright rcamargo\n";
    private static final String jPOSCMD = "JPOSCMD";
    private static long lastTime = 0L;
    private static long currentTime = 0L;
    private static long elapsedTime = 0L;
    private static boolean mAssinc = false;
    private static boolean mBatch = false;
    private static boolean mAbortNonZeroRespcode = false;
    private static boolean mExecutePosScriptCommand = false;
    private static boolean mAbortNonZeroScriptRespCode = false;
    private static long PID;
    private String BatchLine;
    private long idmessage;
    private static ClientSocket client;
    private static long FileSequeunce = 0;

    public Main(String BatchLine, long id) {
        this.BatchLine = BatchLine;
        this.idmessage = id;
    }

    public static void main(String[] args) throws IOException, InterruptedException, NoSuchFieldException, IllegalArgumentException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        // TODO code application logic here
        PID = Util.getPID();        
        System.out.printf(jPOSversion,PID);
        if (args.length > 0) {
            for (int i = 0; i < args.length; i++) {
                switch (args[i].charAt(0)) {
                    case '-': {
                        switch (Character.toUpperCase(args[i].charAt(1))) {
                            case 'V': {
                                _debug = true;
                                break;
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < args.length; i++) {
                switch (args[i].charAt(0)) {
                    case '-': {
                        String parameter = args[i].substring(2, args[i].length());
                        switch (Character.toUpperCase(args[i].charAt(1))) {
                            case 'C': {
                                RunCFGFile(parameter);
                                break;
                            }
                            case 'I': {
                                SetIP(parameter);
                                break;
                            }
                            case 'P': {
                                SetIPPort(parameter);
                                break;
                            }
                            case 'M': {
                                SetMsgFile(parameter);
                                break;
                            }
                            case 'Q': {
                                SetMsgQtd(parameter);
                                break;
                            }
                            case 'D': {
                                SetDelay(parameter);
                                break;
                            }
                            case 'T': {
                                SetTO(parameter);
                                break;
                            }
                            case 'V': {
                                _debug = true;
                                break;
                            }
                            case 'B': {
                                SetBatchFile(args[i].substring(2, args[i].length()));
                                break;
                            }
                            case 'A' : {
                                SetAssincFile((args[i].substring(2, args[i].length())));
                                break;
                            }
                            case 'R': {
                                SetTPS(args[i].substring(2, args[i].length()));
                                break;
                            }
                            case 'S': {
                                SetDirectory(args[i].substring(2, args[i].length()));
                                break;
                            }
                            case 'F': {
                               for ( int c = 0; c < parameter.length(); c++) {
                                   if( parameter.toUpperCase().charAt(c) == 'A') {
                                        mAbortNonZeroScriptRespCode = true;
                                        if( _debug )
                                            System.out.println( "AbortifNonZeroPosCommandScript = ON");
                                   }
                                   if( parameter.toUpperCase().charAt(c) == 'S') {
                                        mExecutePosScriptCommand = true;
                                        if( _debug )
                                            System.out.println( "ExecuteGeneralPosCommandScript = ON");                                        
                                   }
                                   if( parameter.toUpperCase().charAt(c) == 'R') {
                                        mAbortNonZeroRespcode = true;
                                        if( _debug )
                                            System.out.println( "AbortifNonZeroRespCode = ON");
                                   }                                   
                               }
                               break;
                            }
                            default: {
                                System.err.print("Unknown Parameter !!!\n");
                                Sintaxe();
                                System.exit(1);
                                break;
                            }
                        }
                    }
                    if (_debug) {
                        System.out.println("Parameters [" + i + "] " + args[i]);
                    }
                }
            }
        } else {
            Sintaxe();
            System.exit(1);
        }

        if ((mPort == 0 || mCFGfile.length() == 0 || mIP.length() == 0) || (mMsgfile.length() == 0 && mBatchfile.length() == 0 && mAssincFile.length() == 0 )) {
            Sintaxe();
            System.exit(1);
        }

        if ( mAssincFile.length() > 0)
            AssyncLoad();  // Multi-Thead Mode
        else 
            SyncLoad();    // Single or Batch Mode

        System.out.println("\nbye");
        System.exit(0);
    }

    public static void Sintaxe() {
        System.err.println("Sintaxe : jPOS -c<Cfgfile> -s<Data Directory> -i<IP> -p<Port> -m<MsgFile> -b<BatchFile> -A<AssyncFile> -d<Delay> -q<Qtd> -r<TPS Rate> -t<Timeout> -v");
        System.err.println("  -c<Cfgfile>        - jPOS ISO8583 Configuration File");
        System.err.println("  -s<Data Directory> - jPOS Data Directory (for jpos.db or datafiles)");
        System.err.println("  -i<IP>             - IP Address Destination");
        System.err.println("  -p<Port>           - Port Destination");
        System.err.println("  -m<MsgFile>        - Single Message File");
        System.err.println("  -b<BatchFile>      - Batch File Message File (with a list of Single Messages)");
        System.err.println("  -a<AssyncFile>     - Assync File Message File (with a list of Single Messages to Pump)");
        System.err.println("  -q<Qtd>            - Message Quantity for Assync Mode to pump");
        System.err.println("  -d<Delay>          - Delay Between each message to Send em seconds");
        System.err.println("  -t<Timeout>        - Time out (in milisec), default 30000 ms => 30 seconds");
        System.err.println("  -r<TPS Rate>       - TPS Rate for Assync Mode");
        System.err.println("  -f<flags>          - Flags to modify workflow of execution");
        System.err.println("                      -fa => abort if a PosScript Command return a Non Zero Status");
        System.err.println("                      -fr => abort if a Message Response code is a Non Zero return" );
        System.err.println("                      -fs => execute a generic PosScript Command setted by environment Variable <" + jPOSCMD + ")" );
        System.err.println("  -v                 - Verbose (debug info for troubleshooting)");
    }

    public static void RunCFGFile(String larq) throws FileNotFoundException, IOException {
        if (_debug) {
            System.out.println("Config File = " + larq);
        }
        // BufferedReader in = new BufferedReader(new FileReader(larq));
        mCFGfile = larq;
        iso8583.LoadISO8583Profile(larq, mDirectory, _debug);
    }

    public static void SetIP(String lip) {
        if (_debug) {
            System.out.println("IP = " + lip);
        }
        mIP = lip;
    }

    public static void SetTO(String lto) {
        if (_debug) {
            System.out.println("Timeout = " + lto);
        }
        mTO = Integer.parseInt(lto);
    }

    public static void SetTPS(String ltps) {
        if (_debug) {
            System.out.println("TPS Rate = " + ltps);
        }
        mTPS = Integer.parseInt(ltps);
    }
    
    public static void SetDirectory(String dir) {
        if (_debug) {
            System.out.println("Directory = " + dir);
        }
        iso8583.setDataDirectory(dir);
        mDirectory = dir;
    }

    public static void SetIPPort(String lipport) {
        if (_debug) {
            System.out.println("Port = " + lipport);
        }
        mPort = Integer.parseInt(lipport);
    }

    public static void SetErrFile(String lerrfile) throws IOException {
        if (_debug) {
            System.out.println("Error File = " + lerrfile);
        }
        mErrlog = new LogFile(lerrfile);
        mErrlog.log("Starting ...");
    }

    public static void SetMsgFile(String lmsgfile) {
        if (_debug) {
            System.out.println("Msg File = " + lmsgfile);
        }
        mMsgfile = lmsgfile;
    }

    public static void SetBatchFile(String lmsgfile) {
        if (_debug) {
            System.out.println("Batch File = " + lmsgfile);
        }
        mBatchfile = lmsgfile;
        mBatch = true;
        mAssinc = false;
    }

    public static void SetAssincFile(String lmsgfile) {
        if (_debug) {
            System.out.println("Assinc File = " + lmsgfile);
        }
        mAssincFile = lmsgfile;
        mAssinc = true;
        mBatch = false;
    }

    public static void SetMsgQtd(String lmsg) {
        mqtdMsg = Integer.parseInt(lmsg);
        if (_debug) {
            System.out.println("#Messages = " + mqtdMsg);
        }
    }

    private static void SetDelay(String ldelay) {
        if (_debug) {
            System.out.println("Delay = " + mdelay);
        }
        mdelay = Integer.parseInt(ldelay) * 1000;
    }

    public static void slowDown( ) throws InterruptedException {
          long sleeptime;

          currentTime = System.currentTimeMillis();

          elapsedTime = currentTime - lastTime;

          if (elapsedTime == 0) elapsedTime = 1;

          if (mAssinc && _debug)
             System.out.println("===> Elapsed Time : " + elapsedTime + " <====");

          sleeptime = ( 1000 - elapsedTime ) / mTPS;

          if (sleeptime < 0) sleeptime = 0;

          Thread.sleep(sleeptime);

          lastTime = System.currentTimeMillis();
    }
    
    @SuppressWarnings("static-access")
    public static void SyncLoad() throws InterruptedException, IOException, NoSuchFieldException {
        BufferedReader in = null;
        String BatchLine;
        String[] IntProcMessages;
        int[] IntProcMessagesLines;

        client = new ClientSocket(mIP, mPort);
        if (client.Connect() > 0) {
            return;
        }
        
        client.ClearSocket();   // CleanUp de Channel

        if (mTO > 0) {
            client.SetTimeOut(mTO);
        }

        if (mBatchfile.length() > 0 ) {
            try {
                in = new BufferedReader(new FileReader(mBatchfile));
            } catch (IOException e) {
                System.out.println(e.getMessage());
                return;
            }
            BatchLine = in.readLine();
        } else {
            BatchLine = mMsgfile;
        }

        FileSequeunce = 0;
        while (BatchLine != null) {
            if (BatchLine.length() > 0 ) {
                if (BatchLine.charAt(0) != '#') {
                    boolean exists = (new File(BatchLine)).exists();
                    FileSequeunce++;
                    if (!exists) {
                        System.err.println(BatchLine + " not found");
                    } else {
                        System.out.println("\n"+Util.getTimeStamp());
                        System.out.println("*** " + BatchLine + " " + Util.creplicate("*", 100 - BatchLine.length()));

                        lastTime = System.currentTimeMillis();

                        intPreProc.LoadMessages(BatchLine, false, _debug);
                        
                        IntProcMessages = intPreProc.getMessages();
                        IntProcMessagesLines = intPreProc.getMessagesLines();
                        
                        for ( int ix = 0; ix < IntProcMessages.length; ix++ ) {
                            if(_debug) System.out.printf("Message [%d:%s:%d]\n", ix, IntProcMessages[ix],IntProcMessagesLines[ix]);
                            if(IntProcMessages[ix].length() > 0) {
                                ProcessSingleMessage( BatchLine, IntProcMessages[ix], IntProcMessagesLines[ix], ix );
                            }
                        }
                        
                        if( _debug )
                            intPreProc.PrintDecodedMessages();
                        
                        // Limpa variaveis entre um arquivo e outro
                        InterfaceProcessor.getInstance().ClearVariables();
                    }
                }
                if ( mBatch ) {
                    try {
                        BatchLine = in.readLine();
                    } catch (IOException e) {
                        System.out.println(e.getMessage());
                        return;
                    }
                } else {
                    BatchLine = null;
                }
            }
        }
        if (mBatchfile.length() > 0)
            in.close();

        client.Disconnect();
    }
    
    public static void ProcessSingleMessage( String arquivo, String msg, int line, long ix ) throws InterruptedException, IOException, NoSuchFieldException
    {
        InterfaceProcessor message;
        ArrayList<String> Commands;
        byte[] sentbuffer;
        long startSend = 0;
        long etSend = 0;
        
        MessageSet mf = new MessageSet();
        
        // Gera uma nova KSN para a Transacao
        long ksipin = iso8583.getCurrentKSI();
        ksipin++;
        iso8583.setCurrentKSI( ksipin );        
        
        message = new InterfaceProcessor(arquivo, msg, line, mIP, mPort, _debug);
        byte[] msgbuffer = Util.hex2asc(message.getBuffer());
        sentbuffer = msgbuffer;
        message.AddVariable("_MSGSEQ", ix + 1);
        message.AddVariable("_FILESEQ", FileSequeunce);
        message.AddRawVariable("_CONFIGFILE", mCFGfile);
        
        // For POS IP
        if ( iso8583.IsRequestEncrypted() ) {
            //Util.Dump2(msgbuffer, msgbuffer.length );
            byte[] encryptedmsg = message.encryptPOSIP( msgbuffer, msgbuffer.length );
            client.Send(encryptedmsg, encryptedmsg.length, ix);
            iso8583.decode(sentbuffer, sentbuffer.length, false);
        } else {
            client.Send(sentbuffer, sentbuffer.length, ix);
            iso8583.decode(sentbuffer, sentbuffer.length, false);
        }
        message.AddVariable("_SENTBUFFER", Util.Bytes2HEX(sentbuffer, sentbuffer.length) );
        message.AddVariable("_SENDTIME", client.getSendTimeStamp().trim() );
        
        mf = intPreProc.newMessageSet(iso8583.getDecodedFields());
        
        if( _debug ) {
            for (int id = 0; id <= 128; id++)
                if ( mf.getField(id).isInit())
                    System.out.printf("%s.%03d=[%s]\n",mf.getField(0).getRawData(),id,mf.getField(id).getRawData());
        }
        
        message.AddVariable("_RECEIVETIME", "NULL");
        message.AddVariable("_RCVDBUFFER", "NULL");
        message.AddVariable("_MSGETIME", 0 );
        message.AddVariable("_LASTRESPCODE", "???" );
        int LastRespCode = -1;
        if ( message.isSendReceive() ) {
            // Receive the Answer
            sentbuffer = client.getData();
            iso8583.decode(sentbuffer, client.getreclen(), true);
            message.AddVariable("_RECEIVETIME", client.getReceiveTimeStamp().trim() );            
            message.AddVariable("_MSGETIME", client.getReceiveTime() - client.getSendTime() );
            message.AddVariable("_RCVDBUFFER", Util.Bytes2HEX(sentbuffer, client.getreclen()) );
            message.AddVariable("_LASTRESPCODE", iso8583.getLastRespCode() );
            try {
                LastRespCode = Integer.parseInt(iso8583.getLastRespCode());
            } catch ( Exception e ) {
                //
            }

            mf = intPreProc.newMessageSet(iso8583.getDecodedFields());

            if ( mf != null ) {
                if( _debug )
                    for (int id = 0; id <= 128; id++)
                        if ( mf.getField(id).isInit())
                            System.out.printf("%s.%03d=[%s]\n",mf.getField(0).getRawData(),id,mf.getField(id).getRawData());
            }

            if ( mAbortNonZeroRespcode && LastRespCode != 0 )
            {
                System.out.printf("Execution aborted !!!  Last Respcode returned [%d]\n", iso8583.getLastRespCode());
                System.exit(1);
            }
            // Se for Batch Mode ou Single Mode aguarda o time-out
            if (mdelay > 0) {
                try {
                    Thread.sleep(mdelay);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
       
        if( mExecutePosScriptCommand ) {
            String cmdline = jposFunc.GetEnv_func( jPOSCMD );
            if( cmdline != null && cmdline.length() > 0 && !cmdline.isEmpty() && !cmdline.equals(""))
                message.addPosCommand( "!" + cmdline);
            else
                System.out.println( "WARNING: General PosScript Command not executed because " + jPOSCMD + " not setted" );
        }
        
        Commands = message.getPosCommand();
        for (int iCommands = 0; iCommands < Commands.size(); iCommands++) {
            String[] conjunto = Commands.get(iCommands).split(" ");
            
            if( _debug )
                System.out.printf ( "...\nPosScript Command[%s]\n", Commands.get(iCommands) );
            if ( Commands.get(iCommands).charAt(0) == '!' )
            {
                String CommandLine = jposFunc.ResponseField_func(Commands.get(iCommands).substring(1));
                
                System.out.printf ( "-----------------------------------------------------------------------------------------------------\n");
                message.AddVariable("_LASTCMDSTART", Util.getTimeStamp());
                long startTime = System.currentTimeMillis();
                int respCode = jposFunc.RunCommand(CommandLine);
                message.AddVariable("_LASTCMDEND", Util.getTimeStamp());
                long estimatedTime = System.currentTimeMillis() - startTime;
                message.AddVariable("_LASTCMDETIME", estimatedTime );
                System.out.printf ( "-----------------------------------------------------------------------------------------------------\n");
                message.AddVariable("_LASTCMDSTATUS", respCode );
                message.AddRawVariable("_LASTCMD", CommandLine);
                if ( mAbortNonZeroScriptRespCode && respCode != 0 )
                {
                    System.out.printf("Execution aborted !!!  PosCommad Script [%s], returned [%d]\n",CommandLine,respCode);
                    System.exit(1);
                }
            }
            else if( conjunto[0].toUpperCase().equals("DELAY"))
            {
                jposFunc.Delay_func( conjunto[1] );
            } else {
                System.out.printf( "WARNING : [%s] not recognized\n" , Commands.get(iCommands));
            }
        }
    }

    @SuppressWarnings("static-access")
    public static void AssyncLoad() throws InterruptedException, IOException, NoSuchFieldException {
        byte[] sentbuffer;
        BufferedReader in = null;
        String BatchLine;
        long id = 0;
        String[] IntProcMessages;
        int[] IntProcMessagesLines;
        InterfaceProcessor message;

        client = new ClientSocket(mIP, mPort);
        if (client.Connect() > 0) {
            return;
        }

        if (mTO > 0) {
            client.SetTimeOut(mTO);
        }

        while ( true )
        {
            try {
                in = new BufferedReader(new FileReader(mAssincFile));
            } catch (IOException e) {
                System.out.println(e.getMessage());
                return;
            }
            BatchLine = in.readLine();

            while (BatchLine != null) {
                if (BatchLine.length() > 0 ) {
                    if (BatchLine.charAt(0) != '#') {
                        boolean exists = (new File(BatchLine)).exists();
                        if (!exists) 
                        {
                            System.out.println(BatchLine + " not found");
                        } 
                        else
                        {
                            System.out.println("\n"+Util.getTimeStamp());
                            System.out.println("*** " + BatchLine + " " + Util.creplicate("*", 100 - BatchLine.length()));
                           
                            intPreProc.LoadMessages(BatchLine, true, _debug);

                            IntProcMessages = intPreProc.getMessages();
                            IntProcMessagesLines = intPreProc.getMessagesLines();
                            
                            for (int lqtdMsg = 1; lqtdMsg <= mqtdMsg; lqtdMsg++) {
                                
                                lastTime = System.currentTimeMillis();
                                id++;
                                /* In Assync Mode, just send the first message */
                                message = new InterfaceProcessor(BatchLine, IntProcMessages[0], IntProcMessagesLines[0], mIP, mPort, _debug);
                                byte[] msgbuffer = Util.hex2asc(message.getBuffer());
                                sentbuffer = msgbuffer;
                                client.Send(sentbuffer, sentbuffer.length, id);
                                if(_debug) message.PrintGeneratedMessage();
                                iso8583.decode(sentbuffer, sentbuffer.length, false);

                                // Thread para tratar retorno
                                Thread t = new Main(BatchLine,id);
                                t.start();

                                // Aguarda o Final da Thread
    //                            if (mAssinc)
    //                                t.join();
                                    //while (t.isAlive())

                                slowDown();
                            }
                        }
                    }
                }
                try {
                    BatchLine = in.readLine();
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                    return;
                }
            }
        }
//        Thread.sleep(mTO);
//        client.Disconnect();
    }

    @Override
    public void run() {
        try {
            byte[] sentbuffer;
            InterfaceProcessor message;

            //message = new InterfaceProcessor(BatchLine, _debug);
            
            // Obtem resposta
            // if( _debug)
            System.out.println("Threads : " + Thread.activeCount());
            sentbuffer = client.getData();
            iso8583.decode(sentbuffer, client.getreclen(),true);
            
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
