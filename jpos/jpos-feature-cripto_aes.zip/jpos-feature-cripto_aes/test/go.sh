cd "/c/Users/renat/Dropbox/Fontes/test"

DATADIR="/c/Users/renat/Dropbox/Fontes/test/datafile/"
PORTA=6666

if [[ "${1}" == "MCI" ]]; then
	CFGFILE="cfg/jMCI.cfg"
	MSGFILE="term_scripts/mci_i1.jpos"
fi

if [[ "${1}" == "POS" ]]; then
	CFGFILE="cfg/jPOS.cfg"
	MSGFILE="term_scripts/pos4.jpos"
fi

if [[ "${1}" == "POO" ]]; then
	CFGFILE="cfg/jPOO.cfg"
	MSGFILE="term_scripts/pos4.jpos"
fi

if [[ "${1}" == "POSIP" ]]; then
	CFGFILE="cfg/jPOSIP.cfg"
	MSGFILE="term_scripts/pos4.jpos"
fi

if [[ "${1}" == "PDV" ]]; then
	CFGFILE="cfg/jPDVinac.cfg"
	MSGFILE="term_scripts/amex_inac.jpos"
fi

if [[ "${1}" == "TKCH" ]]; then
	CFGFILE="cfg/jTKCHIP.cfg"
	MSGFILE="term_scripts/tkchip_0800.jpos"
fi

if [[ "${1}" == "VISA" ]]; then
	CFGFILE="cfg/jVISA.cfg"
	MSGFILE="term_scripts/visa.jpos"
fi

if [[ "${1}" == "AMEX" ]]; then
	CFGFILE="cfg/jAMEX.cfg"
	MSGFILE="term_scripts/amex.jpos"
fi

if [[ "${1}" == "ELO" ]]; then
	CFGFILE="cfg/jELO.cfg"
	MSGFILE="term_scripts/elo.jpos"
fi

if [[ "${1}" == "ALELO" ]]; then
	CFGFILE="cfg/jAlelo.cfg"
	MSGFILE="term_scripts/alelo.jpos"
fi

if [[ "${1}" == "DINERS" ]]; then
	CFGFILE="cfg/jDV.cfg"
	MSGFILE="term_scripts/diners.jpos"
fi

if [[ "${1}" == "GREENCARD" ]]; then
	CFGFILE="cfg/jDV.cfg"
	MSGFILE="term_scripts/greencard.jpos"
fi

if [[ "${1}" == "SERASA" ]]; then
	CFGFILE="cfg/jHOST.cfg"
	MSGFILE="term_scripts/host.jpos"
fi

if [[ "${1}" == "RAV" ]]; then
	CFGFILE="cfg/jHOST.cfg"
	MSGFILE="term_scripts/rav.jpos"
fi

if [[ "${1}" == "VOUCHER" ]]; then
	CFGFILE="cfg/jVoucher.cfg"
	MSGFILE="term_scripts/voucher.jpos"
fi

if [[ "${1}" == "QRCODE" ]]; then
	CFGFILE="cfg/jWQ3.cfg"
	MSGFILE="term_scripts/wq3.jpos"
fi

if [[ "${1}" == "ITI" ]]; then
	CFGFILE="cfg/jWQ3.cfg"
	MSGFILE="term_scripts/iti.jpos"
fi

java -jar "C:\Users\renat\Documents\NetBeansProjects\jPOS_v2\dist\jPOS_v2.jar" -C${CFGFILE} -Ilocalhost -P${PORTA} -S${DATADIR} -m${MSGFILE} -d2 -T30000 ${2}